// =================================================================
// [스크립트 목적]  전투 1회의 조립자(Composition Root) + 전투 부속 시스템 소유자.
//                 전투 시스템(POCO·매니저)을 생성·주입·연결하고, 드로우→UI 연출과
//                 카드 풀링을 전담한다. 인게임(런) 컨트롤러는 준비 후 실제 시작을 호출.
//                 ※ UI 자식 참조(손패·배치·뷰)는 UIBattle 에서 수령, 데이터는 DataManager 경유.
// [주요 변수]      - _deckSystem/_player/_enemyHandler/... : 조립한 전투 POCO
//                  - _grid/_battle  : Addressable 로 생성한 전투 매니저 (해제용 참조)
//                  - _cardHand/_placementController/_playerView/_enemyView : UIBattle 에서 수령
//                  - _currentEnemyData : 이번 전투 적 데이터 (Run 이 BattleStartContext 로 주입)
//                  - _cts           : 전투 부속 비동기(드로우 연출 등) 취소 토큰
// [의존 관계]      - ResourceManager / PoolManager / UIManager / DataManager (인프라)
//                  - BattleManager / GridManager / ChainExecutor / CardPhaseDispatcher
//                  - DeckSystem / PlayerActor / EnemyTurnHandler / TargetResolver (POCO)
//                  - UIBattle / UICardHand / CardPlacementController / CardAnimationSystem
// [배치]           인게임 씬에 빈 GameObject 만들고 부착 (MainController·InGameController 와 동급)
// [역할 구분]      InGameController = 런 흐름 / BattleController = 전투 조립·부속·연출
//                  / BattleManager = 순수 전투 규칙
// [설계 노트]      - 조립자 패턴: SceneSingleton(Grid/Battle)과 POCO(Deck 등)를 한 곳에서 묶어
//                    Awake 순서 의존 제거.
//                  - UIBattle 오픈 책임을 이 컨트롤러가 인수(기존 BattleManager 에서 이관).
//                  - 전투 입력(덱·적)은 BattleController 가 RunContext 에서 캐내지 않고,
//                  - 적/덱은 InGameController 가 BattleStartContext 로 주입 (Run Flow 분리).
//                    조회해 enum→SO 인덱스를 구축(단일 데이터 출처화). 원본은 읽기 전용.
// =================================================================

using System;
using System.Collections.Generic;
using System.Threading;
using Cysharp.Threading.Tasks;
using DamageNumbersPro;
using DG.Tweening;
using UnityEngine;
using UnityEngine.Serialization;

/// <summary>
/// 전투 1회를 조립·구동하고 전투 부속 시스템(드로우 UI·풀링·연출)을 소유하는 씬 싱글턴.
/// 런 컨트롤러는 준비와 실제 시작을 호출하고, 전투 종료는 OnBattleFinished 로 통지받는다.
/// 전투 규칙은 BattleManager 가, 조립·배선·UI 오픈은 이 클래스가 담당한다 (책임 분리).
/// </summary>
public sealed class BattleController : SceneSingleton<BattleController>
{
    private const string BLIND_POISON_VFX_KEY = "BlindPoisonVfx";
    private const string BossPhaseSortingLayerName = "FrontEffect";
    private const int BossPhaseShadowSortingOrder = 1000;
    private const int BossPhaseDarkSortingOrder = 1001;
    private const int ChainFinisherCount = 100;
    private const float ChainMagicCircleHideDuration = 1f;
    private static readonly Vector3 ChainMilestoneVfxSpawnOffset = new Vector3(0.7f, 0f, 0f);
    private static readonly int[] ChainMagicCircleEndCounts = { 30, 50, 100 };
    private static readonly string[] ChainMagicCircleKeys =
    {
        "Combo_Magic_First",
        "Combo_Magic_Second",
        "Combo_Magic_Third",
    };

    [Serializable]
    private struct ChainMilestoneAttackSetting
    {
        [Tooltip("이 에너지파 공격이 발동하는 누적 체인 수입니다.")]
        [Min(1)]
        [SerializeField] private int _chainCount;

        [Tooltip("에너지파의 1회 타격당 데미지입니다. Kill Target이 꺼져 있으면 이 데미지를 Hit Count 횟수만큼 반복 적용하여 총 Damage x Hit Count 피해를 줍니다.")]
        [Min(0)]
        [SerializeField] private int _damage;

        [Tooltip("데미지와 타격 사운드가 발생하는 횟수입니다. 예: Damage 10, Hit Count 3이면 10 데미지씩 3회, 총 30 데미지를 적용합니다.")]
        [Min(1)]
        [SerializeField] private int _hitCount;

        [Tooltip("켜면 Damage를 사용하지 않고, 지정된 Hit Count 동안 적의 방어도와 체력을 나누어 소진해 마지막 타격에 처치합니다. 100체인은 항상 처치형으로 처리됩니다.")]
        [SerializeField] private bool _killTarget;

        [Tooltip("발사할 에너지파 프리팹의 Addressable 키입니다. 현재 기본 에너지파는 LaserRoot입니다.")]
        [SerializeField] private string _projectileKey;

        [Tooltip("Animation Speed Multiplier가 1일 때 에너지파가 유지되는 기본 시간(초)입니다. 다단 히트는 이 시간 안에 균등한 간격으로 발생합니다.")]
        [Min(0.01f)]
        [SerializeField] private float _animationDuration;

        [Tooltip("에너지파 애니메이션 재생 속도 배율입니다. 값이 커질수록 애니메이션과 전체 타격 진행 시간이 빨라집니다.")]
        [Min(0.01f)]
        [SerializeField] private float _animationSpeedMultiplier;

        [Tooltip("BattleVfxAudioCatalog에 설정된 에너지파 발사음 Pitch에 곱할 배율입니다.")]
        [Range(0.1f, 3f)]
        [SerializeField] private float _launchPitchMultiplier;

        [Tooltip("BattleVfxAudioCatalog에 설정된 에너지파 타격음 Pitch에 곱할 배율입니다. 모든 다단 히트에 동일하게 적용됩니다.")]
        [Range(0.1f, 3f)]
        [SerializeField] private float _hitPitchMultiplier;

        public int ChainCount => _chainCount;
        public int Damage => _damage;
        public int HitCount => Mathf.Max(1, _hitCount);
        public bool KillTarget => _killTarget || _chainCount == ChainFinisherCount;
        public string ProjectileKey => _projectileKey;
        public float AnimationDuration => _animationDuration > 0f
            ? _animationDuration
            : (_chainCount == ChainFinisherCount ? 3f : 1f);
        public float AnimationSpeedMultiplier => _animationSpeedMultiplier > 0f
            ? _animationSpeedMultiplier
            : 1f;
        public float LaunchPitchMultiplier => _launchPitchMultiplier > 0f
            ? _launchPitchMultiplier
            : 1f;
        public float HitPitchMultiplier => _hitPitchMultiplier > 0f
            ? _hitPitchMultiplier
            : 1f;

        public ChainMilestoneAttackSetting(
            int chainCount,
            int damage,
            int hitCount,
            bool killTarget,
            string projectileKey,
            float animationDuration,
            float animationSpeedMultiplier,
            float launchPitchMultiplier,
            float hitPitchMultiplier)
        {
            _chainCount = Mathf.Max(1, chainCount);
            _damage = Mathf.Max(0, damage);
            _hitCount = Mathf.Max(1, hitCount);
            _killTarget = killTarget;
            _projectileKey = projectileKey;
            _animationDuration = Mathf.Max(0.01f, animationDuration);
            _animationSpeedMultiplier = Mathf.Max(0.01f, animationSpeedMultiplier);
            _launchPitchMultiplier = Mathf.Clamp(launchPitchMultiplier, 0.1f, 3f);
            _hitPitchMultiplier = Mathf.Clamp(hitPitchMultiplier, 0.1f, 3f);
        }
    }

    [Header("전투 — 파라미터")]
    [Tooltip("플레이어 시작 스탯 기본치(비런 전투 폴백). InGameController 와 같은 에셋을 물린다.")]
    [SerializeField] private PlayerStatConfigSO _statConfig;

    // 이번 전투에 실제 적용되는 턴 드로우 수(런 스탯 우선 해소값). StartBattle 에서 세팅.
    private int _activeDrawPerTurn = 5;

    // 공유 설정 접근자 — 미할당 시 안전 폴백값.
    private int ConfigMaxHp => _statConfig != null ? _statConfig.MaxHp : 50;
    private int ConfigMaxEnergy => _statConfig != null ? _statConfig.MaxMana : 3;
    private int ConfigDrawPerTurn => _statConfig != null ? _statConfig.DrawPerTurn : 5;
    private int ConfigMaxHandSize => _statConfig != null ? _statConfig.MaxHandSize : 10;

    [Tooltip("적 정의 데이터 (체력·의도 패턴). 비우면 폴백 더미 의도\n" +
             "[horizon] EnemyDataSO 도 추후 DataManager 경유로 전환 예정")]
    [SerializeField] private EnemyDataSO _enemyData;

    [Header("전투 — 연출(VFX) 파라미터")]
    [Tooltip("투사체 이동 속도 (units/sec)")]
    [Min(1f)]
    [SerializeField] private float _projectileSpeed = 20f;
    [Tooltip("다중 타격 투사체가 시작점-도착점 직선의 수직 방향으로 휘어지는 기본 거리입니다.")]
    [Min(0f)]
    [FormerlySerializedAs("_projectileArcHeight")]
    [SerializeField] private float _multiHitProjectileCurveHeight = 0.75f;
    [Tooltip("다중 타격일 때 각 투사체의 비행 속도 배율입니다. 7이면 기존 7타 압축과 같은 속도이며, 1이면 단일 투사체와 같은 비행 시간을 사용합니다.")]
    [Min(0.1f)]
    [SerializeField] private float _multiHitProjectileSpeedMultiplier = 7f;
    [Tooltip("다중 타격 투사체가 직선 경로의 수직 방향으로 벌어지는 거리 비례 곡률 각도입니다.")]
    [Range(0f, 75f)]
    [FormerlySerializedAs("_multiHitProjectileMaxAngle")]
    [SerializeField] private float _multiHitProjectileCurveAngle = 25f;

    [Header("전투 — 보스 페이즈 전환 연출")]
    [Tooltip("보스 중심에서 커지는 Dark Orb의 Addressable 키입니다. 교체 프리팹 루트에는 PoolableMonoBehaviour가 필요합니다.")]
    [SerializeField] private string _bossPhaseDarkOrbKey = "Dark_Orb";

    [Tooltip("보스 주변에서 중심으로 흡수되는 Shadow Orb의 Addressable 키입니다. 교체 프리팹 루트에는 PoolableMonoBehaviour가 필요합니다.")]
    [SerializeField] private string _bossPhaseShadowOrbKey = "ShadowOrb";

    [Tooltip("Dark Orb가 성장하며 Shadow Orb를 흡수하는 기본 시간(초)입니다. 전투 고속 모드의 영향을 받습니다.")]
    [Min(0.1f)]
    [SerializeField] private float _bossPhaseAbsorbDuration = 2f;

    [Tooltip("Shadow Orb 생성 간격(초)입니다. 전투 고속 모드의 영향을 받습니다.")]
    [Min(0.01f)]
    [SerializeField] private float _bossPhaseShadowSpawnInterval = 0.3f;

    [Tooltip("보스 중심에서 Shadow Orb가 생성되는 원의 반지름(월드 단위)입니다.")]
    [Min(0.1f)]
    [SerializeField] private float _bossPhaseShadowSpawnRadius = 2f;

    [Tooltip("Shadow Orb가 Dark Orb까지 이동하며 축소되는 시간(초)입니다. 전투 고속 모드의 영향을 받습니다.")]
    [Min(0.01f)]
    [SerializeField] private float _bossPhaseShadowTravelDuration = 0.45f;

    [Tooltip("Dark Orb가 처음 나타날 때의 월드 Scale입니다.")]
    [Min(0.01f)]
    [SerializeField] private float _bossPhaseDarkStartScale = 0.1f;

    [Tooltip("흡수 완료 시 Dark Orb의 월드 Scale입니다.")]
    [Min(0.01f)]
    [SerializeField] private float _bossPhaseDarkMaxScale = 2f;

    [Tooltip("다음 페이즈 View 적용 후 Dark Orb가 사라지는 시간(초)입니다. 전투 고속 모드의 영향을 받습니다.")]
    [Min(0.01f)]
    [SerializeField] private float _bossPhaseDarkCollapseDuration = 0.2f;

    [Tooltip("보스 페이즈 전환 시작 시 카메라 흔들림 세기입니다.")]
    [Min(0f)]
    [SerializeField] private float _bossPhaseShakeForce = 0.5f;

    [Tooltip("보스 페이즈 전환 시작 시 카메라 흔들림 시간(초)입니다.")]
    [Min(0.01f)]
    [SerializeField] private float _bossPhaseShakeDuration = 0.3f;

    [Tooltip("Dark Orb 축소 완료 후 화면 충격파를 재생하는 컴포넌트입니다.")]
    [SerializeField] private ScreenRipplePlayer _bossPhaseScreenRipple;

    [Tooltip("다음 페이즈 BGM이 준비된 경우, 현재 BGM을 줄이는 시간(초)입니다.")]
    [Min(0f)]
    [SerializeField] private float _bossPhaseBgmFadeOutDuration = 0.5f;

    [Tooltip("화면 충격파 완료 후 다음 페이즈 BGM이 들어오는 시간(초)입니다.")]
    [Min(0f)]
    [SerializeField] private float _bossPhaseBgmFadeInDuration = 1f;

    [Tooltip("다음 페이즈 BGM이 같은 트랙의 변주(피치·베이스만 다른 버전)일 때 켜세요. " +
             "곡을 처음부터 틀지 않고 이전 페이즈가 재생 중이던 위치에서 이어 시작해 마디가 어긋나지 않습니다. " +
             "페이즈마다 완전히 다른 곡을 쓴다면 끄세요.")]
    [SerializeField] private bool _bossPhaseBgmKeepsPlaybackPosition = true;

    [Header("전투 VFX 사운드")]
    [Tooltip("VFX Addressable 키 또는 캐스팅 구체 프리팹 이름과 SFX Addressable 키를 연결하는 카탈로그")]
    [SerializeField] private BattleVfxAudioCatalog _vfxAudioCatalog;

    [Header("전투 — EraseInfo 연출")]
    [Tooltip("EraseInfo 실행 시 적이 플레이어에게 던질 독병 스프라이트")]
    [SerializeField] private Sprite _eraseInfoProjectileSprite;

    [Tooltip("독병 이동 시간(초)")]
    [Min(0.01f)]
    [SerializeField] private float _eraseInfoProjectileDuration = 0.6f;

    [Tooltip("독병 포물선 최대 높이")]
    [Min(0f)]
    [SerializeField] private float _eraseInfoProjectileArcHeight = 1.2f;

    [Tooltip("독병 스프라이트 월드 스케일")]
    [Min(0.01f)]
    [SerializeField] private float _eraseInfoProjectileScale = 4f;

    [Header("전투 — 피해 숫자")]
    [Tooltip("피해량 표시용 DamageNumbersPro 프리팹")]
    [SerializeField] private DamageNumber _damageNumberPrefab;

    [Tooltip("피해 숫자를 대상 앵커에서 얼마나 띄울지")]
    [SerializeField] private Vector3 _damageNumberOffset = new Vector3(0f, 1.1f, 0f);

    [Tooltip("플레이어가 피해를 받을 때 표시되는 숫자 크기")]
    [Min(0.01f)]
    [SerializeField] private float _playerDamageNumberScale = 1f;

    [Tooltip("적이 피해를 받을 때 표시되는 숫자 크기")]
    [Min(0.01f)]
    [SerializeField] private float _enemyDamageNumberScale = 1f;

    [Tooltip("HP 피해 숫자 색상")]
    [SerializeField] private Color _hpDamageNumberColor = new Color(1f, 0.25f, 0.18f, 1f);

    [Tooltip("방어막에 흡수된 피해 숫자 색상 (시안)")]
    [SerializeField] private Color _blockedDamageNumberColor = new Color(0f, 1f, 1f, 1f);

    [Tooltip("연속 피해 숫자를 어긋나게 배치하는 간격 (월드 단위). 겹침 방지")]
    [SerializeField] private Vector3 _damageNumberStagger = new Vector3(0.35f, 0.2f, 0f);

    [Tooltip("이 시간(초) 안에 스폰된 숫자는 겹침 방지를 위해 어긋나 배치. 지나면 위치 리셋")]
    [Min(0.01f)]
    [SerializeField] private float _damageNumberStaggerWindow = 0.4f;

    [Header("전투 — 체인 텍스트")]
    [Tooltip("체인 ON 표시용 DamageNumbersPro 텍스트 프리팹")]
    [SerializeField] private DamageNumber _chainTextPopupPrefab;

    [Tooltip("체인 텍스트를 카드 위치에서 얼마나 띄울지")]
    [SerializeField] private Vector3 _chainTextPopupOffset = new Vector3(0f, 0.9f, 0f);

    [Tooltip("체인 텍스트 크기")]
    [Min(0.01f)]
    [SerializeField] private float _chainTextPopupScale = 1f;

    [Header("전투 — 체인 신호")]
    [Tooltip("카드 사이를 이동할 1bit 화살표 스프라이트. 비우면 기존 선 연출 사용")]
    [SerializeField] private Sprite _chainSignalSprite;

    [Tooltip("체인 신호 화살표의 월드 크기 배율")]
    [Min(0.01f)]
    [SerializeField] private float _chainSignalScale = 1f;

    [Tooltip("체인 신호 화살표가 도착하는 시간(초)")]
    [Min(0.01f)]
    [SerializeField] private float _chainSignalDuration = 0.18f;

    [Header("전투 — 체인 VFX 가속")]
    [Tooltip("이 Chain까지는 체인 전파 VFX를 기본 속도로 재생")]
    [Min(1)]
    [SerializeField] private int _chainVisualSpeedStartCount = 10;

    [Tooltip("시작 Chain 이후 Chain당 체인 전파 VFX 배속 증가율")]
    [Min(0f)]
    [SerializeField] private float _chainVisualSpeedPerChain = 0.03f;

    [Tooltip("체인 전파 VFX의 최종 최소 재생 시간(초)")]
    [Min(0f)]
    [SerializeField] private float _chainVisualMinimumDuration = 0.05f;

    [Header("전투 — 체인 카드 활성음")]
    [Tooltip("첫 번째 ON 카드에 적용할 체인 활성음 피치 배율")]
    [Range(0.1f, 3f)]
    [SerializeField] private float _chainActivationBasePitch = 0.9f;

    [Tooltip("ON 카드가 하나 늘어날 때마다 더할 피치 배율")]
    [Range(0f, 0.1f)]
    [SerializeField] private float _chainActivationPitchPerCard = 0.01f;

    [Tooltip("체인 활성음 피치 배율의 최댓값")]
    [Range(0.1f, 3f)]
    [SerializeField] private float _chainActivationMaxPitch = 1.6f;

    [Header("전투 — Chain 보너스 공격")]
    [Tooltip("Chain 증가 시 마법진 Progress가 새 목표값을 따라가는 시간(초)")]
    [Min(0.01f)]
    [SerializeField] private float _chainMagicCircleProgressDuration = 0.15f;

    [Tooltip("한 번의 체인에서 ON 된 카드 순번이 지정 Chain에 도달하면 플레이어가 추가 공격")]
    [SerializeField]
    private ChainMilestoneAttackSetting[] _chainMilestoneAttacks =
    {
        new ChainMilestoneAttackSetting(10, 10, 1, false, "LaserRoot", 1f, 1f, 1f, 1f),
        new ChainMilestoneAttackSetting(30, 10, 3, false, "LaserRoot", 1.2f, 1f, 1.05f, 1.05f),
        new ChainMilestoneAttackSetting(50, 10, 5, false, "LaserRoot", 1.5f, 1f, 1.1f, 1.1f),
        new ChainMilestoneAttackSetting(70, 10, 7, false, "LaserRoot", 1.8f, 1f, 1.15f, 1.15f),
        new ChainMilestoneAttackSetting(100, 0, 10, true, "LaserRoot", 3f, 1f, 1.2f, 1.2f),
    };

    [Header("전투 — 캐스팅 연출")]
    [Tooltip("캐스팅 대기 상태를 플레이어 주변에 표시할 월드 프리팹")]
    [SerializeField] private CastingOrbView _castingOrbPrefab;

    [Tooltip("CardID별 캐스팅 오브 프리팹 매핑. 미등록 카드는 기본 프리팹 사용")]
    [SerializeField] private CastingOrbVisualSet _castingOrbVisualSet;

    [Tooltip("플레이어 기준 캐스팅 오브젝트 원형 배치 반지름")]
    [Min(0.1f)]
    [SerializeField] private float _castingOrbRadius = 1.35f;

    [Tooltip("플레이어 기준 캐스팅 오브젝트 중심 높이")]
    [SerializeField] private float _castingOrbHeightOffset = 0.65f;

    [Header("전투 객체 프리팹 (World 풀 생성)")]
    [Tooltip("플레이어 대표 객체 프리팹 (Player + 자식 PlayerView)")]
    [SerializeField] private Player _playerPrefab;

    [Tooltip("적 대표 객체 프리팹 (Enemy 파생 + 자식 EnemyView). 층마다 Spawn/Despawn")]
    [SerializeField] private Enemy _enemyPrefab;

    [Tooltip("플레이어 객체가 놓일 월드 위치 (비우면 원점)")]
    [SerializeField] private Transform _playerAnchor;

    [Tooltip("적 객체가 놓일 월드 위치 (비우면 원점)")]
    [SerializeField] private Transform _enemyAnchor;

    [Header("전투 배경")]
    [Tooltip("BattleStartContext에 배경 키가 없을 때 사용할 기본 Addressable 키")]
    [SerializeField] private string _battleBgKey = "BattleBg";

    [Tooltip("배경 오브젝트가 놓일 부모/위치 (비우면 루트). 보통 그리드보다 뒤쪽 정렬")]
    [SerializeField] private Transform _battleBgAnchor;

    [Header("전투 진입 연출")]
    [Tooltip("페이드가 걷힌 뒤 적이 등장하기 전까지 걷는 시간(초)")]
    [Min(0f)]
    [SerializeField] private float _encounterWalkDuration = 1f;

    [Tooltip("적이 등장할 카메라 우측 경계 바깥 여유 거리(m)")]
    [Min(0f)]
    [SerializeField] private float _enemySpawnRightOffset = 1f;

    // ── UIBattle 에서 수령하는 씬 참조 (인스펙터 X — 동적 생성 UI 자식) ──
    private UICardHand _cardHand;
    private CardPlacementInput _placementController;

    // ── 전투 대표 객체 (World 풀 생성) ──────────────────────
    private Player _playerObj;   // 플레이어 대표 객체 (PlayerActor + PlayerView 소유)
    private Enemy _enemyObj;      // 적 대표 객체 (EnemyActor + EnemyView 소유). 층마다 교체
    private EnemyView _runtimeEnemyView; // EnemyDataSO.ViewPrefabKey 로 생성한 SO별 비주얼
    private GameObject _runtimeEnemyViewObj;
    private string _runtimeEnemyViewKey;
    private GameObject _battleBgObj; // 전투 배경 인스턴스 (ResourceManager.InstantiateAsync 로 생성)
    private BattleBackgroundParallaxScroller _battleBgScroller;
    private string _loadedBattleBgKey;
    private SimplePoolable _blindPoisonVfx;
    private CancellationTokenSource _blindPoisonVfxLoadCts;
    private bool _bossPhaseVfxPoolsPrepared;
    private bool _hasBossPhaseAbsorptionTask;
    private UniTask _bossPhaseAbsorptionTask;
    private PoolableMonoBehaviour _bossPhaseDarkOrb;
    private Tween _bossPhaseDarkTween;
    private readonly List<PoolableMonoBehaviour> _bossPhaseShadowOrbs =
        new List<PoolableMonoBehaviour>(8);
    private readonly Dictionary<int, BossPhaseAudioEntry> _bossPhaseAudioEntries =
        new Dictionary<int, BossPhaseAudioEntry>();
    private AudioClip _pendingBossPhaseBgmClip;
    private int _pendingBossPhaseBgmIndex = -1;

    // 페이즈 전환을 시작한 순간의 이전 페이즈 BGM 재생 위치(초).
    // 다음 페이즈 곡을 여기서 이어 시작해 마디가 어긋나지 않게 한다.
    private float _pendingBossPhaseBgmStartTime;

    private sealed class BossPhaseAudioEntry
    {
        public string BgmKey;
        public AudioClip BgmClip;
        public string AbsorbSfxKey;
        public AudioClip AbsorbSfxClip;
    }

    // ── 전투 시스템 (조립으로 생성) ─────────────────────────
    private DeckSystem _deckSystem;
    private PlayerActor _player;
    private EnemyActor _enemy;
    private EnemyTurnHandler _enemyHandler;
    private EnemyEliteBuffController _eliteBuffController;
    private TargetResolver _targetResolver;
    private BattleVfxPresenter _vfxPresenter;
    private CardPhaseDispatcher _dispatcher;
    private CardStatCalculator _calculator;
    private ChainExecutor _chain;
    private BattleReactiveEventBus _reactiveEvents;
    private ReactiveToggleQueue _reactiveToggleQueue;
    private int _lastReactiveEnergy;
    // GridLineAttack 의도의 Amount(자를 라인 수)만큼 미리 뽑아둔 라인 계획들. 예고와 실행이 공유.
    private readonly List<GridLineAttackPlan> _currentLineAttackPlans = new List<GridLineAttackPlan>(4);
    private readonly List<GridSlot> _lineAttackSlots = new List<GridSlot>(8);

    // Addressable 로 생성한 매니저 인스턴스 (해제용 참조).
    private GridManager _grid;
    private BattleManager _battle;

    // ── 전투 입력 (InGameController 가 BattleStartContext 로 주입) ──
    // ★ RunContext/StageProvider/시드맵을 보유하지 않는다 (Run Flow 분리).
    //   이번 전투의 적 데이터만 보관 (적 셋업·재셋업용).
    private EnemyDataSO _currentEnemyData;
    private BattleStartContext _currentContext;
    private bool _isTutorialEnemyEscapeVictory;

    /// <summary>전투 진행 중 여부.</summary>
    public bool IsBattleRunning { get; private set; }

    /// <summary>현재 플레이어 체력 (전투 종료 시 생존 HP 회수용). 미조립이면 0.</summary>
    public int PlayerCurrentHp => _player != null ? _player.Hp : 0;

    /// <summary>현재 플레이어 최대 체력. 미조립이면 0.</summary>
    public int PlayerMaxHp => _player != null ? _player.MaxHp : 0;

    /// <summary>QA 커맨드가 플레이어 체력을 직접 차감하는 양 (방어막 무시).</summary>
    private const int DEBUG_HP_REDUCE_AMOUNT = 3;

    /// <summary>현재 드로우 더미 카드 수. 미조립이면 0.</summary>
    public int DrawPileCount => _deckSystem != null ? _deckSystem.DrawCount : 0;

    /// <summary>현재 버린 더미(묘지) 카드 수. 미조립이면 0.</summary>
    public int DiscardPileCount => _deckSystem != null ? _deckSystem.DiscardCount : 0;

    /// <summary>
    /// 더미 구성(드로우·묘지·소멸)이 변해 UI 카운터 갱신이 필요할 때 발생.
    /// DeckSystem.OnPilesChanged 를 외부(UIBattle)로 중계한다 — DeckSystem 은 private 이므로 직접 구독 불가.
    /// </summary>
    public event Action OnPilesChanged;

    public bool TryDebugFullHeal()
    {
        if (!DebugCommandManager.CanExecuteDomain(EDebugCommand.FullHeal)) return false;
        if (!IsBattleRunning || _player == null || !_player.IsAlive) return false;
        _player.Heal(_player.MaxHp - _player.Hp);
        return true;
    }

    public bool TryDebugDamagePlayer(out int amount)
    {
        amount = DEBUG_HP_REDUCE_AMOUNT;
        if (!DebugCommandManager.CanExecuteDomain(EDebugCommand.DamagePlayer)) return false;
        if (!IsBattleRunning || _player == null || !_player.IsAlive) return false;
        _player.DebugReduceHp(amount);
        Debug.Log($"[DebugCommand] 플레이어 체력 -{amount}");
        return true;
    }

    public bool TryDebugKillEnemy()
    {
        if (!DebugCommandManager.CanExecuteDomain(EDebugCommand.KillEnemy)) return false;
        if (!IsBattleRunning || _enemy == null || !_enemy.IsAlive) return false;
        _enemy.TakeDamage(_enemy.Hp + _enemy.Block);
        return true;
    }

    public bool TryDebugGainMana(int amount)
    {
        if (!DebugCommandManager.CanExecuteDomain(EDebugCommand.GainMana)) return false;
        if (!CanRunPlayerInputDebugCommand() || amount <= 0) return false;
        _player.GainEnergy(amount);
        return true;
    }

    public bool TryDebugDrawCards(int count)
    {
        if (!DebugCommandManager.CanExecuteDomain(EDebugCommand.DrawCard)) return false;
        if (!CanRunPlayerInputDebugCommand() || count <= 0 || _deckSystem == null) return false;
        _deckSystem.DrawCards(count);
        return true;
    }

    public bool TryDebugMulliganHand()
    {
        if (!DebugCommandManager.CanExecuteDomain(EDebugCommand.MulliganHand)) return false;
        if (!CanRunPlayerInputDebugCommand() || _deckSystem == null) return false;
        _deckSystem.DiscardHand();
        _deckSystem.DrawCards(_activeDrawPerTurn);
        return true;
    }

    private bool CanRunPlayerInputDebugCommand()
        => IsBattleRunning && _battle != null && _battle.IsBattleActive &&
           _battle.CurrentPhase == EBattlePhase.PlayerInput && !_battle.IsProcessing && _player != null;

    /// <summary>현재 드로우 더미 카드 목록 조회. UI 표시용 읽기 전용.</summary>
    public IReadOnlyList<Card> GetDrawPileCards()
    {
        return _deckSystem != null ? _deckSystem.DrawPile : EmptyCards;
    }

    /// <summary>현재 버린 더미 카드 목록 조회. UI 표시용 읽기 전용.</summary>
    public IReadOnlyList<Card> GetDiscardPileCards()
    {
        return _deckSystem != null ? _deckSystem.DiscardPile : EmptyCards;
    }

    /// <summary>현재 소멸 더미 카드 목록 조회. UI 표시용 읽기 전용.</summary>
    public IReadOnlyList<Card> GetExhaustPileCards()
    {
        return _deckSystem != null ? _deckSystem.ExhaustPile : EmptyCards;
    }

    /// <summary>현재 전투의 드로우 더미에 전투 한정 카드를 추가한다.</summary>
    public bool AddTemporaryCardToBattleDeck(
        CardDataSO cardData,
        EBattleDeckOwner owner = EBattleDeckOwner.PlayerTemporary,
        bool upgraded = false)
    {
        if (_deckSystem == null || cardData == null || owner == EBattleDeckOwner.RunDeck)
        {
            return false;
        }

        Card card = CardFactory.CreateFromSO(cardData, upgraded);
        if (card == null) return false;

        _deckSystem.AddCardToDrawPileAndShuffle(card, owner);
        return true;
    }

    /// <summary>현재 전투 카드들을 출처별로 조회한다.</summary>
    public void GetBattleCardsByOwner(EBattleDeckOwner owner, List<Card> results)
    {
        if (_deckSystem == null)
        {
            results?.Clear();
            return;
        }

        _deckSystem.GetCardsByOwner(owner, results);
    }

    /// <summary>전투 종료 통지 (true=승리). 런 컨트롤러가 구독해 후속 진행.</summary>
    public event Action<bool> OnBattleFinished;

    /// <summary>
    /// 무한루프 감지 중계 이벤트. 인자: (원인 카드, 그리드 좌표).
    /// ChainExecutor는 전투마다 새로 생성되므로, 씬 수명이 안정적인 이 컨트롤러가 중계한다.
    /// 분석 등 외부 시스템이 안정적으로 구독하는 지점.
    /// </summary>
    public event Action<Card, Vector2Int> OnInfiniteLoopDetected;

    /// <summary>한 체인이 끝날 때 그 체인의 피크 활성화 수를 통지한다. 런 통계의 '최대 체인' 집계에 쓴다.</summary>
    public event Action<int> OnChainEnded;

    /// <summary>플레이어 피격 중계 이벤트. 인자: 실제 HP 감소량(방어막 흡수분 제외).</summary>
    public event Action<int> OnPlayerDamageTaken;

    /// <summary>현재 전투에서 적이 실행 중인 의도(Intent) 종류. 사망 원인 기록용. 없으면 빈 문자열.</summary>
    public string CurrentEnemyIntent
    {
        get
        {
            IReadOnlyList<EnemyIntent> intents = _enemyHandler?.CurrentIntents;
            if (intents == null || intents.Count == 0) return string.Empty;

            int order = Mathf.Clamp(_enemyHandler.CurrentIntentOrder, 0, intents.Count - 1);
            return intents[order].Type.ToString();
        }
    }

    private CancellationTokenSource _cts;
    private bool _assembled;
    private string _currentBattleId = string.Empty;
    private int _battleSequence;
    private float _battleStartedAt;
    private int _lastEnemyTurn;
    private int _battlePlaceCount;
    private int _damageDealtBattle;
    private int _damageTakenBattle;
    private readonly GameObject[] _chainMagicCircleObjects = new GameObject[ChainMagicCircleEndCounts.Length];
    private readonly SpriteMagicCircleReveal[] _chainMagicCircleReveals =
        new SpriteMagicCircleReveal[ChainMagicCircleEndCounts.Length];

    // 카드 더미 조회용 빈 배열 (null 대신 반환 — 호출부 NRE 방지).
    private static readonly IReadOnlyList<Card> EmptyCards = System.Array.Empty<Card>();
    private const string NoDrawableCardKey = "UI_BATTLE_NO_DRAWABLE_CARD";

    public string CurrentBattleId => _currentBattleId;
    public int LastBattleTurnCount => _lastEnemyTurn;

    /// <summary>
    /// 이번 전투가 보스전인지 (적 데이터의 등급 기준).
    /// 스테이지 순서에 의존하지 않으므로 스테이지가 추가·재배치돼도 판정이 깨지지 않는다.
    /// </summary>
    public bool IsBossBattle =>
        _currentEnemyData != null && _currentEnemyData.Grade == EEnemyGrade.Boss;

    /// <summary>튜토리얼 적을 우측 화면 밖으로 퇴장시킨 뒤 사망 연출 없이 승리 처리한다.</summary>
    public async UniTask<bool> PlayTutorialEnemyEscapeVictoryAsync(
        float duration,
        CancellationToken token = default)
    {
        if (_battle == null || !_battle.IsBattleActive)
            return false;

        Transform enemyTransform = _enemyObj != null ? _enemyObj.transform : null;
        if (enemyTransform != null)
        {
            Camera camera = CameraManager.HasInstance ? CameraManager.Instance.MainCamera : Camera.main;
            float targetX = enemyTransform.position.x + Mathf.Max(1f, _enemySpawnRightOffset);
            if (camera != null && camera.orthographic)
            {
                targetX = camera.transform.position.x
                    + camera.orthographicSize * camera.aspect
                    + Mathf.Max(0f, _enemySpawnRightOffset);
            }

            float moveDuration = Mathf.Max(0.01f, duration);
            Tween exitTween = enemyTransform
                .DOMoveX(targetX, moveDuration)
                .SetEase(Ease.InQuad)
                .SetUpdate(true)
                .SetTarget(enemyTransform);
            await exitTween.AsUniTask(token);
        }

        if (token.IsCancellationRequested || _battle == null || !_battle.IsBattleActive)
            return false;

        _isTutorialEnemyEscapeVictory = true;
        _battle.NotifyEnemyDefeated();
        return true;
    }

    // 디스카드 연출 추적 (턴 해결 시 완료 대기용).
    private readonly List<UniTaskCompletionSource> _pendingDiscardAnimations = new List<UniTaskCompletionSource>(16);
    private readonly List<Card> _cardScratch = new List<Card>(64);

    // ─────────────────────────────────────────────
    // 공개 진입점 (런 컨트롤러가 호출)
    // ─────────────────────────────────────────────

    /// <summary>
    /// 화면이 가려진 동안 전투 UI·플레이어·배경·덱을 준비한다.
    /// 적 생성과 실제 전투 시작은 BeginPreparedBattleAsync 에서 수행한다.
    /// </summary>
    /// <param name="context">전투 입력 (덱 ID·적 데이터·시드). InGameController 가 조립.</param>
    /// <param name="token">취소 토큰 (런/씬 이탈).</param>
    public async UniTask<bool> PrepareBattleAsync(BattleStartContext context, CancellationToken token = default)
    {
        if (IsBattleRunning)
        {
            Debug.LogWarning("[BattleController] 이미 전투가 진행 중입니다.");
            return false;
        }
        if (context == null)
        {
            Debug.LogError("[BattleController] BattleStartContext 가 null 입니다. 전투 시작 불가.");
            return false;
        }

        _currentEnemyData = context.EnemyData;
        _currentContext = context;
        _isTutorialEnemyEscapeVictory = false;

        // 전투 BGM은 StageDataSO에서 등급별로 결정되어 컨텍스트로 전달된다.
        if (AudioManager.HasInstance)
        {
            if (string.IsNullOrWhiteSpace(context.BattleBgmKey))
            {
                Debug.LogWarning("[BattleController] StageDataSO 전투 BGM 키가 비어 있어 재생하지 않습니다.");
            }
            else
            {
                // 맵과 같은 곡을 공유하면 AudioManager 가 재생을 유지하고 전투 볼륨으로만 올린다.
                AudioManager.Instance.PlayBgmAsync(
                    context.BattleBgmKey,
                    crossfade: 1f,
                    volume: AudioKeys.BgmVolume.BATTLE,
                    token: token).Forget();
            }
        }

        _battleSequence++;
        string runId = InGameController.HasInstance ? InGameController.Instance.CurrentRunId : string.Empty;
        _currentBattleId = string.IsNullOrEmpty(runId)
            ? $"battle_{_battleSequence}_{DateTime.UtcNow.Ticks}"
            : $"{runId}_battle_{_battleSequence}";
        _battleStartedAt = Time.realtimeSinceStartup;
        _lastEnemyTurn = 0;
        _battlePlaceCount = 0;
        _damageDealtBattle = 0;
        _damageTakenBattle = 0;
        Debug.Assert(ChainMagicCircleEndCounts.Length == ChainMagicCircleKeys.Length,
            "[BattleController] Chain 마법진 구간과 Prefab 키 수가 일치해야 합니다.");
        ReleaseChainMagicCirclesImmediate();

        // 외부 토큰과 자체 토큰을 연결 (씬 이탈·전투 종료 양쪽 대응).
        DisposeCts();
        _cts = token.CanBeCanceled
            ? CancellationTokenSource.CreateLinkedTokenSource(token)
            : new CancellationTokenSource();

        // 0) UIBattle 을 먼저 열고 씬 참조(손패·배치·뷰)를 수령.
        UIBattle battleUI = await OpenBattleUIAsync(_cts.Token);
        if (battleUI == null)
        {
            Debug.LogError("[BattleController] UIBattle 오픈/참조 수령 실패. 전투 시작 중단.");
            return false;
        }
        UIManager.Instance.Close(battleUI);

        // 0-1) 전투 배경 로드 (전투마다 보장. 실패해도 전투는 계속).
        await EnsureBattleBackgroundAsync(context.BattleBackgroundKey, _cts.Token);

        // 다중 페이즈 보스 연출은 전투 시작 전에 풀을 준비해 HP 0 순간의 로드 지연을 막는다.
        await PrepareBossPhaseTransitionVfxPoolsAsync(_cts.Token);
        await PrepareBossPhaseAudioAsync(_cts.Token);

        // 최초 1회만 골격 조립 (Grid/Battle/Player/Deck/Calc/Dispatch).
        if (!_assembled)
        {
            AssembleBattleAsync(_cts.Token);
            if (!_assembled) return false; // 조립 실패
        }

        ApplyGridSizeIfNeeded(context);

        // 1) 그리드 초기화 (이전 전투 잔여 카드 제거 — 매 전투 새 보드).
        _grid?.ClearAllCards();
        _grid?.SetVisible(false);

        // 2) 덱 구성 — 전달받은 덱 ID 로 매 전투 새 Card 생성 (핸드/묘지 리셋).
        // 시드가 있는 전투는 최초 셔플 전에 난수 스트림을 되돌려 재시작 결과를 재현한다.
        // 0은 시드 없는 독립 전투이므로 기존 시간 기반 난수 스트림을 유지한다.
        if (context.ShuffleSeed != 0)
            _deckSystem?.ResetRandom(context.ShuffleSeed);
        BuildDeckFromContext(context);
        _deckSystem?.SetNextTurnStartDrawOrder(context.TutorialFirstDrawCardIds);

        // 2-1) 튜토리얼 전투 전용 선배치. 일반 전투 컨텍스트에서는 실행되지 않는다.
        SeedTutorialGridIfNeeded(context);

        return true;
    }

    /// <summary>준비된 전투의 적을 배치하고 실제 전투 페이즈를 시작한다.</summary>
    public async UniTask<bool> BeginPreparedBattleAsync(
        bool playEncounterIntro,
        CancellationToken token = default)
    {
        if (_currentContext == null || _battle == null || _grid == null || _cts == null)
        {
            Debug.LogError("[BattleController] 준비되지 않은 전투는 시작할 수 없습니다.");
            return false;
        }

        CancellationToken battleToken = _cts.Token;
        if (token.IsCancellationRequested || battleToken.IsCancellationRequested)
        {
            return false;
        }

        BattleStartContext context = _currentContext;
        try
        {
            if (playEncounterIntro)
            {
                await PlayEncounterIntroAsync(context.EnemyData, battleToken);
            }
            else
            {
                Vector3 targetPosition = _enemyAnchor != null ? _enemyAnchor.position : Vector3.zero;
                await SetupEnemyFromContextAsync(context.EnemyData, targetPosition, battleToken);
            }
        }
        catch (OperationCanceledException) when (token.IsCancellationRequested || battleToken.IsCancellationRequested)
        {
            return false;
        }

        if (token.IsCancellationRequested || battleToken.IsCancellationRequested ||
            !ReferenceEquals(_currentContext, context) ||
            _battle == null || _grid == null || _player == null || _enemy == null)
        {
            return false;
        }

        UIBattle battleUI;
        try
        {
            battleUI = await OpenBattleUIAsync(battleToken);
        }
        catch (OperationCanceledException) when (token.IsCancellationRequested || battleToken.IsCancellationRequested)
        {
            return false;
        }

        if (battleUI == null)
        {
            Debug.LogError("[BattleController] UIBattle 재오픈 실패. 전투 시작 중단.");
            return false;
        }

        // UI 로드 await 중 런 종료/씬 이탈로 전투가 해제될 수 있다.
        if (token.IsCancellationRequested || battleToken.IsCancellationRequested ||
            !ReferenceEquals(_currentContext, context) ||
            _battle == null || _grid == null || _player == null || _enemy == null)
        {
            return false;
        }

        // 전투 파라미터 오버라이드 (DTO 에 지정 시 우선, 아니면 인스펙터 기본값).
        int maxHp = context.PlayerMaxHp > 0 ? context.PlayerMaxHp : ConfigMaxHp;
        int maxEnergy = context.PlayerMaxEnergy >= 0 ? context.PlayerMaxEnergy : ConfigMaxEnergy;
        int currentHp = context.PlayerCurrentHp; // 0 이하면 BattleManager 가 풀피 처리
        // 턴 시작 드로우 수: 런 스탯(context) 우선, 없으면 인스펙터 기본값(튜토리얼·아레나 등).
        _activeDrawPerTurn = context.DrawPerTurn >= 0 ? context.DrawPerTurn : ConfigDrawPerTurn;

        if (_cardHand != null)
        {
            _cardHand.Open();
        }

        // 전투 정보 UI(UIBattle)에 액터 바인딩 — HP·방어막·에너지·의도 표시.
        battleUI.BindActors(_player, _enemy);
        battleUI.BindBuffs(_dispatcher);
        battleUI.BindCardInfoHidden(_grid);
        battleUI.BindEnemyEliteBuffs(_eliteBuffController, _enemy);
        battleUI.BindEnemySpeechTarget(ResolveEnemySpeechTarget());

        _grid.SetVisible(true);
        IsBattleRunning = true;

        // 전투 시작 — BattleManager 가 PlayerInput 페이즈로 진입하며
        // HandlePhaseChanged 가 첫 드로우를 트리거한다.
        _battle.SetPreserveConfig(context.Preserve);
        _battle.StartBattle(maxHp, maxEnergy, currentHp);
        _lastReactiveEnergy = _player != null ? _player.Energy : 0;
        ShowEnemySpeech(EEnemySpeechTrigger.BattleStart, enemyTurn: 0, intentOrder: 0);
        return true;
    }

    private void ApplyGridSizeIfNeeded(BattleStartContext context)
    {
        if (context == null || _grid == null)
        {
            return;
        }

        if (context.IsTutorialBattle && context.TutorialGridRows > 0 && context.TutorialGridColumns > 0)
        {
            _grid.SetGridSize(context.TutorialGridRows, context.TutorialGridColumns);
            return;
        }

        if (context.GridRows > 0 && context.GridColumns > 0)
        {
            _grid.SetGridSize(context.GridRows, context.GridColumns);
        }
    }

    private void SeedTutorialGridIfNeeded(BattleStartContext context)
    {
        if (context == null || !context.IsTutorialBattle || _grid == null)
        {
            return;
        }

        IReadOnlyList<BattleStartGridSeedCard> seeds = context.TutorialSeedCards;
        for (int i = 0; i < seeds.Count; i++)
        {
            BattleStartGridSeedCard seed = seeds[i];
            if (seed == null || seed.CardData == null)
            {
                continue;
            }

            Card card = CardFactory.CreateFromSO(seed.CardData, seed.Upgraded);
            if (card == null)
            {
                continue;
            }

            card.SetBattleDeckOwner(EBattleDeckOwner.PlayerTemporary);
            if (!_grid.TryPlaceCard(card, seed.Position))
            {
                Debug.LogWarning($"[BattleController] 튜토리얼 선배치 실패 — {seed.CardData.CardId} @ {seed.Position}");
            }
        }
    }

    // ─────────────────────────────────────────────
    // UIBattle 오픈 + 씬 참조 수령
    // ─────────────────────────────────────────────

    /// <summary>
    /// UIBattle 을 UIManager 로 열고, 그 자식 참조(손패·배치·뷰)를 이 컨트롤러로 수령한다.
    /// 기존엔 BattleManager 가 열었으나(규칙 계층 부적절), 조립 계층인 여기로 책임을 이관.
    /// </summary>
    private async UniTask<UIBattle> OpenBattleUIAsync(CancellationToken token)
    {
        if (!UIManager.HasInstance)
        {
            Debug.LogError("[BattleController] UIManager 가 없습니다.");
            return null;
        }

        UIBattle battleUI = await UIManager.Instance.OpenAsync<UIBattle>(token);
        if (battleUI == null) return null;

        // UIBattle 자식 참조 수령 (동적 생성 null 문제 해결의 핵심).
        _cardHand = battleUI.CardHand;
        _placementController = battleUI.Placement;

        if (_cardHand == null)
        {
            Debug.LogError("[BattleController] UIBattle 에 CardHand 가 없습니다.");
            return null;
        }

        return battleUI;
    }

    private async UniTask PrepareBossPhaseTransitionVfxPoolsAsync(CancellationToken token)
    {
        if (_bossPhaseVfxPoolsPrepared ||
            _currentEnemyData == null ||
            _currentEnemyData.PhaseCount <= 1 ||
            !PoolManager.HasInstance)
        {
            return;
        }

        try
        {
            await PoolManager.Instance.RegisterAsync(_bossPhaseDarkOrbKey, initial: 1, token: token);
            await PoolManager.Instance.RegisterAsync(_bossPhaseShadowOrbKey, initial: 2, token: token);
            _bossPhaseVfxPoolsPrepared = true;
        }
        catch (OperationCanceledException)
        {
            throw;
        }
        catch (Exception ex)
        {
            Debug.LogWarning($"[BattleController] 보스 페이즈 전환 VFX 풀 준비 실패: {ex.Message}");
        }
    }

    private async UniTask PrepareBossPhaseAudioAsync(CancellationToken token)
    {
        ReleaseBossPhaseAudio();

        if (_currentEnemyData == null ||
            _currentEnemyData.PhaseCount <= 1 ||
            !ResourceManager.HasInstance)
        {
            return;
        }

        try
        {
            for (int phaseIndex = 1; phaseIndex < _currentEnemyData.PhaseCount; phaseIndex++)
            {
                // 2페이즈에서 StageDataSO의 공통 P2 곡으로 전환하고,
                // 이후 추가 페이즈에서는 같은 곡을 계속 유지한다.
                string bgmKey = phaseIndex == 1 ? _currentContext?.BossPhase2BgmKey : null;
                string absorbSfxKey = _currentEnemyData.GetPhaseAbsorbSfxKey(phaseIndex);
                if (string.IsNullOrWhiteSpace(bgmKey) && string.IsNullOrWhiteSpace(absorbSfxKey))
                {
                    continue;
                }

                BossPhaseAudioEntry entry = new BossPhaseAudioEntry
                {
                    BgmKey = bgmKey,
                    AbsorbSfxKey = absorbSfxKey,
                };
                // 취소가 중간에 발생해도 이미 로드한 클립을 ReleaseBossPhaseAudio에서 회수할 수 있게
                // 로드 전에 엔트리를 등록한다.
                _bossPhaseAudioEntries[phaseIndex] = entry;

                if (!string.IsNullOrWhiteSpace(bgmKey))
                {
                    entry.BgmClip = await ResourceManager.Instance.LoadAsync<AudioClip>(bgmKey, token);
                }

                if (!string.IsNullOrWhiteSpace(absorbSfxKey))
                {
                    entry.AbsorbSfxClip =
                        await ResourceManager.Instance.LoadAsync<AudioClip>(absorbSfxKey, token);
                }
            }
        }
        catch (OperationCanceledException)
        {
            ReleaseBossPhaseAudio();
            throw;
        }
    }

    private void ReleaseBossPhaseAudio()
    {
        ClearPendingBossPhaseBgm();

        if (ResourceManager.HasInstance)
        {
            foreach (BossPhaseAudioEntry entry in _bossPhaseAudioEntries.Values)
            {
                if (entry.BgmClip != null && !string.IsNullOrWhiteSpace(entry.BgmKey))
                {
                    ResourceManager.Instance.Release<AudioClip>(entry.BgmKey);
                }

                if (entry.AbsorbSfxClip != null && !string.IsNullOrWhiteSpace(entry.AbsorbSfxKey))
                {
                    ResourceManager.Instance.Release<AudioClip>(entry.AbsorbSfxKey);
                }
            }
        }

        _bossPhaseAudioEntries.Clear();
    }

    private void ClearPendingBossPhaseBgm()
    {
        _pendingBossPhaseBgmClip = null;
        _pendingBossPhaseBgmIndex = -1;
        _pendingBossPhaseBgmStartTime = 0f;
    }

    // ─────────────────────────────────────────────
    // 전투 조립 (Composition Root)
    // ─────────────────────────────────────────────

    /// <summary>
    /// 전투 시스템 조립. GridManager/BattleManager 를 Addressable 로 생성(InstantiateAsync)한 뒤,
    /// POCO(Deck/Actor/Resolver/Dispatcher/Chain)를 묶어 주입한다.
    /// 인스턴스화 → 가드 → 조립 순서로 진행해 Addressable 지연 생성에 대응.
    /// </summary>
    private void AssembleBattleAsync(CancellationToken token)
    {
        if (!ResourceManager.HasInstance)
        {
            Debug.LogError("[BattleController] ResourceManager 가 없습니다. 전투 조립 중단.");
            return;
        }

        // 0) GridManager / BattleManager 는 씬에 직접 배치(SceneSingleton).
        //    Addressable 런타임 생성 폐기 → 인스펙터 연결·핸들 관리 부담 제거.
        //    무거운 에셋(데이터·아트)만 DataManager/ResourceManager 가 동적 로딩.
        GridManager grid = GridManager.Instance;
        BattleManager battle = BattleManager.Instance;

        if (grid == null || battle == null)
        {
            Debug.LogError("[BattleController] GridManager/BattleManager 가 씬에 없습니다. " +
                           "인게임 씬에 두 매니저를 배치하세요. 전투 조립 중단.");
            return;
        }

        _grid = grid;
        _battle = battle;

        grid.OnCardInfoHiddenChanged -= HandleCardInfoHiddenChanged;
        grid.OnCardInfoHiddenChanged += HandleCardInfoHiddenChanged;

        grid.Init(); // 슬롯 생성

        // 1) 플레이어 대표 객체 풀 생성 + 셋업 (PlayerActor 소유). 런 내내 1개 유지.
        _playerObj = SpawnPlayerObject();
        _player = _playerObj != null ? _playerObj.Actor : new PlayerActor();
        if (_playerObj == null)
        {
            Debug.LogError("[BattleController] _playerPrefab 미연결 — PlayerActor 폴백 생성(비주얼 없음).");
            _player.Setup(ConfigMaxHp);
        }
        BindPlayerDamageNumber(_player);
        BindPlayerReactiveEvents(_player);

        // 전투 중 HP 변동을 전역 통지로 중계 — 상단 정보바(UINoticeTopInfo)가 전투 밖과 동일한
        // OnPlayerHpChanged 이벤트 하나로 갱신된다. 중복 구독 방지를 위해 해제 후 등록.
        _player.OnHpChanged -= HandlePlayerHpChanged;
        _player.OnHpChanged += HandlePlayerHpChanged;

        // 2) 타겟 해결 (플레이어 1 + 적 1). 적은 SetupEnemyFromContext 에서 SetEnemy 로 주입.
        _targetResolver = new TargetResolver(_player, null);

        // 3) 덱 시스템 (ICardGameService).
        _deckSystem = new DeckSystem();
        _deckSystem.SetEnergyHandler(_player.GainEnergy);
        _deckSystem.SetMaxHandSize(ConfigMaxHandSize);

        // 4) 스탯 계산기 (그리드 집계 합류).
        _calculator = new CardStatCalculator(grid);

        // 5) 연출 프리젠터 — 적 타겟은 층마다 갱신(SetEnemyTarget). 플레이어 타겟은 고정.
        _vfxPresenter = new BattleVfxPresenter(
            resolveCardWorldPos: ResolveCardWorldPosition,
            enemyTarget: null,
            playerTarget: _playerObj != null ? _playerObj.View : null,
            projectileSpeed: _projectileSpeed,
            multiHitProjectileCurveHeight: _multiHitProjectileCurveHeight,
            multiHitProjectileSpeedMultiplier: _multiHitProjectileSpeedMultiplier,
            multiHitProjectileCurveAngle: _multiHitProjectileCurveAngle,
            chainTextPopupPrefab: _chainTextPopupPrefab,
            chainTextPopupOffset: _chainTextPopupOffset,
            chainTextPopupScale: _chainTextPopupScale,
            chainSignalSprite: _chainSignalSprite,
            chainSignalScale: _chainSignalScale,
            chainSignalDuration: _chainSignalDuration,
            chainVisualMinimumDuration: _chainVisualMinimumDuration,
            castingOrbPrefab: _castingOrbPrefab,
            castingOrbVisualSet: _castingOrbVisualSet,
            castingOrbRadius: _castingOrbRadius,
            castingOrbHeightOffset: _castingOrbHeightOffset,
            damageNumberPrefab: _damageNumberPrefab,
            damageNumberOffset: _damageNumberOffset,
            hpDamageNumberColor: _hpDamageNumberColor,
            blockedDamageNumberColor: _blockedDamageNumberColor,
            damageNumberStagger: _damageNumberStagger,
            damageNumberStaggerWindow: _damageNumberStaggerWindow,
            chainActivationBasePitch: _chainActivationBasePitch,
            chainActivationPitchPerCard: _chainActivationPitchPerCard,
            chainActivationMaxPitch: _chainActivationMaxPitch,
            vfxAudioCatalog: _vfxAudioCatalog);

        // 6) 디스패처 (타겟·서비스·계산기·연출 주입).
        _dispatcher = new CardPhaseDispatcher(_targetResolver, _deckSystem, _calculator, grid, _vfxPresenter);

        // 7) 체인 실행기 (그리드·디스패처·프리젠터·시전자).
        _chain = new ChainExecutor(
            grid,
            _dispatcher,
            _vfxPresenter,
            _player,
            chainLoopActivationLimit: ChainFinisherCount, // 피니셔 발동 지점(100)을 무한루프로 판정
            chainVisualSpeedStartCount: _chainVisualSpeedStartCount,
            chainVisualSpeedPerChain: _chainVisualSpeedPerChain,
            chainVisualMinimumDuration: _chainVisualMinimumDuration);
        _chain.OnCardActivatedInChainAsync += HandleChainMilestoneAttackAsync;
        _dispatcher.BindChainExecutor(_chain);

        // 무한루프 감지를 씬 수명 컨트롤러로 중계 (구독자는 전투마다 재구독할 필요가 없다).
        // _chain은 전투마다 새로 만들어지므로 구독 해제는 불필요(참조째 버려진다).
        _chain.OnInfiniteLoopDetected += HandleInfiniteLoopDetected;

        _reactiveEvents = new BattleReactiveEventBus();
        _reactiveToggleQueue = new ReactiveToggleQueue();
        _reactiveToggleQueue.Bind(_chain, grid);
        _deckSystem.SetReactiveEventBus(_reactiveEvents);
        _dispatcher.BindReactiveSystems(_reactiveEvents, _reactiveToggleQueue);

        // 8) 배틀매니저 주입 — 적/적핸들러는 SetupEnemyFromContext 가 SetEnemy 로 채움.
        battle.Initialize(_player, null, null, grid, _chain, _dispatcher, _deckSystem);
        battle.SetEnemyPhaseTransitionStartedHandler(HandleEnemyPhaseTransitionStarted);
        battle.SetEnemyPhaseTransitionHandler(AdvanceEnemyPhaseAsync);

        // 9) 드로우/디스카드 → UI 연출 연결.
        _deckSystem.OnCardDrawn += HandleCardDrawn;
        _deckSystem.OnDrawFailedNoCards += HandleDrawFailedNoCards;
        // 손패 상한 초과로 손에 못 들어온 드로우 카드 — 덱에서 묘지로 바로 날아가는 연출.
        _deckSystem.OnDrawDiscardedHandFull += HandleDrawDiscardedHandFull;
        // 카드가 묘지로 갈 때 손패 UICard 제거 (턴 종료 손패 정리 UI 동기화).
        _deckSystem.OnCardDiscarded += HandleCardDiscarded;
        _deckSystem.OnCardExhausted += HandleCardDiscarded;
        // 더미 개수 변동 → UI 카운터 중계 (_deckSystem 은 전투마다 새로 만들어지므로 해제 불필요).
        _deckSystem.OnPilesChanged += HandlePilesChanged;

        // 11) 페이즈 변화/종료 구독.
        battle.OnPhaseChanged += HandlePhaseChanged;
        battle.OnBattleEnded += HandleBattleEnded;
        battle.OnBeforeEnemyAction += HandleBeforeEnemyAction;
        battle.OnBeforeEnemyActionAsync += HandleBeforeEnemyActionAsync;
        battle.OnCardPlaced += HandleBattleCardPlaced;
        battle.OnCardToggled += HandleBattleCardToggled;
        battle.OnChainEndedAsync += HandleBattleChainEndedAsync;

        _assembled = true;

#if UNITY_EDITOR || DEVELOPMENT_BUILD
        Debug.Log("[BattleController] 전투 조립 완료 (Addressable 생성)");
#endif
    }

    /// <summary>
    /// 전달받은 적 데이터로 이번 전투의 적을 셋업하고, 적에 묶인 시스템들을 갱신한다.
    /// 적은 전투마다 새 EnemyActor 로 생성 → 이전 전투 상태(HP·의도) 오염 없음.
    /// TargetResolver·BattleManager·EnemyView 를 새 적으로 일괄 재연결한다.
    /// 적 결정(시드·층)은 Run Flow(InGameController) 책임 — 여기선 받은 데이터만 셋업.
    /// </summary>
    private async UniTask PlayEncounterIntroAsync(EnemyDataSO enemyData, CancellationToken token)
    {
        Vector3 targetPosition = _enemyAnchor != null ? _enemyAnchor.position : Vector3.zero;
        Camera camera = CameraManager.HasInstance ? CameraManager.Instance.MainCamera : Camera.main;

        if (_battleBgScroller == null || camera == null || !camera.orthographic)
        {
            Debug.LogWarning("[BattleController] 조우 연출용 패럴랙스 또는 Orthographic 카메라가 없어 적을 기존 위치에 배치합니다.");
            await SetupEnemyFromContextAsync(enemyData, targetPosition, token);
            return;
        }

        _battleBgScroller.Resume();
        if (_battleBgScroller.ActiveSpeed <= 0f)
        {
            Debug.LogWarning("[BattleController] 패럴랙스 속도가 0이라 조우 이동을 생략합니다.");
            await SetupEnemyFromContextAsync(enemyData, targetPosition, token);
            return;
        }

        PlayerView playerView = _playerObj != null ? _playerObj.View : null;
        playerView?.PlayWalkAnimation();

        try
        {
            if (_encounterWalkDuration > 0f)
            {
                await UniTask.Delay(
                    TimeSpan.FromSeconds(_encounterWalkDuration),
                    cancellationToken: token);
            }

            Vector3 spawnPosition = targetPosition;
            float cameraRightEdge = camera.transform.position.x + camera.orthographicSize * camera.aspect;
            spawnPosition.x = Mathf.Max(
                cameraRightEdge + _enemySpawnRightOffset,
                targetPosition.x + _enemySpawnRightOffset);

            await SetupEnemyFromContextAsync(enemyData, spawnPosition, token);

            while (_battleBgScroller != null && _enemyObj != null &&
                   !Mathf.Approximately(_enemyObj.transform.position.x, targetPosition.x))
            {
                float speed = _battleBgScroller.ActiveSpeed;
                if (speed <= 0f)
                {
                    Debug.LogWarning("[BattleController] 적 접근 중 패럴랙스가 정지해 남은 이동을 생략합니다.");
                    break;
                }

                _enemyObj.transform.position = Vector3.MoveTowards(
                    _enemyObj.transform.position,
                    targetPosition,
                    speed * Time.deltaTime);
                await UniTask.Yield(PlayerLoopTiming.Update, token);
            }

            if (_enemyObj != null)
            {
                _enemyObj.transform.position = targetPosition;
            }
        }
        finally
        {
            // 적 에셋 로드 await 동안 전투가 정리되면(ReleaseBattleBackground) _battleBgScroller가 null이 될 수 있다.
            if (_battleBgScroller != null)
                _battleBgScroller.Stop();
            playerView?.PlayIdleAnimation();
        }
    }

    private async UniTask SetupEnemyFromContextAsync(
        EnemyDataSO enemyData,
        Vector3 spawnPosition,
        CancellationToken token)
    {
        // DTO 적이 없으면 인스펙터 폴백 (그것도 없으면 더미).
        if (enemyData == null) enemyData = _enemyData;
        _currentEnemyData = enemyData;

        // 이전 적 객체 풀 반환 (전투 교체).
        UnbindEnemyDamageNumber();
        _enemyHandler?.SetEliteBuffController(null);
        _eliteBuffController?.Dispose();
        _eliteBuffController = null;
        DespawnEnemyObject();

        // 새 적 대표 객체 풀 생성 + 셋업 (Enemy 가 EnemyActor·Handler 소유·구성).
        _enemyObj = SpawnEnemyObject(spawnPosition);
        if (_enemyObj != null)
        {
            _enemyObj.Setup(enemyData, grid: _grid);
            await ApplyEnemyViewFromDataAsync(enemyData, 0, token);

            _enemy = _enemyObj.Actor;
            _enemyHandler = _enemyObj.Handler as EnemyTurnHandler;

            // 연출 적 타겟 갱신 (이 적 View 로 투사체 종착).
            _vfxPresenter?.SetEnemyTarget(_enemyObj.View);
        }
        else
        {
            // 폴백: 프리팹 미연결 시 데이터만 (비주얼 없음).
            Debug.LogWarning("[BattleController] _enemyPrefab 미연결 — 적이 데이터로만 존재(비주얼 없음).");
            _enemy = new EnemyActor(enemyData);
            _enemy.Setup(enemyData != null ? enemyData.MaxHp : 1);
            _enemyHandler = new EnemyTurnHandler(_enemy, grid: _grid);
        }
        _enemyHandler?.SetGridLineAttackHandler(ExecuteGridLineAttackAsync);
        _enemyHandler?.SetEraseInfoHandler(ExecuteEraseInfoVfxAsync);
        _enemyHandler?.SetAttackMotionHandler(PlayEnemyAttackMotionAsync);
        BindEliteBuffController();
        BindEnemyDamageNumber(_enemy);

        // 적에 의존하는 시스템 갱신.
        _targetResolver?.SetEnemy(_enemy);
        _battle?.SetEnemy(_enemy, _enemyHandler);

#if UNITY_EDITOR || DEVELOPMENT_BUILD
        string id = enemyData != null ? enemyData.EnemyId : "(폴백 더미)";
        Debug.Log($"[BattleController] 적 셋업 — {id}");
#endif
    }

    /// <summary>EnemyDataSO 의 ViewPrefabKey 로 SO별 적 비주얼을 EnemyPos 에 생성한다.</summary>
    private void BindEliteBuffController()
    {
        _enemyHandler?.SetEliteBuffController(null);
        _eliteBuffController?.Dispose();
        _eliteBuffController = null;

        if (_enemy == null || _enemyHandler == null || _player == null || _deckSystem == null || _battle == null)
        {
            return;
        }

        _eliteBuffController = new EnemyEliteBuffController(
            _enemy,
            _player,
            _deckSystem,
            _battle,
            count => _enemyHandler?.InstallManaDisturbanceCards(count),
            PlayEnemyAttackMotionAsync);
        _enemyHandler.SetEliteBuffController(_eliteBuffController);
    }

    private void HandleEnemyPhaseTransitionStarted(CancellationToken token)
    {
        ClearBossPhaseTransitionVfx();
        ClearPendingBossPhaseBgm();

        AudioClip absorbSfxClip = null;
        int nextPhaseIndex = _enemy != null ? _enemy.CurrentPhaseIndex + 1 : -1;
        if (nextPhaseIndex > 0 &&
            _bossPhaseAudioEntries.TryGetValue(nextPhaseIndex, out BossPhaseAudioEntry audioEntry))
        {
            // 다음 곡이 실제로 준비된 경우에만 현재 BGM을 줄인다.
            // 키가 비었거나 Addressable 로드에 실패했다면 현재 곡을 그대로 유지한다.
            if (audioEntry.BgmClip != null)
            {
                _pendingBossPhaseBgmClip = audioEntry.BgmClip;
                _pendingBossPhaseBgmIndex = nextPhaseIndex;
                if (AudioManager.HasInstance)
                {
                    // 다음 페이즈 곡이 같은 트랙의 변주(피치·베이스만 다른 버전)라는 전제로,
                    // 정지 직전의 재생 위치를 기억해 두었다가 그 지점부터 이어 재생한다.
                    // 처음부터 다시 틀면 마디가 어긋나 "다른 곡으로 갈아탔다"처럼 들린다.
                    _pendingBossPhaseBgmStartTime = _bossPhaseBgmKeepsPlaybackPosition
                        ? AudioManager.Instance.BgmPlaybackTime
                        : 0f;
                    AudioManager.Instance.StopBgm(_bossPhaseBgmFadeOutDuration);
                }
            }

            absorbSfxClip = audioEntry.AbsorbSfxClip;
        }

        if (_bossPhaseShakeForce > 0f && CameraManager.HasInstance)
        {
            CameraManager.Instance.Shake(
                _bossPhaseShakeForce,
                BattleSpeedUtility.ScaleDuration(_bossPhaseShakeDuration));
        }

        Transform anchor = _enemyObj != null && _enemyObj.View != null
            ? _enemyObj.View.AnchorTransform
            : _enemyAnchor;
        if (anchor == null)
        {
            return;
        }

        // 실제 흡수 VFX를 시작하는 순간, 해당 보스/페이즈에 지정된 SFX를 재생한다.
        if (absorbSfxClip != null && AudioManager.HasInstance)
        {
            AudioManager.Instance.PlaySfx(absorbSfxClip);
        }

        _bossPhaseAbsorptionTask = PlayBossPhaseAbsorptionAsync(anchor.position, token);
        _hasBossPhaseAbsorptionTask = true;
    }

    private async UniTask PlayBossPhaseAbsorptionAsync(Vector3 center, CancellationToken token)
    {
        if (!PoolManager.HasInstance || string.IsNullOrWhiteSpace(_bossPhaseDarkOrbKey))
        {
            return;
        }

        try
        {
            PoolableMonoBehaviour darkOrb = await PoolManager.Instance.SpawnAsync(
                _bossPhaseDarkOrbKey,
                center,
                Quaternion.identity,
                token: token);
            if (darkOrb == null)
            {
                Debug.LogWarning($"[BattleController] 보스 페이즈 Dark Orb 생성 실패: {_bossPhaseDarkOrbKey}");
                return;
            }

            _bossPhaseDarkOrb = darkOrb;
            SetupBossPhaseOrb(
                darkOrb,
                center,
                _bossPhaseDarkStartScale,
                BossPhaseDarkSortingOrder);

            float absorbDuration = Mathf.Max(
                0.01f,
                BattleSpeedUtility.ScaleDuration(_bossPhaseAbsorbDuration));
            float spawnInterval = Mathf.Max(
                0.01f,
                BattleSpeedUtility.ScaleDuration(_bossPhaseShadowSpawnInterval));
            float travelDuration = Mathf.Min(
                absorbDuration,
                Mathf.Max(0.01f, BattleSpeedUtility.ScaleDuration(_bossPhaseShadowTravelDuration)));
            float spawnWindow = Mathf.Max(0f, absorbDuration - travelDuration);
            int spawnCount = Mathf.Max(
                1,
                Mathf.FloorToInt(spawnWindow / spawnInterval + 0.0001f) + 1);

            Transform darkTransform = darkOrb.transform;
            _bossPhaseDarkTween = darkTransform
                .DOScale(Vector3.one * Mathf.Max(0.01f, _bossPhaseDarkMaxScale), absorbDuration)
                .SetEase(Ease.OutQuad)
                .SetTarget(darkTransform);

            List<UniTask> shadowTasks = new List<UniTask>(spawnCount);
            for (int i = 0; i < spawnCount; i++)
            {
                if (i > 0)
                {
                    await UniTask.Delay(
                        TimeSpan.FromSeconds(spawnInterval),
                        cancellationToken: token);
                }

                float radians = UnityEngine.Random.Range(0f, 360f) * Mathf.Deg2Rad;
                float shadowScale = UnityEngine.Random.Range(1f, 2f);
                Vector3 spawnPosition = center + new Vector3(
                    Mathf.Cos(radians),
                    Mathf.Sin(radians),
                    0f) * Mathf.Max(0.1f, _bossPhaseShadowSpawnRadius);
                shadowTasks.Add(PlayBossPhaseShadowOrbAsync(
                    spawnPosition,
                    center,
                    shadowScale,
                    travelDuration,
                    token));
            }

            await UniTask.WhenAll(shadowTasks);
            await _bossPhaseDarkTween.AsUniTask(token);
            _bossPhaseDarkTween = null;
        }
        catch (OperationCanceledException)
        {
            ClearBossPhaseTransitionVfx();
            throw;
        }
        catch (Exception ex)
        {
            Debug.LogWarning($"[BattleController] 보스 페이즈 흡수 연출 실패: {ex.Message}");
            ClearBossPhaseTransitionVfx();
        }
    }

    private async UniTask PlayBossPhaseShadowOrbAsync(
        Vector3 spawnPosition,
        Vector3 center,
        float scale,
        float travelDuration,
        CancellationToken token)
    {
        if (!PoolManager.HasInstance || string.IsNullOrWhiteSpace(_bossPhaseShadowOrbKey))
        {
            return;
        }

        PoolableMonoBehaviour shadowOrb = null;
        Sequence sequence = null;
        try
        {
            shadowOrb = await PoolManager.Instance.SpawnAsync(
                _bossPhaseShadowOrbKey,
                spawnPosition,
                Quaternion.identity,
                token: token);
            if (shadowOrb == null)
            {
                Debug.LogWarning($"[BattleController] 보스 페이즈 Shadow Orb 생성 실패: {_bossPhaseShadowOrbKey}");
                return;
            }

            _bossPhaseShadowOrbs.Add(shadowOrb);
            SetupBossPhaseOrb(
                shadowOrb,
                spawnPosition,
                scale,
                BossPhaseShadowSortingOrder);

            Transform orbTransform = shadowOrb.transform;
            sequence = DOTween.Sequence()
                .Join(orbTransform.DOMove(center, travelDuration).SetEase(Ease.InQuad))
                .Join(orbTransform.DOScale(Vector3.zero, travelDuration).SetEase(Ease.InQuad))
                .SetTarget(orbTransform);
            await sequence.AsUniTask(token);
        }
        catch (OperationCanceledException)
        {
            throw;
        }
        catch (Exception ex)
        {
            Debug.LogWarning($"[BattleController] 보스 페이즈 Shadow Orb 연출 실패: {ex.Message}");
        }
        finally
        {
            sequence?.Kill();
            _bossPhaseShadowOrbs.Remove(shadowOrb);
            ReleaseBossPhaseOrb(shadowOrb);
        }
    }

    private static void SetupBossPhaseOrb(
        PoolableMonoBehaviour orb,
        Vector3 position,
        float scale,
        int sortingOrder)
    {
        if (orb == null) return;

        Transform orbTransform = orb.transform;
        orbTransform.DOKill();
        orbTransform.SetPositionAndRotation(position, Quaternion.identity);
        orbTransform.localScale = Vector3.one * Mathf.Max(0.01f, scale);

        Renderer[] renderers = orb.GetComponentsInChildren<Renderer>(includeInactive: true);
        for (int i = 0; i < renderers.Length; i++)
        {
            Renderer renderer = renderers[i];
            if (renderer == null) continue;

            renderer.sortingLayerName = BossPhaseSortingLayerName;
            renderer.sortingOrder = sortingOrder;
        }

        ParticleSystem[] particles = orb.GetComponentsInChildren<ParticleSystem>(includeInactive: true);
        for (int i = 0; i < particles.Length; i++)
        {
            ParticleSystem particle = particles[i];
            if (particle == null) continue;

            particle.Clear(withChildren: false);
            particle.Play(withChildren: false);
        }
    }

    private async UniTask WaitForBossPhaseAbsorptionAsync(CancellationToken token)
    {
        if (!_hasBossPhaseAbsorptionTask)
        {
            return;
        }

        UniTask absorptionTask = _bossPhaseAbsorptionTask;
        _hasBossPhaseAbsorptionTask = false;
        await absorptionTask.AttachExternalCancellation(token);
    }

    private async UniTask CollapseBossPhaseDarkOrbAsync(CancellationToken token)
    {
        PoolableMonoBehaviour darkOrb = _bossPhaseDarkOrb;
        if (darkOrb == null)
        {
            return;
        }

        Transform darkTransform = darkOrb.transform;
        _bossPhaseDarkTween?.Kill();
        _bossPhaseDarkTween = darkTransform
            .DOScale(Vector3.zero, Mathf.Max(
                0.01f,
                BattleSpeedUtility.ScaleDuration(_bossPhaseDarkCollapseDuration)))
            .SetEase(Ease.InQuad)
            .SetTarget(darkTransform);

        try
        {
            await _bossPhaseDarkTween.AsUniTask(token);
        }
        finally
        {
            _bossPhaseDarkTween?.Kill();
            _bossPhaseDarkTween = null;
            if (_bossPhaseDarkOrb == darkOrb)
            {
                _bossPhaseDarkOrb = null;
            }
            ReleaseBossPhaseOrb(darkOrb);
        }
    }

    private async UniTask PlayBossPhaseScreenRippleAsync(
        Vector3 worldPosition,
        CancellationToken token)
    {
        if (_bossPhaseScreenRipple == null)
        {
            Debug.LogWarning("[BattleController] 보스 페이즈 화면 충격파 참조가 없어 연출을 생략합니다.");
            return;
        }

        Camera camera = CameraManager.HasInstance ? CameraManager.Instance.MainCamera : Camera.main;
        if (camera == null)
        {
            Debug.LogWarning("[BattleController] Main Camera가 없어 보스 페이즈 화면 충격파를 생략합니다.");
            return;
        }

        Vector3 viewportPosition = camera.WorldToViewportPoint(worldPosition);
        if (viewportPosition.z <= 0f)
        {
            Debug.LogWarning("[BattleController] Dark Orb가 카메라 뒤에 있어 화면 충격파를 생략합니다.");
            return;
        }

        await _bossPhaseScreenRipple.PlayAtViewportPositionAsync(
            new Vector2(
                Mathf.Clamp01(viewportPosition.x),
                Mathf.Clamp01(viewportPosition.y)),
            BattleSpeedUtility.Multiplier,
            token);
    }

    private void ClearBossPhaseTransitionVfx()
    {
        _hasBossPhaseAbsorptionTask = false;
        _bossPhaseDarkTween?.Kill();
        _bossPhaseDarkTween = null;

        for (int i = _bossPhaseShadowOrbs.Count - 1; i >= 0; i--)
        {
            ReleaseBossPhaseOrb(_bossPhaseShadowOrbs[i]);
        }
        _bossPhaseShadowOrbs.Clear();

        PoolableMonoBehaviour darkOrb = _bossPhaseDarkOrb;
        _bossPhaseDarkOrb = null;
        ReleaseBossPhaseOrb(darkOrb);
    }

    private static void ReleaseBossPhaseOrb(PoolableMonoBehaviour orb)
    {
        if (orb == null) return;

        orb.transform.DOKill();
        ParticleSystem[] particles = orb.GetComponentsInChildren<ParticleSystem>(includeInactive: true);
        for (int i = 0; i < particles.Length; i++)
        {
            ParticleSystem particle = particles[i];
            if (particle != null)
            {
                particle.Stop(
                    withChildren: false,
                    stopBehavior: ParticleSystemStopBehavior.StopEmittingAndClear);
            }
        }

        if (PoolManager.HasInstance && PoolManager.Instance.IsPooledInstance(orb.gameObject))
        {
            PoolManager.Instance.Despawn(orb);
        }
        else
        {
            Destroy(orb.gameObject);
        }
    }

    private async UniTask<bool> AdvanceEnemyPhaseAsync(CancellationToken token)
    {
        await UniTask.WhenAll(
            WaitForBossPhaseAbsorptionAsync(token),
            HideAndReleaseChainMagicCirclesAsync(token));
        if (token.IsCancellationRequested) return false;

        _playerObj?.View?.ResetEffectAnimation();
        _vfxPresenter?.ResetChainTextPopupCount();
        ResetChainCountAndReportPeak();

        bool advanced = _enemyObj != null
            ? _enemyObj.TryAdvancePhase()
            : _enemy != null && _enemy.TryAdvancePhase();
        if (!advanced)
        {
            ClearBossPhaseTransitionVfx();
            ClearPendingBossPhaseBgm();
            return false;
        }

        UIBattle battleUI = UIManager.HasInstance ? UIManager.Instance.Get<UIBattle>() : null;
        battleUI?.RefreshEnemyBossPhaseBuff();

        int phaseIndex = _enemy.CurrentPhaseIndex;
        await ApplyEnemyViewFromDataAsync(_currentEnemyData, phaseIndex, token);
        if (token.IsCancellationRequested) return false;

        EnemyView view = _enemyObj != null ? _enemyObj.View : null;
        _vfxPresenter?.SetEnemyTarget(view);

        battleUI?.BindEnemySpeechTarget(ResolveEnemySpeechTarget());

        bool hasRippleCenter = _bossPhaseDarkOrb != null;
        Vector3 rippleWorldPosition = hasRippleCenter
            ? _bossPhaseDarkOrb.transform.position
            : Vector3.zero;
        await CollapseBossPhaseDarkOrbAsync(token);
        if (token.IsCancellationRequested) return false;

        UniTask rippleTask = hasRippleCenter
            ? PlayBossPhaseScreenRippleAsync(rippleWorldPosition, token)
            : UniTask.CompletedTask;
        UniTask gridDiscardTask = _battle.DiscardGridCardsForEnemyPhaseAsync(token);

        // 다음 페이즈 BGM은 화면 리플 셰이더가 끝난 뒤에만 시작한다.
        // 그리드 정리는 같은 시점에 병렬로 진행하되 BGM 시작 시점을 늦추지 않는다.
        await rippleTask;
        if (token.IsCancellationRequested) return false;
        PlayPreparedBossPhaseBgm(phaseIndex);

        await gridDiscardTask;
        if (token.IsCancellationRequested) return false;

#if UNITY_EDITOR || DEVELOPMENT_BUILD
        Debug.Log($"[BattleController] 보스 {phaseIndex + 1}페이즈 전환 완료 — HP {_enemy.Hp}/{_enemy.MaxHp}");
#endif
        return true;
    }

    private void PlayPreparedBossPhaseBgm(int phaseIndex)
    {
        if (_pendingBossPhaseBgmIndex != phaseIndex || _pendingBossPhaseBgmClip == null)
        {
            return;
        }

        AudioClip clip = _pendingBossPhaseBgmClip;
        float startTime = _pendingBossPhaseBgmStartTime;
        ClearPendingBossPhaseBgm();

        if (AudioManager.HasInstance)
        {
            AudioManager.Instance.PlayBgm(
                clip,
                crossfade: _bossPhaseBgmFadeInDuration,
                volume: AudioKeys.BgmVolume.BATTLE,
                startTime: startTime);
        }
    }

    private async UniTask ApplyEnemyViewFromDataAsync(
        EnemyDataSO enemyData,
        int phaseIndex,
        CancellationToken token)
    {
        string viewKey = enemyData != null ? enemyData.GetPhaseViewPrefabKey(phaseIndex) : null;
        if (string.IsNullOrWhiteSpace(viewKey) || _enemyObj == null || !ResourceManager.HasInstance)
        {
            return;
        }
        if (_runtimeEnemyView != null &&
            string.Equals(_runtimeEnemyViewKey, viewKey, StringComparison.Ordinal))
        {
            return;
        }

        Transform parent = _enemyObj.transform;
        GameObject prefab = await ResourceManager.Instance.LoadAsync<GameObject>(viewKey, token);
        if (prefab == null)
        {
            return;
        }
        if (token.IsCancellationRequested)
        {
            ResourceManager.Instance.Release<GameObject>(viewKey);
            return;
        }

        GameObject nextViewObject = Instantiate(prefab, parent);
        EnemyView nextView = nextViewObject.GetComponentInChildren<EnemyView>(includeInactive: true);

        if (nextView == null)
        {
            Destroy(nextViewObject);
            ResourceManager.Instance.Release<GameObject>(viewKey);
            return;
        }

        Transform viewTransform = nextViewObject.transform;
        viewTransform.SetParent(parent, false);
        viewTransform.localPosition = Vector3.zero;
        viewTransform.localRotation = Quaternion.identity;

        ReleaseRuntimeEnemyView();
        _runtimeEnemyViewObj = nextViewObject;
        _runtimeEnemyViewKey = viewKey;
        _runtimeEnemyView = nextView;
        _enemyObj.SetRuntimeView(nextView);
    }

    /// <summary>플레이어 대표 객체 풀 생성 + 셋업. 프리팹 미연결 시 null.</summary>
    private Player SpawnPlayerObject()
    {
        if (_playerPrefab == null || !PoolManager.HasInstance) return null;

        Vector3 pos = _playerAnchor != null ? _playerAnchor.position : Vector3.zero;
        Player obj = PoolManager.Instance.Spawn(_playerPrefab, pos, Quaternion.identity);
        obj?.Setup(ConfigMaxHp, ConfigMaxEnergy);
        return obj;
    }

    /// <summary>적 대표 객체 풀 생성 (셋업은 호출부). 프리팹 미연결 시 null.</summary>
    private Enemy SpawnEnemyObject(Vector3 position)
    {
        if (_enemyPrefab == null || !PoolManager.HasInstance) return null;

        return PoolManager.Instance.Spawn(_enemyPrefab, position, Quaternion.identity);
    }

    /// <summary>적 객체 풀 반환 (층 교체·전투 종료).</summary>
    private void DespawnEnemyObject()
    {
        ReleaseRuntimeEnemyView();

        if (_enemyObj != null && PoolManager.HasInstance)
        {
            PoolManager.Instance.Despawn(_enemyObj);
        }
        _enemyObj = null;
    }

    /// <summary>SO별 Addressable EnemyView 인스턴스를 해제한다.</summary>
    private void ReleaseRuntimeEnemyView()
    {
        if (_enemyObj != null)
        {
            _enemyObj.ResetRuntimeView();
        }

        if (_runtimeEnemyView != null || _runtimeEnemyViewObj != null)
        {
            GameObject viewObject = _runtimeEnemyViewObj != null
                ? _runtimeEnemyViewObj
                : _runtimeEnemyView.gameObject;
            string viewKey = _runtimeEnemyViewKey;
            _runtimeEnemyView = null;
            _runtimeEnemyViewObj = null;
            _runtimeEnemyViewKey = null;

            if (viewObject != null)
            {
                Destroy(viewObject);
            }

            if (!string.IsNullOrEmpty(viewKey) && ResourceManager.HasInstance)
            {
                ResourceManager.Instance.Release<GameObject>(viewKey);
            }
        }
    }

    /// <summary>
    /// 전달받은 카드 ID 목록으로 DeckSystem 을 새로 구성. 매 전투 호출 → 핸드/묘지 리셋됨.
    /// ID → CardDataSO(DataManager) → Card(CardFactory) 로 매번 새 인스턴스를 만든다
    /// (전투 간 런타임 상태 오염 방지). 덱 구성(누적)은 Run Flow 가 관리하며 여기선 받기만 한다.
    /// </summary>
    private void BuildDeckFromContext(BattleStartContext context)
    {
        if (_deckSystem == null) return;

        if (context != null && context.IsTutorialBattle && context.TutorialDeckCards.Count > 0)
        {
            BuildDeckFromSos(
                context.TutorialDeckCards,
                context.TutorialDeckForcedArrows);
            return;
        }

        IReadOnlyList<RunDeckEntry> deckEntries = context != null ? context.DeckEntries : null;
        IReadOnlyList<string> deckCardIds = context != null ? context.DeckCardIds : null;
        bool isRunDeck = context?.GetPersistentState != null;
        int count = deckEntries != null && deckEntries.Count > 0
            ? deckEntries.Count
            : (deckCardIds != null ? deckCardIds.Count : 0);
        List<Card> cards = new List<Card>(count);

        if (isRunDeck && (deckEntries == null || deckEntries.Count == 0))
        {
            Debug.LogError("[BattleController] 런 전투에 DeckEntries가 없습니다. CardId 폴백 랜덤 생성을 차단합니다.");
            _deckSystem.InitializeFromCards(cards);
            return;
        }

        if (deckEntries != null && deckEntries.Count > 0)
        {
            for (int i = 0; i < deckEntries.Count; i++)
            {
                RunDeckEntry entry = deckEntries[i];
                if (entry == null || string.IsNullOrEmpty(entry.CardId)) continue;

                CardRuntimeData runtime = entry.RuntimeData;
                if (runtime == null)
                {
                    CardDataSO so = DataManager.HasInstance && DataManager.Instance.IsLoaded
                        ? DataManager.Instance.GetData<CardDataSO>(entry.CardId)
                        : null;
                    runtime = so != null ? CardFactory.FromSO(so) : null;
                    entry.SetRuntimeData(runtime);
                }

                // ★ 방향 미확정 entry 라면 여기서 즉석 확정 (DataManager 타이밍 누수 차단).
                entry.EnsureArrowResolved();

                if (runtime == null || !entry.HasArrowDirection)
                {
                    Debug.LogError(
                        $"[BattleController] 런 카드 원본 누락 — entry={entry.EntryId}, " +
                        $"card={entry.CardId}, data={runtime != null}, direction={entry.HasArrowDirection}");
                    continue;
                }

                Card card = CardFactory.Create(runtime, entry.ArrowDirection);
                if (card == null) continue;

                card.SetRunDeckEntryId(entry.EntryId);
                // 각인 등으로 얻은 런 영속 코스트 보정을 전투 인스턴스에 반영.
                if (context?.GetCardCostDelta != null)
                {
                    int costDelta = context.GetCardCostDelta(entry.EntryId);
                    if (costDelta != 0) card.ApplyPermanentCostDelta(costDelta);
                }
                RestorePersistentState(card);
                cards.Add(card);

#if UNITY_EDITOR || DEVELOPMENT_BUILD
                Debug.Log(
                    $"[BattleController] 런 카드 복제 — entry={entry.EntryId}, " +
                    $"card={entry.CardId}, direction={entry.ArrowDirection}");
#endif
            }
        }
        else if (!isRunDeck && deckCardIds != null && DataManager.HasInstance && DataManager.Instance.IsLoaded)
        {
            for (int i = 0; i < deckCardIds.Count; i++)
            {
                CardDataSO so = DataManager.Instance.GetData<CardDataSO>(deckCardIds[i]);
                if (so == null)
                {
                    Debug.LogWarning($"[BattleController] 덱 카드 SO 미발견 — id '{deckCardIds[i]}'. 건너뜁니다.");
                    continue;
                }
                Card card = CardFactory.CreateFromSO(so);
                if (card != null) cards.Add(card);
            }
        }

        // 만들어진 카드들로 덱 초기화 (드로우 더미 채우고 셔플 — 핸드/묘지는 비워짐).
        _deckSystem.InitializeFromCards(cards);

#if UNITY_EDITOR || DEVELOPMENT_BUILD
        Debug.Log($"[BattleController] 덱 구성 — {cards.Count}장 (핸드/묘지 리셋)");
#endif
    }

    private void BuildDeckFromSos(
        IReadOnlyList<CardDataSO> deckCards,
        IReadOnlyList<ECardDirection> forcedArrows)
    {
        if (_deckSystem == null) return;

        int count = deckCards != null ? deckCards.Count : 0;
        List<Card> cards = new List<Card>(count);

        if (deckCards != null)
        {
            for (int i = 0; i < deckCards.Count; i++)
            {
                CardDataSO so = deckCards[i];
                if (so == null) continue;

                Card card = CardFactory.CreateFromSO(so);
                if (card == null) continue;

                if (forcedArrows != null
                    && i < forcedArrows.Count
                    && forcedArrows[i] != ECardDirection.None)
                {
                    card.Arrow.Restore(forcedArrows[i]);
                }
                cards.Add(card);
            }
        }

        _deckSystem.InitializeFromCards(cards);

#if UNITY_EDITOR || DEVELOPMENT_BUILD
        Debug.Log($"[BattleController] 튜토리얼 덱 구성 — {cards.Count}장 (핸드/묘지 리셋)");
#endif
    }

    // ─────────────────────────────────────────────
    // 전투 연동 핸들러
    // ─────────────────────────────────────────────

    /// <summary>페이즈 전환 처리. 플레이어 입력 페이즈 진입 시 카드 드로우.</summary>
    private void HandlePhaseChanged(EBattlePhase phase)
    {
        _grid?.ClearEnemyLineIntentWarning();

        if (phase == EBattlePhase.PlayerInput &&
            _grid != null && _grid.Rows > 0 && _grid.Columns > 0 &&
            HasCurrentIntent(EEnemyIntentType.GridLineAttack))
        {
            // Amount = 자를 라인 수(0/1 이면 1개 — 하위호환).
            int lineCount = Mathf.Max(1, GetCurrentIntentAmount(EEnemyIntentType.GridLineAttack));
            CreateLineAttackPlans(lineCount, _currentLineAttackPlans);
            _grid.ShowEnemyLineIntentWarning(_currentLineAttackPlans);
        }
        else if (phase == EBattlePhase.PlayerInput)
        {
            _currentLineAttackPlans.Clear();
        }

        if (phase == EBattlePhase.PlayerInput && _deckSystem != null)
        {
#if UNITY_EDITOR || DEVELOPMENT_BUILD
            int uiCount = _cardHand != null ? _cardHand.Cards.Count : -1;
            Debug.Log($"[BattleController] 턴 시작 드로우 직전 — 데이터 손패 {_deckSystem.HandCount}, UI 손패 {uiCount}");
#endif
            // 턴 시작 드로우. DeckSystem.OnCardDrawn → HandleCardDrawn 으로 UI 생성.
            _deckSystem.DrawTurnStartCards(_activeDrawPerTurn);
            FlushReactiveTogglesAsync().Forget();
        }
    }

    private bool HasCurrentIntent(EEnemyIntentType type)
    {
        IReadOnlyList<EnemyIntent> intents = _enemyHandler?.CurrentIntents;
        if (intents == null) return false;

        for (int i = 0; i < intents.Count; i++)
        {
            if (intents[i].Type == type) return true;
        }
        return false;
    }

    /// <summary>현재 의도 묶음에서 지정 타입의 Amount 를 반환. 없으면 0.</summary>
    private int GetCurrentIntentAmount(EEnemyIntentType type)
    {
        IReadOnlyList<EnemyIntent> intents = _enemyHandler?.CurrentIntents;
        if (intents == null) return 0;

        for (int i = 0; i < intents.Count; i++)
        {
            if (intents[i].Type == type) return intents[i].Amount;
        }
        return 0;
    }

    /// <summary>
    /// 서로 다른 라인(축+인덱스)을 count 개 뽑아 result 에 채운다. 같은 라인 중복 없음.
    /// 요청 수가 전체 라인 수를 넘으면 가능한 최대까지만 뽑는다.
    /// </summary>
    private void CreateLineAttackPlans(int count, List<GridLineAttackPlan> result)
    {
        result.Clear();

        // 전체 후보 라인(Row 전부 + Column 전부)을 만든 뒤 셔플해 앞에서부터 선택 — 중복 없이 균등.
        int total = _grid.Rows + _grid.Columns;
        count = Mathf.Clamp(count, 1, total);

        var candidates = new List<(EGridLineAxis axis, int index)>(total);
        for (int r = 0; r < _grid.Rows; r++) candidates.Add((EGridLineAxis.Row, r));
        for (int c = 0; c < _grid.Columns; c++) candidates.Add((EGridLineAxis.Column, c));

        int randomStartIndex = 0;
        Card selectedCard = null;
        int placedCardCount = 0;
        foreach (Card card in _grid.PlacedCards)
        {
            if (card == null) continue;

            placedCardCount++;
            if (UnityEngine.Random.Range(0, placedCardCount) == 0)
            {
                selectedCard = card;
            }
        }

        // 그리드에 남은 카드가 있으면 첫 절단선은 해당 카드를 지나는 행 또는 열로 선정한다.
        if (selectedCard != null && _grid.TryGetPosition(selectedCard, out Vector2Int selectedPosition))
        {
            EGridLineAxis selectedAxis = UnityEngine.Random.value < 0.5f
                ? EGridLineAxis.Row
                : EGridLineAxis.Column;
            int selectedIndex = selectedAxis == EGridLineAxis.Row
                ? selectedPosition.y
                : selectedPosition.x;
            int candidateIndex = selectedAxis == EGridLineAxis.Row
                ? selectedIndex
                : _grid.Rows + selectedIndex;

            (candidates[0], candidates[candidateIndex]) = (candidates[candidateIndex], candidates[0]);

            bool forward = UnityEngine.Random.value < 0.5f;
            result.Add(new GridLineAttackPlan(
                candidates[0].axis,
                candidates[0].index,
                forward));
            randomStartIndex = 1;
        }

        // Fisher-Yates 앞부분만 셔플.
        for (int i = randomStartIndex; i < count && i < candidates.Count; i++)
        {
            int j = UnityEngine.Random.Range(i, candidates.Count);
            (candidates[i], candidates[j]) = (candidates[j], candidates[i]);

            bool forward = UnityEngine.Random.value < 0.5f;
            result.Add(new GridLineAttackPlan(candidates[i].axis, candidates[i].index, forward));
        }
    }

    private async UniTask HandleBeforeEnemyActionAsync(
        int enemyTurn,
        int intentOrder,
        CancellationToken token)
    {
        _eliteBuffController?.Clear();

        if (_grid != null)
        {
            await _grid.RestoreBrokenSlotsAsync(token);
        }
    }

    private async UniTask ExecuteGridLineAttackAsync(CancellationToken token)
    {
        if (_currentLineAttackPlans.Count == 0 || _grid == null || _dispatcher == null) return;

        try
        {
            // 예고된 라인들을 순차로 하나씩 자른다. 각 라인은 개별 VFX/막기 판정.
            for (int p = 0; p < _currentLineAttackPlans.Count; p++)
            {
                if (token.IsCancellationRequested) return;
                await ExecuteSingleLineAttackAsync(_currentLineAttackPlans[p], token);
            }
        }
        finally
        {
            _currentLineAttackPlans.Clear();
        }
    }

    /// <summary>단일 라인 계획 하나를 실행한다(VFX + 순차 파괴, 카드가 있으면 흡수/막기).</summary>
    private async UniTask ExecuteSingleLineAttackAsync(GridLineAttackPlan plan, CancellationToken token)
    {
        _grid.GetLineSlots(plan, _lineAttackSlots);
        for (int i = 0; i < _lineAttackSlots.Count; i++)
        {
            if (_lineAttackSlots[i] == null || _lineAttackSlots[i].IsEmpty) continue;
            if (i + 1 < _lineAttackSlots.Count)
            {
                _lineAttackSlots.RemoveRange(i + 1, _lineAttackSlots.Count - i - 1);
            }
            break;
        }

        var breakTasks = new List<UniTask>(_lineAttackSlots.Count);
        LineAttackSlashVfx slash = _grid.BeginLineAttackVfx(_lineAttackSlots, plan);
        float initialDelay = slash != null ? slash.Duration * slash.ImpactStartNormalized : 0f;
        float stepDelay = slash != null && _lineAttackSlots.Count > 1
            ? slash.Duration * (slash.ImpactEndNormalized - slash.ImpactStartNormalized) / (_lineAttackSlots.Count - 1)
            : _grid.LineAttackStepDelay;
        UniTask vfxLifetimeTask = slash != null && slash.Duration > 0f
            ? UniTask.Delay(TimeSpan.FromSeconds(slash.Duration), cancellationToken: token)
            : UniTask.CompletedTask;

        try
        {
            if (initialDelay > 0f)
            {
                await UniTask.Delay(TimeSpan.FromSeconds(initialDelay), cancellationToken: token);
            }

            for (int i = 0; i < _lineAttackSlots.Count; i++)
            {
                token.ThrowIfCancellationRequested();
                GridSlot slot = _lineAttackSlots[i];
                if (slot == null) continue;

                if (!slot.IsEmpty)
                {
                    // 배치된 카드가 그리드 자르기를 흡수 = "카드로 막기".
                    // 그리드 자르기는 보스 고유 의도이므로 보스전 여부만 함께 싣는다.
                    if (EventManager.HasInstance)
                        EventManager.Instance.Publish(new GridCutBlockedSignal(IsBossBattle));

                    await _dispatcher.ExhaustGridCardAsync(slot.OccupiedCard, _enemy, token);
                    break;
                }

                breakTasks.Add(slot.PlayBreakAsync(token));
                if (stepDelay > 0f && i < _lineAttackSlots.Count - 1)
                {
                    await UniTask.Delay(
                        TimeSpan.FromSeconds(stepDelay),
                        cancellationToken: token);
                }
            }

            if (breakTasks.Count > 0)
            {
                await UniTask.WhenAll(breakTasks);
            }
            await vfxLifetimeTask;
        }
        finally
        {
            _grid.EndLineAttackVfx();
        }
    }

    private UniTask PlayEnemyAttackMotionAsync(CancellationToken token)
    {
        EnemyView view = _enemyObj != null ? _enemyObj.View : null;
        return view != null
            ? view.PlayAttackMotionAsync(token)
            : UniTask.CompletedTask;
    }

    private async UniTask ExecuteEraseInfoVfxAsync(CancellationToken token)
    {
        Transform enemyView = _enemyObj != null && _enemyObj.View != null
            ? _enemyObj.View.AnchorTransform
            : _enemyAnchor;
        Transform playerView = _playerObj != null && _playerObj.View != null
            ? _playerObj.View.AnchorTransform
            : _playerAnchor;
        if (_eraseInfoProjectileSprite == null || enemyView == null || playerView == null) return;

        Vector3 start = enemyView.position;
        Vector3 end = playerView.position;
        GameObject projectile = new GameObject("EraseInfoPoisonProjectile");
        SpriteRenderer spriteRenderer = projectile.AddComponent<SpriteRenderer>();
        spriteRenderer.sprite = _eraseInfoProjectileSprite;
        spriteRenderer.sortingLayerName = "FrontEffect";
        projectile.transform.position = start;
        projectile.transform.localScale = Vector3.one * _eraseInfoProjectileScale;

        float duration = Mathf.Max(0.01f, BattleSpeedUtility.ScaleDuration(_eraseInfoProjectileDuration));
        float elapsed = 0f;
        try
        {
            while (elapsed < duration)
            {
                token.ThrowIfCancellationRequested();
                elapsed += Time.deltaTime;
                float t = Mathf.Clamp01(elapsed / duration);
                Vector3 arc = Vector3.up * (4f * _eraseInfoProjectileArcHeight * t * (1f - t));
                projectile.transform.position = Vector3.Lerp(start, end, t) + arc;
                await UniTask.Yield(PlayerLoopTiming.Update, token);
            }
        }
        finally
        {
            if (projectile != null)
            {
                Destroy(projectile);
            }
        }
    }

    private void HandleCardInfoHiddenChanged(bool hidden)
    {
        if (hidden)
        {
            StartBlindPoisonVfx();
        }
        else
        {
            StopBlindPoisonVfx();
        }
    }

    private void StartBlindPoisonVfx()
    {
        if (_blindPoisonVfx != null || _blindPoisonVfxLoadCts != null || !PoolManager.HasInstance)
        {
            return;
        }

        Transform playerAnchor = _playerObj != null && _playerObj.View != null
            ? _playerObj.View.AnchorTransform
            : _playerAnchor;
        if (playerAnchor == null)
        {
            return;
        }

        CancellationToken battleToken = _cts != null ? _cts.Token : CancellationToken.None;
        CancellationTokenSource loadCts = CancellationTokenSource.CreateLinkedTokenSource(battleToken);
        _blindPoisonVfxLoadCts = loadCts;
        SpawnBlindPoisonVfxAsync(playerAnchor, loadCts).Forget();
    }

    private async UniTaskVoid SpawnBlindPoisonVfxAsync(
        Transform playerAnchor,
        CancellationTokenSource loadCts)
    {
        SimplePoolable spawned = null;
        try
        {
            spawned = await PoolManager.Instance.SpawnAsync<SimplePoolable>(
                BLIND_POISON_VFX_KEY,
                playerAnchor.position,
                Quaternion.identity,
                playerAnchor,
                loadCts.Token);

            if (spawned == null)
            {
                Debug.LogWarning($"[BattleController] BlindPoisonVfx 생성 실패 — 키 확인: {BLIND_POISON_VFX_KEY}");
                return;
            }

            bool isStale = loadCts.IsCancellationRequested ||
                           _blindPoisonVfxLoadCts != loadCts ||
                           _grid == null ||
                           !_grid.IsCardInfoHidden;
            if (isStale)
            {
                ReleaseBlindPoisonVfx(spawned);
                spawned = null;
                return;
            }

            Transform vfxTransform = spawned.transform;
            vfxTransform.localPosition = Vector3.zero;
            vfxTransform.localRotation = Quaternion.identity;
            vfxTransform.localScale = Vector3.one;
            _blindPoisonVfx = spawned;
            spawned = null;
        }
        catch (OperationCanceledException)
        {
            ReleaseBlindPoisonVfx(spawned);
        }
        catch (Exception ex)
        {
            ReleaseBlindPoisonVfx(spawned);
            Debug.LogWarning($"[BattleController] BlindPoisonVfx 생성 실패: {ex.Message}");
        }
        finally
        {
            if (_blindPoisonVfxLoadCts == loadCts)
            {
                _blindPoisonVfxLoadCts = null;
            }
            loadCts.Dispose();
        }
    }

    private void StopBlindPoisonVfx()
    {
        CancellationTokenSource loadCts = _blindPoisonVfxLoadCts;
        _blindPoisonVfxLoadCts = null;
        loadCts?.Cancel();

        SimplePoolable activeVfx = _blindPoisonVfx;
        _blindPoisonVfx = null;
        ReleaseBlindPoisonVfx(activeVfx);
    }

    private static void ReleaseBlindPoisonVfx(SimplePoolable vfx)
    {
        if (vfx == null) return;

        if (PoolManager.HasInstance && PoolManager.Instance.IsPooledInstance(vfx.gameObject))
        {
            PoolManager.Instance.Despawn(vfx);
        }
        else
        {
            Destroy(vfx.gameObject);
        }
    }

    private void HandleBeforeEnemyAction(int enemyTurn, int intentOrder)
    {
        _lastEnemyTurn = Mathf.Max(_lastEnemyTurn, enemyTurn);
        ShowEnemySpeech(EEnemySpeechTrigger.BeforeEnemyTurn, enemyTurn, intentOrder);
    }

    private void ShowEnemySpeech(EEnemySpeechTrigger trigger, int enemyTurn, int intentOrder)
    {
        if (_currentEnemyData == null) return;

        EnemySpeechLine speech;
        bool hasSpeech = trigger == EEnemySpeechTrigger.BattleStart
            ? _currentEnemyData.TryGetBattleStartSpeech(out speech)
            : _currentEnemyData.TryGetBeforeEnemyActionSpeech(enemyTurn, intentOrder, out speech);
        if (!hasSpeech) return;

        if (UIManager.HasInstance)
        {
            UIManager.Instance.Get<UIBattle>()?.ShowEnemySpeech(speech);
        }
    }

    private Transform ResolveEnemySpeechTarget()
    {
        if (_enemyObj != null && _enemyObj.View != null)
        {
            return _enemyObj.View.AnchorTransform;
        }
        return _enemyAnchor;
    }

    private void BindPlayerDamageNumber(PlayerActor player)
    {
        UnbindPlayerDamageNumber();
        if (player == null) return;

        player.OnDamageTaken += HandlePlayerDamageTaken;
    }

    private void BindEnemyDamageNumber(EnemyActor enemy)
    {
        UnbindEnemyDamageNumber();
        if (enemy == null) return;

        enemy.OnDamageTaken += HandleEnemyDamageTaken;
    }

    private void UnbindPlayerDamageNumber()
    {
        if (_player != null)
        {
            _player.OnDamageTaken -= HandlePlayerDamageTaken;
        }
    }

    private void BindPlayerReactiveEvents(PlayerActor player)
    {
        UnbindPlayerReactiveEvents();
        if (player == null) return;

        _lastReactiveEnergy = player.Energy;
        player.OnEnergyChanged += HandlePlayerEnergyChanged;
    }

    private void UnbindPlayerReactiveEvents()
    {
        if (_player != null)
        {
            _player.OnEnergyChanged -= HandlePlayerEnergyChanged;
        }
    }

    private void UnbindEnemyDamageNumber()
    {
        if (_enemy != null)
        {
            _enemy.OnDamageTaken -= HandleEnemyDamageTaken;
        }
    }

    private void HandlePlayerDamageTaken(int requestedDamage, int hpDamage, int blockedDamage)
    {
        _damageTakenBattle += Mathf.Max(0, hpDamage);

        if (blockedDamage > 0 && hpDamage <= 0 && AudioManager.HasInstance)
            AudioManager.Instance.PlaySfxAsync(AudioKeys.Battle.PLAYER_BLOCK).Forget();

        if (hpDamage > 0 && AudioManager.HasInstance)
            AudioManager.Instance.PlaySfxAsync(AudioKeys.Battle.PLAYER_HIT).Forget();

        // 외부 구독자(분석 등)에 피격 통지. 가해 적의 ID는 노드 정보로 알 수 있으므로 싣지 않는다.
        OnPlayerDamageTaken?.Invoke(Mathf.Max(0, hpDamage));
        Transform target = _playerObj != null && _playerObj.View != null
            ? _playerObj.View.AnchorTransform
            : _playerAnchor;
        _vfxPresenter?.SpawnDamageNumber(target, requestedDamage, hpDamage, blockedDamage, _playerDamageNumberScale);
    }

    private void HandlePlayerEnergyChanged(int current, int max)
    {
        if (_reactiveEvents == null)
        {
            _lastReactiveEnergy = current;
            return;
        }

        _reactiveEvents.Publish(new BattleReactiveEvent(
            EReactiveEventType.EnergyChanged,
            amount: Mathf.Abs(current - _lastReactiveEnergy),
            previousValue: _lastReactiveEnergy,
            currentValue: current));
        _lastReactiveEnergy = current;
    }

    /// <summary>ChainExecutor의 무한루프 감지를 외부 구독자에게 중계한다 (게임 로직과 분리).</summary>
    private void HandleInfiniteLoopDetected(Card card, Vector2Int position)
        => OnInfiniteLoopDetected?.Invoke(card, position);

    /// <summary>
    /// 체인 활성화 카운트를 리셋하기 직전, 그 체인의 피크 값을 통계로 중계한다.
    /// _chainActivatedCount는 체인 내 단조 증가라 리셋 직전 값이 곧 피크다.
    /// </summary>
    private void ResetChainCountAndReportPeak()
    {
        if (_chain == null) return;
        // 피니셔(100) 도달 체인은 웨이브 단위 처리로 카운터가 100을 몇 개 넘길 수 있다.
        // 100 이상은 전부 '무한루프=100'으로 보도록 한도로 캡한다(100 미만 일반 체인은 실측 그대로).
        int peak = Mathf.Min(_chain.ChainActivatedCount, ChainFinisherCount);
        OnChainEnded?.Invoke(peak);
        _chain.ResetChainActivatedCount();
    }

    private void HandleBattleCardPlaced(Card card, Vector2Int position)
    {
        _vfxPresenter?.ResetChainTextPopupCount();
        ResetChainCountAndReportPeak();
        _battlePlaceCount++;

        _reactiveEvents?.Publish(new BattleReactiveEvent(
            EReactiveEventType.CardPlaced,
            sourceCard: card,
            targetCard: card,
            owner: card != null ? card.BattleDeckOwner : EBattleDeckOwner.RunDeck));
    }

    private async UniTask HandleBattleChainEndedAsync(Card card, CancellationToken token)
    {
        _vfxPresenter?.ResetChainTextPopupCount();
        ResetChainCountAndReportPeak();
        UniTask playerAnimation = _playerObj?.View != null
            ? _playerObj.View.FinishChainAttackAnimationAsync(token)
            : UniTask.CompletedTask;
        await UniTask.WhenAll(HideAndReleaseChainMagicCirclesAsync(token), playerAnimation);
    }

    private async UniTask HandleChainMilestoneAttackAsync(Card card, int chainCount, CancellationToken token)
    {
        Tween milestoneTween = await UpdateChainMagicCirclesAsync(chainCount, token);
        if (token.IsCancellationRequested) return;

        if (Array.IndexOf(ChainMagicCircleEndCounts, chainCount) >= 0)
        {
            if (milestoneTween != null)
            {
                await milestoneTween.AsUniTask(token);
                if (token.IsCancellationRequested) return;
            }

            // 완성된 원이 한 프레임 표시된 뒤 마일스톤 공격을 실행한다.
            await UniTask.NextFrame(token);
            if (token.IsCancellationRequested) return;
        }

        if (!TryGetChainMilestoneAttack(chainCount, out ChainMilestoneAttackSetting setting) ||
            _enemy == null ||
            !_enemy.IsAlive)
        {
            return;
        }

        if (setting.Damage <= 0 && !setting.KillTarget)
        {
            return;
        }

        if (_vfxPresenter != null && !string.IsNullOrEmpty(setting.ProjectileKey))
        {
            await _vfxPresenter.PlayPlayerLaserAsync(
                setting.ProjectileKey,
                ChainMilestoneVfxSpawnOffset,
                setting.AnimationDuration,
                setting.AnimationSpeedMultiplier,
                setting.KillTarget,
                setting.LaunchPitchMultiplier,
                setting.HitPitchMultiplier,
                setting.HitCount,
                (hitIndex, hitToken) => ApplyChainMilestoneHitAsync(setting, hitIndex, hitToken),
                token);
            return;
        }

        for (int hitIndex = 0; hitIndex < setting.HitCount; hitIndex++)
        {
            bool shouldContinue = await ApplyChainMilestoneHitAsync(setting, hitIndex, token);
            if (!shouldContinue || token.IsCancellationRequested) break;
        }
    }

    private async UniTask<Tween> UpdateChainMagicCirclesAsync(int chainCount, CancellationToken token)
    {
        Transform playerAnchor = _playerObj?.View != null
            ? _playerObj.View.AnchorTransform
            : _playerAnchor;
        if (playerAnchor == null || !ResourceManager.HasInstance) return null;

        Tween milestoneTween = null;

        for (int i = 0; i < ChainMagicCircleEndCounts.Length; i++)
        {
            int startCount = i == 0 ? 10 : ChainMagicCircleEndCounts[i - 1];
            if (chainCount <= startCount) continue;

            if (_chainMagicCircleObjects[i] == null)
            {
                try
                {
                    GameObject instance = await ResourceManager.Instance.InstantiateAsync<GameObject>(
                        ChainMagicCircleKeys[i], null, token);
                    if (instance == null) continue;

                    SpriteMagicCircleReveal reveal = instance.GetComponentInChildren<SpriteMagicCircleReveal>(true);
                    if (reveal == null)
                    {
                        Debug.LogWarning($"[BattleController] 마법진 Reveal 컴포넌트 없음: {ChainMagicCircleKeys[i]}");
                        ReleaseChainMagicCircleInstance(instance);
                        continue;
                    }

                    instance.transform.SetPositionAndRotation(
                        playerAnchor.position + ChainMilestoneVfxSpawnOffset,
                        Quaternion.identity);
                    reveal.ResetReveal();
                    _chainMagicCircleObjects[i] = instance;
                    _chainMagicCircleReveals[i] = reveal;
                }
                catch (OperationCanceledException)
                {
                    throw;
                }
                catch (Exception ex)
                {
                    Debug.LogWarning($"[BattleController] 마법진 생성 실패: {ChainMagicCircleKeys[i]} ({ex.Message})");
                    continue;
                }
            }

            float progress = Mathf.InverseLerp(startCount, ChainMagicCircleEndCounts[i], chainCount);
            Tween progressTween = _chainMagicCircleReveals[i]?.TweenProgress(
                progress,
                _chainMagicCircleProgressDuration);
            if (chainCount == ChainMagicCircleEndCounts[i])
            {
                milestoneTween = progressTween;
            }
        }

        return milestoneTween;
    }

    private async UniTask HideAndReleaseChainMagicCirclesAsync(CancellationToken token)
    {
        GameObject[] objects = new GameObject[_chainMagicCircleObjects.Length];
        bool hasCircle = false;
        for (int i = 0; i < objects.Length; i++)
        {
            objects[i] = _chainMagicCircleObjects[i];
            hasCircle |= objects[i] != null;
            _chainMagicCircleReveals[i]?.TweenProgress(0f, ChainMagicCircleHideDuration);
            _chainMagicCircleObjects[i] = null;
            _chainMagicCircleReveals[i] = null;
        }

        if (!hasCircle) return;

        try
        {
            await UniTask.Delay(
                TimeSpan.FromSeconds(ChainMagicCircleHideDuration),
                cancellationToken: token);
        }
        catch (OperationCanceledException)
        {
            // 전투 종료·씬 이탈 시에도 finally에서 Addressable 인스턴스를 회수한다.
        }
        finally
        {
            for (int i = 0; i < objects.Length; i++)
            {
                ReleaseChainMagicCircleInstance(objects[i]);
            }
        }
    }

    private void ReleaseChainMagicCirclesImmediate()
    {
        for (int i = 0; i < _chainMagicCircleObjects.Length; i++)
        {
            ReleaseChainMagicCircleInstance(_chainMagicCircleObjects[i]);
            _chainMagicCircleObjects[i] = null;
            _chainMagicCircleReveals[i] = null;
        }
    }

    private static void ReleaseChainMagicCircleInstance(GameObject instance)
    {
        if (instance == null) return;

        if (ResourceManager.HasInstance)
            ResourceManager.Instance.ReleaseInstance(instance);
        else
            Destroy(instance);
    }

    private UniTask<bool> ApplyChainMilestoneHitAsync(
        ChainMilestoneAttackSetting setting,
        int hitIndex,
        CancellationToken token)
    {
        EnemyActor target = _enemy;
        if (token.IsCancellationRequested || target == null || !target.IsAlive)
        {
            return UniTask.FromResult(false);
        }

        int damage;
        int hitCount = setting.HitCount;
        if (setting.KillTarget)
        {
            int remainingHits = Mathf.Max(1, hitCount - hitIndex);
            damage = Mathf.CeilToInt((target.Hp + target.Block) / (float)remainingHits);
        }
        else
        {
            damage = setting.Damage;
        }

        if (damage > 0)
        {
            target.TakeDamage(damage);
            float shakeForce = setting.ChainCount switch
            {
                10 => 0.1f,
                30 => 0.3f,
                50 => 0.5f,
                ChainFinisherCount => 1f,
                _ => 0f,
            };
            if (shakeForce > 0f && CameraManager.HasInstance)
                CameraManager.Instance.Shake(shakeForce);
        }

        return UniTask.FromResult(target == _enemy && target.IsAlive);
    }

    private bool TryGetChainMilestoneAttack(int chainCount, out ChainMilestoneAttackSetting setting)
    {
        if (_chainMilestoneAttacks != null)
        {
            for (int i = 0; i < _chainMilestoneAttacks.Length; i++)
            {
                ChainMilestoneAttackSetting candidate = _chainMilestoneAttacks[i];
                if (candidate.ChainCount == chainCount)
                {
                    setting = candidate;
                    return true;
                }
            }
        }

        setting = default;
        return false;
    }

    private void HandleBattleCardToggled(Card card, bool activated)
    {
        if (activated)
        {
            bool useNonDamageAnimation = card != null &&
                !card.HasEffect(ECardEffectFlag.Damage | ECardEffectFlag.ManaBurst);
            _playerObj?.View?.PlayChainAttackAnimation(useNonDamageAnimation);
        }

        _reactiveEvents?.Publish(new BattleReactiveEvent(
            EReactiveEventType.CardToggled,
            sourceCard: card,
            targetCard: card,
            amount: activated ? 1 : 0,
            previousValue: activated ? 0 : 1,
            currentValue: activated ? 1 : 0,
            owner: card != null ? card.BattleDeckOwner : EBattleDeckOwner.RunDeck));
    }

    private async UniTaskVoid FlushReactiveTogglesAsync()
    {
        if (_reactiveToggleQueue == null || _cts == null)
        {
            return;
        }

        await _reactiveToggleQueue.FlushAsync(_cts.Token);
    }

    private void HandleEnemyDamageTaken(int requestedDamage, int hpDamage, int blockedDamage)
    {
        _damageDealtBattle += Mathf.Max(0, hpDamage + blockedDamage);
        Transform target = _enemyObj != null && _enemyObj.View != null
            ? _enemyObj.View.AnchorTransform
            : _enemyAnchor;
        _vfxPresenter?.SpawnDamageNumber(target, requestedDamage, hpDamage, blockedDamage, _enemyDamageNumberScale);
    }

    /// <summary>
    /// 카드가 덱에서 손패로 들어왔을 때 — UICard 를 풀에서 스폰·바인딩하고 드로우 연출.
    /// DeckSystem(데이터) → UICard(비주얼) 연결 지점.
    /// </summary>
    private void HandleCardDrawn(Card card)
    {
        if (_cardHand == null || _cardHand.CardPrefab == null)
        {
            return;
        }

        // UICard 풀 스폰 (UI 카테고리). 손패 Transform 을 부모로 스폰해 편입.
        UICard uiCard = SpawnHandCard();
        if (uiCard == null) return;

        uiCard.Bind(card);
        _cardHand.RegisterCard(uiCard);

        if (_placementController != null)
        {
            _placementController.RegisterCard(uiCard);
        }

        if (TutorialSecondBattleSequence.ShouldStageInitialHandPresentation)
        {
            uiCard.SetVisualVisible(false);
            uiCard.SetInteractable(false);
            uiCard.SetRaycastTarget(false);
            return;
        }

        // 드로우 연출 (CardAnimationSystem 있으면).
        if (CardAnimationSystem.HasInstance)
        {
            CardAnimationSystem.Instance.PlayDrawAnim(uiCard, _cardHand, _cts.Token).Forget();
        }
    }

    /// <summary>
    /// 손패 상한 초과로 드로우한 카드가 손에 못 들어오고 묘지로 갔을 때의 연출.
    /// 손패를 거치지 않아 UICard 가 없으므로, 덱 더미 → 묘지 더미로 전송 이미지만 날린다.
    /// DeckSystem.OnDrawDiscardedHandFull 구독.
    /// </summary>
    private void HandleDrawDiscardedHandFull(Card card)
    {
        if (card == null || !CardAnimationSystem.HasInstance) return;

        CardAnimationSystem.Instance.PlayDrawToDiscardAsync(_cts.Token).Forget();
    }

    private void HandleDrawFailedNoCards(Card source)
    {
        if (source == null || !UIManager.HasInstance)
        {
            return;
        }

        Vector3? worldPosition = ResolveCardWorldPosition(source);
        if (!worldPosition.HasValue)
        {
            return;
        }

        UIManager.Instance.Get<UIBattle>()?.ShowTempWorldText(
            worldPosition.Value + Vector3.up * 0.75f,
            Localize(NoDrawableCardKey));
    }

    /// <summary>
    /// 카드가 묘지로 갈 때(턴 종료 손패 정리·필드 회수 등) 해당 UICard 를 손패에서 제거한다.
    /// DeckSystem.OnCardDiscarded 구독. UICard 는 BoundCard 로 원본 Card 를 들고 있으므로
    /// 일치하는 UICard 를 찾아 손패에서 떼고 풀로 반환한다 (UI-데이터 동기화).
    /// 그리드에서 회수된 카드는 손패에 UICard 가 없으니 자연히 무시된다.
    /// [주의] UICardHand.RemoveCard 는 리스트에서 빼고 레이아웃만 갱신할 뿐
    ///        UICard 오브젝트를 풀로 돌려주지 않으므로, 여기서 명시적으로 반환한다.
    /// </summary>
    /// <summary>전투 중 플레이어 HP 변동을 전역 통지(OnPlayerHpChanged)로 중계 — 상단 정보바 갱신용.</summary>
    private void HandlePlayerHpChanged(int current, int max)
    {
        if (!EventManager.HasInstance) return;

        EventManager.Instance.Publish(new OnPlayerHpChanged
        {
            Current = current,
            Max = max,
        });
    }

    /// <summary>DeckSystem 의 더미 개수 변동을 외부(UIBattle 카운터)로 중계.</summary>
    private void HandlePilesChanged()
    {
        OnPilesChanged?.Invoke();
    }

    private void HandleCardDiscarded(Card card)
    {
        if (_cardHand == null || card == null) return;

        // 손패에서 이 Card 를 표현하는 UICard 탐색.
        IReadOnlyList<UICard> handCards = _cardHand.Cards;
        UICard target = null;
        for (int i = 0; i < handCards.Count; i++)
        {
            UICard uiCard = handCards[i];
            if (uiCard != null && uiCard.BoundCard == card)
            {
                target = uiCard;
                break; // 카드 인스턴스는 유일 → 첫 일치에서 종료
            }
        }

        if (target == null)
        {
#if UNITY_EDITOR || DEVELOPMENT_BUILD
            Debug.LogWarning($"[BattleController] 묘지로 간 카드 '{card.CardId}' 에 대응하는 " +
                $"손패 UICard 를 찾지 못했습니다. (손패 {_cardHand.Cards.Count}장) " +
                "이미 그리드 배치된 카드이거나 BoundCard 참조 불일치일 수 있습니다.");
#endif
            return;
        }

        // 손패 리스트에서 제거 (내부에서 배치 입력 구독도 해제됨).
        _cardHand.RemoveCard(target);

        // UICard 오브젝트는 디스카드 연출이 끝난 뒤 풀로 반환한다.
        if (CardAnimationSystem.HasInstance)
        {
            UniTaskCompletionSource completion = new UniTaskCompletionSource();
            _pendingDiscardAnimations.Add(completion);
            PlayDiscardAndCompleteAsync(target, completion).Forget();
        }
        else
        {
            target.ReturnToPoolOrDestroy();
        }

#if UNITY_EDITOR || DEVELOPMENT_BUILD
        Debug.Log($"[BattleController] 손패 UICard 제거 — '{card.CardId}' (남은 손패 {_cardHand.Cards.Count}장)");
#endif
    }

    /// <summary>디스카드 연출을 재생하고 완료 시 펜딩 신호를 해제한다 (풀 반환은 연출 내부 처리).</summary>
    private async UniTaskVoid PlayDiscardAndCompleteAsync(UICard target, UniTaskCompletionSource completion)
    {
        try
        {
            await CardAnimationSystem.Instance.PlayDiscardAnim(target, _cts.Token);
        }
        catch (OperationCanceledException)
        {
            // 전투 종료·씬 이탈로 취소 — CardAnimationSystem 이 정리한다.
        }
        finally
        {
            completion.TrySetResult();
        }
    }

    /// <summary>
    /// 진행 중인 디스카드 연출이 모두 끝날 때까지 대기 (BattleManager 턴 해결이 호출).
    /// 손패 정리 연출이 끝나기 전에 다음 페이즈로 넘어가 UICard 가 튀는 것을 막는다.
    /// </summary>
    public async UniTask WaitForPendingCardAnimationsAsync(CancellationToken token)
    {
        if (_pendingDiscardAnimations.Count == 0) return;

        List<UniTask> tasks = new List<UniTask>(_pendingDiscardAnimations.Count);
        for (int i = 0; i < _pendingDiscardAnimations.Count; i++)
        {
            tasks.Add(_pendingDiscardAnimations[i].Task);
        }
        _pendingDiscardAnimations.Clear();

        await UniTask.WhenAll(tasks).AttachExternalCancellation(token);
    }

    /// <summary>UICard 를 PoolManager(UI 카테고리)에서 스폰. 풀 없으면 직접 생성 폴백.</summary>
    private UICard SpawnHandCard()
    {
        UICard prefab = _cardHand.CardPrefab;

        if (PoolManager.HasInstance)
        {
            // 손패 Transform 을 부모로 스폰 (RefreshLayout 이 위치 재배치).
            return PoolManager.Instance.Spawn(prefab, _cardHand.transform);
        }

        // 폴백: 풀 매니저 없으면 직접 생성.
        return Instantiate(prefab, _cardHand.transform);
    }

    /// <summary>전투 종료 — 승패 결과를 런 컨트롤러로 통지.</summary>
    private void HandleBattleEnded(bool victory)
    {
        CaptureBattleDurationState();
        IsBattleRunning = false;
        _playerObj?.View?.ResetEffectAnimation();
        HideAndReleaseChainMagicCirclesAsync(this.GetCancellationTokenOnDestroy()).Forget();

        // 업적 신호: 적 사망 시점의 전 카드 활성 상태. 그리드는 이후 정리되므로 지금 캡처.
        if (victory && EventManager.HasInstance)
        {
            bool allActive = _grid != null && _grid.AreAllPlacedCardsActive();
            EventManager.Instance.Publish(new EnemyDefeatedSignal(allActive));
        }

        if (_cardHand != null)
        {
            _cardHand.Close();
        }

        CompleteBattleAsync(victory).Forget();
    }

    private async UniTask CompleteBattleAsync(bool victory)
    {
        CancellationToken token = this.GetCancellationTokenOnDestroy();
        bool isEscapeVictory = victory && _isTutorialEnemyEscapeVictory;
        try
        {
            // 적 사망 연출과 동기화: 사망 SFX 재생 + BGM 을 소멸 연출 길이에 맞춰 보상 볼륨까지 낮춤.
            // 맵·전투가 같은 곡을 공유하므로 여기서 정지하면 맵 복귀 때 곡이 처음부터 다시 시작된다.
            // 볼륨만 낮추면 전리품 창 → 맵까지 같은 곡이 끊기지 않고 이어진다.
            // (패배 시에는 InGameController.HandleBattleFinished 가 곡을 완전히 정지한다)
            if (AudioManager.HasInstance)
            {
                if (!isEscapeVictory)
                    AudioManager.Instance.PlaySfxAsync(AudioKeys.Battle.ENEMY_DEATH).Forget();

                float duckDuration = _enemyObj != null && _enemyObj.View != null
                    ? _enemyObj.View.DeathMotionDuration
                    : 0.5f;
                AudioManager.Instance.FadeBgmVolume(AudioKeys.BgmVolume.REWARD, duckDuration);
            }

            if (victory && !isEscapeVictory && _enemyObj != null && _enemyObj.View != null)
            {
                UIBattle battleUI = UIManager.HasInstance ? UIManager.Instance.Get<UIBattle>() : null;
                if (battleUI != null)
                {
                    await battleUI.WaitForEnemyHpTweenAsync(token);
                }
                if (token.IsCancellationRequested) return;

                await _enemyObj.View.PlayDeathMotionAsync(token);
            }
            else if (!victory && _playerObj != null && _playerObj.View != null)
            {
                await _playerObj.View.PlayDefeatAnimationAsync(token);
            }
        }
        catch (OperationCanceledException)
        {
            return;
        }

        if (token.IsCancellationRequested) return;

        if (victory)
        {
            _playerObj?.View?.PlayVictoryAnimation();
        }

        OnBattleFinished?.Invoke(victory);
    }

    private void RestorePersistentState(Card card)
    {
        if (card == null || _dispatcher == null || _currentContext?.GetPersistentState == null) return;
        RunCardPersistentState state = _currentContext.GetPersistentState(card.RunDeckEntryId, false);
        _dispatcher.RestorePersistentState(card, state);
    }

    private void CaptureBattleDurationState()
    {
        if (_dispatcher == null || _deckSystem == null) return;

        _cardScratch.Clear();
        _deckSystem.GetAllCards(_cardScratch);
        if (_grid != null)
        {
            foreach (Card card in _grid.PlacedCards)
            {
                if (card != null && !_cardScratch.Contains(card))
                {
                    _cardScratch.Add(card);
                }
            }
        }

        for (int i = 0; i < _cardScratch.Count; i++)
        {
            Card card = _cardScratch[i];
            if (card == null) continue;

            _dispatcher.ClearDurationState(card, EEffectDuration.EndOfBattle);

            if (card.RunDeckEntryId <= 0 || _currentContext?.GetPersistentState == null) continue;
            RunCardPersistentState state = _currentContext.GetPersistentState(card.RunDeckEntryId, true);
            _dispatcher.CapturePersistentState(card, state);
            _currentContext.TrimPersistentState?.Invoke(card.RunDeckEntryId);
        }
    }

    /// <summary>
    /// 카드의 그리드 월드 위치 조회 (투사체 출발점). presenter 에 주입되는 람다 대상.
    /// GridManager 가 배치 카드의 월드 위치를 제공하는 API 를 사용한다.
    /// </summary>
    /// <returns>배치 위치(월드). 그리드에 없으면 null → 연출 생략.</returns>
    private Vector3? ResolveCardWorldPosition(Card card)
    {
        if (_grid == null || card == null) return null;

        if (_grid.TryGetCardWorldPosition(card, out Vector3 pos))
        {
            return pos;
        }
        return null;
    }

    // ─────────────────────────────────────────────
    // 해제
    // ─────────────────────────────────────────────

    /// <summary>
    /// 전투 배경을 보장 로드한다. 같은 키면 재사용하고, 다른 키면 새 배경 로드 성공 후 교체한다.
    /// </summary>
    private async UniTask EnsureBattleBackgroundAsync(string requestedKey, CancellationToken token)
    {
        string key = string.IsNullOrEmpty(requestedKey) ? _battleBgKey : requestedKey;
        if (string.IsNullOrEmpty(key)) return;

        if (_battleBgObj != null && string.Equals(_loadedBattleBgKey, key, StringComparison.Ordinal))
        {
            if (_battleBgScroller == null)
                _battleBgScroller = _battleBgObj.GetComponent<BattleBackgroundParallaxScroller>();
            return;
        }
        if (!ResourceManager.HasInstance) return;

        try
        {
            GameObject bg = await ResourceManager.Instance
                .InstantiateAsync<GameObject>(key, _battleBgAnchor, token);

            if (bg == null)
            {
                Debug.LogWarning($"[BattleController] 전투 배경 생성 결과가 null — 키 확인: {key}");
                return;
            }

            GameObject previousBg = _battleBgObj;
            _battleBgObj = bg;
            _battleBgScroller = bg.GetComponent<BattleBackgroundParallaxScroller>();
            _loadedBattleBgKey = key;
            ReleaseBattleBackgroundInstance(previousBg);
        }
        catch (OperationCanceledException)
        {
            // 전투 취소 — 배경 핸들은 InstantiateAsync 가 내부 회수. 별도 처리 없음.
        }
        catch (Exception ex)
        {
            Debug.LogWarning($"[BattleController] 전투 배경 로드 실패 — 기존 배경 유지: {key} ({ex.Message})");
        }
    }

    /// <summary>전투 배경 인스턴스 해제 (InstantiateAsync 짝).</summary>
    private void ReleaseBattleBackground()
    {
        ReleaseBattleBackgroundInstance(_battleBgObj);
        _battleBgObj = null;
        _battleBgScroller = null;
        _loadedBattleBgKey = null;
    }

    private void ReleaseBattleBackgroundInstance(GameObject instance)
    {
        if (instance == null) return;

        if (ResourceManager.HasInstance)
        {
            ResourceManager.Instance.ReleaseInstance(instance);
        }
        else
        {
            Destroy(instance);
        }
    }

    /// <summary>전투 부속 해제 — 구독 해제 + Addressable 매니저 해제 (중복 호출 안전).</summary>
    public void ReleaseBattle()
    {
        // 진행 중인 준비/조우 연출을 먼저 중단해, 아래에서 해제할 필드를 await 연속부가 참조하지 않게 한다.
        DisposeCts();

        if (_grid != null)
        {
            _grid.SetCardInfoHidden(false);
            _grid.OnCardInfoHiddenChanged -= HandleCardInfoHiddenChanged;
        }
        StopBlindPoisonVfx();
        _bossPhaseScreenRipple?.Stop();
        ClearBossPhaseTransitionVfx();
        ReleaseBossPhaseAudio();
        _grid?.ClearEnemyLineIntentWarning();
        _grid?.EndLineAttackVfx();
        _grid?.RestoreBrokenSlotsImmediate();
        _enemyHandler?.SetGridLineAttackHandler(null);
        _enemyHandler?.SetEraseInfoHandler(null);
        _enemyHandler?.SetAttackMotionHandler(null);
        _enemyHandler?.SetEliteBuffController(null);
        _eliteBuffController?.Dispose();
        _eliteBuffController = null;
        _currentLineAttackPlans.Clear();

        if (_deckSystem != null)
        {
            _deckSystem.OnCardDrawn -= HandleCardDrawn;
            _deckSystem.OnDrawFailedNoCards -= HandleDrawFailedNoCards;
            _deckSystem.OnDrawDiscardedHandFull -= HandleDrawDiscardedHandFull;
            _deckSystem.OnCardDiscarded -= HandleCardDiscarded;
            _deckSystem.OnCardExhausted -= HandleCardDiscarded;
        }
        if (_battle != null)
        {
            _battle.SetEnemyPhaseTransitionStartedHandler(null);
            _battle.SetEnemyPhaseTransitionHandler(null);
            _battle.OnPhaseChanged -= HandlePhaseChanged;
            _battle.OnBattleEnded -= HandleBattleEnded;
            _battle.OnBeforeEnemyAction -= HandleBeforeEnemyAction;
            _battle.OnBeforeEnemyActionAsync -= HandleBeforeEnemyActionAsync;
            _battle.OnCardPlaced -= HandleBattleCardPlaced;
            _battle.OnCardToggled -= HandleBattleCardToggled;
            _battle.OnChainEndedAsync -= HandleBattleChainEndedAsync;
        }
        if (_chain != null)
        {
            _chain.OnCardActivatedInChainAsync -= HandleChainMilestoneAttackAsync;
        }

        // 전투 대표 객체 풀 반환 (적/플레이어).
        _vfxPresenter?.ClearCastingOrbs();
        UnbindEnemyDamageNumber();
        DespawnEnemyObject();
        UnbindPlayerDamageNumber();
        UnbindPlayerReactiveEvents();
        if (_playerObj != null && PoolManager.HasInstance)
        {
            PoolManager.Instance.Despawn(_playerObj);
        }
        _playerObj = null;

        // 전투 배경 해제 (InstantiateAsync 짝 — RefCount 정리).
        ReleaseBattleBackground();
        ReleaseChainMagicCirclesImmediate();

        _battle = null;
        _grid = null;
        _reactiveEvents?.Clear();
        _reactiveEvents = null;
        _reactiveToggleQueue?.Clear();
        _reactiveToggleQueue = null;

        // 이번 전투 적 데이터 참조 해제 (다음 전투에서 재주입).
        _currentEnemyData = null;
        _currentContext = null;
        _isTutorialEnemyEscapeVictory = false;

        // UI 참조는 UIBattle 소유물 → 해제 책임 없음. 끊기만 함 (다음 전투 때 재수령).
        _cardHand = null;
        _placementController = null;

        _assembled = false;
        IsBattleRunning = false;
    }

    private void DisposeCts()
    {
        if (_cts != null)
        {
            _cts.Cancel();
            _cts.Dispose();
            _cts = null;
        }
    }

    private static string Localize(string key)
    {
        return LocalizationManager.HasInstance
            ? LocalizationManager.Instance.Get(key)
            : key;
    }

    protected override void OnDestroy()
    {
        if (_player != null)
            _player.OnHpChanged -= HandlePlayerHpChanged;
        OnPilesChanged = null;

        ReleaseBattle();
        DisposeCts();
        OnBattleFinished = null;
        base.OnDestroy();
    }
}
