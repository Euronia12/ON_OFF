// =================================================================
// [스크립트 목적]  인게임 씬 컨트롤러.
// [의존 관계]      SceneFlowManager, GameFlowManager, UIManager,
//                  AudioManager, InputManager, DataManager
// [배치]           인게임 씬에 빈 GameObject 만들고 부착
// =================================================================

using System.Threading;
using Cysharp.Threading.Tasks;
using UnityEngine;

public class RyeolController : SceneSingleton<RyeolController>, ISceneLifecycle
{
    // ─────────────────────────────────────────────
    // Inspector
    // ─────────────────────────────────────────────

    [Header("테스트")]
    [SerializeField] private RyeolTestManager _testManager;

    // ─────────────────────────────────────────────
    // Private
    // ─────────────────────────────────────────────

    private CancellationTokenSource _cts;
    private bool _enteredViaTransition;
    private bool _sceneEntered;

    // ─────────────────────────────────────────────
    // Unity
    // ─────────────────────────────────────────────

    protected override void Awake()
    {
        base.Awake();
        _cts = new CancellationTokenSource();
        if (SceneFlowManager.HasInstance)
            SceneFlowManager.Instance.RegisterLifecycle(this);
    }

    private void Start()
    {
        if (!_enteredViaTransition)
            DirectStartAsync().Forget();
    }

    private async UniTaskVoid DirectStartAsync()
    {
        await BootstrapInitializer.WaitForReadyAsync();
        await OnSceneEnter(_cts.Token);
        OnSceneReady();
    }

    // ─────────────────────────────────────────────
    // ISceneLifecycle
    // ─────────────────────────────────────────────

    public async UniTask OnSceneEnter(CancellationToken token)
    {
        if (_sceneEntered) return;
        _sceneEntered = true;
        _enteredViaTransition = true;

        GameFlowManager.Instance.SetState(EGameState.Loading);

        // 1. 데이터 확인
        if (DataManager.HasInstance && !DataManager.Instance.IsLoaded)
            await DataManager.Instance.PreloadAllAsync(null, token);

        // 2. UI 열기
        await UIManager.Instance.OpenAsync<UIBattle>(token);

        // 3. 상태 전환
        GameFlowManager.Instance.SetState(EGameState.InGame);

        // 4. 입력 맵 전환
        if (InputManager.HasInstance)
            InputManager.Instance.SwitchMap(EActionMap.Gameplay);

        await ResourceManager.Instance.InstantiateAsync<GridBoard>();
    }

    public void OnSceneReady()
    {
        _testManager?.TestDrawAsync().Forget();

        
    }

    public async UniTask OnSceneExit(CancellationToken token)
    {
        if (UIManager.HasInstance)
            UIManager.Instance.CloseAll();

        if (AudioManager.HasInstance)
            AudioManager.Instance.StopBgm(fadeOut: 0.5f);

        await UniTask.CompletedTask;
    }

    // ─────────────────────────────────────────────
    // 정리
    // ─────────────────────────────────────────────

    protected override void OnDestroy()
    {
        base.OnDestroy();
        _cts?.Cancel();
        _cts?.Dispose();

        if (SceneFlowManager.HasInstance)
            SceneFlowManager.Instance.UnregisterLifecycle(this);
    }
}