// =================================================================
// [스크립트 목적]  "한 판(run)" 컨트롤러 = Run Flow 총괄.
//                 시드 기반 노드맵 등반: 맵→노드선택→(전투/비전투)→보상→복귀→...→보스→클리어.
//                 ★ 전투 입력(덱·적)을 결정해 BattleStartContext 로 BattleController 에 위임.
// [주요 변수]      - _startingDeck : 시작 덱 종류 (런 덱 초기화)
//                  - _mapData      : 노드맵 생성 파라미터 SO
//                  - _run          : 런 컨텍스트 (시드/층/누적덱/맵/현재노드)
//                  - _enemyPool    : 적 후보 풀 (DataManager 1회 수령. 배정·해석에 사용)
//                  - _startingDeckProvider : 시작덱 ID 추출 헬퍼
//                  - _rewardService: 카드 쿼리·추첨 (보상 후보 생성)
// [의존 관계]      - BattleController (전투 위임, 단방향) / RunContext / EncounterAssigner
//                  - StartingDeckProvider / CardRewardService / BattleStartContext
//                  - UIRewardPopup(승리 전리품) / UICardSelectPopup(카드 1택) / UIGameOverPopup(패배) / UIManager / GameFlowManager / DataManager
//                  - EventManager (비전투 노드 위임: OnMapNodeEntered)
// [배치]           인게임 씬에 빈 GameObject + 부착 (MainController 와 동급)
// [역할 구분]      ★ InGameController = Run Flow / BattleController = Battle Logic
//                    - InGame → Battle 호출 가능 (단방향)
//                    - Battle → InGame 직접 참조 금지 (전투 종료는 OnBattleFinished 이벤트)
//                    - 적 결정·덱 구성·시드는 Run 이 담당 → BattleStartContext 로 주입
// [설계 노트]      - 슬더스식: 덱은 런 내내 유지(RunContext), 핸드/묘지는 전투마다 리셋.
//                  - 보상: 카드가 가진 분류(pools/rarity/unlock)를 CardRewardService 로 쿼리
//                    (보상 테이블 SO 없음). 시드 공유로 재현.
//                  - 시드: 입력 시드 1개 → RunContext.Rng 파생 → 맵/적/보상 재현.
// =================================================================

using System;
using System.Collections.Generic;
using System.Threading;
using Cysharp.Threading.Tasks;
using UnityEngine;
using UnityEngine.Serialization;

/// <summary>
/// 시드 기반 노드맵 등반 런 컨트롤러 (Run Flow).
/// 맵에서 노드를 선택해 전투/비전투를 진행하고, 전투는 BattleStartContext(덱·적)를 조립해
/// BattleController 에 위임한다. 전투 종료는 OnBattleFinished 이벤트로만 수신한다.
/// 적 결정·덱 구성·보상 추첨 등 런 흐름 책임을 전담하며, 전투 내부 로직은 모른다.
/// </summary>
public sealed class InGameController : SceneSingleton<InGameController>
{
    [Header("런 설정")]
    [Tooltip("이번 런의 시작 덱 종류. StartingDeckProvider 가 SO 에서 매칭")]
    [SerializeField] private EStartingDeck _startingDeck = EStartingDeck.Test;

    [Tooltip("튜토리얼처럼 기본 덱만 사용해야 하는 씬에서는 시작 카드팩 선택을 건너뜁니다.")]
    [SerializeField] private bool _skipStartCardPackSelection;

    [Tooltip("이번 런에서 단일 스테이지 모드로 사용할 스테이지 데이터")]
    [FormerlySerializedAs("_mapData")]
    [SerializeField] private StageDataSO _stageData;

    [Tooltip("시드 고정 사용 여부. 끄면 매 런 랜덤 시드")]
    [SerializeField] private bool _useFixedSeed = false;

    [Tooltip("고정 시드 값 (_useFixedSeed 가 켜졌을 때만 사용)")]
    [SerializeField] private int _fixedSeed = 12345;

    [Tooltip("현재 진행 중인 런 시드. 플레이 중 재현 확인용으로 인스펙터에 표시됩니다.")]
    [SerializeField] private int _currentSeed;

    [Header("플레이어 시작 스탯 (공유 설정)")]
    [Tooltip("최대체력/최대마나/드로우/보존 시작 기본치의 단일 소유처. BattleController 와 같은 에셋을 물린다.")]
    [SerializeField] private PlayerStatConfigSO _statConfig;

    [Header("보상")]
    [Tooltip("전투 승리 보상으로 제시할 카드 후보 장수")]
    [Min(1)]
    [SerializeField] private int _rewardCount = 3;

    [Tooltip("런 시작 시 보유 골드 (슬더스 기본 99)")]
    [Min(0)]
    [SerializeField] private int _startingGold = 99;

    [Header("보상 — 골드 (등급별 범위, x=min y=max)")]
    [Tooltip("일반 전투 승리 골드 범위 (슬더스 기본 10~20)")]
    [SerializeField] private Vector2Int _goldNormal = new Vector2Int(10, 20);

    [Tooltip("엘리트 전투 승리 골드 범위 (슬더스 기본 25~35)")]
    [SerializeField] private Vector2Int _goldElite = new Vector2Int(25, 35);

    [Tooltip("보스 전투 승리 골드 범위 (슬더스 기본 95~105)")]
    [SerializeField] private Vector2Int _goldBoss = new Vector2Int(95, 105);

    [Header("런 클리어 연출")]
    [Tooltip("마지막 보스 격파 시 생성할 Addressable 클리어 프리팹 키")]
    [SerializeField] private string _runClearSequenceKey = "RunClearSequence";

    [Tooltip("전투 화면을 가리고 이미지 컷씬을 열 때의 검정 페이드 시간(초)")]
    [Min(0f)]
    [SerializeField] private float _runClearInitialFadeDuration = 1f;

    [Tooltip("이미지 컷씬과 패럴랙스 루프 사이의 흰색 페이드 시간(초)")]
    [Min(0f)]
    [SerializeField] private float _runClearWhiteFadeDuration = 0.5f;

    [Tooltip("완전히 흰 화면을 유지하는 최소 시간(초). Addressable 로드가 더 길면 로드 완료까지 유지합니다.")]
    [Min(0f)]
    [SerializeField] private float _runClearWhiteHoldDuration = 0.5f;

    [Tooltip("패럴랙스 루프에서 결과 화면으로 전환할 때의 검정 페이드 시간(초)")]
    [Min(0f)]
    [SerializeField] private float _runClearResultFadeDuration = 0.5f;

    /// <summary>런 진행 중 여부.</summary>
    public bool IsRunActive { get; private set; }

    // 현재 열려 있는 ESC 런 메뉴 (열림 토글·중복 방지용).
    private UISystemEscMenu _escMenu;
    // ESC 메뉴에서 연 도감. 타이틀 도감과 닫힘 복귀 경로를 분리하기 위한 전용 참조.
    private UICardPileViewer _escCollectionViewer;

    /// <summary>인스펙터에 지정된 기본 시작 덱. None이면 MainController가 덱 선택 UI를 연다.</summary>
    public EStartingDeck StartingDeck => _startingDeck;

    /// <summary>이번 런에 선택된 캐릭터. 전투 스킬 패널이 캐릭터 전용 스킬을 로드할 때 참조. 미선택 시 null.</summary>
    public CharacterSO SelectedCharacter { get; private set; }

    /// <summary>캐릭터 선택 UI(또는 외부)에서 이번 런의 캐릭터를 지정한다.</summary>
    public void SetSelectedCharacter(CharacterSO character)
    {
        SelectedCharacter = character;
    }

    /// <summary>현재 런 컨텍스트 (맵·현재 노드 조회용). 런 비활성 시 null.</summary>
    public RunContext CurrentRun => _run;

    /// <summary>현재 스테이지 번호 (1-based). HUD 표기 "스테이지-층"의 스테이지 값.</summary>
    public int CurrentStageNumber => _currentStageIndex + 1;
    public ERunDifficulty CurrentDifficulty => _run != null
        ? _run.Difficulty
        : ERunDifficulty.Normal;
    public CardRarityWeights CurrentCardRewardRarityWeights => _stageSequence != null
        ? _stageSequence.CardRewardRarityWeights
        : CardRarityWeights.Default;


    /// <summary>
    /// 현재 스테이지의 맵 BGM 키. 상점·휴식·이벤트 등 팝업에서 맵으로 복귀할 때 이 값을 쓴다.
    /// StageDataSO가 유일한 키 소스이며, 미지정이면 재생하지 않는다.
    /// </summary>
    public string CurrentMapBgmKey => _currentStageData != null ? _currentStageData.MapBgmKey : null;

    // 런 상태 (시드/층/덱).
    private RunContext _run;

    // Run Flow 가 소유하는 전투 입력 결정자들 (★ BattleController 에서 이관).
    private List<EnemyDataSO> _enemyPool;            // 적 후보 풀 (DataManager 1회 수령)
    private StartingDeckProvider _startingDeckProvider; // 시작덱 ID 추출
    private CardRewardService _rewardService;        // 보상 카드 쿼리·추첨
    private StageSequenceSO _stageSequence;
    private StageDataSO _currentStageData;
    private int _currentStageIndex;
    private bool _singleStageMode;

    // 이번 전투 승리 보상 묶음(전리품). 승리 시 생성, 수령/다음전투 진행 시 해제.
    // (다음 단계) 통합 보상창 UI 가 이 묶음을 읽어 표시·클릭 수령한다.
    private BattleReward _currentReward;
    private bool _cardRewardApplied;

    private CancellationToken _runToken;
    private CancellationTokenSource _lifetimeCts;
    private bool _battleSubscribed;
    private bool _isEnteringBattle;
    private bool _skipNextShopEntryFade;
    private bool _canSaveRunProgress;
    private bool _isEventEffectApplicationInProgress;
    private bool _isCompletingRun;
    private RunClearPresenter _runClearPresenter;
    private RunSaveData _eventEffectSnapshot;
    private RunSaveData _eventEffectInitialSnapshot;
    // 보스 보상 수령 후 연출이 끝나기 전에는 생명주기 저장도 다음 스테이지 체크포인트를 유지해야 한다.
    private bool _isStageTransitionPending;
    // 체크포인트가 확정한 다음 스테이지 인덱스. 연출 중 _currentStageIndex 가 먼저 증가하므로
    // 재계산하지 않고 이 값을 그대로 재사용한다(스테이지 건너뜀 방지). 미확정이면 -1.
    private int _pendingStageIndex = -1;
    private RunSaveData _restoringSaveData;
    private string _currentRunId = string.Empty;
    private float _runStartedAt;
    private string _statisticsSnapshotRunId = string.Empty;
    private int _currentBattleTurnCount;

    public RunStatisticsSnapshot LastRunStatistics { get; private set; }
    public int LastCompletedBattleTurnCount { get; private set; }

    private CancellationToken LifetimeToken => _lifetimeCts != null ? _lifetimeCts.Token : default;
    public string CurrentRunId => _currentRunId;

    // 이번 런에서 선택한 시작 카드팩 ID (분석용). 팩 선택을 건너뛰면 비어 있다.
    private readonly List<string> _selectedPackIds = new List<string>(2);

    /// <summary>이번 런에서 선택한 시작 카드팩 ID 목록.</summary>
    public IReadOnlyList<string> SelectedPackIds => _selectedPackIds;
    public int CurrentSeed => _currentSeed;

    public bool PreserveSkillCooldownBetweenBattles =>
        _stageSequence != null && _stageSequence.PreserveSkillCooldownBetweenBattles;

    public int GetAdditionalSkillCooldown(SkillDataSO skill)
        => _stageSequence != null ? _stageSequence.GetAdditionalSkillCooldown(skill) : 0;

    public int GetStoredSkillCooldown(string skillId)
    {
        if (!PreserveSkillCooldownBetweenBattles || _run == null) return 0;
        return _run.TryGetSkillCooldown(skillId, out int remainingTurns)
            ? remainingTurns
            : 0;
    }

    public void StoreSkillCooldown(string skillId, int remainingTurns)
    {
        if (_run == null) return;
        if (!PreserveSkillCooldownBetweenBattles)
        {
            _run.ClearSkillCooldowns();
            return;
        }

        _run.SetSkillCooldown(skillId, remainingTurns);
    }

    protected override void OnAwakeInternal()
    {
        _lifetimeCts = new CancellationTokenSource();
    }

    // -------------------------------------------------
    // 런 시작/종료 (MainController 가 호출)
    // -------------------------------------------------

    /// <summary>한 판 시작. 시드 런 컨텍스트를 구성하고 첫 맵 UI 표시까지 기다린다.</summary>
    public UniTask BeginRunAsync(CancellationToken token = default)
        => BeginRunAsync(_startingDeck, token);

    public async UniTask BeginRunAsync(EStartingDeck deckType, CancellationToken token = default)
    {
        if (IsRunActive)
        {
            Debug.LogWarning("[InGameController] 이미 런이 진행 중입니다.");
            return;
        }

        RunSaveSystem.Clear();

        _startingDeck = deckType == EStartingDeck.None
            ? _startingDeck
            : deckType;
        IsRunActive = true;
        _canSaveRunProgress = false;
        _isStageTransitionPending = false;
        _pendingStageIndex = -1;
        ClearEventEffectTransaction();
        _runToken = token;

        // 1) 시드 결정 -> 런 컨텍스트 생성.
        int seed = DebugCommandManager.ResolveNewRunSeed(
            _useFixedSeed ? _fixedSeed : System.Environment.TickCount);
        _currentSeed = seed;
        ERunDifficulty difficulty = _stageData != null
            ? ERunDifficulty.Normal
            : RunLaunchOptions.ConsumeNewRunDifficulty();
        _run = new RunContext(seed, _startingDeck, difficulty);
        _run.OnHpChanged += HandleRunHpChanged;   // 전투 밖 HP 변동(휴식·이벤트·비용) 중계
        _currentRunId = $"run_{seed}_{System.DateTime.UtcNow.Ticks}";
        _runStartedAt = GetCurrentSessionPlaySeconds();
        LastRunStatistics = null;
        LastCompletedBattleTurnCount = 0;
        _statisticsSnapshotRunId = string.Empty;
        if (GameManager.HasInstance)
            GameManager.Instance.NotifyRunStarted();
        InitializeAvailableCardPool();

        // 2) 시작 덱 ID 로 누적 덱 초기화 (StartingDeckProvider 가 SO ID 목록 제공).
        EnsureStartingDeckProvider();
        List<string> startingIds = _startingDeckProvider.GetStartingDeckCardIds(_startingDeck);
        _run.InitializeDeck(startingIds);
        InitializeRunDeckArrowDirections();

        _selectedPackIds.Clear();
        if (!_skipStartCardPackSelection)
            await SelectStartCardPacksAsync(token);

        // 시드·시작덱·카드팩이 모두 확정된 시점. 분석 등 외부 구독자에 런 시작 통지.
        OnRunStarted?.Invoke();

        // 시작 골드 지급 (GrantGold → OnGoldChanged 발행. HUD 는 열릴 때 현재값도 읽음).
        GrantGold(_startingGold, playAudio: false, applyDifficultyModifier: false);

        if (_statConfig == null)
            Debug.LogWarning("[InGameController] PlayerStatConfigSO 미할당 — 기본 폴백값(50/3/5/3)을 사용합니다.");

        // 런 스탯 초기화 — 공유 설정(PlayerStatConfigSO)에서 시작 기본치를 복사.
        _run.InitializeHp(ConfigMaxHp);
        _run.InitializePreserve(ConfigPreserveAll, ConfigMaxPreserve);
        _run.InitializeMana(ConfigMaxMana);
        _run.InitializeDraw(ConfigDrawPerTurn);

#if UNITY_EDITOR || DEVELOPMENT_BUILD
        Debug.Log($"[InGameController] 런 시작 - difficulty={RunDifficultyUtility.ToLogValue(CurrentDifficulty)}, " +
                  $"seed={seed}, 시작덱={_run.DeckCardIds.Count}장");
#endif

        // 3) 노드맵 생성 (런 시드로 절차 생성 -> 같은 시드는 같은 맵).
        StageDataSO initialStage = ResolveInitialStageData();
        if (!GenerateCurrentMap(initialStage))
        {
            IsRunActive = false;
            _canSaveRunProgress = false;
            _currentSeed = 0;
            return;
        }

        _canSaveRunProgress = true;
        SaveRunProgress(currentNodeResolved: true);

        // 최초 실행으로 튜토리얼에 자동 진입한 경우에만 시작 확인을 먼저 기다린다.
        // 패널 로드 실패는 기존 진입 흐름으로 폴백하지만, 버튼 외 경로로 닫히면 진행하지 않는다.
        UIFirstStarPanel firstLaunchPanel = await WaitForFirstLaunchTutorialStartAsync(token);

        try
        {
            // 4) 진입 Notice 로 화면을 먼저 덮고 -> 그 뒤에서 상단 정보 바와 맵을 표시 -> Notice 를 걷어
            //    플레이어의 첫 노드 선택을 기다린다. (UIStageNotice 가 UIMap 보다 먼저 열려야 함)
            UISystemStageNotice notice = await OpenStageNoticeAsync(token);
            if (notice != null)
            {
                await notice.PlayStageEnterAsync(async noticeToken =>
                {
                    // Stage Notice가 검은 배경을 먼저 덮은 뒤 First Star 연출의 암전을 넘겨받는다.
                    if (firstLaunchPanel != null)
                        firstLaunchPanel.ReleaseForStageNotice();
                    await OpenTopInfoAsync(noticeToken);
                    await PresentMapAsync(noticeToken);
                }, token);
            }
            else
            {
                await OpenTopInfoAsync(token);
                await PresentMapAsync(token);
                if (firstLaunchPanel != null)
                    firstLaunchPanel.ReleaseForStageNotice();
            }

            // 안내가 걷혀 맵이 보이는 시점에 스테이지 진입 연출(보스→시작 지점) 재생.
            PlayMapIntroIfPending();
        }
        finally
        {
            // 최종 암전 이후 취소/예외가 발생해도 입력 차단 패널과 월드 연출을 남기지 않는다.
            if (firstLaunchPanel != null && firstLaunchPanel.IsOpen)
                firstLaunchPanel.ReleaseForStageNotice();
        }
    }

    public async UniTask<bool> BeginSavedRunAsync(
        RunSaveData saveData,
        CancellationToken token = default,
        bool showStageNotice = true,
        bool fallbackToNewRunWhenInvalid = true)
    {
        if (IsRunActive)
        {
            Debug.LogWarning("[InGameController] 이미 런이 진행 중입니다.");
            return false;
        }

        if (saveData == null)
        {
            await BeginRunAsync(token);
            return false;
        }

        _startingDeck = (EStartingDeck)saveData.selectedDeckType;
        SelectedCharacter = ResolveSavedCharacter(saveData);
        IsRunActive = true;
        _canSaveRunProgress = false;
        _isStageTransitionPending = false;
        _pendingStageIndex = -1;
        ClearEventEffectTransaction();
        _runToken = token;
        _restoringSaveData = saveData;
        _currentSeed = saveData.seed;

        ERunDifficulty savedDifficulty = RunDifficultyUtility.Normalize((ERunDifficulty)saveData.difficulty);
        _run = new RunContext(saveData.seed, _startingDeck, savedDifficulty);
        _run.OnHpChanged += HandleRunHpChanged;   // 전투 밖 HP 변동(휴식·이벤트·비용) 중계
        _currentRunId = $"run_{saveData.seed}_{System.DateTime.UtcNow.Ticks}";
        _runStartedAt = GetCurrentSessionPlaySeconds();
        LastRunStatistics = null;
        LastCompletedBattleTurnCount = 0;
        _statisticsSnapshotRunId = string.Empty;
        if (GameManager.HasInstance)
            GameManager.Instance.NotifyRunStarted();

        InitializeAvailableCardPool();

        StageDataSO stage = ResolveSavedStageData(saveData.currentStageIndex);
        if (!GenerateCurrentMap(stage))
        {
            IsRunActive = false;
            _canSaveRunProgress = false;
            _restoringSaveData = null;
            _currentSeed = 0;
            return false;
        }

        // 맵 무효화 검사: 저장 당시의 맵 생성 알고리즘 버전이 현재와 다르거나,
        // 재생성한 맵에서 저장된 노드 위치를 되살리지 못하면(위치 유실) 이어하기를 포기한다.
        bool invalidSave = saveData.mapVersion != MapGenerator.AlgorithmVersion;

        // 구버전 전환 롤백이 남긴 고착 세이브(진행 수단 0) 복구.
        // 다음 스테이지가 있으면 승격하고, 없으면(최종 보스 클리어 직후 고착) 되살릴 방법이
        // 없으므로 이어하기를 무효화해 안내 후 새 런으로 넘긴다.
        bool repairedStuckSave = false;
        if (!invalidSave && IsStuckLegacySave(saveData))
        {
            repairedStuckSave = TryPromoteStuckSaveToNextStage(saveData);
            if (!repairedStuckSave)
            {
                Debug.LogWarning(
                    "[InGameController] 고착 세이브인데 승격할 다음 스테이지가 없습니다 — 이어하기를 무효화합니다.");
                invalidSave = true;
            }
        }

        if (!invalidSave)
            invalidSave = !_run.RestoreFromSave(saveData);

        if (!invalidSave)
            EventController.AssignMapEvents(_run, _run.Map, _currentStageIndex);

        if (invalidSave)
        {
            Debug.LogWarning(
                $"[InGameController] 저장 맵 불일치(saveVer={saveData.mapVersion}, " +
                $"cur={MapGenerator.AlgorithmVersion}) — 이어하기를 무효화하고 신규 런으로 전환합니다.");

            IsRunActive = false;
            _canSaveRunProgress = false;
            _run = null;
            _restoringSaveData = null;
            _currentSeed = 0;
            RunSaveSystem.Clear();

            if (!fallbackToNewRunWhenInvalid)
                return false;

            await NotifySavedRunResetAsync(token);
            if (token.IsCancellationRequested) return false;

            await BeginRunAsync(_startingDeck, token);
            return false;
        }

        // 보존 한도: 저장값이 유효하면(>0) 그대로 두어 런 중 이벤트 성장을 유지하고,
        // 구버전·손상으로 0 이하이면 인스펙터 초기치로 폴백한다(0 복원 방지).
        if (_run.MaxPreserveCount <= 0)
            _run.InitializePreserve(ConfigPreserveAll, ConfigMaxPreserve);
        // 마나·드로우: 구버전 세이브(0)면 설정 초기치로 폴백, 유효하면 복원값 유지(이벤트 성장 보존).
        if (_run.MaxMana <= 0) _run.InitializeMana(ConfigMaxMana);
        if (_run.DrawPerTurn <= 0) _run.InitializeDraw(ConfigDrawPerTurn);
        _canSaveRunProgress = true;

        // 복구된 저장은 이미 다음 맵이 생성된 상태이므로 일반 저장으로 즉시 정규화한다.
        // 이때 version 이 최신으로 기록되므로 다음 실행부터는 레거시 복구 분기를 다시 타지 않는다.
        if (repairedStuckSave)
            SaveRunProgress(currentNodeResolved: true);

        int removedMissingCards = PruneMissingRunDeckCards();
        if (removedMissingCards > 0)
        {
            RunSaveSystem.Save(
                _run,
                _currentStageIndex,
                SelectedCharacter != null ? SelectedCharacter.CharacterId : null,
                saveData.currentNodeResolved);
        }

        InitializeRunDeckArrowDirections();

        if (EventManager.HasInstance)
        {
            EventManager.Instance.Publish(new OnGoldChanged
            {
                Current = _run.Gold,
                Delta = 0,
            });
        }

#if UNITY_EDITOR || DEVELOPMENT_BUILD
        Debug.Log(
            $"[InGameController] 저장 런 복원 - seed={_run.Seed}, stage={_currentStageIndex}, " +
            $"node={_run.CurrentNodeId}, deck={_run.DeckCardIds.Count}, gold={_run.Gold}");
#endif

        // 신규 시작과 분리해 분석 버퍼만 재개한다. run_start 중복 전송은 하지 않는다.
        OnRunResumed?.Invoke();

        if (!showStageNotice)
        {
            await OpenTopInfoAsync(token);
            await RestoreSavedRunPositionAsync(token);
            return true;
        }

        UISystemStageNotice notice = await OpenStageNoticeAsync(token);
        if (notice != null)
        {
            await notice.PlayStageEnterAsync(async noticeToken =>
            {
                await OpenTopInfoAsync(noticeToken);
                await RestoreSavedRunPositionAsync(noticeToken);
            }, token);
        }
        else
        {
            await OpenTopInfoAsync(token);
            await RestoreSavedRunPositionAsync(token);
        }

        return true;
    }

    /// <summary>런 종료 (씬 이탈/중단). 전투 부속 해제.</summary>
    public void EndRun()
    {
        if (!IsRunActive && _run == null) return;

        IsRunActive = false;
        _canSaveRunProgress = false;
        DebugCommandManager.ResetRunPendingOverrides();

        if (EventController.HasInstance)
            EventController.Instance.CancelActiveEvent();

        if (_escMenu != null)
        {
            if (UIManager.HasInstance) UIManager.Instance.Close(_escMenu);
            _escMenu = null;
        }
        DetachEscCollectionViewer();
        // 런 종료 시 상단 정보 바도 닫는다 (런 단위 HUD).
        if (UIManager.HasInstance)
            UIManager.Instance.Close<UINoticeTopInfo>();

        UnsubscribeBattle();

        if (BattleController.HasInstance)
        {
            BattleController.Instance.ReleaseBattle();
        }

        _run = null;
        _rewardService = null; // 다음 런에서 재생성 (해방 상태 갱신 반영)
        _stageSequence = null;
        _currentStageData = null;
        _currentStageIndex = 0;
        _singleStageMode = false;
        ClearStageTransitionPending();
        ClearEventEffectTransaction();
        _restoringSaveData = null;
        _currentSeed = 0;
        _currentReward = null; // 보상 묶음 폐기 (런 단위 — 다음 전투에서 재생성)
        _cardRewardApplied = false;
        _skipNextShopEntryFade = false;
        // _enemyPool / _startingDeckProvider 는 데이터 캐시라 유지 (런마다 재구축 불필요).
    }

    // -------------------------------------------------
    // 노드맵 흐름
    // -------------------------------------------------

    /// <summary>맵을 표시하고 플레이어의 노드 선택을 기다린다.</summary>
    private void PresentMap()
    {
        if (_run == null) return;

        if (GameFlowManager.HasInstance)
        {
            GameFlowManager.Instance.SetState(EGameState.InGame);
        }

        PresentMapAsync(_runToken).Forget();
    }

    // 보상 수령 등 노드 종료 후 맵 복귀 시 화면 페이드 시간(초). 기본 전환보다 약간 여유 있게.
    private const float MapReturnFadeDuration = 0.8f;

    /// <summary>
    /// 노드 종료(전투 보상 수령 등) → 맵 복귀를 화면 페이드로 감싸 전환한다.
    /// BGM 크로스페이드 핸드오프는 화면 전환(RunWithFadeAsync)이 소유한다:
    /// bgmKey 를 넘기면 전환 시작과 함께 맵 BGM 으로 크로스페이드하고, 그 길이가 전환 창에
    /// 결속되어(≈2×페이드) 화면이 다시 보일 때쯤 완료 → 크로스페이드는 유지하되 잔재는 안 남는다.
    /// </summary>
    private async UniTaskVoid PresentMapWithFadeAsync(CancellationToken token)
    {
        if (_run == null) return;

        if (GameFlowManager.HasInstance)
            GameFlowManager.Instance.SetState(EGameState.InGame);

        // 페이드가 불가능한 상황(이미 전환 중 등)이면 기존 즉시 전환으로 폴백.
        if (!SceneFlowManager.HasInstance || SceneFlowManager.Instance.IsTransitioning)
        {
            await PresentMapAsync(token);
            return;
        }

        // 맵 UI 구성만 암전 콜백에서 하고, 맵 BGM 크로스페이드는 전환 프리미티브에 위임(bgmKey).
        // 전투와 같은 곡을 공유하므로 대개 재생이 유지된 채 맵 볼륨으로만 내려간다.
        await SceneFlowManager.Instance.RunWithFadeAsync(
            OpenMapUiAsync,
            token,
            MapReturnFadeDuration,
            bgmKey: CurrentMapBgmKey,
            bgmVolume: AudioKeys.BgmVolume.MAP);
    }

    /// <summary>페이드 없이 맵을 표시한다(런 시작·재개·스테이지 전환 등). 맵 UI + 맵 BGM 크로스페이드를 직접 처리.</summary>
    /// <param name="playMapBgm">
    /// false 면 맵 BGM 으로 바꾸지 않고 현재 곡을 그대로 유지한다.
    /// 보스 격파 직후처럼 방금 클리어한 스테이지의 맵을 잠깐 보여주고 곧바로 다음 스테이지로
    /// 넘어가는 구간에서, 이전 스테이지 테마로 되돌아갔다가 다시 바뀌는 왕복을 막는다.
    /// </param>
    private async UniTask PresentMapAsync(CancellationToken token, bool playMapBgm = true)
    {
        await OpenMapUiAsync(token);
        if (token.IsCancellationRequested || !IsRunActive) return;

        // 페이드로 감싸지 않는 경로는 여기서 직접 맵 BGM 크로스페이드.
        // (페이드 경로는 RunWithFadeAsync 의 bgmKey 가 전환 창에 맞춰 처리하므로 여기 안 옴)
        if (playMapBgm && AudioManager.HasInstance)
            AudioManager.Instance.PlayBgmAsync(
                CurrentMapBgmKey, crossfade: 2f, volume: AudioKeys.BgmVolume.MAP).Forget();
    }

    /// <summary>
    /// 스테이지 첫 진입 연출(보스→시작 지점 훑기)이 대기 중이면 재생한다.
    /// 맵은 스테이지 안내(Notice) 뒤에서 미리 표시되므로, 안내가 걷힌 뒤
    /// (=플레이어에게 실제로 보이는 시점) 호출해야 연출이 가려지지 않는다.
    /// </summary>
    private static void PlayMapIntroIfPending()
    {
        UIMap map = UIManager.HasInstance ? UIManager.Instance.Get<UIMap>() : null;
        if (map != null) map.PlayIntroIfPending();
    }

    /// <summary>
    /// 맵 UI 를 열고(미리보기 해제) 상태 갱신을 통지한다. BGM 은 다루지 않는다 — BGM 전환은
    /// 페이드 경로에선 RunWithFadeAsync 가, 비페이드 경로에선 PresentMapAsync 가 소유한다.
    /// </summary>
    private async UniTask OpenMapUiAsync(CancellationToken token)
    {
        if (UIManager.HasInstance)
        {
            UIMap map = await UIManager.Instance.OpenAsync<UIMap>(token);

            // 미리보기(읽기 전용)로 열려 있던 지도도 여기서 노드 선택용으로 전환한다.
            if (map != null)
                map.SetPeekMode(false);
        }

        if (token.IsCancellationRequested || !IsRunActive) return;

        if (EventManager.HasInstance)
        {
            EventManager.Instance.Publish(new OnMapPresented { CurrentNodeId = _run.CurrentNodeId });
        }

#if UNITY_EDITOR || DEVELOPMENT_BUILD
        Debug.Log($"[InGameController] 맵 표시 - 현재 노드={_run.CurrentNodeId}, 선택지={_run.GetReachableNodes().Count}개");
#endif
    }

    /// <summary>플레이어가 노드를 선택했을 때 호출. 이동 검증 후 타입별 분기.</summary>
    /// <param name="nodeId">선택한 노드 ID.</param>
    public void SelectNode(int nodeId)
    {
        if (!IsRunActive || _run == null) return;

        // 이전 노드 이탈 통지 (분석 등). 전투 노드는 이 시점이면 보상 수령까지 끝나 있다.
        // 구독자가 없거나 열린 노드가 없으면 무동작이다.
        OnNodeExited?.Invoke();

        // 다음 노드로 이동하면 이전 보상 대기는 확정 종료(방어적 정리 — 정상 흐름은 continue 에서 해제).
        _run.ClearPendingReward();
        _run.ClearPendingEvent();

        if (!_run.MoveToNode(nodeId))
        {
            Debug.LogWarning($"[InGameController] 이동할 수 없는 노드입니다: {nodeId}");
            return;
        }

        MapNode node = _run.Map.GetNode(nodeId);
        if (node == null)
        {
            Debug.LogError($"[InGameController] 노드를 찾을 수 없습니다: {nodeId}");
            return;
        }

        DebugCommandManager.TryApplyPendingNodeOverrides(node);

        if (node.NodeType != ENodeType.Shop)
            _skipNextShopEntryFade = false;

#if UNITY_EDITOR || DEVELOPMENT_BUILD
        Debug.Log($"[InGameController] 노드 선택 - id={nodeId}, depth={node.Depth}, 타입={node.NodeType}");
#endif

        SaveRunProgress(currentNodeResolved: false);
        DispatchNode(node);
    }

    /// <summary>노드 타입별 분기. 전투 계열은 직접 전투 진입, 그 외는 이벤트 발행.</summary>
    private void DispatchNode(MapNode node, bool skipEntryFade = false)
    {
        // 노드 진입 통지 (분석 등). 타입 분기 전에 발행해 모든 노드가 동일하게 잡히도록 한다.
        OnNodeEntered?.Invoke(node);

        switch (node.NodeType)
        {
            case ENodeType.Battle:
            case ENodeType.Elite:
            case ENodeType.Boss:
            case ENodeType.Test:
                EnterBattleNode(skipEntryFade);
                break;

            case ENodeType.Event:
            case ENodeType.Shop:
            case ENodeType.Rest:
            case ENodeType.Treasure:
                EnterNonBattleNodeWithFadeAsync(node, skipEntryFade).Forget();
                break;

            default:
                CloseMap();
                Debug.LogWarning($"[InGameController] 알 수 없는 노드 타입: {node.NodeType}. 맵으로 복귀.");
                NotifyNodeResolved();
                break;
        }
    }

    /// <summary>
    /// 비전투 노드는 맵을 보인 채 암전한 뒤, 완전히 가려진 시점에 맵을 닫고 진입 이벤트를 발행한다.
    /// 구독 컨트롤러는 전환 중임을 감지해 여기서 소유한 페이드를 재사용한다.
    /// </summary>
    private async UniTaskVoid EnterNonBattleNodeWithFadeAsync(
        MapNode node,
        bool skipEntryFade = false)
    {
        async UniTask EnterNodeAsync(CancellationToken token)
        {
            if (SceneFlowManager.HasInstance &&
                !SceneFlowManager.Instance.IsFadeFullyCovered)
            {
                Debug.LogError("[InGameController] 페이드 차폐 전에 비전투 노드 UI를 처리하려 했습니다.");
                return;
            }

            CloseMap();

            // 상점·휴식은 페이드가 걷히기 전에 UI 생성까지 끝내야 해서 직접 연다.
            // 진입 통지는 별도로 발행한다 — 튜토리얼 등 관전 시스템이 이 이벤트로 동작하므로
            // 여기서 빠뜨리면 상점·휴식 트리거가 통째로 죽는다.
            if (node.NodeType == ENodeType.Shop && ShopController.HasInstance)
            {
                PublishNodeEntered(node);
                await ShopController.Instance.OpenFromMapNodeAsync(node.Id);
                return;
            }

            if (node.NodeType == ENodeType.Rest && RestController.HasInstance)
            {
                PublishNodeEntered(node);
                await RestController.Instance.OpenFromMapNodeAsync(node.Id);
                return;
            }

            if (EventManager.HasInstance)
            {
                EventManager.Instance.Publish(new OnMapNodeEntered
                {
                    NodeType = node.NodeType,
                    NodeId = node.Id,
                });

                // EventController는 이벤트 버스로 시작되므로, 실제 Event UI Open 완료까지
                // 명시적으로 기다려 페이드 인이 먼저 시작되지 않게 한다.
                if (node.NodeType == ENodeType.Event && EventController.HasInstance)
                {
                    bool ready =
                        await EventController.Instance.WaitUntilViewReadyAsync(token);
                    if (!ready)
                        Debug.LogWarning("[InGameController] Event UI 준비에 실패했습니다.");
                }
            }
            else
            {
                Debug.LogWarning("[InGameController] EventManager 부재 - 비전투 노드를 건너뜁니다.");
                NotifyNodeResolved();
            }
        }

        if (SceneFlowManager.HasInstance)
        {
            SceneFlowManager flow = SceneFlowManager.Instance;
            bool reuseCoveredFade =
                (skipEntryFade || flow.IsTransitioning) &&
                await WaitForFadeCoverageAsync(_runToken);

            if (reuseCoveredFade)
            {
                await EnterNodeAsync(_runToken);
                return;
            }

            if (!flow.IsTransitioning)
            {
                await flow.RunWithFadeAsync(
                    fadeToken => EnterNodeAsync(fadeToken),
                    _runToken);
                return;
            }

            Debug.LogError("[InGameController] 비전투 노드 진입용 페이드 차폐에 실패했습니다.");
            return;
        }

        Debug.LogWarning("[InGameController] SceneFlowManager 부재 - 페이드 없이 비전투 노드에 진입합니다.");
        await EnterNodeAsync(_runToken);
    }

    private static async UniTask<bool> WaitForFadeCoverageAsync(CancellationToken token)
    {
        if (!SceneFlowManager.HasInstance) return false;

        SceneFlowManager flow = SceneFlowManager.Instance;
        if (flow.IsFadeFullyCovered) return true;
        if (!flow.IsTransitioning) return false;

        await UniTask.WaitUntil(
            () => flow.IsFadeFullyCovered || !flow.IsTransitioning,
            cancellationToken: token);
        return flow.IsFadeFullyCovered;
    }

    /// <summary>노드 진입 통지 발행. 구독 컨트롤러가 아닌 관전 시스템(튜토리얼·분석)용.</summary>
    private static void PublishNodeEntered(MapNode node)
    {
        if (!EventManager.HasInstance) return;

        EventManager.Instance.Publish(new OnMapNodeEntered
        {
            NodeType = node.NodeType,
            NodeId = node.Id,
        });
    }

    /// <summary>비전투 노드 처리 완료 통지 → 맵 복귀.</summary>
    public void NotifyNodeResolved()
    {
        if (!IsRunActive || _run == null) return;
        SaveRunProgress(currentNodeResolved: true);
        PresentMap();
    }

    /// <summary>비전투 노드 UI를 가린 뒤 정리하고 맵으로 복귀한다.</summary>
    public async UniTask NotifyNodeResolvedWithFadeAsync(
        System.Action beforeMapPresented = null,
        bool skipNextShopEntryFade = false)
    {
        void Resolve()
        {
            beforeMapPresented?.Invoke();
            _skipNextShopEntryFade = skipNextShopEntryFade;
            NotifyNodeResolved();
        }

        if (!IsRunActive || _run == null)
        {
            beforeMapPresented?.Invoke();
            return;
        }

        if (SceneFlowManager.HasInstance && !SceneFlowManager.Instance.IsTransitioning)
        {
            await SceneFlowManager.Instance.RunWithFadeAsync(_ =>
            {
                Resolve();
                return UniTask.CompletedTask;
            });
            return;
        }

        Resolve();
    }

    /// <summary>
    /// 노드를 "해결"로 확정하지 않은 채 맵으로만 복귀한다.
    /// 이벤트 UI 가 실패·취소로 끝났을 때 쓰는 복구 경로 — 노드를 미해결로 남겨야
    /// 이어하기에서 저장된 체크포인트부터 다시 재개할 수 있다.
    /// (NotifyNodeResolvedWithFadeAsync 는 노드를 해결 확정하므로 이 경우에 쓰면 안 된다)
    /// </summary>
    public async UniTask ReturnToMapWithoutResolvingAsync(System.Action beforeMapPresented = null)
    {
        void Recover()
        {
            beforeMapPresented?.Invoke();
            SaveRunProgress(currentNodeResolved: false);
            PresentMap();
        }

        if (!IsRunActive || _run == null)
        {
            beforeMapPresented?.Invoke();
            return;
        }

        if (SceneFlowManager.HasInstance && !SceneFlowManager.Instance.IsTransitioning)
        {
            await SceneFlowManager.Instance.RunWithFadeAsync(_ =>
            {
                Recover();
                return UniTask.CompletedTask;
            });
            return;
        }

        Recover();
    }

    /// <summary>이벤트 직후 상점 진입에서만 중복 페이드를 건너뛴다.</summary>
    public bool ConsumeSkipNextShopEntryFade()
    {
        bool skip = _skipNextShopEntryFade;
        _skipNextShopEntryFade = false;
        return skip;
    }

    private async UniTask SelectStartCardPacksAsync(CancellationToken token)
    {
        List<StartCardPackSO> packs = LoadValidStartCardPacks();
        if (packs.Count == 0)
        {
            Debug.LogWarning($"[InGameController] 유효한 시작 카드팩이 {packs.Count}개입니다. 기본 덱으로 진행합니다.");
            return;
        }

        if (!UIManager.HasInstance)
        {
            Debug.LogWarning("[InGameController] UIManager가 없어 시작 카드팩 선택을 건너뜁니다.");
            return;
        }

        // 시작 카드팩 선택 화면 전용 BGM — 화면이 실제로 열리는 이 지점에서 재생한다.
        // _skipStartCardPackSelection 인 씬(튜토리얼)은 여기까지 오지 않으므로 자동으로 조용하다.
        // 덱 선택 화면을 먼저 거쳐 온 경우엔 같은 곡이라 AudioManager 가 재시작 없이 이어간다.
        if (AudioManager.HasInstance)
            AudioManager.Instance.PlayBgmAsync(AudioKeys.Bgm.CARD_PACK, crossfade: 2f).Forget();

        UIStartCardPackPopup.Show(packs, _run != null ? _run.Seed : 0);
        UIStartCardPackPopup popup = await UIManager.Instance.OpenAsync<UIStartCardPackPopup>(token);
        if (popup == null)
        {
            Debug.LogWarning("[InGameController] 시작 카드팩 팝업 로드에 실패해 기본 덱으로 진행합니다.");
            return;
        }

        var source = new UniTaskCompletionSource<IReadOnlyList<StartCardPackResult>>();
        void Confirm(IReadOnlyList<StartCardPackResult> selected) => source.TrySetResult(selected);
        popup.OnConfirmed += Confirm;

        try
        {
            IReadOnlyList<StartCardPackResult> selected = await source.Task.AttachExternalCancellation(token);

            // 선택한 팩 ID 보관 (분석용). 팝업이 닫히기 전에 읽어야 한다.
            _selectedPackIds.Clear();
            IReadOnlyList<string> pickedPackIds = popup.SelectedPackIds;
            for (int i = 0; i < pickedPackIds.Count; i++)
                _selectedPackIds.Add(pickedPackIds[i]);

            await ApplyStartCardPacksWithFadeAsync(selected, popup, token);
        }
        finally
        {
            popup.OnConfirmed -= Confirm;
            if (popup.IsOpen && UIManager.HasInstance)
                UIManager.Instance.Close(popup);
        }
    }

    private async UniTask ApplyStartCardPacksWithFadeAsync(
        IReadOnlyList<StartCardPackResult> selected,
        UIStartCardPackPopup popup,
        CancellationToken token)
    {
        if (SceneFlowManager.HasInstance)
        {
            await SceneFlowManager.Instance.RunWithFadeAsync(
                _ =>
                {
                    if (popup != null && popup.IsOpen && UIManager.HasInstance)
                        UIManager.Instance.Close(popup);

                    ApplyStartCardPacks(selected);
                    return UniTask.CompletedTask;
                },
                token);
            return;
        }

        ApplyStartCardPacks(selected);
    }

    private List<StartCardPackSO> LoadValidStartCardPacks()
    {
        List<StartCardPackSO> result = new List<StartCardPackSO>();
        if (!DataManager.HasInstance || !DataManager.Instance.IsLoaded)
        {
            Debug.LogError("[InGameController] DataManager가 준비되지 않아 Start 카드팩을 불러올 수 없습니다.");
            return result;
        }

        List<StartCardPackSO> all = DataManager.Instance.GetAllData<StartCardPackSO>() ?? new List<StartCardPackSO>();
        all.Sort((a, b) => string.CompareOrdinal(a != null ? a.name : null, b != null ? b.name : null));

        for (int i = 0; i < all.Count; i++)
        {
            StartCardPackSO pack = all[i];
            if (IsValidStartCardPack(pack))
                result.Add(pack);
        }

        return result;
    }

    private static bool IsValidStartCardPack(StartCardPackSO pack)
    {
        if (pack == null) return false;

        if (string.IsNullOrWhiteSpace(pack.DescriptionKey))
        {
            Debug.LogError($"[InGameController] Start 카드팩 DescriptionKey가 비어 있습니다: {pack.name}");
            return false;
        }

        if (pack.VisualPrefab == null || pack.VisualPrefab.GetComponent<RectTransform>() == null)
        {
            Debug.LogError($"[InGameController] Start 카드팩 VisualPrefab의 루트는 RectTransform이어야 합니다: {pack.name}");
            return false;
        }

        IReadOnlyList<CardDataSO> cards = pack.Cards;
        if (cards == null)
        {
            Debug.LogError($"[InGameController] Start 카드팩의 카드 목록이 null입니다: {pack.name}");
            return false;
        }

        if (cards.Count == 0) return true;

        for (int i = 0; i < cards.Count; i++)
        {
            if (cards[i] != null && !string.IsNullOrEmpty(cards[i].CardId))
                return true;
        }

        Debug.LogError($"[InGameController] Start 카드팩에 유효한 카드가 없습니다: {pack.name}");
        return false;
    }

    private void ApplyStartCardPacks(IReadOnlyList<StartCardPackResult> results)
    {
        if (results == null) return;

        // 팝업에서 확정한 방향을 그대로 덱에 반영 → 연출에서 본 화살표와 동일.
        for (int i = 0; i < results.Count; i++)
        {
            StartCardPackResult result = results[i];
            if (!string.IsNullOrEmpty(result.CardId))
                AddCardToRunDeck(result.CardId, result.Direction);
        }
    }

    // -------------------------------------------------
    // 전투 노드 (★ 전투 입력 조립 → BattleController 위임)
    // -------------------------------------------------

    /// <summary>
    /// 전투 노드 진입. 이번 전투의 적·덱을 결정해 BattleStartContext 로 포장하고,
    /// BattleController 에 위임한다 (BattleController 는 RunContext 를 모름).
    /// </summary>
    private void EnterBattleNode(bool skipEntryFade = false)
    {
        if (_isEnteringBattle) return;

        if (!BattleController.HasInstance)
        {
            Debug.LogError("[InGameController] BattleController 가 씬에 없습니다. 전투 시작 불가.");
            return;
        }

        EnterBattleNodeAsync(skipEntryFade).Forget();
    }

    private async UniTaskVoid EnterBattleNodeAsync(bool skipEntryFade)
    {
        _isEnteringBattle = true;
        try
        {
            BattleController battle = BattleController.Instance;

            // 전투 결과 구독 (중복 방지).
            if (!_battleSubscribed)
            {
                battle.OnBattleFinished += HandleBattleFinished;
                battle.OnPlayerDamageTaken += HandleStatisticsPlayerDamageTaken;
                battle.OnInfiniteLoopDetected += HandleStatisticsInfiniteLoop;
                battle.OnChainEnded += HandleStatisticsChainEnded;
                if (BattleManager.HasInstance)
                {
                    BattleManager.Instance.OnCardPlaced += HandleStatisticsCardPlaced;
                    BattleManager.Instance.OnPlayerTurnConfirmed += HandleStatisticsPlayerTurnConfirmed;
                }
                _battleSubscribed = true;
            }

            // ★ 전투 입력 조립: 적(시드·층 결정) + 덱(런 누적덱) + 시드.
            BattleStartContext context = BuildBattleContext();

            bool reuseCoveredFade =
                SceneFlowManager.HasInstance &&
                (skipEntryFade || SceneFlowManager.Instance.IsTransitioning) &&
                await WaitForFadeCoverageAsync(_runToken);

            if (SceneFlowManager.HasInstance &&
                !reuseCoveredFade &&
                !SceneFlowManager.Instance.IsTransitioning)
            {
                bool prepared = false;
                await SceneFlowManager.Instance.RunWithFadeAsync(
                    async token =>
                    {
                        if (!SceneFlowManager.Instance.IsFadeFullyCovered)
                        {
                            Debug.LogError("[InGameController] 페이드 차폐 전에 전투 UI를 처리하려 했습니다.");
                            return;
                        }

                        // 화면이 완전히 가려진 뒤 맵을 비활성화하고 전투 UI를 구성한다.
                        CloseMap();
                        prepared = await battle.PrepareBattleAsync(context, token);
                    },
                    _runToken);

                if (!prepared ||
                    !await battle.BeginPreparedBattleAsync(true, _runToken))
                {
                    return;
                }
            }
            else
            {
                // 이어하기 복원은 Main 씬 전환 페이드가 이미 화면을 덮고 있으므로
                // 별도 검은 페이드를 생략하고 현재 가림 화면 안에서 전투를 준비한다.
                if (SceneFlowManager.HasInstance && !reuseCoveredFade)
                {
                    Debug.LogError("[InGameController] 전투 노드 진입용 페이드 차폐에 실패했습니다.");
                    return;
                }

                CloseMap();
                if (!await battle.PrepareBattleAsync(context, _runToken) ||
                    !await battle.BeginPreparedBattleAsync(false, _runToken))
                {
                    return;
                }
            }

            _currentBattleTurnCount = 0;
            _run?.Statistics.BeginBattle();

            // 전투 화면 표시 완료 통지 (튜토리얼 안내 등 관전자 시스템 구독용).
            PublishBattleNodeEntered();
        }
        finally
        {
            _isEnteringBattle = false;
        }
    }

    /// <summary>현재 노드 기준으로 전투 진입 완료를 전역 발행한다. 구독자 없으면 무해.</summary>
    private void PublishBattleNodeEntered()
    {
        if (!EventManager.HasInstance || _run == null || _run.Map == null) return;

        MapNode node = _run.Map.GetNode(_run.CurrentNodeId);
        if (node == null) return;

        EventManager.Instance.Publish(new OnBattleNodeEntered
        {
            NodeType = node.NodeType,
            NodeId = node.Id,
        });
    }

    private static void CloseMap()
    {
        if (!UIManager.HasInstance) return;

        UIMap map = UIManager.Instance.Get<UIMap>();
        if (map != null)
            UIManager.Instance.Close(map);
    }

    /// <summary>
    /// 이번 전투의 BattleStartContext 를 조립한다.
    /// 적은 현재 노드에 배정된 EnemyId 를 해석, 덱은 런 누적덱, 시드는 런 시드 공유(재현).
    /// </summary>
    // 공유 설정 접근자 — 미할당 시 안전 폴백값 사용.
    private int ConfigMaxHp => _statConfig != null ? _statConfig.MaxHp : 50;
    private int ConfigMaxMana => _statConfig != null ? _statConfig.MaxMana : 3;
    private int ConfigDrawPerTurn => _statConfig != null ? _statConfig.DrawPerTurn : 5;
    private int ConfigMaxPreserve => _statConfig != null ? _statConfig.MaxPreserveCount : 3;
    private bool ConfigPreserveAll => _statConfig != null && _statConfig.PreserveAll;

    private BattleStartContext BuildBattleContext()
    {
        // 현재 노드에 배정된 적 해석 (미배정/미발견이면 null → BattleController 가 폴백 처리).
        MapNode node = _run != null && _run.Map != null ? _run.Map.GetNode(_run.CurrentNodeId) : null;
        EnemyDataSO enemyData = ResolveAssignedEnemy(node);

#if UNITY_EDITOR || DEVELOPMENT_BUILD
        int nodeId = node != null ? node.Id : -1;
        string id = enemyData != null ? enemyData.EnemyId : "(폴백 더미)";
        Debug.Log($"[InGameController] 노드 {nodeId} 적 결정 — {id}");
#endif

        PreserveConfig preserveConfig = new PreserveConfig(
            _run.PreserveAll,
            _run.MaxPreserveCount,
            _run.SetMaxPreserveCount);

        // 튜토리얼 1층 시연 전투: 시연 카드와 마지막 유저 카드를 실제 손패로 구성한다.
        // 본편 씬에서는 항상 false.
        // 판정은 시퀀스의 IsShowcaseBattleNode 가 단일 진실원 — 시연 시작 게이트와 공유한다.
        TutorialBossShowcaseSO showcase = TutorialShowcaseSequence.ActiveShowcase;
        bool isShowcaseBattle = node != null
            && TutorialShowcaseSequence.IsShowcaseBattleNode(node.NodeType);
        TutorialBattleBasicsSO basics = TutorialSecondBattleSequence.ActiveBasics;
        bool isBasicsBattle = node != null
            && TutorialSecondBattleSequence.IsLessonBattleNode(
                node.NodeType,
                _run != null ? _run.CurrentFloor : 0);

        return new BattleStartContext(
            deckEntries: _run.DeckEntries,
            deckCardIds: _run.DeckCardIds,
            enemyData: enemyData,
            shuffleSeed: BattleStartContext.CreateShuffleSeed(
                _run.Seed,
                _currentStageIndex,
                _run.CurrentNodeId),
            playerMaxHp: _run.HasHp ? _run.MaxHp : ConfigMaxHp,
            playerMaxEnergy: _run.MaxMana > 0 ? _run.MaxMana : ConfigMaxMana,
            playerCurrentHp: _run.HasHp ? _run.CurrentHp : 0,
            getPersistentState: _run.GetPersistentState,
            trimPersistentState: _run.TrimEmptyPersistentState,
            getCardCostDelta: _run.GetCardCostDelta,
            gridRows: _currentStageData != null ? _currentStageData.BattleGridRows : 0,
            gridColumns: _currentStageData != null ? _currentStageData.BattleGridColumns : 0,
            isTutorialBattle: isShowcaseBattle,
            tutorialDeckCards: isShowcaseBattle ? showcase.CreateBattleDeck() : null,
            tutorialDeckForcedArrows: isShowcaseBattle
                ? showcase.CreateBattleDeckForcedArrows()
                : null,
            tutorialFirstDrawCardIds: isBasicsBattle
                ? basics.CreateFirstDrawCardIds()
                : null,
            drawPerTurn: _run.DrawPerTurn > 0 ? _run.DrawPerTurn : -1,
            preserveConfig: preserveConfig,
            battleBackgroundKey: _currentStageData != null
                ? _currentStageData.BattleBackgroundKey
                : null,
            battleBgmKey: _currentStageData != null
                ? _currentStageData.GetBattleBgmKey(
                    enemyData != null ? enemyData.Grade : EEnemyGrade.Normal)
                : null,
            bossPhase2BgmKey: _currentStageData != null
                ? _currentStageData.BossPhase2BgmKey
                : null);
    }

    /// <summary>
    /// 전투 결과 중계 이벤트. 인자: victory(승리 여부).
    /// BattleController는 전투마다 생성/소멸하므로, 씬 수명이 안정적인 InGameController가
    /// 결과를 중계한다. 업적/분석 등 외부 시스템이 안정적으로 구독하는 지점.
    /// </summary>
    public event Action<bool> OnBattleResult;

    /// <summary>전투 종료 처리 (OnBattleFinished 수신) - 승리=전리품 / 패배=게임오버. 승리 시 생존 HP 저장.</summary>
    private void HandleBattleFinished(bool victory)
    {
        if (victory && CurrentDifficulty == ERunDifficulty.Hell && UIManager.HasInstance)
        {
            UIBattle battleUI = UIManager.Instance.Get<UIBattle>();
            battleUI?.TickSkillCooldownForBattleClear();
        }

        LastCompletedBattleTurnCount = Mathf.Max(1, _currentBattleTurnCount);
        _currentBattleTurnCount = 0;
        _run?.Statistics.CompleteBattle(victory, LastCompletedBattleTurnCount);

        // 외부 구독자(업적 등)에 전투 결과 통지 (게임 로직과 분리).
        OnBattleResult?.Invoke(victory);

        // 전투 BGM 정리 — 패배만 즉시 정지(패배 연출을 SFX 로 살린다).
        // 승리 시 맵 BGM 복귀는 여기서 하지 않고, 보상 수령 후 맵이 실제로 뜨는
        // PresentMapAsync 로 미룬다. (여기서 바로 틀면 전리품창이 뜨기도 전에
        // 맵 BGM 이 먼저 흘러 "맵으로 돌아온 듯" 어색하게 들린다)
        if (AudioManager.HasInstance && !victory)
            AudioManager.Instance.StopBgm(fadeOut: 1f);

        // 승리 시에만 생존 HP 를 런에 반영 (패배는 어차피 런 종료).
        if (victory && _run != null && _run.HasHp && BattleController.HasInstance)
        {
            _run.SetCurrentHp(BattleController.Instance.PlayerCurrentHp);
#if UNITY_EDITOR || DEVELOPMENT_BUILD
            Debug.Log($"[InGameController] 전투 승리 — 생존 HP 저장 {_run.CurrentHp}/{_run.MaxHp}");
#endif
        }

        // 마지막 보스는 보상 RNG/팝업/보상 대기 저장을 만들지 않고 즉시 클리어 흐름으로 간다.
        // 튜토리얼은 별도 안내가 닫힌 뒤 타이틀로 복귀한다.
        if (victory && IsCurrentNodeBoss())
        {
            if (TutorialDirector.IsActive)
            {
                _run?.ClearPendingReward();
                CompleteTutorialRunAsync(_runToken).Forget();
                return;
            }

            if (!HasNextStage())
            {
                CompleteFinalRunAsync(_runToken).Forget();
                return;
            }
        }

        // 다음 막이 있는 보스 격파 시, 난이도 규칙만큼 자동 회복한다.
        // 회복량은 "지금까지 잃은 체력"에 비례한다 — Normal 100%(완전 회복) / Hard 75% / Hell 50%.
        // 정액이 아니라 비율이므로 최대 체력이 바뀌어도 난이도 감각이 유지된다.
        // 보상 대기 저장 전에 적용하므로 재개 시 다시 회복되지 않는다.
        // HasNextStage() 가 _stageSequence 비어있음을 이미 걸러낸다.
        if (victory && IsCurrentNodeBoss() && HasNextStage() && _run != null)
        {
            int lostHp = Mathf.Max(0, _run.MaxHp - _run.CurrentHp);
            int percent = _stageSequence.StageClearHealPercent;

            // 올림 — 1이라도 잃었다면 최소 1은 회복되게 한다(비율이 0%가 아닌 한).
            int healAmount = (lostHp * percent + 99) / 100;
            int healed = _run.HealHp(healAmount);
#if UNITY_EDITOR || DEVELOPMENT_BUILD
            if (healed > 0)
                Debug.Log(
                    $"[InGameController] 스테이지 클리어 자동 회복 +{healed} " +
                    $"(잃은 체력 {lostHp} 의 {percent}%, {_run.CurrentHp}/{_run.MaxHp})");
#endif
        }

        // 승리 시 "보상 대기" 상태를 즉시 저장(노드는 해결됨=재전투 안 함, HP 반영 완료).
        // 이후 보상창에서 종료해도 이어하기 시 보상창부터 재개된다.
        if (victory && _run != null)
        {
            _run.BeginPendingReward(_run.CurrentNodeId);
            SaveRunProgress(currentNodeResolved: true);
        }

        ShowResultAsync(victory, _runToken).Forget();
    }

    private bool IsCurrentNodeBoss()
    {
        MapNode current = _run?.Map != null ? _run.Map.GetNode(_run.CurrentNodeId) : null;
        return current != null && current.NodeType == ENodeType.Boss;
    }

    private bool HasNextStage()
    {
        return !_singleStageMode &&
               _stageSequence != null &&
               _stageSequence.GetStageAt(_currentStageIndex + 1) != null;
    }

    private bool IsTutorialBossBattle()
    {
        return TutorialDirector.Active != null && IsCurrentNodeBoss();
    }

    private async UniTaskVoid CompleteTutorialRunAsync(CancellationToken token)
    {
        if (_isCompletingRun) return;
        _isCompletingRun = true;

        try
        {
            TutorialDirector director = TutorialDirector.Active;
            if (director != null)
            {
                // BattleManager 종료 이벤트를 놓친 경우에도 안내가 반드시 시작되도록
                // 런 흐름의 확정된 보스 승리 지점에서 직접 통지한다.
                director.NotifyBossDefeated();
                await director.WaitForBossDefeatedGuideAsync(token);
            }

            if (token.IsCancellationRequested || !IsRunActive) return;

            _run?.ClearPendingReward();
            OnStageCleared?.Invoke(_currentStageIndex);
            FinishRun(victory: true);

            if (MainController.HasInstance)
                MainController.Instance.ReturnToTitle();
            else
                HandleTitleRequested();
        }
        catch (OperationCanceledException)
        {
            // 씬 이탈/런 취소 — 정상 종료.
        }
        finally
        {
            _isCompletingRun = false;
        }
    }

    private async UniTaskVoid CompleteFinalRunAsync(CancellationToken token)
    {
        if (_isCompletingRun) return;
        _isCompletingRun = true;

        try
        {
            OnStageCleared?.Invoke(_currentStageIndex);
            await CommitFinalClearAsync();

            if (AudioManager.HasInstance)
            {
                AudioManager.Instance.PlayBgmAsync(AudioKeys.Bgm.ENDING, crossfade: 1.5f).Forget();
                AudioManager.Instance.PlaySfxAsync(AudioKeys.Game.CLEAR).Forget();
            }

            await GetRunClearPresenter().PlayAsync(token);
        }
        catch (OperationCanceledException)
        {
            // 씬 이탈/런 취소 — 정상 종료. Presenter 가 자체 정리한다.
        }
        finally
        {
            _isCompletingRun = false;
        }
    }

    /// <summary>런 클리어 연출 협력자를 지연 생성한다(인스펙터 값·정리 콜백 주입).</summary>
    private RunClearPresenter GetRunClearPresenter()
    {
        return _runClearPresenter ??= new RunClearPresenter(
            new RunClearPresenter.Config(
                _runClearSequenceKey,
                _runClearInitialFadeDuration,
                _runClearWhiteFadeDuration,
                _runClearWhiteHoldDuration,
                _runClearResultFadeDuration),
            () => LastRunStatistics,
            CleanupRunClearGameplay,
            HandleGameClearTitleRequested);
    }

    private void CleanupRunClearGameplay()
    {
        CloseMap();

        if (UIManager.HasInstance)
            UIManager.Instance.CloseAll();

        UnsubscribeBattle();
        if (BattleController.HasInstance)
            BattleController.Instance.ReleaseBattle();

        ResetAndHideGrid();
    }

    /// <summary>
    /// 런 시작 완료 시 발행 (시드·시작덱·카드팩 확정 직후, 맵 생성 전).
    /// 구독자는 CurrentRunId / CurrentSeed / SelectedPackIds 를 읽으면 된다.
    /// </summary>
    public event Action OnRunStarted;

    /// <summary>
    /// 저장 런 복원 완료 시 발행. 분석 시스템이 현재 세션 버퍼를 열되 신규 run_start는 보내지 않는 경계.
    /// </summary>
    public event Action OnRunResumed;

    /// <summary>
    /// 노드 진입 시 발행. 전투/비전투 구분 없이 DispatchNode 에서 한 번씩 발행된다.
    /// 분석 등 외부 시스템이 노드 단위 버퍼를 여는 지점.
    /// </summary>
    public event Action<MapNode> OnNodeEntered;

    /// <summary>
    /// 노드 이탈 시 발행. 다음 노드를 고르는 순간과 런 종료 시점에 발행된다.
    /// 전투 노드는 보상 수령까지 끝난 뒤에 이 이벤트가 오므로, 보상 데이터도 함께 flush 할 수 있다.
    /// </summary>
    public event Action OnNodeExited;

    /// <summary>보상 후보 제시. 인자: 후보 카드 ID 목록.</summary>
    public event Action<IReadOnlyList<string>> OnRewardOffered;

    /// <summary>보상 카드 선택 확정. 인자: 획득 카드 ID.</summary>
    public event Action<string> OnRewardPicked;

    /// <summary>보상 골드 수령. 인자: 수령 골드량.</summary>
    public event Action<int> OnRewardGoldClaimed;

    /// <summary>
    /// 런 종료 시 발행. 인자: (victory: 클리어 여부, reachedFloor: 도달 층).
    /// 업적/분석 등 외부 시스템이 구독해 게임 로직과 분리해 반응한다(SteamAchievementBridge 등).
    /// </summary>
    public event Action<bool, int> OnRunFinished;

    /// <summary>
    /// 진행 중인 런을 유저가 타이틀 복귀로 버릴 때 발행.
    /// FinishRun(클리어/패배)이 이미 지난 뒤에는 발행되지 않는다(IsRunActive 로 구분).
    /// 분석이 run_end 를 놓치지 않도록 하는 지점.
    /// </summary>
    public event Action OnRunAbandoned;

    /// <summary>진행 중인 런 포기 통지. 이미 종료된 런이면 무동작.</summary>
    private void NotifyRunAbandoned()
    {
        if (!IsRunActive) return;

        CaptureRunStatistics(ERunEndReason.Abandon);

        // 마지막 노드를 먼저 닫아야 노드 버퍼가 버려지지 않는다 (FinishRun 과 동일한 순서).
        OnNodeExited?.Invoke();
        OnRunAbandoned?.Invoke();
    }

    /// <summary>
    /// 스테이지 보스 격파(스테이지 클리어) 시 발행. 인자: clearedStageIndex(0-based, 방금 클리어한 스테이지).
    /// 다음 스테이지 전환/게임 클리어로 넘어가기 직전 시점. 스테이지별 업적 연결에 사용.
    /// </summary>
    public event Action<int> OnStageCleared;

    /// <summary>런 종료 - 결과 화면 전환 (클리어/패배 등 진짜 종료에만).</summary>
    private void FinishRun(bool victory)
    {
        CaptureRunStatistics(victory ? ERunEndReason.Clear : ERunEndReason.Defeat);
        IsRunActive = false;
        _canSaveRunProgress = false;
        ClearStageTransitionPending();
        RunSaveSystem.Clear();

        if (GameFlowManager.HasInstance)
        {
            GameFlowManager.Instance.SetState(EGameState.Result);
        }

        int reachedFloor = _run != null ? _run.CurrentFloor : 0;

#if UNITY_EDITOR || DEVELOPMENT_BUILD
        Debug.Log(
            $"[InGameController] 런 종료 - difficulty={RunDifficultyUtility.ToLogValue(CurrentDifficulty)}, " +
            $"{(victory ? "클리어" : "패배")} (도달 {reachedFloor}층)");
#endif

        // 마지막 노드를 먼저 닫는다. OnRunFinished 가 먼저 오면 노드 버퍼가 flush 되지 못하고 버려진다.
        OnNodeExited?.Invoke();

        // 업적/분석 등 외부 구독자에 통지 (게임 로직과 분리).
        OnRunFinished?.Invoke(victory, reachedFloor);
    }

    /// <summary>
    /// 전투 결과 처리. 승리면 통합 보상창(UIRewardPopup)에 전리품을 띄우고,
    /// 패배면 UIGameOverPopup 으로 재시작/타이틀을 제공한다.
    /// 보상 후보·골드는 카드 분류(pools/rarity/unlock)와 노드 등급으로 추출 — 시드 공유로 재현.
    /// </summary>
    private async UniTask ShowResultAsync(bool victory, CancellationToken token)
    {
        if (GameFlowManager.HasInstance)
        {
            GameFlowManager.Instance.SetState(EGameState.Result);
        }
        if (!UIManager.HasInstance) return;

        if (victory)
        {
            await ShowVictoryRewardAsync(token);
        }
        else
        {
            await ShowDefeatResultAsync(token);
        }
    }

    /// <summary>
    /// 승리 — 전리품(골드+카드) 묶음을 구성해 통합 보상창을 띄운다.
    /// skipGold/skipCard 는 이어하기 재개 시 이미 수령한 항목을 제외하기 위한 플래그다.
    /// 보상은 시드+노드 기반으로 결정적 재생성되므로, 재개 시에도 동일한 후보가 나온다.
    /// </summary>
    private async UniTask ShowVictoryRewardAsync(CancellationToken token, bool skipGold = false, bool skipCard = false)
    {
        // 저장 복원 또는 다른 호출 경로가 이 메서드에 직접 진입해도
        // 튜토리얼 보스 보상 팝업과 보상 RNG가 생성되지 않도록 최종 방어한다.
        if (IsTutorialBossBattle())
        {
            _run?.ClearPendingReward();
            CompleteTutorialRunAsync(token).Forget();
            return;
        }

        // 튜토리얼 1층 시연 승리 직후에는 멘토의 마무리 안내가 닫힌 뒤 보상창을 연다.
        // 본편 씬에서는 시퀀스가 없어 즉시 통과한다.
        while (TutorialShowcaseSequence.IsOutroActive)
            await UniTask.Yield(PlayerLoopTiming.Update, token);

        bool hasGridExpansionReward = HasGridExpansionReward();

        // 남은 보상이 없으면(재개인데 골드·카드 모두 수령됨) 보상창을 생략하고 바로 다음 진행.
        // 다음 막으로 이어지는 보스는 그리드 확장 안내가 남으므로 팝업을 연다.
        if (skipGold && skipCard && !hasGridExpansionReward)
        {
            HandleNextRequested();
            return;
        }

        EnsureRewardService();

        // 카드 후보 추첨 (현재 노드 풀 + 시드 공유 → 재현). RNG 소비 순서는 항상 동일하게 유지.
        ECardPool pool = ResolveCurrentRewardPool();
        CardQueryCriteria criteria = new CardQueryCriteria(
            pool: pool,
            rarity: null,           // 등급 무관 (가중치로 희귀도 반영)
            unlockedOnly: true,     // 해방 카드만 (폴백은 전부 해방)
            stagePool: ResolveCurrentCardStage());
        // 골드는 최초 보상 RNG 결과를 유지하고, 카드만 저장된 QA 재추첨 횟수를 복원한다.
        // 재추첨 RNG로 골드까지 다시 굴리면 저장 재개 시 미수령 골드가 달라진다.
        System.Random rewardRng = CreateCurrentNodeRewardRandom();
        List<CardDataSO> candidates = _rewardService.PickRandom(in criteria, _rewardCount, rewardRng);
        int goldRoll = RollVictoryGold(rewardRng);   // 스킵 여부와 무관하게 굴려 RNG 정합 유지.
        int savedRerollIndex = _run != null ? _run.DebugRewardRerollCount : 0;
        if (savedRerollIndex > 0)
        {
            candidates = _rewardService.PickRandom(
                in criteria,
                _rewardCount,
                CreateCurrentNodeRewardRandom(savedRerollIndex));
        }

        // 전리품 묶음 구성: 골드(등급별 범위 추첨) + 카드 1택. 이미 수령한 항목은 제외.
        _currentReward = new BattleReward();
        _cardRewardApplied = skipCard;   // 이미 카드를 골랐으면 재적용 방지.
        if (!skipGold)
            _currentReward.AddGold(goldRoll);
        if (!skipCard)
            _currentReward.AddCardChoice(candidates);
        if (hasGridExpansionReward)
            _currentReward.AddGridExpansion();

        // 보상 후보 통지 (분석 등). 실제 제시된 후보만 넘긴다.
        if (OnRewardOffered != null && !skipCard && candidates != null)
        {
            var offeredIds = new List<string>(candidates.Count);
            for (int i = 0; i < candidates.Count; i++)
            {
                if (candidates[i] != null)
                    offeredIds.Add(candidates[i].CardId);
            }
            OnRewardOffered.Invoke(offeredIds);
        }

        // 보상창 열기 — 묶음을 정적 예약 후 OpenAsync (UICardPileViewer 와 동일 패턴).
        UIRewardPopup.Show(_currentReward);
        UIRewardPopup reward = await UIManager.Instance.OpenAsync<UIRewardPopup>(token);
        if (reward == null) return;

        // 전리품 창 BGM — 전용 곡 없이 전투에서 이어진 곡을 그대로 유지하고 볼륨만 낮춘다.
        // 곡을 바꾸지 않는 이유: 보스는 스테이지 공용 곡이 아닌 전용 곡(2페이즈면 그 곡)을 쓰므로,
        // 여기서 맵 BGM 을 강제하면 보스 전리품 중에 이전 스테이지 테마로 되돌아가 어색해진다.
        // (전투 종료 시 BattleController 가 이미 보상 볼륨까지 낮춰두므로 대개 변화가 없다)
        // 이어하기로 보상창부터 재개된 경우엔 재생 중인 곡이 없으므로 맵 BGM 을 새로 시작한다.
        if (AudioManager.HasInstance)
        {
            if (AudioManager.Instance.IsBgmPlaying)
                AudioManager.Instance.FadeBgmVolume(AudioKeys.BgmVolume.REWARD, fadeDuration: 1.5f);
            else
                AudioManager.Instance.PlayBgmAsync(
                    CurrentMapBgmKey, crossfade: 1.5f, volume: AudioKeys.BgmVolume.REWARD).Forget();
        }

        // 콜백 재구독 (중복 방지). 골드=즉시수령 / 카드=1택 통지 / 계속=다음 진행.
        reward.OnGoldClaimRequested -= HandleGoldClaimRequested;
        reward.OnCardChosenWithDirection -= HandleRewardChosen;
        reward.OnContinueRequested -= HandleNextRequested;
        reward.OnGoldClaimRequested += HandleGoldClaimRequested;
        reward.OnCardChosenWithDirection += HandleRewardChosen;
        reward.OnContinueRequested += HandleNextRequested;

        await TutorialShowcaseSequence.ShowRewardGuideIfPendingAsync(token);

#if UNITY_EDITOR || DEVELOPMENT_BUILD
        int candCount = candidates != null ? candidates.Count : 0;
        Debug.Log($"[InGameController] 전리품 표시 — {_run.CurrentFloor}층, 보상후보 {candCount}장");
#endif
    }

    /// <summary>패배 — 패배 화면(UIGameOverPopup)으로 통계와 타이틀 복귀 제공.</summary>
    private async UniTask ShowDefeatResultAsync(CancellationToken token)
    {
        _currentReward = null;
        if (AudioManager.HasInstance)
            AudioManager.Instance.PlaySfxAsync(AudioKeys.Game.DEFEAT).Forget();

        // run_end(result=defeat)는 FinishRun 에서 Envelope 로 기록됨.
        FinishRun(victory: false);

        UIGameOverPopup.Show(LastRunStatistics);
        UIGameOverPopup popup = await UIManager.Instance.OpenAsync<UIGameOverPopup>(token);
        if (popup == null) return;

        // 패배 흐름 콜백 재구독 (타이틀).
        // 타이틀은 실제 씬 전환까지 하는 HandleGameOverTitleRequested 로 연결한다.
        popup.OnTitleRequested -= HandleGameOverTitleRequested;
        popup.OnTitleRequested += HandleGameOverTitleRequested;

#if UNITY_EDITOR || DEVELOPMENT_BUILD
        Debug.Log("[InGameController] 패배 통계 화면 표시");
#endif
    }

    /// <summary>
    /// 현재 노드 타입 → 보상 풀 매핑 (Battle→Normal, Elite→Elite, Boss→Boss).
    /// 비전투 노드·조회 실패는 Normal.
    /// </summary>
    private ECardPool ResolveCurrentRewardPool()
    {
        MapNode current = _run?.Map?.GetNode(_run.CurrentNodeId);
        if (current == null) return ECardPool.Normal;

        switch (current.NodeType)
        {
            case ENodeType.Elite: return ECardPool.Elite;
            case ENodeType.Boss: return ECardPool.Boss;
            default: return ECardPool.Normal;
        }
    }

    /// <summary>
    /// 다음 스테이지에서 실제 전투 그리드가 커지는 보스 보상인지 확인한다.
    /// 안내 항목일 뿐이며 실제 크기는 다음 전투 시작 시 StageDataSO 설정으로 적용된다.
    /// </summary>
    private bool HasGridExpansionReward()
    {
        if (!IsCurrentNodeBoss() || !HasNextStage() || _currentStageData == null)
            return false;

        StageDataSO nextStage = _stageSequence.GetStageAt(_currentStageIndex + 1);
        return nextStage != null &&
               (nextStage.BattleGridRows > _currentStageData.BattleGridRows ||
                nextStage.BattleGridColumns > _currentStageData.BattleGridColumns);
    }

    private ECardStagePool ResolveCurrentCardStage()
    {
        return CardQueryCriteria.StageForNumber(CurrentStageNumber);
    }

    /// <summary>
    /// 이번 전투 승리 골드 추첨. 현재 노드 등급별 범위에서 RunContext.Rng 로 굴린다
    /// (시드 공유 → 재현). 슬더스식 — 적 개체가 아닌 인카운터 등급이 범위를 결정한다.
    /// </summary>
    private int RollVictoryGold(System.Random rng)
    {
        if (_run == null) return 0;
        rng ??= _run.Rng;

        Vector2Int range = ResolveGoldRange();
        int min = Mathf.Min(range.x, range.y);
        int max = Mathf.Max(range.x, range.y);
        if (max <= 0) return 0;

        // System.Random.Next 의 상한은 배타적(exclusive) → max 포함을 위해 +1.
        return ApplyDifficultyGoldModifier(rng.Next(min, max + 1));
    }

    private System.Random CreateCurrentNodeRewardRandom(int rerollIndex = 0)
    {
        if (_run == null)
        {
            return new System.Random();
        }

        int nodeId = _run.CurrentNodeId;
        int floor = _run.CurrentFloor;
        int stage = _currentStageIndex;
        return new System.Random(StableRewardSeed(_run.Seed, nodeId, floor, stage, rerollIndex));
    }

    private static int StableRewardSeed(int runSeed, int nodeId, int floor, int stage, int rerollIndex = 0)
    {
        unchecked
        {
            uint hash = 2166136261u;
            hash = (hash ^ (uint)runSeed) * 16777619u;
            hash = (hash ^ (uint)nodeId) * 16777619u;
            hash = (hash ^ (uint)floor) * 16777619u;
            hash = (hash ^ (uint)stage) * 16777619u;
            hash = (hash ^ (uint)rerollIndex) * 16777619u;
            return (int)(hash & 0x7fffffff);
        }
    }

    /// <summary>현재 노드 타입 → 골드 범위 매핑 (Elite/Boss/그 외 Normal).</summary>
    private Vector2Int ResolveGoldRange()
    {
        MapNode current = _run?.Map?.GetNode(_run.CurrentNodeId);
        if (current == null) return _goldNormal;

        switch (current.NodeType)
        {
            case ENodeType.Elite: return _goldElite;
            case ENodeType.Boss: return _goldBoss;
            default: return _goldNormal;
        }
    }

    /// <summary>
    /// 골드 항목 클릭 수령 (UIRewardPopup.OnGoldClaimRequested). 해당 항목의 골드를
    /// 런에 적립·전역 발행하고, 항목을 수령 완료로 표시한다 (UI 가 표시 갱신).
    /// </summary>
    private void HandleGoldClaimRequested(BattleRewardItem item)
    {
        // 씬 전환으로 이미 종료된(죽은) 이전 컨트롤러가 캐시 팝업에 남은 구독으로
        // 먼저 실행돼 항목을 가로채는 것을 차단(MarkClaimed 전에 탈출).
        if (!IsRunActive || _run == null) return;
        if (item == null || item.Claimed) return;
        if (item.Kind != EBattleRewardKind.Gold) return;

        GrantGold(item.GoldAmount, applyDifficultyModifier: false);
        item.MarkClaimed();

        // 보상 골드 수령 통지 (분석 등).
        OnRewardGoldClaimed?.Invoke(item.GoldAmount);

        // 골드 수령을 저장에 반영(이어하기 시 골드 중복 지급 방지).
        if (_run != null)
        {
            _run.MarkRewardGoldClaimed();
            SaveRunProgress(currentNodeResolved: true);
        }
    }

    /// <summary>
    /// 런 골드를 적립하고 변동을 전역 통지(EventManager)한다. 보상·상점·이벤트 공용 경로.
    /// ★ 발행 책임은 여기(InGameController) — RunContext 는 데이터만 보유한다.
    /// </summary>
    /// <param name="amount">획득 골드(양수). 0/음수는 무시.</param>
    /// <returns>난이도 보정까지 반영해 실제로 적립된 골드. 미적립 시 0.</returns>
    public int GrantGold(
        int amount,
        bool playAudio = true,
        bool applyDifficultyModifier = true)
    {
        if (_run == null || amount <= 0) return 0;

        if (applyDifficultyModifier)
            amount = ApplyDifficultyGoldModifier(amount);
        if (amount <= 0) return 0;

        _run.AddGold(amount);

        if (playAudio && AudioManager.HasInstance)
            AudioManager.Instance.PlayUiAsync(AudioKeys.Game.GOLD_GAIN).Forget();

        if (EventManager.HasInstance)
        {
            EventManager.Instance.Publish(new OnGoldChanged
            {
                Current = _run.Gold,
                Delta = amount,
            });
        }

#if UNITY_EDITOR || DEVELOPMENT_BUILD
        Debug.Log($"[InGameController] 골드 +{amount} (보유 {_run.Gold})");
#endif
        return amount;
    }

    /// <summary>
    /// 실제 지급 전에 난이도 보정이 적용된 골드량을 미리 계산한다.
    /// 이벤트 선택지 라벨·보상 설명 등 "지급 예정 수치" 표기 전용.
    /// </summary>
    public int PreviewGrantGold(int amount) => ApplyDifficultyGoldModifier(amount);

    public IReadOnlyList<ECardDirection> CreateRewardArrowDirections(
        IReadOnlyList<CardDataSO> candidates)
    {
        if (candidates == null || candidates.Count == 0 ||
            CurrentDifficulty != ERunDifficulty.Hell ||
            _stageSequence == null ||
            _stageSequence.NormalBattleRewardArrowLimit != 1)
            return null;

        MapNode current = _run?.Map?.GetNode(_run.CurrentNodeId);
        if (current == null || current.NodeType != ENodeType.Battle)
            return null;

        int rerollIndex = _run != null ? _run.DebugRewardRerollCount : 0;
        int seed = StableRewardSeed(
            _run.Seed,
            _run.CurrentNodeId,
            _run.CurrentFloor,
            _currentStageIndex,
            rerollIndex + 7919);
        var rng = new System.Random(seed);
        var directions = new List<ECardDirection>(candidates.Count);
        for (int i = 0; i < candidates.Count; i++)
        {
            if (!HasConfiguredArrowDirection(candidates[i]))
            {
                directions.Add(ECardDirection.None);
                continue;
            }

            switch (rng.Next(4))
            {
                case 0: directions.Add(ECardDirection.Up); break;
                case 1: directions.Add(ECardDirection.Down); break;
                case 2: directions.Add(ECardDirection.Left); break;
                default: directions.Add(ECardDirection.Right); break;
            }
        }

        return directions;
    }

    private static bool HasConfiguredArrowDirection(CardDataSO cardData)
    {
        ArrowConfig config = cardData != null ? cardData.GetArrowConfig(upgraded: false) : null;
        if (config == null) return false;

        if (config.Mode == EArrowMode.Fixed)
            return config.FixedDirs != ECardDirection.None;

        IReadOnlyList<ArrowCandidate> candidates = config.Candidates;
        if (candidates == null) return false;

        for (int i = 0; i < candidates.Count; i++)
        {
            if (candidates[i].direction != ECardDirection.None)
                return true;
        }

        return false;
    }

    private int ApplyDifficultyGoldModifier(int amount)
    {
        if (amount <= 0) return 0;
        int percent = _stageSequence != null ? _stageSequence.GoldGainPercent : 100;
        return Mathf.Max(0, (int)((long)amount * percent / 100L));
    }

    public bool TryDebugGrantGold(int amount)
    {
        if (!DebugCommandManager.CanExecuteDomain(EDebugCommand.AddGold) ||
            !IsRunActive || _run == null || amount <= 0)
            return false;
        GrantGold(amount, applyDifficultyModifier: false);
        SaveRunProgress(currentNodeResolved: false);
        return true;
    }

    public bool TryDebugFullHeal()
    {
        if (!DebugCommandManager.CanExecuteDomain(EDebugCommand.FullHeal)) return false;
        if (!IsRunActive || _run == null || !_run.HasHp) return false;

        bool battleHpChanged = false;
        if (BattleController.HasInstance && BattleController.Instance.IsBattleRunning)
        {
            battleHpChanged = BattleController.Instance.PlayerCurrentHp < BattleController.Instance.PlayerMaxHp;
            if (!BattleController.Instance.TryDebugFullHeal()) return false;
        }

        bool runHpChanged = _run.CurrentHp < _run.MaxHp;
        if (runHpChanged)
            _run.HealHp(_run.MaxHp - _run.CurrentHp);
        if (runHpChanged || battleHpChanged)
            SaveRunProgress(currentNodeResolved: false);
        return true;
    }

    public bool TryDebugAddCards(string cardId, int count, ECardDirection? direction)
    {
        if (!DebugCommandManager.CanExecuteDomain(EDebugCommand.OpenCardDebug)) return false;
        if (!IsRunActive || _run == null || string.IsNullOrWhiteSpace(cardId) || count < 1 || count > 99)
            return false;
        if (!DataManager.HasInstance || DataManager.Instance.GetData<CardDataSO>(cardId) == null)
            return false;

        var addedEntryIds = new List<int>(count);
        for (int i = 0; i < count; i++)
        {
            RunDeckEntry entry = _run.AddCardToDeck(cardId);
            if (entry == null)
            {
                for (int j = 0; j < addedEntryIds.Count; j++)
                    _run.RemoveCardFromDeckEntry(addedEntryIds[j], out _);
                return false;
            }
            ResolveRunDeckEntryArrow(entry, direction);
            if (!entry.HasArrowDirection || (direction.HasValue && entry.ArrowDirection != direction.Value))
            {
                _run.RemoveCardFromDeckEntry(entry.EntryId, out _);
                for (int j = 0; j < addedEntryIds.Count; j++)
                    _run.RemoveCardFromDeckEntry(addedEntryIds[j], out _);
                return false;
            }
            addedEntryIds.Add(entry.EntryId);
        }

        if (addedEntryIds.Count != count) return false;
        SaveRunProgress(currentNodeResolved: false);
        return true;
    }

    public bool TryDebugRerollReward()
    {
        if (!DebugCommandManager.CanExecuteDomain(EDebugCommand.RerollReward)) return false;
        if (_run == null || _currentReward == null || _rewardService == null) return false;

        BattleRewardItem cardItem = null;
        for (int i = 0; i < _currentReward.Items.Count; i++)
        {
            BattleRewardItem item = _currentReward.Items[i];
            if (item != null && item.Kind == EBattleRewardKind.Card && !item.Claimed)
            {
                cardItem = item;
                break;
            }
        }
        if (cardItem == null) return false;

        CardQueryCriteria criteria = new CardQueryCriteria(
            pool: ResolveCurrentRewardPool(),
            rarity: null,
            unlockedOnly: true,
            stagePool: ResolveCurrentCardStage());
        int rerollIndex = _run.DebugRewardRerollCount + 1;
        List<CardDataSO> candidates = _rewardService.PickRandom(
            in criteria, _rewardCount, CreateCurrentNodeRewardRandom(rerollIndex));
        if (!cardItem.ReplaceCardCandidates(candidates)) return false;

        _run.AdvanceDebugRewardReroll();
        SaveRunProgress(currentNodeResolved: true);
        // 팝업이 활성 상태일 때만 다시 그린다. UI 갱신 실패가 리롤 성공을 숨기지 않도록
        // 데이터 교체·저장 후에 수행하며, 팝업 내부의 현재 보상 참조도 명시적으로 갱신한다.
        UIRewardPopup rewardPopup = UIManager.HasInstance ? UIManager.Instance.Get<UIRewardPopup>() : null;
        rewardPopup?.RefreshDebugReward(_currentReward);
        return true;
    }

    /// <summary>
    /// RunContext 의 HP 변동을 전역 통지(OnPlayerHpChanged)로 중계한다.
    /// 휴식·선택 이벤트·비용 지불 등 "전투 밖" HP 변동이 모두 이 경로를 탄다
    /// (전투 중 HP 는 BattleController 가 PlayerActor.OnHpChanged 를 같은 이벤트로 중계).
    /// ★ 발행 책임은 여기(InGameController) — RunContext 는 데이터만 보유한다(골드와 동일 경계).
    /// </summary>
    private void HandleRunHpChanged(int current, int max)
    {
        if (!EventManager.HasInstance) return;

        EventManager.Instance.Publish(new OnPlayerHpChanged
        {
            Current = current,
            Max = max,
        });
    }

    /// <summary>
    /// 런 골드를 지불하고 변동을 전역 통지(EventManager)한다. 이벤트 요구량 등 공용 지불 경로.
    /// GrantGold 와 대칭 — 발행 책임은 여기(InGameController).
    /// </summary>
    /// <param name="amount">지불 골드(양수). 잔액 부족 시 false 반환(차감·발행 안 함).</param>
    public bool SpendGold(int amount)
    {
        if (_run == null || amount <= 0) return false;
        if (!_run.SpendGold(amount)) return false;

        if (AudioManager.HasInstance)
            AudioManager.Instance.PlayUiAsync(AudioKeys.Game.GOLD_SPEND).Forget();

        if (EventManager.HasInstance)
        {
            EventManager.Instance.Publish(new OnGoldChanged
            {
                Current = _run.Gold,
                Delta = -amount,
            });
        }

#if UNITY_EDITOR || DEVELOPMENT_BUILD
        Debug.Log($"[InGameController] 골드 -{amount} (보유 {_run.Gold})");
#endif
        return true;
    }

    /// <summary>
    /// 보상 카드 선택 완료 (UIRewardPopup→UICardSelectPopup 경유). 획득 카드를 런 덱에 추가.
    /// 이 처리가 성공한 뒤 UIRewardPopup 이 보상 항목을 수령 완료로 확정한다.
    /// </summary>
    private void HandleRewardChosen(string acquiredCardId, ECardDirection direction)
    {
        if (string.IsNullOrEmpty(acquiredCardId)) return; // 스킵
        if (_run == null)
            throw new InvalidOperationException("[InGameController] 활성 런 없이 보상 카드를 적용할 수 없습니다.");
        if (_cardRewardApplied)
            throw new InvalidOperationException("[InGameController] 보상 카드가 이미 적용되었습니다.");
        if (!AddCardToRunDeck(acquiredCardId, direction))
            throw new InvalidOperationException(
                $"[InGameController] 보상 카드 덱 추가 실패: {acquiredCardId}");

        _cardRewardApplied = true;

        // 실제 덱 추가 성공 후에만 분석·저장 상태를 확정한다.
        try
        {
            OnRewardPicked?.Invoke(acquiredCardId);
        }
        catch (Exception e)
        {
            Debug.LogException(e);
        }
        if (AudioManager.HasInstance)
            AudioManager.Instance.PlaySfxAsync(AudioKeys.Card.REWARD).Forget();

        try
        {
            _run.MarkRewardCardChosen();
            SaveRunProgress(currentNodeResolved: true);
        }
        catch (Exception e)
        {
            // 덱 적용은 이미 성공했으므로 UI 재시도로 중복 지급하지 않고 다음 저장 기회를 사용한다.
            Debug.LogException(e);
        }
#if UNITY_EDITOR || DEVELOPMENT_BUILD
        Debug.Log($"[InGameController] 보상 카드 덱 추가 — {acquiredCardId} (덱 {_run.DeckCardIds.Count}장)");
#endif
    }

    public bool AddCardToRunDeck(
        string cardId,
        ECardDirection? resolvedDirection = null)
    {
        if (_run == null || string.IsNullOrEmpty(cardId)) return false;

        RunDeckEntry entry = _run.AddCardToDeck(cardId);
        if (entry == null) return false;

        ResolveRunDeckEntryArrow(entry, resolvedDirection);
        return true;
    }

    private CardRuntimeData FindCardRuntimeData(string cardId)
    {
        if (string.IsNullOrEmpty(cardId) || !DataManager.HasInstance) return null;
        CardDataSO card = DataManager.Instance.GetData<CardDataSO>(cardId);
        return card != null ? card.ToRuntimeData() : null;
    }

    private void InitializeRunDeckArrowDirections()
    {
        if (_run == null) return;

        IReadOnlyList<RunDeckEntry> entries = _run.DeckEntries;
        for (int i = 0; i < entries.Count; i++)
        {
            ResolveRunDeckEntryArrow(entries[i]);
        }
    }

    private static void ResolveRunDeckEntryArrow(
        RunDeckEntry entry,
        ECardDirection? resolvedDirection = null)
    {
        if (entry == null) return;

        // RuntimeData 가 비어 있으면 DataManager 에서 1회 채운다 (로드돼 있을 때만).
        if (entry.RuntimeData == null &&
            DataManager.HasInstance && DataManager.Instance.IsLoaded)
        {
            CardDataSO data = DataManager.Instance.GetData<CardDataSO>(entry.CardId);
            CardRuntimeData runtime = data != null ? CardFactory.FromSO(data) : null;
            entry.SetRuntimeData(runtime);
        }

        if (!entry.HasArrowDirection && resolvedDirection.HasValue)
        {
            entry.SetInitialArrowDirection(resolvedDirection.Value);
        }

        // RuntimeData 가 확보됐으면 방향을 그 자리에서 확정 (DataManager 와 무관, 멱등).
        bool resolved = entry.EnsureArrowResolved();

#if UNITY_EDITOR || DEVELOPMENT_BUILD
        if (resolved)
        {
            Debug.Log(
                $"[InGameController] 런 카드 방향 확정 — entry={entry.EntryId}, " +
                $"card={entry.CardId}, direction={entry.ArrowDirection}");
        }
        else if (!entry.HasArrowDirection)
        {
            Debug.LogWarning(
                $"[InGameController] 방향 확정 보류 — entry={entry.EntryId}, " +
                $"card={entry.CardId} (DataManager 미로드 추정, BattleController 에서 재시도됨)");
        }
#endif
    }

    /// <summary>결과 "다음" 버튼. 보스 노드면 클리어, 아니면 맵 복귀.</summary>
    private void HandleNextRequested()
    {
        if (!IsRunActive || _run == null) return;

        // 보상 진행 완료 — 대기 해제(이후 저장에 반영됨).
        _run.ClearPendingReward();

        MapNode current = _run.Map != null ? _run.Map.GetNode(_run.CurrentNodeId) : null;
        if (current != null && current.NodeType == ENodeType.Boss)
        {
#if UNITY_EDITOR || DEVELOPMENT_BUILD
            Debug.Log("[InGameController] 보스 격파 - 다음 맵/클리어 분기 시작");
#endif
            SaveBossStageTransitionCheckpoint();
            ResolveBossClearedAsync(_runToken).Forget();
            return;
        }

#if UNITY_EDITOR || DEVELOPMENT_BUILD
        Debug.Log($"[InGameController] 전투 승리 - 맵 복귀 ({_run.CurrentFloor}층, 덱={_run.DeckCardIds.Count}장)");
#endif

        SaveRunProgress(currentNodeResolved: true);
        // 보상 수령 → 맵 복귀는 화면 페이드로 감싸 BGM/SFX 잔재를 페이드 안에서 정리한다.
        PresentMapWithFadeAsync(_runToken).Forget();
    }

    /// <summary>
    /// 보스 보상 수령 직후, 다음 스테이지 시작을 저장 데이터에만 확정한다.
    /// 연출 중 종료되면 로드 시 새 맵을 생성하므로, 여기서 다음 맵을 미리 만들 필요는 없다.
    /// </summary>
    private void SaveBossStageTransitionCheckpoint()
    {
        if (_run == null) return;
        // 저장 게이트는 SaveRunProgress 와 동일하게 맞춘다.
        // (런 종료·재시작으로 세이브를 지운 뒤 체크포인트가 되살아나는 것을 막는다)
        if (!IsRunActive || !_canSaveRunProgress) return;

        if (_singleStageMode || _stageSequence == null) return;

        // 이미 확정된 목표 인덱스가 있으면 재계산하지 않는다.
        // 전환 연출 중에는 ResolveNextStageData 가 _currentStageIndex 를 먼저 증가시키므로,
        // 여기서 다시 +1 하면 스테이지를 하나 건너뛴 채로 저장된다.
        int nextStageIndex = _isStageTransitionPending && _pendingStageIndex >= 0
            ? _pendingStageIndex
            : _currentStageIndex + 1;
        if (_stageSequence.GetStageAt(nextStageIndex) == null) return;

        _isStageTransitionPending = true;
        _pendingStageIndex = nextStageIndex;
        string characterId = SelectedCharacter != null ? SelectedCharacter.CharacterId : null;
        RunSaveSystem.Save(
            _run,
            nextStageIndex,
            characterId,
            currentNodeResolved: true,
            stageTransitionPending: true);
    }

    private async UniTaskVoid ResolveBossClearedAsync(CancellationToken token)
    {
        if (_run == null) return;

        int clearedStageIndex = _currentStageIndex;
        // 다음 스테이지 맵 생성·저장이 확정되면 true.
        // 확정 이후의 실패(연출·표시 단계)는 인덱스를 되돌리면 안 된다.
        // 되돌리면 메모리 인덱스와 이미 교체된 런타임 맵/세이브가 서로 어긋난다.
        bool stageCommitted = false;

        try
        {
            // 보스 격파 = 현재 스테이지 클리어. 인덱스 증가(ResolveNextStageData) 전에 발화.
            // 외부 구독자(업적 등)에 방금 클리어한 스테이지 인덱스(0-based) 통지.
            OnStageCleared?.Invoke(clearedStageIndex);

            // 방금 클리어한 스테이지의 맵을 잠깐 보여주는 구간이라 BGM 은 건드리지 않는다.
            // 여기서 맵 BGM 으로 바꾸면 이전 스테이지 테마로 되돌아갔다가 바로 아래
            // TransitionToNextMapAsync 가 다음 스테이지 테마로 또 바꾸는 왕복이 생긴다.
            // 보스 곡이 전투 종료 시 낮춰진 볼륨 그대로 이어지다가 스테이지 전환에서 교체된다.
            await PresentMapAsync(token, playMapBgm: false);
            if (token.IsCancellationRequested || _run == null) return;

            UIMap map = UIManager.HasInstance ? UIManager.Instance.Get<UIMap>() : null;
            if (map != null)
            {
                await map.PlayCurrentNodeClearAsync(token);
            }

            StageDataSO nextStage = ResolveNextStageData();
            if (nextStage == null)
            {
                // 게임 클리어 경로 — FinishRun 이 pending·세이브를 정리하므로 롤백 대상이 아니다.
                stageCommitted = true;
                await ShowGameClearAsync(token);
                return;
            }

            bool transitioned = await TransitionToNextMapAsync(
                nextStage,
                token,
                () => stageCommitted = true);
            if (!transitioned)
            {
                Debug.LogError("[InGameController] 다음 스테이지 맵 생성 실패 — 이전 스테이지 인덱스로 복구합니다.");
            }
        }
        finally
        {
            // 보상 완료 시 저장한 다음 스테이지 체크포인트는 취소·예외로 되돌리지 않는다.
            // 여기서 일반 저장으로 롤백하면 이전 보스가 해결된 상태로 저장되어,
            // 이어하기 후 다음 스테이지 전환을 다시 시작할 계기가 사라진다.
            if (!stageCommitted)
            {
                _currentStageIndex = clearedStageIndex;
            }
        }
    }

    private async UniTask<bool> TransitionToNextMapAsync(
        StageDataSO nextStage,
        CancellationToken token,
        Action onMapCommitted)
    {
        UISystemStageNotice notice = await OpenStageNoticeAsync(token);
        if (notice != null)
        {
            bool transitioned = await notice.PlayStageTransitionAsync(async noticeToken =>
            {
                if (!GenerateCurrentMap(nextStage)) return false;
                ClearStageTransitionPending();
                SaveRunProgress(currentNodeResolved: true);
                // 암전 상태에서 맵·세이브를 다음 스테이지로 확정한다.
                onMapCommitted?.Invoke();
                await PresentMapAsync(noticeToken);
                return true;
            }, token);

            if (transitioned) PlayMapIntroIfPending();
            return transitioned;
        }

        if (!GenerateCurrentMap(nextStage)) return false;
        ClearStageTransitionPending();
        SaveRunProgress(currentNodeResolved: true);
        onMapCommitted?.Invoke();
        await PresentMapAsync(token);
        PlayMapIntroIfPending();
        return true;
    }

    /// <summary>스테이지 전환 체크포인트 상태를 해제한다(전환 완료·실패·런 종료 공통).</summary>
    private void ClearStageTransitionPending()
    {
        _isStageTransitionPending = false;
        _pendingStageIndex = -1;
    }

    private async UniTask<UISystemStageNotice> OpenStageNoticeAsync(CancellationToken token)
    {
        if (!UIManager.HasInstance) return null;
        UISystemStageNotice notice = await UIManager.Instance.OpenAsync<UISystemStageNotice>(token);
        if (notice != null)
        {
            // 튜토리얼은 진짜 런으로 돌지만 막 대신 '튜토리얼' 문구를 표시한다.
            if (TutorialDirector.IsActive)
                notice.SetTitleKey(LocalizationKeys.StageNotice.TutorialTitle);
            else
                notice.SetStageNumber(CurrentStageNumber);
        }
        return notice;
    }

    private static async UniTask<UIFirstStarPanel> WaitForFirstLaunchTutorialStartAsync(
        CancellationToken token)
    {
        if (!RunLaunchOptions.ConsumeFirstLaunchTutorial())
            return null;

        if (!UIManager.HasInstance)
        {
            Debug.LogError("[InGameController] UIFirstStarPanel 표시 실패 — UIManager가 없어 기존 튜토리얼 진입을 계속합니다.");
            return null;
        }

        UIFirstStarPanel panel = await UIManager.Instance.OpenAsync<UIFirstStarPanel>(token);
        if (panel == null)
        {
            Debug.LogError("[InGameController] UIFirstStarPanel 로드 실패 — 기존 튜토리얼 진입을 계속합니다.");
            return null;
        }

        // 최초 실행은 타이틀 화면을 건너뛰고 곧바로 이 패널로 오므로, 여기까지 재생 중인 BGM이 없다.
        // 유저 입력을 기다리는 동안(길어질 수 있다) 무음으로 두지 않도록 타이틀 BGM을 깔아 준다.
        // 시작 후에는 PresentMapAsync 가 스테이지 BGM 으로 크로스페이드한다.
        if (AudioManager.HasInstance)
            AudioManager.Instance.PlayBgmAsync(AudioKeys.Bgm.TITLE, crossfade: 1f).Forget();

        if (!await panel.WaitForStartAsync(token))
            throw new OperationCanceledException(token);

        return panel;
    }

    /// <summary>런 상단 정보 바를 연다(런 내내 유지). 이미 열려 있으면(재시작 등) 중복 오픈하지 않는다.</summary>
    private static async UniTask OpenTopInfoAsync(CancellationToken token)
    {
        if (!UIManager.HasInstance) return;
        if (UIManager.Instance.IsOpen<UINoticeTopInfo>()) return;
        await UIManager.Instance.OpenAsync<UINoticeTopInfo>(token);
    }

    private async UniTask ShowGameClearAsync(CancellationToken token)
    {
        // run_end(result=clear)는 FinishRun 에서 Envelope 로 기록됨.
        // 타이틀 배경 분기용 최종 클리어 날짜 기록(현지시간). 이 경로는 최종 클리어 전용이며
        // 튜토리얼은 CompleteTutorialRunAsync 로 우회하므로 여기 도달하지 않는다.
        await CommitFinalClearAsync();

        if (AudioManager.HasInstance)
        {
            AudioManager.Instance.PlayBgmAsync(AudioKeys.Bgm.ENDING, crossfade: 1.5f).Forget();
            AudioManager.Instance.PlaySfxAsync(AudioKeys.Game.CLEAR).Forget();
        }

        await GetRunClearPresenter().ShowResultOnlyAsync(token);
    }

    /// <summary>
    /// 비튜토리얼 최종 클리어의 상태 확정 경계.
    /// 타이틀 전환 토큰과 분리해 영속 저장 완료 후에만 결과 화면으로 진행한다.
    /// </summary>
    private async UniTask CommitFinalClearAsync()
    {
        FinishRun(victory: true);
        await TitleClearStore.RecordTodayAsync();
    }

    // -------------------------------------------------
    // 결과 화면 버튼 처리
    // -------------------------------------------------

    private static void ResetAndHideGrid()
    {
        if (!GridManager.HasInstance) return;

        GridManager grid = GridManager.Instance;
        grid.ClearAllCards();
        grid.SetVisible(false);
    }

    /// <summary>타이틀 복귀 - 런 종료 + 타이틀 상태 전환.</summary>
    private void HandleTitleRequested()
    {
        EndRun();

        if (GameFlowManager.HasInstance)
        {
            GameFlowManager.Instance.SetState(EGameState.Title);
        }
        // [horizon] 실제 타이틀 씬 로드는 SceneFlowManager 연결 시 추가.
    }

    private void HandleGameClearTitleRequested()
    {
        if (MainController.HasInstance)
            MainController.Instance.ReturnToTitle();
        else
            HandleTitleRequested();
    }

    /// <summary>게임오버(패배) 팝업 — 페이드 후 런을 정리하고 타이틀 씬으로 복귀한다.</summary>
    private void HandleGameOverTitleRequested()
    {
        if (MainController.HasInstance)
        {
            // 씬 전환 페이드가 완전히 덮인 뒤 MainController.OnSceneExit에서 EndRun한다.
            // 여기서 먼저 정리하면 전투 UI/오브젝트가 사라진 화면이 페이드 전에 노출된다.
            MainController.Instance.ReturnToTitle();
        }
        else
            HandleTitleRequested(); // 폴백 (씬 로드 미연결 환경).
    }

    // ─────────────────────────────────────────────
    // 상단 바 — 지도 미리보기 / 전체 덱 열람 (슬더스식 상시 열람)
    // ─────────────────────────────────────────────

    /// <summary>
    /// 상단 바 지도 버튼 — 지도 미리보기(읽기 전용) 토글.
    /// 전투·상점 등 어느 시점에든 열람할 수 있고, 노드 선택은 불가.
    /// 노드 선택용으로 이미 열린 지도는 건드리지 않는다(닫으면 진행 불가).
    /// </summary>
    public void ToggleMapPeek()
    {
        if (!IsRunActive || _run == null || !UIManager.HasInstance) return;

        UIMap map = UIManager.Instance.Get<UIMap>();
        if (map != null)
        {
            if (map.IsPeek)
                CloseMapPeek();
            return;
        }

        // 상단 바의 열람 전용 덱이 열려 있으면 지도와 교체한다.
        UIDeckCardPicker picker = UIManager.Instance.Get<UIDeckCardPicker>();
        if (picker != null && picker.IsViewOnly)
            UIManager.Instance.Close(picker);

        OpenMapPeekAsync(_runToken).Forget();
    }

    private async UniTaskVoid OpenMapPeekAsync(CancellationToken token)
    {
        UIMap map = await UIManager.Instance.OpenAsync<UIMap>(token);
        if (map == null || token.IsCancellationRequested || !IsRunActive) return;

        map.SetPeekMode(true);
        SetMapPeekOpenInTopInfo(true);
    }

    /// <summary>
    /// 상단 바 덱 버튼 — 현재 런 전체 덱 열람(읽기 전용) 토글.
    /// 다른 흐름(상점 제거·강화 등)이 연 피커는 건드리지 않는다.
    /// </summary>
    public void ToggleDeckView()
    {
        if (!IsRunActive || _run == null || !UIManager.HasInstance) return;

        // 상단 바에서 연 지도 미리보기는 덱과 동시에 두지 않는다.
        CloseMapPeek();

        UIDeckCardPicker picker = UIManager.Instance.Get<UIDeckCardPicker>();
        if (picker != null)
        {
            if (picker.IsViewOnly)
                UIManager.Instance.Close(picker);
            return;
        }

        UIDeckCardPicker.Show(
            _run.DeckEntries,
            Localize(LocalizationKeys.DeckPicker.ViewTitle),
            viewOnly: true);
        UIManager.Instance.OpenAsync<UIDeckCardPicker>(LifetimeToken).Forget();
    }

    /// <summary>열려 있는 지도 미리보기를 닫는다. 닫았으면 true (ESC 라우팅용).</summary>
    public bool CloseMapPeek()
    {
        if (!UIManager.HasInstance) return false;

        UIMap map = UIManager.Instance.Get<UIMap>();
        if (map == null || !map.IsPeek) return false;

        UIManager.Instance.Close(map);
        SetMapPeekOpenInTopInfo(false);
        return true;
    }

    private static void SetMapPeekOpenInTopInfo(bool isOpen)
    {
        if (!UIManager.HasInstance) return;

        UINoticeTopInfo topInfo = UIManager.Instance.Get<UINoticeTopInfo>();
        topInfo?.SetMapPeekOpen(isOpen);
    }

    /// <summary>ESC 런 메뉴 토글 (MainController 의 ESC 라우팅이 호출). 런 진행 중에만 유효.</summary>
    public void ToggleEscMenu()
    {
        if (!IsRunActive) return;

        // 지도 미리보기가 떠 있으면 ESC 는 먼저 미리보기를 닫는 것으로 소비한다.
        if (CloseMapPeek()) return;

        // 실제 열림 여부는 UIManager 를 단일 출처로 판정한다.
        // (ESC/계속하기로 메뉴가 스스로 닫혀 _escMenu 가 stale 이어도 정확히 동기화됨)
        bool open = UIManager.HasInstance && UIManager.Instance.IsOpen<UISystemEscMenu>();
        if (open)
        {
            CloseEscMenu();
            return;
        }

        _escMenu = null; // 잔여 참조 정리.
        OpenEscMenuAsync().Forget();
    }

    private async UniTaskVoid OpenEscMenuAsync()
    {
        if (!UIManager.HasInstance) return;

        UISystemEscMenu menu = await UIManager.Instance.OpenAsync<UISystemEscMenu>(LifetimeToken);
        if (menu == null) return;

        _escMenu = menu;

        // 선택 결과 구독 — 타이틀은 씬 전환 경로로.
        menu.OnTitleRequested -= HandleEscTitleRequested;
        menu.OnContinueRequested -= HandleEscContinueRequested;
        menu.OnCollectionRequested -= HandleEscCollectionRequested;
        menu.OnTitleRequested += HandleEscTitleRequested;
        menu.OnContinueRequested += HandleEscContinueRequested;
        menu.OnCollectionRequested += HandleEscCollectionRequested;

        // 게임 일시정지 (TimeManager 까지 단일 출처로 제어).
        if (GameFlowManager.HasInstance && !GameFlowManager.Instance.IsPaused)
        {
            GameFlowManager.Instance.TogglePause();
        }
    }

    /// <summary>메뉴 닫기 + 일시정지 해제. 메뉴가 스스로 닫힌 경우에도 정리되도록 멱등 처리.</summary>
    private void CloseEscMenu(bool resumeGame = true)
    {
        if (_escMenu != null)
        {
            _escMenu.OnTitleRequested -= HandleEscTitleRequested;
            _escMenu.OnContinueRequested -= HandleEscContinueRequested;
            _escMenu.OnCollectionRequested -= HandleEscCollectionRequested;

            if (UIManager.HasInstance)
            {
                UIManager.Instance.Close(_escMenu);
            }
            _escMenu = null;
        }

        // 일시정지 해제 (Paused 상태였다면 InGame 으로 복귀).
        if (resumeGame && GameFlowManager.HasInstance && GameFlowManager.Instance.IsPaused)
        {
            GameFlowManager.Instance.TogglePause();
        }
    }

    private void HandleEscContinueRequested()
    {
        CloseEscMenu();
    }

    /// <summary>
    /// ESC 메뉴 도감 — 메뉴는 숨기되 일시정지는 유지한다.
    /// 타이틀 도감 흐름과 별개로 닫힘을 구독해 ESC 메뉴로만 복귀한다.
    /// </summary>
    private void HandleEscCollectionRequested()
    {
        OpenEscCollectionAsync().Forget();
    }

    private async UniTaskVoid OpenEscCollectionAsync()
    {
        if (!UIManager.HasInstance || !IsRunActive) return;

        UICardPileViewer.ShowCollection();

        UICardPileViewer collection = await UIManager.Instance.OpenAsync<UICardPileViewer>(LifetimeToken);
        if (collection == null || !IsRunActive) return;

        DetachEscCollectionViewer();
        _escCollectionViewer = collection;
        collection.OnClosed -= HandleEscCollectionClosed;
        collection.OnClosed += HandleEscCollectionClosed;

        // 첫 Addressable 로드 중에는 ESC 메뉴를 유지하고, 도감 활성화가 끝난 뒤에만 숨긴다.
        CloseEscMenu(resumeGame: false);
    }

    private void HandleEscCollectionClosed()
    {
        DetachEscCollectionViewer();

        if (IsRunActive && GameFlowManager.HasInstance && GameFlowManager.Instance.IsPaused)
            OpenEscMenuAsync().Forget();
    }

    private void DetachEscCollectionViewer()
    {
        if (_escCollectionViewer != null)
            _escCollectionViewer.OnClosed -= HandleEscCollectionClosed;
        _escCollectionViewer = null;
    }

    /// <summary>ESC 메뉴 — 타이틀 복귀. 게임클리어 타이틀 경로와 동일하게 씬 전환까지 처리.</summary>
    private void HandleEscTitleRequested()
    {
        _escMenu = null;
        if (GameFlowManager.HasInstance && GameFlowManager.Instance.IsPaused)
        {
            GameFlowManager.Instance.TogglePause();
        }

        // 진행 중인 런을 버리고 나가는 경우 통지 (EndRun 이 IsRunActive 를 끄기 전에 해야 한다).
        NotifyRunAbandoned();

        // 런 정리 후 실제 타이틀 씬 로드 (MainController.ReturnToTitle).
        // 전환 화면이 완전히 덮인 뒤 MainController.OnSceneExit에서 EndRun한다.
        if (MainController.HasInstance)
        {
            MainController.Instance.ReturnToTitle();
        }
        else
        {
            HandleTitleRequested(); // 폴백 (씬 로드 미연결 환경).
        }
    }

    // -------------------------------------------------
    // 전투 입력 결정자 (지연 생성)
    // -------------------------------------------------

    /// <summary>시작덱 추출 헬퍼 1회 생성.</summary>
    private void EnsureStartingDeckProvider()
    {
        _startingDeckProvider ??= new StartingDeckProvider();
    }

    /// <summary>적 후보 풀 1회 수령 (DataManager.GetAllData).</summary>
    private void EnsureEnemyPool()
    {
        if (_enemyPool != null) return;

        if (DataManager.HasInstance && DataManager.Instance.IsLoaded)
        {
            _enemyPool = DataManager.Instance.GetAllData<EnemyDataSO>() ?? new List<EnemyDataSO>();
        }
        else
        {
            _enemyPool = new List<EnemyDataSO>();
            Debug.LogWarning("[InGameController] DataManager 미준비 — 적 풀 비어있음. 폴백 적 사용.");
        }
    }

    /// <summary>노드에 배정된 적 ID 를 풀에서 해석. 스테이지 풀 우선, 없으면 전역 풀. 미발견이면 null (폴백 더미).</summary>
    private EnemyDataSO ResolveAssignedEnemy(MapNode node)
    {
        if (node == null || string.IsNullOrEmpty(node.EnemyId)) return null;

        EEnemyGrade preferredGrade = ResolveEnemyGrade(node.NodeType);

        // 1) 스테이지 풀 우선 (전역에 없는 적이 있을 수 있음).
        EnemyPoolSO stagePool = _currentStageData != null ? _currentStageData.EnemyPool : null;
        EnemyDataSO found = FindInStagePool(stagePool, node.EnemyId, preferredGrade);
        if (found != null) return found;

        // 2) 전역 풀 폴백.
        EnsureEnemyPool();
        EnemyDataSO fallbackById = null;
        for (int i = 0; i < _enemyPool.Count; i++)
        {
            EnemyDataSO so = _enemyPool[i];
            if (so == null || so.EnemyId != node.EnemyId) continue;
            if (so.Grade == preferredGrade) return so;
            fallbackById ??= so;
        }
        if (fallbackById != null) return fallbackById;

        Debug.LogWarning($"[InGameController] 배정 적을 풀에서 찾지 못했습니다: {node.EnemyId}");
        return null;
    }

    /// <summary>스테이지 적 풀에서 ID 로 적을 찾는다. 등급 일치 우선, 없으면 ID 일치 첫 항목.</summary>
    private static EnemyDataSO FindInStagePool(EnemyPoolSO pool, string enemyId, EEnemyGrade preferredGrade)
    {
        if (pool == null) return null;

        EnemyDataSO fallbackById = null;
        // 네 등급 리스트를 순회.
        for (int listIdx = 0; listIdx < 4; listIdx++)
        {
            IReadOnlyList<WeightedEnemy> list =
                listIdx == 0 ? pool.Normal :
                listIdx == 1 ? pool.Elite :
                listIdx == 2 ? pool.Boss : pool.Test;
            if (list == null) continue;

            for (int i = 0; i < list.Count; i++)
            {
                EnemyDataSO so = list[i].Enemy;
                if (so == null || so.EnemyId != enemyId) continue;
                if (so.Grade == preferredGrade) return so;
                fallbackById ??= so;
            }
        }
        return fallbackById;
    }

    /// <summary>전투 노드 타입에 대응하는 적 등급.</summary>
    private static EEnemyGrade ResolveEnemyGrade(ENodeType nodeType)
    {
        switch (nodeType)
        {
            case ENodeType.Elite: return EEnemyGrade.Elite;
            case ENodeType.Boss: return EEnemyGrade.Boss;
            case ENodeType.Test: return EEnemyGrade.Test;
            default: return EEnemyGrade.Normal;
        }
    }

    /// <summary>보상 서비스 1회 생성 (DataManager 전체 카드 + 해방 폴백).</summary>
    private void EnsureRewardService()
    {
        if (_rewardService != null) return;
        _rewardService = new CardRewardService(
            _run != null ? _run.AvailableCardPool : null,
            AlwaysUnlockedProvider.Instance,
            CurrentCardRewardRarityWeights);
    }

    private StageDataSO ResolveInitialStageData()
    {
        _currentStageIndex = 0;
        _stageSequence = null;
        _currentStageData = null;
        _singleStageMode = _stageData != null;

        if (_singleStageMode)
        {
            return _stageData;
        }

        _stageSequence = ResolveStageSequence();
        StageDataSO stage = _stageSequence != null ? _stageSequence.GetStageAt(_currentStageIndex) : null;
        if (stage == null)
        {
            Debug.LogError("[InGameController] StageDataSO가 비어 있고 유효한 StageSequenceSO를 찾지 못했습니다. 맵 생성 불가.");
        }

        return stage;
    }

    private StageDataSO ResolveSavedStageData(int savedStageIndex)
    {
        StageDataSO stage = ResolveInitialStageData();
        if (_singleStageMode)
            return stage;

        int targetIndex = Mathf.Max(0, savedStageIndex);
        while (_currentStageIndex < targetIndex)
        {
            StageDataSO next = ResolveNextStageData();
            if (next == null) break;
            stage = next;
        }
        return stage;
    }

    /// <summary>
    /// 진행할 수단이 전혀 없는 "고착 세이브"인지 판정한다.
    /// 노드를 이미 해결했고, 받을 보상도 없고, 전환 예약도 없는데 갈 수 있는 노드가 0개인 상태 —
    /// 불러와도 클릭할 것이 없어 새 게임 말고는 방법이 없다.
    /// 체크포인트 도입(version 5) 이전 빌드의 전환 롤백이 남긴 잔재이므로 구버전 저장만 검사한다.
    /// </summary>
    private bool IsStuckLegacySave(RunSaveData saveData)
    {
        // v5 이상은 보상 완료 시 전환 체크포인트를 남기므로 이 상태가 만들어지지 않는다.
        if (saveData == null || saveData.version >= 5) return false;
        if (saveData.stageTransitionPending || !saveData.currentNodeResolved) return false;
        if (saveData.currentNodeId == RunContext.NoNode ||
            saveData.rewardPendingNodeId != RunContext.NoNode ||
            _run?.Map == null)
            return false;

        // "보스 노드"는 프록시일 뿐이고 진짜 조건은 전진 불가다.
        // 중간 노드는 인접이 항상 1개 이상이므로 최종 depth 에서만 0 이 된다.
        return _run.Map.GetReachableNodes(saveData.currentNodeId).Count == 0;
    }

    /// <summary>
    /// 고착 세이브를 다음 스테이지 시작 상태로 승격한다.
    /// 다음 스테이지가 없으면(최종 보스 클리어 직후 고착) 승격할 곳이 없어 false — 호출부가 무효화한다.
    /// </summary>
    private bool TryPromoteStuckSaveToNextStage(RunSaveData saveData)
    {
        if (_singleStageMode || _stageSequence == null) return false;

        int previousStageIndex = _currentStageIndex;
        int nextStageIndex = previousStageIndex + 1;
        StageDataSO nextStage = _stageSequence.GetStageAt(nextStageIndex);
        if (nextStage == null)
            return false;

        _currentStageIndex = nextStageIndex;
        if (!GenerateCurrentMap(nextStage))
        {
            _currentStageIndex = previousStageIndex;
            return false;
        }

        saveData.currentStageIndex = nextStageIndex;
        saveData.currentNodeId = RunContext.NoNode;
        saveData.currentFloor = 1;
        saveData.currentNodeResolved = true;
        saveData.stageTransitionPending = true;
        saveData.exploredNodeIds?.Clear();

        Debug.LogWarning(
            $"[InGameController] 해결 완료 보스 고착 세이브 복구 — stage={previousStageIndex} -> {nextStageIndex}");
        return true;
    }

    private StageSequenceSO ResolveStageSequence()
    {
        if (!DataManager.HasInstance || !DataManager.Instance.IsLoaded)
        {
            Debug.LogError("[InGameController] DataManager 미준비 — StageSequenceSO를 불러올 수 없습니다.");
            return null;
        }

        List<StageSequenceSO> sequences = DataManager.Instance.GetAllData<StageSequenceSO>();
        if (sequences == null || sequences.Count == 0) return null;

        ERunDifficulty difficulty = _run != null
            ? _run.Difficulty
            : ERunDifficulty.Normal;
        StageSequenceSO matched = null;
        int matchCount = 0;
        for (int i = 0; i < sequences.Count; i++)
        {
            StageSequenceSO sequence = sequences[i];
            if (sequence == null || !sequence.HasValidStage || sequence.Difficulty != difficulty)
                continue;

            matched = sequence;
            matchCount++;
        }

        if (matchCount != 1)
        {
            Debug.LogError(
                $"[InGameController] 난이도 시퀀스는 정확히 1개여야 합니다. " +
                $"difficulty={RunDifficultyUtility.ToLogValue(difficulty)}, count={matchCount}");
            return null;
        }


#if UNITY_EDITOR || DEVELOPMENT_BUILD
        Debug.Log(
            $"[InGameController] 난이도 시퀀스 결정 - " +
            $"difficulty={RunDifficultyUtility.ToLogValue(difficulty)}, sequence={matched.SequenceId}");
#endif

        return matched;
    }

    private StageDataSO ResolveNextStageData()
    {
        if (_singleStageMode || _stageSequence == null) return null;

        int nextIndex = _currentStageIndex + 1;
        StageDataSO next = _stageSequence.GetStageAt(nextIndex);
        if (next != null)
        {
            _currentStageIndex = nextIndex;
        }

        return next;
    }

    private bool GenerateCurrentMap(StageDataSO stageData)
    {
        if (_run == null || stageData == null)
        {
            Debug.LogError("[InGameController] StageDataSO가 지정되지 않았습니다. 맵 생성 불가.");
            return false;
        }

        _currentStageData = stageData;
        WarnForMissingStageBgmKeys(stageData);
        _run.GenerateMap(stageData, _currentStageIndex);

        EventController.AssignMapEvents(_run, _run.Map, _currentStageIndex);

        EnsureEnemyPool();
        // 스테이지 적 풀이 지정돼 있으면 그것으로(등급 분리 + 가중치), 없으면 전역 풀 폴백(경고).
        if (stageData.EnemyPool != null)
        {
            EncounterAssigner.Assign(_run.Map, stageData.EnemyPool, _run.Seed, stageData.EarlyDepthRatio);
        }
        else
        {
            Debug.LogWarning($"[InGameController] 스테이지 적 풀(EnemyPool) 미지정 — 전역 풀로 폴백합니다. stage={stageData.StageId}");
            EncounterAssigner.Assign(_run.Map, _enemyPool, _run.Seed, stageData.EarlyDepthRatio);
        }

#if UNITY_EDITOR || DEVELOPMENT_BUILD
        string mode = _singleStageMode ? "single" : $"sequence:{_currentStageIndex}";
        Debug.Log($"[InGameController] 맵 생성 — mode={mode}, stage={stageData.StageId}, grid={stageData.BattleGridRows}x{stageData.BattleGridColumns}");
#endif
        return true;
    }

    private static void WarnForMissingStageBgmKeys(StageDataSO stageData)
    {
        WarnForMissingStageBgmKey(stageData, "UIMap", stageData.MapBgmKey);
        WarnForMissingStageBgmKey(stageData, "일반 전투", stageData.NormalBattleBgmKey);
        WarnForMissingStageBgmKey(stageData, "엘리트 전투", stageData.EliteBattleBgmKey);
        WarnForMissingStageBgmKey(stageData, "보스 1페이즈", stageData.BossBattleBgmKey);
        WarnForMissingStageBgmKey(stageData, "보스 2페이즈", stageData.BossPhase2BgmKey);
    }

    private static void WarnForMissingStageBgmKey(StageDataSO stageData, string usage, string key)
    {
        if (string.IsNullOrWhiteSpace(key))
        {
            Debug.LogWarning(
                $"[InGameController] StageDataSO {usage} BGM 키가 비어 있어 재생하지 않습니다. " +
                $"stage={stageData.StageId}");
        }
    }

    private int PruneMissingRunDeckCards()
    {
        if (_run == null || !DataManager.HasInstance || !DataManager.Instance.IsLoaded)
            return 0;

        List<int> missingEntryIds = null;
        IReadOnlyList<RunDeckEntry> entries = _run.DeckEntries;
        for (int i = 0; i < entries.Count; i++)
        {
            RunDeckEntry entry = entries[i];
            if (entry == null || HasCardData(entry.CardId)) continue;

            missingEntryIds ??= new List<int>();
            missingEntryIds.Add(entry.EntryId);
        }

        if (missingEntryIds == null) return 0;

        int removed = 0;
        for (int i = 0; i < missingEntryIds.Count; i++)
        {
            if (_run.RemoveCardFromDeckEntry(missingEntryIds[i], out string removedCardId))
            {
                removed++;
#if UNITY_EDITOR || DEVELOPMENT_BUILD
                Debug.LogWarning($"[InGameController] 저장 덱 누락 카드 제거 — entry={missingEntryIds[i]}, card={removedCardId}");
#endif
            }
        }

        return removed;
    }

    private static bool HasCardData(string cardId)
    {
        if (string.IsNullOrEmpty(cardId) || !DataManager.HasInstance || !DataManager.Instance.IsLoaded)
            return false;

        if (DataManager.Instance.HasData<CardDataSO>(cardId))
            return true;

        List<CardDataSO> cards = DataManager.Instance.GetAllData<CardDataSO>();
        if (cards == null) return false;

        for (int i = 0; i < cards.Count; i++)
        {
            CardDataSO card = cards[i];
            if (card != null && string.Equals(card.CardId, cardId, StringComparison.Ordinal))
                return true;
        }

        return false;
    }

    private async UniTask RestoreSavedRunPositionAsync(CancellationToken token)
    {
        if (token.IsCancellationRequested || !IsRunActive || _run == null) return;

        // 전투는 이겼으나 보상을 다 받기 전에 종료한 경우 — 재전투 없이 보상창부터 재개.
        // (미해결 노드 재진입보다 우선: 보상 대기면 전투는 이미 끝난 것이 확정이다.)
        if (_run.HasPendingReward)
        {
            MapNode rewardNode = _run.Map != null ? _run.Map.GetNode(_run.RewardPendingNodeId) : null;
            if (rewardNode != null)
            {
                // 구버전에서 마지막 보스 보상 대기가 저장된 경우에도 새 정책에 맞춰
                // 보상 RNG/팝업을 재생성하지 않고 바로 종결 흐름으로 복구한다.
                if (rewardNode.NodeType == ENodeType.Boss &&
                    (TutorialDirector.IsActive || !HasNextStage()))
                {
                    _run.ClearPendingReward();
                    _restoringSaveData = null;
                    if (TutorialDirector.IsActive)
                        CompleteTutorialRunAsync(token).Forget();
                    else
                        CompleteFinalRunAsync(token).Forget();
                    return;
                }

#if UNITY_EDITOR || DEVELOPMENT_BUILD
                Debug.Log($"[InGameController] 보상 대기 재개 - node={rewardNode.Id}, " +
                          $"골드수령={_run.RewardGoldClaimed}, 카드선택={_run.RewardCardChosen}");
#endif
                _restoringSaveData = null;
                await ResumePendingRewardAsync(token);
                return;
            }

            // 대기 노드를 찾지 못하면(맵 유실) 대기 해제 후 맵으로 폴백.
            _run.ClearPendingReward();
        }

        if (_restoringSaveData != null &&
            !_restoringSaveData.currentNodeResolved &&
            _restoringSaveData.currentNodeId != RunContext.NoNode)
        {
            MapNode node = _run.Map != null ? _run.Map.GetNode(_restoringSaveData.currentNodeId) : null;
            if (node != null)
            {
#if UNITY_EDITOR || DEVELOPMENT_BUILD
                Debug.Log($"[InGameController] 미완료 저장 노드 재진입 - id={node.Id}, 타입={node.NodeType}");
#endif
                _restoringSaveData = null;
                DispatchNode(node, skipEntryFade: true);
                return;
            }
        }

        _restoringSaveData = null;
        await PresentMapAsync(token);
        // 미진입 스테이지 재개(첫 노드 선택 전 저장)라면 진입 연출도 여기서 재생.
        PlayMapIntroIfPending();
    }

    /// <summary>
    /// 저장된 "보상 대기" 상태를 보상창으로 재개한다. 전투는 이미 끝났으므로 재싸움 없이
    /// 보상만 결정적 재생성(시드+노드)해 표시하되, 이미 수령한 항목은 건너뛴다.
    /// </summary>
    private async UniTask ResumePendingRewardAsync(CancellationToken token)
    {
        if (GameFlowManager.HasInstance)
            GameFlowManager.Instance.SetState(EGameState.Result);
        if (!UIManager.HasInstance) return;

        await ShowVictoryRewardAsync(
            token,
            skipGold: _run.RewardGoldClaimed,
            skipCard: _run.RewardCardChosen);
    }

    private void SaveRunProgress(bool currentNodeResolved = true)
    {
        if (!IsRunActive || !_canSaveRunProgress || _run == null) return;
        // 스테이지 전환 체크포인트가 확정된 구간에서는 일반 저장이 이를 덮어쓰지 않는다.
        // (연출 중 디버그 커맨드·외부 시스템 저장이 이전 보스 노드를 되살리는 것을 막는다)
        // 전환 성공 경로는 ClearStageTransitionPending 이후에 저장하므로 영향받지 않는다.
        if (_isStageTransitionPending) return;
        bool resolved = currentNodeResolved || _run.IsCurrentNodeExplored();
        if (resolved)
            _run.MarkCurrentNodeExplored();

        string characterId = SelectedCharacter != null ? SelectedCharacter.CharacterId : null;
        RunSaveSystem.Save(_run, _currentStageIndex, characterId, resolved);
    }

    public void SaveRunProgressFromExternalSystem(bool currentNodeResolved = true)
    {
        SaveRunProgress(currentNodeResolved);
    }

    /// <summary>
    /// 진행 중 선택 이벤트의 확정 지점을 즉시 저장하고 취소 롤백 기준도 그 지점으로 전진시킨다.
    /// </summary>
    public bool SavePendingEventCheckpoint(int nodeId)
    {
        if (!_isEventEffectApplicationInProgress || _run == null ||
            nodeId == RunContext.NoNode || _run.CurrentNodeId != nodeId)
            return false;

        string characterId = SelectedCharacter != null ? SelectedCharacter.CharacterId : null;
        if (!RunSaveSystem.Save(
                _run, _currentStageIndex, characterId, currentNodeResolved: false))
            return false;

        _eventEffectSnapshot = _run.ToSaveData(
            _currentStageIndex,
            characterId,
            currentNodeResolved: false);
        return true;
    }

    /// <summary>이벤트 효과 적용이 끝난 시점에 노드를 확정 저장해 결과 UI 중 종료 시 중복 적용을 막는다.</summary>
    public void CompletePendingEvent(int nodeId)
    {
        if (_run == null || nodeId == RunContext.NoNode || _run.CurrentNodeId != nodeId) return;
        ClearEventEffectTransaction();
        _run.ClearPendingEvent(nodeId);
        SaveRunProgress(currentNodeResolved: true);
    }

    /// <summary>이벤트 선택 비용·효과 묶음의 원자 적용을 시작한다.</summary>
    public bool BeginPendingEventEffectApplication(int nodeId)
    {
        if (_isEventEffectApplicationInProgress || _run == null ||
            nodeId == RunContext.NoNode || _run.CurrentNodeId != nodeId)
            return false;

        string characterId = SelectedCharacter != null ? SelectedCharacter.CharacterId : null;
        _eventEffectInitialSnapshot = _run.ToSaveData(
            _currentStageIndex,
            characterId,
            currentNodeResolved: false);
        _eventEffectSnapshot = _eventEffectInitialSnapshot;
        _isEventEffectApplicationInProgress = true;
        return true;
    }

    /// <summary>이벤트 효과 적용 취소 시 선택 직전 런 상태로 되돌린다.</summary>
    public void CancelPendingEventEffectApplication(int nodeId, bool rollbackToInitial = false)
    {
        if (!_isEventEffectApplicationInProgress || _run == null ||
            nodeId == RunContext.NoNode || _run.CurrentNodeId != nodeId)
        {
            ClearEventEffectTransaction();
            return;
        }

        RunSaveData snapshot = rollbackToInitial
            ? _eventEffectInitialSnapshot
            : _eventEffectSnapshot;
        ClearEventEffectTransaction();
        if (snapshot == null) return;

        if (!_run.RestoreFromSave(snapshot))
        {
            Debug.LogError("[InGameController] 이벤트 효과 취소 스냅샷 복원 실패");
            return;
        }

        // RestoreFromSave 는 덱 엔트리를 새로 만들어 RuntimeData 가 비어 있다.
        // 로드 경로에서는 뒤이어 InitializeRunDeckArrowDirections 가 채워주므로,
        // 롤백 경로에서도 동일하게 채워 방향 확정이 풀리지 않게 한다.
        InitializeRunDeckArrowDirections();

        if (rollbackToInitial)
        {
            string characterId = SelectedCharacter != null ? SelectedCharacter.CharacterId : null;
            if (!RunSaveSystem.Save(
                    _run, _currentStageIndex, characterId, currentNodeResolved: false))
                Debug.LogError("[InGameController] 이벤트 초기 상태 롤백 저장 실패");
        }
    }

    private void ClearEventEffectTransaction()
    {
        _isEventEffectApplicationInProgress = false;
        _eventEffectSnapshot = null;
        _eventEffectInitialSnapshot = null;
    }

    public bool TryGetRestChoiceForCurrentStage(int nodeId, out bool isReinforce)
    {
        isReinforce = false;
        return _run != null && _run.TryGetRestChoice(_currentStageIndex, nodeId, out isReinforce);
    }

    public void RecordRestChoiceForCurrentStage(int nodeId, bool isReinforce)
    {
        _run?.SetRestChoice(_currentStageIndex, nodeId, isReinforce);
    }

    /// <summary>
    /// 앱 일시정지/포커스 상실 등 생명주기 시점의 저장(모바일 백그라운드 킬 대비).
    /// 진행 중 런이 있을 때만 현재 상태를 즉시 기록한다. 노드 전투 중 이탈 대비로
    /// currentNodeResolved=false 로 저장해, 복귀 시 해당 노드를 재진입하게 한다.
    /// </summary>
    public void SaveRunProgressOnLifecycle()
    {
        if (!IsRunActive || _run == null) return;

        // 이벤트 비용·효과 적용 중에는 부분 상태를 저장하지 않는다.
        // 선택 직전 pending 이벤트 체크포인트가 이미 파일에 있으므로 종료 후 안전하게 재시도된다.
        if (_isEventEffectApplicationInProgress) return;

        if (_isStageTransitionPending)
        {
            SaveBossStageTransitionCheckpoint();
            return;
        }

        // 보상 대기 중이면 전투는 끝난 상태 → resolved:true 로 저장(보상창 재개 유지, 재전투 방지).
        // 그 외(전투/이벤트 진행 중일 수 있음)는 resolved:false 로 저장해 해당 노드를 재개한다.
        SaveRunProgress(currentNodeResolved: _run.HasPendingReward);
    }

    /// <summary>
    /// 이어하기가 무효화됐을 때(맵 불일치·저장 손상/변조 등) 신규 런으로 전환됨을 사용자에게 안내한다.
    /// 팝업이 없으면(UIManager 부재) 조용히 넘어간다. 사유별 본문은 로컬라이징 키로 받는다.
    /// </summary>
    public async UniTask NotifySavedRunResetAsync(
        CancellationToken token,
        string descKey = LocalizationKeys.Run.ResetMapDesc)
    {
        if (!UIManager.HasInstance) return;

        UISystemConfirm popup = await UIManager.Instance.OpenAsync<UISystemConfirm>(token);
        if (popup == null) return;

        try
        {
            await popup.ShowAsync(
                Localize(LocalizationKeys.Run.ResetTitle),
                Localize(descKey),
                Localize(LocalizationKeys.Common.Confirm),
                null,
                token);
        }
        catch (OperationCanceledException)
        {
            // 취소되어도 신규 런은 그대로 진행한다.
        }
    }

    private static string Localize(string key)
        => !string.IsNullOrEmpty(key) && LocalizationManager.HasInstance && LocalizationManager.Instance.HasKey(key)
            ? LocalizationManager.Instance.Get(key)
            : key ?? string.Empty;

    private CharacterSO ResolveSavedCharacter(RunSaveData saveData)
    {
        if (saveData == null || !DataManager.HasInstance || !DataManager.Instance.IsLoaded)
            return null;

        if (!string.IsNullOrWhiteSpace(saveData.selectedCharacterId))
        {
            CharacterSO byId = DataManager.Instance.GetData<CharacterSO>(saveData.selectedCharacterId);
            if (byId != null)
                return byId;
        }

        List<CharacterSO> characters = DataManager.Instance.GetAllData<CharacterSO>();
        if (characters == null) return null;

        for (int i = 0; i < characters.Count; i++)
        {
            CharacterSO character = characters[i];
            if (character != null &&
                string.Equals(character.CharacterId, "All", StringComparison.OrdinalIgnoreCase))
            {
                return character;
            }
        }

        EStartingDeck deckType = (EStartingDeck)saveData.selectedDeckType;
        for (int i = 0; i < characters.Count; i++)
        {
            CharacterSO character = characters[i];
            if (character != null && character.DeckType == deckType)
                return character;
        }

        return null;
    }

    private void InitializeAvailableCardPool()
    {
        if (_run == null) return;

        List<CardDataSO> allCards = DataManager.HasInstance && DataManager.Instance.IsLoaded
            ? DataManager.Instance.GetAllData<CardDataSO>()
            : null;
        _run.InitializeAvailableCardPool(allCards);

#if UNITY_EDITOR || DEVELOPMENT_BUILD
        Debug.Log(
            $"[InGameController] 런 카드 풀 확정 — deckType={_run.SelectedDeckType}, " +
            $"available={_run.AvailableCardPool.Count}");
#endif
    }

    // -------------------------------------------------
    // 내부
    // -------------------------------------------------

    private void UnsubscribeBattle()
    {
        if (_battleSubscribed && BattleController.HasInstance)
        {
            BattleController.Instance.OnBattleFinished -= HandleBattleFinished;
            BattleController.Instance.OnPlayerDamageTaken -= HandleStatisticsPlayerDamageTaken;
            BattleController.Instance.OnInfiniteLoopDetected -= HandleStatisticsInfiniteLoop;
            BattleController.Instance.OnChainEnded -= HandleStatisticsChainEnded;
        }
        if (_battleSubscribed && BattleManager.HasInstance)
        {
            BattleManager.Instance.OnCardPlaced -= HandleStatisticsCardPlaced;
            BattleManager.Instance.OnPlayerTurnConfirmed -= HandleStatisticsPlayerTurnConfirmed;
        }
        _battleSubscribed = false;
    }

    private void HandleStatisticsPlayerDamageTaken(int hpDamage)
        => _run?.Statistics.RecordDamageTaken(hpDamage);

    private void HandleStatisticsInfiniteLoop(Card card, Vector2Int position)
        => _run?.Statistics.RecordInfiniteLoop();

    private void HandleStatisticsChainEnded(int peakChainCount)
        => _run?.Statistics.RecordChainCount(peakChainCount);

    private void HandleStatisticsCardPlaced(Card card, Vector2Int position)
    {
        if (card != null)
            _run?.Statistics.RecordCardPlacement(card.CardId);
    }

    private void HandleStatisticsPlayerTurnConfirmed()
    {
        _currentBattleTurnCount++;
        _run?.Statistics.RecordPlayerTurn();
    }

    /// <summary>모든 종료 경로가 공유하는 런 통계 스냅샷 생성.</summary>
    public RunStatisticsSnapshot CaptureRunStatistics(ERunEndReason reason)
    {
        if (_run == null) return LastRunStatistics;
        if (!string.IsNullOrEmpty(_currentRunId) && _statisticsSnapshotRunId == _currentRunId)
            return LastRunStatistics;

        float sessionSeconds = GetCurrentSessionPlaySeconds();
        LastRunStatistics = _run.Statistics.Capture(
            reason,
            CurrentDifficulty,
            Mathf.Max(0f, sessionSeconds - _runStartedAt),
            sessionSeconds,
            _run.DeckEntries);
        _statisticsSnapshotRunId = _currentRunId;
        return LastRunStatistics;
    }

    private static float GetCurrentSessionPlaySeconds()
        => GameManager.HasInstance
            ? GameManager.Instance.CurrentSessionPlaySeconds
            : Time.realtimeSinceStartup;

    protected override void OnDestroy()
    {
        if (_lifetimeCts != null)
        {
            _lifetimeCts.Cancel();
            _lifetimeCts.Dispose();
            _lifetimeCts = null;
        }

        _runClearPresenter?.Dispose();
        UnsubscribeBattle();
        base.OnDestroy();
    }
}
