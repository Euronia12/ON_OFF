// =================================================================
// [스크립트 목적]  상점 시스템. Shop 노드 진입 시 재고를 구성하고,
//                 상점 UI 와 구매/카드제거 로직을 중계한 뒤, 나갈 때 맵 복귀를 알린다.
// [주요 변수]      - _cardCount        : 판매 카드 장수 (기본 5)
//                  - _price* / _removal* : 희귀도별 가격·제거비 밸런스 (인스펙터)
// [의존 관계]      - InGameController(OpenFromMapNodeAsync 로 구동 / RunContext·복귀)
//                  - CardRewardService(판매 카드 추첨, 보상과 공용) / UIManager / UIShopPopup
//                  - ShopInventory / RunContext
// [배치]           인게임 씬에 1개 배치 (SceneSingleton). BattleController 와 동격의 노드 처리자.
// [설계 노트]      - 진입 페이드가 걷히기 전에 UI 생성을 끝내야 해서 InGameController 가
//                    OpenFromMapNodeAsync 를 직접 await 한다(OnMapNodeEntered 구독 아님).
//                    그 이벤트는 튜토리얼 등 관전 시스템용 통지로만 발행된다.
//                  - 가격·제거비는 밸런스 수치 → Constants 금지 원칙 따라 인스펙터 필드로 노출.
//                  - 골드 차감·덱 반영은 여기서 RunContext API 로 수행. 골드 변동 통지(EventManager)는
//                    InGameController 가 보상에서 발행하던 것과 동일하게 여기서도 발행한다.
// =================================================================

using System.Collections.Generic;
using Cysharp.Threading.Tasks;
using UnityEngine;

/// <summary>
/// 상점 노드 처리자. 카드 5장 판매 + 골드 기반 카드 제거를 제공한다.
/// Shop 노드 진입 이벤트를 구독해 UI 를 띄우고, 쇼핑 종료 시 InGameController 로 맵 복귀를 알린다.
/// </summary>
public sealed class ShopController : SceneSingleton<ShopController>
{
    /// <summary>상점 진열 확정 통지. 인자: 제시된 카드 ID 목록. 분석 등 외부 시스템이 구독한다.</summary>
    public event System.Action<IReadOnlyList<string>> OnInventoryBuilt;

    /// <summary>카드 구매 성공 통지. 인자: (카드 ID, 지불 골드).</summary>
    public event System.Action<string, int> OnCardPurchased;

    /// <summary>덱에서 카드 제거 성공 통지. 인자: (카드 ID, 지불 골드).</summary>
    public event System.Action<string, int> OnCardRemoved;

    [Header("재고")]
    [Tooltip("판매 카드 장수")]
    [Min(1)]
    [SerializeField] private int _cardCount = 5;

    [Header("카드 가격 (희귀도별 기본가, x=min y=max 의 랜덤 범위)")]
    [Tooltip("Common 카드 가격 범위 (슬더스 기본 45~55)")]
    [SerializeField] private Vector2Int _priceCommon = new Vector2Int(45, 55);

    [Tooltip("Rare 카드 가격 범위 (슬더스 기본 68~82)")]
    [SerializeField] private Vector2Int _priceRare = new Vector2Int(68, 82);

    [Tooltip("Unique 카드 가격 범위 (슬더스 기본 135~165)")]
    [SerializeField] private Vector2Int _priceUnique = new Vector2Int(135, 165);

    [Tooltip("Legendary 카드 가격 범위")]
    [SerializeField] private Vector2Int _priceLegendary = new Vector2Int(220, 280);

    [Header("카드 제거 비용 (점증)")]
    [Tooltip("최초 제거 비용 (슬더스 기본 75)")]
    [SerializeField] private int _removalBaseCost = 75;

    [Tooltip("제거할 때마다 증가하는 비용 (슬더스 기본 +25)")]
    [SerializeField] private int _removalStep = 25;

    [Tooltip("제거 비용 상한 (0 이하면 무제한). 슬더스는 보통 상한 없음")]
    [SerializeField] private int _removalMaxCost = 0;

    // 현재 방문 상태.
    private ShopInventory _inventory;
    private UIShopPopup _popup;
    private int _currentNodeId = RunContext.NoNode;

    protected override void OnDestroy()
    {
        DetachPopup();
        base.OnDestroy();
    }

    // 상점 열기는 InGameController.EnterNonBattleNodeWithFadeAsync 가 OpenFromMapNodeAsync 로
    // 직접 구동한다(페이드 안에서 UI 생성까지 대기해야 하므로). OnMapNodeEntered 는
    // 튜토리얼 등 관전 시스템용 통지로만 쓰이며, 여기서 구독하면 상점이 이중으로 열린다.

    /// <summary>InGameController의 페이드 내부에서 호출. UI 생성 완료까지 기다린다.</summary>
    public async UniTask OpenFromMapNodeAsync(int nodeId)
    {
        _currentNodeId = nodeId;
        await OpenShopAsync();
    }

    // ─────────────────────────────────────────────
    // 상점 열기 / 재고 구성
    // ─────────────────────────────────────────────

    private async UniTask OpenShopAsync()
    {
        RunContext run = CurrentRun;
        if (run == null)
        {
            ResolveAndReturn();
            return;
        }

        // 상점 BGM (맵 BGM 위로 크로스페이드). 나갈 때 ResolveAndReturn 에서 맵으로 복귀.
        if (AudioManager.HasInstance)
            AudioManager.Instance.PlayBgmAsync(AudioKeys.Bgm.SHOP, crossfade: 1f).Forget();

        _inventory = BuildInventory(run, _currentNodeId);

        // 진열 목록 통지 (분석 등).
        if (OnInventoryBuilt != null && _inventory != null)
        {
            IReadOnlyList<ShopCardEntry> items = _inventory.Items;
            var offeredIds = new List<string>(items.Count);
            for (int i = 0; i < items.Count; i++)
            {
                if (items[i] != null && items[i].Card != null)
                    offeredIds.Add(items[i].Card.CardId);
            }
            OnInventoryBuilt.Invoke(offeredIds);
        }

        if (!UIManager.HasInstance)
        {
            ResolveAndReturn();
            return;
        }

        UIShopPopup.Show(_inventory);
        UIShopPopup popup = await UIManager.Instance.OpenAsync<UIShopPopup>();
        if (popup == null)
        {
            ResolveAndReturn();
            return;
        }

        _popup = popup;

        // 콜백 재구독 (중복 방지). 구매=카드 / 제거=덱 카드 1장 / 나가기=맵 복귀.
        popup.OnBuyCardRequested -= HandleBuyCard;
        popup.OnRemoveCardRequested -= HandleRemoveCard;
        popup.OnLeaveRequested -= HandleLeave;
        popup.OnBuyCardRequested += HandleBuyCard;
        popup.OnRemoveCardRequested += HandleRemoveCard;
        popup.OnLeaveRequested += HandleLeave;

#if UNITY_EDITOR || DEVELOPMENT_BUILD
        Debug.Log($"[ShopController] 상점 진입 — 판매 {_inventory.Items.Count}장, 제거비 {_inventory.CardRemovalCost}");
#endif
    }

    /// <summary>이번 방문 재고 구성 — 판매 카드 추첨(Shop 풀) + 희귀도별 가격 + 점증 제거비.</summary>
    private ShopInventory BuildInventory(RunContext run, int nodeId)
    {
        if (TryBuildSavedInventory(run, nodeId, out ShopInventory savedInventory))
            return savedInventory;

        CardRewardService rewardService = CreateRewardService(run);

        int removalCost = CalcRemovalCost(run.CardRemovalCount);
        ShopInventory inv = new ShopInventory(removalCost);

        // Shop 풀에서 카드 추첨. 상점별 재고가 섞이지 않도록 노드 기준 RNG 를 사용한다.
        System.Random shopRng = CreateShopRandom(run, nodeId);
        CardQueryCriteria criteria = new CardQueryCriteria(
            pool: ECardPool.Shop,
            rarity: null,
            unlockedOnly: true,
            stagePool: ResolveCurrentCardStage());
        List<CardDataSO> picks = rewardService.PickRandom(in criteria, _cardCount, shopRng);

        if (picks != null)
        {
            for (int i = 0; i < picks.Count; i++)
            {
                CardDataSO card = picks[i];
                if (card == null) continue;
                inv.AddCard(card, RollPrice(card.Rarity, shopRng), ResolveShopCardArrow(card));
            }
        }

        SaveInventoryState(run, inv, nodeId);
        return inv;
    }

    public bool TryDebugRerollInventory()
    {
        if (!DebugCommandManager.CanExecuteDomain(EDebugCommand.RerollShop)) return false;
        RunContext run = CurrentRun;
        if (run == null || _inventory == null || _popup == null || !_popup.IsOpen ||
            _currentNodeId == RunContext.NoNode)
            return false;

        CardRewardService rewardService = CreateRewardService(run);
        var inv = new ShopInventory(CalcRemovalCost(run.CardRemovalCount));
        var rng = new System.Random(run.Rng.Next());
        CardQueryCriteria criteria = new CardQueryCriteria(
            pool: ECardPool.Shop,
            rarity: null,
            unlockedOnly: true,
            stagePool: ResolveCurrentCardStage());
        List<CardDataSO> picks = rewardService.PickRandom(in criteria, _cardCount, rng);
        if (picks == null || picks.Count == 0) return false;

        for (int i = 0; i < picks.Count; i++)
        {
            CardDataSO card = picks[i];
            if (card == null) continue;
            inv.AddCard(card, RollPrice(card.Rarity, rng), ResolveShopCardArrow(card));
        }
        if (inv.Items.Count == 0) return false;

        _inventory = inv;
        SaveInventoryState(run, inv, _currentNodeId);
        SaveRunProgress(currentNodeResolved: false);
        _popup.RefreshDebugInventory(inv);
        return true;
    }

    private bool TryBuildSavedInventory(RunContext run, int nodeId, out ShopInventory inv)
    {
        inv = null;
        if (run == null || !run.TryGetShopState(nodeId, out RunSaveShopState state) || state == null)
            return false;

        inv = new ShopInventory(state.cardRemovalCost);
        if (state.cards != null)
        {
            for (int i = 0; i < state.cards.Count; i++)
            {
                RunSaveShopCardEntry saved = state.cards[i];
                if (saved == null || string.IsNullOrEmpty(saved.cardId)) continue;

                CardDataSO card = DataManager.HasInstance
                    ? DataManager.Instance.GetData<CardDataSO>(saved.cardId)
                    : null;
                if (card == null) continue;

                inv.AddCard(
                    card,
                    saved.price,
                    (ECardDirection)saved.arrowDirection,
                    saved.purchased);
            }
        }

        return inv.Items.Count > 0;
    }

    private ECardDirection ResolveShopCardArrow(CardDataSO card)
    {
        Card preview = CardFactory.CreateFromSO(card, upgraded: false);
        return preview != null && preview.Arrow != null
            ? preview.Arrow.Current
            : ECardDirection.None;
    }

    private System.Random CreateShopRandom(RunContext run, int nodeId)
    {
        if (run == null)
            return new System.Random();

        int resolvedNodeId = nodeId != RunContext.NoNode ? nodeId : run.CurrentNodeId;
        return new System.Random(StableShopSeed(run.Seed, resolvedNodeId, run.CurrentFloor));
    }

    private static int StableShopSeed(int runSeed, int nodeId, int floor)
    {
        unchecked
        {
            uint hash = 2166136261u;
            hash = (hash ^ (uint)runSeed) * 16777619u;
            hash = (hash ^ (uint)nodeId) * 16777619u;
            hash = (hash ^ (uint)floor) * 16777619u;
            hash = (hash ^ 0x53484F50u) * 16777619u; // "SHOP" salt.
            return (int)(hash & 0x7fffffff);
        }
    }

    private CardRewardService CreateRewardService(RunContext run)
    {
        CardRarityWeights weights = InGameController.HasInstance
            ? InGameController.Instance.CurrentCardRewardRarityWeights
            : CardRarityWeights.Default;
        return new CardRewardService(
            run != null ? run.AvailableCardPool : null,
            AlwaysUnlockedProvider.Instance,
            weights);
    }

    private ECardStagePool ResolveCurrentCardStage()
    {
        // 현재 막에 맞는 스테이지 풀. 상점은 InGameController 로 구동되므로 그 진행 값을 따른다.
        int stageNumber = InGameController.HasInstance
            ? InGameController.Instance.CurrentStageNumber
            : 1;
        return CardQueryCriteria.StageForNumber(stageNumber);
    }

    /// <summary>희귀도별 가격 범위에서 시드 난수로 추첨.</summary>
    private int RollPrice(ECardRarity rarity, System.Random rng)
    {
        Vector2Int range = rarity switch
        {
            ECardRarity.Rare => _priceRare,
            ECardRarity.Unique => _priceUnique,
            ECardRarity.Legendary => _priceLegendary,
            _ => _priceCommon,
        };

        int min = Mathf.Min(range.x, range.y);
        int max = Mathf.Max(range.x, range.y);
        if (max <= 0) return 0;
        return rng.Next(min, max + 1); // 상한 포함
    }

    /// <summary>점증 제거 비용: base + step * 이미_제거한_횟수 (상한 옵션).</summary>
    private int CalcRemovalCost(int alreadyRemoved)
    {
        int cost = _removalBaseCost + _removalStep * Mathf.Max(0, alreadyRemoved);
        if (_removalMaxCost > 0) cost = Mathf.Min(cost, _removalMaxCost);
        return cost;
    }

    // ─────────────────────────────────────────────
    // 구매 / 제거 (UI 콜백)
    // ─────────────────────────────────────────────

    /// <summary>카드 구매 — 잔액 확인 → 골드 차감 → 덱 추가 → 항목 구매표시.</summary>
    private void HandleBuyCard(ShopCardEntry entry)
    {
        RunContext run = CurrentRun;
        if (run == null || entry == null || entry.Purchased || entry.Card == null) return;

        if (!run.SpendGold(entry.Price))
        {
#if UNITY_EDITOR || DEVELOPMENT_BUILD
            Debug.Log($"[ShopController] 구매 실패(잔액 부족) — {entry.Card.CardId} ({entry.Price}골드, 보유 {run.Gold})");
#endif
            return; // 잔액 부족 — 미차감
        }

        if (!InGameController.HasInstance ||
            !InGameController.Instance.AddCardToRunDeck(entry.Card.CardId, entry.ArrowDirection))
        {
            run.AddGold(entry.Price);
            return;
        }
        entry.MarkPurchased();
        if (AudioManager.HasInstance)
            AudioManager.Instance.PlaySfxAsync(AudioKeys.Card.BUY).Forget();

        SaveInventoryState(run, _inventory, _currentNodeId);
        SaveRunProgress(currentNodeResolved: false);
        PublishGoldChanged(run, -entry.Price);

        // 구매 통지 (분석 등). 골드 차감·덱 반영이 모두 성공한 뒤에만 발행한다.
        OnCardPurchased?.Invoke(entry.Card.CardId, entry.Price);

#if UNITY_EDITOR || DEVELOPMENT_BUILD
        Debug.Log(
            $"[ShopController] 카드 구매 — {entry.Card.CardId}, direction={entry.ArrowDirection} " +
            $"(-{entry.Price}골드, 보유 {run.Gold})");
#endif
    }

    /// <summary>
    /// 카드 제거 — 잔액 확인 → 골드 차감 → 덱에서 해당 엔트리 제거 → 제거 횟수 누적(점증).
    /// 제거 대상 EntryId 는 UI(덱 뷰어)에서 선택해 전달한다.
    /// </summary>
    private bool HandleRemoveCard(int entryId)
    {
        RunContext run = CurrentRun;
        if (run == null || _inventory == null) return false;
        if (!_inventory.RemovalAvailable) return false;

        // 비용은 현재까지의 제거 횟수로 매번 산정 (같은 방문 내 연속 제거도 점증).
        int cost = CalcRemovalCost(run.CardRemovalCount);
        if (!run.CanAffordGold(cost)) return false; // 잔액 부족

        // 영구 덱에서 제거 (RunContext 직접 — 구매 추가와 동일 경로로 일원화).
        if (!run.RemoveCardFromDeckEntry(entryId, out string cardId)) return false; // 덱에 없으면 차감 안 함

        run.SpendGold(cost);
        run.RegisterCardRemoval(); // 제거 횟수 누적 → 다음 비용 점증

        // 제거 통지 (분석 등).
        OnCardRemoved?.Invoke(cardId, cost);

        if (AudioManager.HasInstance)
            AudioManager.Instance.PlaySfxAsync(AudioKeys.Card.REMOVE).Forget();

        // 다음 제거 비용으로 인벤토리 갱신 (UI 표시 갱신용).
        _inventory.UpdateRemovalCost(CalcRemovalCost(run.CardRemovalCount));
        SaveInventoryState(run, _inventory, _currentNodeId);
        SaveRunProgress(currentNodeResolved: false);
        PublishGoldChanged(run, -cost);

#if UNITY_EDITOR || DEVELOPMENT_BUILD
        Debug.Log($"[ShopController] 카드 제거 — {cardId} (-{cost}골드, 보유 {run.Gold}, 누적제거 {run.CardRemovalCount})");
#endif
        return true;
    }

    /// <summary>골드 변동 전역 통지 (보상과 동일하게 EventManager 발행).</summary>
    private void PublishGoldChanged(RunContext run, int delta)
    {
        if (delta != 0 && AudioManager.HasInstance)
        {
            string audioKey = delta > 0
                ? AudioKeys.Game.GOLD_GAIN
                : AudioKeys.Game.GOLD_SPEND;
            AudioManager.Instance.PlayUiAsync(audioKey).Forget();
        }

        if (!EventManager.HasInstance) return;
        EventManager.Instance.Publish(new OnGoldChanged
        {
            Current = run.Gold,
            Delta = delta,
        });
    }

    // ─────────────────────────────────────────────
    // 나가기 / 복귀
    // ─────────────────────────────────────────────

    private void HandleLeave()
    {
        ResolveAndReturn();
    }

    /// <summary>상점 종료 — 재고 정리 후 InGameController 에 노드 처리 완료를 알려 맵 복귀.</summary>
    private void ResolveAndReturn()
    {
        ResolveAndReturnAsync().Forget();
    }

    private async UniTaskVoid ResolveAndReturnAsync()
    {
        if (InGameController.HasInstance)
        {
            await InGameController.Instance.NotifyNodeResolvedWithFadeAsync(CompleteReturn);
            return;
        }

        CompleteReturn();
    }

    private void CompleteReturn()
    {
        DetachPopup();
        ClearInventoryState(CurrentRun, _currentNodeId);
        _inventory = null;
        _currentNodeId = RunContext.NoNode;

    }

    private void DetachPopup()
    {
        UIShopPopup popup = _popup;
        _popup = null;
        if (popup == null) return;

        popup.OnBuyCardRequested -= HandleBuyCard;
        popup.OnRemoveCardRequested -= HandleRemoveCard;
        popup.OnLeaveRequested -= HandleLeave;
        if (popup.IsOpen && UIManager.HasInstance)
            UIManager.Instance.Close(popup);
    }

    private RunContext CurrentRun =>
        InGameController.HasInstance ? InGameController.Instance.CurrentRun : null;

    private void SaveInventoryState(RunContext run, ShopInventory inventory, int nodeId)
    {
        if (run == null || inventory == null || nodeId == RunContext.NoNode) return;
        run.SetShopState(inventory.ToSaveData(nodeId));
    }

    private void ClearInventoryState(RunContext run, int nodeId)
    {
        if (run == null || nodeId == RunContext.NoNode) return;
        run.RemoveShopState(nodeId);
    }

    private void SaveRunProgress(bool currentNodeResolved)
    {
        if (InGameController.HasInstance)
            InGameController.Instance.SaveRunProgressFromExternalSystem(currentNodeResolved);
    }
}
