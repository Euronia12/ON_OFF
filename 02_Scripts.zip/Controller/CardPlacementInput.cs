// =================================================================
// [스크립트 목적]  핸드 UICard 의 드롭/호버 입력을 그리드 배치로 잇는 입력 어댑터
//                 (구 CardPlacementController). 그리드 비주얼은 GridSlot 이 흡수했으므로
//                 별도 비주얼 스폰 없이 데이터 배치만 위임한다.
// [주요 변수]      - _camera          : 스크린→월드 Raycast 카메라 (비우면 Camera.main)
//                  - _slotLayerMask   : 그리드 슬롯 레이어
//                  - _rayDistance     : Raycast 최대 거리
// [의존 관계]      - GridManager / BattleManager / UICard / GridSlot
// [배치]           UIBattle 프리팹 자식 (손패 입력을 받는 UI 계층 어댑터).
//                  매니저 접근은 .Instance 정적 접근이라 위치 무관.
// [설계 노트]      - UICard 의 콜백(OnDropRequested 등)을 구독해 동작
//                  - 배치 성공: UICard.ConfirmPlaced() / 배치 실패: UICard.ReturnToHand()
//                  - 그리드 카드 비주얼은 GridSlot 이 직접 표현 (GridCardObject 폐기)
// =================================================================

using Cysharp.Threading.Tasks;
using UnityEngine;

/// <summary>
/// 핸드의 UICard 입력을 그리드 배치로 연결하는 입력 어댑터(MonoBehaviour).
/// UICard 는 "드롭됨/위치변경" 만 통지하고, 이 어댑터가 스크린→슬롯 좌표 변환과
/// BattleManager.PlaceCardAsync 호출을 책임진다. 배치된 카드의 비주얼은 GridSlot 이 표현한다.
/// </summary>
public sealed class CardPlacementInput : MonoBehaviour
{
    private const string CostNotEnoughKey = "UI_COST_NOT_ENOUGH";
    private readonly RaycastHit[] _slotHits = new RaycastHit[32];

    [Header("Raycast")]
    [Tooltip("스크린→월드 Raycast 에 사용할 카메라. 비우면 Camera.main")]
    [SerializeField] private Camera _camera;

    [Tooltip("그리드 슬롯 레이어 마스크. 슬롯 BoxCollider 가 속한 레이어")]
    [SerializeField] private LayerMask _slotLayerMask = ~0;

    [Tooltip("Raycast 최대 거리")]
    [Min(1f)]
    [SerializeField] private float _rayDistance = 100f;

    // 손패 카드 드래그 시작 시 진행 중이던 스킬 시전을 해제하는 콜백.
    // UIBattle 가 스킬 패널의 CancelCast 를 주입한다 (인스펙터 수동 배선 불필요).
    private System.Action _skillCanceller;
    private ICardPlacementService _placementService;

    private Camera Cam => _camera != null ? _camera : Camera.main;

    /// <summary>드래그 시작 시 호출할 스킬 시전 해제 콜백 주입. (UIBattle 가 스킬 패널과 연결)</summary>
    public void SetSkillCanceller(System.Action canceller)
    {
        _skillCanceller = canceller;
    }

    public void SetPlacementService(ICardPlacementService service)
    {
        _placementService = service;
    }

    private ICardPlacementService PlacementService =>
        _placementService ?? (BattleManager.HasInstance ? BattleManager.Instance : null);

    // ── UICard 구독 (BattleController 가 드로우 시 등록) ──────

    /// <summary>UICard 가 드로우되어 손패에 들어올 때 호출 — 콜백 구독.</summary>
    public void RegisterCard(UICard card)
    {
        if (card == null) return;
        card.OnDropRequested += HandleDropRequested;
        card.OnHoverPositionChanged += HandleHoverChanged;
        card.OnDragEnded += HandleDragEnded;
        card.OnDragBegan += HandleDragBegan;
    }

    /// <summary>UICard 가 손패를 떠날 때 호출 — 구독 해제 (누수 방지).</summary>
    public void UnregisterCard(UICard card)
    {
        if (card == null) return;
        card.OnDropRequested -= HandleDropRequested;
        card.OnHoverPositionChanged -= HandleHoverChanged;
        card.OnDragEnded -= HandleDragEnded;
        card.OnDragBegan -= HandleDragBegan;
    }

    // ── 콜백 처리 ───────────────────────────────────────────

    /// <summary>드래그 중 위치 변경 — 마우스 아래 빈칸과 카드 방향 영향 경로를 미리 보여준다.</summary>
    private void HandleHoverChanged(UICard uiCard, Vector2 screenPos)
    {
        if (!GridManager.HasInstance) return;

        GridSlot slot = FindSlotAt(screenPos);
        if (slot != null)
        {
            Card card = uiCard != null ? uiCard.BoundCard : null;
            if (card != null)
            {
                GridManager.Instance.ClearHighlights();
                bool canPlace = EvaluatePlacement(card, slot);
                GridManager.Instance.ShowPlacementPreview(card, slot.Position, canPlace);
            }
            else
            {
                GridManager.Instance.ClearPlacementPreview();
            }
        }
        else
        {
            GridManager.Instance.ClearHighlights();
            GridManager.Instance.ClearPlacementPreview();
        }
    }

    /// <summary>
    /// 신호 경로 프리뷰(방향·사거리·전파 타입 반영) 표시. 호버 칸이 빈 칸일 때만 강조한다.
    /// UICard 콜백이 카드를 싣지 않으므로, 드래그 중인 UICard 의 드래그 핸들러에서
    /// uiCard.BoundCard 와 현재 스크린 좌표로 직접 호출하는 것을 권장한다(경로 미리보기 활성화).
    /// </summary>
    public void PreviewPlacement(Card card, Vector2 screenPos)
    {
        if (!GridManager.HasInstance || card == null) return;

        GridSlot slot = FindSlotAt(screenPos);
        if (slot != null)
        {
            bool canPlace = EvaluatePlacement(card, slot);
            GridManager.Instance.ShowPlacementPreview(card, slot.Position, canPlace);
        }
        else
        {
            GridManager.Instance.ClearPlacementPreview();
        }
    }

    /// <summary>
    /// 호버 칸의 유효 표시 판정. 빈 칸 배치 가능 여부를 확인한다.
    /// </summary>
    private bool EvaluatePlacement(Card card, GridSlot slot)
    {
        ICardPlacementService service = PlacementService;
        return service != null && card != null && slot != null && service.CanPlaceCard(card, slot.Position);
    }

    /// <summary>드래그 시작 — 진행 중이던 스킬 시전 상태를 해제한다 (손패 배치 우선).</summary>
    private void HandleDragBegan(UICard uiCard)
    {
        _skillCanceller?.Invoke();
    }

    /// <summary>드래그 종료 — 하이라이트·프리뷰 정리.</summary>
    private void HandleDragEnded()
    {
        if (GridManager.HasInstance)
        {
            GridManager.Instance.ClearHighlights();
            GridManager.Instance.ClearPlacementPreview();
        }
    }

    /// <summary>드롭됨 — 슬롯 해석 후 배치 시도 (비동기).</summary>
    private void HandleDropRequested(UICard uiCard, Vector2 screenPos)
    {
        if (GridManager.HasInstance)
        {
            GridManager.Instance.ClearPlacementPreview();
        }
        TryPlaceAsync(uiCard, screenPos).Forget();
    }

    /// <summary>
    /// 드롭 위치의 슬롯을 찾아 BattleManager 로 배치 시도.
    /// 성공: UICard 소멸(그리드 비주얼은 슬롯이 표현) / 실패: UICard 손패 복귀.
    /// </summary>
    private async UniTaskVoid TryPlaceAsync(UICard uiCard, Vector2 screenPos)
    {
        if (uiCard == null) return;

        // 배치 확정 외의 모든 종료(실패·예외·취소)에서 반드시 손패로 복귀시킨다.
        // ★ 중간 await(팝업 로드/배치 이벤트)에서 예외·취소로 죽으면 ReturnToHand 가
        //   안 불려 카드가 드롭 위치·드래그 스케일로 박제되는 버그가 있었다.
        bool resolved = false; // ConfirmPlaced/ReturnToHand 중 하나가 이미 처리됐는가
        try
        {
            Card card = uiCard.BoundCard;
            GridSlot slot = FindSlotAt(screenPos);

            ICardPlacementService service = PlacementService;
            if (card == null || service == null) return;
            if (slot == null) return;
            if (!slot.IsEmpty || !slot.IsUsable)
            {
                PlayCannotLocateSfx();
                return;
            }

            if (!card.CanAffordPlacement(service.CurrentEnergy))
            {
                PlayCannotLocateSfx();

                // 팝업 로드(await) 동안 카드를 드롭 위치에 방치하지 않게 먼저 복귀시킨다
                // — 떠 있는 카드를 그 사이 다시 잡으면 위치가 꼬인다.
                uiCard.ReturnToHand();
                resolved = true;

                if (UIManager.HasInstance)
                {
                    UISystemNavi systemNavi =
                        await UIManager.Instance.OpenAsync<UISystemNavi>();
                    systemNavi?.Show(CostNotEnoughKey);
                }
                return;
            }

            if (await service.PlaceCardAsync(card, slot.Position))
            {
                // 배치 성공 — 손패 UICard 제거 (그리드 슬롯 비주얼이 대체).
                uiCard.ConfirmPlaced();
                resolved = true;
            }
            else
            {
                if (!slot.IsEmpty || !slot.IsUsable)
                    PlayCannotLocateSfx();
            }
        }
        finally
        {
            if (!resolved && uiCard != null)
            {
                // 실패/중단 — 카드 손패 복귀.
                uiCard.ReturnToHand();
            }
        }
    }

    // ── 내부 ───────────────────────────────────────────────

    private static void PlayCannotLocateSfx()
    {
        if (AudioManager.HasInstance)
            AudioManager.Instance.PlaySfxAsync(AudioKeys.Card.CANNOT_LOCATE).Forget();
    }

    /// <summary>스크린 좌표 아래의 그리드 슬롯을 Raycast 로 탐지. 없으면 null.</summary>
    private GridSlot FindSlotAt(Vector2 screenPos)
    {
        Camera cam = Cam;
        if (cam == null) return null;

        Ray ray = cam.ScreenPointToRay(screenPos);
        int hitCount = Physics.RaycastNonAlloc(
            ray,
            _slotHits,
            _rayDistance,
            _slotLayerMask,
            QueryTriggerInteraction.Collide);

        GridSlot nearestSlot = null;
        float nearestDistance = float.MaxValue;
        for (int i = 0; i < hitCount; i++)
        {
            RaycastHit hit = _slotHits[i];
            if (hit.collider == null) continue;

            GridSlot slot = hit.collider.GetComponentInParent<GridSlot>();
            if (slot == null || hit.distance >= nearestDistance) continue;

            nearestSlot = slot;
            nearestDistance = hit.distance;
        }

        return nearestSlot;
    }
}
