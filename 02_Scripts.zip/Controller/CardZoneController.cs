﻿// =================================================================
// [스크립트 목적]  카드 영역 간 이동 조율 + ICardGameService 구현 (드로우/순환)
// [주요 변수]      - _deck/_hand/_graveyard : 세 영역
//                  - _rng : 셔플 시드 (슬더스식 결정론적 셔플 대비)
// [의존 관계]      - Deck/Hand/Graveyard/Card/CardFactory/GridManager
//                  - ICardGameService 구현 → BattleManager/효과의 드로우 호출을 실제 처리
// [설계 노트]      - 이동 로직을 한 곳에 집중 (Draw/Play/Discard/Reshuffle)
//                  - 덱 소진 시 묘지 셔플 재채움 (순환형)
//                  - 비주얼은 각 영역 이벤트(OnCardAdded/Removed) 구독으로 분리
// =================================================================

using System.Collections.Generic;
using Cysharp.Threading.Tasks;
using UnityEngine;

/// <summary>
/// 덱/핸드/묘지 간 카드 이동을 조율하고 ICardGameService 를 구현한다.
/// Draw(덱→핸드), Play(핸드→필드), Discard(핸드/필드→묘지), Reshuffle(묘지→덱)을 담당.
/// 덱이 소진되면 묘지를 섞어 자동 재채움한다 (순환형, 슬더스 방식).
/// </summary>
public sealed class CardZoneController : ICardGameService, ICardZoneService
{
    private readonly Deck _deck = new Deck();
    private readonly Hand _hand = new Hand();
    private readonly Graveyard _graveyard = new Graveyard();
    private readonly System.Random _rng;

    public Deck Deck => _deck;
    public Hand Hand => _hand;
    public Graveyard Graveyard => _graveyard;

    // ICardZoneService.Hand 명시적 구현 (손패 읽기 전용 노출).
    IReadOnlyList<Card> ICardZoneService.Hand => _hand.Cards;

    /// <param name="seed">셔플 시드. 동일 시드면 동일 셔플 (재현·테스트·슬더스식 런).</param>
    /// <param name="maxHandSize">최대 손패 수.</param>
    public CardZoneController(int? seed = null, int maxHandSize = 10)
    {
        _rng = seed.HasValue ? new System.Random(seed.Value) : new System.Random();
        _hand.SetMaxHandSize(maxHandSize);
    }

    // ── 덱 구성 ─────────────────────────────────────────────

    /// <summary>
    /// 유저 덱 데이터로 덱 초기화. SO 리스트 → Card 생성 → 덱에 채우고 셔플.
    /// 전투 시작 전 1회 호출.
    /// </summary>
    public void BuildDeck(IReadOnlyList<CardDataSO> deckData)
    {
        _deck.Clear();
        _hand.Clear();
        _graveyard.Clear();

        if (deckData != null)
        {
            for (int i = 0; i < deckData.Count; i++)
            {
                Card card = CardFactory.CreateFromSO(deckData[i]);
                if (card != null) _deck.Add(card);
            }
        }
        _deck.Shuffle(_rng);
    }

    // ── ICardGameService 구현 ───────────────────────────────

    /// <summary>전투 시작 초기 핸드 드로우.</summary>
    public void DrawInitialHand(int count)
    {
        DrawCards(count);
    }

    /// <summary>카드 count 장 드로우 (덱→핸드). 덱 소진 시 묘지 셔플 재채움.</summary>
    public void DrawCards(int count, Card source = null)
    {
        bool drewAny = false;
        for (int i = 0; i < count; i++)
        {
            if (!DrawOne())
            {
                break; // 더 뽑을 카드 없음 (덱+묘지 모두 소진)
            }
            drewAny = true;
        }

        // 여러 장을 뽑아도 효과음은 1회만 (초기 핸드 드로우 시 소리 겹침 방지).
        if (drewAny) PlaySfx(AudioKeys.Card.DRAW);
    }

    /// <summary>사운드 재생 헬퍼. AudioManager 가 없거나 에셋이 없으면 조용히 무시된다.</summary>
    private static void PlaySfx(string key)
    {
        if (AudioManager.HasInstance)
            AudioManager.Instance.PlaySfxAsync(key).Forget();
    }

    /// <summary>이미 생성된 카드 1장을 곧바로 손패에 추가한다 (손패 가득 차면 무시).</summary>
    public void AddCardToHand(Card card)
    {
        if (card == null) return;
        _hand.TryAdd(card);
    }

    /// <summary>에너지 획득. 자원 시스템 연결 시 구현 (현재 로그만).</summary>
    public void GainEnergy(int amount)
    {
#if UNITY_EDITOR || DEVELOPMENT_BUILD
        Debug.Log($"[CardZone] GainEnergy {amount} (자원 시스템 미연결)");
#endif
        // [추정 구현] 에너지/자원 매니저 연결 시 교체
    }

    public void ExhaustCard(Card card)
    {
        if (card == null) return;
        _deck.Remove(card);
        _hand.Remove(card);
        _graveyard.Remove(card);
        card.ClearRecallCostOverride();
    }

    // ── 이동 ───────────────────────────────────────────────

    /// <summary>한 장 드로우. 덱 비면 묘지 재채움 후 재시도. 손패 가득 차면 묘지로 버림.</summary>
    private bool DrawOne()
    {
        if (_deck.IsEmpty)
        {
            ReshuffleGraveyardIntoDeck();
            if (_deck.IsEmpty) return false; // 묘지도 비어 더 못 뽑음
        }

        Card card = _deck.DrawTop();
        if (card == null) return false;

        // 손패 가득 차면 오버플로우 → 묘지로 (드로우는 소비된 것으로 간주).
        if (!_hand.TryAdd(card))
        {
            _graveyard.Add(card);
        }
        return true;
    }

    /// <summary>핸드 → 필드(그리드) 배치 성공 시 핸드에서 제거. 배치는 호출자가 GridManager 로 수행.</summary>
    public void OnCardPlayedToField(Card card)
    {
        _hand.Remove(card);
        card?.ClearRecallCostOverride();
        PlaySfx(AudioKeys.Card.PLACE);
        // 필드(그리드)에 올라간 카드는 그리드가 소유. 묘지행은 그리드 정리 시 DiscardFromField 로.
    }

    /// <summary>핸드 → 묘지 (손패 카드 버리기).</summary>
    public void DiscardFromHand(Card card)
    {
        if (_hand.Remove(card))
        {
            card.ClearRecallCostOverride();
            if (!card.IsHandOnlyDisturbance)
            {
                _graveyard.Add(card);
            }
            if (!_suppressDiscardSfx) PlaySfx(AudioKeys.Card.DISCARD);
        }
    }

    // 손패 일괄 버리기 중 장당 효과음이 겹치지 않도록 억제하는 플래그.
    private bool _suppressDiscardSfx;

    /// <summary>핸드 전체 → 묘지 (턴 종료 시 손패 정리, 보존 제외는 호출자가 사전 처리).</summary>
    public void DiscardHand()
    {
        // 스냅샷 후 이동 (순회 중 변경 방지).
        var snapshot = new List<Card>(_hand.Cards);
        if (snapshot.Count == 0) return;

        _suppressDiscardSfx = true;
        for (int i = 0; i < snapshot.Count; i++)
        {
            DiscardFromHand(snapshot[i]);
        }
        _suppressDiscardSfx = false;

        // 여러 장을 버려도 효과음은 1회만.
        PlaySfx(AudioKeys.Card.DISCARD);
    }

    /// <summary>필드 → 묘지 (그리드에서 회수된 카드를 묘지로). GridManager 회수와 연동.</summary>
    public void DiscardFromField(Card card)
    {
        if (card != null)
        {
            card.ClearRecallCostOverride();
            _graveyard.Add(card);
        }
    }

    public void ReturnFieldCardToHand(Card card)
    {
        _hand.TryAdd(card);
    }

    public void ExhaustFromField(Card card)
    {
        ExhaustCard(card);
    }

    /// <summary>드로우 더미에 카드 1장을 추가하고 섞는다.</summary>
    public void AddCardToDrawPileAndShuffle(
        Card card,
        EBattleDeckOwner owner = EBattleDeckOwner.PlayerTemporary)
    {
        if (card == null) return;

        card.SetBattleDeckOwner(owner);
        _deck.Add(card);
        _deck.Shuffle(_rng);
    }

    /// <summary>묘지를 섞어 덱으로 되돌림 (덱 소진 시 순환).</summary>
    public void ReshuffleGraveyardIntoDeck()
    {
        if (_graveyard.IsEmpty) return;

        List<Card> recycled = _graveyard.TakeAll();
        _deck.AddRange(recycled);
        _deck.Shuffle(_rng);

#if UNITY_EDITOR || DEVELOPMENT_BUILD
        Debug.Log($"[CardZone] 묘지 {recycled.Count}장 → 덱 재채움(셔플)");
#endif
    }
}
