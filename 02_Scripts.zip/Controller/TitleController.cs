﻿// =================================================================
// [스크립트 목적]  타이틀 씬 컨트롤러 템플릿. 씬 생명주기 + UI 활성화 + 씬 전환
// [의존 관계]      - BootstrapInitializer, GameFlowManager, GameManager, UIManager,
//                    AudioManager, SaveManager, UserManager, SceneFlowManager
// [배치]           Title 씬에 빈 GameObject 만들고 이 컴포넌트 부착
// [주의]           첫 씬이므로 Start에서 WaitForReadyAsync 필수.
//                  ISceneLifecycle 구현 — 다른 씬에서 Title로 "복귀"할 때도 훅 동작
// =================================================================
using System;
using System.Threading;
using Cysharp.Threading.Tasks;
using UnityEngine;

public class TitleController : MonoBehaviour, ISceneLifecycle
{
    [Header("씬 전환")]
    [Tooltip("게임 시작 시 이동할 씬 이름")]
    [SerializeField] private string _gameSceneName = "Main";

    [Tooltip("튜토리얼 선택 시 이동할 씬 이름")]
    [SerializeField] private string _tutorialSceneName = "Tutorial";

    [Header("타이틀 리소스")]
    [Tooltip("타이틀 UI Addressable 키")]
    [SerializeField] private string _titleUIKey = "UITitle";

    [Tooltip("타이틀 BGM Addressable 키")]
    [SerializeField] private string _titleBgmKey = "BGM_Title";

    [Tooltip("세이브 슬롯 이름")]
    [SerializeField] private string _saveSlot = "slot1";

    [Header("크레딧 연출")]
    [Tooltip("타이틀 크레딧용 ClearBg/중앙 걷기 연출")]
    [SerializeField] private TitleCreditWalkSequence _titleCreditWalkSequence;

    [Tooltip("크레딧 진입·종료 시 검은 페이드 시간(초)")]
    [Min(0f)]
    [SerializeField] private float _creditFadeDuration = 0.5f;

    private UITitle _titleUI;
    private TitleMainMenu _cardMenu;
    private CancellationTokenSource _cts;
    private UIOptions _titleOptionsPopup;
    private UICreditScroll _titleCreditPopup;
    private UICardPileViewer _titleCollectionPopup;
    private bool _isExiting;
    private bool _isCreditOpening;
    private bool _isCreditClosing;
    private bool _creditClosePending;
    private bool _titleHiddenForCredits;

    private void Awake()
    {
        _cts = new CancellationTokenSource();

        // 씬 생명주기 등록 (다른 씬에서 Title로 복귀 시 SceneFlowManager가 훅 호출)
        if (SceneFlowManager.HasInstance)
            SceneFlowManager.Instance.RegisterLifecycle(this);
    }

    private void Start()
    {
        // Unity 메시지 Start는 void여야 함 (UniTaskVoid는 UNT0006 경고).
        // 비동기 작업은 별도 메서드로 분리해 Forget 호출.
        InitializeAsync().Forget();
    }

    private async UniTaskVoid InitializeAsync()
    {
        // 첫 씬이므로 매니저 초기화 완료 대기 (복귀 시엔 즉시 통과)
        await BootstrapInitializer.WaitForReadyAsync();

        // 최초 실행이면 타이틀 UI·BGM을 건너뛰고 튜토리얼 씬으로 바로 진입.
        // 씬 전환으로 복귀한 경우(_enteredViaTransition)는 대상이 아니다.
        if (!_enteredViaTransition && !FirstLaunchStore.HasEnteredTutorial)
        {
            if (await TryEnterFirstLaunchTutorialAsync())
                return;
            // 진입 불가(씬 이름 미지정 등)면 아래 일반 타이틀 흐름으로 폴백
        }

        // 첫 진입(게임 시작 직후)은 씬 전환 시퀀스를 안 타므로 직접 Enter/Ready 호출.
        // 다른 씬에서 복귀한 경우엔 SceneFlowManager가 이미 호출했으므로 중복 방지 플래그 사용.
        if (!_enteredViaTransition)
        {
            await OnSceneEnter(_cts.Token);
            OnSceneReady();
        }
    }

    // 씬 전환으로 진입했는지 구분 (복귀 시 SceneFlowManager가 OnSceneEnter 호출 → true)
    private bool _enteredViaTransition;
    // OnSceneEnter 중복 실행 방지. Start()와 SceneFlowManager가 경쟁해
    // OnSceneEnter가 두 번 불릴 수 있으므로 1회만 수행되도록 가드 (InGameController와 동일).
    private bool _sceneEntered;

    // ─────────────────────────────────────────────
    // ISceneLifecycle
    // ─────────────────────────────────────────────

    public async UniTask OnSceneEnter(CancellationToken token)
    {
        // 중복 진입 차단 (Start ↔ SceneFlowManager 경쟁으로 두 번 불릴 수 있음)
        if (_sceneEntered) return;
        _sceneEntered = true;

        _enteredViaTransition = true;

        // 첫 씬은 전환 시퀀스를 안 타 OnSceneLoadComplete가 발행되지 않으므로,
        // 현재 씬 카메라를 명시적으로 재탐색 → Screen Canvas 카메라 연결을 트리거한다.
        // (CameraManager가 OnMainCameraChanged를 발행 → UIManager가 Canvas에 연결)
        if (CameraManager.HasInstance)
            CameraManager.Instance.RefreshMainCamera();
        if (UIManager.HasInstance)
            UIManager.Instance.SetUIRootCamera();

        // 페이드 뒤(화면 가려진 상태)에서 무거운 준비 작업
        GameFlowManager.Instance.SetState(EGameState.Title);

        // 타이틀 UI 로드 + 열기
        _titleUI = await UIManager.Instance.OpenAsync<UITitle>(_titleUIKey, token);

        // 오늘 최종 클리어 기록 여부에 따라 배경 스프라이트 결정.
        // 이 구간은 페이드로 화면이 가려진 상태라 스왑 플래시가 보이지 않는다.
        if (_titleUI != null)
        {
            _titleUI.OnOpened -= HandleTitleOpened;
            _titleUI.OnOpened += HandleTitleOpened;
            await RefreshTitleBackgroundAsync(token);
        }

        if (UIManager.HasInstance)
        {
            UIManager.Instance.OnEscapeUnhandled -= HandleEscapeUnhandled;
            UIManager.Instance.OnEscapeUnhandled += HandleEscapeUnhandled;
        }

        BindCardMenu();

        // BGM 미리 준비 (재생은 Ready에서)
        // 필요 시 여기서 추가 에셋 프리로드
    }

    private void HandleTitleOpened()
    {
        if (_cts == null || _cts.IsCancellationRequested)
            return;

        RefreshTitleBackgroundAsync(_cts.Token).Forget();
    }

    private async UniTask RefreshTitleBackgroundAsync(CancellationToken token)
    {
        if (_titleUI == null)
            return;

        bool clearedToday = await TitleClearStore.IsClearedTodayAsync(token);
        if (_titleUI != null)
            _titleUI.SetClearBackground(clearedToday);
    }

    public void OnSceneReady()
    {
        // 페이드 인 완료 후 — BGM 시작, 인트로 연출 등
        if (AudioManager.HasInstance)
            AudioManager.Instance.PlayBgmAsync(_titleBgmKey, crossfade: 1f).Forget();
    }

    public async UniTask OnSceneExit(CancellationToken token)
    {
        _isExiting = true;
        if (UIManager.HasInstance)
            UIManager.Instance.OnEscapeUnhandled -= HandleEscapeUnhandled;
        UnbindCardMenu();
        CleanupTitleCreditPresentation();

        // 타이틀 떠날 때 정리 (페이드 뒤)
        // UI 닫기
        if (UIManager.HasInstance)
            UIManager.Instance.CloseAll();

        // BGM 페이드 아웃
        if (AudioManager.HasInstance)
            AudioManager.Instance.StopBgm(fadeOut: 0.5f);

        await UniTask.CompletedTask;
    }

    private void HandleMenuActionSelected(ETitleMenuAction action)
    {
        ExecuteMenuActionAsync(action).Forget();
    }

    private void HandleEscapeUnhandled()
    {
        _titleUI?.CancelDifficultySelection();
    }

    private async UniTask ExecuteMenuActionAsync(ETitleMenuAction action)
    {
        switch (action)
        {
            case ETitleMenuAction.GameStart:
                await StartGameAsync();
                break;
            case ETitleMenuAction.Continue:
                await ContinueGameAsync();
                break;
            case ETitleMenuAction.Options:
                if (AudioManager.HasInstance)
                    AudioManager.Instance.StopBgm(fadeOut: 0f);
                if (UIManager.HasInstance)
                {
                    _titleOptionsPopup = await UIManager.Instance.OpenAsync<UIOptions>(_cts.Token);
                    if (_titleOptionsPopup != null)
                        _titleOptionsPopup.OnClosed += ResumeTitleBgmAfterOptions;
                }
                break;
            case ETitleMenuAction.Credits:
                await OpenTitleCreditsAsync();
                break;
            case ETitleMenuAction.Collection:
                if (AudioManager.HasInstance)
                    AudioManager.Instance.StopBgm(fadeOut: 0f);
                if (UIManager.HasInstance)
                {
                    UICardPileViewer.ShowCollection();
                    _titleCollectionPopup = await UIManager.Instance.OpenAsync<UICardPileViewer>(_cts.Token);
                    if (_titleCollectionPopup != null)
                        _titleCollectionPopup.OnClosed += ResumeTitleBgmAfterCollection;
                }
                break;
            case ETitleMenuAction.Quit:
                if (GameManager.HasInstance)
                    GameManager.Instance.RequestQuit();
                break;
            case ETitleMenuAction.Tutorial:
                await SceneFlowManager.Instance.LoadSceneWithScreenAsync(_tutorialSceneName);
                break;
        }
    }

    private void BindCardMenu()
    {
        UnbindCardMenu();
        _cardMenu = _titleUI != null ? _titleUI.CardMenu : null;
        bool initialized = _cardMenu != null && _cardMenu.Initialize();
        if (_cardMenu != null)
            _cardMenu.OnMenuActionSelected += HandleMenuActionSelected;
        _titleUI?.SetCardMenuActive(initialized);
    }

    private void ResumeTitleBgmAfterOptions()
    {
        if (_titleOptionsPopup != null)
            _titleOptionsPopup.OnClosed -= ResumeTitleBgmAfterOptions;
        _titleOptionsPopup = null;

        _cardMenu?.ResetInteractionState();

        if (_isExiting || !AudioManager.HasInstance)
            return;

        AudioManager.Instance.PlayBgmAsync(_titleBgmKey, crossfade: 0f).Forget();
    }

    private async UniTask OpenTitleCreditsAsync()
    {
        if (_isExiting || _isCreditOpening || _isCreditClosing || _titleCreditPopup != null)
            return;

        _isCreditOpening = true;
        _creditClosePending = false;

        // 크레딧 전용 BGM 으로 교체. 옵션·컬렉션과 달리 화면이 길게 재생되므로 무음으로 두지 않고,
        // 타이틀 BGM 위로 화면 페이드와 같은 길이만큼 크로스페이드해 들어간다.
        // 복귀는 ResumeTitleBgm 이 담당한다.
        if (AudioManager.HasInstance)
            AudioManager.Instance.PlayBgmAsync(
                AudioKeys.Bgm.CREDIT,
                crossfade: _creditFadeDuration).Forget();

        try
        {
            await RunCreditFadeAsync(PrepareTitleCreditsAsync, _cts.Token);
        }
        catch (OperationCanceledException)
        {
            CleanupTitleCreditPresentation();
        }
        catch (Exception e)
        {
            Debug.LogError($"[TitleController] 타이틀 크레딧 진입 실패: {e}");
            CleanupTitleCreditPresentation();
            if (!_isExiting)
            {
                await RestoreTitleUiAsync(CancellationToken.None);
                ResumeTitleBgm();
            }
        }
        finally
        {
            _isCreditOpening = false;
        }

        if (_creditClosePending)
        {
            _creditClosePending = false;
            if (_isExiting || _cts == null || _cts.IsCancellationRequested)
                CleanupTitleCreditPresentation();
            else
                CloseTitleCreditsPresentationAsync(_cts.Token).Forget();
        }
    }

    private async UniTask PrepareTitleCreditsAsync(CancellationToken token)
    {
        if (!UIManager.HasInstance)
        {
            ResumeTitleBgm();
            return;
        }

        Camera camera = CameraManager.HasInstance
            ? CameraManager.Instance.MainCamera
            : Camera.main;
        bool presentationReady = _titleCreditWalkSequence != null &&
                                 _titleCreditWalkSequence.Prepare(camera);

        if (presentationReady && _titleUI != null && _titleUI.IsOpen)
        {
            UIManager.Instance.Close(_titleUI);
            _titleHiddenForCredits = true;
        }

        _titleCreditPopup = await UIManager.Instance.OpenAsync<UICreditScroll>(token);
        if (_titleCreditPopup == null)
        {
            CleanupTitleCreditPresentation();
            await RestoreTitleUiAsync(token);
            ResumeTitleBgm();
            return;
        }

        _titleCreditPopup.SetBackdropVisible(!presentationReady);
        _titleCreditPopup.OnClosed -= HandleTitleCreditsClosed;
        _titleCreditPopup.OnClosed += HandleTitleCreditsClosed;

        if (presentationReady)
            _titleCreditWalkSequence.Play();
    }

    private void HandleTitleCreditsClosed()
    {
        if (_titleCreditPopup != null)
            _titleCreditPopup.OnClosed -= HandleTitleCreditsClosed;
        _titleCreditPopup = null;

        if (_isExiting || _cts == null || _cts.IsCancellationRequested)
        {
            CleanupTitleCreditPresentation();
            return;
        }

        if (_isCreditOpening)
        {
            _creditClosePending = true;
            return;
        }

        CloseTitleCreditsPresentationAsync(_cts.Token).Forget();
    }

    private async UniTaskVoid CloseTitleCreditsPresentationAsync(CancellationToken token)
    {
        if (_isCreditClosing)
            return;

        _isCreditClosing = true;
        try
        {
            await RunCreditFadeAsync(async fadeToken =>
            {
                CleanupTitleCreditPresentation();
                await RestoreTitleUiAsync(fadeToken);
                ResumeTitleBgm();
            }, token);
        }
        catch (OperationCanceledException)
        {
            CleanupTitleCreditPresentation();
        }
        catch (Exception e)
        {
            Debug.LogError($"[TitleController] 타이틀 크레딧 종료 실패: {e}");
            CleanupTitleCreditPresentation();
            if (!_isExiting)
            {
                await RestoreTitleUiAsync(CancellationToken.None);
                ResumeTitleBgm();
            }
        }
        finally
        {
            _isCreditClosing = false;
            _cardMenu?.ResetInteractionState();
        }
    }

    private async UniTask RunCreditFadeAsync(
        Func<CancellationToken, UniTask> transition,
        CancellationToken token)
    {
        if (SceneFlowManager.HasInstance && !SceneFlowManager.Instance.IsTransitioning)
        {
            await SceneFlowManager.Instance.RunWithFadeAsync(
                transition,
                token,
                _creditFadeDuration,
                fadeColor: Color.black);
            return;
        }

        await transition(token);
    }

    private async UniTask RestoreTitleUiAsync(CancellationToken token)
    {
        if (!_titleHiddenForCredits || _isExiting || !UIManager.HasInstance)
            return;

        UITitle restoredTitle = await UIManager.Instance.OpenAsync<UITitle>(_titleUIKey, token);
        if (restoredTitle == null)
            return;

        _titleUI = restoredTitle;
        _titleHiddenForCredits = false;
        _titleUI.OnOpened -= HandleTitleOpened;
        _titleUI.OnOpened += HandleTitleOpened;
        // UITitle 비활성화 시 TitleCardMenu.OnDisable이 초기화 상태를 해제하므로,
        // 캐시된 같은 인스턴스여도 슬롯과 카드를 다시 구성해야 드래그 배치가 동작한다.
        BindCardMenu();
    }

    private void CleanupTitleCreditPresentation()
    {
        _titleCreditWalkSequence?.StopAndHide();
    }

    private void ResumeTitleBgm()
    {
        if (_isExiting || !AudioManager.HasInstance)
            return;

        // 옵션·컬렉션은 무음에서 복귀하지만, 크레딧은 전용 BGM 이 흐르고 있어 곡끼리 맞바꾸게 된다.
        // 끊김이 도드라지지 않도록 크레딧 화면 페이드와 같은 길이로 크로스페이드한다.
        AudioManager.Instance.PlayBgmAsync(
            _titleBgmKey,
            crossfade: _creditFadeDuration).Forget();
    }

    private void ResumeTitleBgmAfterCollection()
    {
        if (_titleCollectionPopup != null)
            _titleCollectionPopup.OnClosed -= ResumeTitleBgmAfterCollection;
        _titleCollectionPopup = null;

        _cardMenu?.ResetInteractionState();

        if (_isExiting || !AudioManager.HasInstance)
            return;

        AudioManager.Instance.PlayBgmAsync(_titleBgmKey, crossfade: 0f).Forget();
    }

    private void UnbindCardMenu()
    {
        if (_cardMenu != null)
            _cardMenu.OnMenuActionSelected -= HandleMenuActionSelected;
        _cardMenu = null;
    }

    private static string Localize(string key)
        => !string.IsNullOrEmpty(key) && LocalizationManager.HasInstance && LocalizationManager.Instance.HasKey(key)
            ? LocalizationManager.Instance.Get(key)
            : key ?? string.Empty;

    private async UniTask StartGameAsync()
    {
        if (RunSaveSystem.HasSave)
        {
            if (!UIManager.HasInstance)
            {
                _cardMenu?.ResetInteractionState();
                return;
            }

            UISystemConfirm popup = await UIManager.Instance.OpenAsync<UISystemConfirm>(_cts.Token);
            if (popup == null)
            {
                _cardMenu?.ResetInteractionState();
                return;
            }

            ESystemConfirmResult result;
            try
            {
                result = await popup.ShowAsync(
                    Localize(LocalizationKeys.Run.NewGameConfirmTitle),
                    Localize(LocalizationKeys.Run.NewGameConfirmDesc),
                    Localize(LocalizationKeys.Common.Confirm),
                    Localize(LocalizationKeys.Common.Cancel),
                    _cts.Token);
            }
            catch (OperationCanceledException)
            {
                return;
            }

            if (result != ESystemConfirmResult.Confirm)
            {
                _cardMenu?.ResetInteractionState();
                return;
            }

        }

        if (_titleUI == null)
        {
            _cardMenu?.ResetInteractionState();
            return;
        }

        ERunDifficulty? selectedDifficulty;
        try
        {
            selectedDifficulty = await _titleUI.ShowDifficultySelectAsync(_cts.Token);
        }
        catch (OperationCanceledException)
        {
            return;
        }

        if (!selectedDifficulty.HasValue)
        {
            _cardMenu?.ResetInteractionState();
            return;
        }

        if (RunSaveSystem.HasSave)
            RunSaveSystem.Clear();
        RunLaunchOptions.RequestNewRun(selectedDifficulty.Value);

        await EnterGameAsync();
    }

    private async UniTask ContinueGameAsync()
    {
        if (!RunSaveSystem.HasSave)
        {
            _cardMenu?.ResetInteractionState();
            return;
        }

        RunLaunchOptions.RequestContinueSavedRun();
        await EnterGameAsync();
    }

    /// <summary>
    /// 최초 실행 전용 튜토리얼 자동 진입. 타이틀 UI를 열지 않고 곧바로 씬 전환한다.
    /// 진입에 성공하면 true, 진입 조건이 안 되면(씬 이름 미지정 등) false 를 반환해
    /// 호출부가 일반 타이틀 흐름으로 폴백하게 한다.
    /// </summary>
    private async UniTask<bool> TryEnterFirstLaunchTutorialAsync()
    {
        if (string.IsNullOrEmpty(_tutorialSceneName) || !SceneFlowManager.HasInstance)
            return false;

        // 타이틀 UI가 뒤늦게 열리지 않도록 OnSceneEnter 진입을 미리 봉인
        _sceneEntered = true;
        _enteredViaTransition = true;

        // 첫 씬은 OnSceneLoadComplete 가 발행되지 않아 Screen Canvas 에 카메라가 붙지 않는다.
        // 페이드·로딩 화면이 렌더되지 않는 문제를 막기 위해 전환 전에 직접 갱신한다.
        if (CameraManager.HasInstance)
            CameraManager.Instance.RefreshMainCamera();
        if (UIManager.HasInstance)
            UIManager.Instance.SetUIRootCamera();

        // 실제 최초 진입 기록은 튜토리얼 시작 패널의 버튼을 누른 시점에 남긴다.
        RunLaunchOptions.RequestFirstLaunchTutorial();

        await SceneFlowManager.Instance.LoadSceneWithScreenAsync(_tutorialSceneName);
        return true;
    }

    private async UniTask EnterGameAsync()
    {
        UserManager.Instance.CreateNewUser(_saveSlot);

        // 씬 전환 (페이드 → OnSceneExit → 로드 → 새 씬 OnSceneEnter → 페이드인 → Ready)
        await SceneFlowManager.Instance.LoadSceneWithScreenAsync(_gameSceneName);
    }

    private void OnDestroy()
    {
        if (UIManager.HasInstance)
            UIManager.Instance.OnEscapeUnhandled -= HandleEscapeUnhandled;
        UnbindCardMenu();
        if (_titleUI != null)
            _titleUI.OnOpened -= HandleTitleOpened;
        if (_titleOptionsPopup != null)
            _titleOptionsPopup.OnClosed -= ResumeTitleBgmAfterOptions;
        if (_titleCreditPopup != null)
            _titleCreditPopup.OnClosed -= HandleTitleCreditsClosed;
        if (_titleCollectionPopup != null)
            _titleCollectionPopup.OnClosed -= ResumeTitleBgmAfterCollection;
        CleanupTitleCreditPresentation();
        _cts?.Cancel();
        _cts?.Dispose();

        if (SceneFlowManager.HasInstance)
            SceneFlowManager.Instance.UnregisterLifecycle(this);
    }
}
