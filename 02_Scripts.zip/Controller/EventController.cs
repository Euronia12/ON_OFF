// =================================================================
// [스크립트 목적]  Event 노드 후보 선택, Addressable UI 실행, 완료 후 맵 복귀를 담당한다.
// [의존 관계]      - EventManager / DataManager / UIManager / RunContext
// =================================================================

using System;
using System.Collections.Generic;
using System.Threading;
using Cysharp.Threading.Tasks;
using UnityEngine;

public sealed class EventController : SceneSingleton<EventController>
{
    private IDisposableEvent _eventSubscription;
    private CancellationTokenSource _eventCts;
    private UIBase _activeView;
    private bool _eventInProgress;
    private UniTaskCompletionSource<bool> _viewReadySource;

    protected override void OnAwakeInternal()
    {
        if (EventManager.HasInstance)
            _eventSubscription = EventManager.Instance.Subscribe<OnMapNodeEntered>(HandleNodeEntered);
    }

    protected override void OnDestroy()
    {
        _eventSubscription?.Dispose();
        _eventSubscription = null;
        _viewReadySource?.TrySetResult(false);
        _viewReadySource = null;
        CancelActiveEvent();
        base.OnDestroy();
    }

    private void HandleNodeEntered(OnMapNodeEntered evt)
    {
        if (evt.NodeType != ENodeType.Event) return;
        if (_eventInProgress)
        {
            Debug.LogWarning("[EventController] Event 처리 중 중복 진입 요청을 무시합니다.");
            return;
        }

        _viewReadySource = new UniTaskCompletionSource<bool>();
        PlayEventAsync(evt.NodeId).Forget();
    }

    /// <summary>현재 Event 노드의 UI가 실제 Open을 마칠 때까지 기다린다.</summary>
    public async UniTask<bool> WaitUntilViewReadyAsync(CancellationToken token)
    {
        UniTaskCompletionSource<bool> source = _viewReadySource;
        if (source == null) return false;
        return await source.Task.AttachExternalCancellation(token);
    }

    private async UniTaskVoid PlayEventAsync(int nodeId)
    {
        _eventInProgress = true;
        _eventCts = new CancellationTokenSource();
        CancellationToken token = _eventCts.Token;

        bool completed = false;
        // 뷰가 실제로 열려 PlayAsync 까지 들어갔는가. 실패 복구 방식을 가른다:
        //   false = 이벤트를 아예 열지 못함 → 노드를 건너뛴다(재진입해도 또 실패한다)
        //   true  = 진행 중 취소·예외    → 노드를 미해결로 두고 체크포인트에서 재개시킨다
        bool viewStarted = false;
        try
        {
            RunContext run = CurrentRun;
            EventDataSO data = PickEvent(run, nodeId);
            if (data == null)
            {
                Debug.LogWarning("[EventController] 등장 가능한 Event가 없어 노드를 건너뜁니다.");
                return;
            }

            // 후보 목록은 encountered 상태에 따라 달라지므로 선택 결과를 먼저 고정 저장한다.
            // 이어하기에서는 같은 노드의 pending EventId 를 직접 사용해 재추첨하지 않는다.
            run.BeginPendingEvent(nodeId, data.EventId);
            run.MarkEventEncountered(data.EventId);
            if (InGameController.HasInstance)
                InGameController.Instance.SaveRunProgressFromExternalSystem(currentNodeResolved: false);

            if (!UIManager.HasInstance)
            {
                Debug.LogError("[EventController] UIManager가 없어 Event를 열 수 없습니다.");
                return;
            }

            IEventView eventView = await OpenViewWithFadeAsync(data, token);
            _viewReadySource?.TrySetResult(eventView != null);
            if (eventView == null) return;

            var context = new EventContext(run, nodeId, InGameController.Instance,
                GridManager.HasInstance ? GridManager.Instance : null,
                data.EventId, data.UseSeededRandom);
            viewStarted = true;
            await eventView.PlayAsync(context, token);
            completed = true;
        }
        catch (OperationCanceledException)
        {
        }
        catch (Exception e)
        {
            Debug.LogException(e);
        }
        finally
        {
            _viewReadySource?.TrySetResult(false);
            if (completed)
                await ResolveAndReturnAsync();
            else
                await AbortAndReturnAsync(nodeId, viewStarted);
            _eventCts?.Dispose();
            _eventCts = null;
            _eventInProgress = false;
            _viewReadySource = null;
        }
    }

    /// <summary>
    /// 이벤트가 정상 종료되지 못했을 때의 복구. 진입 시 맵이 이미 닫혀 있으므로
    /// 여기서 맵을 되살리지 않으면 빈 화면에 갇혀 런을 이어갈 수 없다.
    /// 런 종료(EndRun)로 인한 취소는 InGameController 쪽 IsRunActive 가드가 모두 무동작 처리한다.
    /// </summary>
    /// <param name="viewStarted">뷰가 실제로 열려 진행 중이었는지. 노드 해결 여부를 가른다.</param>
    private async UniTask AbortAndReturnAsync(int nodeId, bool viewStarted)
    {
        CloseActiveView();

        if (!InGameController.HasInstance || !InGameController.Instance.IsRunActive)
            return;

        if (viewStarted)
        {
            // 효과 적용 중 취소·예외. 체크포인트가 파일에 남아 있으므로 노드를 미해결로 두고
            // 맵만 복구한다 — 다시 진입하면 저장된 지점부터 재개된다.
            Debug.LogWarning($"[EventController] Event가 정상 종료되지 않아 맵으로 복구합니다: node={nodeId}");
            await InGameController.Instance.ReturnToMapWithoutResolvingAsync();
            return;
        }

        // 이벤트를 열지도 못한 경우. 재진입해도 같은 이유로 실패하므로 노드를 해결 처리해 건너뛴다.
        Debug.LogWarning($"[EventController] Event를 열지 못해 노드를 건너뜁니다: node={nodeId}");
        CurrentRun?.ClearPendingEvent(nodeId);
        await InGameController.Instance.NotifyNodeResolvedWithFadeAsync();
    }

    private async UniTask<IEventView> OpenViewWithFadeAsync(EventDataSO data, CancellationToken token)
    {
        if (!SceneFlowManager.HasInstance || SceneFlowManager.Instance.IsTransitioning)
            return await OpenViewAsync(data, token);

        IEventView eventView = null;
        await SceneFlowManager.Instance.RunWithFadeAsync(async fadeToken =>
        {
            eventView = await OpenViewAsync(data, fadeToken);
        }, token);
        return eventView;
    }

    private async UniTask ResolveAndReturnAsync()
    {
        void CloseActiveEvent()
        {
            CloseActiveView();
        }

        if (InGameController.HasInstance)
        {
            CurrentRun?.ClearPendingEvent();
            await InGameController.Instance.NotifyNodeResolvedWithFadeAsync(
                CloseActiveEvent,
                skipNextShopEntryFade: true);
            return;
        }

        CloseActiveEvent();
    }

    // 유형별 뷰 오픈. Choice=단일 UIChoiceEvent(캐시)+SO 데이터, 그 외=기존 PrefabKey 프리팹.
    // BGM 전환도 여기서 건다 — 이 함수는 화면이 가려진 페이드 구간 안에서 호출되므로
    // 곡 교체가 암전 중에 묻힌다 (Shop/Rest 의 Open*Async 와 같은 구조).
    private async UniTask<IEventView> OpenViewAsync(EventDataSO data, CancellationToken token)
    {
        // 이벤트 BGM (맵 BGM 위로 크로스페이드). 나갈 때 ResolveAndReturnAsync 에서 맵으로 복귀.
        if (AudioManager.HasInstance)
            AudioManager.Instance.PlayBgmAsync(AudioKeys.Bgm.EVENT, crossfade: 1f).Forget();

        if (data.Type == EEventType.Choice)
        {
            // 이미지는 조우 시점에만 키로 로드(초상화 방식). 없으면 null → 뷰에서 숨김.
            Sprite image = null;
            if (!string.IsNullOrWhiteSpace(data.ImageKey) && ResourceManager.HasInstance)
                image = await ResourceManager.Instance.LoadSpriteAsync(data.ImageKey, token);

            UIChoiceEvent.Show(data.ToViewData(image));
            UIChoiceEvent view = await UIManager.Instance.OpenAsync<UIChoiceEvent>(token);
            _activeView = view;
            return view;
        }

        _activeView = await UIManager.Instance.OpenTransientAsync(data.PrefabKey, token);
        if (_activeView == null) return null;
        if (_activeView is not IEventView eventView)
        {
            Debug.LogError($"[EventController] Event 프리팹에 IEventView가 없습니다: {data.PrefabKey}");
            return null;
        }
        return eventView;
    }

    private EventDataSO PickEvent(RunContext run, int nodeId)
    {
        if (run == null || !DataManager.HasInstance || !DataManager.Instance.IsLoaded) return null;

        if (run.TryGetPendingEvent(nodeId, out string pendingEventId))
        {
            EventDataSO pending = FindEventById(pendingEventId);
            if (IsPlayable(pending)) return pending;

            Debug.LogWarning($"[EventController] 저장된 pending 이벤트를 찾지 못해 재추첨합니다: {pendingEventId}");
            run.ClearPendingEvent(nodeId);
        }

        if (DebugCommandManager.TryGetForcedEvent(out EventDataSO forced) && IsPlayable(forced))
        {
            DebugCommandManager.ConsumeForcedEvent(forced);
            return forced;
        }

        int stageIndex = InGameController.HasInstance
            ? InGameController.Instance.CurrentStageNumber - 1
            : 0;
        if (run.TryGetAssignedEvent(nodeId, out string assignedEventId))
        {
            EventDataSO assigned = FindEventById(assignedEventId);
            if (IsPlayable(assigned)) return assigned;

            Debug.LogError($"[EventController] 맵에 배정된 이벤트를 찾을 수 없습니다: " +
                           $"stage={stageIndex}, node={nodeId}, event={assignedEventId}");
            return null;
        }

        // 데이터 로드 순서 때문에 생성 직후 배정되지 못한 경우에도 한 노드만 즉석 추첨하지 않는다.
        // 현재 맵 전체를 정렬된 순서로 배정해야 진입 경로가 결과에 영향을 주지 않는다.
        AssignMapEvents(run, run.Map, stageIndex);
        if (run.TryGetAssignedEvent(nodeId, out assignedEventId))
            return FindEventById(assignedEventId);

        Debug.LogError($"[EventController] 이벤트 노드에 사전 배정값이 없습니다: " +
                       $"stage={stageIndex}, node={nodeId}");
        return null;
    }

    /// <summary>
    /// 맵 생성 직후 모든 Event 노드의 콘텐츠를 확정해 예약한다.
    /// 실제 풀 소모는 해당 노드 진입 시 MarkEventEncountered 로 처리한다.
    /// 진입 순서나 선택 경로가 달라도 같은 시드·스테이지·노드는 같은 이벤트를 유지한다.
    /// </summary>
    public static void AssignMapEvents(RunContext run, MapGraph map, int stageIndex)
    {
        if (run == null || map == null || stageIndex < 0 ||
            !DataManager.HasInstance || !DataManager.Instance.IsLoaded)
            return;

        var eventNodes = new List<MapNode>();
        foreach (MapNode node in map.Nodes)
        {
            if (node != null && node.NodeType == ENodeType.Event)
                eventNodes.Add(node);
        }
        eventNodes.Sort((a, b) => a.Id.CompareTo(b.Id));

        List<EventDataSO> all = DataManager.Instance.GetAllData<EventDataSO>();
        all.Sort((a, b) => string.CompareOrdinal(a?.EventId, b?.EventId));
        var candidates = new List<EventDataSO>();
        var candidateIds = new HashSet<string>(StringComparer.Ordinal);
        var reservedEventIds = new HashSet<string>(StringComparer.Ordinal);
        int stageNumber = stageIndex + 1;

        for (int i = 0; i < eventNodes.Count; i++)
        {
            if (run.TryGetAssignedEvent(eventNodes[i].Id, out string assignedEventId))
                reservedEventIds.Add(assignedEventId);
        }

        // 조건이 충족된 후속 이벤트를 일반 추첨보다 먼저 선점 배정한다.
        AssignPrerequisiteEvents(all, run, stageNumber, eventNodes, reservedEventIds);

        for (int i = 0; i < eventNodes.Count; i++)
        {
            MapNode node = eventNodes[i];
            if (run.TryGetAssignedEvent(node.Id, out _)) continue;

            BuildCandidates(all, run, stageNumber, candidates, candidateIds, reservedEventIds);

            var rng = new System.Random(CombineSeed(run.Seed, stageIndex, node.Id));
            EventDataSO selected = PickWeighted(candidates, rng);
            if (selected == null)
            {
                node.NodeType = ENodeType.Battle;
                Debug.LogWarning($"[EventController] 중복 없이 배정 가능한 이벤트가 없어 Battle로 전환합니다: " +
                                 $"stage={stageNumber}, node={node.Id}");
                continue;
            }

            if (run.AssignEvent(node.Id, selected.EventId))
                reservedEventIds.Add(selected.EventId);
        }
    }

    /// <summary>
    /// 실제 선택 기록으로 선행 조건이 충족된 후속 이벤트를 빈 Event 노드에 우선 배정한다.
    /// 현재 맵에 자리가 없으면 조건 기록이 유지되므로 다음 스테이지에서 다시 배정한다.
    /// </summary>
    private static void AssignPrerequisiteEvents(
        List<EventDataSO> all,
        RunContext run,
        int stageNumber,
        List<MapNode> eventNodes,
        HashSet<string> reservedEventIds)
    {
        if (eventNodes.Count == 0) return;

        List<EventDataSO> pending = null;
        for (int i = 0; i < all.Count; i++)
        {
            EventDataSO data = all[i];
            if (data == null || !data.Enabled || string.IsNullOrWhiteSpace(data.EventId)) continue;
            if (!data.HasPrerequisite || !IsPlayable(data) || data.Weight <= 0f) continue;
            if (!data.IsStageAllowed(stageNumber)) continue;
            if (run.HasEncounteredEvent(data.EventId)) continue;
            if (reservedEventIds.Contains(data.EventId)) continue;
            if (!data.IsPrerequisiteMet(run)) continue;

            pending ??= new List<EventDataSO>();
            pending.Add(data);
        }

        if (pending == null) return;

        pending.Sort((a, b) =>
        {
            int byWeight = b.Weight.CompareTo(a.Weight);
            return byWeight != 0 ? byWeight : string.CompareOrdinal(a.EventId, b.EventId);
        });

        int nodeIndex = 0;
        for (int i = 0; i < pending.Count; i++)
        {
            while (nodeIndex < eventNodes.Count &&
                   run.TryGetAssignedEvent(eventNodes[nodeIndex].Id, out _))
                nodeIndex++;

            if (nodeIndex >= eventNodes.Count) break;

            EventDataSO data = pending[i];
            if (run.AssignEvent(eventNodes[nodeIndex].Id, data.EventId))
                reservedEventIds.Add(data.EventId);
            nodeIndex++;
        }
    }

    private static EventDataSO FindEventById(string eventId)
    {
        if (string.IsNullOrWhiteSpace(eventId) || !DataManager.HasInstance) return null;

        List<EventDataSO> all = DataManager.Instance.GetAllData<EventDataSO>();
        for (int i = 0; i < all.Count; i++)
        {
            EventDataSO data = all[i];
            if (data != null && string.Equals(data.EventId, eventId, StringComparison.Ordinal))
                return data;
        }
        return null;
    }

    // 후보 목록 구성. 실제 조우했거나 현재 맵에 예약된 이벤트는 제외한다.
    private static void BuildCandidates(
        List<EventDataSO> all,
        RunContext run,
        int stage,
        List<EventDataSO> candidates,
        HashSet<string> candidateIds,
        HashSet<string> reservedEventIds)
    {
        candidates.Clear();
        candidateIds.Clear();

        for (int i = 0; i < all.Count; i++)
        {
            EventDataSO data = all[i];
            if (data == null || !data.Enabled || string.IsNullOrWhiteSpace(data.EventId) || !IsPlayable(data))
                continue;
            if (run.HasEncounteredEvent(data.EventId)) continue;
            if (reservedEventIds.Contains(data.EventId)) continue;

            // 스테이지 등장 조건 · 가중치 0 이하 제외.
            if (stage > 0 && !data.IsStageAllowed(stage)) continue;
            if (data.Weight <= 0f) continue;

            if (data.HasPrerequisite && !data.IsPrerequisiteMet(run)) continue;

            if (!candidateIds.Add(data.EventId))
            {
                Debug.LogWarning($"[EventController] 중복 EventId를 제외합니다: {data.EventId}");
                continue;
            }

            candidates.Add(data);
        }
    }

    // 유형별 실행 가능 여부. GridPuzzle=PrefabKey 필요, Choice=선택지 필요.
    private static bool IsPlayable(EventDataSO data)
        => data.Type == EEventType.GridPuzzle
            ? !string.IsNullOrWhiteSpace(data.PrefabKey)
            : data.Choices.Count > 0;

    // 후보 목록에서 Weight 기반 가중치 추첨. GC 없는 누적합 방식.
    private static EventDataSO PickWeighted(List<EventDataSO> candidates, System.Random rng)
    {
        if (candidates.Count == 0) return null;

        double total = 0d;
        for (int i = 0; i < candidates.Count; i++)
            total += candidates[i].Weight;

        if (total <= 0d) return candidates[rng.Next(candidates.Count)];

        double roll = rng.NextDouble() * total;
        double cumulative = 0d;
        for (int i = 0; i < candidates.Count; i++)
        {
            cumulative += candidates[i].Weight;
            if (roll < cumulative) return candidates[i];
        }
        return candidates[candidates.Count - 1]; // 부동소수 오차 보정
    }

    private static int CombineSeed(int seed, int stageIndex, int nodeId)
    {
        unchecked
        {
            int h = 17;
            h = h * 31 + seed;
            h = h * 31 + stageIndex;
            h = h * 31 + nodeId;
            return h;
        }
    }

    public void CancelActiveEvent()
    {
        _eventCts?.Cancel();
        CloseActiveView();
    }

    private void CloseActiveView()
    {
        UIBase view = _activeView;
        _activeView = null;
        if (view != null && UIManager.HasInstance)
            UIManager.Instance.Close(view);
    }

    private RunContext CurrentRun =>
        InGameController.HasInstance ? InGameController.Instance.CurrentRun : null;
}
