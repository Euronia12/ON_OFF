// =================================================================
// [스크립트 목적]  메인(아웃게임) 씬 컨트롤러. 씬 생명주기를 소유하고 인프라(HUD·풀·입력·BGM)를
//                 준비한 뒤, "한 판(run)" 을 InGameController 로 띄운다.
// [주요 변수]      - _titleSceneName : 종료 시 복귀 씬
//                  - _hudKey         : 인게임 HUD Addressable 키
//                                      (BGM 키는 AudioKeys.Bgm.* 중앙 레지스트리 사용)
//                  - _prewarmPools   : 진입 시 풀 프리웜 여부
// [의존 관계]      - SceneFlowManager(ISceneLifecycle) / GameFlowManager / UIManager
//                  - PoolManager / DataManager / InputManager / AudioManager (인프라)
//                  - InGameController (런 시작 위임)
// [배치]           메인(인게임) 씬에 빈 GameObject 만들고 부착
// [역할 구분]      MainController = 씬·인프라·메타 진행 / InGameController = 런 흐름
//                  / BattleController = 전투 조립 / BattleManager = 전투 규칙
// [설계 노트]      - 같은 씬 전제: ISceneLifecycle 은 MainController 만 보유. 나머지는 호출받아 동작
//                  - [horizon] 캐릭터 선택·맵·메타 진행은 확장 지점. 현재는 즉시 런 시작
// =================================================================

using Cysharp.Threading.Tasks;
using System.Threading;
using UnityEngine;

/// <summary>
/// 메인 씬의 진행·인프라를 총괄하는 씬 싱글턴. 씬 생명주기(ISceneLifecycle)를 단독 소유하며,
/// 진입 시 HUD·풀·입력맵·BGM 을 준비하고 InGameController 로 한 판을 시작시킨다.
/// 같은 씬 안에서 메타(아웃게임) → 런 → 전투 계층의 최상단 역할을 한다.
/// </summary>
public sealed class MainController : SceneSingleton<MainController>, ISceneLifecycle
{
    [Header("씬 전환")]
    [Tooltip("게임 종료 시 돌아갈 씬 (보통 Title)")]
    [SerializeField] private string _titleSceneName = "Title";

    [Header("인게임 UI")]
    [Tooltip("HUD UI 키 (비우면 클래스명 사용)")]
    [SerializeField] private string _hudKey = "UIHud";

    [Header("리소스")]
    [Tooltip("진입 시 풀 프리웜 실행")]
    [SerializeField] private bool _prewarmPools = true;

    [Header("런 시작")]
    [Tooltip("진입 후 자동으로 런을 시작할지 여부. 캐릭터 선택 UI 도입 전까지 true 권장")]
    [SerializeField] private bool _autoStartRun = true;

    [Tooltip("런 시작 전 덱 선택 UI 키")]
    [SerializeField] private string _deckSelectKey = "UIWindowDeckSelect";

    [Tooltip("미리 지정할 캐릭터. 비우면(null) 캐릭터 선택 화면을 열고, " +
             "지정하면 선택 화면 없이 그 캐릭터로 자동 런 시작 (테스트·디버그 편의용)")]
    [SerializeField] private CharacterSO _presetCharacter;

    private CancellationTokenSource _cts;
    private bool _enteredViaTransition;
    // OnSceneEnter 중복 실행 방지 (Start ↔ SceneFlowManager 경쟁 가드).
    private bool _sceneEntered;
    private bool _savedRunRestoredDuringSceneEnter;
    private bool _savedRunFallbackPending;

    protected override void Awake()
    {
        base.Awake(); // SceneSingleton — Instance 등록

        _cts = new CancellationTokenSource();
        if (SceneFlowManager.HasInstance)
            SceneFlowManager.Instance.RegisterLifecycle(this);
    }

    private void Start()
    {
        // 씬 전환으로 진입한 게 아니라 직접 Play 한 경우만 자체 초기화.
        if (!_enteredViaTransition)
            DirectStartAsync().Forget();
    }

    private async UniTaskVoid DirectStartAsync()
    {
        await BootstrapInitializer.WaitForReadyAsync();

        // 정상 씬 전환 쪽 OnSceneEnter가 이미 시작됐거나 완료됐다면 그 흐름이 끝까지 소유한다.
        // 여기서 같은 작업을 병렬로 시작하면 바깥 전환이 중복 가드만 통과한 뒤 먼저 페이드 인할 수 있다.
        if (_sceneEntered) return;

        // 에디터에서 Main/Tutorial 씬을 직접 Play해도 정상 진입과 같은
        // Fade out → OnSceneEnter 준비 → Fade in 순서를 보장한다.
        if (SceneFlowManager.HasInstance)
        {
            // 정상 씬 로드 전환이 진행 중이면 해당 전환이 OnSceneEnter/OnSceneReady를 호출한다.
            if (SceneFlowManager.Instance.IsTransitioning) return;

            await SceneFlowManager.Instance.RunWithFadeAsync(
                fadeToken => OnSceneEnter(fadeToken),
                _cts.Token);
            OnSceneReady();
            return;
        }

        // SceneFlowManager가 없는 테스트 경로도 preload 동안 완전 차폐를 보장한다.
        CanvasGroup directFade = null;
        if (UIManager.HasInstance &&
            UIManager.Instance.FadeGroup != null)
        {
            directFade = UIManager.Instance.FadeGroup;
            directFade.alpha = 1f;
            directFade.blocksRaycasts = true;
        }

        try
        {
            await OnSceneEnter(_cts.Token);
        }
        finally
        {
            if (directFade != null)
            {
                directFade.alpha = 0f;
                directFade.blocksRaycasts = false;
            }
        }
        OnSceneReady();
    }

    // ─────────────────────────────────────────────
    // ISceneLifecycle
    // ─────────────────────────────────────────────

    public async UniTask OnSceneEnter(CancellationToken token)
    {
        // 중복 진입 차단 (Start ↔ SceneFlowManager 경쟁으로 두 번 불릴 수 있음).
        if (_sceneEntered) return;
        _sceneEntered = true;
        _enteredViaTransition = true;

        // 페이드 뒤(화면 가려진 상태)에서 무거운 준비 작업.
        GameFlowManager.Instance.SetState(EGameState.Loading);

        // 1. 데이터 확인 (보통 이미 로드됨).
        if (DataManager.HasInstance && !DataManager.Instance.IsLoaded)
            await DataManager.Instance.PreloadAllAsync(null, token);

        // 2. 풀 프리웜 (카드·적·이펙트 미리 생성).
        if (_prewarmPools && PoolManager.HasInstance)
            await PoolManager.Instance.PrewarmFromTableAsync(token: token);

        // 3. 기존 페이드가 완전히 화면을 덮은 뒤 아틀라스와 주요 UI 인스턴스를 준비한다.
        // 가림 상태를 보장할 수 없으면 UI 노출 위험이 있으므로 사전 로드를 건너뛴다.
        if (IsEntryFadeFullyCovered())
            await PreloadGamePresentationAsync(token);
        else
            GameLogger.LogWarning(ELogCategory.UI,
                "게임 진입 UI preload 생략: 페이드가 완전히 덮이지 않았습니다.");

        // 4. HUD 열기.
        //await UIManager.Instance.OpenAsync<UIHud>(token);

        // 5. 입력맵을 게임플레이로.
        if (InputManager.HasInstance)
            InputManager.Instance.SwitchMap(EActionMap.Gameplay);

        UIManager.Instance.SetUIRootCamera();

        // 처리되지 않은 ESC(팝업으로 소비되지 않은) → 런 메뉴 토글 라우팅.
        if (UIManager.HasInstance)
        {
            UIManager.Instance.OnEscapeUnhandled -= HandleEscapeUnhandled;
            UIManager.Instance.OnEscapeUnhandled += HandleEscapeUnhandled;
        }

        // 이어하기는 타이틀→Main 씬 전환 페이드가 화면을 덮고 있는 동안 복원한다.
        // 별도의 Stage Notice/페이드를 사용하지 않아 저장 지점이 준비되는 즉시 화면을 연다.
        if (_autoStartRun &&
            RunLaunchOptions.ContinueSavedRun &&
            InGameController.HasInstance &&
            RunSaveSystem.TryLoad(out RunSaveData saveData))
        {
            RunLaunchOptions.ConsumeContinueSavedRun();
            _savedRunRestoredDuringSceneEnter =
                await InGameController.Instance.BeginSavedRunAsync(
                    saveData,
                    token,
                    showStageNotice: false,
                    fallbackToNewRunWhenInvalid: false);
            _savedRunFallbackPending = !_savedRunRestoredDuringSceneEnter;
        }
    }

    private static bool IsEntryFadeFullyCovered()
    {
        if (SceneFlowManager.HasInstance)
            return SceneFlowManager.Instance.IsFadeFullyCovered;

        if (!UIManager.HasInstance || UIManager.Instance.FadeGroup == null)
            return false;

        CanvasGroup fade = UIManager.Instance.FadeGroup;
        return fade.alpha == 1f && fade.blocksRaycasts;
    }

    private static async UniTask PreloadGamePresentationAsync(CancellationToken token)
    {
        if (ResourceManager.HasInstance)
        {
            await UniTask.WhenAll(
                ResourceManager.Instance.LoadAtlasAsync(EAtlasType.CardIcon, token),
                ResourceManager.Instance.LoadAtlasAsync(EAtlasType.Common, token));
        }

        if (!UIManager.HasInstance) return;

        await UniTask.WhenAll(
            UIManager.Instance.PreloadAsync<UIMap>(token),
            UIManager.Instance.PreloadAsync<UIBattle>(token),
            UIManager.Instance.PreloadAsync<UIShopPopup>(token),
            UIManager.Instance.PreloadAsync<UIRestPopup>(token),
            UIManager.Instance.PreloadAsync<UIChoiceEvent>(token),
            UIManager.Instance.PreloadAsync<UIRewardPopup>(token),
            UIManager.Instance.PreloadAsync<UICardSelectPopup>(token));

        await UIManager.Instance.PreloadTransientAsync(nameof(UIGridPuzzleEvent), token);
    }

    public void OnSceneReady()
    {
        // 페이드 인 완료 후 — 화면 보이는 상태에서 진행.
        GameFlowManager.Instance.SetState(EGameState.InGame);

        // 덱·시작 카드팩 선택 BGM은 그 화면을 실제로 여는 OpenDeckSelectAsync 가 소유한다.
        // 여기서 틀면 선택 화면을 건너뛰는 경로(튜토리얼·프리셋 캐릭터·이어하기)에서도
        // 잠깐 흐르다 맵 BGM 으로 넘어가 "앞에 다른 곡이 끼었다"처럼 들린다.

        // 정상 이어하기는 OnSceneEnter에서 이미 복원됐다. 유효하지 않은 저장만 페이드가
        // 열린 뒤 안내하고 신규 런으로 전환해, 검은 화면 뒤에서 팝업 입력을 기다리지 않는다.
        if (_autoStartRun && _savedRunFallbackPending)
            StartInvalidSavedRunFallbackSafelyAsync(_cts != null ? _cts.Token : default).Forget();
        else if (_autoStartRun && !_savedRunRestoredDuringSceneEnter)
            StartRunOrOpenDeckSelectSafelyAsync(_cts != null ? _cts.Token : default).Forget();
    }

    public async UniTask OnSceneExit(CancellationToken token)
    {
        if (UIManager.HasInstance)
        {
            UIManager.Instance.OnEscapeUnhandled -= HandleEscapeUnhandled;
        }

        // 런 정리 (전투 부속 해제 포함).
        if (InGameController.HasInstance)
            InGameController.Instance.EndRun();

        // 풀 정리 (다음 씬에 안 가져감).
        if (PoolManager.HasInstance)
            PoolManager.Instance.ClearAll();

        // UI 닫기.
        if (UIManager.HasInstance)
            UIManager.Instance.CloseAll();

        // BGM 정지.
        if (AudioManager.HasInstance)
            AudioManager.Instance.StopBgm(fadeOut: 0.5f);

        await UniTask.CompletedTask;
    }

    // ─────────────────────────────────────────────
    // 런 시작/종료
    // ─────────────────────────────────────────────

    /// <summary>한 판(run) 시작. InGameController 에 위임. (캐릭터 선택 완료 후 호출 지점)</summary>
    public async UniTask StartRunAsync(CancellationToken token = default)
        => await StartRunAsync(EStartingDeck.None, token);

    public async UniTask StartRunAsync(EStartingDeck deckType, CancellationToken token = default)
    {
        if (!InGameController.HasInstance)
        {
            Debug.LogError("[MainController] InGameController 가 씬에 없습니다. 런 시작 불가.");
            return;
        }

        CancellationToken runToken = token.CanBeCanceled ? token : _cts.Token;
        if (deckType == EStartingDeck.None)
            await InGameController.Instance.BeginRunAsync(runToken);
        else
            await InGameController.Instance.BeginRunAsync(deckType, runToken);
    }

    private async UniTask StartRunOrOpenDeckSelectAsync(CancellationToken token)
    {
        if (!InGameController.HasInstance)
        {
            Debug.LogError("[MainController] InGameController 가 씬에 없습니다. 런 시작 불가.");
            return;
        }

        if (RunLaunchOptions.ConsumeContinueSavedRun())
        {
            if (RunSaveSystem.TryLoad(out RunSaveData saveData))
            {
                // 직접 Main 씬을 실행한 경우의 폴백 경로. 이어하기에서는 Act 진입 Notice를 생략한다.
                await InGameController.Instance.BeginSavedRunAsync(
                    saveData,
                    token,
                    showStageNotice: false);
                return;
            }

            Debug.LogWarning("[MainController] 이어하기 요청이 있었지만 저장 데이터를 불러오지 못해(손상/변조/부재) 새 런을 시작합니다.");
            // 손상·변조된 저장은 삭제해 다음 실행 때 이어하기 팝업이 반복 실패하지 않게 한다.
            RunSaveSystem.Clear();
            // 유저에게도 새 게임으로 전환됨을 안내(맵 불일치 안내와 동일 팝업 재사용).
            await InGameController.Instance.NotifySavedRunResetAsync(
                token,
                LocalizationKeys.Run.ResetCorruptDesc);
        }

        // 인스펙터에 캐릭터를 미리 지정했으면 선택 화면을 건너뛰고 그 캐릭터로 즉시 시작한다.
        if (_presetCharacter != null)
        {
            await StartRunWithPresetCharacterAsync(_presetCharacter, token);
            return;
        }

        if (InGameController.Instance.StartingDeck == EStartingDeck.None)
            await OpenDeckSelectAsync(token);
        else
            await StartRunAsync(token);
    }

    private async UniTaskVoid StartInvalidSavedRunFallbackSafelyAsync(CancellationToken token)
    {
        _savedRunFallbackPending = false;

        try
        {
            await InGameController.Instance.NotifySavedRunResetAsync(token);
            if (token.IsCancellationRequested) return;

            await InGameController.Instance.BeginRunAsync(
                InGameController.Instance.StartingDeck,
                token);
        }
        catch (System.OperationCanceledException)
        {
        }
        catch (System.Exception e)
        {
            Debug.LogError($"[MainController] 무효한 저장 데이터의 신규 런 전환 중 예외: {e}");
        }
    }

    private async UniTaskVoid StartRunOrOpenDeckSelectSafelyAsync(CancellationToken token)
    {
        try
        {
            await StartRunOrOpenDeckSelectAsync(token);
        }
        catch (System.OperationCanceledException)
        {
        }
        catch (System.Exception e)
        {
            Debug.LogError($"[MainController] 런 시작/이어하기 중 예외: {e}");

            if (InGameController.HasInstance)
                InGameController.Instance.EndRun();

            if (UIManager.HasInstance)
            {
                UIManager.Instance.Close<UINoticeTopInfo>();
                if (!token.IsCancellationRequested)
                    await OpenDeckSelectAsync(token);
            }
        }
    }

    /// <summary>인스펙터에 지정된 캐릭터로 선택 화면 없이 즉시 런을 시작한다.</summary>
    private async UniTask StartRunWithPresetCharacterAsync(CharacterSO character, CancellationToken token)
    {
        // 선택 캐릭터를 런 상태로 보관 → 전투 스킬 패널이 캐릭터 전용 스킬을 로드한다.
        if (InGameController.HasInstance)
            InGameController.Instance.SetSelectedCharacter(character);

        EStartingDeck deckType = character != null ? character.DeckType : EStartingDeck.None;
        await StartRunAsync(deckType, token);
    }

    private async UniTask OpenDeckSelectAsync(CancellationToken token)
    {
        if (!UIManager.HasInstance)
        {
            await StartRunAsync(token);
            return;
        }

        // 덱·시작 카드팩 선택 전용 BGM — 화면이 실제로 열리는 이 지점에서만 재생한다.
        // 뒤로가기 등으로 이 화면을 다시 열어도 같은 곡이므로 AudioManager 가 재시작 없이
        // 볼륨만 맞춘다(재생 위치 유지).
        if (AudioManager.HasInstance)
            AudioManager.Instance.PlayBgmAsync(AudioKeys.Bgm.CARD_PACK, crossfade: 2f).Forget();

        UIWindowDeckSelect deckSelect = await UIManager.Instance.OpenAsync<UIWindowDeckSelect>(_deckSelectKey, token);
        if (deckSelect == null)
        {
            await StartRunAsync(token);
            return;
        }

        deckSelect.OnStartRequested -= HandleCharacterStartRequested;
        deckSelect.OnStartRequested += HandleCharacterStartRequested;
        await deckSelect.WaitUntilReadyAsync(token);
    }

    public async UniTask OpenDeckSelectFromGameClearAsync()
    {
        CancellationToken token = _cts != null ? _cts.Token : default;

        await UniTask.Yield();

        if (InGameController.HasInstance)
            InGameController.Instance.EndRun();

        if (GameFlowManager.HasInstance)
            GameFlowManager.Instance.SetState(EGameState.InGame);

        if (SceneFlowManager.HasInstance)
        {
            await SceneFlowManager.Instance.RunWithFadeAsync(
                async fadeToken =>
                {
                    CloseDeckSelect();
                    await OpenDeckSelectAsync(fadeToken);
                },
                token);
        }
        else
        {
            CloseDeckSelect();
            await OpenDeckSelectAsync(token);
        }
    }

    private void HandleCharacterStartRequested(CharacterSO character)
    {
        StartRunFromDeckSelectAsync(character).Forget();
    }

    private async UniTaskVoid StartRunFromDeckSelectAsync(CharacterSO character)
    {
        CancellationToken token = _cts != null ? _cts.Token : default;

        // 선택 캐릭터를 런 상태로 보관 → 전투 스킬 패널이 캐릭터 전용 스킬을 로드한다.
        if (InGameController.HasInstance)
            InGameController.Instance.SetSelectedCharacter(character);

        EStartingDeck deckType = character != null ? character.DeckType : EStartingDeck.None;

        if (SceneFlowManager.HasInstance)
        {
            await SceneFlowManager.Instance.RunWithFadeAsync(
                _ =>
                {
                    CloseDeckSelect();
                    return UniTask.CompletedTask;
                },
                token);

            await StartRunAsync(deckType, token);
        }
        else
        {
            CloseDeckSelect();
            await StartRunAsync(deckType, token);
        }
    }

    private void CloseDeckSelect()
    {
        if (!UIManager.HasInstance) return;

        UIWindowDeckSelect deckSelect = UIManager.Instance.Get<UIWindowDeckSelect>();
        if (deckSelect != null)
        {
            deckSelect.OnStartRequested -= HandleCharacterStartRequested;
            UIManager.Instance.Close(deckSelect);
        }
    }

    private void OnDisable()
    {
        if (UIManager.HasInstance)
        {
            UIWindowDeckSelect deckSelect = UIManager.Instance.Get<UIWindowDeckSelect>();
            if (deckSelect != null)
            {
                deckSelect.OnStartRequested -= HandleCharacterStartRequested;
            }
        }
    }

    /// <summary>타이틀로 복귀 (일시정지 메뉴의 "나가기" 등).</summary>
    public void ReturnToTitle()
    {
        if (TimeManager.HasInstance)
        {
            TimeManager.Instance.ClearScales();
            if (TimeManager.Instance.IsPaused)
                TimeManager.Instance.Resume();
        }

        SceneFlowManager.Instance.LoadSceneWithScreenAsync(_titleSceneName).Forget();
    }

    /// <summary>팝업으로 소비되지 않은 ESC 수신 → 런 진행 중이면 일시정지 메뉴 토글.</summary>
    private void HandleEscapeUnhandled()
    {
        // 런이 살아있는 인게임 상태에서만 메뉴를 연다.
        if (!InGameController.HasInstance || !InGameController.Instance.IsRunActive) return;

        InGameController.Instance.ToggleEscMenu();
    }

    // ─────────────────────────────────────────────
    // 일시정지 (InputManager ESC 등에서 호출)
    // ─────────────────────────────────────────────

    public void TogglePause()
    {
        // GameFlowManager 로 일원화 → 상태 전환 시 TimeManager 를 단일 출처로 제어.
        if (GameFlowManager.HasInstance)
            GameFlowManager.Instance.TogglePause();

        // TODO: 일시정지 UI 토글 (상태 구독으로 처리 권장).
    }

    protected override void OnDestroy()
    {
        base.OnDestroy(); // SceneSingleton — Instance 해제

        _cts?.Cancel();
        _cts?.Dispose();

        if (UIManager.HasInstance)
        {
            UIManager.Instance.OnEscapeUnhandled -= HandleEscapeUnhandled;
        }

        if (SceneFlowManager.HasInstance)
            SceneFlowManager.Instance.UnregisterLifecycle(this);
    }
}
