using Cysharp.Threading.Tasks;
using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.InputSystem;
using UnityEngine.UI;

public sealed class SkillCastInput : MonoBehaviour
{
    private const string CooldownMessageKey = "UI_SKILL_COOLDOWN";

    [Header("Raycast")]
    [SerializeField] private Camera _camera;
    [SerializeField] private LayerMask _slotLayerMask = ~0;
    [Min(1f)]
    [SerializeField] private float _rayDistance = 100f;

    [Header("시전 아이콘")]
    [SerializeField] private RectTransform _cursorIconRoot;
    [SerializeField] private Image _cursorIcon;

    private readonly RaycastHit[] _slotHits = new RaycastHit[32];
    private SkillRuntime _castingSkill;
    private SkillCastContext _context = SkillCastContext.None;
    private Card _tutorialAllowedTarget;

    private Camera Cam => _camera != null ? _camera : Camera.main;

    public bool IsCasting => _castingSkill != null;

    /// <summary>타겟팅(시전 대기) 시작 — 손패 흐리기 등 "그리드 선택 모드" 진입 신호.</summary>
    public event Action OnCastStarted;
    public event Action OnCastEnded;
    /// <summary>스킬 효과 적용 완료. 스킬 ID, 대상 카드, 선택 방향을 전달한다.</summary>
    public event Action<string, Card, ECardDirection> OnSkillApplied;

    /// <summary>튜토리얼 중 스킬 적용 대상을 한 장으로 제한한다. null이면 해제한다.</summary>
    public void SetTutorialAllowedTarget(Card target)
    {
        _tutorialAllowedTarget = target;
        CancelCast();
    }

    /// <summary>방향 없이 즉시 타겟팅 시작 (off 형 스킬용).</summary>
    public void BeginCast(SkillRuntime skill)
        => BeginCastWithDirection(skill, ECardDirection.None);

    /// <summary>
    /// 방향 버튼 클릭 즉시 (스킬 + 방향) 타겟팅을 시작한다.
    /// 기존의 "방향 선택 대기" 중간 단계를 제거한 단축 진입점.
    /// 같은 스킬·방향을 다시 누르면 시전을 취소(토글)한다.
    /// </summary>
    public void BeginCastWithDirection(SkillRuntime skill, ECardDirection direction)
    {
        if (skill == null || skill.Data == null)
            return;

        if (!CanUseCurrentPhase())
            return;

        if (!skill.IsReady)
        {
            ShowCooldownMessageAsync().Forget();
            return;
        }

        // 동일 스킬 + 동일 방향 재클릭 → 토글 취소.
        if (_castingSkill == skill && _context.Direction == direction)
        {
            CancelCast();
            return;
        }

        // 방향 전환은 내부 리셋만(OnCastEnded 미발행) → 스킬 선택 해제 같은 종료 처리를 유발하지 않는다.
        ResetCastState();
        StartTargeting(skill, new SkillCastContext(direction));
    }

    public void CancelCast()
    {
        bool wasCasting = IsCasting;
        ResetCastState();
        if (wasCasting)
            OnCastEnded?.Invoke();
    }

    /// <summary>시전 상태만 초기화 (커서·프리뷰 정리). OnCastEnded 는 발행하지 않는다 — 전환 중 내부용.</summary>
    private void ResetCastState()
    {
        _castingSkill = null;
        _context = SkillCastContext.None;
        SetCursorVisible(false);
        if (GridManager.HasInstance)
        {
            GridManager.Instance.SetSkillPreviewActive(false);
            GridManager.Instance.ClearPlacementPreview();
        }
    }

    private void StartTargeting(SkillRuntime skill, SkillCastContext context)
    {
        _castingSkill = skill;
        _context = context;
        if (GridManager.HasInstance)
            GridManager.Instance.SetSkillPreviewActive(true);
        SetCursorVisible(true);
        LoadCursorIconAsync(skill).Forget();
        OnCastStarted?.Invoke();
    }

    private void Update()
    {
        if (_castingSkill == null)
            return;

        if (!CanUseCurrentPhase())
        {
            CancelCast();
            return;
        }

        Mouse mouse = Mouse.current;
        if (mouse == null)
            return;

        Vector2 mousePosition = mouse.position.ReadValue();

        if (mouse.rightButton.wasPressedThisFrame)
        {
            CancelCast();
            return;
        }

        UpdateCursorPosition(mousePosition);
        UpdatePreview(mousePosition);

        if (mouse.leftButton.wasPressedThisFrame)
        {
            if (IsPointerOverUI(mousePosition))
            {
                // 스킬 시전 버튼 위 클릭은 패널이 토글/방향전환을 처리하므로 취소하지 않는다.
                // 그 외 UI(손패·더미·턴종료 등) 클릭은 "다른 행동"으로 보고 시전을 취소한다.
                if (!IsPointerOverSkillCastButton(mousePosition))
                    CancelCast();
            }
            else
            {
                // UI 밖(그리드) 클릭 — 유효 타겟이면 적용, 아니면 TryApplyAt 내부에서 취소한다.
                TryApplyAt(mousePosition);
            }
        }
    }

    // UI 레이캐스트 결과 재사용 버퍼 (클릭 프레임에만 사용 — 매 프레임 아님).
    private readonly List<RaycastResult> _uiRaycastResults = new List<RaycastResult>(16);

    /// <summary>포인터가 UI 요소 위에 있는지 (EventSystem 기반).</summary>
    private static bool IsPointerOverUI(Vector2 screenPosition)
    {
        EventSystem es = EventSystem.current;
        return es != null && es.IsPointerOverGameObject();
    }

    /// <summary>포인터 아래 UI 중에 스킬 시전 버튼(방향/탭)이 있는지 — 토글 처리를 위해 취소 제외 대상.</summary>
    private bool IsPointerOverSkillCastButton(Vector2 screenPosition)
    {
        EventSystem es = EventSystem.current;
        if (es == null) return false;

        PointerEventData pointer = new PointerEventData(es) { position = screenPosition };
        _uiRaycastResults.Clear();
        es.RaycastAll(pointer, _uiRaycastResults);

        for (int i = 0; i < _uiRaycastResults.Count; i++)
        {
            GameObject go = _uiRaycastResults[i].gameObject;
            if (go == null) continue;
            if (go.GetComponentInParent<UIBattleSkillButton>() != null) return true;
            if (go.GetComponentInParent<UIBattleSkillSelectButton>() != null) return true;
        }
        return false;
    }

    private void UpdateCursorPosition(Vector2 screenPosition)
    {
        if (_cursorIconRoot != null)
            _cursorIconRoot.position = screenPosition;
    }

    private void UpdatePreview(Vector2 screenPosition)
    {
        if (!GridManager.HasInstance)
            return;

        GridSlot slot = FindSlotAt(screenPosition);
        if (slot == null)
        {
            GridManager.Instance.ClearPlacementPreview();
            return;
        }

        bool canApply = CanApplyToSlot(slot);
        GridManager.Instance.ShowSkillTargetPreview(slot.Position, canApply);
    }

    private void TryApplyAt(Vector2 screenPos)
    {
        if (_castingSkill == null || !_castingSkill.IsReady)
        {
            ShowCooldownMessageAsync().Forget();
            CancelCast();
            return;
        }

        GridSlot slot = FindSlotAt(screenPos);
        if (!CanApplyToSlot(slot))
            return; // 그리드 빈 칸/잘못된 칸 클릭은 무시 (시전 유지 — UI 클릭에서만 취소).

        Card target = slot.OccupiedCard;
        SkillRuntime skill = _castingSkill;
        ECardDirection direction = _context.Direction;
        IReadOnlyList<SkillEffectBase> effects = _castingSkill.Data.Effects;
        for (int i = 0; i < effects.Count; i++)
        {
            if (effects[i] != null && effects[i].CanApplyToCard(target, _context))
                effects[i].ApplyToCard(target, GridManager.Instance, _context);
        }

        skill.Use();
        OnSkillApplied?.Invoke(skill.Data.SkillId, target, direction);

        // 업적 신호: 이번 런에서 스킬을 사용함(스킬 미사용 클리어 실격 표식).
        if (EventManager.HasInstance)
            EventManager.Instance.Publish(new SkillUsedSignal());

        if (AudioManager.HasInstance)
            AudioManager.Instance.PlaySfxAsync(AudioKeys.Skill.USE).Forget();
        CancelCast();
    }

    private bool CanApplyToSlot(GridSlot slot)
    {
        if (_castingSkill == null || _castingSkill.Data == null || slot == null || slot.IsEmpty)
            return false;
        if (!CanUseCurrentPhase() || !GridManager.HasInstance)
            return false;
        if (_tutorialAllowedTarget != null && slot.OccupiedCard != _tutorialAllowedTarget)
            return false;

        IReadOnlyList<SkillEffectBase> effects = _castingSkill.Data.Effects;
        for (int i = 0; i < effects.Count; i++)
        {
            if (effects[i] != null && effects[i].CanApplyToCard(slot.OccupiedCard, _context))
                return true;
        }
        return false;
    }

    private bool CanUseCurrentPhase()
    {
        return BattleManager.HasInstance &&
               BattleManager.Instance.IsBattleActive &&
               BattleManager.Instance.CurrentPhase == EBattlePhase.PlayerInput &&
               !BattleManager.Instance.IsProcessing;
    }

    private GridSlot FindSlotAt(Vector2 screenPos)
    {
        Camera cam = Cam;
        if (cam == null) return null;

        Ray ray = cam.ScreenPointToRay(screenPos);
        int hitCount = Physics.RaycastNonAlloc(
            ray,
            _slotHits,
            _rayDistance,
            _slotLayerMask,
            QueryTriggerInteraction.Collide);

        GridSlot nearestSlot = null;
        float nearestDistance = float.MaxValue;
        for (int i = 0; i < hitCount; i++)
        {
            RaycastHit hit = _slotHits[i];
            if (hit.collider == null || hit.distance >= nearestDistance)
                continue;

            GridSlot slot = hit.collider.GetComponentInParent<GridSlot>();
            if (slot == null) continue;

            nearestSlot = slot;
            nearestDistance = hit.distance;
        }

        return nearestSlot;
    }

    private void SetCursorVisible(bool visible)
    {
        if (_cursorIconRoot != null)
            _cursorIconRoot.gameObject.SetActive(visible);
    }

    private async UniTaskVoid LoadCursorIconAsync(SkillRuntime skill)
    {
        if (_cursorIcon == null || skill?.Data == null || string.IsNullOrEmpty(skill.Data.IconKey))
            return;
        if (!ResourceManager.HasInstance)
            return;

        Sprite sprite = await ResourceManager.Instance.LoadAtlasSpriteAsync(
            EAtlasType.CardIcon, skill.Data.IconKey, this.GetCancellationTokenOnDestroy());
        if (this == null || _castingSkill != skill)
            return;
        _cursorIcon.sprite = sprite;
        _cursorIcon.enabled = sprite != null;
    }

    private async UniTaskVoid ShowCooldownMessageAsync()
    {
        if (!UIManager.HasInstance) return;
        UISystemNavi systemNavi = await UIManager.Instance.OpenAsync<UISystemNavi>();
        systemNavi?.Show(CooldownMessageKey);
    }
}
