// =================================================================
// [스크립트 목적]  휴식(모닥불) 노드 시스템. Rest 노드 진입 시 휴식 UI 를 띄우고,
//                 회복/강화 중 하나를 확정한 뒤 맵 복귀를 알린다.
// [주요 변수]      - _healPercent  : 회복 비율 (MaxHp 의 %) — 인스펙터 조절
//                  - _healFlatBonus: 비율 외 추가 고정 회복 (선택)
// [의존 관계]      - InGameController(OpenFromMapNodeAsync 로 구동 / RunContext·복귀)
//                  - UIManager / UIRestPopup / RunContext
// [배치]           인게임 씬에 1개 배치 (SceneSingleton). ShopController 와 동격의 노드 처리자.
// [설계 노트]      - 진입 페이드가 걷히기 전에 UI 생성을 끝내야 해서 InGameController 가
//                    OpenFromMapNodeAsync 를 직접 await 한다(OnMapNodeEntered 구독 아님).
//                    그 이벤트는 튜토리얼 등 관전 시스템용 통지로만 발행된다.
//                  - 회복량은 밸런스 수치 → Constants 금지 원칙 따라 인스펙터 노출.
//                  - 회복과 강화는 Rest 노드마다 하나만 확정할 수 있다.
//                  - HP 변경은 RunContext.HealHp 로 수행. 휴식은 맵 화면(전투 밖)이라
//                    전투용 HP UI(PlayerActor 이벤트)와 무관 — UIRestPopup 이 회복 결과를 직접 표시.
// =================================================================

using Cysharp.Threading.Tasks;
using UnityEngine;

/// <summary>
/// 휴식 노드 처리자. 체력 회복과 카드 강화를 제공한다.
/// Rest 노드 진입 이벤트를 구독해 UI 를 띄우고, 나가기 시 InGameController 로 맵 복귀를 알린다.
/// </summary>
public sealed class RestController : SceneSingleton<RestController>
{
    /// <summary>휴식 노드 선택 확정 통지. 인자: true=강화, false=회복. 분석 등이 구독한다.</summary>
    public event System.Action<bool> OnRestChoiceMade;

    [Header("회복")]
    [Tooltip("휴식 회복 비율 (최대 체력의 %). 슬더스 기본 30")]
    [Range(0, 100)]
    [SerializeField] private int _healPercent = 30;

    [Tooltip("비율 회복에 더해지는 고정 회복량 (선택, 기본 0)")]
    [Min(0)]
    [SerializeField] private int _healFlatBonus = 0;

    [Header("자동 나가기")]
    [Tooltip("회복 확정 후 자동으로 나가기까지 대기 시간 (초). 갱신된 체력을 보여주는 시간")]
    [Min(0f)]
    [SerializeField] private float _autoLeaveDelay = 0.75f;

    private UIRestPopup _popup;
    private int _activeNodeId = RunContext.NoNode;
    private bool _choiceConfirmed;

    protected override void OnDestroy()
    {
        DetachPopup();
        base.OnDestroy();
    }

    // 휴식 열기는 InGameController.EnterNonBattleNodeWithFadeAsync 가 OpenFromMapNodeAsync 로
    // 직접 구동한다(페이드 안에서 UI 생성까지 대기해야 하므로). OnMapNodeEntered 는
    // 튜토리얼 등 관전 시스템용 통지로만 쓰이며, 여기서 구독하면 휴식이 이중으로 열린다.

    /// <summary>InGameController의 페이드 내부에서 호출. UI 생성 완료까지 기다린다.</summary>
    public UniTask OpenFromMapNodeAsync(int nodeId)
    {
        return OpenRestAsync(nodeId);
    }

    private async UniTask OpenRestAsync(int nodeId)
    {
        RunContext run = CurrentRun;
        if (run == null || !UIManager.HasInstance)
        {
            ResolveAndReturn();
            return;
        }

        if (InGameController.Instance.TryGetRestChoiceForCurrentStage(nodeId, out _))
        {
            ResolveAndReturn();
            return;
        }

        _activeNodeId = nodeId;
        _choiceConfirmed = false;

        // 휴식 BGM (맵 BGM 위로 크로스페이드). 나갈 때 ResolveAndReturn 에서 맵으로 복귀.
        if (AudioManager.HasInstance)
            AudioManager.Instance.PlayBgmAsync(AudioKeys.Bgm.REST, crossfade: 1f).Forget();

        // 이번 휴식의 회복 예정량 산정 (UI 표시용 — 실제 적용은 회복 클릭 시).
        int healAmount = CalcHealAmount(run);

        UIRestPopup.Show(run.CurrentHp, run.MaxHp, healAmount);
        UIRestPopup popup = await UIManager.Instance.OpenAsync<UIRestPopup>();
        if (popup == null)
        {
            ResolveAndReturn();
            return;
        }

        _popup = popup;

        // 콜백 재구독 (중복 방지).
        popup.OnRestRequested -= HandleRest;
        popup.OnReinforceRequested -= HandleReinforce;
        popup.OnLeaveRequested -= HandleLeave;
        popup.OnRestRequested += HandleRest;
        popup.OnReinforceRequested += HandleReinforce;
        popup.OnLeaveRequested += HandleLeave;

#if UNITY_EDITOR || DEVELOPMENT_BUILD
        Debug.Log($"[RestController] 휴식 진입 — 현재 {run.CurrentHp}/{run.MaxHp}, 회복예정 +{healAmount}");
#endif
    }

    /// <summary>이번 휴식 회복량 = MaxHp * 비율 + 고정 보너스 (반올림).</summary>
    private int CalcHealAmount(RunContext run)
    {
        if (run == null || !run.HasHp) return 0;
        int byPercent = Mathf.RoundToInt(run.MaxHp * (_healPercent / 100f));
        return byPercent + _healFlatBonus;
    }

    // ─────────────────────────────────────────────
    // 회복 / 나가기 (UI 콜백)
    // ─────────────────────────────────────────────

    /// <summary>휴식(회복) 선택 — HP 회복 후 선택을 확정하고 잠시 뒤 자동으로 나간다.</summary>
    private void HandleRest()
    {
        if (_choiceConfirmed) return;

        RunContext run = CurrentRun;
        if (run != null && run.HasHp)
        {
            int healed = run.HealHp(CalcHealAmount(run));
            if (healed > 0)
            {
                if (AudioManager.HasInstance)
                    AudioManager.Instance.PlaySfxAsync(AudioKeys.Game.REST_HEAL).Forget();

                ConfirmChoice(false);

                // 회복 선택 확정 통지 (분석 등).
                OnRestChoiceMade?.Invoke(false);

                SaveRunProgress(currentNodeResolved: true);
                _popup?.ShowHealResult(run.CurrentHp, run.MaxHp);
                AutoLeaveAsync(_autoLeaveDelay).Forget();
            }
#if UNITY_EDITOR || DEVELOPMENT_BUILD
            Debug.Log($"[RestController] 휴식 회복 — +{healed} (현재 {run.CurrentHp}/{run.MaxHp})");
#endif
        }
    }

    private void HandleReinforce()
    {
        if (_choiceConfirmed || _activeNodeId == RunContext.NoNode || !ReinforceController.HasInstance) return;
        ReinforceController.Instance.OpenFromRest(_activeNodeId, HandleReinforceClosed);
    }

    private void HandleReinforceClosed(bool reinforced)
    {
        if (!reinforced) return;
        ConfirmChoice(true);

        // 강화 선택 확정 통지 (분석 등). 강화 상세(카드·방향)는 ReinforceController가 별도로 발행한다.
        OnRestChoiceMade?.Invoke(true);

        // 강화 결과는 이미 결과 화면에서 확인했으므로 휴식 창을 거치지 않고 바로 나간다.
        AutoLeaveAsync(0f).Forget();
    }

    private void ConfirmChoice(bool isReinforce)
    {
        _choiceConfirmed = true;
        if (_activeNodeId != RunContext.NoNode && InGameController.HasInstance)
            InGameController.Instance.RecordRestChoiceForCurrentStage(_activeNodeId, isReinforce);
        _popup?.SetChoiceConfirmed();
    }

    /// <summary>회복/강화 확정 후 자동 나가기. 대기 중 수동 나가기로 이미 종료됐으면 무시한다.</summary>
    private async UniTaskVoid AutoLeaveAsync(float delaySeconds)
    {
        if (delaySeconds > 0f)
        {
            bool cancelled = await UniTask.Delay(
                Mathf.RoundToInt(delaySeconds * 1000f),
                cancellationToken: this.GetCancellationTokenOnDestroy()).SuppressCancellationThrow();
            if (cancelled) return;
        }

        if (_activeNodeId == RunContext.NoNode) return;

        await ResolveAndReturnAsync();
    }

    /// <summary>회복 없이 나가기 (휴식 스킵).</summary>
    private void HandleLeave()
    {
        ResolveAndReturn();
    }

    /// <summary>휴식 종료 — InGameController 에 노드 처리 완료를 알려 맵 복귀.</summary>
    private void ResolveAndReturn()
    {
        ResolveAndReturnAsync().Forget();
    }

    private async UniTask ResolveAndReturnAsync()
    {
        if (InGameController.HasInstance)
        {
            await InGameController.Instance.NotifyNodeResolvedWithFadeAsync(CompleteReturn);
            return;
        }

        CompleteReturn();
    }

    private void CompleteReturn()
    {
        DetachPopup();
        _activeNodeId = RunContext.NoNode;
        _choiceConfirmed = false;

    }

    private void DetachPopup()
    {
        UIRestPopup popup = _popup;
        _popup = null;
        if (popup == null) return;

        popup.OnRestRequested -= HandleRest;
        popup.OnReinforceRequested -= HandleReinforce;
        popup.OnLeaveRequested -= HandleLeave;
        if (popup.IsOpen && UIManager.HasInstance)
            UIManager.Instance.Close(popup);
    }

    private RunContext CurrentRun =>
        InGameController.HasInstance ? InGameController.Instance.CurrentRun : null;

    private void SaveRunProgress(bool currentNodeResolved)
    {
        if (InGameController.HasInstance)
            InGameController.Instance.SaveRunProgressFromExternalSystem(currentNodeResolved);
    }
}
