// =================================================================
// [스크립트 목적]  Rest 노드 Reinforce 처리자. 덱 카드 1장에 런 단위 화살표 1개를 추가한다.
// [의존 관계]      - RestController / InGameController / UIReinforcePopup / UIDeckCardPicker
// =================================================================

using System;
using System.Collections.Generic;
using Cysharp.Threading.Tasks;
using UnityEngine;

public sealed class ReinforceController : SceneSingleton<ReinforceController>
{
    /// <summary>
    /// 카드 강화(화살표 추가) 성공 통지. 인자: (카드 ID, 강화 전 방향, 추가된 방향).
    /// 분석 등 외부 시스템이 구독한다.
    /// </summary>
    public event System.Action<string, ECardDirection, ECardDirection> OnCardReinforced;

    private const string ReinforcePickerTitleKey = "UI_REINFORCE_PICKER_TITLE";
    private const string ReinforceFailedKey = "UI_REINFORCE_FAILED";

    private UIReinforcePopup _popup;
    private UIDeckCardPicker _picker;
    private int _activeNodeId = RunContext.NoNode;
    private bool _reinforceInProgress;
    private bool _applyInProgress;
    private bool _pickerOpenInProgress;
    private bool _directionOpenInProgress;
    private bool _reinforceApplied;
    private Action<bool> _onRestFlowClosed;

    public bool OpenFromRest(int nodeId, Action<bool> onClosed)
    {
        if (_reinforceInProgress || nodeId == RunContext.NoNode || onClosed == null) return false;

        _onRestFlowClosed = onClosed;
        OpenReinforce(nodeId);
        return true;
    }

    private void OpenReinforce(int nodeId)
    {
        RunContext run = CurrentRun;
        if (run == null || !UIManager.HasInstance)
        {
            ResolveAndReturn();
            return;
        }

        _activeNodeId = nodeId;
        _reinforceInProgress = true;
        _applyInProgress = false;
        bool wasReinforce = false;
        bool hasRestChoice = InGameController.HasInstance &&
                             InGameController.Instance.TryGetRestChoiceForCurrentStage(nodeId, out wasReinforce);
        _reinforceApplied = hasRestChoice && wasReinforce;

        if (hasRestChoice)
        {
            ResolveAndReturn(_reinforceApplied);
            return;
        }

        OpenReinforcePickerAsync().Forget();
    }

    private void AttachPopupEvents()
    {
        if (_popup == null) return;
        DetachPopupEvents(_popup);
        _popup.OnReinforceRequested += HandleReinforceRequested;
        _popup.OnIgnoreRequested += HandleIgnoreRequested;
        _popup.OnNextRequested += HandleNextRequested;
        _popup.OnDirectionConfirmed += HandleDirectionConfirmed;
        _popup.OnDirectionBackRequested += HandleDirectionBackRequested;
    }

    private void DetachPopupEvents(UIReinforcePopup popup)
    {
        if (popup == null) return;
        popup.OnReinforceRequested -= HandleReinforceRequested;
        popup.OnIgnoreRequested -= HandleIgnoreRequested;
        popup.OnNextRequested -= HandleNextRequested;
        popup.OnDirectionConfirmed -= HandleDirectionConfirmed;
        popup.OnDirectionBackRequested -= HandleDirectionBackRequested;
    }

    private void HandleReinforceRequested()
    {
        if (_picker != null || _pickerOpenInProgress) return;
        OpenReinforcePickerAsync().Forget();
    }

    private async UniTaskVoid OpenReinforcePickerAsync()
    {
        RunContext run = CurrentRun;
        if (run == null || !UIManager.HasInstance)
        {
            ResolveAndReturn(_reinforceApplied);
            return;
        }

        _pickerOpenInProgress = true;
        UIDeckCardPicker.Show(
            new List<RunDeckEntry>(run.DeckEntries),
            title: Localize(ReinforcePickerTitleKey),
            cancelable: true,
            requireConfirmation: false);
        _picker = await UIManager.Instance.OpenAsync<UIDeckCardPicker>();
        _pickerOpenInProgress = false;

        if (_activeNodeId == RunContext.NoNode)
        {
            ClosePicker();
            return;
        }

        if (_picker == null)
        {
            ResolveAndReturn(_reinforceApplied);
            return;
        }

        _picker.OnEntryConfirmed -= HandleReinforceSelected;
        _picker.OnCancelled -= HandlePickerCancelled;
        _picker.OnEntryConfirmed += HandleReinforceSelected;
        _picker.OnCancelled += HandlePickerCancelled;

        CloseReinforcePopupSilently();
    }

    private void HandleReinforceSelected(int entryId)
    {
        if (_activeNodeId == RunContext.NoNode || _directionOpenInProgress) return;

        if (InGameController.HasInstance &&
            InGameController.Instance.TryGetRestChoiceForCurrentStage(_activeNodeId, out bool wasReinforce))
        {
            ClosePicker();
            ResolveAndReturn(wasReinforce);
            return;
        }

        RunContext run = CurrentRun;
        if (run == null)
        {
            _picker?.ShowMessageAndReturnToList(Localize(ReinforceFailedKey));
            return;
        }

        RunDeckEntry entry = FindDeckEntry(run, entryId);
        if (entry == null || !HasAvailableDirection(entry))
        {
            _picker?.ShowMessageAndReturnToList(Localize(ReinforceFailedKey));
            return;
        }

        OpenDirectionPopupAsync(entry).Forget();
    }

    /// <summary>Rest 강화 전용 방향 선택 화면을 연다.</summary>
    private async UniTaskVoid OpenDirectionPopupAsync(RunDeckEntry entry)
    {
        if (!UIManager.HasInstance)
        {
            ResolveAndReturn();
            return;
        }

        _directionOpenInProgress = true;
        UIReinforcePopup.Show(false);
        _popup = await UIManager.Instance.OpenAsync<UIReinforcePopup>();
        _directionOpenInProgress = false;

        if (_activeNodeId == RunContext.NoNode)
        {
            CloseReinforcePopupSilently();
            return;
        }

        if (_popup == null)
        {
            ResolveAndReturn();
            return;
        }

        AttachPopupEvents();
        _popup.SetKeepViewOnDirectionBack(true);
        _popup.ShowDirectionSelection(entry);
        ClosePicker();
    }

    private void HandleDirectionConfirmed(int entryId, ECardDirection direction)
    {
        if (_applyInProgress || _activeNodeId == RunContext.NoNode) return;

        RunContext run = CurrentRun;
        if (run == null)
        {
            ClosePopupAndResolve();
            return;
        }

        // 강화 전 상태를 미리 읽는다 (적용 후에는 이전 방향을 알 수 없다).
        string targetCardId = null;
        ECardDirection previousDirection = ECardDirection.None;
        IReadOnlyList<RunDeckEntry> entries = run.DeckEntries;
        for (int i = 0; i < entries.Count; i++)
        {
            if (entries[i].EntryId != entryId) continue;

            targetCardId = entries[i].CardId;
            previousDirection = entries[i].ArrowDirection;
            break;
        }

        _applyInProgress = true;
        bool applied = run.TryAddArrowToEntry(entryId, direction);
        _applyInProgress = false;
        if (!applied)
        {
            ClosePopupAndResolve();
            return;
        }

        run.Statistics.RecordReinforcement();

        // 강화 성공 통지 (분석 등).
        if (!string.IsNullOrEmpty(targetCardId))
            OnCardReinforced?.Invoke(targetCardId, previousDirection, direction);

        if (InGameController.HasInstance)
            InGameController.Instance.RecordRestChoiceForCurrentStage(_activeNodeId, true);
        _reinforceApplied = true;
        SaveRunProgress(currentNodeResolved: true);
        RunDeckEntry reinforcedEntry = FindDeckEntry(run, entryId);

        if (_popup != null && reinforcedEntry != null)
            _popup.ShowReinforceResult(reinforcedEntry, direction);
        else
            ClosePopupAndResolve(true);

#if UNITY_EDITOR || DEVELOPMENT_BUILD
        Debug.Log($"[ReinforceController] Reinforce 완료 — node={_activeNodeId}, entry={entryId}, added={direction}");
#endif
    }

    private void HandleDirectionBackRequested()
    {
        if (_picker != null || _pickerOpenInProgress) return;
        OpenReinforcePickerAsync().Forget();
    }

    private void CloseReinforcePopupSilently()
    {
        if (_popup == null) return;

        UIReinforcePopup popup = _popup;
        DetachPopupEvents(popup);
        _popup = null;

        if (popup.IsOpen && UIManager.HasInstance)
            UIManager.Instance.Close(popup);
    }

    private void HandleIgnoreRequested()
    {
        ResolveAndReturn(_reinforceApplied);
    }

    private void HandleNextRequested()
    {
        ResolveAndReturn(true);
    }

    private void HandlePickerCancelled()
    {
        if (_picker != null)
        {
            _picker.OnEntryConfirmed -= HandleReinforceSelected;
            _picker.OnCancelled -= HandlePickerCancelled;
            _picker = null;
        }

        if (_popup == null)
            ResolveAndReturn(_reinforceApplied);
    }

    private void ResolveAndReturn(bool reinforced = false)
    {
        bool result = reinforced || _reinforceApplied;
        ClosePicker();

        UIReinforcePopup popup = _popup;
        if (popup != null)
        {
            DetachPopupEvents(popup);
            _popup = null;
        }

        _activeNodeId = RunContext.NoNode;
        _reinforceInProgress = false;
        _applyInProgress = false;
        _pickerOpenInProgress = false;
        _directionOpenInProgress = false;
        _reinforceApplied = false;

        Action<bool> onRestFlowClosed = _onRestFlowClosed;
        _onRestFlowClosed = null;
        if (popup != null && popup.IsOpen && UIManager.HasInstance)
            UIManager.Instance.Close(popup);

        if (onRestFlowClosed != null)
        {
            onRestFlowClosed(result);
            return;
        }

        if (InGameController.HasInstance)
            InGameController.Instance.NotifyNodeResolved();
    }

    private void ClosePopupAndResolve(bool reinforced = false)
    {
        UIReinforcePopup popup = _popup;
        ResolveAndReturn(reinforced);

        if (popup != null && popup.IsOpen && UIManager.HasInstance)
            UIManager.Instance.Close(popup);
    }

    private RunContext CurrentRun =>
        InGameController.HasInstance ? InGameController.Instance.CurrentRun : null;

    private void SaveRunProgress(bool currentNodeResolved)
    {
        if (InGameController.HasInstance)
            InGameController.Instance.SaveRunProgressFromExternalSystem(currentNodeResolved);
    }

    private static string Localize(string key)
    {
        return LocalizationManager.HasInstance
            ? LocalizationManager.Instance.Get(key)
            : key;
    }

    private void ClosePicker()
    {
        if (_picker == null) return;

        UIDeckCardPicker picker = _picker;
        picker.OnEntryConfirmed -= HandleReinforceSelected;
        picker.OnCancelled -= HandlePickerCancelled;
        _picker = null;

        if (UIManager.HasInstance)
            UIManager.Instance.Close(picker);
    }

    private static RunDeckEntry FindDeckEntry(RunContext run, int entryId)
    {
        if (run == null) return null;

        IReadOnlyList<RunDeckEntry> entries = run.DeckEntries;
        for (int i = 0; i < entries.Count; i++)
        {
            if (entries[i]?.EntryId == entryId)
                return entries[i];
        }
        return null;
    }

    private static bool HasAvailableDirection(RunDeckEntry entry)
    {
        return entry != null &&
               (entry.CanAddArrow(ECardDirection.Up) ||
                entry.CanAddArrow(ECardDirection.Down) ||
                entry.CanAddArrow(ECardDirection.Left) ||
                entry.CanAddArrow(ECardDirection.Right));
    }
}
