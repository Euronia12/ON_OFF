// =================================================================
// [스크립트 목적]  최초 튜토리얼 시작 전 배경 패럴랙스와 캐릭터 우측 횡단을 재생한다.
// [주요 변수]      - _backgroundPrefab : 엔딩과 공유하는 ClearBg 프리팹
//                  - _playerPrefab : Walk 애니메이션을 재사용할 공용 플레이어 프리팹
// [의존 관계]      - BattleBackgroundParallaxScroller / Player / PlayerView / Camera
// [배치]           Addressable "FirstLaunchWalkSequence" 프리팹 루트.
// =================================================================

using UnityEngine;

/// <summary>최초 자동 튜토리얼 진입용 월드 배경과 캐릭터 이동을 소유한다.</summary>
public sealed class FirstLaunchWalkSequence : MonoBehaviour
{
    [Header("배경")]
    [Tooltip("엔딩과 공유하는 ClearBg 프리팹")]
    [SerializeField] private GameObject _backgroundPrefab;

    [Tooltip("카메라 중심을 기준으로 적용할 배경 위치 오프셋(월드 단위)")]
    [SerializeField] private Vector3 _backgroundCameraOffset = new Vector3(0f, -1f, 0f);

    [Tooltip("배경 종횡비를 유지하는 균일 배율")]
    [Min(0.01f)]
    [SerializeField] private float _backgroundUniformScale = 1f;

    [Header("캐릭터")]
    [Tooltip("횡단 연출에서 복제할 공용 플레이어 프리팹")]
    [SerializeField] private Player _playerPrefab;

    [Tooltip("카메라 중심을 기준으로 적용할 캐릭터 위치 오프셋(월드 단위)")]
    [SerializeField] private Vector3 _playerCameraOffset = new Vector3(0f, 1f, 0f);

    [Tooltip("캐릭터가 화면 밖에 완전히 숨도록 더하는 좌우 여백(월드 단위)")]
    [Min(0f)]
    [SerializeField] private float _offscreenPadding = 0.2f;

    [Tooltip("Renderer를 찾지 못했을 때 사용할 캐릭터 반폭(월드 단위)")]
    [Min(0f)]
    [SerializeField] private float _fallbackPlayerHalfWidth = 0.5f;

    [Tooltip("오른쪽으로 걸을 때 SpriteRenderer를 좌우 반전할지 여부")]
    [SerializeField] private bool _flipForRight;

    private Camera _camera;
    private GameObject _backgroundInstance;
    private BattleBackgroundParallaxScroller _backgroundScroller;
    private Player _playerInstance;
    private PlayerView _playerView;
    private SpriteRenderer _playerRenderer;
    private Vector3 _playerBasePosition;
    private float _startX;
    private float _endX;

    public float Progress { get; private set; }

    /// <summary>카메라 기준으로 배경과 캐릭터를 만들고 캐릭터를 좌측 화면 밖에 배치한다.</summary>
    public void Prepare(Camera targetCamera)
    {
        _camera = targetCamera;
        if (_camera == null)
        {
            Debug.LogWarning("[FirstLaunchWalkSequence] 카메라가 없어 폴백 위치로 연출을 준비합니다.");
        }

        CreateBackground();
        CreatePlayer();
        ConfigureTravelRange();
        SetNormalizedProgress(0f);
    }

    /// <summary>Walk 애니메이션과 좌측 방향 패럴랙스를 시작한다.</summary>
    public void BeginWalk()
    {
        if (_playerView != null)
        {
            _playerView.SetFlipX(_flipForRight);
            _playerView.PlayWalkAnimation();
        }

        if (_backgroundScroller != null)
            _backgroundScroller.Resume();
    }

    /// <summary>전체 이동거리 0~1의 정규화 위치로 캐릭터를 이동한다.</summary>
    public void SetNormalizedProgress(float progress)
    {
        Progress = Mathf.Clamp01(progress);
        if (_playerInstance == null) return;

        Vector3 position = _playerBasePosition;
        position.x = Mathf.Lerp(_startX, _endX, Progress);
        _playerInstance.transform.position = position;
    }

    /// <summary>캐릭터를 우측 화면 밖으로 확정하고 배경 이동을 정지한다.</summary>
    public void ForceComplete()
    {
        SetNormalizedProgress(1f);
        Stop();
    }

    public void Stop()
    {
        if (_backgroundScroller != null)
            _backgroundScroller.Stop();
    }

    private void CreateBackground()
    {
        if (_backgroundPrefab == null || _backgroundInstance != null) return;

        _backgroundInstance = Instantiate(_backgroundPrefab, transform);
        Transform backgroundTransform = _backgroundInstance.transform;
        Vector3 cameraPosition = _camera != null ? _camera.transform.position : Vector3.zero;
        backgroundTransform.position = new Vector3(
            cameraPosition.x + _backgroundCameraOffset.x,
            cameraPosition.y + _backgroundCameraOffset.y,
            _backgroundCameraOffset.z);

        float scale = Mathf.Max(0.01f, _backgroundUniformScale);
        backgroundTransform.localScale = new Vector3(scale, scale, scale);

        _backgroundScroller = _backgroundInstance
            .GetComponentInChildren<BattleBackgroundParallaxScroller>(includeInactive: true);
        if (_backgroundScroller == null)
        {
            Debug.LogWarning("[FirstLaunchWalkSequence] ClearBg 패럴랙스 컴포넌트를 찾지 못했습니다.");
            return;
        }

        // 캐릭터가 오른쪽으로 걸으므로 배경은 반대 방향인 왼쪽으로 순환한다.
        _backgroundScroller.Configure(_camera, moveRight: false, useUnscaledTime: true);
        _backgroundScroller.Stop();
    }

    private void CreatePlayer()
    {
        if (_playerPrefab == null || _playerInstance != null) return;

        _playerInstance = Instantiate(_playerPrefab, transform);
        _playerInstance.transform.localRotation = Quaternion.identity;
        _playerView = _playerInstance.View;
        _playerRenderer = _playerInstance.GetComponentInChildren<SpriteRenderer>(includeInactive: true);

        Vector3 cameraPosition = _camera != null ? _camera.transform.position : Vector3.zero;
        _playerBasePosition = new Vector3(
            cameraPosition.x + _playerCameraOffset.x,
            cameraPosition.y + _playerCameraOffset.y,
            _playerCameraOffset.z);
    }

    private void ConfigureTravelRange()
    {
        float halfWidth = _playerRenderer != null
            ? _playerRenderer.bounds.extents.x
            : Mathf.Max(0f, _fallbackPlayerHalfWidth);

        if (_camera != null)
        {
            float leftEdge = _camera.ViewportToWorldPoint(new Vector3(0f, 0.5f, 0f)).x;
            float rightEdge = _camera.ViewportToWorldPoint(new Vector3(1f, 0.5f, 0f)).x;
            _startX = leftEdge - halfWidth - _offscreenPadding;
            _endX = rightEdge + halfWidth + _offscreenPadding;
            return;
        }

        _startX = _playerBasePosition.x - 10f - halfWidth - _offscreenPadding;
        _endX = _playerBasePosition.x + 10f + halfWidth + _offscreenPadding;
    }

    private void OnDestroy()
    {
        Stop();
    }
}
