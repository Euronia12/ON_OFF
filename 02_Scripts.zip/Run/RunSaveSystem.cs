// =================================================================
// [스크립트 목적]  런 저장 파일 입출력. 원자적 쓰기 + 무결성(HMAC) 검증으로
//                 손상·변조로부터 저장을 보호한다.
// [의존 관계]      - RunContext.ToSaveData / RestoreFromSave 와 짝을 이룬다.
// [설계 노트]      - 원자적 쓰기: 임시 파일에 먼저 쓰고 성공 시 교체(File.Replace/Move).
//                    쓰기 도중 크래시/전원 차단 시 기존 저장이 손상되지 않는다.
//                  - 무결성: payload(JSON) + HMAC-SHA256 서명을 봉투(Envelope)로 감싼다.
//                    로드 시 서명 불일치면 변조로 간주해 거부한다.
//                  - ★ 키가 클라이언트에 내장되므로 완전한 치트 방지는 아니다(난독화 수준).
//                    서버 검증이 없는 싱글플레이 기준의 변조 억제 목적이다.
//                  - 구버전(봉투 없는 평문 JSON) 저장은 하위호환으로 그대로 읽는다.
// =================================================================

using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using UnityEngine;

public static class RunSaveSystem
{
    private const string FileName = "run_save.json";
    private const string TempFileName = "run_save.json.tmp";

    // HMAC 서명 키. 클라이언트 내장 — 난독화 수준의 변조 억제용(서버 검증 아님).
    private static readonly byte[] SignatureKey =
        Encoding.UTF8.GetBytes("zRzhAVa5ONbBE/Ju84dFHH3JrxNXTdoA6SW3XDaUlMQ=");

    private static string SavePath => Path.Combine(Application.persistentDataPath, FileName);
    private static string TempPath => Path.Combine(Application.persistentDataPath, TempFileName);

    // 이 세션에서 저장 파일을 건드리면 안 될 때 켠다(예: 튜토리얼 — 일반 게임 세이브와 슬롯 공유).
    // 켜져 있는 동안 Save/Clear 는 모두 무시되어, 어떤 경로로 호출돼도 기존 세이브가 보존된다.
    public static bool SuppressPersistence { get; set; }

    public static bool HasSave => File.Exists(SavePath);

    // 저장 봉투: 실제 데이터(JSON 문자열) + 그 서명.
    [Serializable]
    private sealed class SaveEnvelope
    {
        public string payload;
        public string sig;
    }

    public static bool TryLoad(out RunSaveData data)
    {
        data = null;
        if (!File.Exists(SavePath)) return false;

        try
        {
            string raw = File.ReadAllText(SavePath);
            data = Deserialize(raw);
            if (data == null || data.version <= 0) { data = null; return false; }
            if (data.version < 2)
                data.currentNodeResolved = true;
            return true;
        }
        catch (Exception e)
        {
            Debug.LogWarning($"[RunSaveSystem] 런 저장 불러오기 실패: {e.Message}");
            data = null;
            return false;
        }
    }

    public static bool Save(
        RunContext run,
        int currentStageIndex,
        string selectedCharacterId = null,
        bool currentNodeResolved = true,
        bool stageTransitionPending = false)
    {
        if (SuppressPersistence) return true;
        if (run == null) return false;

        RunSaveData data = run.ToSaveData(
            currentStageIndex,
            selectedCharacterId,
            currentNodeResolved,
            stageTransitionPending);
        try
        {
            string json = Serialize(data);
            WriteAtomic(json);
            return true;
        }
        catch (Exception e)
        {
            Debug.LogWarning($"[RunSaveSystem] 런 저장 실패: {e.Message}");
            return false;
        }
    }

    public static void Clear()
    {
        if (SuppressPersistence) return;
        try
        {
            if (File.Exists(SavePath))
                File.Delete(SavePath);
            if (File.Exists(TempPath))
                File.Delete(TempPath);
        }
        catch (Exception e)
        {
            Debug.LogWarning($"[RunSaveSystem] 런 저장 삭제 실패: {e.Message}");
        }
    }

    // -------------------------------------------------
    // 직렬화 / 무결성
    // -------------------------------------------------

    private static string Serialize(RunSaveData data)
    {
        // 서명은 payload 문자열 그대로에 대해 계산한다(prettyPrint 없이 안정적으로).
        string payload = JsonUtility.ToJson(data, prettyPrint: false);
        var env = new SaveEnvelope
        {
            payload = payload,
            sig = ComputeSignature(payload),
        };
        return JsonUtility.ToJson(env, prettyPrint: true);
    }

    /// <summary>봉투 형식(서명 검증) 우선, 실패 시 구버전 평문 JSON 으로 폴백.</summary>
    private static RunSaveData Deserialize(string raw)
    {
        if (string.IsNullOrEmpty(raw)) return null;

        // 1) 봉투 형식 시도.
        SaveEnvelope env = null;
        try { env = JsonUtility.FromJson<SaveEnvelope>(raw); }
        catch { env = null; }

        if (env != null && !string.IsNullOrEmpty(env.payload) && !string.IsNullOrEmpty(env.sig))
        {
            string expected = ComputeSignature(env.payload);
            if (!FixedTimeEquals(expected, env.sig))
            {
                Debug.LogWarning("[RunSaveSystem] 저장 서명 불일치 — 변조/손상으로 간주해 거부합니다.");
                return null;
            }
            return JsonUtility.FromJson<RunSaveData>(env.payload);
        }

        // 2) 구버전 하위호환: 봉투 없는 평문 RunSaveData JSON.
        return JsonUtility.FromJson<RunSaveData>(raw);
    }

    private static string ComputeSignature(string payload)
    {
        using (var hmac = new HMACSHA256(SignatureKey))
        {
            byte[] hash = hmac.ComputeHash(Encoding.UTF8.GetBytes(payload ?? string.Empty));
            return Convert.ToBase64String(hash);
        }
    }

    /// <summary>타이밍 공격 완화용 상수 시간 비교(서명 검증).</summary>
    private static bool FixedTimeEquals(string a, string b)
    {
        if (a == null || b == null || a.Length != b.Length) return false;
        int diff = 0;
        for (int i = 0; i < a.Length; i++)
            diff |= a[i] ^ b[i];
        return diff == 0;
    }

    // -------------------------------------------------
    // 원자적 쓰기
    // -------------------------------------------------

    /// <summary>
    /// 임시 파일에 먼저 쓰고 flush 후, 원본으로 교체한다.
    /// 교체는 File.Replace(원자적) 우선, 원본이 없으면 Move 로 대체한다.
    /// </summary>
    private static void WriteAtomic(string json)
    {
        // 임시 파일에 완전히 기록 + 디스크 flush.
        using (var stream = new FileStream(TempPath, FileMode.Create, FileAccess.Write, FileShare.None))
        using (var writer = new StreamWriter(stream, new UTF8Encoding(false)))
        {
            writer.Write(json);
            writer.Flush();
            stream.Flush(flushToDisk: true);
        }

        if (File.Exists(SavePath))
        {
            // 원본을 임시본으로 원자적 교체(백업 파일 없이).
            File.Replace(TempPath, SavePath, destinationBackupFileName: null);
        }
        else
        {
            File.Move(TempPath, SavePath);
        }
    }
}
