using System;
using System.Collections.Generic;

public enum ERunDifficulty
{
    Normal = 0,
    Hard = 1,
    Hell = 2,
}

[Serializable]
public sealed class RunSaveData
{
    public int version = 9;
    // 맵 생성 알고리즘 버전. 저장 당시의 MapGenerator.AlgorithmVersion 값을 기록한다.
    // 로드 시 현재 버전과 다르면 시드로 재생성한 맵이 저장 위치와 어긋날 수 있어 저장을 무효화한다.
    public int mapVersion;
    public int seed;
    public int difficulty;
    public int selectedDeckType;
    public string selectedCharacterId;
    public int currentStageIndex;
    public int currentFloor;
    public int currentNodeId = RunContext.NoNode;
    public bool currentNodeResolved;
    // 보스 보상 수령 직후 다음 스테이지 시작을 확정한 저장인지 여부.
    // 로드 시 현재 노드/탐험 기록 대신 다음 스테이지의 첫 층에서 시작한다.
    public bool stageTransitionPending;
    // 전투 승리 후 "보상 미수령" 재개용. 보상 대기 중인 노드 ID(없으면 NoNode)와
    // 이미 수령한 항목 플래그. 이어하기 시 재전투 없이 보상창부터 재개하되, 중복 수령을 막는다.
    public int rewardPendingNodeId = RunContext.NoNode;
    public bool rewardGoldClaimed;
    public bool rewardCardChosen;
    public int debugRewardRerollCount;
    // 실행 중인 이벤트 노드 재개용. 맵 배정값과 별도로, 효과 적용 도중 종료됐을 때
    // 동일 EventId의 UI를 다시 열기 위한 체크포인트다.
    public int pendingEventNodeId = RunContext.NoNode;
    public string pendingEventId = string.Empty;
    public RunSavePendingEventProgress pendingEventProgress;
    public int gold;
    public int maxHp;
    public int currentHp;
    public int maxPreserveCount;
    public bool preserveAll;
    public int cardRemovalCount;
    // 런 단위 최대 마나·턴 드로우 수(이벤트 성장). 구버전 세이브는 0 → 이어하기 시 인스펙터 초기치로 폴백.
    public int maxMana;
    public int drawPerTurn;
    public List<RunSaveDeckEntry> deck = new List<RunSaveDeckEntry>();
    public List<RunSaveShopState> shops = new List<RunSaveShopState>();
    public List<RunSaveRestChoice> restChoices = new List<RunSaveRestChoice>();
    public List<RunSaveSkillCooldown> skillCooldowns = new List<RunSaveSkillCooldown>();
    public List<int> exploredNodeIds = new List<int>();
    public List<string> encounteredEventIds = new List<string>();
    public RunSaveStatistics statistics = new RunSaveStatistics();
    // 맵 생성 시점에 확정된 이벤트. nodeId 자체가 런 전체에서 고유하다.
    public List<RunSaveEventAssignment> eventAssignments = new List<RunSaveEventAssignment>();
    // 이벤트에서 실제로 고른 선택지. 2단 연쇄 이벤트(선행 조건) 판정의 근거다.
    // "맵에 배치됨"을 뜻하는 encounteredEventIds 와 달리, 플레이어가 직접 선택한 사실만 남는다.
    public List<RunSaveEventChoice> eventChoices = new List<RunSaveEventChoice>();
    // 카드별 영구 코스트 보정(각인 등). 키는 런 덱 엔트리 ID.
    public List<RunSaveCardCostDelta> cardCostDeltas = new List<RunSaveCardCostDelta>();
    // 스킬별 영구 쿨타임 보정. 키는 SkillDataSO 의 SkillId.
    public List<RunSaveSkillCooldownDelta> skillCooldownDeltas = new List<RunSaveSkillCooldownDelta>();
}

[Serializable]
public sealed class RunSavePendingEventProgress
{
    public int nodeId = RunContext.NoNode;
    public string eventId = string.Empty;
    public int choiceIndex = -1;
    public bool costsApplied;
    public int nextEffectIndex;
    public List<string> effectTypeIds = new List<string>();
    public List<RunSaveEventEffectResult> results = new List<RunSaveEventEffectResult>();
    public List<RunSaveEventEffectState> effects = new List<RunSaveEventEffectState>();
}

[Serializable]
public sealed class RunSaveEventEffectResult
{
    public int effectIndex;
    public bool hasAmount;
    public int amount;
    public bool hasArrowAddition;
    public int arrowTargetEntryId;
    public string arrowTargetCardId = string.Empty;
    public bool arrowTargetHasDirection;
    public int arrowTargetDirection;
    public int addedArrowDirection;
    public List<RunSaveEventCardTransformResult> cardTransforms =
        new List<RunSaveEventCardTransformResult>();
    public bool hasCardCostChange;
    public int costEntryId;
    public string costCardId = string.Empty;
    public int costCardDirection;
    public int costBefore;
    public int costAfter;
}

[Serializable]
public sealed class RunSaveEventCardTransformResult
{
    public string sourceCardId = string.Empty;
    // 결과 화면이 원본 카드도 실물로 띄우므로 원본 방향까지 남긴다.
    // 원본 엔트리는 변이 시점에 덱에서 사라져 나중에 되짚을 수 없다.
    public int sourceDirection;
    public string resultCardId = string.Empty;
    public int resultDirection;
}

[Serializable]
public sealed class RunSaveEventEffectState
{
    public int effectIndex;
    public string kind = string.Empty;
    public bool prepared;
    public bool applied;
    public List<RunSaveEventTransformPair> transforms = new List<RunSaveEventTransformPair>();
    public List<RunSaveEventCardRewardSlot> rewardSlots = new List<RunSaveEventCardRewardSlot>();
}

[Serializable]
public sealed class RunSaveEventTransformPair
{
    public int sourceEntryId;
    public string sourceCardId = string.Empty;
    // 교체 전에 확정해 둔 원본 방향. 결과 화면 재현용이며 적용 로직에는 쓰지 않는다.
    public bool hasSourceArrowDirection;
    public int sourceArrowDirection;
    public string resultCardId = string.Empty;
    public bool hasArrowDirection;
    public int arrowDirection;
}

[Serializable]
public sealed class RunSaveEventCardRewardSlot
{
    public bool processed;
    public bool skipped;
    public string chosenCardId = string.Empty;
    public int chosenArrowDirection;
    public List<RunSaveEventCardCandidate> candidates = new List<RunSaveEventCardCandidate>();
}

[Serializable]
public sealed class RunSaveEventCardCandidate
{
    public string cardId = string.Empty;
    public int arrowDirection;
}

[Serializable]
public sealed class RunSaveSkillCooldown
{
    public string skillId = string.Empty;
    public int remainingTurns;
}

[Serializable]
public sealed class RunSaveStatistics
{
    public int battlesStarted;
    public int battlesCompleted;
    public int battlesWon;
    public int noDamageWins;
    public int totalBattleTurns;
    public int totalPlayerTurns;
    public int maxBattleTurns;
    public int totalDamageTaken;
    public int cardPlacementCount;
    public int infiniteLoopCount;
    public int reinforcementCount;
    public int maxChainCount;
    public List<RunSaveCardPlacement> cardPlacements = new List<RunSaveCardPlacement>();
}

[Serializable]
public sealed class RunSaveCardPlacement
{
    public string cardId = string.Empty;
    public int count;
}

[Serializable]
public sealed class RunSaveEventAssignment
{
    public int nodeId = RunContext.NoNode;
    public string eventId = string.Empty;
}

[Serializable]
public sealed class RunSaveEventChoice
{
    public string eventId = string.Empty;
    public int choiceIndex = -1;
}

[Serializable]
public sealed class RunSaveCardCostDelta
{
    public int entryId;
    public int delta;
}

[Serializable]
public sealed class RunSaveSkillCooldownDelta
{
    public string skillId = string.Empty;
    public int delta;
}

[Serializable]
public sealed class RunSaveDeckEntry
{
    public int entryId;
    public string cardId;
    public bool hasArrowDirection;
    public int arrowDirection;
}

[Serializable]
public sealed class RunSaveShopState
{
    public int nodeId;
    public int cardRemovalCost;
    public List<RunSaveShopCardEntry> cards = new List<RunSaveShopCardEntry>();
}

[Serializable]
public sealed class RunSaveShopCardEntry
{
    public string cardId;
    public int price;
    public int arrowDirection;
    public bool purchased;
}

[Serializable]
public sealed class RunSaveRestChoice
{
    public int stageIndex;
    public int nodeId;
    public bool isReinforce;
}
