using System;
using System.Collections.Generic;
using UnityEngine;

/// <summary>종료 결과 화면과 GA가 함께 사용하는 런 통계 누적기.</summary>
public sealed class RunStatisticsState
{
    private readonly Dictionary<string, int> _cardPlacements = new Dictionary<string, int>(16);

    private bool _battleActive;
    private int _currentBattleDamage;

    public int BattlesStarted { get; private set; }
    public int BattlesCompleted { get; private set; }
    public int BattlesWon { get; private set; }
    public int NoDamageWins { get; private set; }
    public int TotalBattleTurns { get; private set; }
    public int TotalPlayerTurns { get; private set; }
    public int MaxBattleTurns { get; private set; }
    public int TotalDamageTaken { get; private set; }
    public int CardPlacementCount { get; private set; }
    public int InfiniteLoopCount { get; private set; }
    public int ReinforcementCount { get; private set; }
    public int MaxChainCount { get; private set; }

    /// <summary>
    /// 이 통계가 저장에서 복원됐는지(=이어하기 런). 세션 스코프인 RunAnalyticsBuffer 와
    /// 달리 이 통계는 저장/복원되어 전체 런을 누적하므로, 드리프트 검증 시 이어하기 런은
    /// 두 계층의 스코프가 달라 비교 대상에서 제외하는 기준으로 쓴다.
    /// </summary>
    public bool WasRestored { get; private set; }

    public void BeginBattle()
    {
        if (_battleActive) return;
        _battleActive = true;
        _currentBattleDamage = 0;
        BattlesStarted++;
    }

    public void CompleteBattle(bool victory, int turns)
    {
        if (!_battleActive) return;

        turns = Mathf.Max(0, turns);
        _battleActive = false;
        BattlesCompleted++;
        TotalBattleTurns += turns;
        MaxBattleTurns = Mathf.Max(MaxBattleTurns, turns);

        if (victory)
        {
            BattlesWon++;
            if (_currentBattleDamage == 0)
                NoDamageWins++;
        }

        _currentBattleDamage = 0;
    }

    public void RecordDamageTaken(int hpDamage)
    {
        if (hpDamage <= 0) return;
        TotalDamageTaken += hpDamage;
        if (_battleActive)
            _currentBattleDamage += hpDamage;
    }

    public void RecordCardPlacement(string cardId)
    {
        if (string.IsNullOrWhiteSpace(cardId)) return;
        CardPlacementCount++;
        _cardPlacements.TryGetValue(cardId, out int current);
        _cardPlacements[cardId] = current + 1;
    }

    public void RecordInfiniteLoop() => InfiniteLoopCount++;
    public void RecordReinforcement() => ReinforcementCount++;
    public void RecordPlayerTurn() => TotalPlayerTurns++;

    /// <summary>한 체인의 최종(=피크) 활성화 수를 받아 런 최대 체인을 갱신한다.</summary>
    public void RecordChainCount(int chainCount)
    {
        if (chainCount > MaxChainCount) MaxChainCount = chainCount;
    }

    public RunStatisticsSnapshot Capture(
        ERunEndReason result,
        ERunDifficulty difficulty,
        float activeRunSeconds,
        float currentSessionSeconds,
        IReadOnlyList<RunDeckEntry> deckEntries)
    {
        var deck = new List<RunDeckSnapshotEntry>(deckEntries?.Count ?? 0);
        if (deckEntries != null)
        {
            for (int i = 0; i < deckEntries.Count; i++)
            {
                RunDeckEntry entry = deckEntries[i];
                if (entry == null || string.IsNullOrWhiteSpace(entry.CardId)) continue;
                deck.Add(new RunDeckSnapshotEntry(
                    entry.EntryId,
                    entry.CardId,
                    entry.HasArrowDirection,
                    entry.ArrowDirection));
            }
        }

        string topCardId = string.Empty;
        int topCardCount = 0;
        foreach (KeyValuePair<string, int> pair in _cardPlacements)
        {
            if (pair.Value > topCardCount ||
                (pair.Value == topCardCount && string.CompareOrdinal(pair.Key, topCardId) < 0))
            {
                topCardId = pair.Key;
                topCardCount = pair.Value;
            }
        }

        return new RunStatisticsSnapshot(
            result,
            difficulty,
            Mathf.Max(0f, activeRunSeconds),
            Mathf.Max(0f, currentSessionSeconds),
            BattlesStarted,
            BattlesCompleted,
            BattlesWon,
            NoDamageWins,
            TotalBattleTurns,
            TotalPlayerTurns,
            MaxBattleTurns,
            TotalDamageTaken,
            CardPlacementCount,
            InfiniteLoopCount,
            ReinforcementCount,
            MaxChainCount,
            topCardId,
            topCardCount,
            deck);
    }

    public RunSaveStatistics ToSaveData()
    {
        var data = new RunSaveStatistics
        {
            battlesStarted = BattlesStarted,
            battlesCompleted = BattlesCompleted,
            battlesWon = BattlesWon,
            noDamageWins = NoDamageWins,
            totalBattleTurns = TotalBattleTurns,
            totalPlayerTurns = TotalPlayerTurns,
            maxBattleTurns = MaxBattleTurns,
            totalDamageTaken = TotalDamageTaken,
            cardPlacementCount = CardPlacementCount,
            infiniteLoopCount = InfiniteLoopCount,
            reinforcementCount = ReinforcementCount,
            maxChainCount = MaxChainCount,
        };

        foreach (KeyValuePair<string, int> pair in _cardPlacements)
        {
            data.cardPlacements.Add(new RunSaveCardPlacement
            {
                cardId = pair.Key,
                count = pair.Value,
            });
        }

        return data;
    }

    public void Restore(RunSaveStatistics data)
    {
        // 이어하기 복원 경로에서만 호출된다(신규 런은 거치지 않음). 드리프트 검증 제외 기준.
        WasRestored = true;
        _battleActive = false;
        _currentBattleDamage = 0;
        _cardPlacements.Clear();

        if (data == null)
        {
            BattlesStarted = BattlesCompleted = BattlesWon = NoDamageWins = 0;
            TotalBattleTurns = TotalPlayerTurns = MaxBattleTurns = TotalDamageTaken = 0;
            CardPlacementCount = InfiniteLoopCount = ReinforcementCount = 0;
            MaxChainCount = 0;
            return;
        }

        BattlesStarted = Mathf.Max(0, data.battlesStarted);
        BattlesCompleted = Mathf.Max(0, data.battlesCompleted);
        BattlesWon = Mathf.Clamp(data.battlesWon, 0, BattlesCompleted);
        NoDamageWins = Mathf.Clamp(data.noDamageWins, 0, BattlesWon);
        TotalBattleTurns = Mathf.Max(0, data.totalBattleTurns);
        TotalPlayerTurns = Mathf.Max(TotalBattleTurns, data.totalPlayerTurns);
        MaxBattleTurns = Mathf.Max(0, data.maxBattleTurns);
        TotalDamageTaken = Mathf.Max(0, data.totalDamageTaken);
        CardPlacementCount = Mathf.Max(0, data.cardPlacementCount);
        InfiniteLoopCount = Mathf.Max(0, data.infiniteLoopCount);
        ReinforcementCount = Mathf.Max(0, data.reinforcementCount);
        MaxChainCount = Mathf.Max(0, data.maxChainCount);

        int restoredPlacements = 0;
        if (data.cardPlacements != null)
        {
            for (int i = 0; i < data.cardPlacements.Count; i++)
            {
                RunSaveCardPlacement saved = data.cardPlacements[i];
                if (saved == null || string.IsNullOrWhiteSpace(saved.cardId) || saved.count <= 0) continue;
                _cardPlacements[saved.cardId] = saved.count;
                restoredPlacements += saved.count;
            }
        }

        // 구버전/손상 저장에서 합계와 카드별 합이 다르면 상세 데이터 쪽을 신뢰한다.
        if (_cardPlacements.Count > 0)
            CardPlacementCount = restoredPlacements;
    }
}

public sealed class RunStatisticsSnapshot
{
    public ERunEndReason Result { get; }
    public ERunDifficulty Difficulty { get; }
    public float ActiveRunSeconds { get; }
    public float CurrentSessionSeconds { get; }
    public int BattlesStarted { get; }
    public int BattlesCompleted { get; }
    public int BattlesWon { get; }
    public int NoDamageWins { get; }
    public int TotalBattleTurns { get; }
    public int TotalPlayerTurns { get; }
    public int MaxBattleTurns { get; }
    public int TotalDamageTaken { get; }
    public int CardPlacementCount { get; }
    public int InfiniteLoopCount { get; }
    public int ReinforcementCount { get; }
    public int MaxChainCount { get; }
    public string TopCardId { get; }
    public int TopCardCount { get; }
    public IReadOnlyList<RunDeckSnapshotEntry> FinalDeck { get; }

    public int FinalDeckCount => FinalDeck?.Count ?? 0;
    public float AverageTurnsPerBattle => BattlesCompleted > 0 ? (float)TotalBattleTurns / BattlesCompleted : 0f;
    public float NoDamageWinRatio => BattlesWon > 0 ? (float)NoDamageWins / BattlesWon : 0f;
    public float AverageDamagePerBattle => BattlesCompleted > 0 ? (float)TotalDamageTaken / BattlesCompleted : 0f;
    public float AverageCardPlacementsPerTurn => TotalPlayerTurns > 0 ? (float)CardPlacementCount / TotalPlayerTurns : 0f;

    public RunStatisticsSnapshot(
        ERunEndReason result,
        ERunDifficulty difficulty,
        float activeRunSeconds,
        float currentSessionSeconds,
        int battlesStarted,
        int battlesCompleted,
        int battlesWon,
        int noDamageWins,
        int totalBattleTurns,
        int totalPlayerTurns,
        int maxBattleTurns,
        int totalDamageTaken,
        int cardPlacementCount,
        int infiniteLoopCount,
        int reinforcementCount,
        int maxChainCount,
        string topCardId,
        int topCardCount,
        IReadOnlyList<RunDeckSnapshotEntry> finalDeck)
    {
        Result = result;
        Difficulty = RunDifficultyUtility.Normalize(difficulty);
        ActiveRunSeconds = activeRunSeconds;
        CurrentSessionSeconds = currentSessionSeconds;
        BattlesStarted = battlesStarted;
        BattlesCompleted = battlesCompleted;
        BattlesWon = battlesWon;
        NoDamageWins = noDamageWins;
        TotalBattleTurns = totalBattleTurns;
        TotalPlayerTurns = totalPlayerTurns;
        MaxBattleTurns = maxBattleTurns;
        TotalDamageTaken = totalDamageTaken;
        CardPlacementCount = cardPlacementCount;
        InfiniteLoopCount = infiniteLoopCount;
        ReinforcementCount = reinforcementCount;
        MaxChainCount = maxChainCount;
        TopCardId = topCardId ?? string.Empty;
        TopCardCount = topCardCount;
        FinalDeck = finalDeck ?? Array.Empty<RunDeckSnapshotEntry>();
    }
}

public sealed class RunDeckSnapshotEntry
{
    public int EntryId { get; }
    public string CardId { get; }
    public bool HasArrowDirection { get; }
    public ECardDirection ArrowDirection { get; }

    public RunDeckSnapshotEntry(int entryId, string cardId, bool hasArrowDirection, ECardDirection arrowDirection)
    {
        EntryId = entryId;
        CardId = cardId;
        HasArrowDirection = hasArrowDirection;
        ArrowDirection = arrowDirection;
    }

    public RunDeckEntry ToRunDeckEntry()
    {
        var entry = new RunDeckEntry(EntryId, CardId);
        if (HasArrowDirection)
            entry.SetInitialArrowDirection(ArrowDirection);
        return entry;
    }
}
