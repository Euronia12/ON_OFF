// =================================================================
// [스크립트 목적]  런(run) 단위 상태 변화에 대한 EventManager 이벤트 struct 정의.
//                 발행자(InGameController)와 구독자(HUD·상점·유물 등 타 시스템)를
//                 느슨하게 결합한다 (MapEvents 와 동일한 협업 경계 패턴).
// [사용 예시]      EventManager.Instance.Publish(new OnGoldChanged { Current = gold, Delta = +amount });
// [의존 관계]      InGameController(발행) / UIHud·상점·이벤트·유물 시스템(구독, 타 담당자)
// [설계 노트]      - 골드는 RunContext 가 데이터로 보유하지만, "변동 통지"는 전역 PubSub 로 흘린다.
//                    이유: HUD 는 RunContext(런마다 생성·폐기)보다 오래 살고 직접 참조하지 않으며,
//                    골드 소비자가 HUD 외에도(상점·유물) 늘어나는 "타 담당자" 영역이기 때문.
//                  - EventManager 제약상 이벤트는 struct 여야 한다 (where T : struct).
//                  - 발행은 RunContext 가 아니라 InGameController 가 한다 (POCO 순수성 유지).
// =================================================================

/// <summary>
/// 런 골드 보유량이 변했을 때 발행. HUD 가 구독해 표시를 갱신하고,
/// 유물·이벤트 등 타 시스템이 "골드 획득/소모 시" 반응하는 데 사용한다.
/// </summary>
public struct OnGoldChanged
{
    /// <summary>변동 후 현재 보유 골드.</summary>
    public int Current;

    /// <summary>이번 변동량 (획득 +, 소모 -). 0 은 발행하지 않는 것이 일반적.</summary>
    public int Delta;
}

/// <summary>
/// 플레이어 체력(현재/최대)이 변했을 때 발행. 상단 정보바(UINoticeTopInfo)가 구독해 게이지를 갱신한다.
/// 발행처는 두 곳이며, 두 경로 모두 이 이벤트 하나로 합류한다:
///   (a) 전투 밖 — InGameController 가 RunContext.OnHpChanged 를 중계 (휴식·선택 이벤트·비용 지불 등)
///   (b) 전투 중 — BattleController 가 PlayerActor.OnHpChanged 를 중계 (피격·회복 실시간)
/// </summary>
public struct OnPlayerHpChanged
{
    /// <summary>변동 후 현재 체력.</summary>
    public int Current;

    /// <summary>변동 후 최대 체력.</summary>
    public int Max;
}