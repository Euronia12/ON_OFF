public static class RunLaunchOptions
{
    public static bool ContinueSavedRun { get; private set; }
    public static ERunDifficulty NewRunDifficulty { get; private set; } = ERunDifficulty.Normal;
    private static bool _firstLaunchTutorialRequested;

    public static void RequestContinueSavedRun()
    {
        ContinueSavedRun = true;
        _firstLaunchTutorialRequested = false;
    }

    public static void RequestNewRun(ERunDifficulty difficulty = ERunDifficulty.Normal)
    {
        ContinueSavedRun = false;
        _firstLaunchTutorialRequested = false;
        NewRunDifficulty = RunDifficultyUtility.Normalize(difficulty);
    }

    /// <summary>최초 실행에서 자동 진입한 튜토리얼임을 다음 런 시작에 전달한다.</summary>
    public static void RequestFirstLaunchTutorial()
    {
        ContinueSavedRun = false;
        _firstLaunchTutorialRequested = true;
    }

    /// <summary>최초 자동 튜토리얼 요청을 한 번만 소비한다.</summary>
    public static bool ConsumeFirstLaunchTutorial()
    {
        bool value = _firstLaunchTutorialRequested;
        _firstLaunchTutorialRequested = false;
        return value;
    }

    public static bool ConsumeContinueSavedRun()
    {
        bool value = ContinueSavedRun;
        ContinueSavedRun = false;
        return value;
    }

    public static ERunDifficulty ConsumeNewRunDifficulty()
    {
        ERunDifficulty value = NewRunDifficulty;
        NewRunDifficulty = ERunDifficulty.Normal;
        return value;
    }
}

public static class RunDifficultyUtility
{
    public static ERunDifficulty Normalize(ERunDifficulty difficulty)
    {
        return difficulty >= ERunDifficulty.Normal && difficulty <= ERunDifficulty.Hell
            ? difficulty
            : ERunDifficulty.Normal;
    }

    public static string ToLogValue(ERunDifficulty difficulty)
    {
        switch (Normalize(difficulty))
        {
            case ERunDifficulty.Hard: return "hard";
            case ERunDifficulty.Hell: return "hell";
            default: return "normal";
        }
    }
}
