// =================================================================
// [스크립트 목적]  마지막 보스 격파 후 패럴랙스 루프와 캐릭터 퇴장을 재생한다.
// [주요 변수]      - _backgroundScroller : 다중 레이어 순환 패럴랙스 배경
//                  - _playerPrefab : 승리/걷기 애니메이션을 재사용할 플레이어 프리팹
// [의존 관계]      - BattleBackgroundParallaxScroller / Player / PlayerView / Camera / UniTask
// =================================================================

using System.Threading;
using Cysharp.Threading.Tasks;
using UnityEngine;

/// <summary>런 클리어 전용 월드 패럴랙스 루프를 소유하는 프리팹 컴포넌트.</summary>
public sealed class RunClearSequence : MonoBehaviour
{
    [Header("컷씬 루트")]
    [Tooltip("전용 배경과 캐릭터를 포함하는 컷씬 루트")]
    [SerializeField] private GameObject _cutsceneRoot;

    [Header("배경 구도")]
    [Tooltip("카메라 기준으로 배치할 ClearBg 루트. 비우면 하위 패럴랙스 컴포넌트의 Transform을 사용")]
    [SerializeField] private Transform _backgroundRoot;

    [Tooltip("카메라 중심을 기준으로 적용할 배경 위치 오프셋(월드 단위)")]
    [SerializeField] private Vector3 _backgroundCameraOffset = new Vector3(0f, -1f, 0f);

    [Tooltip("배경 종횡비를 유지하는 균일 배율")]
    [Min(0.01f)]
    [SerializeField] private float _backgroundUniformScale = 1f;

    [Header("캐릭터")]
    [Tooltip("컷씬에서 복제할 공용 플레이어 프리팹")]
    [SerializeField] private Player _playerPrefab;

    [Tooltip("캐릭터 중앙 배치 기준점")]
    [SerializeField] private Transform _playerAnchor;

    [Tooltip("걷기 시작 시 SpriteRenderer를 좌측 방향으로 반전할지 여부")]
    [SerializeField] private bool _flipForExit = true;

    [Header("이동 연출")]
    [Tooltip("걷기 시작 후 캐릭터 퇴장 전까지 배경만 먼저 스크롤하는 시간(초)")]
    [Min(0f)]
    [SerializeField] private float _backgroundLeadDuration = 1f;

    [Tooltip("캐릭터가 화면 왼쪽으로 퇴장하는 속도(월드 단위/초)")]
    [Min(0.01f)]
    [SerializeField] private float _playerExitSpeed = 4f;

    [Tooltip("카메라 또는 Renderer가 없을 때 사용할 캐릭터 퇴장 시간(초)")]
    [Min(0f)]
    [SerializeField] private float _fallbackExitDuration = 3f;

    private Camera _camera;
    private BattleBackgroundParallaxScroller _backgroundScroller;
    private Player _playerInstance;
    private PlayerView _playerView;
    private SpriteRenderer _playerRenderer;

    private void Awake()
    {
        SetInitialState();
    }

    /// <summary>흰색 페이드 뒤에 보일 컷씬 배경과 캐릭터를 준비한다.</summary>
    public void PrepareLoop(Camera targetCamera)
    {
        _camera = targetCamera;

        if (_cutsceneRoot != null)
            _cutsceneRoot.SetActive(true);

        PositionCutsceneAtCamera();
        PrepareBackground();
        CreatePlayer();
    }

    /// <summary>승리 1회 → 걷기/Flip → 패럴랙스 시작 → 캐릭터 좌측 퇴장을 재생한다.</summary>
    public async UniTask PlayLoopAsync(CancellationToken token)
    {
        try
        {
            if (_playerView != null)
                await _playerView.PlayVictoryAnimationAsync(token);

            if (_playerView != null)
            {
                _playerView.SetFlipX(_flipForExit);
                _playerView.PlayWalkAnimation();
            }

            if (_backgroundScroller != null)
                _backgroundScroller.Resume();

            if (_backgroundScroller != null && _backgroundLeadDuration > 0f)
            {
                await UniTask.Delay(
                    System.TimeSpan.FromSeconds(_backgroundLeadDuration),
                    DelayType.UnscaledDeltaTime,
                    cancellationToken: token);
            }

            await MovePlayerOffscreenAsync(token);
        }
        finally
        {
            if (_backgroundScroller != null)
                _backgroundScroller.Stop();
        }
    }

    private void SetInitialState()
    {
        if (_cutsceneRoot != null)
            _cutsceneRoot.SetActive(false);
    }

    private void PositionCutsceneAtCamera()
    {
        if (_camera == null || _cutsceneRoot == null) return;

        Transform root = _cutsceneRoot.transform;
        Vector3 cameraPosition = _camera.transform.position;
        root.position = new Vector3(cameraPosition.x, cameraPosition.y, root.position.z);
    }

    private void PrepareBackground()
    {
        if (_cutsceneRoot == null) return;

        if (_backgroundScroller == null)
        {
            _backgroundScroller = _cutsceneRoot
                .GetComponentInChildren<BattleBackgroundParallaxScroller>(includeInactive: true);
        }

        if (_backgroundScroller == null)
        {
            Debug.LogWarning("[RunClearSequence] 패럴랙스 배경을 찾지 못해 배경 이동 없이 진행합니다.");
            return;
        }

        if (_backgroundRoot == null)
            _backgroundRoot = _backgroundScroller.transform;

        if (_backgroundRoot != null && _camera != null)
        {
            Vector3 cameraPosition = _camera.transform.position;
            _backgroundRoot.position = new Vector3(
                cameraPosition.x + _backgroundCameraOffset.x,
                cameraPosition.y + _backgroundCameraOffset.y,
                _backgroundCameraOffset.z);

            float scale = Mathf.Max(0.01f, _backgroundUniformScale);
            _backgroundRoot.localScale = new Vector3(scale, scale, scale);
        }

        // 플레이어가 왼쪽으로 퇴장하므로 배경은 반대 방향인 오른쪽으로 순환한다.
        _backgroundScroller.Configure(_camera, moveRight: true, useUnscaledTime: true);
        _backgroundScroller.Stop();
    }

    private void CreatePlayer()
    {
        if (_playerPrefab == null || _playerInstance != null) return;

        Transform parent = _playerAnchor != null ? _playerAnchor : transform;
        _playerInstance = Instantiate(_playerPrefab, parent);
        _playerInstance.transform.localPosition = Vector3.zero;
        _playerInstance.transform.localRotation = Quaternion.identity;
        _playerView = _playerInstance.View;
        _playerRenderer = _playerInstance.GetComponentInChildren<SpriteRenderer>(includeInactive: true);
    }

    private async UniTask MovePlayerOffscreenAsync(CancellationToken token)
    {
        if (_playerInstance == null) return;

        float elapsed = 0f;
        while (!HasPlayerExitedLeft())
        {
            token.ThrowIfCancellationRequested();
            float delta = Time.unscaledDeltaTime;
            elapsed += delta;
            _playerInstance.transform.position += Vector3.left * (_playerExitSpeed * delta);

            if ((_camera == null || _playerRenderer == null) && elapsed >= _fallbackExitDuration)
                break;

            await UniTask.Yield(PlayerLoopTiming.Update, token);
        }
    }

    private bool HasPlayerExitedLeft()
    {
        if (_camera == null || _playerRenderer == null) return false;

        float leftEdge = _camera.ViewportToWorldPoint(new Vector3(0f, 0.5f, 0f)).x;
        return _playerRenderer.bounds.max.x < leftEdge;
    }
}
