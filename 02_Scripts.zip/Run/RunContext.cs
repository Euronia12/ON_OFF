// =================================================================
// [스크립트 목적]  한 판(run)의 전역 상태 보관 (POCO). 시드·현재 층·누적 덱을 들고
//                 전투 간 유지되는 정보를 한 곳에 모은다 (슬더스식 런 컨텍스트).
// [주요 변수]      - Seed         : 런 재현용 시드 (고정 입력 → 동일 런)
//                  - CurrentFloor : 현재 층 (1-based, 전투 클리어 시 증가)
//                  - DeckCardIds  : 누적 덱 (카드 SO ID 목록). 보상으로 늘어남
//                  - Gold         : 런 단위 화폐 (전투 보상으로 획득, 상점에서 소모). 런 종료 시 폐기.
//                                   ★ 데이터만 보유 — 변동 통지는 InGameController 가 EventManager 로 발행
//                  - MaxHp/CurrentHp : 런 단위 체력 (전투 간 유지). 전투 시작 HP·종료 생존 HP·휴식 회복 대상
//                  - Rng          : 시드 파생 난수 (절차 생성·셔플 공용)
//                  - Map          : 이번 런의 노드맵 그래프 (생성 후 보관)
//                  - CurrentNodeId: 현재 위치한 노드 ID (-1 = 아직 진입 전)
// [의존 관계]      - InGameController 가 생성·소유, BattleController/EncounterAssigner 가 참조
// [설계 노트]      - 덱은 "런 내내 유지"(슬더스) → 카드 추가/제거는 여기서만.
//                    핸드/묘지는 전투 단위(DeckSystem)라 여기 없음.
//                  - 덱을 Card 인스턴스가 아닌 SO ID 로 들고, 전투 시작마다 CardFactory 로
//                    새 Card 를 만든다 → 전투 간 런타임 상태(강화/스탯) 오염 없음.
//                  - 시드 1개에서 System.Random 을 파생해 셔플·보상 추첨에 공용 사용.
//                    (노드별 적 배정은 EncounterAssigner 가 시드+노드ID 해시로 별도 수행)
//                  - 노드맵: 현재 노드의 depth 와 CurrentFloor 가 항상 같이 움직인다.
//                    MoveToNode 가 노드 이동과 AdvanceFloor 를 함께 처리해 둘을 동기화.
//                  - HP: 슬더스식 — 전투에서 깎인 HP 가 다음 전투로 이어지고, 휴식/효과로 회복.
//                    데이터만 보유(변동 통지 없음) — HP UI 는 전투 중 PlayerActor 이벤트로 갱신.
// =================================================================

using System;
using System.Collections.Generic;
using UnityEngine;

public sealed class RunDeckEntry
{
    public int EntryId { get; }
    public string CardId { get; }
    public bool HasArrowDirection { get; private set; }
    public ECardDirection ArrowDirection { get; private set; }
    public CardRuntimeData RuntimeData { get; private set; }

    public RunDeckEntry(int entryId, string cardId)
    {
        EntryId = entryId;
        CardId = cardId;
    }

    public void SetInitialArrowDirection(ECardDirection direction)
    {
        if (HasArrowDirection) return;
        ArrowDirection = direction;
        HasArrowDirection = true;
        PublishShardArrowState();
    }

    public void SetRuntimeData(CardRuntimeData runtimeData)
    {
        if (RuntimeData == null)
        {
            RuntimeData = runtimeData;
            // 저장에서 방향이 먼저 복원된 엔트리는 런타임 데이터가 연결되는 이 시점에 판정한다.
            PublishShardArrowState();
        }
    }

    /// <summary>
    /// 방향이 아직 확정되지 않았고 RuntimeData 가 있으면, 그 자리에서 1회 굴려 확정한다.
    /// DataManager 로드 타이밍과 무관하게 멱등으로 동작한다(이미 확정이면 즉시 반환).
    /// 방향 결정 규칙(Fixed/Random/Weighted)은 CardFactory.Create → CardArrowState.Resolve 를 재사용.
    /// </summary>
    /// <returns>이 호출로 새로 확정했으면 true.</returns>
    public bool EnsureArrowResolved()
    {
        if (HasArrowDirection) return false;
        if (RuntimeData == null) return false;

        Card temp = CardFactory.Create(RuntimeData); // 내부에서 Resolve() 1회 수행
        if (temp == null) return false;

        ArrowDirection = temp.Arrow != null ? temp.Arrow.Current : ECardDirection.None;
        HasArrowDirection = true;
        PublishShardArrowState();
        return true;
    }

    public bool TryAddArrow(ECardDirection direction)
    {
        if (!CanAddArrow(direction)) return false;

        ArrowDirection |= direction;
        HasArrowDirection = true;
        PublishShardArrowState();
        return true;
    }

    public bool CanAddArrow(ECardDirection direction)
    {
        bool isCardinal = direction == ECardDirection.Up ||
                          direction == ECardDirection.Down ||
                          direction == ECardDirection.Left ||
                          direction == ECardDirection.Right;
        return isCardinal && (ArrowDirection & direction) == 0;
    }

    public bool TryRemoveArrow(ECardDirection direction)
    {
        if (!CanRemoveArrow(direction)) return false;
        ArrowDirection &= ~direction;
        return true;
    }

    public bool CanRemoveArrow(ECardDirection direction)
    {
        bool isCardinal = direction == ECardDirection.Up ||
                          direction == ECardDirection.Down ||
                          direction == ECardDirection.Left ||
                          direction == ECardDirection.Right;
        return isCardinal && (ArrowDirection & direction) != 0;
    }

    public bool TryReplaceArrow(ECardDirection remove, ECardDirection add)
    {
        if (remove == add || !CanRemoveArrow(remove) || !CanAddArrow(add)) return false;
        ArrowDirection = (ArrowDirection & ~remove) | add;
        PublishShardArrowState();
        return true;
    }

    /// <summary>
    /// 파편화살 패턴 카드의 현재 방향 상태를 업적 브릿지에 알린다.
    /// 최초 획득·상점·이벤트·휴식 강화 등 런 덱에서 일어나는 모든 방향 변경 경로가 이 메서드로 모인다.
    /// </summary>
    private void PublishShardArrowState()
    {
        if (!HasArrowDirection ||
            RuntimeData == null ||
            RuntimeData.PatternType != EChainPatternType.ShotgunForward2 ||
            !EventManager.HasInstance)
        {
            return;
        }

        EventManager.Instance.Publish(new ShardArrowSignal(ArrowDirection));
    }
}

public sealed class RunCardPersistentState
{
    private readonly Dictionary<string, int> _intValues = new Dictionary<string, int>();

    public void SetInt(string key, int value)
    {
        if (string.IsNullOrEmpty(key)) return;
        if (value == 0)
        {
            _intValues.Remove(key);
            return;
        }
        _intValues[key] = value;
    }

    public bool TryGetInt(string key, out int value)
    {
        value = 0;
        return !string.IsNullOrEmpty(key) && _intValues.TryGetValue(key, out value);
    }

    public void Clear()
    {
        _intValues.Clear();
    }

    public bool IsEmpty => _intValues.Count == 0;
}

/// <summary>
/// 한 판(run)의 전역 상태. 시드, 현재 층, 누적 덱(SO ID), 런 체력을 보관한다.
/// 전투는 매번 새로 시작(핸드·묘지 리셋)하지만, 덱·층·체력 진행은 이 컨텍스트로 이어진다.
/// 덱을 카드 ID 로 보관해 전투마다 깨끗한 Card 인스턴스를 재생성한다 (상태 오염 방지).
/// </summary>
public sealed class RunContext
{
    /// <summary>런 재현용 시드. 동일 시드 + 동일 선택 = 동일 런.</summary>
    public int Seed { get; }

    /// <summary>시드에서 파생된 난수 (층 적 선택·셔플 공용). 런 내내 같은 인스턴스 사용.</summary>
    public System.Random Rng { get; }

    /// <summary>이번 런에서 선택한 시작 덱 타입. 획득 가능 카드 풀 필터의 기준이다.</summary>
    public EStartingDeck SelectedDeckType { get; }

    /// <summary>이번 런에서 선택한 난이도. 저장·데이터·전투 규칙의 공통 기준이다.</summary>
    public ERunDifficulty Difficulty { get; }

    /// <summary>현재 층 (1-based). 전투 승리 시 InGameController 가 증가시킨다.</summary>
    public int CurrentFloor { get; private set; }

    /// <summary>
    /// 이번 런의 노드맵 그래프. GenerateMap 호출 전엔 null.
    /// 노드의 depth 와 CurrentFloor 는 항상 동기화된다(MoveToNode 가 함께 갱신).
    /// </summary>
    public MapGraph Map { get; private set; }

    /// <summary>현재 위치한 노드 ID. 아직 맵에 진입하지 않았으면 -1.</summary>
    public int CurrentNodeId { get; private set; } = NoNode;

    /// <summary>"노드 미진입" 상태를 나타내는 센티넬 값.</summary>
    public const int NoNode = -1;

    // -------------------------------------------------
    // 보상 대기 (전투 승리 후 보상 미수령 재개용)
    // -------------------------------------------------

    /// <summary>보상 수령 대기 중인 노드 ID. 대기 없으면 NoNode. 이어하기 시 보상창 재개 판단에 쓰인다.</summary>
    public int RewardPendingNodeId { get; private set; } = NoNode;

    /// <summary>대기 보상의 골드 수령 완료 여부(중복 지급 방지).</summary>
    public bool RewardGoldClaimed { get; private set; }

    /// <summary>대기 보상의 카드 선택 완료 여부(중복 획득 방지).</summary>
    public bool RewardCardChosen { get; private set; }

    /// <summary>현재 대기 보상에 적용한 QA 재추첨 횟수. 이어하기 재현용으로 저장한다.</summary>
    public int DebugRewardRerollCount { get; private set; }

    /// <summary>보상 수령 대기 상태 여부.</summary>
    public bool HasPendingReward => RewardPendingNodeId != NoNode;

    /// <summary>전투 승리 직후 보상 대기 시작(수령 플래그 초기화).</summary>
    public void BeginPendingReward(int nodeId)
    {
        RewardPendingNodeId = nodeId;
        RewardGoldClaimed = false;
        RewardCardChosen = false;
        DebugRewardRerollCount = 0;
    }

    public void MarkRewardGoldClaimed() => RewardGoldClaimed = true;
    public void MarkRewardCardChosen() => RewardCardChosen = true;
    public void AdvanceDebugRewardReroll() => DebugRewardRerollCount++;

    /// <summary>보상 수령/진행 완료로 대기 해제.</summary>
    public void ClearPendingReward()
    {
        RewardPendingNodeId = NoNode;
        RewardGoldClaimed = false;
        RewardCardChosen = false;
        DebugRewardRerollCount = 0;
    }

    // 누적 덱 — 카드 SO ID 목록. 보상 획득 시 추가, (추후) 제거 효과 시 삭제.
    private readonly List<string> _deckCardIds = new List<string>(32);
    private readonly List<RunDeckEntry> _deckEntries = new List<RunDeckEntry>(32);
    public RunStatisticsState Statistics { get; } = new RunStatisticsState();
    private readonly List<CardDataSO> _availableCardPool = new List<CardDataSO>(128);
    private readonly Dictionary<int, RunCardPersistentState> _persistentCardStates =
        new Dictionary<int, RunCardPersistentState>();
    private readonly Dictionary<int, RunSaveShopState> _shopStates =
        new Dictionary<int, RunSaveShopState>();
    private readonly Dictionary<long, RunSaveRestChoice> _restChoices =
        new Dictionary<long, RunSaveRestChoice>();
    private readonly HashSet<string> _encounteredEventIds = new HashSet<string>(System.StringComparer.Ordinal);
    // 영속 상태 정리용 임시 버퍼 (GC 회피 — 매 복원마다 재할당하지 않는다).
    private readonly List<int> _persistentStateScratch = new List<int>();
    private readonly Dictionary<int, string> _eventAssignments =
        new Dictionary<int, string>();
    // 이벤트에서 실제로 고른 선택지(EventId → 0-based 선택지 인덱스). 연쇄 이벤트 선행 조건 판정용.
    private readonly Dictionary<string, int> _eventChoices =
        new Dictionary<string, int>(System.StringComparer.Ordinal);
    // 카드별 영구 코스트 보정(런 덱 엔트리 ID → 증감량). 0 은 저장하지 않는다.
    private readonly Dictionary<int, int> _cardCostDeltas = new Dictionary<int, int>();
    // 스킬별 영구 쿨타임 보정(SkillId → 증감량). 0 은 저장하지 않는다.
    private readonly Dictionary<string, int> _skillCooldownDeltas =
        new Dictionary<string, int>(System.StringComparer.Ordinal);
    // 전투 사이에 유지할 스킬별 남은 쿨타임(SkillId → 남은 턴). 영구 보정과 별도 상태다.
    private readonly Dictionary<string, int> _skillCooldowns =
        new Dictionary<string, int>(System.StringComparer.Ordinal);
    public int PendingEventNodeId { get; private set; } = NoNode;
    public string PendingEventId { get; private set; } = string.Empty;
    public RunSavePendingEventProgress PendingEventProgress { get; private set; }
    private int _nextDeckEntryId = 1;

    /// <summary>누적 덱의 카드 SO ID 목록 (읽기 전용).</summary>
    public IReadOnlyList<string> DeckCardIds => _deckCardIds;
    public IReadOnlyList<RunDeckEntry> DeckEntries => _deckEntries;
    public IReadOnlyList<CardDataSO> AvailableCardPool => _availableCardPool;
    public IReadOnlyCollection<string> EncounteredEventIds => _encounteredEventIds;

    /// <summary>
    /// 런 단위 화폐(골드). 전투 보상·이벤트로 획득하고 상점에서 소모한다.
    /// 슬더스식 — 런이 끝나면(승리/패배) 폐기된다(영구 화폐는 별도 UserData 도메인).
    /// 직접 대입 불가. 변경은 AddGold/SpendGold 로만 한다.
    /// ★ 변동 통지는 RunContext 가 하지 않는다 — POCO 순수성 유지(매니저 의존 없음).
    ///   골드 변동 브로드캐스트는 InGameController 가 EventManager 로 발행한다(OnGoldChanged).
    /// </summary>
    public int Gold { get; private set; }

    /// <summary>런 단위 최대 체력. 런 시작 시 설정, (추후) 영구 강화로 증가 가능.</summary>
    public int MaxHp { get; private set; }

    /// <summary>
    /// 런 단위 현재 체력. 전투 시작 시 이 값으로 시작하고, 전투 종료(승리) 시 생존 HP 를 여기 저장한다.
    /// 휴식/효과로 회복한다. 슬더스식 — 전투 간 HP 가 유지된다.
    /// </summary>
    public int CurrentHp { get; private set; }

    /// <summary>HP 시스템 초기화 여부 (InitializeHp 호출 전이면 false).</summary>
    public bool HasHp => MaxHp > 0;

    /// <summary>
    /// 런 체력(현재/최대)이 변했을 때 발생 (현재 HP, 최대 HP).
    /// EventManager 를 직접 호출하지 않고 C# event 만 노출한다 — POCO 순수성 유지(매니저 의존 없음).
    /// InGameController 가 이를 구독해 OnPlayerHpChanged 로 브로드캐스트한다(골드와 동일한 경계).
    /// </summary>
    public event Action<int, int> OnHpChanged;

    /// <summary>
    /// 턴 종료 시 보존 선택 가능한 최대 카드 수 (런 단위). 런 시작 시 초기값으로 세팅되고,
    /// 런 중 카드/유물 효과로 증가할 수 있다. 다음 런에는 이어지지 않는다(새 RunContext = 새 초기값).
    /// </summary>
    public int MaxPreserveCount { get; private set; }

    /// <summary>전체 보존 모드 여부 (런 단위). true 면 턴 종료 시 그리드 카드를 전부 유지한다.</summary>
    public bool PreserveAll { get; private set; }

    /// <summary>
    /// 런 단위 최대 마나(에너지). 전투 시작 시 이 값으로 시작하고, 이벤트로 증감할 수 있다.
    /// 다음 런에는 이어지지 않는다(새 RunContext = 새 초기값).
    /// </summary>
    public int MaxMana { get; private set; }

    /// <summary>
    /// 런 단위 턴 시작 드로우 수. 전투 턴마다 이만큼 드로우하고, 이벤트로 증감할 수 있다.
    /// 하한(DrawMin) 미만으로 내려가지 않는다(0 드로우 소프트락 방지).
    /// </summary>
    public int DrawPerTurn { get; private set; }

    private const int ManaMin = 0;
    private const int DrawMin = 1;

    /// <param name="seed">런 시드. 같은 값이면 같은 절차 생성 결과.</param>
    public RunContext(
        int seed,
        EStartingDeck selectedDeckType = EStartingDeck.None,
        ERunDifficulty difficulty = ERunDifficulty.Normal)
    {
        Seed = seed;
        Rng = new System.Random(seed);
        SelectedDeckType = selectedDeckType;
        Difficulty = RunDifficultyUtility.Normalize(difficulty);
        CurrentFloor = 1;
    }

    public bool TryGetSkillCooldown(string skillId, out int remainingTurns)
    {
        remainingTurns = 0;
        return !string.IsNullOrEmpty(skillId) &&
               _skillCooldowns.TryGetValue(skillId, out remainingTurns);
    }

    public void SetSkillCooldown(string skillId, int remainingTurns)
    {
        if (string.IsNullOrEmpty(skillId)) return;
        if (remainingTurns <= 0)
        {
            _skillCooldowns.Remove(skillId);
            return;
        }

        _skillCooldowns[skillId] = remainingTurns;
    }

    public void ClearSkillCooldowns() => _skillCooldowns.Clear();

    public bool HasEncounteredEvent(string eventId)
        => !string.IsNullOrWhiteSpace(eventId) && _encounteredEventIds.Contains(eventId);

    public bool MarkEventEncountered(string eventId)
        => !string.IsNullOrWhiteSpace(eventId) && _encounteredEventIds.Add(eventId);

    public bool TryGetAssignedEvent(int nodeId, out string eventId)
    {
        eventId = null;
        return nodeId != NoNode &&
               _eventAssignments.TryGetValue(nodeId, out eventId) &&
               !string.IsNullOrWhiteSpace(eventId);
    }

    public bool AssignEvent(int nodeId, string eventId)
    {
        if (nodeId == NoNode || string.IsNullOrWhiteSpace(eventId)) return false;

        if (_eventAssignments.ContainsKey(nodeId)) return false;

        _eventAssignments.Add(nodeId, eventId);
        return true;
    }

    /// <summary>
    /// 이벤트에서 고른 선택지를 기록한다(같은 이벤트를 다시 만나면 마지막 선택으로 덮어쓴다).
    /// 연쇄 이벤트의 선행 조건은 이 기록으로만 판정한다 — HasEncounteredEvent 는
    /// "맵에 배치됨"을 뜻할 뿐이라 지나친 이벤트까지 참이 되어버린다.
    /// </summary>
    public void RecordEventChoice(string eventId, int choiceIndex)
    {
        if (string.IsNullOrWhiteSpace(eventId) || choiceIndex < 0) return;
        _eventChoices[eventId] = choiceIndex;
    }

    public bool TryGetEventChoice(string eventId, out int choiceIndex)
    {
        choiceIndex = -1;
        return !string.IsNullOrWhiteSpace(eventId) &&
               _eventChoices.TryGetValue(eventId, out choiceIndex);
    }

    /// <summary>지정 이벤트에서 해당 선택지를 골랐는지. choiceIndex 가 음수면 "선택한 사실"만 확인한다.</summary>
    public bool HasEventChoice(string eventId, int choiceIndex)
    {
        if (!TryGetEventChoice(eventId, out int recorded)) return false;
        return choiceIndex < 0 || recorded == choiceIndex;
    }

    /// <summary>카드(런 덱 엔트리)의 영구 코스트 보정값. 없으면 0.</summary>
    public int GetCardCostDelta(int entryId)
        => _cardCostDeltas.TryGetValue(entryId, out int delta) ? delta : 0;

    /// <summary>
    /// 카드의 영구 코스트 보정값을 설정한다(누적이 아니라 최종값 대입).
    /// 하한 판정에 필요한 BaseCost 를 POCO 인 RunContext 가 알 수 없으므로,
    /// 클램프는 호출부(효과 클래스)가 계산해 넘긴다.
    /// </summary>
    public void SetCardCostDelta(int entryId, int delta)
    {
        if (delta == 0) _cardCostDeltas.Remove(entryId);
        else _cardCostDeltas[entryId] = delta;
    }

    /// <summary>스킬의 영구 쿨타임 보정값. 없으면 0.</summary>
    public int GetSkillCooldownDelta(string skillId)
        => !string.IsNullOrWhiteSpace(skillId) && _skillCooldownDeltas.TryGetValue(skillId, out int delta)
            ? delta
            : 0;

    /// <summary>스킬의 영구 쿨타임 보정값을 설정한다(최종값 대입). 클램프는 호출부 책임.</summary>
    public void SetSkillCooldownDelta(string skillId, int delta)
    {
        if (string.IsNullOrWhiteSpace(skillId)) return;
        if (delta == 0) _skillCooldownDeltas.Remove(skillId);
        else _skillCooldownDeltas[skillId] = delta;
    }

    public void BeginPendingEvent(int nodeId, string eventId)
    {
        if (nodeId == NoNode || string.IsNullOrWhiteSpace(eventId)) return;
        PendingEventNodeId = nodeId;
        PendingEventId = eventId;
        if (PendingEventProgress != null &&
            (PendingEventProgress.nodeId != nodeId ||
             !string.Equals(PendingEventProgress.eventId, eventId, StringComparison.Ordinal)))
        {
            PendingEventProgress = null;
        }
    }

    public RunSavePendingEventProgress BeginEventChoiceProgress(
        int nodeId, string eventId, int choiceIndex)
    {
        if (nodeId == NoNode || string.IsNullOrWhiteSpace(eventId) || choiceIndex < 0)
            return null;

        RunSavePendingEventProgress progress = PendingEventProgress;
        if (progress == null || progress.nodeId != nodeId ||
            !string.Equals(progress.eventId, eventId, StringComparison.Ordinal) ||
            progress.choiceIndex != choiceIndex)
        {
            progress = new RunSavePendingEventProgress
            {
                nodeId = nodeId,
                eventId = eventId,
                choiceIndex = choiceIndex,
            };
            PendingEventProgress = progress;
        }
        return progress;
    }

    public RunSaveEventEffectState GetOrCreateEventEffectState(int effectIndex, string kind)
    {
        RunSavePendingEventProgress progress = PendingEventProgress;
        if (progress == null || effectIndex < 0) return null;
        progress.effects ??= new List<RunSaveEventEffectState>();

        for (int i = 0; i < progress.effects.Count; i++)
        {
            RunSaveEventEffectState state = progress.effects[i];
            if (state != null && state.effectIndex == effectIndex)
                return string.Equals(state.kind, kind, StringComparison.Ordinal) ? state : null;
        }

        var created = new RunSaveEventEffectState { effectIndex = effectIndex, kind = kind ?? string.Empty };
        progress.effects.Add(created);
        return created;
    }

    public void SetEventEffectResult(int effectIndex, ChoiceEventEffectResult value)
    {
        RunSavePendingEventProgress progress = PendingEventProgress;
        if (progress == null || effectIndex < 0) return;
        progress.results ??= new List<RunSaveEventEffectResult>();

        RunSaveEventEffectResult result = null;
        for (int i = 0; i < progress.results.Count; i++)
        {
            if (progress.results[i] == null || progress.results[i].effectIndex != effectIndex) continue;
            result = progress.results[i];
            break;
        }
        if (result == null)
        {
            result = new RunSaveEventEffectResult { effectIndex = effectIndex };
            progress.results.Add(result);
        }
        result.hasAmount = value.Amount.HasValue;
        result.amount = value.Amount.GetValueOrDefault();

        result.hasArrowAddition = value.HasArrowAddition;
        result.arrowTargetEntryId = value.ArrowTarget?.EntryId ?? 0;
        result.arrowTargetCardId = value.ArrowTarget?.CardId ?? string.Empty;
        result.arrowTargetHasDirection = value.ArrowTarget?.HasArrowDirection ?? false;
        result.arrowTargetDirection = (int)(value.ArrowTarget?.ArrowDirection ?? ECardDirection.None);
        result.addedArrowDirection = (int)value.AddedArrowDirection;

        result.cardTransforms ??= new List<RunSaveEventCardTransformResult>();
        result.cardTransforms.Clear();
        if (value.CardTransforms != null)
        {
            for (int i = 0; i < value.CardTransforms.Count; i++)
            {
                ChoiceEventCardTransformResult transform = value.CardTransforms[i];
                result.cardTransforms.Add(new RunSaveEventCardTransformResult
                {
                    sourceCardId = transform.SourceCardId,
                    sourceDirection = (int)transform.SourceDirection,
                    resultCardId = transform.ResultCardId,
                    resultDirection = (int)transform.ResultDirection,
                });
            }
        }

        result.hasCardCostChange = value.HasCardCostChange;
        ChoiceEventCardCostResult cost = value.CardCostChange;
        result.costEntryId = cost.EntryId;
        result.costCardId = cost.CardId ?? string.Empty;
        result.costCardDirection = (int)cost.Direction;
        result.costBefore = cost.BeforeCost;
        result.costAfter = cost.AfterCost;
    }

    public RunSaveEventEffectResult GetEventEffectResult(int effectIndex)
    {
        RunSavePendingEventProgress progress = PendingEventProgress;
        if (progress?.results == null) return null;
        for (int i = 0; i < progress.results.Count; i++)
        {
            RunSaveEventEffectResult result = progress.results[i];
            if (result != null && result.effectIndex == effectIndex)
                return result;
        }
        return null;
    }

    public bool TryGetPendingEvent(int nodeId, out string eventId)
    {
        eventId = PendingEventId;
        return nodeId != NoNode && PendingEventNodeId == nodeId && !string.IsNullOrWhiteSpace(eventId);
    }

    public void ClearPendingEvent(int nodeId = NoNode)
    {
        if (nodeId != NoNode && PendingEventNodeId != nodeId) return;
        PendingEventNodeId = NoNode;
        PendingEventId = string.Empty;
        PendingEventProgress = null;
    }

    public RunSaveData ToSaveData(
        int currentStageIndex,
        string selectedCharacterId = null,
        bool currentNodeResolved = true,
        bool stageTransitionPending = false)
    {
        var data = new RunSaveData
        {
            mapVersion = MapGenerator.AlgorithmVersion,
            seed = Seed,
            difficulty = (int)Difficulty,
            selectedDeckType = (int)SelectedDeckType,
            selectedCharacterId = selectedCharacterId ?? string.Empty,
            currentStageIndex = currentStageIndex,
            currentFloor = CurrentFloor,
            currentNodeId = CurrentNodeId,
            currentNodeResolved = currentNodeResolved || CurrentNodeId == NoNode,
            stageTransitionPending = stageTransitionPending,
            rewardPendingNodeId = RewardPendingNodeId,
            rewardGoldClaimed = RewardGoldClaimed,
            rewardCardChosen = RewardCardChosen,
            debugRewardRerollCount = DebugRewardRerollCount,
            pendingEventNodeId = PendingEventNodeId,
            pendingEventId = PendingEventId,
            pendingEventProgress = CloneEventProgress(PendingEventProgress),
            gold = Gold,
            maxHp = MaxHp,
            currentHp = CurrentHp,
            maxPreserveCount = MaxPreserveCount,
            preserveAll = PreserveAll,
            cardRemovalCount = CardRemovalCount,
            maxMana = MaxMana,
            drawPerTurn = DrawPerTurn,
            statistics = Statistics.ToSaveData(),
        };

        for (int i = 0; i < _deckEntries.Count; i++)
        {
            RunDeckEntry entry = _deckEntries[i];
            if (entry == null) continue;
            data.deck.Add(new RunSaveDeckEntry
            {
                entryId = entry.EntryId,
                cardId = entry.CardId,
                hasArrowDirection = entry.HasArrowDirection,
                arrowDirection = (int)entry.ArrowDirection,
            });
        }

        if (Map != null)
        {
            foreach (MapNode node in Map.Nodes)
            {
                if (node != null && node.Explored)
                    data.exploredNodeIds.Add(node.Id);
            }
        }

        foreach (string eventId in _encounteredEventIds)
        {
            if (!string.IsNullOrWhiteSpace(eventId))
                data.encounteredEventIds.Add(eventId);
        }

        foreach (KeyValuePair<int, string> pair in _eventAssignments)
        {
            data.eventAssignments.Add(new RunSaveEventAssignment
            {
                nodeId = pair.Key,
                eventId = pair.Value,
            });
        }

        foreach (KeyValuePair<string, int> pair in _eventChoices)
        {
            data.eventChoices.Add(new RunSaveEventChoice
            {
                eventId = pair.Key,
                choiceIndex = pair.Value,
            });
        }

        foreach (KeyValuePair<int, int> pair in _cardCostDeltas)
        {
            data.cardCostDeltas.Add(new RunSaveCardCostDelta
            {
                entryId = pair.Key,
                delta = pair.Value,
            });
        }

        foreach (KeyValuePair<string, int> pair in _skillCooldownDeltas)
        {
            data.skillCooldownDeltas.Add(new RunSaveSkillCooldownDelta
            {
                skillId = pair.Key,
                delta = pair.Value,
            });
        }

        foreach (RunSaveShopState shopState in _shopStates.Values)
        {
            RunSaveShopState copy = CloneShopState(shopState);
            if (copy != null)
                data.shops.Add(copy);
        }

        foreach (RunSaveRestChoice restChoice in _restChoices.Values)
        {
            RunSaveRestChoice copy = CloneRestChoice(restChoice);
            if (copy != null)
                data.restChoices.Add(copy);
        }


        foreach (KeyValuePair<string, int> pair in _skillCooldowns)
        {
            if (string.IsNullOrEmpty(pair.Key) || pair.Value <= 0) continue;
            data.skillCooldowns.Add(new RunSaveSkillCooldown
            {
                skillId = pair.Key,
                remainingTurns = pair.Value,
            });
        }

        return data;
    }

    /// <summary>
    /// 저장 데이터를 이 런 컨텍스트에 복원한다.
    /// 맵은 호출 전에 GenerateMap 으로 생성되어 있어야 하며, 저장된 노드 위치를 되살린다.
    /// </summary>
    /// <returns>
    /// 맵 위치 복원까지 정상 성공하면 true. 저장에는 특정 노드가 있었으나(진입 후)
    /// 재생성된 맵에서 그 노드를 찾지 못해 위치가 어긋난 경우(맵 알고리즘 변경 등) false.
    /// </returns>
    /// <summary>
    /// 복원된 덱에 더는 존재하지 않는 엔트리의 카드 영속 상태를 제거한다.
    /// (RestoreFromSave 가 영속 상태를 통째로 비우지 않으므로 여기서 짝을 맞춘다)
    /// </summary>
    private void PruneOrphanPersistentCardStates()
    {
        if (_persistentCardStates.Count == 0) return;

        _persistentStateScratch.Clear();
        foreach (int entryId in _persistentCardStates.Keys)
        {
            bool alive = false;
            for (int i = 0; i < _deckEntries.Count; i++)
            {
                if (_deckEntries[i] == null || _deckEntries[i].EntryId != entryId) continue;
                alive = true;
                break;
            }
            if (!alive) _persistentStateScratch.Add(entryId);
        }

        for (int i = 0; i < _persistentStateScratch.Count; i++)
            _persistentCardStates.Remove(_persistentStateScratch[i]);
        _persistentStateScratch.Clear();
    }

    public bool RestoreFromSave(RunSaveData data)
    {
        if (data == null) return false;

        _deckCardIds.Clear();
        _deckEntries.Clear();
        _nextDeckEntryId = 1;
        // ★ _persistentCardStates 는 여기서 지우지 않는다.
        // 저장 포맷에 없는 상태라 비우면 "복원"이 아니라 "소실"이 된다.
        // 로드 경로는 갓 만든 RunContext 라 어차피 비어 있고,
        // 런 도중 롤백(이벤트 효과 취소)에서 지우면 카드 누적 상태가 통째로 날아간다.
        // 덱에서 사라진 엔트리의 잔여 상태는 덱 재구성 뒤 아래에서 정리한다.

        if (data.deck != null)
        {
            for (int i = 0; i < data.deck.Count; i++)
            {
                RunSaveDeckEntry saved = data.deck[i];
                if (saved == null || string.IsNullOrEmpty(saved.cardId)) continue;

                int entryId = saved.entryId > 0 ? saved.entryId : _nextDeckEntryId;
                RunDeckEntry entry = new RunDeckEntry(entryId, saved.cardId);
                if (saved.hasArrowDirection)
                    entry.SetInitialArrowDirection((ECardDirection)saved.arrowDirection);

                _deckCardIds.Add(saved.cardId);
                _deckEntries.Add(entry);
                _nextDeckEntryId = Mathf.Max(_nextDeckEntryId, entryId + 1);
            }
        }

        PruneOrphanPersistentCardStates();

        Gold = Mathf.Max(0, data.gold);
        MaxHp = Mathf.Max(0, data.maxHp);
        // 저장된 런은 항상 "생존" 상태여야 한다(사망 시 저장이 삭제됨). currentHp 가 0 이하로 들어오면
        // 손상·변조로 간주하고 최소 1 로 보정해, HP 0 짜리 무력화된 런이 복원되는 것을 막는다.
        CurrentHp = MaxHp > 0 ? Mathf.Clamp(data.currentHp, 1, MaxHp) : 0;
        PreserveAll = data.preserveAll;
        MaxPreserveCount = Mathf.Max(0, data.maxPreserveCount);
        CardRemovalCount = Mathf.Max(0, data.cardRemovalCount);
        // 마나·드로우: 구버전 세이브는 0 으로 들어온다. 여기서는 값만 복원하고,
        // 0 이하(구버전·손상)면 InGameController 가 인스펙터 초기치로 폴백 초기화한다.
        MaxMana = Mathf.Max(0, data.maxMana);
        DrawPerTurn = Mathf.Max(0, data.drawPerTurn);
        Statistics.Restore(data.statistics);

        RewardPendingNodeId = data.rewardPendingNodeId;
        RewardGoldClaimed = data.rewardGoldClaimed;
        RewardCardChosen = data.rewardCardChosen;
        DebugRewardRerollCount = Mathf.Max(0, data.debugRewardRerollCount);
        PendingEventNodeId = data.pendingEventNodeId;
        PendingEventId = data.pendingEventId ?? string.Empty;
        PendingEventProgress = CloneEventProgress(data.pendingEventProgress);
        if (PendingEventNodeId == NoNode || string.IsNullOrWhiteSpace(PendingEventId))
            ClearPendingEvent();
        else if (PendingEventProgress != null &&
                 (PendingEventProgress.nodeId != PendingEventNodeId ||
                  !string.Equals(PendingEventProgress.eventId, PendingEventId, StringComparison.Ordinal)))
            PendingEventProgress = null;

        _encounteredEventIds.Clear();
        if (data.encounteredEventIds != null)
        {
            for (int i = 0; i < data.encounteredEventIds.Count; i++)
                MarkEventEncountered(data.encounteredEventIds[i]);
        }


        _eventAssignments.Clear();
        if (data.eventAssignments != null)
        {
            for (int i = 0; i < data.eventAssignments.Count; i++)
            {
                RunSaveEventAssignment assignment = data.eventAssignments[i];
                if (assignment == null) continue;
                AssignEvent(assignment.nodeId, assignment.eventId);
            }
        }

        // 아래 3종은 반드시 Clear + 재적용이어야 한다. RestoreFromSave 는 로드뿐 아니라
        // 이벤트 효과 취소 롤백(InGameController 의 스냅샷 복원)에도 쓰이므로,
        // 지우지 않으면 취소한 선택·보정이 남는다.
        _eventChoices.Clear();
        if (data.eventChoices != null)
        {
            for (int i = 0; i < data.eventChoices.Count; i++)
            {
                RunSaveEventChoice choice = data.eventChoices[i];
                if (choice == null) continue;
                RecordEventChoice(choice.eventId, choice.choiceIndex);
            }
        }

        _cardCostDeltas.Clear();
        if (data.cardCostDeltas != null)
        {
            for (int i = 0; i < data.cardCostDeltas.Count; i++)
            {
                RunSaveCardCostDelta costDelta = data.cardCostDeltas[i];
                if (costDelta == null) continue;
                SetCardCostDelta(costDelta.entryId, costDelta.delta);
            }
        }

        _skillCooldownDeltas.Clear();
        if (data.skillCooldownDeltas != null)
        {
            for (int i = 0; i < data.skillCooldownDeltas.Count; i++)
            {
                RunSaveSkillCooldownDelta cooldownDelta = data.skillCooldownDeltas[i];
                if (cooldownDelta == null) continue;
                SetSkillCooldownDelta(cooldownDelta.skillId, cooldownDelta.delta);
            }
        }

        _shopStates.Clear();
        if (data.shops != null)
        {
            for (int i = 0; i < data.shops.Count; i++)
            {
                RunSaveShopState shopState = CloneShopState(data.shops[i]);
                if (shopState != null && shopState.nodeId != NoNode)
                    _shopStates[shopState.nodeId] = shopState;
            }
        }

        _restChoices.Clear();
        if (data.restChoices != null)
        {
            for (int i = 0; i < data.restChoices.Count; i++)
            {
                RunSaveRestChoice restChoice = CloneRestChoice(data.restChoices[i]);
                if (restChoice != null)
                    _restChoices[GetRestChoiceKey(restChoice.stageIndex, restChoice.nodeId)] = restChoice;
            }
        }


        _skillCooldowns.Clear();
        if (data.skillCooldowns != null)
        {
            for (int i = 0; i < data.skillCooldowns.Count; i++)
            {
                RunSaveSkillCooldown cooldown = data.skillCooldowns[i];
                if (cooldown == null) continue;
                SetSkillCooldown(cooldown.skillId, Mathf.Max(0, cooldown.remainingTurns));
            }
        }

        // 세이브 로드 직후 HP 를 1회 통지 — 구독자가 이미 붙어 있다면 상단바가 즉시 동기화된다.
        NotifyHpChanged();

        // 보스 보상 완료 직후의 체크포인트는 다음 스테이지의 맵으로 이미 재생성돼 있다.
        // 이전 보스 노드의 위치/탐험 기록을 적용하지 않고 새 맵의 1층에서 시작한다.
        if (data.stageTransitionPending)
        {
            CurrentNodeId = NoNode;
            CurrentFloor = 1;
            return true;
        }

        return RestoreMapProgress(data.currentNodeId, data.exploredNodeIds, data.currentNodeResolved);
    }

    public bool TryGetRestChoice(int stageIndex, int nodeId, out bool isReinforce)
    {
        isReinforce = false;
        if (stageIndex < 0 || nodeId == NoNode) return false;
        if (!_restChoices.TryGetValue(GetRestChoiceKey(stageIndex, nodeId), out RunSaveRestChoice choice)) return false;

        isReinforce = choice.isReinforce;
        return true;
    }

    public void SetRestChoice(int stageIndex, int nodeId, bool isReinforce)
    {
        if (stageIndex < 0 || nodeId == NoNode) return;

        _restChoices[GetRestChoiceKey(stageIndex, nodeId)] = new RunSaveRestChoice
        {
            stageIndex = stageIndex,
            nodeId = nodeId,
            isReinforce = isReinforce,
        };
    }

    public bool TryGetShopState(int nodeId, out RunSaveShopState state)
    {
        state = null;
        if (nodeId == NoNode) return false;
        if (!_shopStates.TryGetValue(nodeId, out RunSaveShopState stored)) return false;

        state = CloneShopState(stored);
        return state != null;
    }

    public void SetShopState(RunSaveShopState state)
    {
        RunSaveShopState copy = CloneShopState(state);
        if (copy == null || copy.nodeId == NoNode) return;
        _shopStates[copy.nodeId] = copy;
    }

    public void RemoveShopState(int nodeId)
    {
        if (nodeId == NoNode) return;
        _shopStates.Remove(nodeId);
    }

    private static RunSaveShopState CloneShopState(RunSaveShopState source)
    {
        if (source == null) return null;

        var copy = new RunSaveShopState
        {
            nodeId = source.nodeId,
            cardRemovalCost = source.cardRemovalCost,
        };

        if (source.cards != null)
        {
            for (int i = 0; i < source.cards.Count; i++)
            {
                RunSaveShopCardEntry card = source.cards[i];
                if (card == null || string.IsNullOrEmpty(card.cardId)) continue;

                copy.cards.Add(new RunSaveShopCardEntry
                {
                    cardId = card.cardId,
                    price = card.price,
                    arrowDirection = card.arrowDirection,
                    purchased = card.purchased,
                });
            }
        }

        return copy;
    }

    private static RunSaveRestChoice CloneRestChoice(RunSaveRestChoice source)
    {
        if (source == null || source.stageIndex < 0 || source.nodeId == NoNode) return null;

        return new RunSaveRestChoice
        {
            stageIndex = source.stageIndex,
            nodeId = source.nodeId,
            isReinforce = source.isReinforce,
        };
    }

    private static long GetRestChoiceKey(int stageIndex, int nodeId)
    {
        return GetStageNodeKey(stageIndex, nodeId);
    }

    private static long GetStageNodeKey(int stageIndex, int nodeId)
        => ((long)stageIndex << 32) | (uint)nodeId;

    /// <returns>
    /// 저장된 현재 노드(NoNode 가 아닌 값)를 맵에서 찾아 복원했으면 true.
    /// 저장이 아직 노드 미진입(NoNode)이면 위치 어긋남이 없으므로 true.
    /// 노드가 있었으나 재생성 맵에서 찾지 못했으면(위치 유실) false.
    /// </returns>
    public bool RestoreMapProgress(
        int currentNodeId,
        IEnumerable<int> exploredNodeIds,
        bool currentNodeResolved = false)
    {
        if (Map == null) return false;

        foreach (MapNode node in Map.Nodes)
        {
            if (node != null) node.Explored = false;
        }

        if (exploredNodeIds != null)
        {
            foreach (int nodeId in exploredNodeIds)
            {
                MapNode explored = Map.GetNode(nodeId);
                if (explored != null) explored.Explored = true;
            }
        }

        MapNode current = Map.GetNode(currentNodeId);
        CurrentNodeId = current != null ? current.Id : NoNode;
        CurrentFloor = current != null ? current.Depth : Mathf.Max(1, CurrentFloor);
        if (current != null && currentNodeResolved)
            current.Explored = true;

        // 저장이 노드 진입 상태였는데(NoNode 아님) 맵에서 못 찾았으면 위치 유실.
        return currentNodeId == NoNode || current != null;
    }

    public bool IsCurrentNodeExplored()
    {
        MapNode current = Map != null ? Map.GetNode(CurrentNodeId) : null;
        return current != null && current.Explored;
    }

    public void MarkCurrentNodeExplored()
    {
        MapNode current = Map != null ? Map.GetNode(CurrentNodeId) : null;
        if (current != null)
            current.Explored = true;
    }

    public void InitializeAvailableCardPool(IEnumerable<CardDataSO> cards)
    {
        _availableCardPool.Clear();
        if (cards == null) return;

        foreach (CardDataSO card in cards)
        {
            if (card == null) continue;
            // None 타입은 어느 풀에도 절대 포함하지 않는다 (선택 덱이 무엇이든 제외).
            if (card.DeckType == EStartingDeck.None) continue;
            if (card.DeckType != EStartingDeck.Common && card.DeckType != SelectedDeckType) continue;
            _availableCardPool.Add(card);
        }
    }

    /// <summary>시작 덱 ID 들로 덱 초기화 (런 시작 시 1회).</summary>
    public void InitializeDeck(IEnumerable<string> startingCardIds)
    {
        _deckCardIds.Clear();
        _deckEntries.Clear();
        _persistentCardStates.Clear();
        _cardCostDeltas.Clear();
        _nextDeckEntryId = 1;
        if (startingCardIds == null) return;

        foreach (string id in startingCardIds)
        {
            if (!string.IsNullOrEmpty(id))
            {
                AddCardToDeck(id);
            }
        }
    }

    /// <summary>덱에 카드 추가 (전투 보상 획득).</summary>
    public RunDeckEntry AddCardToDeck(string cardId)
    {
        if (!string.IsNullOrEmpty(cardId))
        {
            _deckCardIds.Add(cardId);
            RunDeckEntry entry = new RunDeckEntry(_nextDeckEntryId++, cardId);
            _deckEntries.Add(entry);
            return entry;
        }

        return null;
    }

    /// <summary>
    /// 덱 순서는 유지하면서 지정 엔트리를 완전히 새로운 카드 엔트리로 교체한다.
    /// 기존 엔트리에 연결된 영구 상태와 코스트 보정은 폐기한다.
    /// </summary>
    public RunDeckEntry ReplaceCardInDeckEntry(
        int entryId, string newCardId, ECardDirection? resolvedDirection = null)
    {
        if (string.IsNullOrEmpty(newCardId)) return null;
        int index = FindDeckEntryIndex(entryId);
        if (index < 0 || index >= _deckCardIds.Count) return null;

        _persistentCardStates.Remove(entryId);
        _cardCostDeltas.Remove(entryId);

        var replacement = new RunDeckEntry(_nextDeckEntryId++, newCardId);
        if (resolvedDirection.HasValue)
            replacement.SetInitialArrowDirection(resolvedDirection.Value);
        _deckCardIds[index] = newCardId;
        _deckEntries[index] = replacement;
        return replacement;
    }

    /// <summary>덱에서 카드 1장 제거 (제거 이벤트·상점 등). 첫 일치 항목만 제거.</summary>
    public bool RemoveCardFromDeck(string cardId)
    {
        int index = _deckCardIds.IndexOf(cardId);
        if (index < 0) return false;
        if (index >= _deckEntries.Count) return false;

        return RemoveCardFromDeckEntry(_deckEntries[index].EntryId, out _);
    }

    public bool RemoveCardFromDeckEntry(int entryId, out string removedCardId)
    {
        removedCardId = null;
        int index = FindDeckEntryIndex(entryId);
        if (index < 0 || index >= _deckCardIds.Count) return false;

        RunDeckEntry entry = _deckEntries[index];
        removedCardId = entry.CardId;
        _deckCardIds.RemoveAt(index);
        _persistentCardStates.Remove(entry.EntryId);
        _cardCostDeltas.Remove(entry.EntryId);
        _deckEntries.RemoveAt(index);
        return true;
    }

    public bool TryAddArrowToEntry(int entryId, ECardDirection direction)
    {
        RunDeckEntry entry = FindDeckEntry(entryId);
        if (entry == null) return false;

        if (!entry.HasArrowDirection && !entry.EnsureArrowResolved())
            return false;

        return entry.TryAddArrow(direction);
    }

    public bool TryRemoveArrowFromEntry(int entryId, ECardDirection direction)
    {
        RunDeckEntry entry = FindDeckEntry(entryId);
        if (entry == null) return false;
        if (!entry.HasArrowDirection && !entry.EnsureArrowResolved()) return false;
        return entry.TryRemoveArrow(direction);
    }

    public bool TryReplaceArrowOnEntry(int entryId, ECardDirection remove, ECardDirection add)
    {
        RunDeckEntry entry = FindDeckEntry(entryId);
        if (entry == null) return false;
        if (!entry.HasArrowDirection && !entry.EnsureArrowResolved()) return false;
        return entry.TryReplaceArrow(remove, add);
    }

    private RunDeckEntry FindDeckEntry(int entryId)
    {
        int index = FindDeckEntryIndex(entryId);
        return index >= 0 ? _deckEntries[index] : null;
    }

    private int FindDeckEntryIndex(int entryId)
    {
        for (int i = 0; i < _deckEntries.Count; i++)
        {
            RunDeckEntry entry = _deckEntries[i];
            if (entry != null && entry.EntryId == entryId)
                return i;
        }
        return -1;
    }

    public RunCardPersistentState GetPersistentState(int deckEntryId, bool create)
    {
        if (deckEntryId <= 0) return null;
        if (_persistentCardStates.TryGetValue(deckEntryId, out RunCardPersistentState state))
        {
            return state;
        }
        if (!create) return null;

        state = new RunCardPersistentState();
        _persistentCardStates[deckEntryId] = state;
        return state;
    }

    public void TrimEmptyPersistentState(int deckEntryId)
    {
        if (deckEntryId <= 0) return;
        if (_persistentCardStates.TryGetValue(deckEntryId, out RunCardPersistentState state) &&
            state != null && state.IsEmpty)
        {
            _persistentCardStates.Remove(deckEntryId);
        }
    }

    /// <summary>
    /// 이번 런에서 상점 카드 제거 서비스를 이용한 횟수. 제거 비용 점증(슬더스식)에 쓰인다.
    /// 비용 계산은 상점 시스템이 담당하고, 여기서는 횟수만 누적한다(런 단위 데이터).
    /// </summary>
    public int CardRemovalCount { get; private set; }

    /// <summary>카드 제거 서비스 이용 1회 기록 (비용 점증용). 실제 덱 제거와 별개로 호출.</summary>
    public void RegisterCardRemoval()
    {
        CardRemovalCount++;
    }

    // -------------------------------------------------
    // 골드 (런 단위 화폐)
    // -------------------------------------------------

    /// <summary>
    /// 골드 획득 (전투 보상·이벤트). 음수/0 은 무시한다(소모는 SpendGold 사용).
    /// 데이터만 변경한다 — 변동 통지(이벤트 발행)는 호출부(InGameController)가 담당한다.
    /// </summary>
    public void AddGold(int amount)
    {
        if (amount <= 0) return;
        Gold += amount;
    }

    /// <summary>
    /// 골드 소모 (상점 구매 등). 보유량이 부족하면 차감하지 않고 false 를 반환한다.
    /// 데이터만 변경한다 — 변동 통지는 호출부가 담당한다.
    /// </summary>
    /// <returns>차감에 성공하면 true, 잔액 부족이면 false.</returns>
    public bool SpendGold(int amount)
    {
        if (amount <= 0) return true;     // 비용 0 은 항상 성공(무료)
        if (Gold < amount) return false;  // 잔액 부족 — 미차감

        Gold -= amount;
        return true;
    }

    /// <summary>골드 지불 가능 여부 (구매 버튼 활성 판단 등).</summary>
    public bool CanAffordGold(int amount) => amount <= 0 || Gold >= amount;

    // -------------------------------------------------
    // 체력 (런 단위 — 전투 간 유지)
    // -------------------------------------------------

    /// <summary>
    /// 런 체력 초기화 (런 시작 시 1회). 최대 체력 설정 + 현재 체력을 가득 채운다.
    /// maxHp 가 0 이하면 무시(HP 시스템 미사용 — 매 전투 풀피 폴백).
    /// </summary>
    public void InitializeHp(int maxHp)
    {
        if (maxHp <= 0) return;
        MaxHp = maxHp;
        CurrentHp = maxHp;
        NotifyHpChanged();
    }

    /// <summary>
    /// 전투 종료 후 생존 체력을 런에 반영 (승리 시 호출). 0~MaxHp 로 클램프.
    /// HP 시스템 미초기화면(HasHp=false) 무시.
    /// </summary>
    public void SetCurrentHp(int hp)
    {
        if (!HasHp) return;
        int clamped = Mathf.Clamp(hp, 0, MaxHp);
        if (clamped == CurrentHp) return;   // 값 변화 없음 — 불필요한 UI 갱신 방지
        CurrentHp = clamped;
        NotifyHpChanged();
    }

    /// <summary>체력 회복 (휴식·효과). MaxHp 한도로 클램프. 회복한 실제량을 반환.</summary>
    public int HealHp(int amount)
    {
        if (!HasHp || amount <= 0) return 0;
        int before = CurrentHp;
        CurrentHp = Mathf.Min(MaxHp, CurrentHp + amount);
        int healed = CurrentHp - before;
        if (healed > 0) NotifyHpChanged();
        return healed;
    }

    /// <summary>최대 체력 증가 (영구 강화 등). 증가분만큼 현재 체력도 항상 함께 올린다.</summary>
    public void IncreaseMaxHp(int amount)
    {
        if (!HasHp || amount <= 0) return;
        MaxHp += amount;
        CurrentHp += amount;
        NotifyHpChanged();
    }

    /// <summary>최대 체력 증감 (요구량 지불 등). 최소 1 클램프, 현재 체력이 초과하면 함께 내린다.</summary>
    public void ModifyMaxHp(int delta)
    {
        if (!HasHp || delta == 0) return;
        MaxHp = Mathf.Max(1, MaxHp + delta);
        if (delta > 0) CurrentHp += delta;          // 증가 시 현재 체력도 동일 수치 상승
        if (CurrentHp > MaxHp) CurrentHp = MaxHp;
        NotifyHpChanged();
    }

    /// <summary>HP 변동 통지 (현재, 최대). 구독자가 없으면 아무 일도 하지 않는다.</summary>
    private void NotifyHpChanged()
    {
        OnHpChanged?.Invoke(CurrentHp, MaxHp);
    }

    /// <summary>다음 층으로 전진 (전투 클리어 시).</summary>
    public void AdvanceFloor()
    {
        CurrentFloor++;
    }

    /// <summary>
    /// 보존 설정 초기화 (런 시작 시 1회). 전체 보존 여부와 보존 한도 초기값을 세팅한다.
    /// preserveAll=true 면 maxPreserveCount 는 무의미(전부 유지).
    /// </summary>
    public void InitializePreserve(bool preserveAll, int maxPreserveCount)
    {
        PreserveAll = preserveAll;
        MaxPreserveCount = maxPreserveCount < 0 ? 0 : maxPreserveCount;
    }

    /// <summary>보존 한도 증가 (런 중 카드/유물 효과). 음수·0 은 무시. 새 한도를 반환.</summary>
    public int IncreaseMaxPreserveCount(int amount)
    {
        if (amount <= 0) return MaxPreserveCount;
        MaxPreserveCount += amount;
        return MaxPreserveCount;
    }

    /// <summary>보존 한도를 직접 설정 (전투 중 역반영 콜백 수신용). 0 미만은 0 으로 보정.</summary>
    public void SetMaxPreserveCount(int value)
    {
        MaxPreserveCount = value < 0 ? 0 : value;
    }

    /// <summary>최대 마나 초기화 (런 시작·이어하기 폴백). 하한 보정.</summary>
    public void InitializeMana(int maxMana)
    {
        MaxMana = maxMana < ManaMin ? ManaMin : maxMana;
    }

    /// <summary>최대 마나 증감 (이벤트 등). 부호 있는 delta, 하한 클램프. 새 값을 반환.</summary>
    public int ModifyMaxMana(int delta)
    {
        MaxMana = Mathf.Max(ManaMin, MaxMana + delta);
        return MaxMana;
    }

    /// <summary>턴 시작 드로우 수 초기화 (런 시작·이어하기 폴백). 하한 보정.</summary>
    public void InitializeDraw(int drawPerTurn)
    {
        DrawPerTurn = drawPerTurn < DrawMin ? DrawMin : drawPerTurn;
    }

    /// <summary>턴 시작 드로우 수 증감 (이벤트 등). 부호 있는 delta, 하한 클램프. 새 값을 반환.</summary>
    public int ModifyDrawPerTurn(int delta)
    {
        DrawPerTurn = Mathf.Max(DrawMin, DrawPerTurn + delta);
        return DrawPerTurn;
    }

    // -------------------------------------------------
    // 노드맵
    // -------------------------------------------------

    /// <summary>
    /// 이 런의 맵을 생성한다(런 시작 시 1회). 런 시드로 생성하므로 같은 시드는 같은 맵.
    /// 생성 직후엔 아직 노드에 진입하지 않은 상태(CurrentNodeId = NoNode)다.
    /// </summary>
    /// <param name="stageData">스테이지 생성 파라미터 SO.</param>
    public void GenerateMap(StageDataSO stageData, int stageIndex)
    {
        Map = MapGenerator.Generate(stageData, Seed, stageIndex);
        CurrentNodeId = NoNode;
        CurrentFloor = 1;
        ClearPendingEvent();
    }

    /// <summary>
    /// 현재 위치에서 이동 가능한 노드 목록을 반환한다.
    /// 아직 진입 전(NoNode)이면 첫 행(depth 1)의 모든 노드가 후보,
    /// 그 외엔 현재 노드의 인접 노드가 후보다. 맵이 없으면 빈 목록.
    /// </summary>
    public List<MapNode> GetReachableNodes()
    {
        var result = new List<MapNode>(4);
        if (Map == null) return result;

        // 진입 전: 첫 행 전체가 선택지.
        if (CurrentNodeId == NoNode)
        {
            int firstWidth = Map.GetDepthWidth(1);
            for (int i = 0; i < firstWidth; i++)
            {
                MapNode n = Map.GetNode(1, i);
                if (n != null) result.Add(n);
            }
            return result;
        }

        return Map.GetReachableNodes(CurrentNodeId);
    }

    /// <summary>
    /// 지정 노드로 이동할 수 있는지 검사한다(슬더스 이동 규칙).
    /// 현재 도달 가능 후보(GetReachableNodes)에 포함된 노드만 이동 가능.
    /// </summary>
    public bool CanMoveTo(int nodeId)
    {
        foreach (MapNode n in GetReachableNodes())
        {
            if (n.Id == nodeId) return true;
        }
        return false;
    }

    /// <summary>
    /// 지정 노드로 이동한다. 이동 규칙을 통과하면 현재 노드를 갱신하고
    /// 층(CurrentFloor)을 노드의 depth 와 동기화한 뒤, 이전 노드를 방문 처리한다.
    /// 규칙 위반(도달 불가)이면 false 를 반환하고 상태를 바꾸지 않는다.
    /// </summary>
    /// <returns>이동에 성공하면 true.</returns>
    public bool MoveToNode(int nodeId)
    {
        if (Map == null) return false;
        if (!CanMoveTo(nodeId)) return false;

        MapNode target = Map.GetNode(nodeId);
        if (target == null) return false;

        // 현재 노드를 방문 처리 (UI 알파·이동 규칙 표시용).
        MapNode prev = Map.GetNode(CurrentNodeId);
        if (prev != null) prev.Explored = true;

        CurrentNodeId = nodeId;

        // 층 동기화: 노드 depth 와 CurrentFloor 를 일치시킨다.
        CurrentFloor = target.Depth;
        return true;
    }

    private static RunSavePendingEventProgress CloneEventProgress(
        RunSavePendingEventProgress source)
    {
        if (source == null) return null;
        var clone = new RunSavePendingEventProgress
        {
            nodeId = source.nodeId,
            eventId = source.eventId ?? string.Empty,
            choiceIndex = source.choiceIndex,
            costsApplied = source.costsApplied,
            nextEffectIndex = source.nextEffectIndex,
        };

        if (source.effectTypeIds != null)
        {
            for (int i = 0; i < source.effectTypeIds.Count; i++)
                clone.effectTypeIds.Add(source.effectTypeIds[i] ?? string.Empty);
        }

        if (source.results != null)
        {
            for (int i = 0; i < source.results.Count; i++)
            {
                RunSaveEventEffectResult result = source.results[i];
                if (result == null) continue;
                clone.results.Add(new RunSaveEventEffectResult
                {
                    effectIndex = result.effectIndex,
                    hasAmount = result.hasAmount,
                    amount = result.amount,
                    hasArrowAddition = result.hasArrowAddition,
                    arrowTargetEntryId = result.arrowTargetEntryId,
                    arrowTargetCardId = result.arrowTargetCardId ?? string.Empty,
                    arrowTargetHasDirection = result.arrowTargetHasDirection,
                    arrowTargetDirection = result.arrowTargetDirection,
                    addedArrowDirection = result.addedArrowDirection,
                    hasCardCostChange = result.hasCardCostChange,
                    costEntryId = result.costEntryId,
                    costCardId = result.costCardId ?? string.Empty,
                    costCardDirection = result.costCardDirection,
                    costBefore = result.costBefore,
                    costAfter = result.costAfter,
                });
                RunSaveEventEffectResult resultClone = clone.results[clone.results.Count - 1];
                if (result.cardTransforms != null)
                {
                    for (int j = 0; j < result.cardTransforms.Count; j++)
                    {
                        RunSaveEventCardTransformResult transform = result.cardTransforms[j];
                        if (transform == null) continue;
                        resultClone.cardTransforms.Add(new RunSaveEventCardTransformResult
                        {
                            sourceCardId = transform.sourceCardId ?? string.Empty,
                            sourceDirection = transform.sourceDirection,
                            resultCardId = transform.resultCardId ?? string.Empty,
                            resultDirection = transform.resultDirection,
                        });
                    }
                }
            }
        }

        if (source.effects != null)
        {
            for (int i = 0; i < source.effects.Count; i++)
            {
                RunSaveEventEffectState state = source.effects[i];
                if (state == null) continue;
                var stateClone = new RunSaveEventEffectState
                {
                    effectIndex = state.effectIndex,
                    kind = state.kind ?? string.Empty,
                    prepared = state.prepared,
                    applied = state.applied,
                };
                if (state.transforms != null)
                {
                    for (int j = 0; j < state.transforms.Count; j++)
                    {
                        RunSaveEventTransformPair pair = state.transforms[j];
                        if (pair == null) continue;
                        stateClone.transforms.Add(new RunSaveEventTransformPair
                        {
                            sourceEntryId = pair.sourceEntryId,
                            sourceCardId = pair.sourceCardId ?? string.Empty,
                            hasSourceArrowDirection = pair.hasSourceArrowDirection,
                            sourceArrowDirection = pair.sourceArrowDirection,
                            resultCardId = pair.resultCardId ?? string.Empty,
                            hasArrowDirection = pair.hasArrowDirection,
                            arrowDirection = pair.arrowDirection,
                        });
                    }
                }
                if (state.rewardSlots != null)
                {
                    for (int j = 0; j < state.rewardSlots.Count; j++)
                    {
                        RunSaveEventCardRewardSlot slot = state.rewardSlots[j];
                        if (slot == null) continue;
                        var slotClone = new RunSaveEventCardRewardSlot
                        {
                            processed = slot.processed,
                            skipped = slot.skipped,
                            chosenCardId = slot.chosenCardId ?? string.Empty,
                            chosenArrowDirection = slot.chosenArrowDirection,
                        };
                        if (slot.candidates != null)
                        {
                            for (int k = 0; k < slot.candidates.Count; k++)
                            {
                                RunSaveEventCardCandidate candidate = slot.candidates[k];
                                if (candidate == null) continue;
                                slotClone.candidates.Add(new RunSaveEventCardCandidate
                                {
                                    cardId = candidate.cardId ?? string.Empty,
                                    arrowDirection = candidate.arrowDirection,
                                });
                            }
                        }
                        stateClone.rewardSlots.Add(slotClone);
                    }
                }
                clone.effects.Add(stateClone);
            }
        }
        return clone;
    }
}
