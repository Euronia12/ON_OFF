// =================================================================
// [스크립트 목적]  최종 보스 격파 엔딩 연출(이미지 컷씬 → 패럴랙스 루프 → 결과 화면)의
//                 UI/리소스 오케스트레이션을 InGameController 에서 분리한 협력자.
// [주요 변수]      - _sequence : Addressable 로 생성한 런 클리어 패럴랙스 프리팹
//                  - _skip     : 루프 스킵 UI
//                  - _loopCts  : 루프 전용 취소 토큰(스킵 시 취소)
// [의존 관계]      - UIRunClearDisplay / UIRunClearSkip / RunClearSequence / UISystemGameClear
//                  - SceneFlowManager / UIManager / ResourceManager / CameraManager / UniTask
// [설계 노트]      - 게임 로직(런 종료·통계 확정·게임플레이 정리)은 컨트롤러가 소유한다.
//                    이 클래스는 "무엇을 정리할지"를 콜백으로 위임받아 연출만 담당한다.
//                  - Config/콜백 주입으로 InGameController 의 private 상태에 의존하지 않는다.
// =================================================================

using System;
using System.Threading;
using Cysharp.Threading.Tasks;
using UnityEngine;

/// <summary>런 클리어 엔딩 연출 전담 협력자. 연출 흐름·UI·Addressable 인스턴스 수명을 소유한다.</summary>
public sealed class RunClearPresenter
{
    /// <summary>연출 타이밍·리소스 키 묶음. InGameController 의 인스펙터 값을 그대로 전달받는다.</summary>
    public readonly struct Config
    {
        public readonly string SequenceKey;
        public readonly float InitialFadeDuration;
        public readonly float WhiteFadeDuration;
        public readonly float WhiteHoldDuration;
        public readonly float ResultFadeDuration;

        public Config(
            string sequenceKey,
            float initialFadeDuration,
            float whiteFadeDuration,
            float whiteHoldDuration,
            float resultFadeDuration)
        {
            SequenceKey = sequenceKey;
            InitialFadeDuration = initialFadeDuration;
            WhiteFadeDuration = whiteFadeDuration;
            WhiteHoldDuration = whiteHoldDuration;
            ResultFadeDuration = resultFadeDuration;
        }
    }

    private readonly Config _config;
    private readonly Func<RunStatisticsSnapshot> _getStatistics;
    private readonly Action _cleanupGameplay;
    private readonly Action _titleRequested;

    private RunClearSequence _sequence;
    private UIRunClearSkip _skip;
    private CancellationTokenSource _loopCts;
    private bool _isLoopSkipRequested;

    /// <param name="getStatistics">결과 화면에 바인딩할 런 통계 스냅샷 제공자.</param>
    /// <param name="cleanupGameplay">가려진 상태에서 맵·전투·그리드 등 게임플레이를 정리하는 컨트롤러 콜백.</param>
    /// <param name="titleRequested">결과 화면 타이틀 복귀 버튼 콜백.</param>
    public RunClearPresenter(
        Config config,
        Func<RunStatisticsSnapshot> getStatistics,
        Action cleanupGameplay,
        Action titleRequested)
    {
        _config = config;
        _getStatistics = getStatistics;
        _cleanupGameplay = cleanupGameplay;
        _titleRequested = titleRequested;
    }

    /// <summary>
    /// 엔딩 연출 전체를 재생한다: 검정 페이드 → 이미지 컷씬 → 흰 페이드/루프 준비 →
    /// 패럴랙스 루프 → 검정 페이드 → 결과 화면 Reveal. 취소/예외 시 자체 정리하고,
    /// 로드 실패 등으로 루프가 준비되지 않으면 결과 화면으로 폴백한다.
    /// </summary>
    public async UniTask PlayAsync(CancellationToken token)
    {
        try
        {
            UIRunClearDisplay display = await TransitionToDisplayAsync(token);
            if (display != null)
                await display.PlayAsync(token);

            bool loopReady = await TransitionToLoopAsync(token);
            if (!loopReady) return;

            await PlayLoopAsync(token);
            UISystemGameClear result = await TransitionToResultAsync(token, _config.ResultFadeDuration);
            if (result != null)
                await result.PlayRevealAsync(token);
        }
        catch (OperationCanceledException)
        {
            CloseDisplay();
            CloseSkip();
            DisposeLoopCts();
            ReleaseSequence();
        }
        catch (Exception e)
        {
            Debug.LogError($"[RunClearPresenter] 런 클리어 연출 실패: {e}");
            CloseDisplay();
            CloseSkip();
            DisposeLoopCts();
            ReleaseSequence();

            if (!token.IsCancellationRequested)
            {
                UISystemGameClear result = await TransitionToResultAsync(token, _config.ResultFadeDuration);
                if (result != null)
                    await result.PlayRevealAsync(token);
            }
        }
    }

    /// <summary>
    /// 컷씬·루프 없이 결과 화면만 페이드로 연다(레거시/방어 경로용).
    /// 스테이지 클리어 통지·런 종료·오디오는 호출부가 이미 처리한 상태여야 한다.
    /// </summary>
    public async UniTask ShowResultOnlyAsync(CancellationToken token)
    {
        UISystemGameClear result = await TransitionToResultAsync(token, _config.ResultFadeDuration);
        if (result != null)
            await result.PlayRevealAsync(token);
    }

    /// <summary>남은 연출 UI·Addressable 인스턴스를 강제 정리한다(컨트롤러 OnDestroy 등).</summary>
    public void Dispose()
    {
        CloseDisplay();
        CloseSkip();
        DisposeLoopCts();
        ReleaseSequence();
    }

    // -------------------------------------------------
    // 이미지 컷씬
    // -------------------------------------------------

    private async UniTask<UIRunClearDisplay> TransitionToDisplayAsync(CancellationToken token)
    {
        UIRunClearDisplay display = null;

        async UniTask Prepare(CancellationToken fadeToken)
        {
            _cleanupGameplay?.Invoke();
            if (!UIManager.HasInstance)
            {
                Debug.LogWarning("[RunClearPresenter] UIManager가 없어 이미지 컷씬을 건너뜁니다.");
                return;
            }

            display = await UIManager.Instance.OpenAsync<UIRunClearDisplay>(fadeToken);
            if (display == null)
                Debug.LogWarning("[RunClearPresenter] 이미지 컷씬 UI를 열지 못했습니다.");
        }

        if (SceneFlowManager.HasInstance && !SceneFlowManager.Instance.IsTransitioning)
        {
            await SceneFlowManager.Instance.RunWithFadeAsync(
                Prepare,
                token,
                _config.InitialFadeDuration,
                fadeColor: Color.black);
        }
        else
        {
            await Prepare(token);
        }

        return display;
    }

    private static void CloseDisplay()
    {
        if (UIManager.HasInstance)
            UIManager.Instance.Close<UIRunClearDisplay>();
    }

    // -------------------------------------------------
    // 루프 준비 / 재생
    // -------------------------------------------------

    private async UniTask<RunClearSequence> CreateSequenceAsync(CancellationToken token)
    {
        if (!ResourceManager.HasInstance || string.IsNullOrWhiteSpace(_config.SequenceKey))
        {
            Debug.LogError("[RunClearPresenter] 런 클리어 프리팹을 생성할 ResourceManager/키가 없습니다.");
            return null;
        }

        RunClearSequence sequence = await ResourceManager.Instance
            .InstantiateAsync<RunClearSequence>(_config.SequenceKey, token: token);
        if (sequence == null)
            Debug.LogError($"[RunClearPresenter] 런 클리어 프리팹 생성 실패: {_config.SequenceKey}");
        return sequence;
    }

    private async UniTask<UIRunClearSkip> OpenSkipAsync(CancellationToken token)
    {
        if (!UIManager.HasInstance) return null;

        UIRunClearSkip skip = await UIManager.Instance.OpenAsync<UIRunClearSkip>(token);
        if (skip == null)
            Debug.LogWarning("[RunClearPresenter] 런 클리어 스킵 UI를 열지 못했습니다.");
        return skip;
    }

    private async UniTask<bool> TransitionToLoopAsync(CancellationToken token)
    {
        UISystemGameClear fallbackResult = null;

        async UniTask Prepare(CancellationToken fadeToken)
        {
            CloseDisplay();

            UniTask<RunClearSequence> sequenceTask = CreateSequenceAsync(fadeToken);
            UniTask<UIRunClearSkip> skipTask = OpenSkipAsync(fadeToken);
            UniTask minimumHoldTask = UniTask.Delay(
                TimeSpan.FromSeconds(_config.WhiteHoldDuration),
                DelayType.UnscaledDeltaTime,
                cancellationToken: fadeToken);

            _sequence = await sequenceTask;
            _skip = await skipTask;
            await minimumHoldTask;

            if (_sequence == null)
            {
                CloseSkip();
                fallbackResult = await OpenResultAsync(fadeToken);
                return;
            }

            if (_skip != null)
            {
                _skip.OnSkipRequested -= HandleLoopSkipRequested;
                _skip.OnSkipRequested += HandleLoopSkipRequested;
            }

            Camera camera = CameraManager.HasInstance ? CameraManager.Instance.MainCamera : Camera.main;
            _sequence.PrepareLoop(camera);
        }

        if (SceneFlowManager.HasInstance && !SceneFlowManager.Instance.IsTransitioning)
        {
            await SceneFlowManager.Instance.RunWithFadeAsync(
                Prepare,
                token,
                _config.WhiteFadeDuration,
                fadeColor: Color.white);
        }
        else
        {
            await Prepare(token);
        }

        if (_sequence != null) return true;

        if (fallbackResult != null)
            await fallbackResult.PlayRevealAsync(token);
        return false;
    }

    private async UniTask PlayLoopAsync(CancellationToken token)
    {
        if (_sequence == null) return;

        DisposeLoopCts();
        _isLoopSkipRequested = false;
        _loopCts = CancellationTokenSource.CreateLinkedTokenSource(token);
        _skip?.SetInputEnabled(true);

        try
        {
            await _sequence.PlayLoopAsync(_loopCts.Token);
        }
        catch (OperationCanceledException) when (
            _isLoopSkipRequested && !token.IsCancellationRequested)
        {
            // 버튼/ESC 스킵은 루프만 끝내고 전체 엔딩 흐름은 계속 진행한다.
        }
        finally
        {
            CloseSkip();
            DisposeLoopCts();
        }
    }

    private void HandleLoopSkipRequested()
    {
        if (_isLoopSkipRequested) return;

        _isLoopSkipRequested = true;
        _loopCts?.Cancel();
    }

    private void CloseSkip()
    {
        if (_skip != null)
            _skip.OnSkipRequested -= HandleLoopSkipRequested;

        if (UIManager.HasInstance)
            UIManager.Instance.Close<UIRunClearSkip>();
        _skip = null;
    }

    private void DisposeLoopCts()
    {
        if (_loopCts == null) return;

        _loopCts.Dispose();
        _loopCts = null;
    }

    // -------------------------------------------------
    // 결과 화면
    // -------------------------------------------------

    private async UniTask<UISystemGameClear> TransitionToResultAsync(
        CancellationToken token,
        float fadeDuration)
    {
        UISystemGameClear result = null;

        async UniTask Prepare(CancellationToken fadeToken)
        {
            CloseDisplay();
            CloseSkip();
            ReleaseSequence();
            _cleanupGameplay?.Invoke();
            result = await OpenResultAsync(fadeToken);
        }

        if (SceneFlowManager.HasInstance && !SceneFlowManager.Instance.IsTransitioning)
        {
            await SceneFlowManager.Instance.RunWithFadeAsync(
                Prepare,
                token,
                fadeDuration,
                fadeColor: Color.black);
        }
        else
        {
            await Prepare(token);
        }

        return result;
    }

    private async UniTask<UISystemGameClear> OpenResultAsync(CancellationToken token)
    {
        if (!UIManager.HasInstance)
        {
            Debug.LogError("[RunClearPresenter] UIManager가 없어 게임클리어 결과 UI를 열 수 없습니다.");
            return null;
        }

        UISystemGameClear result = await UIManager.Instance.OpenAsync<UISystemGameClear>(token);
        if (result == null) return null;

        result.BindStatistics(_getStatistics?.Invoke());
        if (_titleRequested != null)
        {
            result.OnTitleRequested -= _titleRequested;
            result.OnTitleRequested += _titleRequested;
        }
        return result;
    }

    private void ReleaseSequence()
    {
        if (_sequence == null) return;

        GameObject instance = _sequence.gameObject;
        _sequence = null;
        if (ResourceManager.HasInstance)
            ResourceManager.Instance.ReleaseInstance(instance);
        else
            UnityEngine.Object.Destroy(instance);
    }
}
