using UnityEngine;

[DisallowMultipleComponent]
public sealed class BattleBackgroundParallaxScroller : MonoBehaviour
{
    [System.Serializable]
    private sealed class Layer
    {
        [SerializeField] private Transform[] _backgrounds;
        [SerializeField, Min(0f)] private float _speedMultiplier = 1f;

        public Transform[] Backgrounds => _backgrounds;
        public float SpeedMultiplier => _speedMultiplier;
    }

    [SerializeField] private Layer[] _layers;
    [SerializeField] private Camera _camera;
    [SerializeField, Min(0f)] private float _speed = 1f;
    [SerializeField, Min(0.01f)] private float _backgroundWidth = 14.2f;
    [SerializeField, Min(0f)] private float _recycleMargin = 1f;

    private bool _isScrolling;
    private bool _moveRight;
    private bool _useUnscaledTime;

    public float ActiveSpeed => _isScrolling ? _speed : 0f;

    private void Awake()
    {
        if (_camera == null)
            _camera = Camera.main;

        Debug.Assert(_layers != null && _layers.Length > 0,
            $"{nameof(BattleBackgroundParallaxScroller)}: 이동할 배경 레이어가 필요합니다.", this);
        Debug.Assert(_camera != null,
            $"{nameof(BattleBackgroundParallaxScroller)}: Main Camera가 필요합니다.", this);

        if (_layers == null) return;

        foreach (Layer layer in _layers)
        {
            Debug.Assert(layer != null && layer.Backgrounds != null && layer.Backgrounds.Length > 0,
                $"{nameof(BattleBackgroundParallaxScroller)}: 각 레이어에 이동할 배경이 필요합니다.", this);
        }
    }

    private void Update()
    {
        if (!_isScrolling || _speed <= 0f || _camera == null || _layers == null || _layers.Length == 0)
            return;

        float cameraHalfWidth = _camera.orthographicSize * _camera.aspect;
        float leftRecycleEdge = _camera.transform.position.x - cameraHalfWidth - _recycleMargin;
        float rightRecycleEdge = _camera.transform.position.x + cameraHalfWidth + _recycleMargin;
        float deltaTime = _useUnscaledTime ? Time.unscaledDeltaTime : Time.deltaTime;

        foreach (Layer layer in _layers)
        {
            Transform[] backgrounds = layer?.Backgrounds;
            if (backgrounds == null || backgrounds.Length == 0 || layer.SpeedMultiplier <= 0f) continue;

            // 런 클리어 컷씬처럼 루트에 균일 스케일을 적용해도 실제 월드 폭으로 순환한다.
            float scaledBackgroundWidth = _backgroundWidth * Mathf.Abs(transform.lossyScale.x);
            float recycleDistance = scaledBackgroundWidth * backgrounds.Length;
            float movement = _speed * layer.SpeedMultiplier * deltaTime;

            foreach (Transform background in backgrounds)
            {
                if (background == null) continue;

                Vector3 position = background.position;
                position.x += _moveRight ? movement : -movement;

                if (_moveRight)
                {
                    float backgroundLeftEdge = position.x - scaledBackgroundWidth * 0.5f;
                    if (backgroundLeftEdge > rightRecycleEdge)
                    {
                        float passedCycles = Mathf.Floor(
                            (backgroundLeftEdge - rightRecycleEdge) / recycleDistance) + 1f;
                        position.x -= recycleDistance * passedCycles;
                    }
                }
                else
                {
                    float backgroundRightEdge = position.x + scaledBackgroundWidth * 0.5f;
                    if (backgroundRightEdge < leftRecycleEdge)
                    {
                        float passedCycles = Mathf.Floor(
                            (leftRecycleEdge - backgroundRightEdge) / recycleDistance) + 1f;
                        position.x += recycleDistance * passedCycles;
                    }
                }

                background.position = position;
            }
        }
    }

    public void SetSpeed(float speed)
    {
        _speed = Mathf.Max(0f, speed);
        _isScrolling = _speed > 0f;
    }

    /// <summary>사용 카메라와 스크롤 방향·시간 기준을 설정한다.</summary>
    public void Configure(Camera camera, bool moveRight, bool useUnscaledTime = false)
    {
        if (camera != null)
            _camera = camera;

        _moveRight = moveRight;
        _useUnscaledTime = useUnscaledTime;
    }

    public void Stop() => _isScrolling = false;

    public void Resume() => _isScrolling = _speed > 0f;
}
