// =================================================================
// [스크립트 목적]  전투 스킬 패널. 선택 캐릭터의 스킬(1개 또는 3개)을 로드하고,
//                  스킬 타입(off/회전/방향)에 맞는 버튼 그룹 Root 만 활성화한다.
//                  - 단일 스킬: 스킬 선택 바 없이 해당 그룹 버튼 노출
//                  - 3-스킬   : 방향 불요 스킬은 탭 선택 즉시 타겟팅, 방향 스킬만 세부 버튼 노출
// [주요 변수]      - _skillRuntimes : 캐릭터 스킬 런타임(1 또는 3)
//                  - _skillSelectorRoot : 3-스킬 전용 스킬 탭 바 (단일 모드에선 비활성)
//                  - _offRoot/_rotateRoot/_directionRoot : 그룹 버튼 부모(같은 자리 공유)
// [의존 관계]      - InGameController(SelectedCharacter) / SkillCastInput
//                  - UIBattleSkillButton(방향) / UIBattleSkillSelectButton(스킬 탭)
// [설계 노트]      - 스킬 타입은 SkillDataSO 의 Effects(DirectionOptions/RequiresDirectionSelection)
//                    에서 파생. 버튼 개별 토글이 아닌 그룹 Root 단위 활성/비활성.
//                  - VerticalLayoutGroup 가정: 선택 바 비활성 시 방향 버튼이 자동 리플로우.
// =================================================================

using System;
using System.Collections.Generic;
using Cysharp.Threading.Tasks;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public sealed class UIBattleSkillPanel : MonoBehaviour
{
    [Header("스킬 입력")]
    [Tooltip("스킬 타겟팅 입력")]
    [SerializeField] private SkillCastInput _skillCastInput;

    [Header("스킬 선택 바 (3-스킬 전용)")]
    [Tooltip("스킬 탭 버튼들의 부모. 단일 스킬 캐릭터에선 비활성")]
    [SerializeField] private GameObject _skillSelectorRoot;

    [Header("버튼 그룹 Root (타입별 부모 오브젝트)")]
    [Tooltip("off 형 스킬 버튼들의 부모. 방향 불요 스킬에서 활성")]
    [SerializeField] private GameObject _offRoot;

    [Tooltip("회전형 스킬 버튼(좌/우)들의 부모")]
    [SerializeField] private GameObject _rotateRoot;

    [Tooltip("방향형 스킬 버튼(상하좌우)들의 부모")]
    [SerializeField] private GameObject _directionRoot;

    [Header("스킬 설명 패널")]
    [Tooltip("스킬 선택 탭 호버 시 고정 위치에 표시할 루트")]
    [SerializeField] private GameObject _skillDescriptionRoot;

    [Tooltip("DescKey 와 쿨타임을 표시할 스킬 설명 텍스트")]
    [SerializeField] private TMP_Text _skillDescriptionText;

    [Tooltip("기본 쿨타임 표기 로컬라이즈 키. {0}에 SkillDataSO 쿨타임 턴 수를 넣는다.")]
    [SerializeField] private string _cooldownFormatKey = LocalizationKeys.Skill.TooltipCooldownFormat;

    /// <summary>버튼 그룹 종류.</summary>
    private enum ESkillButtonGroup { None, Off, Rotate, Direction }

    private readonly List<UIBattleSkillSelectButton> _selectorButtons = new List<UIBattleSkillSelectButton>(3);
    private readonly List<UIBattleSkillButton> _offButtons = new List<UIBattleSkillButton>(1);
    private readonly List<UIBattleSkillButton> _rotateButtons = new List<UIBattleSkillButton>(2);
    private readonly List<UIBattleSkillButton> _directionButtons = new List<UIBattleSkillButton>(4);

    private readonly List<SkillRuntime> _skillRuntimes = new List<SkillRuntime>(3);

    private const float SKILL_LABEL_MIN_FONT_SIZE = 13f;
    private const float SKILL_LABEL_MAX_FONT_SIZE = 24f;

    // 그룹별 담당 스킬 (3-스킬은 타입 중복이 없어 1:1 매핑).
    private SkillRuntime _offSkill;
    private SkillRuntime _rotateSkill;
    private SkillRuntime _directionSkill;

    private ESkillButtonGroup _activeGroup = ESkillButtonGroup.None;
    private List<UIBattleSkillButton> _activeButtons;
    private SkillRuntime _activeSkill;          // 현재 펼쳐진 그룹을 담당하는 스킬
    private bool _multiSkill;
    private bool _phaseEnabled;
    private bool _initialized;
    private int _iconVersion;
    private RectTransform _tooltipRect;
    private object _tooltipOwner;
    private SkillRuntime _hoveredSkill;
    private Canvas _canvas;
    private string _tutorialAllowedSkillId = string.Empty;
    private ECardDirection _tutorialAllowedDirection = ECardDirection.None;

    /// <summary>스킬 타겟팅 입력. Initialize 후 유효 (UIBattle 이 손패 흐리기 배선에 사용).</summary>
    public SkillCastInput CastInput => _skillCastInput;

    public bool IsSelectionGuideActive =>
        _activeSkill != null
        && ((_multiSkill && _phaseEnabled) || (_skillCastInput != null && _skillCastInput.IsCasting));

    public string ActivePromptKey
    {
        get
        {
            if (!IsSelectionGuideActive || _activeSkill?.Data == null)
                return string.Empty;

            return _activeSkill.Data.RequiresDirectionSelection
                   && (_skillCastInput == null || !_skillCastInput.IsCasting)
                ? _activeSkill.Data.DirectionPromptKey
                : _activeSkill.Data.TargetPromptKey;
        }
    }

    public event Action OnSelectionStateChanged;

    /// <summary>튜토리얼에서 허용된 방향 스킬의 세부 버튼 패널이 펼쳐졌는지 여부.</summary>
    public bool IsTutorialAllowedSkillSelected =>
        !string.IsNullOrEmpty(_tutorialAllowedSkillId)
        && _activeSkill?.Data?.SkillId == _tutorialAllowedSkillId
        && _activeGroup != ESkillButtonGroup.None;

    /// <summary>튜토리얼 중 사용할 스킬과 선택 방향을 제한한다.</summary>
    public void SetTutorialRestriction(
        string allowedSkillId,
        ECardDirection allowedDirection = ECardDirection.None)
    {
        _tutorialAllowedSkillId = allowedSkillId ?? string.Empty;
        _tutorialAllowedDirection = allowedDirection;

        if (_activeSkill != null && !IsTutorialSkillAllowed(_activeSkill))
            SetActiveSkill(null);
        else
            RefreshActiveGroupVisibility();
    }

    /// <summary>튜토리얼 스킬 제한을 해제한다.</summary>
    public void ClearTutorialRestriction()
    {
        _tutorialAllowedSkillId = string.Empty;
        _tutorialAllowedDirection = ECardDirection.None;
        RefreshActiveGroupVisibility();
    }

    /// <summary>현재 튜토리얼 단계에서 허용된 스킬 UI 위의 포인터인지 확인한다.</summary>
    public bool IsPointerOverAllowedTutorialControl(Vector2 screenPosition)
    {
        if (string.IsNullOrEmpty(_tutorialAllowedSkillId))
            return ContainsScreenPoint(transform as RectTransform, screenPosition);

        if (TryGetTutorialAllowedSkillRect(out RectTransform selectorRect)
            && ContainsScreenPoint(selectorRect, screenPosition))
            return true;

        if (_activeSkill == null || !IsTutorialSkillAllowed(_activeSkill)
            || _activeButtons == null)
        {
            return false;
        }

        for (int i = 0; i < _activeButtons.Count; i++)
        {
            UIBattleSkillButton button = _activeButtons[i];
            if (button != null
                && (_tutorialAllowedDirection == ECardDirection.None
                    || button.Direction == _tutorialAllowedDirection)
                && ContainsScreenPoint(button.transform as RectTransform, screenPosition))
            {
                return true;
            }
        }
        return false;
    }

    /// <summary>튜토리얼에서 허용된 스킬 선택 버튼의 실제 화면 RectTransform을 반환한다.</summary>
    public bool TryGetTutorialAllowedSkillRect(out RectTransform rect)
    {
        rect = null;
        if (string.IsNullOrEmpty(_tutorialAllowedSkillId))
            return false;

        for (int i = 0; i < _skillRuntimes.Count && i < _selectorButtons.Count; i++)
        {
            UIBattleSkillSelectButton button = _selectorButtons[i];
            if (button == null
                || _skillRuntimes[i]?.Data?.SkillId != _tutorialAllowedSkillId)
            {
                continue;
            }

            rect = button.transform as RectTransform;
            return rect != null && rect.gameObject.activeInHierarchy;
        }
        return false;
    }

    public void Initialize()
    {
        if (_initialized) return;
        _initialized = true;

        if (_skillCastInput == null)
            _skillCastInput = GetComponentInChildren<SkillCastInput>(true);
        _canvas = GetComponentInParent<Canvas>();
        if (_skillCastInput != null)
        {
            _skillCastInput.OnCastEnded -= HandleSkillCastEnded;
            _skillCastInput.OnCastEnded += HandleSkillCastEnded;
        }

        CacheSelectorButtons(_skillSelectorRoot, _selectorButtons);
        CacheButtons(_offRoot, _offButtons);
        CacheButtons(_rotateRoot, _rotateButtons);
        CacheButtons(_directionRoot, _directionButtons);
        InitializeSkillTooltip();

        SetSelectorActive(false);
        SetAllRootsActive(false);
        HideSkillTooltip();
    }

    public void BindSkills()
    {
        Initialize();
        UnbindSkills();

        LoadCharacterSkills();
        if (_skillRuntimes.Count == 0)
        {
            Debug.LogWarning("[UIBattleSkillPanel] 선택 캐릭터의 스킬을 찾지 못했습니다. 패널을 비활성화합니다.");
            SetSelectorActive(false);
            SetAllRootsActive(false);
            HideSkillTooltip();
            return;
        }

        for (int i = 0; i < _skillRuntimes.Count; i++)
        {
            _skillRuntimes[i].OnBattleStart();
            if (InGameController.HasInstance)
            {
                int remaining = InGameController.Instance.GetStoredSkillCooldown(
                    _skillRuntimes[i].Data.SkillId);
                _skillRuntimes[i].RestoreCooldown(remaining);
            }
            _skillRuntimes[i].OnChanged += HandleSkillChanged;
        }

        _multiSkill = _skillRuntimes.Count > 1;
        SetSelectorActive(_multiSkill);

        if (_multiSkill)
        {
            // 3-스킬: 스킬 탭 노출, 초기엔 어떤 그룹도 펼치지 않음.
            BindSelectorButtons();
            SetActiveSkill(null);
        }
        else
        {
            // 단일: 유일 스킬의 그룹을 바로 펼친다. 방향 불요 스킬은 기존 off 버튼 경로 유지.
            SetActiveSkill(_skillRuntimes[0]);
        }

        RefreshActiveGroupVisibility();
    }

    public void UnbindSkills()
    {
        _iconVersion++;
        _skillCastInput?.CancelCast();

        PersistSkillCooldowns();

        for (int i = 0; i < _skillRuntimes.Count; i++)
            _skillRuntimes[i].OnChanged -= HandleSkillChanged;
        _skillRuntimes.Clear();
        _offSkill = _rotateSkill = _directionSkill = null;

        for (int i = 0; i < _selectorButtons.Count; i++)
            _selectorButtons[i]?.Unbind();

        _activeSkill = null;
        _tutorialAllowedSkillId = string.Empty;
        _tutorialAllowedDirection = ECardDirection.None;
        SetActiveGroup(ESkillButtonGroup.None);
        SetAllRootsActive(false);
        ClearButtonOverlays();
        SetSelectorActive(false);
        HideSkillTooltip();
    }

    public void SetPhaseEnabled(bool enabled)
    {
        bool changed = _phaseEnabled != enabled;
        _phaseEnabled = enabled;
        HideSkillTooltip();
        RefreshActiveGroupVisibility();
        if (changed)
            OnSelectionStateChanged?.Invoke();
    }

    public void TickTurnEnd()
    {
        // 모든 스킬 쿨다운 틱 (과거 SkillLoadout 역할).
        for (int i = 0; i < _skillRuntimes.Count; i++)
            _skillRuntimes[i].TickTurnEnd();
    }

    public void CancelCast()
    {
        _skillCastInput?.CancelCast();
        if (_multiSkill && _activeSkill != null)
            SetActiveSkill(null);
    }

    public void RefreshLocalization()
    {
        if (_multiSkill)
            BindSelectorButtons();

        if (_tooltipOwner != null && _hoveredSkill != null)
            ShowSkillTooltip(_tooltipOwner, _hoveredSkill);
    }

    public bool TryResetDebugCooldowns()
    {
        if (!DebugCommandManager.CanExecuteDomain(EDebugCommand.ResetSkillCooldown)) return false;
        if (_skillRuntimes.Count == 0) return false;

        for (int i = 0; i < _skillRuntimes.Count; i++)
            _skillRuntimes[i]?.ResetCooldown();
        return true;
    }

    // ─────────────────────────────────────────────
    // 스킬 로드 / 타입 판별
    // ─────────────────────────────────────────────

    private void LoadCharacterSkills()
    {
        _skillRuntimes.Clear();
        _offSkill = _rotateSkill = _directionSkill = null;

        if (!InGameController.HasInstance)
        {
            Debug.LogWarning("[UIBattleSkillPanel] InGameController 가 없어 캐릭터 스킬을 로드할 수 없습니다.");
            return;
        }

        CharacterSO character = InGameController.Instance.SelectedCharacter;
        if (character == null || character.Skills == null)
            return;

        // 런 영속 쿨타임 보정(과충전 코일 등)을 런타임 데이터 생성 시점에 주입한다.
        RunContext run = InGameController.Instance.CurrentRun;
        IReadOnlyList<SkillDataSO> skills = character.Skills;
        for (int i = 0; i < skills.Count; i++)
        {
            if (skills[i] == null) continue;

            // 난이도는 런 시작부터 확정된 규칙이고 이벤트 보정은 이후 누적되는 변화다.
            // 두 값을 합친 뒤 한 번만 하한 처리해 중간 클램프로 이벤트 감소량이 사라지지 않게 한다.
            int difficultyCooldownDelta = InGameController.HasInstance
                ? InGameController.Instance.GetAdditionalSkillCooldown(skills[i])
                : 0;
            int eventCooldownDelta = run != null
                ? run.GetSkillCooldownDelta(skills[i].SkillId)
                : 0;
            SkillRuntime runtime = new SkillRuntime(
                skills[i].ToRuntimeData(difficultyCooldownDelta + eventCooldownDelta));
            _skillRuntimes.Add(runtime);

            // 그룹별 담당 스킬 매핑 (타입 중복 시 첫 스킬 유지).
            switch (ResolveGroup(runtime.Data))
            {
                case ESkillButtonGroup.Off: _offSkill ??= runtime; break;
                case ESkillButtonGroup.Rotate: _rotateSkill ??= runtime; break;
                case ESkillButtonGroup.Direction: _directionSkill ??= runtime; break;
            }
        }
    }

    /// <summary>스킬 효과 구성으로 버튼 그룹(off/회전/방향)을 판별한다.</summary>
    private static ESkillButtonGroup ResolveGroup(SkillRuntimeData data)
    {
        if (data == null || !data.RequiresDirectionSelection)
            return ESkillButtonGroup.Off;

        ECardDirection opts = data.DirectionOptions;
        bool hasUpDown = (opts & (ECardDirection.Up | ECardDirection.Down)) != 0;
        return hasUpDown ? ESkillButtonGroup.Direction : ESkillButtonGroup.Rotate;
    }

    private SkillRuntime GetGroupSkill(ESkillButtonGroup group)
    {
        return group switch
        {
            ESkillButtonGroup.Off => _offSkill,
            ESkillButtonGroup.Rotate => _rotateSkill,
            ESkillButtonGroup.Direction => _directionSkill,
            _ => null,
        };
    }

    // ─────────────────────────────────────────────
    // 스킬 탭 (3-스킬)
    // ─────────────────────────────────────────────

    private void BindSelectorButtons()
    {
        for (int i = 0; i < _selectorButtons.Count; i++)
        {
            UIBattleSkillSelectButton button = _selectorButtons[i];
            if (button == null) continue;

            bool valid = i < _skillRuntimes.Count;
            button.gameObject.SetActive(valid);
            if (!valid) continue;

            SkillRuntime runtime = _skillRuntimes[i];
            button.Bind(i, runtime, HandleSelectorClicked, HandleSelectorHoverEntered, HandleTooltipHoverExited);
            button.SetLabel(ResolveLocalized(runtime.Data != null ? runtime.Data.DisplayNameKey : string.Empty));
        }

        SynchronizeSelectorLabelFontSize();
    }

    private void SynchronizeSelectorLabelFontSize()
    {
        float smallestFontSize = SKILL_LABEL_MAX_FONT_SIZE;
        bool hasLabel = false;

        for (int i = 0; i < _skillRuntimes.Count && i < _selectorButtons.Count; i++)
        {
            UIBattleSkillSelectButton button = _selectorButtons[i];
            if (button == null) continue;

            smallestFontSize = Mathf.Min(
                smallestFontSize,
                button.CalculateAutoSizedLabelFontSize(SKILL_LABEL_MIN_FONT_SIZE, SKILL_LABEL_MAX_FONT_SIZE));
            hasLabel = true;
        }

        if (!hasLabel) return;

        for (int i = 0; i < _skillRuntimes.Count && i < _selectorButtons.Count; i++)
            _selectorButtons[i]?.SetLabelFontSize(smallestFontSize);
    }

    private void HandleSelectorClicked(int index)
    {
        if (index < 0 || index >= _skillRuntimes.Count) return;

        SkillRuntime runtime = _skillRuntimes[index];
        if (!IsTutorialSkillAllowed(runtime)) return;

        // 같은 탭 재클릭 → 접기.
        if (_activeSkill == runtime)
        {
            SetActiveSkill(null);
            return;
        }

        SetActiveSkill(runtime);

        if (_multiSkill && IsImmediateCastSkill(runtime))
            BeginImmediateCast(runtime);
    }

    private void RefreshSelectorSelected()
    {
        for (int i = 0; i < _selectorButtons.Count; i++)
        {
            UIBattleSkillSelectButton button = _selectorButtons[i];
            if (button == null) continue;
            bool selected = i < _skillRuntimes.Count && _skillRuntimes[i] == _activeSkill;
            button.SetSelected(selected);
        }
    }

    // ─────────────────────────────────────────────
    // 그룹 펼치기 / 활성
    // ─────────────────────────────────────────────

    /// <summary>지정 스킬의 그룹을 펼친다. null 이면 모두 접는다.</summary>
    private void SetActiveSkill(SkillRuntime skill)
    {
        _skillCastInput?.CancelCast();
        HideSkillTooltip();
        _activeSkill = skill;

        if (skill == null)
        {
            SetActiveGroup(ESkillButtonGroup.None);
            RefreshSelectorSelected();
            RefreshActiveGroupVisibility();
            OnSelectionStateChanged?.Invoke();
            return;
        }

        SetActiveGroup(ResolveGroup(skill.Data));
        if (IsImmediateCastSkill(skill))
        {
            SetActiveGroup(ESkillButtonGroup.None);
            _iconVersion++;
        }
        else
        {
            LoadGroupIconsAsync(skill.Data, ++_iconVersion).Forget();
        }
        RefreshSelectorSelected();
        RefreshActiveGroupVisibility();
        OnSelectionStateChanged?.Invoke();
    }

    private void SetActiveGroup(ESkillButtonGroup group)
    {
        _activeGroup = group;

        _activeButtons = group switch
        {
            ESkillButtonGroup.Off => _offButtons,
            ESkillButtonGroup.Rotate => _rotateButtons,
            ESkillButtonGroup.Direction => _directionButtons,
            _ => null,
        };

        if (_activeButtons != null)
        {
            for (int i = 0; i < _activeButtons.Count; i++)
                _activeButtons[i]?.Bind(HandleSkillButtonClicked);
        }
    }

    /// <summary>
    /// 세부(방향) 버튼 그룹 가시성/상태 갱신.
    /// - 단일 스킬: 그룹을 항상 표시. 쿨다운이면 버튼 비활성 + 남은 턴 수 표시.
    /// - 3-스킬   : 선택한 스킬이 "준비됨 + 입력 페이즈"일 때만 그룹을 펼침(쿨다운이면 숨김, 탭에 숫자).
    /// </summary>
    private void RefreshActiveGroupVisibility()
    {
        // 스킬 탭도 쿨다운 중에는 클릭을 완전히 차단한다. 호버 설명은 버튼 컴포넌트가 별도로 처리한다.
        for (int i = 0; i < _selectorButtons.Count; i++)
        {
            bool selectorReady = i < _skillRuntimes.Count
                && _skillRuntimes[i] != null
                && _skillRuntimes[i].IsReady
                && IsTutorialSkillAllowed(_skillRuntimes[i]);
            _selectorButtons[i]?.SetInteractable(_phaseEnabled && selectorReady);
        }

        bool hasActiveSkill = _activeSkill != null && IsTutorialSkillAllowed(_activeSkill);
        bool hasSkill = hasActiveSkill && _activeGroup != ESkillButtonGroup.None;
        bool ready = hasActiveSkill && _activeSkill.IsReady;
        int remaining = _activeSkill != null ? _activeSkill.RemainingCooldown : 0;
        int maxCooldown = _activeSkill != null ? _activeSkill.MaxCooldown : 0;
        bool immediateCastSkill = hasActiveSkill && IsImmediateCastSkill(_activeSkill);

        // 단일: 항상 펼침 / 3-스킬: 준비된 스킬을 골랐을 때만 펼침.
        bool showGroup = hasSkill && (_multiSkill ? (_phaseEnabled && ready) : true);

        SetRootActive(_offRoot, showGroup && _activeGroup == ESkillButtonGroup.Off);
        SetRootActive(_rotateRoot, showGroup && _activeGroup == ESkillButtonGroup.Rotate);
        SetRootActive(_directionRoot, showGroup && _activeGroup == ESkillButtonGroup.Direction);

        // 보일 때 버튼 상태 갱신: 클릭은 페이즈+준비됨에서만, 쿨다운이면 남은 턴 수 표시.
        if (showGroup && _activeButtons != null)
        {
            bool canCast = _phaseEnabled && ready;
            for (int i = 0; i < _activeButtons.Count; i++)
            {
                UIBattleSkillButton button = _activeButtons[i];
                bool directionAllowed = _tutorialAllowedDirection == ECardDirection.None
                    || (button != null && button.Direction == _tutorialAllowedDirection);
                button?.SetInteractable(canCast && directionAllowed);
                _activeButtons[i]?.SetCooldown(remaining, maxCooldown);
            }
        }

        // 그룹이 숨겨지면(3-스킬 쿨다운/미선택) 진행 중이던 시전도 취소한다.
        if (!showGroup && !immediateCastSkill)
            _skillCastInput?.CancelCast();

        // 실제 시전(타겟팅) 중일 때만 방향 버튼 하이라이트를 유지하고,
        // 그 외(스킬 사용 후·다른 행동으로 시전 해제 후)에는 항상 해제해 잔상을 막는다.
        if (_skillCastInput == null || !_skillCastInput.IsCasting)
            ClearButtonOverlays();
    }

    // ─────────────────────────────────────────────
    // 방향 버튼 클릭 / 선택 오버레이
    // ─────────────────────────────────────────────

    private void HandleSkillButtonClicked(ECardDirection direction)
    {
        if (_skillCastInput == null || _activeSkill == null) return;
        if (_tutorialAllowedDirection != ECardDirection.None
            && direction != _tutorialAllowedDirection)
        {
            return;
        }
        _skillCastInput.BeginCastWithDirection(_activeSkill, direction);

        if (_skillCastInput.IsCasting)
            ShowButtonOverlay(direction);
        else
            ClearButtonOverlays();
    }

    private void HandleSkillCastEnded()
    {
        // 캐스트 종료/취소 시 방향 버튼 선택 표시 정리.
        ClearButtonOverlays();

        // 3-스킬: 세부(방향) 선택뿐 아니라 스킬 선택(탭)도 함께 해제해 미선택 상태로 되돌린다.
        // (단일 스킬은 항상 그 스킬이 노출되므로 선택 해제 대상 아님)
        if (_multiSkill && _activeSkill != null)
        {
            SetActiveSkill(null);
        }
    }

    private void HandleSkillChanged()
    {
        PersistSkillCooldowns();
        HideSkillTooltip();
        RefreshActiveGroupVisibility();
    }

    private void PersistSkillCooldowns()
    {
        if (!InGameController.HasInstance) return;

        for (int i = 0; i < _skillRuntimes.Count; i++)
        {
            SkillRuntime runtime = _skillRuntimes[i];
            if (runtime?.Data == null) continue;
            InGameController.Instance.StoreSkillCooldown(
                runtime.Data.SkillId,
                runtime.RemainingCooldown);
        }
    }

    private void BeginImmediateCast(SkillRuntime skill)
    {
        if (_skillCastInput == null || skill == null) return;
        _skillCastInput.BeginCast(skill);
    }

    private static bool IsImmediateCastSkill(SkillRuntime skill)
    {
        return skill?.Data != null && !skill.Data.RequiresDirectionSelection;
    }

    private bool IsTutorialSkillAllowed(SkillRuntime skill)
    {
        return string.IsNullOrEmpty(_tutorialAllowedSkillId)
            || skill?.Data?.SkillId == _tutorialAllowedSkillId;
    }

    private bool ContainsScreenPoint(RectTransform rect, Vector2 screenPosition)
    {
        if (rect == null || !rect.gameObject.activeInHierarchy) return false;
        Camera uiCamera = _canvas != null && _canvas.renderMode != RenderMode.ScreenSpaceOverlay
            ? _canvas.worldCamera
            : null;
        return RectTransformUtility.RectangleContainsScreenPoint(rect, screenPosition, uiCamera);
    }

    private void ShowButtonOverlay(ECardDirection direction)
    {
        if (_activeButtons == null) return;
        for (int i = 0; i < _activeButtons.Count; i++)
        {
            UIBattleSkillButton button = _activeButtons[i];
            if (button != null)
                button.SetSelected(button.Direction == direction);
        }
    }

    private void ClearButtonOverlays()
    {
        ClearOverlay(_offButtons);
        ClearOverlay(_rotateButtons);
        ClearOverlay(_directionButtons);
    }

    private static void ClearOverlay(List<UIBattleSkillButton> buttons)
    {
        for (int i = 0; i < buttons.Count; i++)
            buttons[i]?.SetSelected(false);
    }

    // ─────────────────────────────────────────────
    // 그룹 Root / 캐싱 유틸
    // ─────────────────────────────────────────────

    private static void CacheButtons(GameObject root, List<UIBattleSkillButton> cache)
    {
        cache.Clear();
        if (root != null)
            root.transform.GetComponentsInChildren(true, cache);
    }

    private static void CacheSelectorButtons(GameObject root, List<UIBattleSkillSelectButton> cache)
    {
        cache.Clear();
        if (root != null)
            root.transform.GetComponentsInChildren(true, cache);
    }

    private static void SetRootActive(GameObject root, bool active)
    {
        if (root != null && root.activeSelf != active)
            root.SetActive(active);
    }

    private void SetAllRootsActive(bool active)
    {
        SetRootActive(_offRoot, active);
        SetRootActive(_rotateRoot, active);
        SetRootActive(_directionRoot, active);
    }

    private void SetSelectorActive(bool active)
    {
        SetRootActive(_skillSelectorRoot, active);
    }

    // ─────────────────────────────────────────────
    // 설명 툴팁 / 아이콘
    // ─────────────────────────────────────────────

    private void InitializeSkillTooltip()
    {
        _tooltipRect = _skillDescriptionRoot != null
            ? _skillDescriptionRoot.transform as RectTransform
            : null;

        if (_tooltipRect != null)
            _tooltipRect.SetAsLastSibling();

        if (_skillDescriptionRoot != null)
        {
            Graphic[] graphics = _skillDescriptionRoot.GetComponentsInChildren<Graphic>(true);
            for (int i = 0; i < graphics.Length; i++)
                graphics[i].raycastTarget = false;
        }

        HideSkillTooltip();
    }

    private void HandleSelectorHoverEntered(
        UIBattleSkillSelectButton button,
        SkillRuntime skill)
    {
        ShowSkillTooltip(button, skill);
    }

    private void HandleTooltipHoverExited(object owner)
    {
        if (!ReferenceEquals(_tooltipOwner, owner)) return;
        HideSkillTooltip();
    }

    private void ShowSkillTooltip(object owner, SkillRuntime skill)
    {
        if (owner == null || skill?.Data == null || _skillDescriptionRoot == null)
        {
            HideSkillTooltip();
            return;
        }

        _tooltipOwner = owner;
        _hoveredSkill = skill;

        if (_skillDescriptionText != null)
        {
            LocalizedFontUtility.ApplyCurrentFont(_skillDescriptionText);
            string descriptionKey = !string.IsNullOrEmpty(skill.Data.DescKey)
                ? skill.Data.DescKey
                : skill.Data.DescriptionKey;
            string description = ResolveLocalized(descriptionKey);
            string cooldown = ResolveLocalizedFormat(_cooldownFormatKey, skill.MaxCooldown);
            _skillDescriptionText.text = string.IsNullOrEmpty(description)
                ? cooldown
                : $"{description}\n{cooldown}";
        }

        if (!_skillDescriptionRoot.activeSelf)
            _skillDescriptionRoot.SetActive(true);
        _tooltipRect?.SetAsLastSibling();
    }

    private void HideSkillTooltip()
    {
        _tooltipOwner = null;
        _hoveredSkill = null;

        if (_skillDescriptionRoot != null && _skillDescriptionRoot.activeSelf)
            _skillDescriptionRoot.SetActive(false);
    }

    private async UniTaskVoid LoadGroupIconsAsync(SkillRuntimeData data, int version)
    {
        if (data == null || _activeButtons == null || !ResourceManager.HasInstance)
            return;

        for (int i = 0; i < _activeButtons.Count; i++)
        {
            UIBattleSkillButton button = _activeButtons[i];
            if (button == null) continue;

            string key = GetDetailIconKeyOrMain(data, i);
            if (string.IsNullOrEmpty(key))
                continue;

            Sprite sprite = await ResourceManager.Instance.LoadAtlasSpriteAsync(
                EAtlasType.CardIcon, key, this.GetCancellationTokenOnDestroy());
            if (this == null || version != _iconVersion)
                return;

            button.SetIcon(sprite);
        }
    }

    private static string GetDetailIconKeyOrMain(SkillRuntimeData data, int visibleIndex)
    {
        if (data == null) return string.Empty;
        if (data.DetailIconKeys != null && visibleIndex >= 0 && visibleIndex < data.DetailIconKeys.Count)
        {
            string key = data.DetailIconKeys[visibleIndex];
            if (!string.IsNullOrEmpty(key))
                return key;
        }
        return data.IconKey;
    }

    private static string ResolveLocalized(string key)
    {
        if (string.IsNullOrEmpty(key))
            return string.Empty;
        return LocalizationManager.HasInstance
            ? LocalizationManager.Instance.Get(key)
            : key;
    }

    private static string ResolveLocalizedFormat(string key, int value)
    {
        if (string.IsNullOrEmpty(key))
            return value.ToString();
        return LocalizationManager.HasInstance
            ? LocalizationManager.Instance.Get(key, value)
            : key;
    }

    private void OnDestroy()
    {
        if (_skillCastInput != null)
            _skillCastInput.OnCastEnded -= HandleSkillCastEnded;
        UnbindSkills();

    }
}
