using System;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "CastingOrbVisualSet", menuName = "Battle/Casting Orb Visual Set")]
public sealed class CastingOrbVisualSet : ScriptableObject
{
    [Serializable]
    private sealed class Entry
    {
        [Tooltip("매칭할 카드 ID")]
        [SerializeField] private string _cardId;

        [Tooltip("이 카드 캐스팅에 사용할 CastingOrb 프리팹")]
        [SerializeField] private CastingOrbView _prefab;

        public string CardId => _cardId;
        public CastingOrbView Prefab => _prefab;
    }

    [SerializeField] private List<Entry> _entries = new List<Entry>();

    public CastingOrbView FindPrefab(string cardId)
    {
        if (string.IsNullOrEmpty(cardId) || _entries == null)
        {
            return null;
        }

        for (int i = 0; i < _entries.Count; i++)
        {
            Entry entry = _entries[i];
            if (entry == null || entry.Prefab == null)
            {
                continue;
            }

            if (string.Equals(entry.CardId, cardId, StringComparison.Ordinal))
            {
                return entry.Prefab;
            }
        }

        return null;
    }
}
