// =================================================================
// [스크립트 목적]  전투 승리 보상 한 묶음(전리품)을 표현하는 POCO 모델.
//                 슬더스식 통합 보상창("전리품!")이 표시·수령할 항목들을 담는다.
//                 항목별 "수령 여부"를 추적해, 클릭 수령(1회) UI 를 데이터로 뒷받침한다.
// [주요 변수]      - Items        : 보상 항목 리스트 (골드/카드/…)
//                  - EBattleRewardKind : 항목 종류 (확장 시 유물/룬 추가)
// [의존 관계]      - InGameController 가 승리 시 생성(골드 추첨·카드 후보 주입)
//                  - (다음 단계) 통합 보상창 UI 가 Items 를 읽어 표시·수령
// [설계 노트]      - ★ 이 모델은 "무엇을 줄지"만 담는다. 실제 적용(RunContext.AddGold,
//                    AddCardToDeck)은 수령 처리 시 컨트롤러가 수행한다 (데이터/로직 분리).
//                  - 카드 항목은 "1택" 묶음(여러 후보 중 하나 선택)이라 후보 리스트를 들고,
//                    골드 항목은 단순 수치다. 종류별로 의미가 달라 한 클래스에 합산하지 않고
//                    Kind + 페이로드 필드로 구분한다(유물/룬 확장 시 필드만 추가).
//                  - 골드량 추첨(등급별 범위)은 컨트롤러 책임. 이 모델은 확정된 값만 보유.
// =================================================================

using System.Collections.Generic;

/// <summary>전투 보상 항목의 종류. 확장 시 Relic/Rune 등을 추가한다.</summary>
public enum EBattleRewardKind
{
    /// <summary>골드(런 단위 화폐).</summary>
    Gold = 0,

    /// <summary>카드 1택 (여러 후보 중 하나 선택).</summary>
    Card = 1,

    /// <summary>보스 격파 후 다음 스테이지의 그리드 확장 안내.</summary>
    GridExpansion = 2,

    // [확장 자리] 콘텐츠 추가 시 아래처럼 (기존 값 유지):
    // Relic = 3,   // 유물
    // Rune  = 4,   // 룬(영구 화폐일 수 있음 — 적용 시점에 분기)
    // Potion = 5,  // 포션
}

/// <summary>
/// 전투 보상 항목 1개. 종류(Kind)에 따라 의미 있는 페이로드 필드만 채워진다.
/// - Gold : GoldAmount 사용 (CardCandidates 는 비어 있음)
/// - Card : CardCandidates 사용 (GoldAmount 는 0). 그 중 1택 → ChosenCardId 에 기록
/// 수령 처리(클릭)되면 Claimed=true 로 표시해 중복 수령을 막는다.
/// </summary>
public sealed class BattleRewardItem
{
    /// <summary>이 항목의 종류.</summary>
    public EBattleRewardKind Kind { get; }

    /// <summary>골드 항목일 때의 골드량 (Card 항목은 0).</summary>
    public int GoldAmount { get; }

    /// <summary>카드 항목일 때의 후보들 (1택 대상). Gold 항목은 빈 리스트.</summary>
    public IReadOnlyList<CardDataSO> CardCandidates { get; private set; }
    public IReadOnlyList<ECardDirection> CardCandidateDirections { get; private set; }

    /// <summary>이미 수령했는지 여부. 수령 처리 시 컨트롤러가 MarkClaimed 로 설정.</summary>
    public bool Claimed { get; private set; }

    /// <summary>
    /// 카드 항목에서 실제 선택된 카드 ID (수령 시 기록). 스킵이거나 골드 항목이면 null.
    /// </summary>
    public string ChosenCardId { get; private set; }

    private BattleRewardItem(
        EBattleRewardKind kind,
        int goldAmount,
        IReadOnlyList<CardDataSO> cardCandidates,
        IReadOnlyList<ECardDirection> cardCandidateDirections = null)
    {
        Kind = kind;
        GoldAmount = goldAmount;
        CardCandidates = cardCandidates ?? System.Array.Empty<CardDataSO>();
        CardCandidateDirections = cardCandidateDirections ?? System.Array.Empty<ECardDirection>();
    }

    /// <summary>골드 보상 항목 생성.</summary>
    public static BattleRewardItem CreateGold(int amount)
    {
        return new BattleRewardItem(EBattleRewardKind.Gold, amount < 0 ? 0 : amount, null);
    }

    /// <summary>카드 1택 보상 항목 생성 (후보 리스트 주입).</summary>
    public static BattleRewardItem CreateCard(
        IReadOnlyList<CardDataSO> candidates,
        IReadOnlyList<ECardDirection> directions = null)
    {
        return new BattleRewardItem(EBattleRewardKind.Card, 0, candidates, directions);
    }

    /// <summary>그리드 확장 안내 항목 생성.</summary>
    public static BattleRewardItem CreateGridExpansion()
    {
        return new BattleRewardItem(EBattleRewardKind.GridExpansion, 0, null);
    }

    /// <summary>수령 완료 표시 (골드·유물 등 선택지 없는 항목). 중복 수령 방지.</summary>
    public void MarkClaimed()
    {
        Claimed = true;
    }

    /// <summary>카드 1택 수령 완료 표시 (선택 카드 ID 기록, 스킵이면 null).</summary>
    public void MarkClaimedCard(string chosenCardId)
    {
        ChosenCardId = chosenCardId;
        Claimed = true;
    }

    public bool ReplaceCardCandidates(IReadOnlyList<CardDataSO> candidates)
    {
        if (Kind != EBattleRewardKind.Card || Claimed || candidates == null || candidates.Count == 0)
            return false;
        CardCandidates = candidates;
        CardCandidateDirections = System.Array.Empty<ECardDirection>();
        return true;
    }
}

/// <summary>
/// 전투 1회의 보상 묶음(전리품). 골드·카드 등 여러 항목을 담는다.
/// 생성은 컨트롤러가, 표시·수령은 통합 보상창 UI 가 담당한다(다음 단계).
/// </summary>
public sealed class BattleReward
{
    private readonly List<BattleRewardItem> _items = new List<BattleRewardItem>(4);

    /// <summary>보상 항목 목록 (읽기 전용).</summary>
    public IReadOnlyList<BattleRewardItem> Items => _items;

    /// <summary>보상 항목이 하나라도 있는지 (보상창 노출 판단용).</summary>
    public bool HasAny => _items.Count > 0;

    /// <summary>아직 수령하지 않은 항목이 남아 있는지 ("받기 완료" 판단용).</summary>
    public bool HasUnclaimed
    {
        get
        {
            for (int i = 0; i < _items.Count; i++)
            {
                if (!_items[i].Claimed) return true;
            }
            return false;
        }
    }

    /// <summary>골드 항목 추가 (amount &gt; 0 일 때만).</summary>
    public void AddGold(int amount)
    {
        if (amount <= 0) return;
        _items.Add(BattleRewardItem.CreateGold(amount));
    }

    /// <summary>카드 1택 항목 추가 (후보가 1장 이상일 때만).</summary>
    public BattleRewardItem AddCardChoice(
        IReadOnlyList<CardDataSO> candidates,
        IReadOnlyList<ECardDirection> directions = null)
    {
        if (candidates == null || candidates.Count == 0) return null;
        BattleRewardItem item = BattleRewardItem.CreateCard(candidates, directions);
        _items.Add(item);
        return item;
    }

    /// <summary>보스 격파 후 그리드 확장 안내 항목 추가.</summary>
    public void AddGridExpansion()
    {
        _items.Add(BattleRewardItem.CreateGridExpansion());
    }
}
