// =================================================================
// [스크립트 목적]  전투 스킬 패널의 개별 방향/회전/off 버튼 1개.
//                  자신의 버튼·방향·아이콘·선택 오버레이를 캐싱하고, 클릭 시 방향을 콜백한다.
// [주요 변수]      - _button   : 클릭 버튼
//                  - _direction: 이 버튼이 의미하는 방향 (off 는 None, 회전은 Left/Right)
//                  - _icon     : 방향 아이콘 Image
//                  - _selectedOverlay : 시전 중 선택 표시 오버레이
// [의존 관계]      - UIBattleSkillPanel 이 Bind/SetIcon/SetSelected/SetInteractable 호출
// =================================================================

using System;
using Cysharp.Threading.Tasks;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

[RequireComponent(typeof(Button))]
public sealed class UIBattleSkillButton : MonoBehaviour, IPointerClickHandler
{
    [Tooltip("클릭 버튼. 비우면 같은 오브젝트의 Button 자동 캐싱")]
    [SerializeField] private Button _button;

    [Tooltip("이 버튼이 의미하는 방향. off=None, 회전=Left/Right, 방향=상하좌우")]
    [SerializeField] private ECardDirection _direction = ECardDirection.None;

    [Tooltip("방향 아이콘 Image. 비우면 버튼 하위 Image 자동 탐색")]
    [SerializeField] private Image _icon;

    [Tooltip("시전 중 이 버튼이 선택되었음을 표시할 오버레이 (선택)")]
    [SerializeField] private GameObject _selectedOverlay;

    [Tooltip("쿨다운 중 켜질 오버레이 (선택, 단일 캐릭터용)")]
    [SerializeField] private GameObject _cooldownOverlay;

    [Tooltip("남은 쿨다운 턴 수 텍스트 (선택)")]
    [SerializeField] private TMP_Text _cooldownText;

    [Tooltip("쿨다운 게이지 Image (선택). 코드는 fillAmount(남은턴/최대턴)만 갱신하며, Fill Method·Clockwise·Origin 은 인스펙터 설정을 따른다")]
    [SerializeField] private Image _cooldownFill;

    /// <summary>이 버튼이 의미하는 방향.</summary>
    public ECardDirection Direction => _direction;

    private Action<ECardDirection> _clicked;
    private bool _bound;
    private int _remainingCooldown;

    public void Bind(Action<ECardDirection> clicked)
    {
        if (_button == null)
            _button = GetComponent<Button>();

        _clicked = clicked;
        if (_button != null && !_bound)
        {
            _button.onClick.AddListener(HandleClicked);
            _bound = true;
        }

        SetSelected(false);
    }

    public void Unbind()
    {
        _clicked = null;
        SetSelected(false);
    }

    /// <summary>버튼 입력 가능 여부.</summary>
    public void SetInteractable(bool value)
    {
        if (_button != null)
            _button.interactable = value;
    }

    /// <summary>남은 쿨다운 표시. remaining&gt;0 이면 오버레이+턴 수+게이지, 0이면 숨김.</summary>
    public void SetCooldown(int remaining, int max)
    {
        _remainingCooldown = Mathf.Max(0, remaining);
        bool onCooldown = _remainingCooldown > 0;
        if (_cooldownOverlay != null && _cooldownOverlay.activeSelf != onCooldown)
            _cooldownOverlay.SetActive(onCooldown);
        if (_cooldownText != null)
        {
            LocalizedFontUtility.ApplyCurrentFont(_cooldownText);
            _cooldownText.text = onCooldown ? _remainingCooldown.ToString() : string.Empty;
        }

        UICooldownFillUtility.Apply(_cooldownFill, _remainingCooldown, max);
    }

    /// <summary>선택 오버레이 on/off.</summary>
    public void SetSelected(bool on)
    {
        if (_selectedOverlay != null && _selectedOverlay.activeSelf != on)
            _selectedOverlay.SetActive(on);
    }

    /// <summary>방향 아이콘 스프라이트 지정.</summary>
    public void SetIcon(Sprite sprite)
    {
        Image image = _icon != null ? _icon : ResolveIconImage();
        if (image == null) return;

        image.sprite = sprite;
        image.enabled = sprite != null;
        image.rectTransform.localRotation = Quaternion.identity;
    }

    private Image ResolveIconImage()
    {
        if (_button == null) return null;

        Image[] images = _button.GetComponentsInChildren<Image>(true);
        for (int i = 0; i < images.Length; i++)
        {
            if (images[i] != null && images[i] != _button.targetGraphic)
                return images[i];
        }

        return _button.targetGraphic as Image;
    }

    private void HandleClicked()
    {
        _clicked?.Invoke(_direction);
    }

    public void OnPointerClick(PointerEventData eventData)
    {
        if (eventData.button != PointerEventData.InputButton.Left || _remainingCooldown <= 0) return;
        if (AudioManager.HasInstance)
            AudioManager.Instance.PlaySfxAsync(AudioKeys.Card.CANNOT_LOCATE).Forget();
    }

    private void OnDestroy()
    {
        if (_button != null && _bound)
            _button.onClick.RemoveListener(HandleClicked);
        _bound = false;
        _clicked = null;
    }
}
