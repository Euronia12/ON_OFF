using UnityEngine;

// Unity가 생성한 기존 프로젝트 파일의 컴파일 항목 호환용 빈 타입.
// 캐스팅 상태 표시는 UIBattleBuffIcon으로 이동했다.
public sealed class UICastingQueuePanel : MonoBehaviour
{
}
