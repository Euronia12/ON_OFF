using System;
using Cysharp.Threading.Tasks;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public sealed class UIBattleBuffIcon : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler
{
    [SerializeField] private Image _icon;
    [SerializeField] private TMP_Text _countText;

    private int _loadVersion;
    private string _iconKey;
    private Action<UIBattleBuffIcon> _pointerEnter;
    private Action<UIBattleBuffIcon> _pointerExit;

    public void Bind(BattleBuffView view)
    {
        if (_countText != null)
        {
            _countText.text = view.RemainingCount.ToString();
        }

        if (_iconKey == view.IconKey) return;

        _iconKey = view.IconKey;
        LoadIconAsync(_iconKey, ++_loadVersion).Forget();
    }

    public void Bind(Sprite sprite, string countText)
    {
        _loadVersion++;
        _iconKey = null;
        if (_icon != null)
        {
            _icon.sprite = sprite;
            _icon.enabled = sprite != null;
        }

        if (_countText != null)
        {
            _countText.text = countText ?? string.Empty;
            _countText.enabled = !string.IsNullOrEmpty(countText);
        }
    }

    public void SetHoverHandlers(Action<UIBattleBuffIcon> pointerEnter, Action<UIBattleBuffIcon> pointerExit)
    {
        _pointerEnter = pointerEnter;
        _pointerExit = pointerExit;
        if (_icon != null)
        {
            _icon.raycastTarget = pointerEnter != null || pointerExit != null;
        }
    }

    public void OnPointerEnter(PointerEventData eventData)
    {
        _pointerEnter?.Invoke(this);
    }

    public void OnPointerExit(PointerEventData eventData)
    {
        _pointerExit?.Invoke(this);
    }

    private async UniTaskVoid LoadIconAsync(string iconKey, int version)
    {
        if (_icon != null)
        {
            _icon.sprite = null;
            _icon.enabled = false;
        }

        if (string.IsNullOrEmpty(iconKey) || !ResourceManager.HasInstance)
        {
            return;
        }

        Sprite sprite = await ResourceManager.Instance.LoadAtlasSpriteAsync(
            EAtlasType.CardIcon,
            iconKey,
            this.GetCancellationTokenOnDestroy());
        if (this == null || version != _loadVersion || _icon == null)
        {
            return;
        }

        _icon.sprite = sprite;
        _icon.enabled = sprite != null;
    }
}
