// =================================================================
// [스크립트 목적]  전투 화면 UI (UIBase). 플레이어/적 상태 위젯 + 턴 종료 버튼 +
//                 드로우/디스카드 더미 위치 보유. 손패(UICardHand)는 자식으로 둠.
//                 ※ 동적 생성 UI라 자식 참조를 BattleController에 직접 전달(Refs).
// [주요 변수]      - _playerStatus/_enemyStatus : 액터 상태 위젯 (재사용)
//                  - _endTurnButton : 턴 종료 버튼
//                  - _drawPileRect/_discardPileRect : 카드 연출 시작·도착 위치
//                  - _cardHand/_placement/_playerView/_enemyView : 전투 씬 참조(자식)
// [의존 관계]      - UIBase / UIActorStatus / UIEnemyIntentView / BattleManager / UICardHand
//                  - CardPlacementController / PlayerView / EnemyView
//                  - CardAnimationSystem 이 DrawPileRect/DiscardPileRect 참조
// [배치]           UIManager 로 여는 전투 화면. BattleController 가 Bind 로 액터 연결
// [설계 노트]      - 액터 표시는 위젯에 위임 (플레이어/적 같은 위젯 재사용)
//                  - 손패/배치/뷰 참조는 이 프리팹 자식이므로 UIBattle 이 소유하고,
//                    BattleController 는 BattleSceneRefs 로 일괄 수령(동적 생성 null 해결)
// =================================================================

using Cysharp.Threading.Tasks;
using System.Collections.Generic;
using System.Threading;
using TMPro;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.UI;

/// <summary>
/// 전투 화면. 플레이어/적 상태 위젯과 턴 종료 버튼을 조립하고,
/// 카드 연출용 더미 위치(드로우/디스카드)와 전투 씬 참조(손패·배치·뷰)를 제공한다.
/// 액터 연결은 BattleController 가 BindActors 로 수행한다.
/// </summary>
public sealed class UIBattle : UIBase
{
    [Header("액터 상태 위젯")]
    [Tooltip("플레이어 상태 위젯 (HP·방어막·에너지)")]
    [SerializeField] private UIActorStatus _playerStatus;

    [Tooltip("적 상태 위젯 (HP·방어막)")]
    [SerializeField] private UIActorStatus _enemyStatus;

    [Tooltip("적 의도 위젯 (다중 의도 아이콘+수치). 미연결 시 의도 미표시")]
    [SerializeField] private UIEnemyIntentView _enemyIntentView;

    [Header("턴 진행")]
    [Tooltip("턴 종료 버튼")]
    [SerializeField] private Button _endTurnButton;

    [Tooltip("보존 페이즈 안내 텍스트")]
    [SerializeField] private TMP_Text _preserveText;

    [Tooltip("보존 선택 확정 버튼")]
    [SerializeField] private Button _preserveButton;

    [Header("고정 텍스트")]
    [Tooltip("드로우 더미 라벨")]
    [SerializeField] private TMP_Text _drawPileLabelText;

    [Tooltip("디스카드 더미 라벨")]
    [SerializeField] private TMP_Text _discardPileLabelText;

    [Header("더미 카드 개수")]
    [Tooltip("드로우 더미에 남은 카드 수 표시")]
    [SerializeField] private TMP_Text _drawPileCountText;

    [Tooltip("디스카드 더미(묘지)에 쌓인 카드 수 표시")]
    [SerializeField] private TMP_Text _discardPileCountText;

    [Tooltip("턴 종료 버튼 텍스트")]
    [SerializeField] private TMP_Text _endTurnButtonText;

    [Tooltip("보존 선택 확정 버튼 텍스트")]
    [SerializeField] private TMP_Text _preserveButtonText;

    [Tooltip("적 의도 라벨")]
    [SerializeField] private TMP_Text _enemyIntentLabelText;

    [Header("스킬")]
    [Tooltip("전투 스킬 패널. 비우면 자식에서 자동 탐색")]
    [SerializeField] private UIBattleSkillPanel _skillPanel;

    [Tooltip("스킬 선택 단계에 따라 현재 입력 안내를 표시하는 텍스트")]
    [SerializeField] private TMP_Text _skillPromptText;

    [Header("더미 보기 버튼")]
    [Tooltip("드로우 더미 버튼 (카드 목록 팝업 열기)")]
    [SerializeField] private Button _drawPileButton;

    [Tooltip("디스카드 더미 버튼 (카드 목록 팝업 열기)")]
    [SerializeField] private Button _discardPileButton;

    [Tooltip("소멸 더미 버튼 (카드 목록 팝업 열기)")]
    [SerializeField] private Button _exhaustPileButton;

    [Header("손패 / 입력")]
    [Tooltip("손패 UI (이 UIBattle 의 자식)")]
    [SerializeField] private UICardHand _cardHand;

    [Tooltip("카드 배치 입력 어댑터 (이 UIBattle 의 자식). null 이면 손패에서 자동 탐색")]
    [SerializeField] private CardPlacementInput _placement;

    [Header("카드 연출 더미 위치")]
    [Tooltip("드로우 시작 위치 (덱 더미)")]
    [SerializeField] private RectTransform _drawPileRect;

    [Tooltip("디스카드 도착 위치 (묘지 더미)")]
    [SerializeField] private RectTransform _discardPileRect;

    [Header("캐스팅 오브")]
    [Tooltip("캐스팅 오브 호버 시 표시할 정보 패널 프리팹")]
    [SerializeField] private RectTransform _castingOrbInfoPanelPrefab;

    [Header("버프")]
    [SerializeField] private RectTransform _buffRoot;
    [SerializeField] private UIBattleBuffIcon _buffIconPrefab;
    [Tooltip("EraseInfo 디버프에 사용할 적 의도 아이콘 매핑")]
    [SerializeField] private IntentIconSO _intentIconSet;
    [Tooltip("BuffRoot 아이콘 호버 설명에 사용할 기존 적 의도 패널")]
    [SerializeField] private UIEnemyIntentPanel _buffTooltipPanel;
    [Tooltip("디버프 아이콘 아래에 표시할 툴팁 위치 오프셋(px)")]
    [SerializeField] private Vector2 _buffTooltipOffset = new Vector2(0f, -12f);
    [SerializeField] private UIEnemyEliteBuffStatusPanel _enemyEliteBuffStatusPanel;

    /// <summary>CardAnimationSystem 이 드로우 시작 위치로 참조.</summary>
    public RectTransform DrawPileRect => _drawPileRect;

    /// <summary>CardAnimationSystem 이 디스카드 도착 위치로 참조.</summary>
    public RectTransform DiscardPileRect => _discardPileRect;

    /// <summary>손패 UI 접근 (BattleController 가 드로우 시 사용).</summary>
    public UICardHand CardHand => _cardHand;

    /// <summary>배치 어댑터 접근.</summary>
    public CardPlacementInput Placement => _placement;

    /// <summary>튜토리얼 스킬 제한을 설정할 전투 스킬 패널.</summary>
    public UIBattleSkillPanel SkillPanel => _skillPanel;

    public void TickSkillCooldownForBattleClear()
    {
        _skillPanel?.TickTurnEnd();
    }

    /// <summary>테스트 커맨드용 스킬 쿨타임 초기화. 스킬 패널은 이 전투 UI가 소유한다.</summary>
    public bool TryResetDebugSkillCooldowns()
    {
        return _skillPanel != null && _skillPanel.TryResetDebugCooldowns();
    }

    private EnemySpeechBubble _enemySpeechBubble;
    private CastingOrbHoverProbe _castingOrbHoverProbe;
    private readonly Dictionary<int, UIBattleBuffIcon> _buffIcons = new Dictionary<int, UIBattleBuffIcon>(8);
    private readonly List<int> _removedBuffIds = new List<int>(8);
    private CardPhaseDispatcher _buffDispatcher;
    private GridManager _cardInfoGrid;
    private UIBattleBuffIcon _eraseInfoDebuffIcon;

    // ── 초기화 ──────────────────────────────────────────────

    protected override void Init()
    {
        RefreshLocalizedTexts();

        // 턴 종료 버튼 리스너 등록 (최초 1회).
        if (_endTurnButton != null)
        {
            _endTurnButton.onClick.AddListener(HandleEndTurnClicked);
        }

        if (_preserveButton != null)
        {
            _preserveButton.onClick.AddListener(HandlePreserveClicked);
            _preserveButton.gameObject.SetActive(false);
        }

        if (_preserveText != null)
        {
            _preserveText.gameObject.SetActive(false);
        }

        if (_skillPanel == null)
            _skillPanel = GetComponentInChildren<UIBattleSkillPanel>(true);
        _skillPanel?.Initialize();
        if (_skillPanel != null)
        {
            _skillPanel.OnSelectionStateChanged -= SyncSkillSelectionVisual;
            _skillPanel.OnSelectionStateChanged += SyncSkillSelectionVisual;
        }

        // 스킬 타겟팅 시작/종료에 맞춰 손패를 흐리게/복원 — "손패는 스킬 대상 아님"을 알린다.
        SkillCastInput castInput = _skillPanel != null ? _skillPanel.CastInput : null;
        if (castInput != null)
        {
            castInput.OnCastStarted -= HandleSkillCastStarted;
            castInput.OnCastStarted += HandleSkillCastStarted;
            castInput.OnCastEnded -= HandleSkillCastEnded;
            castInput.OnCastEnded += HandleSkillCastEnded;
        }

        // 더미 보기 버튼 리스너 등록 (최초 1회).
        if (_drawPileButton != null)
        {
            _drawPileButton.onClick.AddListener(HandleDrawPileClicked);
        }

        if (_discardPileButton != null)
        {
            _discardPileButton.onClick.AddListener(HandleDiscardPileClicked);
        }

        if (_exhaustPileButton != null)
        {
            _exhaustPileButton.onClick.AddListener(HandleExhaustPileClicked);
        }

        // 배치 어댑터를 인스펙터에서 안 꽂았다면 자식에서 1회 탐색 (안전망).
        if (_placement == null && _cardHand != null)
        {
            _placement = _cardHand.GetComponentInParent<CardPlacementInput>();
        }

        // 손패 카드 드래그 시작 → 진행 중이던 스킬 시전 해제 (스킬 패널 경유). 수동 배선 불필요.
        if (_placement != null && _skillPanel != null)
        {
            _placement.SetSkillCanceller(_skillPanel.CancelCast);
        }

        EnsureEnemySpeechBubble();
        EnsureCastingOrbHoverProbe();

#if UNITY_EDITOR || DEVELOPMENT_BUILD
        Debug.Assert(_cardHand != null, $"[{name}] UIBattle: _cardHand 미할당.");
        Debug.Assert(_placement != null, $"[{name}] UIBattle: _placement 미할당.");
#endif
    }

    public override void OnLocalize()
    {
        base.OnLocalize();
        RefreshLocalizedTexts();
        _skillPanel?.RefreshLocalization();
        _castingOrbHoverProbe?.RefreshLocalization();
        SyncSkillSelectionVisual();
    }

    private void RefreshLocalizedTexts()
    {
        if (_drawPileLabelText != null)
            _drawPileLabelText.text = Localize(LocalizationKeys.Battle.DrawPile);
        if (_discardPileLabelText != null)
            _discardPileLabelText.text = Localize(LocalizationKeys.Battle.DiscardPile);
        if (_endTurnButtonText != null)
            _endTurnButtonText.text = Localize(LocalizationKeys.Battle.EndTurn);
        if (_preserveButtonText != null)
            _preserveButtonText.text = Localize(LocalizationKeys.Battle.PreserveConfirm);
        if (_enemyIntentLabelText != null)
            _enemyIntentLabelText.text = Localize(LocalizationKeys.Battle.EnemyIntent);

        if (BattleManager.HasInstance)
        {
            BattleManager battle = BattleManager.Instance;
            HandlePreserveSelectionChanged(battle.CurrentPreserveSelectedCount, battle.MaxPreserveCount);
        }
    }

    // ── 액터 바인딩 (BattleController 가 호출) ───────────────

    /// <summary>플레이어/적 액터를 상태 위젯에 연결 + 페이즈 구독(턴종료 버튼 자동 잠금).</summary>
    public void BindActors(PlayerActor player, EnemyActor enemy)
    {
        if (_cardHand != null) _cardHand.BindPlayer(player);

        if (_playerStatus != null) _playerStatus.BindPlayer(player);
        else Debug.LogWarning("[UIBattle] _playerStatus 미연결 — 플레이어 HP/에너지 표시 불가. Inspector 확인.");

        if (_enemyStatus != null) _enemyStatus.BindEnemy(enemy);
        else Debug.LogWarning("[UIBattle] _enemyStatus 미연결 — 적 HP/방어막 표시 불가. Inspector 확인.");

        // 적 의도(다중)는 별도 위젯이 담당. 미연결이면 의도만 안 보일 뿐 전투엔 지장 없음.
        if (_enemyIntentView != null) _enemyIntentView.Bind(enemy);

#if UNITY_EDITOR || DEVELOPMENT_BUILD
        if (enemy == null)
            Debug.LogWarning("[UIBattle] BindActors 의 enemy 가 null 입니다. 적 셋업 순서를 확인하세요.");
#endif

        // 페이즈 변화에 따라 턴종료 버튼을 자동 잠금/해제 (처리 중 연타 방지).
        if (BattleManager.HasInstance)
        {
            BattleManager battle = BattleManager.Instance;
            battle.OnPhaseChanged -= HandlePhaseChanged; // 중복 구독 방지
            battle.OnPhaseChanged += HandlePhaseChanged;
            battle.OnProcessingChanged -= HandleProcessingChanged;
            battle.OnProcessingChanged += HandleProcessingChanged;
            battle.OnPreserveSelectionChanged -= HandlePreserveSelectionChanged;
            battle.OnPreserveSelectionChanged += HandlePreserveSelectionChanged;
            battle.OnPreserveLimitExceeded -= HandlePreserveLimitExceeded;
            battle.OnPreserveLimitExceeded += HandlePreserveLimitExceeded;

            // 현재 상태 즉시 반영.
            _skillPanel?.BindSkills();
            HandlePhaseChanged(battle.CurrentPhase);
            HandlePreserveSelectionChanged(battle.CurrentPreserveSelectedCount, battle.MaxPreserveCount);
        }

        // 더미 개수 카운터 — 드로우/디스카드/셔플마다 갱신.
        if (BattleController.HasInstance)
        {
            BattleController.Instance.OnPilesChanged -= RefreshPileCounts; // 중복 구독 방지
            BattleController.Instance.OnPilesChanged += RefreshPileCounts;
            RefreshPileCounts(); // 현재 상태 즉시 반영
        }
    }

    internal UniTask WaitForEnemyHpTweenAsync(CancellationToken token)
    {
        return _enemyStatus != null
            ? _enemyStatus.WaitForHpTweenAsync(token)
            : UniTask.CompletedTask;
    }

    public void BindEnemySpeechTarget(Transform target)
    {
        EnsureEnemySpeechBubble();
        _enemySpeechBubble?.BindTarget(target);
    }

    public void ShowEnemySpeech(EnemySpeechLine speech)
    {
        EnsureEnemySpeechBubble();
        _enemySpeechBubble?.Show(speech);
    }

    public void ShowTempWorldText(Vector3 worldPosition, string text)
    {
        if (string.IsNullOrWhiteSpace(text)) return;

        BattleTempText.Show(
            transform as RectTransform,
            GetComponentInParent<Canvas>(),
            worldPosition,
            text);
    }

    public void BindBuffs(CardPhaseDispatcher dispatcher)
    {
        if (_buffDispatcher == dispatcher)
        {
            RefreshBuffs();
            return;
        }

        UnbindBuffs();
        _buffDispatcher = dispatcher;
        if (_buffDispatcher != null)
        {
            _buffDispatcher.OnBuffChanged += RefreshBuffs;
        }

        RefreshBuffs();
    }

    public void BindCardInfoHidden(GridManager grid)
    {
        if (_cardInfoGrid == grid)
        {
            HandleCardInfoHiddenChanged(grid != null && grid.IsCardInfoHidden);
            return;
        }

        UnbindCardInfoHidden();
        _cardInfoGrid = grid;
        if (_cardInfoGrid != null)
        {
            _cardInfoGrid.OnCardInfoHiddenChanged += HandleCardInfoHiddenChanged;
        }

        HandleCardInfoHiddenChanged(_cardInfoGrid != null && _cardInfoGrid.IsCardInfoHidden);
    }

    /// <summary>액터 연결 해제 + 페이즈/처리 구독 해제 (전투 종료 시).</summary>
    public void BindEnemyEliteBuffs(EnemyEliteBuffController controller, EnemyActor enemy)
    {
        _enemyEliteBuffStatusPanel?.Bind(controller, enemy);
    }

    public void RefreshEnemyBossPhaseBuff()
    {
        _enemyEliteBuffStatusPanel?.RefreshBossPhase();
    }

    public void UnbindActors()
    {
        if (_cardHand != null) _cardHand.UnbindPlayer();
        if (_playerStatus != null) _playerStatus.Unbind();
        if (_enemyStatus != null) _enemyStatus.Unbind();
        if (_enemyIntentView != null) _enemyIntentView.Unbind();

        if (BattleManager.HasInstance)
        {
            BattleManager.Instance.OnPhaseChanged -= HandlePhaseChanged;
            BattleManager.Instance.OnProcessingChanged -= HandleProcessingChanged;
            BattleManager.Instance.OnPreserveSelectionChanged -= HandlePreserveSelectionChanged;
            BattleManager.Instance.OnPreserveLimitExceeded -= HandlePreserveLimitExceeded;
        }

        if (BattleController.HasInstance)
            BattleController.Instance.OnPilesChanged -= RefreshPileCounts;

        _skillPanel?.UnbindSkills();

        _enemySpeechBubble?.Hide();
        UnbindBuffs();
        UnbindCardInfoHidden();
        _enemyEliteBuffStatusPanel?.Unbind();
        _castingOrbHoverProbe?.Hide();
    }

    /// <summary>드로우·디스카드 더미 카드 수 갱신. 드로우마다 호출되므로 GC 없는 SetText 오버로드를 쓴다.</summary>
    private void RefreshPileCounts()
    {
        if (!BattleController.HasInstance) return;

        BattleController controller = BattleController.Instance;
        if (_drawPileCountText != null)
            _drawPileCountText.SetText("{0}", controller.DrawPileCount);
        if (_discardPileCountText != null)
            _discardPileCountText.SetText("{0}", controller.DiscardPileCount);
    }

    /// <summary>페이즈 변화 처리 — PlayerInput 에서는 턴 종료, PreserveSelect 에서는 보존 UI만 활성.</summary>
    private void HandlePhaseChanged(EBattlePhase phase)
    {
        BattleManager battle = BattleManager.HasInstance ? BattleManager.Instance : null;
        bool isPreserveSelect = phase == EBattlePhase.PreserveSelect
                                && battle != null
                                && !battle.IsPreserveAll;
        bool canEndTurn = phase == EBattlePhase.PlayerInput
                          && battle != null
                          && !battle.IsProcessing;
        bool canConfirmPreserve = isPreserveSelect
                                  && battle != null
                                  && !battle.IsProcessing;

        SetEndTurnVisible(!isPreserveSelect);
        SetEndTurnInteractable(canEndTurn);
        SetPreserveVisible(isPreserveSelect);
        SetPreserveInteractable(canConfirmPreserve);
        _skillPanel?.SetPhaseEnabled(phase == EBattlePhase.PlayerInput && battle != null && !battle.IsProcessing);

        if (phase == EBattlePhase.PlayerResolve)
        {
            _skillPanel?.TickTurnEnd();
            _skillPanel?.CancelCast();
        }
        else if (phase != EBattlePhase.PlayerInput)
        {
            _skillPanel?.CancelCast();
        }
    }

    /// <summary>처리 중 상태 변화 — 처리 중이면 무조건 잠금, 끝나면 페이즈 기준 재평가.</summary>
    private void HandleProcessingChanged(bool processing)
    {
        if (processing)
        {
            SetEndTurnInteractable(false);
            _skillPanel?.SetPhaseEnabled(false);
            // 체인 시작 시 즉시 시전을 해제하고 손패 표시도 동기화한다.
            // Update에서 다음 프레임에 취소되기를 기다리면 이벤트 순서에 따라 흐림이 남을 수 있다.
            _skillPanel?.CancelCast();
            SyncSkillSelectionVisual();
        }
        else if (BattleManager.HasInstance)
        {
            HandlePhaseChanged(BattleManager.Instance.CurrentPhase);
            SyncSkillSelectionVisual();
        }
    }

    // ── 스킬 타겟팅 중 손패 흐림 ────────────────────────────

    /// <summary>스킬 타겟팅 시작 — 손패를 흐리게 해 그리드 카드만 대상임을 알린다.</summary>
    private void HandleSkillCastStarted()
    {
        SyncSkillSelectionVisual();
    }

    /// <summary>스킬 타겟팅 종료(적용/취소) — 손패 복원.</summary>
    private void HandleSkillCastEnded()
    {
        SyncSkillSelectionVisual();
    }

    /// <summary>이벤트 순서와 무관하게 실제 시전 상태를 기준으로 손패 흐림을 맞춘다.</summary>
    private void SyncSkillSelectionVisual()
    {
        bool active = _skillPanel != null && _skillPanel.IsSelectionGuideActive;
        _cardHand?.SetSkillSelectionActive(active);

        if (_skillPromptText == null) return;

        string promptKey = active ? _skillPanel.ActivePromptKey : string.Empty;
        bool showPrompt = !string.IsNullOrEmpty(promptKey);
        _skillPromptText.gameObject.SetActive(showPrompt);
        if (!showPrompt) return;

        LocalizedFontUtility.ApplyCurrentFont(_skillPromptText);
        _skillPromptText.text = Localize(promptKey);
    }

    // ── 턴 종료 ─────────────────────────────────────────────

    /// <summary>턴 종료 버튼 클릭. 손패를 묘지로 보낸 뒤 보존 페이즈로 진입한다.</summary>
    private void HandleEndTurnClicked()
    {
        if (!BattleManager.HasInstance) return;

        BattleManager battle = BattleManager.Instance;
        if (battle.CurrentPhase == EBattlePhase.PlayerInput)
        {
            battle.ConfirmPlayerTurn();
        }
    }

    private void HandlePreserveClicked()
    {
        if (!BattleManager.HasInstance) return;

        BattleManager battle = BattleManager.Instance;
        if (battle.CurrentPhase == EBattlePhase.PreserveSelect)
        {
            battle.ConfirmPreserveSelect();
        }
    }

    private void HandlePreserveSelectionChanged(int selected, int max)
    {
        if (_preserveText != null)
            _preserveText.text = string.Format(Localize(LocalizationKeys.Battle.PreserveSelectFormat), selected, max);
    }

    private void HandlePreserveLimitExceeded()
    {
        if (AudioManager.HasInstance)
            AudioManager.Instance.PlayUiAsync(AudioKeys.Ui.FAILURE).Forget();
        ShowPreserveLimitExceededAsync().Forget();
    }

    private async UniTaskVoid ShowPreserveLimitExceededAsync()
    {
        if (!UIManager.HasInstance) return;

        UISystemNavi systemNavi = await UIManager.Instance.OpenAsync<UISystemNavi>();
        systemNavi?.Show(LocalizationKeys.Battle.PreserveLimitExceeded);
    }

    private static string Localize(string key)
    {
        return LocalizationManager.HasInstance
            ? LocalizationManager.Instance.Get(key)
            : key;
    }

    /// <summary>턴 종료 버튼 활성/비활성 (처리 중 입력 차단용).</summary>
    public void SetEndTurnInteractable(bool interactable)
    {
        if (_endTurnButton != null)
        {
            _endTurnButton.interactable = interactable;
        }
    }

    /// <summary>튜토리얼 등 특수 흐름에서 턴 종료 버튼 오브젝트 자체를 숨기거나 표시한다.</summary>
    public void SetEndTurnVisible(bool visible)
    {
        if (_endTurnButton != null)
        {
            _endTurnButton.gameObject.SetActive(visible);
        }
    }

    /// <summary>
    /// 튜토리얼 등 특수 흐름에서 스킬 패널 사용을 잠그거나 푼다.
    /// 페이즈 전환·처리 상태 갱신(RefreshPhaseUI/SetProcessing)이 다시 덮어쓸 수 있으므로
    /// 잠근 쪽이 해제 시점을 책임진다.
    /// </summary>
    public void SetSkillPanelInteractable(bool interactable)
    {
        _skillPanel?.SetPhaseEnabled(interactable);
    }

    private void SetPreserveVisible(bool visible)
    {
        if (_preserveText != null)
            _preserveText.gameObject.SetActive(visible);
        if (_preserveButton != null)
            _preserveButton.gameObject.SetActive(visible);
    }

    private void SetPreserveInteractable(bool interactable)
    {
        if (_preserveButton != null)
            _preserveButton.interactable = interactable;
    }

    // ── 더미 보기 ───────────────────────────────────────────

    /// <summary>드로우 더미 버튼 클릭 → 드로우 목록 팝업 열기.</summary>
    private void HandleDrawPileClicked()
    {
        UICardPileViewer.ShowDrawPile();
        OpenPileViewer();
    }

    /// <summary>디스카드 더미 버튼 클릭 → 디스카드 목록 팝업 열기.</summary>
    private void HandleDiscardPileClicked()
    {
        UICardPileViewer.ShowDiscardPile();
        OpenPileViewer();
    }

    private void HandleExhaustPileClicked()
    {
        UICardPileViewer.ShowExhaustPile();
        OpenPileViewer();
    }

    private void OpenPileViewer()
    {
        if (UIManager.HasInstance)
        {
            UIManager.Instance.OpenAsync<UICardPileViewer>().Forget();
        }
    }

    public override void OnClose()
    {
        _skillPanel?.CancelCast();
        _cardHand?.SetSkillSelectionActive(false);
        UnbindActors();
        _cardHand?.Close();
        _castingOrbHoverProbe?.Hide();
    }

    private void OnDestroy()
    {
        UnbindBuffs();
        UnbindCardInfoHidden();
        _castingOrbHoverProbe?.Hide();

        if (BattleController.HasInstance)
            BattleController.Instance.OnPilesChanged -= RefreshPileCounts;

        SkillCastInput castInput = _skillPanel != null ? _skillPanel.CastInput : null;
        if (castInput != null)
        {
            castInput.OnCastStarted -= HandleSkillCastStarted;
            castInput.OnCastEnded -= HandleSkillCastEnded;
        }

        if (_skillPanel != null)
            _skillPanel.OnSelectionStateChanged -= SyncSkillSelectionVisual;

        _skillPanel?.UnbindSkills();

        if (_endTurnButton != null)
        {
            _endTurnButton.onClick.RemoveListener(HandleEndTurnClicked);
        }

        if (_preserveButton != null)
        {
            _preserveButton.onClick.RemoveListener(HandlePreserveClicked);
        }

        if (_drawPileButton != null)
        {
            _drawPileButton.onClick.RemoveListener(HandleDrawPileClicked);
        }

        if (_discardPileButton != null)
        {
            _discardPileButton.onClick.RemoveListener(HandleDiscardPileClicked);
        }

        if (_exhaustPileButton != null)
        {
            _exhaustPileButton.onClick.RemoveListener(HandleExhaustPileClicked);
        }
    }

    private void EnsureEnemySpeechBubble()
    {
        if (_enemySpeechBubble != null) return;

        GameObject go = new GameObject("EnemySpeechBubble", typeof(RectTransform));
        RectTransform rect = go.GetComponent<RectTransform>();
        rect.SetParent(transform, worldPositionStays: false);
        rect.anchorMin = new Vector2(0.5f, 0.5f);
        rect.anchorMax = new Vector2(0.5f, 0.5f);
        rect.pivot = new Vector2(0.5f, 0f);
        rect.sizeDelta = new Vector2(260f, 84f);
        rect.localScale = Vector3.one;
        rect.SetAsLastSibling();

        _enemySpeechBubble = go.AddComponent<EnemySpeechBubble>();
        _enemySpeechBubble.Initialize(GetComponentInParent<Canvas>(), transform as RectTransform);
    }

    private void UnbindBuffs()
    {
        if (_buffDispatcher != null)
        {
            _buffDispatcher.OnBuffChanged -= RefreshBuffs;
            _buffDispatcher = null;
        }

        ClearBuffIcons();
    }

    private void UnbindCardInfoHidden()
    {
        if (_cardInfoGrid != null)
        {
            _cardInfoGrid.OnCardInfoHiddenChanged -= HandleCardInfoHiddenChanged;
            _cardInfoGrid = null;
        }

        if (_eraseInfoDebuffIcon != null)
        {
            _eraseInfoDebuffIcon.gameObject.SetActive(false);
        }
        _buffTooltipPanel?.Hide();
        RefreshBuffs();
    }

    private void HandleCardInfoHiddenChanged(bool hidden)
    {
        if (hidden && _eraseInfoDebuffIcon == null && _buffRoot != null && _buffIconPrefab != null)
        {
            _eraseInfoDebuffIcon = Instantiate(_buffIconPrefab, _buffRoot);
            _eraseInfoDebuffIcon.SetHoverHandlers(HandleEraseInfoPointerEnter, HandleEraseInfoPointerExit);
        }

        if (_eraseInfoDebuffIcon != null)
        {
            if (hidden)
            {
                EEnemyIntentType intentType = ResolveCardInfoHiddenIntentType();
                Sprite sprite = _intentIconSet != null
                    ? _intentIconSet.Resolve(intentType)
                    : null;
                _eraseInfoDebuffIcon.Bind(sprite, string.Empty);
                _eraseInfoDebuffIcon.gameObject.SetActive(true);
                _eraseInfoDebuffIcon.transform.SetSiblingIndex(0);
            }
            else
            {
                _eraseInfoDebuffIcon.gameObject.SetActive(false);
            }
        }

        if (!hidden)
        {
            _buffTooltipPanel?.Hide();
        }
        RefreshBuffs();
    }

    private void HandleEraseInfoPointerEnter(UIBattleBuffIcon icon)
    {
        if (_buffTooltipPanel == null || icon == null) return;

        EnemyIntent intent = new EnemyIntent { Type = ResolveCardInfoHiddenIntentType() };
        _buffTooltipPanel.Show(
            intent,
            descriptionKeyOverride: LocalizationKeys.Battle.PlayerEraseInfoDebuffDesc);
        _buffTooltipPanel.MoveBelow((RectTransform)icon.transform, _buffTooltipOffset);
    }

    private void HandleEraseInfoPointerExit(UIBattleBuffIcon icon)
    {
        _buffTooltipPanel?.Hide();
    }

    private EEnemyIntentType ResolveCardInfoHiddenIntentType()
    {
        return _cardInfoGrid != null && _cardInfoGrid.IsCardInfoHiddenKeepArrow
            ? EEnemyIntentType.EraseCardKindOnly
            : EEnemyIntentType.EraseInfo;
    }

    private void RefreshBuffs()
    {
        if (_buffRoot == null || _buffIconPrefab == null) return;

        IReadOnlyList<BattleBuffView> views = _buffDispatcher?.ActiveBuffViews;
        _removedBuffIds.Clear();
        foreach (int id in _buffIcons.Keys)
        {
            _removedBuffIds.Add(id);
        }

        int firstBuffIndex = _eraseInfoDebuffIcon != null && _eraseInfoDebuffIcon.gameObject.activeSelf ? 1 : 0;
        int count = views != null ? views.Count : 0;
        for (int i = 0; i < count; i++)
        {
            BattleBuffView view = views[i];
            _removedBuffIds.Remove(view.Id);
            if (!_buffIcons.TryGetValue(view.Id, out UIBattleBuffIcon icon) || icon == null)
            {
                icon = Instantiate(_buffIconPrefab, _buffRoot);
                _buffIcons[view.Id] = icon;
            }

            icon.transform.SetSiblingIndex(firstBuffIndex + i);
            icon.Bind(view);
        }

        for (int i = 0; i < _removedBuffIds.Count; i++)
        {
            int id = _removedBuffIds[i];
            if (_buffIcons.TryGetValue(id, out UIBattleBuffIcon icon) && icon != null)
            {
                Destroy(icon.gameObject);
            }
            _buffIcons.Remove(id);
        }
    }

    private void ClearBuffIcons()
    {
        foreach (UIBattleBuffIcon icon in _buffIcons.Values)
        {
            if (icon != null)
            {
                Destroy(icon.gameObject);
            }
        }
        _buffIcons.Clear();
    }

    private void EnsureCastingOrbHoverProbe()
    {
        if (_castingOrbHoverProbe != null) return;

        GameObject go = new GameObject("CastingOrbHoverProbe", typeof(RectTransform));
        RectTransform rect = go.GetComponent<RectTransform>();
        rect.SetParent(transform, worldPositionStays: false);
        rect.anchorMin = new Vector2(0.5f, 0.5f);
        rect.anchorMax = new Vector2(0.5f, 0.5f);
        rect.sizeDelta = Vector2.zero;
        rect.localScale = Vector3.one;
        rect.SetAsLastSibling();

        _castingOrbHoverProbe = go.AddComponent<CastingOrbHoverProbe>();
        _castingOrbHoverProbe.Initialize(GetComponentInParent<Canvas>(), transform as RectTransform, _castingOrbInfoPanelPrefab);
    }
}

/// <summary>캐스팅 오브 위에 마우스를 올리면 Card ID 작은 정보창을 표시한다.</summary>
internal sealed class CastingOrbHoverProbe : MonoBehaviour
{
    private readonly RaycastHit[] _hits = new RaycastHit[32];

    private const float RayDistance = 100f;

    private CastingOrbInfoPanel _panel;
    private CastingOrbView _previewOrb;

    public void Initialize(Canvas canvas, RectTransform canvasRect, RectTransform panelPrefab)
    {
        _panel = CastingOrbInfoPanel.Create(canvas, canvasRect, panelPrefab);
        Hide();
    }

    public void Hide()
    {
        _panel?.Hide();
        ClearSourcePreview();
    }

    public void RefreshLocalization()
    {
        _panel?.RefreshLocalization();
    }

    private void OnDisable()
    {
        Hide();
    }

    private void Update()
    {
        if (_panel == null || Mouse.current == null)
        {
            return;
        }

        if (Mouse.current.leftButton.isPressed)
        {
            Hide();
            return;
        }

        if (UnityEngine.EventSystems.EventSystem.current != null &&
            UnityEngine.EventSystems.EventSystem.current.IsPointerOverGameObject())
        {
            Hide();
            return;
        }

        Vector2 screenPos = Mouse.current.position.ReadValue();
        CastingOrbView orb = FindOrbAt(screenPos);
        if (orb == null || string.IsNullOrWhiteSpace(orb.CardId))
        {
            Hide();
            return;
        }

        string displayNameKey = string.IsNullOrEmpty(orb.DisplayNameKey)
            ? orb.CardId
            : orb.DisplayNameKey;
        _panel.Show(displayNameKey, screenPos);
        ShowSourcePreview(orb);
    }

    private CastingOrbView FindOrbAt(Vector2 screenPos)
    {
        Camera cam = Camera.main;
        if (cam == null)
        {
            return null;
        }

        Ray ray = cam.ScreenPointToRay(screenPos);
        int hitCount = Physics.RaycastNonAlloc(
            ray,
            _hits,
            RayDistance,
            ~0,
            QueryTriggerInteraction.Collide);

        CastingOrbView nearest = null;
        float nearestDistance = float.MaxValue;
        for (int i = 0; i < hitCount; i++)
        {
            RaycastHit hit = _hits[i];
            if (hit.collider == null || hit.distance >= nearestDistance) continue;

            CastingOrbView orb = hit.collider.GetComponentInParent<CastingOrbView>();
            if (orb == null || string.IsNullOrWhiteSpace(orb.CardId)) continue;

            nearest = orb;
            nearestDistance = hit.distance;
        }

        return nearest;
    }

    private void ShowSourcePreview(CastingOrbView orb)
    {
        if (!GridManager.HasInstance || orb == null || orb.SourceCard == null)
        {
            ClearSourcePreview();
            return;
        }

        if (!GridManager.Instance.TryGetPosition(orb.SourceCard, out Vector2Int position))
        {
            ClearSourcePreview();
            return;
        }

        GridManager.Instance.ShowPlacementPreview(orb.SourceCard, position, true);
        _previewOrb = orb;
    }

    private void ClearSourcePreview()
    {
        if (_previewOrb != null && GridManager.HasInstance)
        {
            GridManager.Instance.ClearPlacementPreview();
        }

        _previewOrb = null;
    }
}

/// <summary>마우스 기준으로 따라다니는 캐스팅 오브 카드 이름 패널.</summary>
internal sealed class CastingOrbInfoPanel
{
    private static readonly Vector2 MouseOffset = new Vector2(18f, -18f);

    private readonly RectTransform _rect;
    private readonly RectTransform _parentRect;
    private readonly Canvas _canvas;
    private readonly CanvasGroup _canvasGroup;
    private readonly TMP_Text _text;
    private string _displayNameKey = string.Empty;

    private CastingOrbInfoPanel(RectTransform rect, RectTransform parentRect, Canvas canvas, CanvasGroup canvasGroup, TMP_Text text)
    {
        _rect = rect;
        _parentRect = parentRect;
        _canvas = canvas;
        _canvasGroup = canvasGroup;
        _text = text;
    }

    public static CastingOrbInfoPanel Create(Canvas canvas, RectTransform parentRect, RectTransform prefab)
    {
        if (parentRect == null || prefab == null)
        {
            return null;
        }

        RectTransform rect = Object.Instantiate(prefab, parentRect, worldPositionStays: false);
        rect.name = prefab.name;
        rect.SetParent(parentRect, worldPositionStays: false);
        rect.localScale = Vector3.one;
        rect.SetAsLastSibling();

        CanvasGroup canvasGroup = rect.GetComponent<CanvasGroup>();
        if (canvasGroup != null)
        {
            canvasGroup.blocksRaycasts = false;
        }

        TMP_Text text = rect.GetComponentInChildren<TMP_Text>(true);
        if (text != null)
        {
            LocalizedFontUtility.ApplyCurrentFont(text);
            text.raycastTarget = false;
        }

        return new CastingOrbInfoPanel(rect, parentRect, canvas, canvasGroup, text);
    }

    public void Show(string displayNameKey, Vector2 mouseScreenPosition)
    {
        if (_displayNameKey != displayNameKey)
        {
            _displayNameKey = displayNameKey;
            RefreshLocalization();
        }

        PositionAtScreen(mouseScreenPosition + MouseOffset);
        if (_canvasGroup != null)
        {
            _canvasGroup.alpha = 1f;
            _canvasGroup.blocksRaycasts = false;
        }
    }

    public void RefreshLocalization()
    {
        if (_text == null || string.IsNullOrEmpty(_displayNameKey))
        {
            return;
        }

        _text.text = LocalizationManager.HasInstance
            ? LocalizationManager.Instance.Get(_displayNameKey)
            : _displayNameKey;
    }

    public void Hide()
    {
        _displayNameKey = string.Empty;
        if (_canvasGroup != null)
        {
            _canvasGroup.alpha = 0f;
            _canvasGroup.blocksRaycasts = false;
        }
    }

    private void PositionAtScreen(Vector2 screenPosition)
    {
        if (_rect == null || _parentRect == null)
        {
            return;
        }

        Camera uiCamera = _canvas != null && _canvas.renderMode != RenderMode.ScreenSpaceOverlay
            ? _canvas.worldCamera
            : null;

        if (!RectTransformUtility.ScreenPointToLocalPointInRectangle(
                _parentRect,
                screenPosition,
                uiCamera,
                out Vector2 localPoint))
        {
            return;
        }

        Rect parentRect = _parentRect.rect;
        Vector2 size = _rect.rect.size;
        localPoint.x = Mathf.Clamp(localPoint.x, parentRect.xMin, parentRect.xMax - size.x);
        localPoint.y = Mathf.Clamp(localPoint.y, parentRect.yMin + size.y, parentRect.yMax);
        _rect.anchoredPosition = localPoint;
    }
}

/// <summary>전투 중 적 머리 위 대사를 표시하는 말풍선 UI.</summary>
internal sealed class EnemySpeechBubble : MonoBehaviour
{
    private const float DefaultDuration = 2f;

    private RectTransform _rect;
    private RectTransform _canvasRect;
    private Canvas _canvas;
    private TMP_Text _text;
    private Transform _target;
    private float _hideAt;

    public void Initialize(Canvas canvas, RectTransform canvasRect)
    {
        _rect = transform as RectTransform;
        _canvas = canvas;
        _canvasRect = canvasRect;

        Image background = gameObject.AddComponent<Image>();
        background.color = new Color(1f, 1f, 1f, 0.94f);
        background.raycastTarget = false;

        GameObject textGo = new GameObject("Text", typeof(RectTransform));
        RectTransform textRect = textGo.GetComponent<RectTransform>();
        textRect.SetParent(transform, worldPositionStays: false);
        textRect.anchorMin = Vector2.zero;
        textRect.anchorMax = Vector2.one;
        textRect.offsetMin = new Vector2(18f, 14f);
        textRect.offsetMax = new Vector2(-18f, -14f);

        _text = textGo.AddComponent<TextMeshProUGUI>();
        LocalizedFontUtility.ApplyCurrentFont(_text);
        _text.alignment = TextAlignmentOptions.Center;
        _text.color = new Color(0.08f, 0.08f, 0.08f, 1f);
        _text.fontSize = 24f;
        _text.textWrappingMode = TextWrappingModes.Normal;
        _text.raycastTarget = false;

        Hide();
    }

    public void BindTarget(Transform target)
    {
        _target = target;
    }

    public void Show(EnemySpeechLine speech)
    {
        if (_text == null || string.IsNullOrWhiteSpace(speech.Text)) return;

        _text.text = speech.Text;
        _hideAt = Time.unscaledTime + (speech.Duration > 0f ? speech.Duration : DefaultDuration);
        gameObject.SetActive(true);
        UpdatePosition();
    }

    public void Hide()
    {
        if (gameObject.activeSelf)
        {
            gameObject.SetActive(false);
        }
    }

    private void LateUpdate()
    {
        if (Time.unscaledTime >= _hideAt)
        {
            Hide();
            return;
        }

        UpdatePosition();
    }

    private void UpdatePosition()
    {
        if (_rect == null || _canvasRect == null) return;

        Camera camera = null;
        if (_canvas != null && _canvas.renderMode != RenderMode.ScreenSpaceOverlay)
        {
            camera = _canvas.worldCamera != null ? _canvas.worldCamera : Camera.main;
        }

        Vector3 worldPosition = _target != null ? _target.position + Vector3.up * 1.15f : Vector3.zero;
        Vector2 screenPosition = RectTransformUtility.WorldToScreenPoint(camera, worldPosition);
        if (RectTransformUtility.ScreenPointToLocalPointInRectangle(_canvasRect, screenPosition, camera, out Vector2 localPoint))
        {
            _rect.anchoredPosition = localPoint;
        }
    }
}

/// <summary>전투 중 카드 위치 근처에 짧게 뜨는 임시 텍스트.</summary>
internal sealed class BattleTempText : MonoBehaviour
{
    private const float Duration = 1.1f;
    private const float RiseDistance = 52f;

    private RectTransform _rect;
    private TMP_Text _text;
    private CanvasGroup _canvasGroup;
    private Vector2 _startPosition;
    private float _startTime;

    public static void Show(RectTransform canvasRect, Canvas canvas, Vector3 worldPosition, string text)
    {
        if (canvasRect == null || canvas == null)
        {
            return;
        }

        Camera camera = canvas.renderMode != RenderMode.ScreenSpaceOverlay
            ? canvas.worldCamera != null ? canvas.worldCamera : Camera.main
            : null;

        Vector2 screenPosition = RectTransformUtility.WorldToScreenPoint(camera, worldPosition);
        if (!RectTransformUtility.ScreenPointToLocalPointInRectangle(
                canvasRect,
                screenPosition,
                camera,
                out Vector2 localPoint))
        {
            return;
        }

        GameObject go = new GameObject("tmpTxt", typeof(RectTransform), typeof(CanvasGroup));
        RectTransform rect = go.GetComponent<RectTransform>();
        rect.SetParent(canvasRect, worldPositionStays: false);
        rect.anchorMin = new Vector2(0.5f, 0.5f);
        rect.anchorMax = new Vector2(0.5f, 0.5f);
        rect.pivot = new Vector2(0.5f, 0.5f);
        rect.sizeDelta = new Vector2(360f, 54f);
        rect.anchoredPosition = localPoint;
        rect.localScale = Vector3.one;
        rect.SetAsLastSibling();

        TMP_Text label = go.AddComponent<TextMeshProUGUI>();
        LocalizedFontUtility.ApplyCurrentFont(label);
        label.text = text;
        label.alignment = TextAlignmentOptions.Center;
        label.fontSize = 24f;
        label.fontStyle = FontStyles.Bold;
        label.color = new Color(1f, 0.82f, 0.28f, 1f);
        label.raycastTarget = false;

        Outline outline = go.AddComponent<Outline>();
        outline.effectColor = new Color(0f, 0f, 0f, 0.7f);
        outline.effectDistance = new Vector2(2f, -2f);

        BattleTempText tempText = go.AddComponent<BattleTempText>();
        tempText.Initialize(rect, label, go.GetComponent<CanvasGroup>(), localPoint);
    }

    private void Initialize(RectTransform rect, TMP_Text text, CanvasGroup canvasGroup, Vector2 startPosition)
    {
        _rect = rect;
        _text = text;
        _canvasGroup = canvasGroup;
        _startPosition = startPosition;
        _startTime = Time.unscaledTime;
    }

    private void Update()
    {
        float t = Mathf.Clamp01((Time.unscaledTime - _startTime) / Duration);
        if (_rect != null)
        {
            _rect.anchoredPosition = _startPosition + Vector2.up * (RiseDistance * t);
        }

        if (_canvasGroup != null)
        {
            _canvasGroup.alpha = 1f - Mathf.SmoothStep(0f, 1f, t);
        }

        if (t >= 1f)
        {
            Destroy(gameObject);
        }
    }
}
