using System;
using System.Collections.Generic;
using UnityEngine;

[Serializable]
public sealed class BattleVfxAudioCue
{
    [Tooltip("CardDataSO 또는 VFX 스폰에 사용하는 Addressable VFX 키")]
    [SerializeField] private string _vfxKey;

    [Tooltip("Assets/00_Addressable/Sound/addressableMap.json에 등록된 SFX 키")]
    [SerializeField] private string _sfxKey;

    [Range(0f, 1f)]
    [SerializeField] private float _volume = 1f;

    [Range(0.1f, 3f)]
    [SerializeField] private float _pitch = 1f;

    [Tooltip("다중 타격에서 같은 소리가 반복될 때 AudioManager의 랜덤 피치를 적용")]
    [SerializeField] private bool _randomPitch = true;

    public string VfxKey => _vfxKey;
    public string SfxKey => _sfxKey;
    public float Volume => Mathf.Clamp01(_volume);
    public float Pitch => Mathf.Clamp(_pitch, 0.1f, 3f);
    public bool RandomPitch => _randomPitch;
    public bool IsValid => !string.IsNullOrWhiteSpace(_vfxKey) && !string.IsNullOrWhiteSpace(_sfxKey);
}

[CreateAssetMenu(fileName = "BattleVfxAudioCatalog", menuName = "Battle/VFX Audio Catalog")]
public sealed class BattleVfxAudioCatalog : ScriptableObject
{
    [Tooltip("VFX가 스폰될 때 재생할 SFX 매핑")]
    [SerializeField] private List<BattleVfxAudioCue> _entries = new List<BattleVfxAudioCue>();

    public bool TryFind(string vfxKey, out BattleVfxAudioCue cue)
    {
        if (!string.IsNullOrWhiteSpace(vfxKey))
        {
            for (int i = 0; i < _entries.Count; i++)
            {
                BattleVfxAudioCue candidate = _entries[i];
                if (candidate != null &&
                    candidate.IsValid &&
                    string.Equals(candidate.VfxKey, vfxKey, StringComparison.Ordinal))
                {
                    cue = candidate;
                    return true;
                }
            }
        }

        cue = null;
        return false;
    }
}
