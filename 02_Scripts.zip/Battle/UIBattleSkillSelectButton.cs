// =================================================================
// [스크립트 목적]  3-스킬 캐릭터 전용 스킬 선택 탭 버튼 1개.
//                  스킬 이름 텍스트·쿨다운·선택 표시를 캐싱하고, 클릭 시 스킬 인덱스를 콜백한다.
//                  (클릭 = 캐스트 시작이 아니라 "해당 스킬의 방향 버튼 그룹 펼치기" 선택)
// [주요 변수]      - _label : 스킬 이름 텍스트 (아이콘 없음, 텍스트 전용)
//                  - _cooldownOverlay/_cooldownText : 쿨다운 표시
//                  - _selectedOverlay : 현재 펼쳐진 스킬 표시
// [의존 관계]      - UIBattleSkillPanel 이 Bind/SetLabel/SetSelected/SetInteractable 호출
// =================================================================

using System;
using Cysharp.Threading.Tasks;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

[RequireComponent(typeof(Button))]
public sealed class UIBattleSkillSelectButton : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler, IPointerClickHandler
{
    [Tooltip("클릭 버튼. 비우면 같은 오브젝트의 Button 자동 캐싱")]
    [SerializeField] private Button _button;

    [Tooltip("스킬 이름 텍스트 라벨")]
    [SerializeField] private TMP_Text _label;

    [Tooltip("쿨다운 중 켜질 오버레이 (선택)")]
    [SerializeField] private GameObject _cooldownOverlay;

    [Tooltip("남은 쿨다운 턴 텍스트 (선택)")]
    [SerializeField] private TMP_Text _cooldownText;

    [Tooltip("쿨다운 게이지 Image (선택). 코드는 fillAmount(남은턴/최대턴)만 갱신하며, Fill Method·Clockwise·Origin 은 인스펙터 설정을 따른다")]
    [SerializeField] private Image _cooldownFill;

    [Tooltip("이 스킬이 현재 펼쳐졌음을 표시할 오버레이 (선택)")]
    [SerializeField] private GameObject _selectedOverlay;

    private int _index;
    private SkillRuntime _runtime;
    private Action<int> _clicked;
    private Action<UIBattleSkillSelectButton, SkillRuntime> _hoverEntered;
    private Action<UIBattleSkillSelectButton> _hoverExited;
    private bool _bound;

    public void Bind(
        int index,
        SkillRuntime runtime,
        Action<int> clicked,
        Action<UIBattleSkillSelectButton, SkillRuntime> hoverEntered,
        Action<UIBattleSkillSelectButton> hoverExited)
    {
        _index = index;
        _clicked = clicked;
        _hoverEntered = hoverEntered;
        _hoverExited = hoverExited;

        if (_button == null)
            _button = GetComponent<Button>();
        if (_button != null && !_bound)
        {
            _button.onClick.AddListener(HandleClicked);
            _bound = true;
        }

        SetRuntime(runtime);
        SetSelected(false);
    }

    public void Unbind()
    {
        SetRuntime(null);
        _clicked = null;
        _hoverEntered = null;
        _hoverExited = null;
        SetSelected(false);
    }

    public void SetLabel(string text)
    {
        if (_label != null)
        {
            LocalizedFontUtility.ApplyCurrentFont(_label);
            _label.text = text ?? string.Empty;
        }
    }

    /// <summary>라벨이 지정 범위 안에서 자동 조절된 결과 크기를 반환한다.</summary>
    public float CalculateAutoSizedLabelFontSize(float minSize, float maxSize)
    {
        if (_label == null) return 0f;

        _label.enableAutoSizing = true;
        _label.fontSizeMin = minSize;
        _label.fontSizeMax = maxSize;
        _label.ForceMeshUpdate();
        return _label.fontSize;
    }

    /// <summary>라벨 크기를 고정한다.</summary>
    public void SetLabelFontSize(float fontSize)
    {
        if (_label == null) return;

        _label.enableAutoSizing = false;
        _label.fontSize = fontSize;
    }

    public void SetSelected(bool on)
    {
        if (_selectedOverlay != null && _selectedOverlay.activeSelf != on)
            _selectedOverlay.SetActive(on);
    }

    public void SetInteractable(bool value)
    {
        if (_button != null)
            _button.interactable = value;
    }

    private void SetRuntime(SkillRuntime runtime)
    {
        if (_runtime != null)
            _runtime.OnChanged -= Refresh;

        _runtime = runtime;

        if (_runtime != null)
            _runtime.OnChanged += Refresh;

        Refresh();
    }

    private void Refresh()
    {
        int remaining = _runtime != null ? _runtime.RemainingCooldown : 0;
        bool cooldown = remaining > 0;

        if (_cooldownOverlay != null && _cooldownOverlay.activeSelf != cooldown)
            _cooldownOverlay.SetActive(cooldown);

        if (_cooldownText != null)
        {
            LocalizedFontUtility.ApplyCurrentFont(_cooldownText);
            _cooldownText.text = cooldown ? remaining.ToString() : string.Empty;
        }

        UICooldownFillUtility.Apply(_cooldownFill, remaining, _runtime != null ? _runtime.MaxCooldown : 0);
    }

    private void HandleClicked()
    {
        _clicked?.Invoke(_index);
    }

    public void OnPointerEnter(PointerEventData eventData)
    {
        if (_runtime != null)
            _hoverEntered?.Invoke(this, _runtime);
    }

    public void OnPointerExit(PointerEventData eventData)
    {
        _hoverExited?.Invoke(this);
    }

    public void OnPointerClick(PointerEventData eventData)
    {
        if (eventData.button != PointerEventData.InputButton.Left ||
            _runtime == null || _runtime.RemainingCooldown <= 0)
        {
            return;
        }

        if (AudioManager.HasInstance)
            AudioManager.Instance.PlaySfxAsync(AudioKeys.Card.CANNOT_LOCATE).Forget();
    }

    private void OnDisable()
    {
        _hoverExited?.Invoke(this);
    }

    private void OnDestroy()
    {
        if (_button != null && _bound)
            _button.onClick.RemoveListener(HandleClicked);
        _bound = false;
        if (_runtime != null)
            _runtime.OnChanged -= Refresh;
        _runtime = null;
        _clicked = null;
        _hoverEntered = null;
        _hoverExited = null;
    }
}
