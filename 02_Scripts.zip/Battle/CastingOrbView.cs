using TMPro;
using UnityEngine;

/// <summary>캐스팅 대기 상태를 월드에 표시하는 오브젝트.</summary>
public sealed class CastingOrbView : PoolableMonoBehaviour
{
    [Header("표시")]
    [Tooltip("숫자 표시용 TMP. 비우면 런타임에 생성")]
    [SerializeField] private TMP_Text _countText;

    [Tooltip("오브젝트 색상")]
    [SerializeField] private Color _orbColor = new Color(0.36f, 0.78f, 1f, 0.9f);

    [Tooltip("월드 크기")]
    [Min(0.01f)]
    [SerializeField] private float _orbScale = 0.42f;

    private const string SortingLayerName = "FrontEffect";
    private const int OrbSortingOrder = 1000;
    private const int TextSortingOrder = 1001;
    private const float HoverColliderRadius = 0.55f;

    private static readonly Color32 OutlineColor = new Color32(0x2C, 0x2C, 0x2C, 0xFF);
    private const float OutlineWidth = 0.2f;

    public int Id { get; private set; }
    public Card SourceCard { get; private set; }
    public string CardId => SourceCard?.Data != null ? SourceCard.Data.CardId : SourceCard?.CardId ?? string.Empty;
    public string DisplayNameKey => SourceCard?.Data != null ? SourceCard.Data.DisplayNameKey : string.Empty;
    public string DescriptionKey => SourceCard?.Data != null ? SourceCard.Data.DescriptionKey : string.Empty;
    public Vector3 WorldPosition => transform.position;

    public void Initialize(int id, int remainingCount)
    {
        Initialize(id, remainingCount, null);
    }

    public void Initialize(int id, int remainingCount, Card sourceCard)
    {
        Id = id;
        SourceCard = sourceCard;
        EnsureFallbackVisual();
        ApplySorting();
        EnsureHoverCollider();
        SetRemainingCount(remainingCount);
    }

    public void SetRemainingCount(int remainingCount)
    {
        EnsureFallbackVisual();
        if (_countText != null)
        {
            LocalizedFontUtility.ApplyCurrentFont(_countText);
            ApplyOutline();
            _countText.text = Mathf.Max(0, remainingCount).ToString();
        }
    }

    public void MoveTo(Vector3 worldPosition)
    {
        transform.position = worldPosition;
    }

    public override void OnReturnToPool()
    {
        SourceCard = null;
        Id = 0;
        if (_countText != null)
        {
            _countText.text = string.Empty;
        }
        base.OnReturnToPool();
    }

    private void Awake()
    {
        EnsureFallbackVisual();
        EnsureHoverCollider();
    }

    private void EnsureHoverCollider()
    {
        if (GetComponentInChildren<Collider>() != null)
        {
            return;
        }

        SphereCollider collider = gameObject.AddComponent<SphereCollider>();
        collider.isTrigger = true;
        collider.radius = HoverColliderRadius;
    }

    private void EnsureFallbackVisual()
    {
        if (_countText != null)
        {
            return;
        }

        if (transform.childCount == 0)
        {
            CreateFallbackOrb();
        }

        GameObject textGo = new GameObject("Count");
        textGo.transform.SetParent(transform, worldPositionStays: false);
        textGo.transform.localPosition = new Vector3(0f, 0f, -0.08f);

        _countText = textGo.AddComponent<TextMeshPro>();
        LocalizedFontUtility.ApplyCurrentFont(_countText);
        _countText.alignment = TextAlignmentOptions.Center;
        _countText.color = Color.white;
        _countText.fontSize = 3f;
        _countText.fontStyle = FontStyles.Bold;
        _countText.raycastTarget = false;

        RectTransform rect = _countText.rectTransform;
        rect.sizeDelta = new Vector2(1.2f, 0.8f);

        Renderer textRenderer = _countText.GetComponent<Renderer>();
        if (textRenderer != null)
        {
            textRenderer.sortingLayerName = SortingLayerName;
            textRenderer.sortingOrder = TextSortingOrder;
        }

        ApplyOutline();
    }

    private void ApplyOutline()
    {
        if (_countText == null)
        {
            return;
        }

        // fontMaterial는 이 텍스트 전용 인스턴스라 다른 텍스트에 영향 없음
        Material mat = _countText.fontMaterial;
        mat.EnableKeyword(ShaderUtilities.Keyword_Outline);
        mat.SetColor(ShaderUtilities.ID_OutlineColor, OutlineColor);
        mat.SetFloat(ShaderUtilities.ID_OutlineWidth, OutlineWidth);
    }

    private void ApplySorting()
    {
        SpriteRenderer[] spriteRenderers = GetComponentsInChildren<SpriteRenderer>(includeInactive: true);
        for (int i = 0; i < spriteRenderers.Length; i++)
        {
            spriteRenderers[i].sortingLayerName = SortingLayerName;
            spriteRenderers[i].sortingOrder = OrbSortingOrder;
        }

        Renderer textRenderer = _countText != null ? _countText.GetComponent<Renderer>() : null;
        if (textRenderer != null)
        {
            textRenderer.sortingLayerName = SortingLayerName;
            textRenderer.sortingOrder = TextSortingOrder;
        }
    }

    private void CreateFallbackOrb()
    {
        GameObject orb = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        orb.name = "Orb";
        orb.transform.SetParent(transform, worldPositionStays: false);
        orb.transform.localScale = Vector3.one * _orbScale;

        Collider collider = orb.GetComponent<Collider>();
        if (collider != null)
        {
            Destroy(collider);
        }

        Renderer renderer = orb.GetComponent<Renderer>();
        if (renderer != null)
        {
            Material material = CreateOrbMaterial();
            if (material != null)
            {
                renderer.material = material;
            }
            renderer.sortingLayerName = SortingLayerName;
            renderer.sortingOrder = OrbSortingOrder;
        }
    }

    private Material CreateOrbMaterial()
    {
        Shader shader = Shader.Find("Universal Render Pipeline/Unlit");
        if (shader == null)
        {
            shader = Shader.Find("Sprites/Default");
        }

        if (shader == null)
        {
            shader = Shader.Find("Standard");
        }
        if (shader == null)
        {
            return null;
        }

        Material material = new Material(shader);
        material.color = _orbColor;
        return material;
    }
}