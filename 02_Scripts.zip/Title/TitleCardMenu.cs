// =================================================================
// [스크립트 목적]  타이틀 전용 카드 손패·그리드 생성과 메뉴 발동
// [의존 관계]      - TitleGridSlot, TitleCardView, UGUI
// [원칙]           전투 런타임과 분리된 표현 전용 축소판으로 유지
// =================================================================

using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public sealed class TitleCardMenu : MonoBehaviour
{
    [Header("그리드")]
    [Min(1)] [SerializeField] private int _rows = 3;
    [Min(1)] [SerializeField] private int _columns = 3;
    [SerializeField] private Vector2Int _centerPosition = new Vector2Int(1, 1);

    [Header("루트")]
    [SerializeField] private RectTransform _boardRoot;
    [SerializeField] private RectTransform _handRoot;
    [SerializeField] private RectTransform _dragRoot;

    [Header("프리팹")]
    [SerializeField] private TitleGridSlot _slotPrefab;
    [SerializeField] private TitleCardView _cardPrefab;

    [Header("Seed")]
    [SerializeField] private List<TitleFixedCardSeed> _fixedCardSeeds = new();
    [SerializeField] private List<TitleHandCardSeed> _handCardSeeds = new();

    [Header("손패 배치")]
    [SerializeField] private float _anglePerCard = 3f;
    [SerializeField] private float _maxFanAngle = 21f;
    [SerializeField] private float _arcRadius = 3000f;
    [SerializeField, Min(0f)] private float _restLowerY = 100f;

    [Header("발동")]
    [Min(0f)] [SerializeField] private float _actionDelay = 0.15f;

    [Header("안내")]
    [SerializeField] private TMP_Text _guideText;
    [SerializeField] private string _guideTextKey = LocalizationKeys.Title.CardPlaceGuide;
    [Min(0f)] [SerializeField] private float _guideShakeDistance = 10f;
    [Min(0.01f)] [SerializeField] private float _guideShakeDuration = 0.25f;

    private readonly Dictionary<Vector2Int, TitleGridSlot> _slots = new();
    private readonly Dictionary<ETitleMenuAction, TitleCardView> _handCardByAction = new();
    private readonly List<TitleCardView> _handCards = new();
    private readonly List<GameObject> _spawned = new();

    private bool _initialized;
    private bool _isResolving;
    private TitleCardView _draggingCard;
    private TitleCardView _resolvingCard;
    private TitleGridSlot _resolvingSlot;
    private Coroutine _resolveRoutine;
    private Coroutine _guideShakeRoutine;
    private Vector2 _guideBasePosition;

    public event Action<ETitleMenuAction> OnMenuActionSelected;

    public bool Initialize()
    {
        ClearGenerated();
        if (!ValidateConfiguration())
            return false;

        BuildSlots();
        BuildFixedCards();
        BuildHand();
        RefreshLocalization();
        _initialized = true;
        return true;
    }

    public void RefreshLocalization()
    {
        if (_guideText != null)
        {
            LocalizedFontUtility.ApplyCurrentFont(_guideText);
            _guideText.text = LocalizationManager.HasInstance
                ? LocalizationManager.Instance.Get(_guideTextKey)
                : _guideTextKey;
        }

        for (int i = 0; i < _handCards.Count; i++)
            _handCards[i]?.RefreshLocalization();
    }

    // 팝업 복귀 시 그리드 슬롯 시각 상태를 초기화한다.
    public void ResetSlotStates()
    {
        foreach (TitleGridSlot slot in _slots.Values)
            slot?.ResetActivationState();
    }

    private void BuildSlots()
    {
        GridLayoutGroup layout = _boardRoot.GetComponent<GridLayoutGroup>();
        if (layout != null)
        {
            layout.constraint = GridLayoutGroup.Constraint.FixedColumnCount;
            layout.constraintCount = _columns;
        }

        for (int y = _rows - 1; y >= 0; y--)
        {
            for (int x = 0; x < _columns; x++)
            {
                TitleGridSlot slot = Instantiate(_slotPrefab, _boardRoot);
                Vector2Int position = new Vector2Int(x, y);
                slot.Initialize(
                    position,
                    position == _centerPosition,
                    HandleSlotDrop,
                    HandleSlotClicked,
                    HandleSlotHover);
                _slots[position] = slot;
                _spawned.Add(slot.gameObject);
            }
        }
    }

    private void BuildFixedCards()
    {
        HashSet<Vector2Int> used = new HashSet<Vector2Int>();
        for (int i = 0; i < _fixedCardSeeds.Count; i++)
        {
            TitleFixedCardSeed seed = _fixedCardSeeds[i];
            if (!ValidateFixedSeed(seed, used))
                continue;
            if (!IsActionAvailable(seed.Action))
                continue;

            _slots[seed.Position].SetFixedMenu(seed);
            used.Add(seed.Position);
        }
    }

    private void BuildHand()
    {
        for (int i = 0; i < _handCardSeeds.Count; i++)
        {
            TitleHandCardSeed seed = _handCardSeeds[i];
            if (seed == null || seed.Direction == ETitleDirection.None)
            {
                Debug.LogWarning($"[TitleCardMenu] 유효하지 않은 핸드 Seed 제외: index {i}");
                continue;
            }
            if (!TryGetTarget(seed.Direction, out TitleGridSlot target))
                continue;

            TitleCardView card = Instantiate(_cardPrefab, _handRoot);
            card.InitializeHand(seed, _dragRoot, HandleCardDragStateChanged);
            _handCards.Add(card);
            _spawned.Add(card.gameObject);

            _handCardByAction[target.MenuAction] = card;
        }

        LayoutHand();
    }

    private void LayoutHand()
    {
        int count = _handCards.Count;
        float fanAngle = Mathf.Min(_anglePerCard * Mathf.Max(0, count - 1), _maxFanAngle);

        for (int i = 0; i < count; i++)
        {
            float t = count == 1 ? 0.5f : (float)i / (count - 1);
            float angle = Mathf.Lerp(-fanAngle * 0.5f, fanAngle * 0.5f, t);
            float radians = angle * Mathf.Deg2Rad;
            Vector2 position = new Vector2(
                _arcRadius * Mathf.Sin(radians),
                _arcRadius * (Mathf.Cos(radians) - 1f) - _restLowerY);
            _handCards[i].SetHandPose(position, -angle, i);
        }
    }

    private void HandleCardDragStateChanged(TitleCardView card, bool dragging)
    {
        _draggingCard = dragging ? card : null;
        ClearPreviews();
    }

    private void HandleSlotHover(TitleGridSlot slot, bool entered)
    {
        ClearPreviews();
        if (!entered || _draggingCard == null || _isResolving)
            return;

        bool valid = slot.IsCenter && slot.IsEmpty;
        slot.SetPlacementPreview(valid);
        if (valid && TryGetTarget(_draggingCard.Direction, out TitleGridSlot target))
            target.SetSignalPreview(true);
    }

    private void HandleSlotClicked(TitleGridSlot slot)
    {
        if (slot == null || slot.MenuAction == ETitleMenuAction.None)
            return;

        if (_handCardByAction.TryGetValue(slot.MenuAction, out TitleCardView card))
            card.PlayAttentionShake();
        PlayGuideShake();
    }

    private void HandleSlotDrop(TitleGridSlot slot, TitleCardView card)
    {
        ClearPreviews();
        if (!_initialized || _isResolving || slot == null || card == null || !card.IsHandCard)
        {
            card?.ReturnToHand();
            return;
        }

        card.MarkDropHandled();
        if (!slot.IsCenter || !slot.IsEmpty || !TryGetTarget(card.Direction, out TitleGridSlot target))
        {
            card.ReturnToHand();
            return;
        }

        card.HideForPlacement();
        slot.SetOccupiedCard(card);
        _isResolving = true;
        _resolvingCard = card;
        _resolvingSlot = slot;
        _resolveRoutine = StartCoroutine(ResolveSelectionRoutine(card, slot, target));
    }

    private IEnumerator ResolveSelectionRoutine(
        TitleCardView card,
        TitleGridSlot center,
        TitleGridSlot target)
    {
        center.PlayActivation();
        yield return new WaitForSecondsRealtime(center.ActivationDuration);

        target.PlayActivation();
        yield return new WaitForSecondsRealtime(target.ActivationDuration);
        if (_actionDelay > 0f)
            yield return new WaitForSecondsRealtime(_actionDelay);

        ETitleMenuAction action = target.MenuAction;
        center.ClearOccupiedCard(card);
        card.ReturnToHand();
        _resolveRoutine = null;
        _resolvingCard = null;
        _resolvingSlot = null;
        _isResolving = false;
        OnMenuActionSelected?.Invoke(action);
    }

    private bool TryGetTarget(ETitleDirection direction, out TitleGridSlot target)
    {
        Vector2Int position = _centerPosition + DirectionToOffset(direction);
        return _slots.TryGetValue(position, out target) &&
               target.MenuAction != ETitleMenuAction.None;
    }

    private void ClearPreviews()
    {
        foreach (TitleGridSlot slot in _slots.Values)
            slot.ClearPreview();
    }

    private void PlayGuideShake()
    {
        if (_guideText == null)
            return;

        StopGuideShake();
        _guideBasePosition = _guideText.rectTransform.anchoredPosition;
        _guideShakeRoutine = StartCoroutine(GuideShakeRoutine());
    }

    private IEnumerator GuideShakeRoutine()
    {
        float duration = Mathf.Max(0.01f, _guideShakeDuration);
        float elapsed = 0f;
        while (elapsed < duration)
        {
            float progress = elapsed / duration;
            float wave = Mathf.Sin(progress * Mathf.PI * 8f) * (1f - progress);
            _guideText.rectTransform.anchoredPosition =
                _guideBasePosition + Vector2.right * (wave * _guideShakeDistance);
            elapsed += Time.unscaledDeltaTime;
            yield return null;
        }

        _guideText.rectTransform.anchoredPosition = _guideBasePosition;
        _guideShakeRoutine = null;
    }

    private void StopGuideShake()
    {
        if (_guideShakeRoutine == null)
            return;
        StopCoroutine(_guideShakeRoutine);
        _guideShakeRoutine = null;
        if (_guideText != null)
            _guideText.rectTransform.anchoredPosition = _guideBasePosition;
    }

    private bool ValidateConfiguration()
    {
        if (_rows < 1 || _columns < 1 || !IsInBounds(_centerPosition))
        {
            Debug.LogError($"[TitleCardMenu] 잘못된 그리드 설정: {_columns}x{_rows}, center={_centerPosition}");
            return false;
        }
        if (_boardRoot == null || _handRoot == null || _dragRoot == null)
        {
            Debug.LogError("[TitleCardMenu] BoardRoot/HandRoot/DragRoot 참조가 필요합니다.");
            return false;
        }
        if (_slotPrefab == null || _cardPrefab == null)
        {
            Debug.LogError("[TitleCardMenu] Slot/Card 프리팹 참조가 필요합니다.");
            return false;
        }
        return true;
    }

    private bool ValidateFixedSeed(TitleFixedCardSeed seed, HashSet<Vector2Int> used)
    {
        if (seed == null || seed.Action == ETitleMenuAction.None)
        {
            Debug.LogWarning("[TitleCardMenu] 액션이 없는 고정 Seed 제외");
            return false;
        }
        if (!IsInBounds(seed.Position) || seed.Position == _centerPosition || used.Contains(seed.Position))
        {
            Debug.LogWarning($"[TitleCardMenu] 잘못된 고정 Seed 좌표 제외: {seed.Position}");
            return false;
        }
        return true;
    }

    private bool IsInBounds(Vector2Int position)
    {
        return position.x >= 0 && position.x < _columns &&
               position.y >= 0 && position.y < _rows;
    }

    private static bool IsActionAvailable(ETitleMenuAction action)
    {
        return action != ETitleMenuAction.Continue || RunSaveSystem.HasSave;
    }

    private static Vector2Int DirectionToOffset(ETitleDirection direction)
    {
        return direction switch
        {
            ETitleDirection.Up => Vector2Int.up,
            ETitleDirection.Down => Vector2Int.down,
            ETitleDirection.Left => Vector2Int.left,
            ETitleDirection.Right => Vector2Int.right,
            ETitleDirection.UpLeft => new Vector2Int(-1, 1),
            ETitleDirection.UpRight => new Vector2Int(1, 1),
            ETitleDirection.DownLeft => new Vector2Int(-1, -1),
            ETitleDirection.DownRight => new Vector2Int(1, -1),
            _ => Vector2Int.zero,
        };
    }

    private void ClearGenerated()
    {
        StopResolve();
        StopGuideShake();
        _initialized = false;
        for (int i = 0; i < _spawned.Count; i++)
            if (_spawned[i] != null)
                Destroy(_spawned[i]);
        _spawned.Clear();
        _slots.Clear();
        _handCards.Clear();
        _handCardByAction.Clear();
    }

    private void StopResolve()
    {
        if (_resolveRoutine != null)
        {
            StopCoroutine(_resolveRoutine);
            _resolveRoutine = null;
        }
        ClearPreviews();
        if (_resolvingCard != null)
        {
            _resolvingSlot?.ClearOccupiedCard(_resolvingCard);
            _resolvingCard.ReturnToHand();
        }
        _resolvingCard = null;
        _resolvingSlot = null;
        _draggingCard = null;
        _isResolving = false;
    }

    private void OnDisable()
    {
        StopResolve();
        StopGuideShake();
        _initialized = false;
    }

    private void OnDestroy()
    {
        StopResolve();
        StopGuideShake();
        OnMenuActionSelected = null;
    }
}
