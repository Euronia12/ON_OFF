// =================================================================
// [스크립트 목적]  타이틀 크레딧 뒤에서 ClearBg 패럴랙스와 중앙 고정 플레이어 걷기를 재생한다.
// [주요 변수]      - _backgroundPrefab : 기존 ClearBg 프리팹(씬 동안 1회 생성 후 재사용)
//                  - _playerPrefab     : 크레딧마다 PoolManager에서 Spawn/Despawn할 플레이어
// [배치]           Title 씬의 TitleController GameObject.
// =================================================================

using UnityEngine;

/// <summary>타이틀 크레딧 전용 월드 배경과 중앙 고정 걷기 연출을 소유한다.</summary>
public sealed class TitleCreditWalkSequence : MonoBehaviour
{
    [Header("배경")]
    [Tooltip("기존 ClearBg 프리팹. 최초 크레딧 진입 시 한 번 생성한 뒤 씬 동안 재사용")]
    [SerializeField] private GameObject _backgroundPrefab;

    [Tooltip("카메라 중심을 기준으로 적용할 배경 위치 오프셋(월드 단위)")]
    [SerializeField] private Vector3 _backgroundCameraOffset = new Vector3(0f, -1f, 0f);

    [Tooltip("배경 종횡비를 유지하는 균일 배율")]
    [Min(0.01f)]
    [SerializeField] private float _backgroundUniformScale = 1f;

    [Tooltip("크레딧 연출 전용 배경 이동 속도(월드 단위/초)")]
    [Min(0f)]
    [SerializeField] private float _backgroundScrollSpeed = 2f;

    [Header("캐릭터")]
    [Tooltip("PoolManager에서 생성할 공용 플레이어 프리팹")]
    [SerializeField] private Player _playerPrefab;

    [Tooltip("카메라 중심을 기준으로 적용할 캐릭터 위치 오프셋. X는 항상 카메라 중앙으로 고정")]
    [SerializeField] private Vector3 _playerCameraOffset = new Vector3(0f, 1.5f, 0f);

    [Tooltip("오른쪽 걷기 재생 시 SpriteRenderer를 좌우 반전할지 여부")]
    [SerializeField] private bool _flipForRight;

    private GameObject _backgroundInstance;
    private BattleBackgroundParallaxScroller _backgroundScroller;
    private Player _playerInstance;
    private PlayerView _playerView;
    private bool _isPrepared;

    /// <summary>
    /// 배경을 활성화하고 플레이어를 풀에서 꺼내 카메라 중앙에 배치한다.
    /// 필수 참조나 PoolManager가 없으면 기존 크레딧 UI로 폴백할 수 있도록 false를 반환한다.
    /// </summary>
    public bool Prepare(Camera targetCamera)
    {
        StopAndHide();

        if (_backgroundPrefab == null || _playerPrefab == null || !PoolManager.HasInstance)
        {
            Debug.LogWarning("[TitleCreditWalkSequence] 필수 프리팹 또는 PoolManager가 없어 걷기 연출을 건너뜁니다.");
            return false;
        }

        if (_backgroundInstance == null)
        {
            _backgroundInstance = Instantiate(_backgroundPrefab, transform);
            _backgroundScroller = _backgroundInstance
                .GetComponentInChildren<BattleBackgroundParallaxScroller>(includeInactive: true);
        }

        if (_backgroundInstance == null || _backgroundScroller == null)
        {
            Debug.LogWarning("[TitleCreditWalkSequence] ClearBg 패럴랙스 컴포넌트를 찾지 못했습니다.");
            SetBackgroundActive(false);
            return false;
        }

        Vector3 cameraPosition = targetCamera != null
            ? targetCamera.transform.position
            : Vector3.zero;

        Transform backgroundTransform = _backgroundInstance.transform;
        backgroundTransform.position = new Vector3(
            cameraPosition.x + _backgroundCameraOffset.x,
            cameraPosition.y + _backgroundCameraOffset.y,
            _backgroundCameraOffset.z);
        float scale = Mathf.Max(0.01f, _backgroundUniformScale);
        backgroundTransform.localScale = new Vector3(scale, scale, scale);
        SetBackgroundActive(true);

        // 캐릭터는 오른쪽을 향한 채 고정되고, 배경만 반대 방향인 왼쪽으로 순환한다.
        _backgroundScroller.Configure(targetCamera, moveRight: false, useUnscaledTime: true);
        _backgroundScroller.SetSpeed(_backgroundScrollSpeed);
        _backgroundScroller.Stop();

        _playerInstance = PoolManager.Instance.Spawn(_playerPrefab, transform);
        if (_playerInstance == null)
        {
            Debug.LogWarning("[TitleCreditWalkSequence] 플레이어를 풀에서 생성하지 못했습니다.");
            SetBackgroundActive(false);
            return false;
        }

        _playerInstance.transform.SetPositionAndRotation(
            new Vector3(
                cameraPosition.x,
                cameraPosition.y + _playerCameraOffset.y,
                _playerCameraOffset.z),
            Quaternion.identity);
        _playerInstance.transform.localScale = _playerPrefab.transform.localScale;
        _playerView = _playerInstance.View;
        if (_playerView == null)
        {
            Debug.LogWarning("[TitleCreditWalkSequence] 플레이어 View를 찾지 못했습니다.");
            StopAndHide();
            return false;
        }

        _isPrepared = true;
        return true;
    }

    /// <summary>오른쪽 걷기 애니메이션과 왼쪽 배경 이동을 시작한다.</summary>
    public void Play()
    {
        if (!_isPrepared) return;

        _playerView.SetFlipX(_flipForRight);
        _playerView.PlayWalkAnimation();
        _backgroundScroller.Resume();
    }

    /// <summary>연출을 정지하고 배경을 숨긴 뒤 플레이어를 반드시 풀로 반환한다.</summary>
    public void StopAndHide()
    {
        _isPrepared = false;

        if (_backgroundScroller != null)
            _backgroundScroller.Stop();

        SetBackgroundActive(false);

        if (_playerView != null)
            _playerView.PlayIdleAnimation();
        _playerView = null;

        if (_playerInstance != null)
        {
            if (PoolManager.HasInstance &&
                PoolManager.Instance.IsPooledInstance(_playerInstance.gameObject))
            {
                PoolManager.Instance.Despawn(_playerInstance);
            }
            else
            {
                Destroy(_playerInstance.gameObject);
            }
        }
        _playerInstance = null;
    }

    private void SetBackgroundActive(bool active)
    {
        if (_backgroundInstance != null)
            _backgroundInstance.SetActive(active);
    }

    private void OnDestroy()
    {
        StopAndHide();
    }
}
