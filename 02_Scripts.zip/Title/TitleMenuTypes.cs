// =================================================================
// [스크립트 목적]  타이틀 카드 메뉴의 방향·메뉴 액션·초기 Seed 데이터 정의
// [주요 변수]      - ETitleDirection / ETitleMenuAction
//                  - TitleFixedCardSeed / TitleHandCardSeed
// [의존 관계]      - TitleCardMenu, TitleCardView
// =================================================================

using System;
using UnityEngine;

public enum ETitleDirection
{
    None = 0,
    Up,
    Down,
    Left,
    Right,
    UpLeft,
    UpRight,
    DownLeft,
    DownRight,
}

public enum ETitleMenuAction
{
    None = 0,
    GameStart,
    Options,
    Credits,
    Quit,
    Tutorial,
    Collection,
    Continue,
}

[Serializable]
public sealed class TitleFixedCardSeed
{
    [Tooltip("고정 메뉴 카드에 표시할 이름")]
    public string DisplayName;

    [Tooltip("고정 메뉴 카드 아이콘")]
    public Sprite Icon;

    [Tooltip("그리드 좌표")]
    public Vector2Int Position;

    [Tooltip("선택 시 TitleController에 통지할 메뉴 액션")]
    public ETitleMenuAction Action;
}

[Serializable]
public sealed class TitleHandCardSeed
{
    [Tooltip("방향 카드에 표시할 이름")]
    public string DisplayName;

    [Tooltip("방향 카드 아이콘")]
    public Sprite Icon;

    [Tooltip("중앙에서 가리킬 방향")]
    public ETitleDirection Direction;
}
