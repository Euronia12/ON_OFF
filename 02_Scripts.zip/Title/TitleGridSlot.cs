﻿// =================================================================
// [스크립트 목적]  타이틀 전용 그리드 슬롯의 드롭·프리뷰·발동 표현
// [의존 관계]      - UGUI EventSystem, TitleCardView
// =================================================================

using System;
using System.Collections;
using Cysharp.Threading.Tasks;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

[RequireComponent(typeof(RectTransform), typeof(Button))]
public sealed class TitleGridSlot : MonoBehaviour,
    IDropHandler,
    IPointerEnterHandler,
    IPointerExitHandler,
    ILocalizable
{
    private static readonly Color OccupiedOnColor = Color.white;
    private static readonly Color OccupiedOffColor = new Color32(160, 164, 160, 255);

    [Header("비주얼")]
    [SerializeField] private Image _background;
    [SerializeField] private Image _occupied;
    [SerializeField] private Image _highlight;
    [SerializeField] private Image _signal;
    [SerializeField] private TMP_Text _nameText;
    [SerializeField] private GameObject _arrowPrefab;

    [Header("색상")]
    [SerializeField] private Color _normalColor = new Color(0.16f, 0.18f, 0.24f, 0.9f);
    [SerializeField] private Color _centerColor = new Color(0.3f, 0.36f, 0.5f, 0.95f);
    [SerializeField] private Color _fixedColor = new Color(0.45f, 0.31f, 0.16f, 1f);
    [SerializeField] private Color _validColor = new Color(0.3f, 0.9f, 0.5f, 0.8f);
    [SerializeField] private Color _invalidColor = new Color(0.95f, 0.25f, 0.25f, 0.8f);
    [SerializeField] private Color _signalColor = new Color(1f, 0.82f, 0.2f, 0.85f);

    [Header("발동 연출")]
    [Min(0.01f)] [SerializeField] private float _activationDuration = 0.35f;
    [Min(1f)] [SerializeField] private float _activationScale = 1.12f;

    private Button _selectButton;
    private Action<TitleGridSlot, TitleCardView> _onCardDropped;
    private Action<TitleGridSlot> _onSlotClicked;
    private Action<TitleGridSlot, bool> _onHoverChanged;
    private Coroutine _activationRoutine;
    private Color _baseColor;
    private bool _occupiedOn;
    private Vector3 _baseScale = Vector3.one;
    private Image _occupiedIcon;
    private GameObject _arrowRoot;
    private GameObject _up;
    private GameObject _down;
    private GameObject _left;
    private GameObject _right;
    private GameObject _upLeft;
    private GameObject _upRight;
    private GameObject _downLeft;
    private GameObject _downRight;
    private string _fixedDisplayNameKey = string.Empty;
    private string _currentDisplayNameKey = string.Empty;
    private Sprite _fixedIcon;

    public Vector2Int Position { get; private set; }
    public bool IsCenter { get; private set; }
    public TitleCardView OccupiedCard { get; private set; }
    public ETitleMenuAction MenuAction { get; private set; }
    public bool IsEmpty => OccupiedCard == null;
    public float ActivationDuration => _activationDuration;

    public void Initialize(
        Vector2Int position,
        bool isCenter,
        Action<TitleGridSlot, TitleCardView> onCardDropped,
        Action<TitleGridSlot> onSlotClicked,
        Action<TitleGridSlot, bool> onHoverChanged)
    {
        CacheReferences();
        Position = position;
        IsCenter = isCenter;
        OccupiedCard = null;
        MenuAction = ETitleMenuAction.None;
        _onCardDropped = onCardDropped;
        _onSlotClicked = onSlotClicked;
        _onHoverChanged = onHoverChanged;
        name = $"TitleSlot_{position.x}_{position.y}";
        _baseScale = transform.localScale;

        EnsureOccupiedVisual();
        SetMenuVisual(null);
        ClearPreview();
        RefreshSelectButton();
    }

    public void SetFixedMenu(TitleFixedCardSeed seed)
    {
        MenuAction = seed?.Action ?? ETitleMenuAction.None;
        SetMenuVisual(seed);
        RefreshSelectButton();
    }

    public void SetOccupiedCard(TitleCardView card)
    {
        OccupiedCard = card;
        ApplyOccupiedVisual(
            card != null,
            string.Empty,
            card?.Icon,
            card != null ? card.Direction : ETitleDirection.None);
        SetOccupiedState(card != null);
        RefreshBaseVis();
        RefreshSelectButton();
    }

    public void ClearOccupiedCard(TitleCardView card)
    {
        if (OccupiedCard != card)
            return;
        OccupiedCard = null;
        ApplyOccupiedVisual(
            MenuAction != ETitleMenuAction.None,
            _fixedDisplayNameKey,
            _fixedIcon,
            ETitleDirection.None);
        SetOccupiedState(false);
        RefreshBaseVis();
        RefreshSelectButton();
    }

    public void SetPlacementPreview(bool valid)
    {
        if (_highlight == null)
        {
            if (_background != null)
                _background.color = valid ? _validColor : _invalidColor;
            return;
        }
        _highlight.color = valid ? _validColor : _invalidColor;
        _highlight.gameObject.SetActive(true);
    }

    public void SetSignalPreview(bool active)
    {
        if (_signal == null)
            return;
        _signal.color = _signalColor;
        _signal.gameObject.SetActive(active);
    }

    public void ClearPreview()
    {
        if (_activationRoutine == null)
        {
            if (_highlight != null)
                _highlight.gameObject.SetActive(false);
            if (_background != null)
                _background.color = _baseColor;
        }
        if (_signal != null)
            _signal.gameObject.SetActive(false);
    }

    public void PlayActivation()
    {
        StopActivation();
        if (_occupied != null && _occupied.gameObject.activeSelf)
            SetOccupiedState(!_occupiedOn);
        if (AudioManager.HasInstance)
            AudioManager.Instance.PlayUiAsync(AudioKeys.Title.CARD_ACTIVATE).Forget();
        _activationRoutine = StartCoroutine(ActivationRoutine());
    }

    // 발동 연출로 토글된 블럭 상태를 기본값으로 되돌린다.
    public void ResetActivationState()
    {
        StopActivation();
        SetOccupiedState(false);
        ClearPreview();
    }

    public void OnDrop(PointerEventData eventData)
    {
        TitleCardView card = eventData.pointerDrag != null
            ? eventData.pointerDrag.GetComponent<TitleCardView>()
            : null;
        if (card != null)
            _onCardDropped?.Invoke(this, card);
    }

    public void OnPointerEnter(PointerEventData eventData)
    {
        _onHoverChanged?.Invoke(this, true);
    }

    public void OnPointerExit(PointerEventData eventData)
    {
        _onHoverChanged?.Invoke(this, false);
    }

    public void OnLocalize()
    {
        LocalizedFontUtility.ApplyCurrentFont(_nameText);
        RefreshName();
    }

    private void Awake()
    {
        CacheReferences();
    }

    private void OnEnable()
    {
        if (LocalizationManager.HasInstance)
            LocalizationManager.Instance.Register(this);
        else
            LocalizedFontUtility.ApplyCurrentFont(_nameText);
    }

    private void CacheReferences()
    {
        _background ??= GetComponent<Image>();
        _selectButton ??= GetComponent<Button>();
        _selectButton.onClick.RemoveListener(HandleSelectButtonClicked);
        _selectButton.onClick.AddListener(HandleSelectButtonClicked);
    }

    private void SetMenuVisual(TitleFixedCardSeed seed)
    {
        bool hasMenu = seed != null && seed.Action != ETitleMenuAction.None;
        _fixedDisplayNameKey = hasMenu ? seed.DisplayName ?? string.Empty : string.Empty;
        _fixedIcon = hasMenu ? seed.Icon : null;
        _baseColor = hasMenu ? _fixedColor : (IsCenter ? _centerColor : _normalColor);
        if (_background != null)
            _background.color = _baseColor;
        ApplyOccupiedVisual(hasMenu, _fixedDisplayNameKey, _fixedIcon, ETitleDirection.None);
        SetOccupiedState(false);
        RefreshBaseVis();
    }

    private void ApplyOccupiedVisual(
        bool active,
        string displayNameKey,
        Sprite icon,
        ETitleDirection direction)
    {
        EnsureOccupiedVisual();
        _currentDisplayNameKey = active ? displayNameKey ?? string.Empty : string.Empty;
        if (_occupied != null)
            _occupied.gameObject.SetActive(active);
        if (_occupiedIcon != null)
        {
            _occupiedIcon.sprite = icon;
            _occupiedIcon.enabled = active && icon != null;
        }
        if (_nameText != null)
            _nameText.gameObject.SetActive(active && !string.IsNullOrEmpty(_currentDisplayNameKey));
        ShowDirection(active ? direction : ETitleDirection.None);
        RefreshName();
    }

    private void SetOccupiedState(bool on)
    {
        _occupiedOn = on;
        if (_occupied != null)
            _occupied.color = on ? OccupiedOnColor : OccupiedOffColor;
    }

    private void RefreshBaseVis()
    {
        if (_background != null)
            _background.gameObject.SetActive(IsCenter || MenuAction != ETitleMenuAction.None || OccupiedCard != null);
    }

    private void EnsureOccupiedVisual()
    {
        if (_occupiedIcon == null && _occupied != null)
        {
            GameObject iconObject = new GameObject(
                "Icon", typeof(RectTransform), typeof(CanvasRenderer), typeof(Image));
            RectTransform rect = (RectTransform)iconObject.transform;
            rect.SetParent(_occupied.transform, false);
            rect.anchorMin = new Vector2(0.18f, 0.18f);
            rect.anchorMax = new Vector2(0.82f, 0.82f);
            rect.offsetMin = Vector2.zero;
            rect.offsetMax = Vector2.zero;
            _occupiedIcon = iconObject.GetComponent<Image>();
            _occupiedIcon.preserveAspect = true;
            _occupiedIcon.raycastTarget = false;
            _occupiedIcon.enabled = false;
        }

        if (_arrowRoot == null && _arrowPrefab != null)
        {
            _arrowRoot = Instantiate(_arrowPrefab, transform);
            _arrowRoot.name = "Arrow";
            if (_arrowRoot.transform is RectTransform rect)
            {
                rect.anchorMin = new Vector2(0.5f, 0.5f);
                rect.anchorMax = new Vector2(0.5f, 0.5f);
                rect.anchoredPosition = Vector2.zero;
                rect.sizeDelta = new Vector2(140f, 140f);
                if (_nameText != null)
                    rect.SetSiblingIndex(_nameText.transform.GetSiblingIndex());
            }
            _up = FindArrow("Up");
            _down = FindArrow("Down");
            _left = FindArrow("Left");
            _right = FindArrow("Right");
            _upLeft = FindArrow("UpLeft");
            _upRight = FindArrow("UpRight");
            _downLeft = FindArrow("DownLeft");
            _downRight = FindArrow("DownRight");
        }
    }

    private GameObject FindArrow(string childName)
    {
        Transform child = _arrowRoot != null ? _arrowRoot.transform.Find(childName) : null;
        return child != null ? child.gameObject : null;
    }

    private void ShowDirection(ETitleDirection direction)
    {
        SetActive(_up, direction == ETitleDirection.Up);
        SetActive(_down, direction == ETitleDirection.Down);
        SetActive(_left, direction == ETitleDirection.Left);
        SetActive(_right, direction == ETitleDirection.Right);
        SetActive(_upLeft, direction == ETitleDirection.UpLeft);
        SetActive(_upRight, direction == ETitleDirection.UpRight);
        SetActive(_downLeft, direction == ETitleDirection.DownLeft);
        SetActive(_downRight, direction == ETitleDirection.DownRight);
        if (_arrowRoot != null)
            _arrowRoot.SetActive(direction != ETitleDirection.None);
    }

    private static void SetActive(GameObject target, bool active)
    {
        if (target != null && target.activeSelf != active)
            target.SetActive(active);
    }

    private void RefreshName()
    {
        if (_nameText == null)
            return;
        _nameText.text = string.IsNullOrEmpty(_currentDisplayNameKey)
            ? string.Empty
            : LocalizationManager.HasInstance
                ? LocalizationManager.Instance.Get(_currentDisplayNameKey)
                : _currentDisplayNameKey;
    }

    private void RefreshSelectButton()
    {
        _selectButton.interactable = MenuAction != ETitleMenuAction.None;
    }

    private void HandleSelectButtonClicked()
    {
        if (AudioManager.HasInstance)
            AudioManager.Instance.PlayUiAsync(AudioKeys.Title.CLICK).Forget();
        _onSlotClicked?.Invoke(this);
    }

    private IEnumerator ActivationRoutine()
    {
        if (_highlight != null)
        {
            _highlight.color = _signalColor;
            _highlight.gameObject.SetActive(true);
        }

        float half = Mathf.Max(0.01f, _activationDuration * 0.5f);
        float elapsed = 0f;
        while (elapsed < half)
        {
            transform.localScale = Vector3.LerpUnclamped(
                _baseScale,
                _baseScale * _activationScale,
                elapsed / half);
            elapsed += Time.unscaledDeltaTime;
            yield return null;
        }

        elapsed = 0f;
        while (elapsed < half)
        {
            transform.localScale = Vector3.LerpUnclamped(
                _baseScale * _activationScale,
                _baseScale,
                elapsed / half);
            elapsed += Time.unscaledDeltaTime;
            yield return null;
        }

        transform.localScale = _baseScale;
        if (_highlight != null)
            _highlight.gameObject.SetActive(false);
        _activationRoutine = null;
    }

    private void StopActivation()
    {
        if (_activationRoutine != null)
        {
            StopCoroutine(_activationRoutine);
            _activationRoutine = null;
        }
        transform.localScale = _baseScale;
        if (_highlight != null)
            _highlight.gameObject.SetActive(false);
    }

    private void OnDisable()
    {
        if (LocalizationManager.HasInstance)
            LocalizationManager.Instance.Unregister(this);
        StopActivation();
    }

    private void OnDestroy()
    {
        StopActivation();
        if (_selectButton != null)
            _selectButton.onClick.RemoveListener(HandleSelectButtonClicked);
        if (LocalizationManager.HasInstance)
            LocalizationManager.Instance.Unregister(this);
        _onCardDropped = null;
        _onSlotClicked = null;
        _onHoverChanged = null;
    }
}
