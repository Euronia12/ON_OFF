// =================================================================
// [스크립트 목적]  타이틀 전용 손패 카드 표시와 드래그 입력
// [의존 관계]      - UGUI EventSystem, DOTween, TitleHandCardSeed
// =================================================================

using System;
using System.Collections;
using Cysharp.Threading.Tasks;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

[RequireComponent(typeof(RectTransform), typeof(CanvasGroup))]
public sealed class TitleCardView : MonoBehaviour,
    IBeginDragHandler, IDragHandler, IEndDragHandler,
    IPointerEnterHandler, IPointerExitHandler
{
    [Header("표시")]
    [SerializeField] private Image _background;
    [SerializeField] private Image _iconImage;
    [SerializeField] private TMP_Text _nameText;

    [Header("방향 아이콘")]
    [SerializeField] private GameObject _up;
    [SerializeField] private GameObject _down;
    [SerializeField] private GameObject _left;
    [SerializeField] private GameObject _right;
    [SerializeField] private GameObject _upLeft;
    [SerializeField] private GameObject _upRight;
    [SerializeField] private GameObject _downLeft;
    [SerializeField] private GameObject _downRight;

    [Header("상태 색상")]
    [SerializeField] private Color _defaultColor = Color.white;
    [SerializeField] private Color _draggingColor = new Color(0.8f, 0.9f, 1f, 1f);
    [SerializeField] private Color _activatedColor = new Color(1f, 0.9f, 0.45f, 1f);

    [Header("손패 연출")]
    [Min(1f)] [SerializeField] private float _hoverScale = 1.2f;
    [Min(0f)] [SerializeField] private float _hoverOffsetY = 40f;
    [Range(0.1f, 1f)] [SerializeField] private float _dragScale = 0.6f;
    [Min(0.01f)] [SerializeField] private float _moveDuration = 0.12f;

    [Header("발동 연출")]
    [Min(0.01f)] [SerializeField] private float _activationDuration = 0.35f;
    [Min(1f)] [SerializeField] private float _activationScale = 1.15f;

    [Header("주의 연출")]
    [Min(0f)] [SerializeField] private float _attentionShakeAngle = 6f;
    [Min(0.01f)] [SerializeField] private float _attentionShakeDuration = 0.28f;
    [Min(1f)] [SerializeField] private float _attentionScale = 1.06f;

    private RectTransform _rect;
    private CanvasGroup _canvasGroup;
    private RectTransform _dragRoot;
    private Transform _homeParent;
    private int _homeSiblingIndex;
    private Vector2 _homeAnchoredPosition;
    private Vector2 _homeSizeDelta;
    private Quaternion _homeRotation = Quaternion.identity;
    private Vector2 _dragPointerOffset;
    private Vector3 _baseScale = Vector3.one;
    private Vector3 _restScale = Vector3.one;
    private float _baseAlpha = 1f;
    private Coroutine _activationRoutine;
    private Coroutine _attentionRoutine;
    private Coroutine _motionRoutine;
    private Action<TitleCardView, bool> _onDragStateChanged;
    private string _displayNameKey;
    private Sprite _icon;
    private bool _dropHandled;
    private bool _isHovering;

    public ETitleDirection Direction { get; private set; }
    public string DisplayNameKey => _displayNameKey;
    public Sprite Icon => _icon;
    public bool IsHandCard { get; private set; }
    public bool IsDragging { get; private set; }
    public float ActivationDuration => _activationDuration;

    public void InitializeHand(
        TitleHandCardSeed seed,
        RectTransform dragRoot,
        Action<TitleCardView, bool> onDragStateChanged)
    {
        CacheReferences();
        IsHandCard = true;
        Direction = seed != null ? seed.Direction : ETitleDirection.None;
        _dragRoot = dragRoot;
        _onDragStateChanged = onDragStateChanged;
        _displayNameKey = seed?.DisplayName ?? string.Empty;
        _icon = seed?.Icon;

        if (_iconImage != null)
        {
            _iconImage.sprite = _icon;
            _iconImage.gameObject.SetActive(_icon != null);
        }

        ToggleDirectionIcons(Direction);
        RefreshLocalization();
        ApplyDefaultVisual();
    }

    public void SetHandPose(Vector2 anchoredPosition, float rotation, int siblingIndex)
    {
        CacheReferences();
        _rect.anchorMin = new Vector2(0.5f, 0.5f);
        _rect.anchorMax = new Vector2(0.5f, 0.5f);
        _rect.pivot = new Vector2(0.5f, 0.5f);
        _rect.anchoredPosition = anchoredPosition;
        _rect.localRotation = Quaternion.Euler(0f, 0f, rotation);
        _rect.localScale = _baseScale;
        _rect.SetSiblingIndex(siblingIndex);

        _homeParent = _rect.parent;
        _homeSiblingIndex = siblingIndex;
        _homeAnchoredPosition = anchoredPosition;
        _homeSizeDelta = _rect.sizeDelta;
        _homeRotation = _rect.localRotation;
        _restScale = _baseScale;
    }

    public void MarkDropHandled()
    {
        _dropHandled = true;
    }

    public void ReturnToHand()
    {
        StopActivation();
        StopAttention();
        KillMotionTween();
        bool wasDragging = IsDragging;

        if (_homeParent != null)
        {
            _rect.SetParent(_homeParent, false);
            _rect.SetSiblingIndex(Mathf.Clamp(_homeSiblingIndex, 0, _homeParent.childCount - 1));
            _rect.anchorMin = new Vector2(0.5f, 0.5f);
            _rect.anchorMax = new Vector2(0.5f, 0.5f);
            _rect.pivot = new Vector2(0.5f, 0.5f);
            _rect.sizeDelta = _homeSizeDelta;
            _rect.anchoredPosition = _homeAnchoredPosition;
            _rect.localRotation = _homeRotation;
        }

        _restScale = _baseScale;
        _rect.localScale = _restScale;
        _canvasGroup.blocksRaycasts = true;
        _canvasGroup.alpha = _baseAlpha;
        IsDragging = false;
        _dropHandled = true;
        ApplyDefaultVisual();
        if (wasDragging)
            _onDragStateChanged?.Invoke(this, false);
    }

    public void HideForPlacement()
    {
        StopActivation();
        KillMotionTween();
        bool wasDragging = IsDragging;
        _canvasGroup.alpha = 0f;
        _canvasGroup.blocksRaycasts = false;
        IsDragging = false;
        _dropHandled = true;
        if (wasDragging)
            _onDragStateChanged?.Invoke(this, false);
    }

    public void PlayActivation()
    {
        StopActivation();
        _activationRoutine = StartCoroutine(ActivationRoutine());
    }

    public void PlayAttentionShake()
    {
        if (IsDragging)
            return;
        StopAttention();
        _attentionRoutine = StartCoroutine(AttentionShakeRoutine());
    }

    public void OnPointerEnter(PointerEventData eventData)
    {
        if (!IsHandCard || IsDragging || _activationRoutine != null)
            return;

        _isHovering = true;
        if (AudioManager.HasInstance)
            AudioManager.Instance.PlayUiAsync(AudioKeys.Title.CARD_HOVER).Forget();
        _rect.SetAsLastSibling();
        StartMotion(
            _homeAnchoredPosition + Vector2.up * _hoverOffsetY,
            Quaternion.identity,
            _baseScale * _hoverScale);
    }

    public void OnPointerExit(PointerEventData eventData)
    {
        if (!_isHovering || IsDragging)
            return;

        _isHovering = false;
        if (_homeParent != null)
            _rect.SetSiblingIndex(Mathf.Clamp(_homeSiblingIndex, 0, _homeParent.childCount - 1));
        StartMotion(_homeAnchoredPosition, _homeRotation, _baseScale);
    }

    public void OnBeginDrag(PointerEventData eventData)
    {
        if (!IsHandCard)
            return;

        _isHovering = false;
        StopActivation();
        StopAttention();
        KillMotionTween();
        IsDragging = true;
        _dropHandled = false;
        _canvasGroup.blocksRaycasts = false;
        if (_dragRoot != null)
        {
            _rect.SetParent(_dragRoot, true);
            _rect.SetAsLastSibling();
            CaptureDragPointerOffset(eventData);
        }
        else
        {
            _dragPointerOffset = Vector2.zero;
        }
        ApplyDraggingVisual();
        _onDragStateChanged?.Invoke(this, true);
        UpdateDragPosition(eventData);
    }

    public void OnDrag(PointerEventData eventData)
    {
        if (IsDragging)
            UpdateDragPosition(eventData);
    }

    public void OnEndDrag(PointerEventData eventData)
    {
        if (!IsDragging)
            return;

        IsDragging = false;
        _canvasGroup.blocksRaycasts = true;
        _onDragStateChanged?.Invoke(this, false);
        if (!_dropHandled)
            ReturnToHand();
    }

    public void RefreshLocalization()
    {
        if (_nameText == null)
            return;

        LocalizedFontUtility.ApplyCurrentFont(_nameText);
        _nameText.text = LocalizationManager.HasInstance && !string.IsNullOrEmpty(_displayNameKey)
            ? LocalizationManager.Instance.Get(_displayNameKey)
            : _displayNameKey;
    }

    private void ApplyDefaultVisual()
    {
        if (_background != null)
            _background.color = _defaultColor;
    }

    private void ApplyDraggingVisual()
    {
        if (_background != null)
            _background.color = _draggingColor;
        _rect.localRotation = Quaternion.identity;
        _rect.localScale = _baseScale * _dragScale;
    }

    private IEnumerator ActivationRoutine()
    {
        if (_background != null)
            _background.color = _activatedColor;

        float half = Mathf.Max(0.01f, _activationDuration * 0.5f);
        float elapsed = 0f;
        while (elapsed < half)
        {
            _rect.localScale = Vector3.LerpUnclamped(
                _restScale,
                _restScale * _activationScale,
                SmoothStep(elapsed / half));
            elapsed += Time.unscaledDeltaTime;
            yield return null;
        }

        elapsed = 0f;
        while (elapsed < half)
        {
            _rect.localScale = Vector3.LerpUnclamped(
                _restScale * _activationScale,
                _restScale,
                SmoothStep(elapsed / half));
            elapsed += Time.unscaledDeltaTime;
            yield return null;
        }

        _rect.localScale = _restScale;
        ApplyDefaultVisual();
        _activationRoutine = null;
    }

    private IEnumerator AttentionShakeRoutine()
    {
        float duration = Mathf.Max(0.01f, _attentionShakeDuration);
        float elapsed = 0f;
        while (elapsed < duration)
        {
            float progress = elapsed / duration;
            float wave = Mathf.Sin(progress * Mathf.PI * 6f) * (1f - progress);
            _rect.localRotation = _homeRotation * Quaternion.Euler(0f, 0f, wave * _attentionShakeAngle);
            _rect.localScale = Vector3.LerpUnclamped(
                _baseScale * _attentionScale,
                _baseScale,
                SmoothStep(progress));
            elapsed += Time.unscaledDeltaTime;
            yield return null;
        }

        RestoreHomeTransform();
        _attentionRoutine = null;
    }

    private void UpdateDragPosition(PointerEventData eventData)
    {
        RectTransform parentRect = _rect.parent as RectTransform;
        if (parentRect != null && RectTransformUtility.ScreenPointToLocalPointInRectangle(
                parentRect, eventData.position, eventData.pressEventCamera, out Vector2 local))
            _rect.anchoredPosition = local - _dragPointerOffset;
    }

    private void CaptureDragPointerOffset(PointerEventData eventData)
    {
        RectTransform parentRect = _rect.parent as RectTransform;
        if (parentRect == null || !RectTransformUtility.ScreenPointToLocalPointInRectangle(
                parentRect, eventData.position, eventData.pressEventCamera, out Vector2 pointerLocal))
        {
            _dragPointerOffset = Vector2.zero;
            return;
        }
        _dragPointerOffset = pointerLocal - _rect.anchoredPosition;
    }

    private void ToggleDirectionIcons(ETitleDirection direction)
    {
        SetActive(_up, direction == ETitleDirection.Up);
        SetActive(_down, direction == ETitleDirection.Down);
        SetActive(_left, direction == ETitleDirection.Left);
        SetActive(_right, direction == ETitleDirection.Right);
        SetActive(_upLeft, direction == ETitleDirection.UpLeft);
        SetActive(_upRight, direction == ETitleDirection.UpRight);
        SetActive(_downLeft, direction == ETitleDirection.DownLeft);
        SetActive(_downRight, direction == ETitleDirection.DownRight);
    }

    private static void SetActive(GameObject target, bool active)
    {
        if (target != null && target.activeSelf != active)
            target.SetActive(active);
    }

    private void Awake()
    {
        CacheReferences();
    }

    private void CacheReferences()
    {
        _rect ??= GetComponent<RectTransform>();
        _canvasGroup ??= GetComponent<CanvasGroup>();
        _background ??= GetComponent<Image>();
        _baseScale = transform.localScale;
        _restScale = _baseScale;
        _baseAlpha = _canvasGroup.alpha;
    }

    private void StopActivation()
    {
        if (_activationRoutine != null)
        {
            StopCoroutine(_activationRoutine);
            _activationRoutine = null;
        }
        _rect.localScale = _restScale;
        ApplyDefaultVisual();
    }

    private void StopAttention()
    {
        if (_attentionRoutine == null)
            return;
        StopCoroutine(_attentionRoutine);
        _attentionRoutine = null;
        RestoreHomeTransform();
    }

    private void RestoreHomeTransform()
    {
        KillMotionTween();
        _rect.localScale = _baseScale;
        _rect.localRotation = _homeRotation;
    }

    private void StartMotion(Vector2 targetPosition, Quaternion targetRotation, Vector3 targetScale)
    {
        KillMotionTween();
        _motionRoutine = StartCoroutine(MotionRoutine(targetPosition, targetRotation, targetScale));
    }

    private IEnumerator MotionRoutine(Vector2 targetPosition, Quaternion targetRotation, Vector3 targetScale)
    {
        Vector2 startPosition = _rect.anchoredPosition;
        Quaternion startRotation = _rect.localRotation;
        Vector3 startScale = _rect.localScale;
        float duration = Mathf.Max(0.01f, _moveDuration);
        float elapsed = 0f;

        while (elapsed < duration)
        {
            float progress = Mathf.Clamp01(elapsed / duration);
            float eased = 1f - (1f - progress) * (1f - progress); // Ease.OutQuad
            _rect.anchoredPosition = Vector2.LerpUnclamped(startPosition, targetPosition, eased);
            _rect.localRotation = Quaternion.SlerpUnclamped(startRotation, targetRotation, eased);
            _rect.localScale = Vector3.LerpUnclamped(startScale, targetScale, eased);
            elapsed += Time.unscaledDeltaTime;
            yield return null;
        }

        _rect.anchoredPosition = targetPosition;
        _rect.localRotation = targetRotation;
        _rect.localScale = targetScale;
        _motionRoutine = null;
    }

    private void KillMotionTween()
    {
        if (_motionRoutine == null)
            return;

        StopCoroutine(_motionRoutine);
        _motionRoutine = null;
    }

    private static float SmoothStep(float value)
    {
        value = Mathf.Clamp01(value);
        return value * value * (3f - 2f * value);
    }

    private void OnDisable()
    {
        _isHovering = false;
        KillMotionTween();
        StopActivation();
        StopAttention();
        IsDragging = false;
    }

    private void OnDestroy()
    {
        KillMotionTween();
        StopActivation();
        StopAttention();
        _onDragStateChanged = null;
    }
}
