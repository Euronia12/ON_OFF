using DG.Tweening;
using UnityEngine;
using UnityEngine.UI;

public sealed class TitleLogoIntro : MonoBehaviour
{
    private static readonly Color OnColor = Color.white;
    private static readonly Color OffColor = new Color32(160, 164, 160, 255);

    [Header("연출 속도")]
    [SerializeField] private float _dropDuration = 0.45f;
    [SerializeField] private float _punchDuration = 0.16f;
    [SerializeField] private float _signalDuration = 0.12f;
    [SerializeField] private float _cellToggleDuration = 0.09f;
    [SerializeField] private float _dropHeight = 120f;

    [Header("연쇄 신호선")]
    [SerializeField] private Color _signalColor = new Color(0.1f, 0.95f, 1f, 1f);
    [SerializeField] private float _signalWidth = 0.05f;

    [SerializeField] private GridLayoutGroup _layout;
    [SerializeField] private RectTransform _onO;
    [SerializeField] private RectTransform _onN;
    [SerializeField] private RectTransform _and;
    [SerializeField] private RectTransform _offO;
    [SerializeField] private RectTransform _offF1;
    [SerializeField] private RectTransform _offF2;

    private Sequence _sequence;
    private Vector2[] _positions;
    private LineRenderer _signalLine;
    private Material _signalMaterial;
    private Vector3 _signalFrom;
    private Vector3 _signalTo;

    public void Play()
    {
        KillSequence();
        CacheLayoutPositions();
        ApplyInitialState();

        CanvasGroup andGroup = _and.GetComponent<CanvasGroup>();

        _sequence = DOTween.Sequence().SetUpdate(true).SetLink(gameObject);
        _sequence.Append(_and.DOAnchorPos(_positions[2], _dropDuration).SetEase(Ease.OutCubic));
        _sequence.Join(andGroup.DOFade(1f, _dropDuration));
        _sequence.Append(_and.DOPunchScale(Vector3.one * 0.12f, _punchDuration, 5, 0.5f));
        AppendSignal(_and, _onN);
        _sequence.Append(GetOccupiedImage(_onN).DOColor(OnColor, _cellToggleDuration));
        AppendSignal(_onN, _onO);
        _sequence.Append(GetOccupiedImage(_onO).DOColor(OnColor, _cellToggleDuration));
        AppendSignal(_and, _offO);
        _sequence.Append(GetOccupiedImage(_offO).DOColor(OffColor, _cellToggleDuration));
        _sequence.OnComplete(ApplyFinalState);
    }

    private void AppendSignal(RectTransform from, RectTransform to)
    {
        _sequence.AppendCallback(() => PrepareSignalLine(from.position, to.position));
        _sequence.Append(DOVirtual.Float(0f, 1f, _signalDuration, UpdateSignalLine).SetEase(Ease.Linear));
        _sequence.AppendCallback(HideSignalLine);
    }

    private void PrepareSignalLine(Vector3 from, Vector3 to)
    {
        EnsureSignalLine();
        _signalFrom = from;
        _signalTo = to;
        _signalLine.enabled = true;
        _signalLine.SetPosition(0, from);
        _signalLine.SetPosition(1, from);
    }

    private void UpdateSignalLine(float progress)
    {
        const float extendRatio = 0.55f;

        if (progress < extendRatio)
        {
            _signalLine.SetPosition(0, _signalFrom);
            _signalLine.SetPosition(1, Vector3.Lerp(_signalFrom, _signalTo, progress / extendRatio));
            return;
        }

        float shrinkProgress = (progress - extendRatio) / (1f - extendRatio);
        _signalLine.SetPosition(0, Vector3.Lerp(_signalFrom, _signalTo, shrinkProgress));
        _signalLine.SetPosition(1, _signalTo);
    }

    private void EnsureSignalLine()
    {
        if (_signalLine != null)
            return;

        _signalLine = gameObject.AddComponent<LineRenderer>();
        _signalLine.useWorldSpace = true;
        _signalLine.positionCount = 2;
        _signalLine.startWidth = _signalWidth;
        _signalLine.endWidth = _signalWidth;
        _signalLine.startColor = _signalColor;
        _signalLine.endColor = _signalColor;
        _signalLine.sortingLayerName = "UI";
        _signalLine.sortingOrder = 1;

        Shader shader = Shader.Find("Sprites/Default");
        if (shader == null)
            return;

        _signalMaterial = new Material(shader) { color = _signalColor };
        _signalLine.material = _signalMaterial;
    }

    private void HideSignalLine()
    {
        if (_signalLine != null)
            _signalLine.enabled = false;
    }

    private void CacheLayoutPositions()
    {
        _layout.enabled = true;
        Canvas.ForceUpdateCanvases();
        LayoutRebuilder.ForceRebuildLayoutImmediate((RectTransform)_layout.transform);

        RectTransform[] cells = { _onO, _onN, _and, _offO, _offF1, _offF2 };
        _positions = new Vector2[cells.Length];
        for (int i = 0; i < cells.Length; i++)
            _positions[i] = cells[i].anchoredPosition;

        _layout.enabled = false;
    }

    private void ApplyInitialState()
    {
        RestoreTransforms();
        SetOccupiedColor(_onO, OffColor);
        SetOccupiedColor(_onN, OffColor);
        SetAlpha(_and, 0f);
        SetOccupiedColor(_offO, OnColor);
        SetOccupiedColor(_offF1, OffColor);
        SetOccupiedColor(_offF2, OffColor);
        _and.anchoredPosition = _positions[2] + Vector2.up * _dropHeight;
    }

    private void ApplyFinalState()
    {
        RestoreTransforms();
        SetOccupiedColor(_onO, OnColor);
        SetOccupiedColor(_onN, OnColor);
        SetAlpha(_and, 1f);
        SetOccupiedColor(_offO, OffColor);
        SetOccupiedColor(_offF1, OffColor);
        SetOccupiedColor(_offF2, OffColor);
    }

    private void RestoreTransforms()
    {
        if (_positions == null)
            return;

        RectTransform[] cells = { _onO, _onN, _and, _offO, _offF1, _offF2 };
        for (int i = 0; i < cells.Length; i++)
        {
            cells[i].anchoredPosition = _positions[i];
            cells[i].localScale = Vector3.one;
        }
    }

    private static void SetAlpha(RectTransform cell, float alpha)
    {
        cell.GetComponent<CanvasGroup>().alpha = alpha;
    }

    private static Image GetOccupiedImage(RectTransform cell)
    {
        return cell.Find("OccupiedVis").GetComponent<Image>();
    }

    private static void SetOccupiedColor(RectTransform cell, Color color)
    {
        GetOccupiedImage(cell).color = color;
        SetAlpha(cell, 1f);
    }

    private void KillSequence()
    {
        _sequence?.Kill();
        _sequence = null;
    }

    private void OnDisable()
    {
        KillSequence();
        HideSignalLine();
        ApplyFinalState();
    }

    private void OnDestroy()
    {
        if (_signalMaterial != null)
            Destroy(_signalMaterial);
    }
}
