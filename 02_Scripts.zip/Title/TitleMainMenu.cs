// =================================================================
// [스크립트 목적]  타이틀의 일반 버튼형 메인 메뉴 표시와 액션 전달
// [주요 변수]      - _buttonRoot / _buttonTemplate / _entries
// [직렬화 전환]     버튼과 텍스트는 UITitle.prefab에 직접 구성하고 런타임 생성하지 않음
// [의존 관계]      - UGUI Button, TMP, LocalizationManager
// [원칙]           실제 메뉴 기능 실행은 TitleController가 담당하고 이 컴포넌트는 선택 액션만 전달
// =================================================================

using System;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public sealed class TitleMainMenu : MonoBehaviour
{
    [Serializable]
    private sealed class MenuEntry
    {
        [Tooltip("TitleController로 전달할 메뉴 액션")]
        [SerializeField] private ETitleMenuAction _action;

        [Tooltip("버튼 문구에 사용할 기존 로컬라이제이션 키")]
        [SerializeField] private string _localizationKey;

        [Tooltip("UITitle 프리팹에 직렬화된 메뉴 버튼")]
        [SerializeField] private Button _button;

        [Tooltip("버튼 문구를 표시할 TMP 텍스트")]
        [SerializeField] private TMP_Text _label;

        public ETitleMenuAction Action => _action;
        public string LocalizationKey => _localizationKey;
        public Button Button => _button;
        public TMP_Text Label => _label;
    }

    [Header("버튼 구성")]
    [Tooltip("표시 순서대로 직렬화한 메뉴 버튼, 액션, 로컬라이제이션 키")]
    [SerializeField] private List<MenuEntry> _entries = new();

    [Header("입력")]
    [Tooltip("빠른 연속 입력을 한 번으로 제한하는 시간(초)")]
    [Min(0f)]
    [SerializeField] private float _clickLockDuration = 0.2f;

    private bool _isInitialized;
    private float _clickUnlockTime;

    public event Action<ETitleMenuAction> OnMenuActionSelected;

    public bool Initialize()
    {
        if (!_isInitialized && !BindButtons())
            return false;

        RefreshAvailability();
        RefreshLocalization();
        ResetInteractionState();
        return true;
    }

    public void RefreshLocalization()
    {
        bool useBold = !LocalizationManager.HasInstance ||
                       LocalizationManager.Instance.CurrentLanguage != SystemLanguage.ChineseTraditional;

        for (int i = 0; i < _entries.Count; i++)
        {
            MenuEntry entry = _entries[i];
            if (entry == null || entry.Label == null)
                continue;

            LocalizedFontUtility.ApplyCurrentFont(entry.Label);
            entry.Label.fontStyle = useBold ? FontStyles.Bold : FontStyles.Normal;
            string key = entry.LocalizationKey;
            entry.Label.text = LocalizationManager.HasInstance
                ? LocalizationManager.Instance.Get(key)
                : key;
        }
    }

    public void ResetInteractionState()
    {
        _clickUnlockTime = 0f;
        RefreshAvailability();

        for (int i = 0; i < _entries.Count; i++)
        {
            Button button = _entries[i]?.Button;
            if (button == null || !button.gameObject.activeInHierarchy || !button.interactable)
                continue;

            if (EventSystem.current != null)
                button.Select();
            break;
        }
    }

    private bool BindButtons()
    {
        if (_entries.Count == 0)
        {
            Debug.LogError("[TitleMainMenu] 직렬화된 메뉴 버튼이 필요합니다.");
            return false;
        }

        for (int i = 0; i < _entries.Count; i++)
        {
            MenuEntry entry = _entries[i];
            if (entry == null || entry.Action == ETitleMenuAction.None ||
                string.IsNullOrWhiteSpace(entry.LocalizationKey) ||
                entry.Button == null || entry.Label == null)
            {
                Debug.LogError($"[TitleMainMenu] 메뉴 버튼 직렬화 누락: index {i}");
                return false;
            }
        }

        for (int i = 0; i < _entries.Count; i++)
        {
            MenuEntry entry = _entries[i];
            ETitleMenuAction action = entry.Action;
            entry.Button.onClick.AddListener(() => HandleButtonClicked(action));
        }

        _isInitialized = true;
        return true;
    }

    private void RefreshAvailability()
    {
        for (int i = 0; i < _entries.Count; i++)
        {
            MenuEntry entry = _entries[i];
            if (entry == null || entry.Button == null)
                continue;

            bool isAvailable = entry.Action != ETitleMenuAction.Continue ||
                               RunSaveSystem.HasSave;
            entry.Button.gameObject.SetActive(isAvailable);
            entry.Button.interactable = isAvailable;
        }
    }

    private void HandleButtonClicked(ETitleMenuAction action)
    {
        if (Time.unscaledTime < _clickUnlockTime)
            return;

        _clickUnlockTime = Time.unscaledTime + _clickLockDuration;
        OnMenuActionSelected?.Invoke(action);
    }

    private void OnDisable()
    {
        _clickUnlockTime = 0f;
    }

    private void OnDestroy()
    {
        OnMenuActionSelected = null;
    }
}
