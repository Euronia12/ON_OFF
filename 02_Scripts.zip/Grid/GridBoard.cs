// =================================================================
// [스크립트 목적]  5×5 그리드 초기화 및 셀 관리. World Space에 배치.
// [주요 변수]      - _cellPrefab  : GridCell 컴포넌트를 가진 셀 프리팹
//                  - _cells       : [row, col] 2D 배열
//                  - _rows, _cols : 그리드 크기 (기본 5×5, 나중에 변경 가능)
// [의존 관계]      MonoBehaviour, GridCell
// [배치]           World Space에 빈 GameObject 만들고 부착.
//                 셀 프리팹에는 BoxCollider2D + GridCell 필수.
// [설계]           _rows/_cols Inspector 노출 → 나중에 크기 변경 용이
// =================================================================

using UnityEngine;

public class GridBoard : MonoBehaviour
{
    // ─────────────────────────────────────────────
    // Inspector
    // ─────────────────────────────────────────────

    [Header("그리드 설정")]
    [Tooltip("그리드 행 수.")]
    [SerializeField] private int _rows = 5;

    [Tooltip("그리드 열 수.")]
    [SerializeField] private int _cols = 5;

    [Tooltip("셀 간격 (World 단위).")]
    [SerializeField] private float _cellSize = 1.2f;

    [Header("셀 프리팹")]
    [Tooltip("GridCell + BoxCollider2D가 부착된 셀 프리팹.")]
    [SerializeField] private GridCell _cellPrefab;

    // ─────────────────────────────────────────────
    // 공개 API
    // ─────────────────────────────────────────────

    public GridCell[,] Cells => _cells;
    public int Rows => _rows;
    public int Cols => _cols;

    /// <summary>좌표로 셀 접근. 범위 초과 시 null 반환.</summary>
    public GridCell GetCell(int row, int col)
    {
        if (row < 0 || row >= _rows || col < 0 || col >= _cols) return null;
        return _cells[row, col];
    }

    // ─────────────────────────────────────────────
    // Private
    // ─────────────────────────────────────────────

    private GridCell[,] _cells;

    // ─────────────────────────────────────────────
    // Unity
    // ─────────────────────────────────────────────

    private void Awake()
    {
        BuildGrid();
    }

    // ─────────────────────────────────────────────
    // 그리드 생성
    // ─────────────────────────────────────────────

    private void BuildGrid()
    {
        if (_cellPrefab == null)
        {
            GameLogger.LogError(ELogCategory.Gameplay, "[GridBoard] _cellPrefab이 미지정.");
            return;
        }

        _cells = new GridCell[_rows, _cols];

        float startX = -(_cols - 1) * _cellSize / 2f;
        float startY = -(_rows - 1) * _cellSize / 2f;

        for (int r = 0; r < _rows; r++)
        {
            for (int c = 0; c < _cols; c++)
            {
                // 로컬 좌표로 생성 → 부모(GridBoard)의 회전/스케일이 자동 반영
                var localPos = new Vector3(
                    startX + c * _cellSize,
                    startY + r * _cellSize,
                    0f);

                var cell = Instantiate(_cellPrefab, transform);
                cell.transform.localPosition = localPos;
                cell.transform.localRotation = Quaternion.identity;
                cell.Initialize(r, c);
                _cells[r, c] = cell;
            }
        }

        GameLogger.Log(ELogCategory.Gameplay,
            $"[GridBoard] {_rows}×{_cols} 그리드 생성 완료.");
    }

    // ─────────────────────────────────────────────
    // 유틸
    // ─────────────────────────────────────────────

    /// <summary>전체 셀 초기화 (라운드 시작 시 사용).</summary>
    public void ClearAll()
    {
        if (_cells == null) return;
        foreach (var cell in _cells)
            cell?.Clear();
    }

    /// <summary>빈 셀 목록 반환.</summary>
    public System.Collections.Generic.List<GridCell> GetEmptyCells()
    {
        var result = new System.Collections.Generic.List<GridCell>();
        if (_cells == null) return result;

        foreach (var cell in _cells)
        {
            if (cell != null && cell.IsEmpty)
                result.Add(cell);
        }
        return result;
    }
}