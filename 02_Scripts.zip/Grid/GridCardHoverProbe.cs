// =================================================================
// [스크립트 목적]  그리드에 놓인 카드(점유 슬롯)에 마우스를 올리면 상세 확대본 표시.
//                 그리드는 UI 가 아니라 월드 콜라이더이므로 OnPointerEnter 가 오지 않는다.
//                 → 매 프레임 마우스 아래를 Raycast 로 직접 탐지(폴링)한다.
// [주요 변수]      - _camera        : 스크린→월드 Raycast 카메라 (비우면 Camera.main)
//                  - _slotLayerMask : 그리드 슬롯 레이어 마스크 (GridSlot BoxCollider)
//                  - _rayDistance   : Raycast 최대 거리
//                  - _detailPanel   : 카드 상세 확대본 (손패와 같은 인스턴스를 공유 연결)
// [의존 관계]      - GridSlot(OccupiedCard) / UICardDetailPanel / Camera
//                  - 매니저 수정 없음. 슬롯에서 직접 카드 데이터를 얻는다.
// [배치]           전투 씬(또는 UIBattle) 상주. _detailPanel 은 손패가 쓰는 패널과 동일 연결.
// [설계 노트]      - CardPlacementInput 의 FindSlotAt 과 동일 방식의 Raycast 를 자체 보유한다.
//                    (그 클래스는 배치 입력 책임 — 호버 폴링까지 떠안기지 않도록 분리)
//                  - OnMouseEnter 대신 폴링을 쓰는 이유: 그리드엔 마우스 이벤트/PhysicsRaycaster
//                    처리가 없고, CardPlacementInput 이 이미 같은 Physics.Raycast 경로를 검증함.
//                  - 호버한 슬롯의 월드 위치를 스크린 좌표로 변환해 패널을 카드 오른쪽 상단에 띄운다(ShowAt).
//                  - 드래그 중(UI 위 포인터)에는 배치 프리뷰가 우선이므로 확대본을 숨긴다.
// =================================================================

using Cysharp.Threading.Tasks;
using UnityEngine;
using UnityEngine.InputSystem;

/// <summary>
/// 그리드 점유 슬롯 호버 감지 폴링 컴포넌트.
/// 매 프레임 마우스 아래 슬롯을 Raycast 로 찾아, 카드가 놓인 칸이면 확대본을 띄운다.
/// </summary>
public sealed class GridCardHoverProbe : MonoBehaviour
{
    private readonly RaycastHit[] _slotHits = new RaycastHit[32];

    [Header("Raycast")]
    [Tooltip("스크린→월드 Raycast 카메라. 비우면 Camera.main")]
    [SerializeField] private Camera _camera;

    [Tooltip("그리드 슬롯 레이어 마스크. 슬롯 BoxCollider 가 속한 레이어")]
    [SerializeField] private LayerMask _slotLayerMask = ~0;

    [Tooltip("Raycast 최대 거리")]
    [Min(1f)]
    [SerializeField] private float _rayDistance = 100f;

    [Header("확대본")]
    [Tooltip("카드 상세 확대본. 손패가 쓰는 패널과 같은 인스턴스를 연결(공유)")]
    [SerializeField] private UICardDetailPanel _detailPanel;

    private Camera Cam => _camera != null ? _camera : Camera.main;

    private GridSlot _currentSlot;  // 현재 확대본이 향하는 슬롯 (중복 갱신 방지)
    private Card _previewCard;       // 현재 영향 경로 프리뷰를 표시 중인 카드 (중복 갱신 방지)
    private int _lastActivationVersion;
    private CardStatCalculator _calculator;

    private void OnEnable()
    {
        ClearCurrent();
    }

    private void OnDisable()
    {
        HideDetail();
        ClearHoverPreview();
    }

    private void Update()
    {
        if (_detailPanel == null || Mouse.current == null)
        {
            return;
        }

        // 포인터가 UI(손패 카드 등) 위면 그쪽 호버가 우선 — 그리드 확대본 숨김.
        // (손패 카드 드래그/호버 중 그리드 확대본이 끼어드는 것 방지)
        if (UnityEngine.EventSystems.EventSystem.current != null &&
            UnityEngine.EventSystems.EventSystem.current.IsPointerOverGameObject())
        {
            HideDetail();
            ClearHoverPreview();
            return;
        }

        Vector2 screenPos = Mouse.current.position.ReadValue();
        GridSlot slot = FindSlotAt(screenPos);

        // 점유된 슬롯(카드 있음)만 대상. 빈 칸·슬롯 밖이면 숨김.
        if (slot == null || slot.IsEmpty || slot.OccupiedCard == null)
        {
            HideDetail();
            ClearHoverPreview();
            return;
        }

        _currentSlot = slot;

        if (GridManager.HasInstance && GridManager.Instance.IsCardInfoHidden)
        {
            HideDetail();
            ClearHoverPreview();
            return;
        }

        // 호버한 슬롯(=카드)의 월드 위치를 스크린 좌표로 변환해 패널을 카드 오른쪽 상단에 띄운다.
        Vector2 cardScreenPos = WorldToScreen(slot.transform.position);
        _detailPanel.ShowAt(slot.OccupiedCard, GetCalculator(), cardScreenPos);

        // 카드가 영향을 주는 칸(경로/패턴/오라)을 그리드 테두리 셰이더로 강조.
        ShowHoverPreview(slot.OccupiedCard);
    }

    /// <summary>호버한 배치 카드의 영향 경로 프리뷰를 표시한다. (스킬 시전 중에는 양보)</summary>
    private void ShowHoverPreview(Card card)
    {
        if (card == null || !GridManager.HasInstance) return;

        // 보존 페이즈에는 보존 하이라이트가 우선 — 호버 경로 프리뷰를 표시하지 않는다.
        if (BattleManager.HasInstance &&
            BattleManager.Instance.CurrentPhase == EBattlePhase.PreserveSelect)
        {
            ClearHoverPreview();
            return;
        }

        // 스킬 타겟 프리뷰가 우선이면 호버 프리뷰는 표시하지 않는다.
        if (GridManager.Instance.IsSkillPreviewActive)
        {
            ClearHoverPreview();
            return;
        }

        int activationVersion = GridManager.Instance.ActivationVersion;
        if (_previewCard == card && _lastActivationVersion == activationVersion) return;

        _previewCard = card;
        _lastActivationVersion = activationVersion;
        GridManager.Instance.ShowPlacedCardPreview(card);
    }

    /// <summary>호버 경로 프리뷰 해제. 배치/스킬 프리뷰는 GridManager 의 별도 레이어가 유지한다.</summary>
    private void ClearHoverPreview()
    {
        if (_previewCard == null) return;
        _previewCard = null;
        _lastActivationVersion = 0;

        if (GridManager.HasInstance)
        {
            GridManager.Instance.ClearHoverPreview();
        }
    }

    /// <summary>월드 위치를 스크린 좌표로 변환. 카메라가 없으면 입력값의 xy 폴백.</summary>
    private Vector2 WorldToScreen(Vector3 worldPos)
    {
        Camera cam = Cam;
        if (cam == null) return worldPos;
        Vector3 screen = cam.WorldToScreenPoint(worldPos);
        return new Vector2(screen.x, screen.y);
    }

    private CardStatCalculator GetCalculator()
    {
        if (_calculator == null && GridManager.HasInstance)
        {
            _calculator = new CardStatCalculator(GridManager.Instance);
        }

        return _calculator;
    }

    /// <summary>확대본 숨김 + 현재 슬롯 추적 해제. (표시 중일 때만 패널 Hide 호출)</summary>
    private void HideDetail()
    {
        if (_currentSlot == null) return;
        _currentSlot = null;
        if (_detailPanel != null) _detailPanel.Hide();
    }

    /// <summary>슬롯 추적만 초기화 (패널 Hide 는 안전상 호출). OnEnable 진입용.</summary>
    private void ClearCurrent()
    {
        _currentSlot = null;
        if (_detailPanel != null) _detailPanel.Hide();
    }

    /// <summary>스크린 좌표 아래의 그리드 슬롯을 Raycast 로 탐지. 없으면 null.</summary>
    private GridSlot FindSlotAt(Vector2 screenPos)
    {
        Camera cam = Cam;
        if (cam == null) return null;

        Ray ray = cam.ScreenPointToRay(screenPos);
        int hitCount = Physics.RaycastNonAlloc(
            ray,
            _slotHits,
            _rayDistance,
            _slotLayerMask,
            QueryTriggerInteraction.Collide);

        GridSlot nearestSlot = null;
        float nearestDistance = float.MaxValue;
        for (int i = 0; i < hitCount; i++)
        {
            RaycastHit hit = _slotHits[i];
            if (hit.collider == null) continue;

            GridSlot slot = hit.collider.GetComponentInParent<GridSlot>();
            if (slot == null || hit.distance >= nearestDistance) continue;

            nearestSlot = slot;
            nearestDistance = hit.distance;
        }

        return nearestSlot;
    }
}
