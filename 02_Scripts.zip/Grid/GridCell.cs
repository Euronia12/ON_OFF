// =================================================================
// [스크립트 목적]  5×5 그리드의 셀 하나. 카드 점유 상태 관리.
//                 UICard 드롭 시 OnCardPlaced 이벤트 수신 → 점유 처리.
// [주요 변수]      - Row, Col        : 그리드 내 좌표 (GridBoard가 주입)
//                  - _isOccupied     : 점유 여부
//                  - _placedCard     : 현재 점유한 UICard 참조
// [의존 관계]      MonoBehaviour, EventManager, BoxCollider (Physics3D 탐지용)
// [배치]           GridBoard가 자동 생성. Inspector 직접 배치 불필요.
// [설계]           UICard가 Physics.Raycast로 이 셀을 탐지.
//                 BoxCollider 필수 부착 (RequireComponent로 강제).
//                 그리드가 X축으로 눕혀져 있어 Physics2D 대신 Physics3D 사용.
// =================================================================

using UnityEngine;

[RequireComponent(typeof(BoxCollider))]
public class GridCell : MonoBehaviour
{
    // ─────────────────────────────────────────────
    // Inspector
    // ─────────────────────────────────────────────

    [Header("비주얼")]
    [Tooltip("빈 셀 표시 오브젝트 (비어있을 때 활성).")]
    [SerializeField] private GameObject _emptyVisual;

    [Tooltip("점유 셀 표시 오브젝트 (카드가 놓였을 때 활성).")]
    [SerializeField] private GameObject _occupiedVisual;

    [Tooltip("드롭 가능 하이라이트 오브젝트 (드래그 중 마우스 올라왔을 때 활성).")]
    [SerializeField] private GameObject _highlightVisual;

    // ─────────────────────────────────────────────
    // 공개 상태
    // ─────────────────────────────────────────────

    public int Row { get; private set; }
    public int Col { get; private set; }
    public bool IsEmpty => !_isOccupied;

    /// <summary>현재 이 셀을 점유한 카드. 비어있으면 null.</summary>
    public UICard PlacedCard { get; private set; }

    // ─────────────────────────────────────────────
    // Private
    // ─────────────────────────────────────────────

    private bool _isOccupied;
    private IDisposableEvent _placedSub;

    // ─────────────────────────────────────────────
    // Unity
    // ─────────────────────────────────────────────

    private void OnEnable()
    {
        if (EventManager.HasInstance)
            _placedSub = EventManager.Instance.Subscribe<OnCardPlaced>(OnCardPlaced);
    }

    private void OnDisable()
    {
        _placedSub?.Dispose();
    }

    // ─────────────────────────────────────────────
    // 초기화 (GridBoard가 호출)
    // ─────────────────────────────────────────────

    /// <summary>GridBoard가 생성 직후 호출해 좌표 주입.</summary>
    public void Initialize(int row, int col)
    {
        Row = row;
        Col = col;
        name = $"Cell_{row}_{col}";
        RefreshVisual();
    }

    // ─────────────────────────────────────────────
    // 이벤트 처리
    // ─────────────────────────────────────────────

    private void OnCardPlaced(OnCardPlaced evt)
    {
        if (evt.Cell != this) return;

        _isOccupied = true;
        PlacedCard = evt.Card;
        RefreshVisual();

        GameLogger.Log(ELogCategory.Gameplay,
            $"[GridCell] ({Row},{Col}) 카드 배치 완료.");
    }

    // ─────────────────────────────────────────────
    // 점유 해제 (나중에 카드 회수 기능 추가 시 사용)
    // ─────────────────────────────────────────────

    /// <summary>셀 점유 해제. 카드 회수 기능 구현 시 호출.</summary>
    public void Clear()
    {
        var prev = PlacedCard;

        _isOccupied = false;
        PlacedCard = null;
        RefreshVisual();

        if (EventManager.HasInstance)
            EventManager.Instance.Publish(new OnCardRemovedFromCell { Card = prev, Cell = this });
    }

    // ─────────────────────────────────────────────
    // 비주얼
    // ─────────────────────────────────────────────

    private void RefreshVisual()
    {
        if (_emptyVisual != null)
            _emptyVisual.SetActive(!_isOccupied);

        if (_occupiedVisual != null)
            _occupiedVisual.SetActive(_isOccupied);

        if (_highlightVisual != null)
            _highlightVisual.SetActive(false);
    }

    // ─────────────────────────────────────────────
    // 하이라이트
    // ─────────────────────────────────────────────

    public void SetHighlight(bool active)
    {
        if (_highlightVisual != null)
            _highlightVisual.SetActive(active && IsEmpty);
    }
}