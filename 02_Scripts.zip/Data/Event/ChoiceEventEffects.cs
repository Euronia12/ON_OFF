// =================================================================
// [스크립트 목적]  Choice Event 선택지 효과(SerializeReference 다형성). EventDataSO 에 직렬화된다.
// [주요 변수]      - 각 효과의 수치/모드 파라미터
// [의존 관계]      - EventContext(RunContext/InGameController/GridManager) 를 통해 런 상태에 적용
// [설계 노트]      - 무상태 config 객체 → 여러 이벤트 실행 간 공유 참조 안전.
//                    상호작용 효과(카드/방향 선택)는 서브 UI 를 열어 대상 확정 후 적용.
// =================================================================

using System;
using System.Collections.Generic;
using System.Threading;
using Cysharp.Threading.Tasks;
using UnityEngine;

public enum EChoiceArrowOperation
{
    Add,
    Remove,
    Replace
}

public enum EChoiceArrowTargetMode
{
    PlayerSelect,
    Random
}

public enum EChoiceDirectionMode
{
    PlayerSelect,
    Random,
    Fixed
}

public enum EChoiceCardRemoveMode
{
    Random,
    PlayerSelect
}

/// <summary>카드 대상 지정 방식(신규 카드 효과 공용). 기존 두 enum 은 이름이 용도에 묶여 재사용하지 않는다.</summary>
public enum EChoiceCardTargetMode
{
    PlayerSelect,
    Random
}

public enum EChoiceCardCostOperation
{
    Decrease = 0,
    Increase = 1,
}

[Serializable]
public abstract class ChoiceEventEffectBase
{
    /// <summary>효과 적용 결과. 대표 수치와 결과 화면에 필요한 부가 정보를 함께 반환한다.</summary>
    public abstract UniTask<ChoiceEventEffectResult> ApplyAsync(EventContext context, CancellationToken token);
    public abstract bool Validate(out string error);

    /// <summary>
    /// 효과 자체의 적용 가능성(대상 카드 존재·하한 도달 여부 등). false 면 선택지가 잠긴다.
    /// 요구량(Cost)·덱 크기 게이트와 AND 로 묶인다.
    /// </summary>
    public virtual bool CanApply(EventContext context) => true;

    /// <summary>
    /// {amount}/{cost} 외의 문자열 토큰을 등록한다(예: {skill}).
    /// 라벨 로컬라이즈는 EventContext 확정 전에 일어나므로 context 를 받지 않는다 —
    /// 필요한 런 고정 데이터는 구현부가 매니저에서 직접 읽는다.
    /// </summary>
    public virtual void CollectTextTokens(IDictionary<string, string> tokens) { }

    /// <summary>
    /// 결과 화면용 문자열 토큰. 기본 효과는 선택 전과 동일하며,
    /// 적용 뒤 현재값을 표시해야 하는 효과만 재정의한다.
    /// </summary>
    public virtual void CollectResultTextTokens(IDictionary<string, string> tokens)
        => CollectTextTokens(tokens);

    /// <summary>
    /// 설명 토큰({amount}) 치환용 대표(예정) 수치. 수치가 없는 효과는 null.
    /// 선택 전 라벨/설명에서 참조. 결과 텍스트는 ApplyAsync 가 반환한 실제 적용값을 쓴다.
    /// </summary>
    public virtual int? DescAmount => null;

    protected static string Localize(string key)
        => LocalizationManager.HasInstance ? LocalizationManager.Instance.Get(key) : key;

    /// <summary>
    /// 시드·노드·효과별 소금값에서 파생한 안정 난수원.
    /// run.Rng 를 직접 쓰면 소비 순서에 결과가 묶이는데 스트림 위치는 세이브에 없어 재현이 깨진다.
    /// 맵·보상·상점이 쓰는 것과 같은 좌표 해시 방식을 따른다.
    /// </summary>
    protected static System.Random CreateStableRng(EventContext context, int salt)
    {
        if (!context.UseSeededRandom)
            return new System.Random(Guid.NewGuid().GetHashCode());

        unchecked
        {
            int h = 17;
            h = h * 31 + (context.Run != null ? context.Run.Seed : 0);
            h = h * 31 + context.NodeId;
            h = h * 31 + StableStringHash(context.EventId);
            h = h * 31 + context.ChoiceIndex;
            h = h * 31 + context.EffectIndex;
            h = h * 31 + salt;
            return new System.Random(h);
        }
    }

    private static int StableStringHash(string value)
    {
        unchecked
        {
            int hash = 23;
            if (value == null) return hash;
            for (int i = 0; i < value.Length; i++) hash = hash * 31 + value[i];
            return hash;
        }
    }

    protected static RunSaveEventEffectState GetEffectState(EventContext context, string kind)
        => context.Run?.GetOrCreateEventEffectState(context.EffectIndex, kind);

    protected static void SaveCheckpoint(EventContext context)
    {
        if (context.InGame == null ||
            !context.InGame.SavePendingEventCheckpoint(context.NodeId))
        {
            throw new InvalidOperationException("[ChoiceEventEffect] 이벤트 체크포인트 저장에 실패했습니다.");
        }
    }

    protected static ECardDirection ResolveCardArrow(CardDataSO cardData, System.Random rng)
    {
        if (cardData == null) return ECardDirection.None;
        UnityEngine.Random.State previous = UnityEngine.Random.state;
        try
        {
            UnityEngine.Random.InitState(rng != null ? rng.Next() : Guid.NewGuid().GetHashCode());
            Card card = CardFactory.CreateFromSO(cardData);
            return card?.Arrow != null ? card.Arrow.Current : ECardDirection.None;
        }
        finally
        {
            UnityEngine.Random.state = previous;
        }
    }

    protected static CardRewardService CreateCardRewardService(EventContext context)
    {
        CardRarityWeights weights = context.InGame != null
            ? context.InGame.CurrentCardRewardRarityWeights
            : CardRarityWeights.Default;
        return new CardRewardService(
            context.Run != null ? context.Run.AvailableCardPool : null,
            AlwaysUnlockedProvider.Instance,
            weights);
    }

    /// <summary>덱 엔트리의 런타임 데이터를 확보한다(미해석 엔트리 보정 포함). 실패 시 null.</summary>
    protected static CardRuntimeData ResolveRuntimeData(RunDeckEntry entry)
    {
        if (entry == null) return null;
        if (entry.RuntimeData == null && DataManager.HasInstance && DataManager.Instance.IsLoaded)
        {
            CardDataSO cardData = DataManager.Instance.GetData<CardDataSO>(entry.CardId);
            if (cardData != null) entry.SetRuntimeData(CardFactory.FromSO(cardData));
        }
        return entry.RuntimeData;
    }

    protected static async UniTask<RunDeckEntry> SelectDeckEntryAsync(
        List<RunDeckEntry> entries,
        CancellationToken token,
        string progressText = null,
        bool requireConfirmation = false)
    {
        if (!UIManager.HasInstance) return null;

        UIDeckCardPicker.Show(entries, Localize("UI_CHOICE_CARD_SELECT"), cancelable: false,
            requireConfirmation: requireConfirmation, progressText: progressText);
        UIDeckCardPicker picker = await UIManager.Instance.OpenAsync<UIDeckCardPicker>(token);
        if (picker == null) return null;

        var source = new UniTaskCompletionSource<int>();
        void Confirm(int entryId) => source.TrySetResult(entryId);
        void Cancel() => source.TrySetCanceled();
        picker.OnEntryConfirmed += Confirm;
        picker.OnCancelled += Cancel;
        try
        {
            int selectedId = await source.Task.AttachExternalCancellation(token);
            for (int i = 0; i < entries.Count; i++)
                if (entries[i]?.EntryId == selectedId) return entries[i];
            return null;
        }
        finally
        {
            picker.OnEntryConfirmed -= Confirm;
            picker.OnCancelled -= Cancel;
            if (picker.IsOpen && UIManager.HasInstance) UIManager.Instance.Close(picker);
        }
    }
}

/// <summary>선택 이벤트 효과 1개의 실제 적용 결과.</summary>
public readonly struct ChoiceEventEffectResult
{
    public int? Amount { get; }
    public RunDeckEntry ArrowTarget { get; }
    public ECardDirection AddedArrowDirection { get; }
    public IReadOnlyList<ChoiceEventCardTransformResult> CardTransforms { get; }
    public ChoiceEventCardCostResult CardCostChange { get; }

    public bool HasArrowAddition =>
        ArrowTarget != null && AddedArrowDirection != ECardDirection.None;
    public bool HasCardTransforms => CardTransforms != null && CardTransforms.Count > 0;
    public bool HasCardCostChange => CardCostChange.IsValid;

    private ChoiceEventEffectResult(
        int? amount,
        RunDeckEntry arrowTarget,
        ECardDirection addedArrowDirection,
        IReadOnlyList<ChoiceEventCardTransformResult> cardTransforms = null,
        ChoiceEventCardCostResult cardCostChange = default)
    {
        Amount = amount;
        ArrowTarget = arrowTarget;
        AddedArrowDirection = addedArrowDirection;
        CardTransforms = cardTransforms;
        CardCostChange = cardCostChange;
    }

    public static ChoiceEventEffectResult FromAmount(int? amount)
        => new ChoiceEventEffectResult(amount, null, ECardDirection.None);

    public static ChoiceEventEffectResult ArrowAdded(
        RunDeckEntry target,
        ECardDirection direction)
        => new ChoiceEventEffectResult(null, target, direction);

    public static ChoiceEventEffectResult CardsTransformed(
        IReadOnlyList<ChoiceEventCardTransformResult> transforms)
        => new ChoiceEventEffectResult(transforms?.Count ?? 0, null, ECardDirection.None, transforms);

    public static ChoiceEventEffectResult CardCostChanged(ChoiceEventCardCostResult change)
        => new ChoiceEventEffectResult(
            Mathf.Abs(change.AfterCost - change.BeforeCost),
            null,
            ECardDirection.None,
            cardCostChange: change);
}

/// <summary>이벤트 결과 화면에서 원본→변이 카드 한 쌍을 나란히 표시하기 위한 불변 데이터.</summary>
public readonly struct ChoiceEventCardTransformResult
{
    public string SourceCardId { get; }
    public ECardDirection SourceDirection { get; }
    public string ResultCardId { get; }
    public ECardDirection ResultDirection { get; }

    public ChoiceEventCardTransformResult(
        string sourceCardId,
        ECardDirection sourceDirection,
        string resultCardId,
        ECardDirection resultDirection)
    {
        SourceCardId = sourceCardId ?? string.Empty;
        SourceDirection = sourceDirection;
        ResultCardId = resultCardId ?? string.Empty;
        ResultDirection = resultDirection;
    }
}

/// <summary>이벤트 결과 화면에 표시할 카드 코스트 변경 한 건.</summary>
public readonly struct ChoiceEventCardCostResult
{
    public string CardId { get; }
    public ECardDirection Direction { get; }
    public int BeforeCost { get; }
    public int AfterCost { get; }
    public int EntryId { get; }
    public bool IsValid => !string.IsNullOrEmpty(CardId);

    public ChoiceEventCardCostResult(
        string cardId,
        ECardDirection direction,
        int beforeCost,
        int afterCost,
        int entryId = 0)
    {
        CardId = cardId ?? string.Empty;
        Direction = direction;
        BeforeCost = beforeCost;
        AfterCost = afterCost;
        EntryId = entryId;
    }
}

[Serializable]
public sealed class ChoiceGoldEffect : ChoiceEventEffectBase
{
    [Min(1)] [SerializeField] private int _amount = 10;

    // 난이도별 골드 획득 배율이 적용된 "실제 지급 예정" 수치를 표기한다.
    // 라벨 조립 시점에는 EventContext 가 없으므로 매니저에서 직접 읽는다(베이스 주석 참조).
    public override int? DescAmount => InGameController.HasInstance
        ? InGameController.Instance.PreviewGrantGold(_amount)
        : _amount;

    public override UniTask<ChoiceEventEffectResult> ApplyAsync(EventContext context, CancellationToken token)
    {
        // 결과 문구도 실제 적립된 골드(난이도 보정 후)를 그대로 표시한다.
        int granted = context.InGame != null ? context.InGame.GrantGold(_amount) : 0;
        return UniTask.FromResult(ChoiceEventEffectResult.FromAmount(granted));
    }

    public override bool Validate(out string error)
    {
        error = _amount > 0 ? null : "골드는 1 이상이어야 합니다.";
        return error == null;
    }
}

// 최대 HP 증감(런 단위). RunContext.ModifyMaxHp 의 최소 1 클램프를 그대로 탄다.
// 감소를 EventCost(MaxHp) 로 저작하면 최대 HP 가 낮은 플레이어는 선택지 자체가 잠겨
// 모든 선택지가 막히는 하드락이 생길 수 있어, 페널티는 효과로 처리한다.
[Serializable]
public sealed class ChoiceModifyMaxHpEffect : ChoiceEventEffectBase
{
    [Tooltip("양수는 증가, 음수는 감소. 최대 체력은 최소 1 로 클램프된다.")]
    [SerializeField] private int _delta = -10;

    public override int? DescAmount => _delta;

    public override UniTask<ChoiceEventEffectResult> ApplyAsync(EventContext context, CancellationToken token)
    {
        RunContext run = context.Run;
        if (run == null || _delta == 0)
            return UniTask.FromResult(ChoiceEventEffectResult.FromAmount(0));

        int before = run.MaxHp;
        run.ModifyMaxHp(_delta);
        return UniTask.FromResult(
            ChoiceEventEffectResult.FromAmount(run.MaxHp - before)); // 실제 증감량
    }

    public override bool Validate(out string error)
    {
        error = _delta != 0 ? null : "최대 체력 증감량은 0 이 아니어야 합니다.";
        return error == null;
    }
}

// 덱 카드 1장의 코스트를 영구히 낮춘다(각인). 보정값은 런 단위로 저장되고
// 전투 덱 생성·덱 뷰에서 Card.ApplyPermanentCostDelta 로 반영된다.
[Serializable]
public sealed class ChoiceCardCostEffect : ChoiceEventEffectBase
{
    private const int RngSalt = 8110;

    [Tooltip("증가/감소할 코스트 양. 감소는 하한에 걸리면 그만큼만 적용된다.")]
    [Min(1)] [SerializeField] private int _amount = 1;
    [SerializeField] private EChoiceCardCostOperation _operation = EChoiceCardCostOperation.Decrease;
    [SerializeField] private EChoiceCardTargetMode _mode = EChoiceCardTargetMode.PlayerSelect;
    [Tooltip("적용 후 최소 코스트. 0 까지 낮출 수 있다.")]
    [Min(0)] [SerializeField] private int _minCost;

    public override int? DescAmount => _amount;

    public override bool CanApply(EventContext context)
        => context.Run != null && CollectEligible(context.Run).Count > 0;

    public override async UniTask<ChoiceEventEffectResult> ApplyAsync(
        EventContext context, CancellationToken token)
    {
        RunContext run = context.Run;
        if (run == null) return ChoiceEventEffectResult.FromAmount(0);

        List<RunDeckEntry> eligible = CollectEligible(run);
        if (eligible.Count == 0)
        {
            Debug.LogWarning("[ChoiceCardCostEffect] 코스트를 낮출 수 있는 카드가 없습니다.");
            return ChoiceEventEffectResult.FromAmount(0);
        }

        RunDeckEntry entry = _mode == EChoiceCardTargetMode.Random
            ? SelectRandomEntry(context, eligible)
            : await SelectDeckEntryAsync(eligible, token, requireConfirmation: true);
        if (entry == null) return ChoiceEventEffectResult.FromAmount(0);

        CardRuntimeData data = ResolveRuntimeData(entry);
        if (data == null) return ChoiceEventEffectResult.FromAmount(0);

        int currentDelta = run.GetCardCostDelta(entry.EntryId);
        int currentCost = data.Cost + currentDelta;
        int newCost;
        if (_operation == EChoiceCardCostOperation.Increase)
            newCost = currentCost > int.MaxValue - _amount ? int.MaxValue : currentCost + _amount;
        else
            newCost = Mathf.Max(_minCost, currentCost - _amount);
        run.SetCardCostDelta(entry.EntryId, newCost - data.Cost);
        return ChoiceEventEffectResult.CardCostChanged(new ChoiceEventCardCostResult(
            entry.CardId,
            entry.ArrowDirection,
            currentCost,
            newCost,
            entry.EntryId));
    }

    public override bool Validate(out string error)
    {
        error = _amount > 0 ? null : "코스트 감소량은 1 이상이어야 합니다.";
        return error == null;
    }

    // 대상 조건 두 가지:
    //  - 가변 코스트(ManaBurst)는 숫자 코스트가 아니라 감소 개념이 성립하지 않는다 → 제외
    //  - 현재 코스트가 하한 초과인 카드만 → 이미 하한(기본 0)인 카드는 선택 불가
    private List<RunDeckEntry> CollectEligible(RunContext run)
    {
        var result = new List<RunDeckEntry>();
        IReadOnlyList<RunDeckEntry> entries = run.DeckEntries;
        for (int i = 0; i < entries.Count; i++)
        {
            RunDeckEntry entry = entries[i];
            CardRuntimeData data = ResolveRuntimeData(entry);
            if (data == null) continue;
            if ((data.GetEffectFlags() & ECardEffectFlag.ManaBurst) != 0) continue;
            if (_operation == EChoiceCardCostOperation.Increase ||
                data.Cost + run.GetCardCostDelta(entry.EntryId) > _minCost)
                result.Add(entry);
        }
        return result;
    }

    private RunDeckEntry SelectRandomEntry(EventContext context, List<RunDeckEntry> eligible)
    {
        RunSaveEventEffectResult previous = context.Run.GetEventEffectResult(context.EffectIndex - 1);
        if (previous != null && previous.hasCardCostChange && previous.costEntryId > 0)
        {
            for (int i = eligible.Count - 1; i >= 0; i--)
            {
                if (eligible[i].EntryId == previous.costEntryId)
                    eligible.RemoveAt(i);
            }
        }

        if (eligible.Count == 0)
        {
            Debug.LogWarning("[ChoiceCardCostEffect] 이전 코스트 변경 대상과 다른 카드가 없습니다.");
            return null;
        }

        return eligible[CreateStableRng(context, RngSalt).Next(eligible.Count)];
    }
}

// 덱 카드 1장을 복제해 덱에 추가한다(화살표 포함). 각인된 코스트 보정도 기본적으로 함께 복사한다.
[Serializable]
public sealed class ChoiceDuplicateCardEffect : ChoiceEventEffectBase
{
    private const int RngSalt = 8120;

    [SerializeField] private EChoiceCardTargetMode _mode = EChoiceCardTargetMode.PlayerSelect;
    [Tooltip("체크 시 원본의 영구 코스트 보정(각인)까지 복제본에 복사한다.")]
    [SerializeField] private bool _copyCostDelta = true;
    [Tooltip("복제할 장수. PlayerSelect 는 이 횟수만큼 선택 팝업을 반복한다.")]
    [Min(1)] [SerializeField] private int _count = 1;

    public override int? DescAmount => _count;

    public override bool CanApply(EventContext context)
        => context.Run != null && context.Run.DeckEntries.Count > 0;

    public override async UniTask<ChoiceEventEffectResult> ApplyAsync(
        EventContext context, CancellationToken token)
    {
        RunContext run = context.Run;
        if (run == null || context.InGame == null) return ChoiceEventEffectResult.FromAmount(0);

        int duplicated = 0;
        for (int i = 0; i < _count; i++)
        {
            var entries = new List<RunDeckEntry>(run.DeckEntries);
            if (entries.Count == 0) break;

            RunDeckEntry entry = _mode == EChoiceCardTargetMode.Random
                ? entries[CreateStableRng(context, RngSalt + i).Next(entries.Count)]
                : await SelectDeckEntryAsync(entries, token, requireConfirmation: true);
            if (entry == null) break;

            int sourceDelta = run.GetCardCostDelta(entry.EntryId);
            ECardDirection? direction = entry.HasArrowDirection
                ? entry.ArrowDirection
                : (ECardDirection?)null;
            if (!context.InGame.AddCardToRunDeck(entry.CardId, direction))
            {
                Debug.LogWarning($"[ChoiceDuplicateCardEffect] 카드 복제에 실패했습니다: {entry.CardId}");
                break;
            }
            duplicated++;

            // AddCardToDeck 은 덱 끝에 추가하므로 마지막 엔트리가 방금 만든 복제본이다.
            if (_copyCostDelta && sourceDelta != 0)
            {
                IReadOnlyList<RunDeckEntry> after = run.DeckEntries;
                RunDeckEntry created = after.Count > 0 ? after[after.Count - 1] : null;
                if (created != null && string.Equals(created.CardId, entry.CardId, StringComparison.Ordinal))
                    run.SetCardCostDelta(created.EntryId, sourceDelta);
            }
        }
        return ChoiceEventEffectResult.FromAmount(duplicated);
    }

    public override bool Validate(out string error)
    {
        error = _count > 0 ? null : "복제 장수는 1 이상이어야 합니다.";
        return error == null;
    }
}

// 카드 후보 N장을 제시하고 1장을 고르게 한다(전투 보상과 같은 UICardSelectPopup 재사용).
[Serializable]
public sealed class ChoiceCardOfferEffect : ChoiceEventEffectBase
{
    private const int RngSalt = 8130;

    [Tooltip("제시할 후보 장수.")]
    [Min(1)] [SerializeField] private int _candidateCount = 3;
    [Tooltip("후보를 뽑을 카드 풀.")]
    [SerializeField] private ECardPool _pool = ECardPool.Normal;
    [Tooltip("체크 시 아래 등급의 카드만 후보로 삼는다.")]
    [SerializeField] private bool _restrictRarity;
    [SerializeField] private ECardRarity _rarity = ECardRarity.Rare;
    [Tooltip("체크 시 현재 스테이지의 카드 풀로 한정한다.")]
    [SerializeField] private bool _useCurrentStagePool = true;
    [Tooltip("체크 시 이미 덱에 있는 카드를 후보에서 제외한다.")]
    [SerializeField] private bool _excludeOwned;

    public override int? DescAmount => _candidateCount;

    public override bool CanApply(EventContext context)
    {
        RunContext run = context.Run;
        if (run == null) return false;
        CardQueryCriteria criteria = BuildCriteria(run);
        return CreateCardRewardService(context).HasAny(in criteria);
    }

    public override async UniTask<ChoiceEventEffectResult> ApplyAsync(
        EventContext context, CancellationToken token)
    {
        RunContext run = context.Run;
        if (run == null || context.InGame == null || !UIManager.HasInstance)
            return ChoiceEventEffectResult.FromAmount(0);

        CardQueryCriteria criteria = BuildCriteria(run);
        List<CardDataSO> candidates =
            CreateCardRewardService(context).PickRandom(
                in criteria, _candidateCount, CreateStableRng(context, RngSalt));
        if (candidates.Count == 0)
        {
            Debug.LogWarning("[ChoiceCardOfferEffect] 제시할 카드 후보가 없습니다.");
            return ChoiceEventEffectResult.FromAmount(0);
        }

        UICardSelectPopup.Show(candidates);
        UICardSelectPopup popup = await UIManager.Instance.OpenAsync<UICardSelectPopup>(token);
        if (popup == null) return ChoiceEventEffectResult.FromAmount(0);

        var source = new UniTaskCompletionSource<(string cardId, ECardDirection direction)>();
        void Resolved(string cardId, ECardDirection direction) => source.TrySetResult((cardId, direction));
        popup.OnCardResolved += Resolved;
        bool popupResolved = false;
        try
        {
            (string cardId, ECardDirection direction) = await source.Task.AttachExternalCancellation(token);
            popupResolved = true;
            if (string.IsNullOrEmpty(cardId)) return ChoiceEventEffectResult.FromAmount(0); // 스킵

            bool added = context.InGame.AddCardToRunDeck(cardId, direction);
            if (!added) Debug.LogWarning($"[ChoiceCardOfferEffect] 카드 추가에 실패했습니다: {cardId}");
            return ChoiceEventEffectResult.FromAmount(added ? 1 : 0);
        }
        finally
        {
            popup.OnCardResolved -= Resolved;
            // 팝업은 선택 확정 시 스스로 닫히지만, 취소 경로를 위해 남아 있으면 정리한다.
            if (!popupResolved && popup.IsOpen && UIManager.HasInstance)
                UIManager.Instance.Close(popup);
        }
    }

    public override bool Validate(out string error)
    {
        error = _candidateCount > 0 ? null : "제시 장수는 1 이상이어야 합니다.";
        return error == null;
    }

    private CardQueryCriteria BuildCriteria(RunContext run)
    {
        HashSet<string> exclude = null;
        if (_excludeOwned)
        {
            exclude = new HashSet<string>(StringComparer.Ordinal);
            IReadOnlyList<string> owned = run.DeckCardIds;
            for (int i = 0; i < owned.Count; i++) exclude.Add(owned[i]);
        }

        ECardStagePool stagePool = _useCurrentStagePool && InGameController.HasInstance
            ? CardQueryCriteria.StageForNumber(InGameController.Instance.CurrentStageNumber)
            : ECardStagePool.All;

        return new CardQueryCriteria(
            _pool,
            _restrictRarity ? _rarity : (ECardRarity?)null,
            unlockedOnly: true,
            excludeIds: exclude,
            stagePool: stagePool);
    }
}

/// <summary>이벤트 선택 즉시 카드 보상 목록을 열어 독립적인 카드 1택을 여러 번 제공한다.</summary>
[Serializable]
public sealed class ChoiceCardRewardEffect : ChoiceEventEffectBase
{
    private const int RngSalt = 8150;

    [Min(1)] [SerializeField] private int _rewardCount = 1;
    [Min(1)] [SerializeField] private int _candidateCount = 3;

    public override int? DescAmount => _rewardCount;

    public override bool CanApply(EventContext context)
    {
        if (context.Run == null) return false;
        CardQueryCriteria criteria = BuildCriteria(context);
        return CreateCardRewardService(context).HasAny(in criteria);
    }

    public override async UniTask<ChoiceEventEffectResult> ApplyAsync(
        EventContext context, CancellationToken token)
    {
        if (context.Run == null || context.InGame == null || !UIManager.HasInstance)
            return ChoiceEventEffectResult.FromAmount(0);

        RunSaveEventEffectState state = GetEffectState(context, GetType().FullName);
        if (state == null)
            throw new InvalidOperationException("[ChoiceCardRewardEffect] 진행 상태를 만들 수 없습니다.");

        if (!state.prepared)
        {
            PrepareSlots(context, state);
            state.prepared = true;
            SaveCheckpoint(context); // 후보와 방향을 팝업 노출 전에 확정 저장한다.
        }

        if (state.applied || AllRewardSlotsProcessed(state))
        {
            state.applied = true;
            SaveCheckpoint(context);
            return ChoiceEventEffectResult.FromAmount(CountAcquired(state));
        }

        var reward = new BattleReward();
        var itemToSlot = new Dictionary<BattleRewardItem, RunSaveEventCardRewardSlot>();
        for (int i = 0; i < state.rewardSlots.Count; i++)
        {
            RunSaveEventCardRewardSlot slot = state.rewardSlots[i];
            if (slot == null || slot.processed) continue;

            var cards = new List<CardDataSO>(slot.candidates.Count);
            var directions = new List<ECardDirection>(slot.candidates.Count);
            for (int j = 0; j < slot.candidates.Count; j++)
            {
                RunSaveEventCardCandidate saved = slot.candidates[j];
                CardDataSO card = ResolveCardData(saved?.cardId);
                if (card == null) continue;
                cards.Add(card);
                directions.Add((ECardDirection)saved.arrowDirection);
            }
            BattleRewardItem item = reward.AddCardChoice(cards, directions);
            if (item != null) itemToSlot[item] = slot;
        }

        if (!reward.HasAny)
            throw new InvalidOperationException("[ChoiceCardRewardEffect] 복원할 카드 보상 후보가 없습니다.");

        UIRewardPopup.Show(reward);
        UIRewardPopup popup = await UIManager.Instance.OpenAsync<UIRewardPopup>(token);
        if (popup == null) throw new InvalidOperationException("[ChoiceCardRewardEffect] 보상 팝업을 열 수 없습니다.");

        var completed = new UniTaskCompletionSource();
        void Chosen(BattleRewardItem item, string cardId, ECardDirection direction)
        {
            if (!itemToSlot.TryGetValue(item, out RunSaveEventCardRewardSlot slot) || slot.processed)
                return;

            bool skipped = string.IsNullOrEmpty(cardId);
            bool previousProcessed = slot.processed;
            bool previousSkipped = slot.skipped;
            string previousChosenCardId = slot.chosenCardId;
            int previousDirection = slot.chosenArrowDirection;
            RunDeckEntry addedEntry = null;

            try
            {
                if (!skipped)
                {
                    int beforeCount = context.Run?.DeckEntries.Count ?? 0;
                    if (!context.InGame.AddCardToRunDeck(cardId, direction))
                        throw new InvalidOperationException(
                            $"[ChoiceCardRewardEffect] 카드 덱 추가 실패: {cardId}");

                    IReadOnlyList<RunDeckEntry> entries = context.Run?.DeckEntries;
                    if (entries != null && entries.Count > beforeCount)
                        addedEntry = entries[entries.Count - 1];
                    if (entries == null || entries.Count != beforeCount + 1)
                        throw new InvalidOperationException(
                            $"[ChoiceCardRewardEffect] 추가된 덱 엔트리를 확인할 수 없습니다: {cardId}");
                }

                slot.processed = true;
                slot.skipped = skipped;
                slot.chosenCardId = cardId ?? string.Empty;
                slot.chosenArrowDirection = (int)direction;
                SaveCheckpoint(context); // 카드 추가/스킵 직후 즉시 저장한다.
            }
            catch
            {
                slot.processed = previousProcessed;
                slot.skipped = previousSkipped;
                slot.chosenCardId = previousChosenCardId;
                slot.chosenArrowDirection = previousDirection;

                if (addedEntry != null &&
                    context.Run != null &&
                    !context.Run.RemoveCardFromDeckEntry(addedEntry.EntryId, out _))
                {
                    Debug.LogError(
                        $"[ChoiceCardRewardEffect] 저장 실패 후 카드 롤백 실패: entry={addedEntry.EntryId}");
                }
                throw;
            }
        }
        void Continued() => completed.TrySetResult();

        popup.OnCardItemChosen += Chosen;
        popup.OnContinueRequested += Continued;
        bool completedNormally = false;
        try
        {
            await completed.Task.AttachExternalCancellation(token);
            completedNormally = true;
        }
        finally
        {
            popup.OnCardItemChosen -= Chosen;
            popup.OnContinueRequested -= Continued;
            if (!completedNormally && popup.IsOpen && UIManager.HasInstance)
                UIManager.Instance.Close(popup);
        }

        if (!AllRewardSlotsProcessed(state))
            throw new InvalidOperationException("[ChoiceCardRewardEffect] 처리되지 않은 보상 슬롯이 남았습니다.");

        state.applied = true;
        SaveCheckpoint(context);
        return ChoiceEventEffectResult.FromAmount(CountAcquired(state));
    }

    public override bool Validate(out string error)
    {
        if (_rewardCount <= 0) error = "카드 보상 횟수는 1 이상이어야 합니다.";
        else if (_candidateCount <= 0) error = "카드 후보 수는 1 이상이어야 합니다.";
        else error = null;
        return error == null;
    }

    private void PrepareSlots(EventContext context, RunSaveEventEffectState state)
    {
        CardRewardService service = CreateCardRewardService(context);
        CardQueryCriteria criteria = BuildCriteria(context);
        for (int i = 0; i < _rewardCount; i++)
        {
            System.Random rng = CreateStableRng(context, RngSalt + i);
            List<CardDataSO> picked = service.PickRandom(in criteria, _candidateCount, rng);
            if (picked.Count == 0)
                throw new InvalidOperationException("[ChoiceCardRewardEffect] 카드 보상 후보 풀이 비었습니다.");

            var slot = new RunSaveEventCardRewardSlot();
            for (int j = 0; j < picked.Count; j++)
            {
                slot.candidates.Add(new RunSaveEventCardCandidate
                {
                    cardId = picked[j].CardId,
                    arrowDirection = (int)ResolveCardArrow(picked[j], rng),
                });
            }
            state.rewardSlots.Add(slot);
        }
    }

    private static bool AllRewardSlotsProcessed(RunSaveEventEffectState state)
    {
        if (state.rewardSlots.Count == 0) return false;
        for (int i = 0; i < state.rewardSlots.Count; i++)
            if (state.rewardSlots[i] == null || !state.rewardSlots[i].processed) return false;
        return true;
    }

    private static int CountAcquired(RunSaveEventEffectState state)
    {
        int count = 0;
        for (int i = 0; i < state.rewardSlots.Count; i++)
        {
            RunSaveEventCardRewardSlot slot = state.rewardSlots[i];
            if (slot != null && slot.processed && !slot.skipped) count++;
        }
        return count;
    }

    private static CardDataSO ResolveCardData(string cardId)
        => !string.IsNullOrEmpty(cardId) && DataManager.HasInstance && DataManager.Instance.IsLoaded
            ? DataManager.Instance.GetData<CardDataSO>(cardId)
            : null;

    private static CardQueryCriteria BuildCriteria(EventContext context)
        => new CardQueryCriteria(
            ECardPool.Normal,
            rarity: null,
            unlockedOnly: true,
            stagePool: CardQueryCriteria.StageForNumber(
                context.InGame != null ? context.InGame.CurrentStageNumber : 1));
}

[Serializable]
public abstract class ChoiceCardTransformEffectBase : ChoiceEventEffectBase
{
    protected abstract int RngSalt { get; }
    protected abstract List<RunDeckEntry> CollectTargets(EventContext context);

    public override bool CanApply(EventContext context)
    {
        List<RunDeckEntry> targets = CollectTargets(context);
        if (targets == null || targets.Count == 0) return false;
        var service = new CardRewardService(
            context.Run.AvailableCardPool, AlwaysUnlockedProvider.Instance);
        for (int i = 0; i < targets.Count; i++)
            if (!HasReplacement(service, context, targets[i]?.CardId)) return false;
        return true;
    }

    public override UniTask<ChoiceEventEffectResult> ApplyAsync(
        EventContext context, CancellationToken token)
    {
        token.ThrowIfCancellationRequested();
        RunSaveEventEffectState state = GetEffectState(context, GetType().FullName);
        if (state == null)
            throw new InvalidOperationException("[ChoiceCardTransformEffect] 진행 상태를 만들 수 없습니다.");

        if (!state.prepared)
        {
            PrepareTransformPlan(context, state);
            state.prepared = true;
            SaveCheckpoint(context); // 비시드 결과도 적용 전에 먼저 고정한다.
        }

        if (!state.applied)
        {
            ApplyTransformPlan(context, state);
            state.applied = true;
            SaveCheckpoint(context); // 교체된 덱을 즉시 저장한다.
        }

        return UniTask.FromResult(ChoiceEventEffectResult.CardsTransformed(
            BuildTransformResults(state)));
    }

    protected static CardQueryCriteria BuildTransformCriteria(
        EventContext context, string excludeCardId)
    {
        HashSet<string> excludes = string.IsNullOrEmpty(excludeCardId)
            ? null
            : new HashSet<string>(StringComparer.Ordinal) { excludeCardId };
        return new CardQueryCriteria(
            ECardPool.Normal,
            rarity: null,
            unlockedOnly: true,
            excludeIds: excludes,
            stagePool: CardQueryCriteria.StageForNumber(
                context.InGame != null ? context.InGame.CurrentStageNumber : 1));
    }

    private void PrepareTransformPlan(EventContext context, RunSaveEventEffectState state)
    {
        List<RunDeckEntry> targets = CollectTargets(context);
        if (targets == null || targets.Count == 0)
            throw new InvalidOperationException("[ChoiceCardTransformEffect] 변환 대상 카드가 없습니다.");

        var service = new CardRewardService(
            context.Run.AvailableCardPool, AlwaysUnlockedProvider.Instance);
        for (int i = 0; i < targets.Count; i++)
        {
            RunDeckEntry source = targets[i];
            System.Random rng = CreateStableRng(context, RngSalt + i);
            CardQueryCriteria criteria = BuildTransformCriteria(context, source.CardId);
            List<CardDataSO> picked = service.PickRandom(in criteria, 1, rng);
            if (picked.Count == 0)
                throw new InvalidOperationException($"[ChoiceCardTransformEffect] '{source.CardId}'의 변환 후보가 없습니다.");

            // 원본 방향은 교체 전에만 읽을 수 있다. 결과 화면에서 원본 카드를 재현하려면
            // 지금 확정해 계획에 함께 저장해야 한다.
            ResolveRuntimeData(source);
            bool hasSourceArrow = source.HasArrowDirection || source.EnsureArrowResolved();

            state.transforms.Add(new RunSaveEventTransformPair
            {
                sourceEntryId = source.EntryId,
                sourceCardId = source.CardId,
                hasSourceArrowDirection = hasSourceArrow,
                sourceArrowDirection = hasSourceArrow ? (int)source.ArrowDirection : 0,
                resultCardId = picked[0].CardId,
                hasArrowDirection = true,
                arrowDirection = (int)ResolveCardArrow(picked[0], rng),
            });
        }
    }

    private static void ApplyTransformPlan(EventContext context, RunSaveEventEffectState state)
    {
        for (int i = 0; i < state.transforms.Count; i++)
        {
            RunSaveEventTransformPair pair = state.transforms[i];
            RunDeckEntry current = FindEntry(context.Run, pair.sourceEntryId);
            if (current == null || !string.Equals(current.CardId, pair.sourceCardId, StringComparison.Ordinal))
                throw new InvalidOperationException(
                    $"[ChoiceCardTransformEffect] 원본 엔트리가 저장 계획과 다릅니다: {pair.sourceEntryId}/{pair.sourceCardId}");

            ECardDirection? direction = pair.hasArrowDirection
                ? (ECardDirection)pair.arrowDirection
                : (ECardDirection?)null;
            RunDeckEntry replacement = context.Run.ReplaceCardInDeckEntry(
                pair.sourceEntryId, pair.resultCardId, direction);
            if (replacement == null)
                throw new InvalidOperationException($"[ChoiceCardTransformEffect] 카드 교체 실패: {pair.resultCardId}");

            CardDataSO card = DataManager.HasInstance && DataManager.Instance.IsLoaded
                ? DataManager.Instance.GetData<CardDataSO>(pair.resultCardId)
                : null;
            if (card != null) replacement.SetRuntimeData(CardFactory.FromSO(card));
        }
    }

    private static RunDeckEntry FindEntry(RunContext run, int entryId)
    {
        IReadOnlyList<RunDeckEntry> entries = run?.DeckEntries;
        if (entries == null) return null;
        for (int i = 0; i < entries.Count; i++)
            if (entries[i] != null && entries[i].EntryId == entryId) return entries[i];
        return null;
    }

    private static IReadOnlyList<ChoiceEventCardTransformResult> BuildTransformResults(
        RunSaveEventEffectState state)
    {
        if (state?.transforms == null || state.transforms.Count == 0)
            return Array.Empty<ChoiceEventCardTransformResult>();

        var results = new List<ChoiceEventCardTransformResult>(state.transforms.Count);
        for (int i = 0; i < state.transforms.Count; i++)
        {
            RunSaveEventTransformPair pair = state.transforms[i];
            if (pair == null) continue;
            results.Add(new ChoiceEventCardTransformResult(
                pair.sourceCardId,
                pair.hasSourceArrowDirection
                    ? (ECardDirection)pair.sourceArrowDirection
                    : ECardDirection.None,
                pair.resultCardId,
                pair.hasArrowDirection
                    ? (ECardDirection)pair.arrowDirection
                    : ECardDirection.None));
        }
        return results;
    }

    private static bool HasReplacement(
        CardRewardService service, EventContext context, string sourceCardId)
    {
        if (context.Run == null || service == null) return false;
        CardQueryCriteria criteria = BuildTransformCriteria(context, sourceCardId);
        return service.HasAny(in criteria);
    }
}

[Serializable]
public sealed class ChoiceRandomCardTransformEffect : ChoiceCardTransformEffectBase
{
    [Min(1)] [SerializeField] private int _count = 1;
    protected override int RngSalt => 8160;
    public override int? DescAmount => _count;

    protected override List<RunDeckEntry> CollectTargets(EventContext context)
    {
        var eligible = new List<RunDeckEntry>();
        IReadOnlyList<RunDeckEntry> entries = context.Run?.DeckEntries;
        if (entries == null) return eligible;
        var service = new CardRewardService(
            context.Run.AvailableCardPool, AlwaysUnlockedProvider.Instance);
        for (int i = 0; i < entries.Count; i++)
            if (entries[i] != null && HasAnyAlternative(service, context, entries[i].CardId))
                eligible.Add(entries[i]);
        if (eligible.Count < _count) return new List<RunDeckEntry>();

        System.Random rng = CreateStableRng(context, RngSalt - 1);
        for (int i = eligible.Count - 1; i > 0; i--)
        {
            int j = rng.Next(i + 1);
            (eligible[i], eligible[j]) = (eligible[j], eligible[i]);
        }
        if (eligible.Count > _count) eligible.RemoveRange(_count, eligible.Count - _count);
        return eligible;
    }

    private static bool HasAnyAlternative(
        CardRewardService service, EventContext context, string sourceCardId)
    {
        CardQueryCriteria criteria = BuildTransformCriteria(context, sourceCardId);
        return service.HasAny(in criteria);
    }

    public override bool Validate(out string error)
    {
        error = _count > 0 ? null : "변환 장수는 1 이상이어야 합니다.";
        return error == null;
    }
}

[Serializable]
public sealed class ChoiceBasicCardsTransformEffect : ChoiceCardTransformEffectBase
{
    private static readonly HashSet<string> TargetIds = new HashSet<string>(StringComparer.Ordinal)
    {
        "Fire_Bolt",
        // 시작 덱의 화염구도 방향이 카드 ID에 분리된 레거시 기본 카드다.
        "Magic_Bolt_Left",
        "Magic_Bolt_Right",
        "Barrier",
        // 시작 덱의 마법 방벽은 방향이 카드 ID에 분리된 레거시 기본 카드다.
        // 표시명만 비슷한 중화염구와 Greater/Wind/Prism_Barrier 등의 파생 카드는 포함하지 않는다.
        "Barrier_Up",
        "Barrier_Down",
        "Barrier_UpDown",
    };

    protected override int RngSalt => 8170;

    protected override List<RunDeckEntry> CollectTargets(EventContext context)
    {
        var result = new List<RunDeckEntry>();
        IReadOnlyList<RunDeckEntry> entries = context.Run?.DeckEntries;
        if (entries == null) return result;
        for (int i = 0; i < entries.Count; i++)
            if (entries[i] != null && TargetIds.Contains(entries[i].CardId)) result.Add(entries[i]);
        return result;
    }

    public override bool Validate(out string error)
    {
        error = null;
        return true;
    }
}

// 카드 여러 장을 제물로 바쳐 상위 등급 카드 1장으로 변환한다.
//  - RequireSameRarity : 같은 등급만 제물로 받고 그 등급 +N 을 확정 지급 (정렬된 변이)
//  - 해제 시           : 아무 등급이나 받고, 제물에 든 등급들의 +N 중 균등 추첨 (무질서한 변이)
[Serializable]
public sealed class ChoiceTransmuteCardEffect : ChoiceEventEffectBase
{
    private const int RngSalt = 8140;

    [Tooltip("제물로 바칠 카드 장수.")]
    [Min(1)] [SerializeField] private int _sacrificeCount = 3;
    [Tooltip("체크 시 제물을 같은 등급으로만 받고, 결과 등급이 확정된다(정렬된 변이).")]
    [SerializeField] private bool _requireSameRarity;
    [Tooltip("결과 등급 상승 폭. 0 이면 동급 변환.")]
    [Min(0)] [SerializeField] private int _rarityStep = 1;
    [Tooltip("후보를 뽑을 카드 풀.")]
    [SerializeField] private ECardPool _pool = ECardPool.Normal;

    public override int? DescAmount => _sacrificeCount;

    public override bool CanApply(EventContext context)
    {
        RunContext run = context.Run;
        if (run == null || _pool == ECardPool.None ||
            run.DeckEntries.Count < _sacrificeCount)
            return false;

        var service = new CardRewardService(
            run.AvailableCardPool, AlwaysUnlockedProvider.Instance);

        // 정렬된 변이는 같은 등급을 요구 장수만큼 보유해야 성립한다.
        if (_requireSameRarity)
            return CollectRaritiesWithEnoughCards(run, service).Count > 0;

        int eligibleCount = 0;
        IReadOnlyList<RunDeckEntry> entries = run.DeckEntries;
        for (int i = 0; i < entries.Count; i++)
        {
            CardRuntimeData data = ResolveRuntimeData(entries[i]);
            if (data == null || !HasRewardAtOrBelow(service, Raise(data.Rarity))) continue;
            if (++eligibleCount >= _sacrificeCount) return true;
        }
        return false;
    }

    public override async UniTask<ChoiceEventEffectResult> ApplyAsync(
        EventContext context, CancellationToken token)
    {
        RunContext run = context.Run;
        if (run == null || context.InGame == null) return ChoiceEventEffectResult.FromAmount(0);

        // 1) 제물 선택 — 정렬된 변이는 첫 장의 등급으로 이후 후보를 좁힌다.
        var sacrificed = new List<RunDeckEntry>(_sacrificeCount);
        var rarities = new List<ECardRarity>(_sacrificeCount);
        ECardRarity? lockedRarity = null;
        var rewardService = new CardRewardService(
            run.AvailableCardPool, AlwaysUnlockedProvider.Instance);
        HashSet<ECardRarity> eligibleRarities = _requireSameRarity
            ? CollectRaritiesWithEnoughCards(run, rewardService)
            : null;

        for (int i = 0; i < _sacrificeCount; i++)
        {
            List<RunDeckEntry> candidates =
                CollectCandidates(
                    run, sacrificed, lockedRarity, rewardService, eligibleRarities);
            if (candidates.Count == 0)
            {
                throw new InvalidOperationException(
                    "[ChoiceTransmuteCardEffect] 제물로 바칠 카드가 부족합니다.");
            }

            string progress = RemainingProgressText(_sacrificeCount - i);
            RunDeckEntry entry =
                await SelectDeckEntryAsync(candidates, token, progress, requireConfirmation: true);
            if (entry == null)
                throw new InvalidOperationException(
                    "[ChoiceTransmuteCardEffect] 선택한 제물 엔트리를 확인할 수 없습니다.");

            CardRuntimeData data = ResolveRuntimeData(entry);
            if (data == null)
                throw new InvalidOperationException(
                    "[ChoiceTransmuteCardEffect] 선택한 제물의 런타임 데이터가 없습니다.");

            sacrificed.Add(entry);
            rarities.Add(data.Rarity);
            if (_requireSameRarity) lockedRarity ??= data.Rarity;
        }

        // 2) 결과 등급 결정 — 확정(정렬) 또는 제물 등급 집합에서 균등 추첨(무질서).
        ECardRarity targetRarity = ResolveTargetRarity(context, rarities);

        // 3) 보상을 먼저 확보한다. 제물을 먼저 지우면 보상 추첨이 실패했을 때
        //    카드만 잃고 아무것도 못 받는 순손실이 된다.
        CardDataSO reward = PickReward(rewardService, context, targetRarity);
        if (reward == null)
        {
            throw new InvalidOperationException(
                $"[ChoiceTransmuteCardEffect] {targetRarity} 등급 보상 후보가 없습니다.");
        }

        // 4) 제물 제거 후 지급. 코스트 보정은 제거 시 자동 정리된다.
        for (int i = 0; i < sacrificed.Count; i++)
            run.RemoveCardFromDeckEntry(sacrificed[i].EntryId, out _);

        context.InGame.AddCardToRunDeck(reward.CardId);
        return ChoiceEventEffectResult.FromAmount(sacrificed.Count);
    }

    public override bool Validate(out string error)
    {
        if (_sacrificeCount <= 0)
        {
            error = "제물 장수는 1 이상이어야 합니다.";
            return false;
        }
        if (_pool == ECardPool.None)
        {
            error = "변환 보상 카드 풀이 필요합니다.";
            return false;
        }
        error = null;
        return true;
    }

    // 이미 고른 제물과 (정렬 변이라면) 확정된 등급을 반영한 남은 후보.
    private List<RunDeckEntry> CollectCandidates(
        RunContext run,
        List<RunDeckEntry> picked,
        ECardRarity? lockedRarity,
        CardRewardService rewardService,
        HashSet<ECardRarity> eligibleRarities)
    {
        var result = new List<RunDeckEntry>();
        IReadOnlyList<RunDeckEntry> entries = run.DeckEntries;
        for (int i = 0; i < entries.Count; i++)
        {
            RunDeckEntry entry = entries[i];
            if (picked.Contains(entry)) continue;

            CardRuntimeData data = ResolveRuntimeData(entry);
            if (data == null) continue;
            if (lockedRarity.HasValue && data.Rarity != lockedRarity.Value) continue;
            if (!lockedRarity.HasValue && eligibleRarities != null &&
                !eligibleRarities.Contains(data.Rarity))
                continue;
            if (!HasRewardAtOrBelow(rewardService, Raise(data.Rarity))) continue;
            result.Add(entry);
        }
        return result;
    }

    // 보상 가능한 카드를 같은 등급으로 요구 장수만큼 보유한 등급 집합(정렬 변이 게이트).
    private HashSet<ECardRarity> CollectRaritiesWithEnoughCards(
        RunContext run, CardRewardService rewardService)
    {
        var counts = new Dictionary<ECardRarity, int>();
        IReadOnlyList<RunDeckEntry> entries = run.DeckEntries;
        for (int i = 0; i < entries.Count; i++)
        {
            CardRuntimeData data = ResolveRuntimeData(entries[i]);
            if (data == null) continue;
            if (!HasRewardAtOrBelow(rewardService, Raise(data.Rarity))) continue;
            counts.TryGetValue(data.Rarity, out int count);
            counts[data.Rarity] = count + 1;
        }

        var result = new HashSet<ECardRarity>();
        foreach (KeyValuePair<ECardRarity, int> pair in counts)
            if (pair.Value >= _sacrificeCount) result.Add(pair.Key);
        return result;
    }

    // 정렬 변이는 단일 등급이라 확정. 무질서 변이는 제물에 실제로 포함된 등급들의 상승분 중 균등 추첨.
    private ECardRarity ResolveTargetRarity(EventContext context, List<ECardRarity> rarities)
    {
        var raised = new List<ECardRarity>(rarities.Count);
        for (int i = 0; i < rarities.Count; i++)
        {
            ECardRarity value = Raise(rarities[i]);
            if (!raised.Contains(value)) raised.Add(value);
        }

        if (raised.Count == 0) return ECardRarity.Common;
        if (raised.Count == 1) return raised[0];

        raised.Sort();
        return raised[CreateStableRng(context, RngSalt).Next(raised.Count)];
    }

    private ECardRarity Raise(ECardRarity rarity)
        => (ECardRarity)Mathf.Min((int)rarity + _rarityStep, (int)ECardRarity.Legendary);

    private bool HasRewardAtOrBelow(CardRewardService service, ECardRarity targetRarity)
    {
        for (int rarity = (int)targetRarity; rarity >= 0; rarity--)
        {
            var criteria = new CardQueryCriteria(_pool, (ECardRarity)rarity);
            if (service.HasAny(in criteria)) return true;
        }
        return false;
    }

    // 목표 등급 후보가 없으면 한 단계씩 낮춰 재시도한다(초기 빌드에 고등급 카드가 적을 수 있음).
    private CardDataSO PickReward(
        CardRewardService service, EventContext context, ECardRarity targetRarity)
    {
        System.Random rng = CreateStableRng(context, RngSalt + 1);

        for (int rarity = (int)targetRarity; rarity >= 0; rarity--)
        {
            var criteria = new CardQueryCriteria(_pool, (ECardRarity)rarity);
            List<CardDataSO> picked = service.PickRandom(in criteria, 1, rng);
            if (picked.Count > 0) return picked[0];
        }
        return null;
    }

    private static string RemainingProgressText(int remaining)
        => LocalizationManager.HasInstance
            ? LocalizationManager.Instance.Get("UI_CHOICE_TRANSMUTE_REMAINING", remaining)
            : string.Empty;
}

// 보유 스킬 하나의 쿨타임을 영구히 낮춘다. 선택지 하나가 스킬 슬롯 하나에 대응하며,
// 슬롯이 비었거나 이미 하한 쿨타임인 스킬의 선택지는 잠긴다.
[Serializable]
public sealed class ChoiceSkillCooldownEffect : ChoiceEventEffectBase
{
    [Tooltip("대상 스킬 슬롯(0-based). 캐릭터 보유 스킬 순서와 같다.")]
    [Range(0, 2)] [SerializeField] private int _skillSlotIndex;
    [Tooltip("낮출 쿨타임 턴 수.")]
    [Min(1)] [SerializeField] private int _amount = 1;
    [Tooltip("적용 후 최소 쿨타임. 0턴 스킬은 허용하지 않으므로 1 미만으로 내릴 수 없다.")]
    [Min(SkillDataSO.CooldownMin)] [SerializeField] private int _minCooldown = SkillDataSO.CooldownMin;

    public override int? DescAmount => _amount;

    public override bool CanApply(EventContext context)
    {
        RunContext run = context.Run;
        SkillDataSO skill = ResolveSkill();
        if (run == null || skill == null) return false; // 슬롯이 비었으면 선택 불가
        // 이미 하한 쿨타임인 스킬은 더 낮출 수 없으므로 선택지가 잠긴다.
        return CurrentCooldown(run, skill, context.InGame) > EffectiveMinCooldown;
    }

    /// <summary>SO 하한을 밑돌지 않도록 보정한 실제 하한.</summary>
    private int EffectiveMinCooldown => Mathf.Max(SkillDataSO.CooldownMin, _minCooldown);

    public override void CollectTextTokens(IDictionary<string, string> tokens)
        => CollectTextTokens(tokens, useCurrentCooldown: false);

    public override void CollectResultTextTokens(IDictionary<string, string> tokens)
        => CollectTextTokens(tokens, useCurrentCooldown: true);

    private void CollectTextTokens(
        IDictionary<string, string> tokens, bool useCurrentCooldown)
    {
        SkillDataSO skill = ResolveSkill();
        if (skill == null || tokens == null) return;

        string name = Localize(skill.DisplayNameKey);
        tokens["skill"] = name;
        tokens["skill" + _skillSlotIndex] = name;

        RunContext run = InGameController.HasInstance ? InGameController.Instance.CurrentRun : null;
        if (run != null)
        {
            int current = CurrentCooldown(run, skill, InGameController.Instance);
            int after = useCurrentCooldown
                ? current
                : Mathf.Max(EffectiveMinCooldown, current - _amount);
            tokens["cooldownAfter"] = after.ToString();
        }
    }

    public override UniTask<ChoiceEventEffectResult> ApplyAsync(
        EventContext context, CancellationToken token)
    {
        RunContext run = context.Run;
        SkillDataSO skill = ResolveSkill();
        if (run == null || skill == null)
            return UniTask.FromResult(ChoiceEventEffectResult.FromAmount(0));

        int before = CurrentCooldown(run, skill, context.InGame);
        int after = Mathf.Max(EffectiveMinCooldown, before - _amount);
        int appliedDecrease = before - after;
        run.SetSkillCooldownDelta(
            skill.SkillId,
            run.GetSkillCooldownDelta(skill.SkillId) - appliedDecrease);
        return UniTask.FromResult(ChoiceEventEffectResult.FromAmount(appliedDecrease)); // 실제 감소량
    }

    public override bool Validate(out string error)
    {
        if (_skillSlotIndex < 0)
        {
            error = "스킬 슬롯 번호는 0 이상이어야 합니다.";
            return false;
        }
        error = _amount > 0 ? null : "쿨타임 감소량은 1 이상이어야 합니다.";
        return error == null;
    }

    private static int CurrentCooldown(
        RunContext run, SkillDataSO skill, InGameController inGame)
    {
        int difficultyDelta = inGame != null
            ? inGame.GetAdditionalSkillCooldown(skill)
            : 0;
        int eventDelta = run != null
            ? run.GetSkillCooldownDelta(skill.SkillId)
            : 0;
        return skill.ResolveCooldown(difficultyDelta + eventDelta);
    }

    // 캐릭터가 슬롯 수보다 적은 스킬을 가질 수 있으므로 범위를 항상 확인한다.
    private SkillDataSO ResolveSkill()
    {
        if (!InGameController.HasInstance) return null;
        CharacterSO character = InGameController.Instance.SelectedCharacter;
        if (character == null) return null;

        IReadOnlyList<SkillDataSO> skills = character.Skills;
        if (skills == null || _skillSlotIndex < 0 || _skillSlotIndex >= skills.Count) return null;
        return skills[_skillSlotIndex];
    }
}

[Serializable]
public sealed class ChoiceHealEffect : ChoiceEventEffectBase
{
    [Min(1)] [SerializeField] private int _amount = 10;
    [Tooltip("체크 시 회복량을 무시하고 최대 체력까지 완전 회복한다.")]
    [SerializeField] private bool _healToFull;

    // 풀힐은 회복량이 현재 HP 에 따라 달라져 고정 수치가 없으므로 토큰 노출 없음.
    public override int? DescAmount => _healToFull ? (int?)null : _amount;

    public override UniTask<ChoiceEventEffectResult> ApplyAsync(EventContext context, CancellationToken token)
    {
        RunContext run = context.Run;
        int healed = run != null ? run.HealHp(_healToFull ? run.MaxHp : _amount) : 0; // 실제 회복량 반환
        return UniTask.FromResult(ChoiceEventEffectResult.FromAmount(healed));
    }

    public override bool Validate(out string error)
    {
        error = (_healToFull || _amount > 0) ? null : "회복량은 1 이상이어야 합니다.";
        return error == null;
    }
}

[Serializable]
public sealed class ChoiceAddCardEffect : ChoiceEventEffectBase
{
    [SerializeField] private CardDataSO _card;

    public override UniTask<ChoiceEventEffectResult> ApplyAsync(EventContext context, CancellationToken token)
    {
        if (_card != null) context.InGame?.AddCardToRunDeck(_card.CardId);
        return UniTask.FromResult(ChoiceEventEffectResult.FromAmount(null));
    }

    public override bool Validate(out string error)
    {
        error = _card != null ? null : "추가할 카드가 필요합니다.";
        return error == null;
    }
}

[Serializable]
public sealed class ChoiceRemoveCardEffect : ChoiceEventEffectBase
{
    [SerializeField] private EChoiceCardRemoveMode _mode;
    [Tooltip("제거할 카드 장수. PlayerSelect 는 이 횟수만큼 선택 팝업을 반복한다.")]
    [Min(1)] [SerializeField] private int _count = 1;

    public override int? DescAmount => _count;

    public override async UniTask<ChoiceEventEffectResult> ApplyAsync(EventContext context, CancellationToken token)
    {
        RunContext run = context.Run;
        if (run == null) return ChoiceEventEffectResult.FromAmount(0);

        int removedTotal = 0;
        for (int removed = 0; removed < _count; removed++)
        {
            if (run.DeckEntries.Count == 0)
            {
                Debug.LogWarning("[ChoiceRemoveCardEffect] 제거할 카드가 없어 남은 제거를 건너뜁니다.");
                break;
            }

            var entries = new List<RunDeckEntry>(run.DeckEntries);
            RunDeckEntry entry;
            if (_mode == EChoiceCardRemoveMode.Random)
            {
                entry = entries[run.Rng.Next(entries.Count)];
            }
            else
            {
                // 남은 제거 횟수 표시(다중 제거일 때만). 선택 후 확인 버튼으로 제거 확정.
                string progress = _count > 1 ? RemainingProgressText(_count - removed) : null;
                entry = await SelectDeckEntryAsync(entries, token, progress, requireConfirmation: true);
            }
            if (entry == null) break; // 선택 불가/취소 → 남은 제거 중단

            if (run.RemoveCardFromDeckEntry(entry.EntryId, out _))
                removedTotal++;
            else
                Debug.LogWarning($"[ChoiceRemoveCardEffect] 카드 제거에 실패했습니다: entry={entry.EntryId}");
        }
        return ChoiceEventEffectResult.FromAmount(removedTotal); // 실제 제거한 장수
    }

    public override bool Validate(out string error)
    {
        error = _count > 0 ? null : "제거 장수는 1 이상이어야 합니다.";
        return error == null;
    }

    // "남은 제거 N장" 표기. 키가 있으면 로컬라이즈(포맷 {0}), 없으면 폴백 문자열.
    private static string RemainingProgressText(int remaining)
    {
        if (LocalizationManager.HasInstance)
            return LocalizationManager.Instance.Get("UI_CHOICE_REMOVE_REMAINING", remaining);
        return $"남은 제거 {remaining}장";
    }
}

[Serializable]
public sealed class ChoiceArrowEffect : ChoiceEventEffectBase
{
    private const ECardDirection Cardinals =
        ECardDirection.Up | ECardDirection.Down | ECardDirection.Left | ECardDirection.Right;

    [SerializeField] private EChoiceArrowOperation _operation;
    [SerializeField] private EChoiceArrowTargetMode _targetMode;
    [SerializeField] private EChoiceDirectionMode _removeDirectionMode = EChoiceDirectionMode.PlayerSelect;
    [SerializeField] private ECardDirection _fixedRemoveDirection = ECardDirection.Up;
    [SerializeField] private EChoiceDirectionMode _addDirectionMode = EChoiceDirectionMode.PlayerSelect;
    [SerializeField] private ECardDirection _fixedAddDirection = ECardDirection.Up;

    public override async UniTask<ChoiceEventEffectResult> ApplyAsync(EventContext context, CancellationToken token)
    {
        RunContext run = context.Run;
        if (run == null) return ChoiceEventEffectResult.FromAmount(null);

        List<RunDeckEntry> eligible = BuildEligibleEntries(run);
        if (eligible.Count == 0)
        {
            Debug.LogWarning($"[ChoiceArrowEffect] 적용 가능한 카드가 없어 {_operation} 효과를 건너뜁니다.");
            return ChoiceEventEffectResult.FromAmount(null);
        }

        RunDeckEntry entry = _targetMode == EChoiceArrowTargetMode.Random
            ? eligible[run.Rng.Next(eligible.Count)]
            : await SelectDeckEntryAsync(eligible, token);
        if (entry == null) return ChoiceEventEffectResult.FromAmount(null);

        ECardDirection remove = ECardDirection.None;
        ECardDirection add = ECardDirection.None;
        if (_operation != EChoiceArrowOperation.Add)
        {
            remove = await ResolveDirectionAsync(
                entry,
                entry.ArrowDirection & Cardinals,
                _removeDirectionMode,
                _fixedRemoveDirection,
                "UI_CHOICE_ARROW_REMOVE",
                run,
                token);
            if (remove == ECardDirection.None) return ChoiceEventEffectResult.FromAmount(null);
        }

        if (_operation != EChoiceArrowOperation.Remove)
        {
            ECardDirection allowedAdd = Cardinals & ~entry.ArrowDirection;
            add = await ResolveDirectionAsync(
                entry,
                allowedAdd,
                _addDirectionMode,
                _fixedAddDirection,
                "UI_CHOICE_ARROW_ADD",
                run,
                token);
            if (add == ECardDirection.None || add == remove)
                return ChoiceEventEffectResult.FromAmount(null);
        }

        bool applied = _operation switch
        {
            EChoiceArrowOperation.Add => run.TryAddArrowToEntry(entry.EntryId, add),
            EChoiceArrowOperation.Remove => run.TryRemoveArrowFromEntry(entry.EntryId, remove),
            EChoiceArrowOperation.Replace => run.TryReplaceArrowOnEntry(entry.EntryId, remove, add),
            _ => false
        };
        if (!applied)
        {
            Debug.LogWarning($"[ChoiceArrowEffect] 화살표 {_operation} 적용에 실패했습니다: entry={entry.EntryId}");
            return ChoiceEventEffectResult.FromAmount(null);
        }

        return add != ECardDirection.None
            ? ChoiceEventEffectResult.ArrowAdded(entry, add)
            : ChoiceEventEffectResult.FromAmount(null);
    }

    public override bool Validate(out string error)
    {
        if (_operation != EChoiceArrowOperation.Add &&
            _removeDirectionMode == EChoiceDirectionMode.Fixed && !IsSingleCardinal(_fixedRemoveDirection))
        {
            error = "삭제 고정 방향은 상하좌우 중 하나여야 합니다.";
            return false;
        }
        if (_operation != EChoiceArrowOperation.Remove &&
            _addDirectionMode == EChoiceDirectionMode.Fixed && !IsSingleCardinal(_fixedAddDirection))
        {
            error = "추가 고정 방향은 상하좌우 중 하나여야 합니다.";
            return false;
        }
        if (_operation == EChoiceArrowOperation.Replace &&
            _removeDirectionMode == EChoiceDirectionMode.Fixed &&
            _addDirectionMode == EChoiceDirectionMode.Fixed &&
            _fixedRemoveDirection == _fixedAddDirection)
        {
            error = "변경 전후 방향은 달라야 합니다.";
            return false;
        }
        error = null;
        return true;
    }

    private List<RunDeckEntry> BuildEligibleEntries(RunContext run)
    {
        var result = new List<RunDeckEntry>();
        IReadOnlyList<RunDeckEntry> entries = run.DeckEntries;
        for (int i = 0; i < entries.Count; i++)
        {
            RunDeckEntry entry = entries[i];
            if (entry == null) continue;
            if (entry.RuntimeData == null && DataManager.HasInstance && DataManager.Instance.IsLoaded)
            {
                CardDataSO cardData = DataManager.Instance.GetData<CardDataSO>(entry.CardId);
                if (cardData != null) entry.SetRuntimeData(CardFactory.FromSO(cardData));
            }
            if (entry.RuntimeData == null) continue;
            if (!entry.HasArrowDirection && !entry.EnsureArrowResolved()) continue;

            ECardDirection current = entry.ArrowDirection & Cardinals;
            ECardDirection removable = current;
            ECardDirection addable = Cardinals & ~current;
            if (_operation != EChoiceArrowOperation.Add &&
                _removeDirectionMode == EChoiceDirectionMode.Fixed)
                removable &= _fixedRemoveDirection;
            if (_operation != EChoiceArrowOperation.Remove &&
                _addDirectionMode == EChoiceDirectionMode.Fixed)
                addable &= _fixedAddDirection;

            bool eligible = _operation switch
            {
                EChoiceArrowOperation.Add => addable != ECardDirection.None,
                EChoiceArrowOperation.Remove => removable != ECardDirection.None,
                EChoiceArrowOperation.Replace => removable != ECardDirection.None &&
                                                 addable != ECardDirection.None,
                _ => false
            };
            if (eligible) result.Add(entry);
        }
        return result;
    }

    private static async UniTask<ECardDirection> ResolveDirectionAsync(
        RunDeckEntry entry,
        ECardDirection allowed,
        EChoiceDirectionMode mode,
        ECardDirection fixedDirection,
        string titleKey,
        RunContext run,
        CancellationToken token)
    {
        allowed &= Cardinals;
        if (allowed == ECardDirection.None) return ECardDirection.None;
        if (mode == EChoiceDirectionMode.Fixed)
            return (allowed & fixedDirection) != 0 ? fixedDirection : ECardDirection.None;
        if (mode == EChoiceDirectionMode.Random)
            return PickRandomDirection(allowed, run.Rng);
        if (!UIManager.HasInstance) return ECardDirection.None;

        UIReinforcePopup.Show(false);
        UIReinforcePopup popup = await UIManager.Instance.OpenAsync<UIReinforcePopup>(token);
        if (popup == null) return ECardDirection.None;

        var source = new UniTaskCompletionSource<ECardDirection>();
        void Confirm(int _, ECardDirection direction) => source.TrySetResult(direction);
        popup.OnDirectionConfirmed += Confirm;
        popup.ShowDirectionSelection(entry, allowed, Localize(titleKey), false);
        try
        {
            return await source.Task.AttachExternalCancellation(token);
        }
        finally
        {
            popup.OnDirectionConfirmed -= Confirm;
            if (popup.IsOpen && UIManager.HasInstance) UIManager.Instance.Close(popup);
        }
    }

    private static ECardDirection PickRandomDirection(ECardDirection allowed, System.Random rng)
    {
        ECardDirection[] values =
        {
            ECardDirection.Up, ECardDirection.Down, ECardDirection.Left, ECardDirection.Right
        };
        var candidates = new List<ECardDirection>(4);
        for (int i = 0; i < values.Length; i++)
            if ((allowed & values[i]) != 0) candidates.Add(values[i]);
        return candidates.Count == 0 ? ECardDirection.None : candidates[rng.Next(candidates.Count)];
    }

    private static bool IsSingleCardinal(ECardDirection direction)
        => direction == ECardDirection.Up || direction == ECardDirection.Down ||
           direction == ECardDirection.Left || direction == ECardDirection.Right;
}

// 최대 HP 영구 증가. 증가분만큼 현재 HP 도 항상 함께 상승.
[Serializable]
public sealed class ChoiceMaxHpEffect : ChoiceEventEffectBase
{
    [Min(1)] [SerializeField] private int _amount = 5;

    public override int? DescAmount => _amount;

    public override UniTask<ChoiceEventEffectResult> ApplyAsync(EventContext context, CancellationToken token)
    {
        context.Run?.IncreaseMaxHp(_amount);
        return UniTask.FromResult(ChoiceEventEffectResult.FromAmount(_amount));
    }

    public override bool Validate(out string error)
    {
        error = _amount > 0 ? null : "최대 체력 증가량은 1 이상이어야 합니다.";
        return error == null;
    }
}

// 보존 한도 증감(런 단위). 감소 시 0 미만으로 내려가지 않도록 클램프.
[Serializable]
public sealed class ChoicePreserveEffect : ChoiceEventEffectBase
{
    [Tooltip("양수는 증가, 음수는 감소. 감소는 0 미만으로 내려가지 않는다.")]
    [SerializeField] private int _delta = 1;

    public override int? DescAmount => _delta;

    public override UniTask<ChoiceEventEffectResult> ApplyAsync(EventContext context, CancellationToken token)
    {
        RunContext run = context.Run;
        if (run == null || _delta == 0)
            return UniTask.FromResult(ChoiceEventEffectResult.FromAmount(0));

        int before = run.MaxPreserveCount;
        if (_delta > 0)
            run.IncreaseMaxPreserveCount(_delta);
        else
            run.SetMaxPreserveCount(run.MaxPreserveCount + _delta); // SetMaxPreserveCount 가 0 하한 보정
        return UniTask.FromResult(
            ChoiceEventEffectResult.FromAmount(run.MaxPreserveCount - before)); // 실제 증감량
    }

    public override bool Validate(out string error)
    {
        error = _delta != 0 ? null : "보존 증감량은 0 이 아니어야 합니다.";
        return error == null;
    }
}

// 최대 마나 증감(런 단위). 하한(0) 클램프.
[Serializable]
public sealed class ChoiceModifyMaxManaEffect : ChoiceEventEffectBase
{
    [Tooltip("양수는 증가, 음수는 감소. 최소 0 으로 클램프.")]
    [SerializeField] private int _delta = 1;

    public override int? DescAmount => _delta;

    public override UniTask<ChoiceEventEffectResult> ApplyAsync(EventContext context, CancellationToken token)
    {
        RunContext run = context.Run;
        if (run == null || _delta == 0)
            return UniTask.FromResult(ChoiceEventEffectResult.FromAmount(0));
        int before = run.MaxMana;
        run.ModifyMaxMana(_delta);
        return UniTask.FromResult(
            ChoiceEventEffectResult.FromAmount(run.MaxMana - before)); // 실제 증감량
    }

    public override bool Validate(out string error)
    {
        error = _delta != 0 ? null : "마나 증감량은 0 이 아니어야 합니다.";
        return error == null;
    }
}

// 턴 드로우 수 증감(런 단위). 하한(1) 클램프로 0 드로우 소프트락 방지.
[Serializable]
public sealed class ChoiceModifyDrawEffect : ChoiceEventEffectBase
{
    [Tooltip("양수는 증가, 음수는 감소. 최소 1 로 클램프.")]
    [SerializeField] private int _delta = 1;

    public override int? DescAmount => _delta;

    public override UniTask<ChoiceEventEffectResult> ApplyAsync(EventContext context, CancellationToken token)
    {
        RunContext run = context.Run;
        if (run == null || _delta == 0)
            return UniTask.FromResult(ChoiceEventEffectResult.FromAmount(0));
        int before = run.DrawPerTurn;
        run.ModifyDrawPerTurn(_delta);
        return UniTask.FromResult(
            ChoiceEventEffectResult.FromAmount(run.DrawPerTurn - before)); // 실제 증감량
    }

    public override bool Validate(out string error)
    {
        error = _delta != 0 ? null : "드로우 증감량은 0 이 아니어야 합니다.";
        return error == null;
    }
}
