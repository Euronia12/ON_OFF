// =================================================================
// [스크립트 목적]  Choice Event 한 선택지의 순수 데이터(EventDataSO 에 직렬화).
//                 + 뷰에 주입하는 경계 POCO(EventViewData). UI 참조 없음.
// [설계 노트]      - UI(버튼/텍스트) 참조는 슬롯 프리팹(UIChoiceSlot)이 보유.
//                    데이터(키/효과/조건)는 여기 + EventDataSO 가 보유해 완전 분리.
// =================================================================

using System;
using System.Collections.Generic;
using UnityEngine;

[Serializable]
public sealed class EventChoiceData
{
    [Tooltip("선택지 버튼 라벨 번역 키")]
    [SerializeField] private string _textKey;
    [Tooltip("버튼 라벨과 별개로 표시할 선택지 설명 번역 키(선택)")]
    [SerializeField] private string _descKey;
    [Tooltip("선택 확정 후 표시할 결과(후속) 텍스트 번역 키(선택). 비우면 결과 문구 없음.")]
    [SerializeField] private string _resultKey;
    [SerializeReference] private List<ChoiceEventEffectBase> _effects = new();

    [Tooltip("요구량. 모두 충족해야 해금(잠김 해제)되고, 선택 시 그만큼 차감된다.")]
    [SerializeField] private List<EventCost> _costs = new();

    [Tooltip("덱 최소 장수 게이트. 0=하한 없음. 미충족 시 잠김(차감 없음).")]
    [Min(0)] [SerializeField] private int _minDeckSize;
    [Tooltip("덱 최대 장수 게이트. 0=상한 없음.")]
    [Min(0)] [SerializeField] private int _maxDeckSize;

    public string TextKey => _textKey;
    public string DescKey => _descKey;
    public string ResultKey => _resultKey;
    public IReadOnlyList<ChoiceEventEffectBase> Effects => _effects;
    public IReadOnlyList<EventCost> Costs => _costs;
    public int MinDeckSize => _minDeckSize;
    public int MaxDeckSize => _maxDeckSize;

    /// <summary>덱 크기 게이트 충족 여부(차감 없는 순수 잠금).</summary>
    public bool IsDeckSizeAllowed(RunContext run)
    {
        if (run == null) return false;
        int count = run.DeckEntries.Count;
        return (_minDeckSize <= 0 || count >= _minDeckSize) &&
               (_maxDeckSize <= 0 || count <= _maxDeckSize);
    }
}

/// <summary>
/// EventController 가 EventDataSO 에서 만들어 뷰(UIChoiceEvent)에 주입하는 경계 객체.
/// 뷰가 ScriptableObject 를 직접 참조하지 않게 한다(SO 격리). 효과는 무상태라 공유 참조 안전.
/// </summary>
public sealed class EventViewData
{
    /// <summary>선택 기록(연쇄 이벤트 선행 조건)용 식별자. 뷰는 표시에 쓰지 않는다.</summary>
    public string EventId { get; }
    public string TitleKey { get; }
    public string DescKey { get; }
    public Sprite Image { get; }
    public IReadOnlyList<EventChoiceData> Choices { get; }
    public bool UseSeededRandom { get; }

    public EventViewData(string eventId, string titleKey, string descKey, Sprite image,
        IReadOnlyList<EventChoiceData> choices, bool useSeededRandom = true)
    {
        EventId = eventId;
        TitleKey = titleKey;
        DescKey = descKey;
        Image = image;
        Choices = choices ?? Array.Empty<EventChoiceData>();
        UseSeededRandom = useSeededRandom;
    }
}
