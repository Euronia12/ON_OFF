// =================================================================
// [스크립트 목적]  Choice Event 선택지 요구량(Cost). 충족돼야 해금(게이트)하고,
//                 선택 시 그만큼 수치를 차감한다. 조건(Requirement)을 대체하는 단일 개념.
// [의존 관계]      - RunContext(런 스탯 차감/조회)
// [설계 노트]      - 하한 클램프로 지불 후 음수/자살을 방지. 게이트가 지불 가능성을 보장하므로
//                    실제 Pay 는 부분 실패 없이 안전하게 적용된다.
// =================================================================

using System;
using UnityEngine;

/// <summary>요구량으로 지불 가능한 런 스탯 종류.</summary>
public enum ECostType
{
    Gold = 0,
    CurrentHp = 1,
    MaxHp = 2,
    MaxMana = 3,
    Preserve = 4,
    Draw = 5,
}

[Serializable]
public sealed class EventCost
{
    // 하한: 지불 후 이 값 미만이 되면 지불 불가(게이트).
    private const int HpMin = 1;
    private const int MaxHpMin = 1;
    private const int ManaMin = 0;
    private const int PreserveMin = 0;
    private const int DrawMin = 1;

    [SerializeField] private ECostType _type = ECostType.Gold;
    [Min(1)] [SerializeField] private int _amount = 10;

    public ECostType Type => _type;
    public int Amount => _amount;

    /// <summary>지불 가능 여부(해금 게이트). 지불 후 하한을 유지해야 true.</summary>
    public bool CanAfford(EventContext context)
    {
        RunContext run = context.Run;
        if (run == null) return false;
        return _type switch
        {
            ECostType.Gold => run.CanAffordGold(_amount),
            ECostType.CurrentHp => run.CurrentHp - _amount >= HpMin,
            ECostType.MaxHp => run.MaxHp - _amount >= MaxHpMin,
            ECostType.MaxMana => run.MaxMana - _amount >= ManaMin,
            ECostType.Preserve => run.MaxPreserveCount - _amount >= PreserveMin,
            ECostType.Draw => run.DrawPerTurn - _amount >= DrawMin,
            _ => false
        };
    }

    /// <summary>수치 차감(선택 확정 시). CanAfford 통과를 전제로 호출.</summary>
    public void Pay(EventContext context)
    {
        RunContext run = context.Run;
        if (run == null || _amount <= 0) return;
        switch (_type)
        {
            // 골드는 InGameController 경유 → OnGoldChanged 발행(상단 정보 바 갱신).
            case ECostType.Gold: context.InGame?.SpendGold(_amount); break;
            case ECostType.CurrentHp: run.SetCurrentHp(run.CurrentHp - _amount); break;
            case ECostType.MaxHp: run.ModifyMaxHp(-_amount); break;
            case ECostType.MaxMana: run.ModifyMaxMana(-_amount); break;
            case ECostType.Preserve: run.SetMaxPreserveCount(run.MaxPreserveCount - _amount); break;
            case ECostType.Draw: run.ModifyDrawPerTurn(-_amount); break;
        }
    }
}
