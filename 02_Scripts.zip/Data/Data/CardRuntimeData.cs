// =================================================================
// [스크립트 목적]  카드 1장의 런타임 데이터 (순수 POCO). SO 격리 경계.
//                  CardDataSO 의 강화 분기(기본/강화)를 "이미 선택된 단일 값"으로 평탄화한다.
// [주요 변수]      - CardId/표시키        : 식별·UI 키
//                  - CardType/Rarity/Keywords : 분류·키워드 비트
//                  - Cost                 : 강화 반영된 단일 비용
//                  - Effects              : 효과 정의 리스트 (SO 의 [SerializeReference] 원본 참조)
//                  - Arrow                : 방위 화살표 설정 (ArrowConfig 참조)
//                  - Range                : 신호 전파 사거리 (강화 반영)
//                  - Propagation          : 경로 차단 규칙 (관통/차단/빈칸막힘)
//                  - Vfx*                 : 연출 데이터 (prefab 참조 제거 → string key)
//                  - IsTemporaryFieldOnly : 덱/묘지에 편입되지 않는 필드 전용 임시 카드 여부
//                  - GeneratesCardsOnTurnEnd : ON 상태 턴 종료 시 설정된 카드 생성 여부
//                  - IsHandOnlyDisturbance : 손패에만 머물다 턴 종료 시 제거되는 방해 카드 여부
// [의존 관계]      - CardFactory.FromSO 가 생성, CardFactory.Create 가 소비
//                  - 이 클래스는 CardDataSO(ScriptableObject)를 일절 참조하지 않는다 (격리)
// [설계 노트]      - SO 의 강화 분기(GetEffects/GetArrowConfig/GetRange 등)는
//                    FromSO 에서 1회 해소, 이후 게임플레이는 단일 값만 본다
//                  - Effects 는 여기서 Clone 하지 않는다. 카드 인스턴스별 격리는 Create 가 담당
//                    (메모리 원칙: "효과는 카드 인스턴스마다 Clone")
//                  - projectile/VFX 는 prefab 이 아닌 풀 키(string)만 보유 → PoolManager.SpawnAsync(key)
// =================================================================

using System.Collections.Generic;

/// <summary>
/// 카드의 런타임 데이터 컨테이너 (순수 POCO).
/// CardDataSO 가 보유하던 정적 데이터 중 "현재 강화 상태에서 실제 사용될 값"만 평탄화해 담는다.
/// ScriptableObject 의존을 끊는 격리 경계로서, 게임플레이 코드는 이 타입만 참조한다.
/// </summary>
public sealed class CardRuntimeData
{
    // ── 기본 정보 ───────────────────────────────────────────
    public string CardId { get; }
    public string DisplayNameKey { get; }
    public string DescriptionKey { get; }
    public string IconKey { get; }

    public ECardType CardType { get; }
    public ECardRarity Rarity { get; }
    public ECardKeyword Keywords { get; }

    /// <summary>강화 여부가 이미 반영된 단일 비용.</summary>
    public int Cost { get; }

    /// <summary>이 데이터가 강화 상태로 변환됐는지.</summary>
    public bool IsUpgraded { get; }

    // ── 효과 / 방향 ─────────────────────────────────────────

    /// <summary>
    /// 효과 정의 리스트. SO 의 [SerializeReference] 효과를 그대로 참조한다 (여기선 미복제).
    /// 카드 인스턴스별 독립 상태는 CardFactory.Create 가 Clone 으로 보장한다.
    /// </summary>
    public IReadOnlyList<CardEffectBase> Effects { get; }

    /// <summary>방위 화살표 설정. CardArrowState 가 Resolve 시 참조.</summary>
    public ArrowConfig Arrow { get; }

    // ── 신호 전파 ───────────────────────────────────────────

    /// <summary>신호(체인) 전파 사거리 (강화 반영). 1 이면 인접 1칸. ChainExecutor 가 사용.</summary>
    public int Range { get; }

    /// <summary>경로 차단 규칙 (관통/차단/빈칸막힘). 체인 전파 시 ChainExecutor 가 해석.</summary>
    public EChainPropagation Propagation { get; }

    /// <summary>체인 전파 패턴. 특수 카드면 Line 대신 별도 패턴을 사용한다 (형태 고정 — 거리는 Range).</summary>
    public EChainPatternType PatternType { get; }

    // ── 연출 (prefab 참조 제거 → 풀 키) ─────────────────────

    /// <summary>연출 종류 (없음/투사체/적중/둘다).</summary>
    public EVfxType VfxType { get; }

    /// <summary>연출 대상 방향 (적/자기).</summary>
    public EVfxTarget VfxTarget { get; }

    /// <summary>투사체 풀 키 (PoolManager.SpawnAsync 키). 비어있으면 투사체 생략.</summary>
    public string ProjectileKey { get; }

    /// <summary>적중 이펙트 풀 키. 비어있으면 적중 연출 생략.</summary>
    public string HitVfxKey { get; }

    /// <summary>필드 전용 임시 카드 여부. true 면 턴 종료 시 묘지로 가지 않고 제거된다.</summary>
    public bool IsTemporaryFieldOnly { get; }

    /// <summary>ON 상태로 턴 종료 시 설정된 카드를 플레이어 드로우 더미에 추가하는 블록 여부.</summary>
    public bool GeneratesCardsOnTurnEnd { get; }

    /// <summary>ON 상태로 턴 종료 시 생성할 CardDataSO의 에셋 이름.</summary>
    public string TurnEndGeneratedCardId { get; }

    /// <summary>ON 상태로 턴 종료 시 블록 한 장당 생성할 카드 수.</summary>
    public int TurnEndGeneratedCardCount { get; }

    /// <summary>손패 전용 방해 카드 여부. 그리드 배치 불가, 턴 종료 시 묘지 없이 제거된다.</summary>
    public bool IsHandOnlyDisturbance { get; }

    /// <summary>손패에 남은 채 턴 종료되면 플레이어에게 피해를 주는 카드 여부.</summary>
    public bool DealsDamageInHandOnTurnEnd { get; }

    /// <summary>DealsDamageInHandOnTurnEnd 가 true 일 때 턴 종료 시 가하는 피해량.</summary>
    public int HandTurnEndDamage { get; }

    public CardRuntimeData(
        string cardId,
        string displayNameKey,
        string descriptionKey,
        string iconKey,
        ECardType cardType,
        ECardRarity rarity,
        ECardKeyword keywords,
        int cost,
        bool isUpgraded,
        IReadOnlyList<CardEffectBase> effects,
        ArrowConfig arrow,
        int range,
        EChainPropagation propagation,
        EChainPatternType patternType,
        EVfxType vfxType,
        EVfxTarget vfxTarget,
        string projectileKey,
        string hitVfxKey,
        bool isTemporaryFieldOnly = false,
        bool generatesCardsOnTurnEnd = false,
        string turnEndGeneratedCardId = null,
        int turnEndGeneratedCardCount = 0,
        bool isHandOnlyDisturbance = false,
        bool dealsDamageInHandOnTurnEnd = false,
        int handTurnEndDamage = 0)
    {
        CardId = cardId;
        DisplayNameKey = displayNameKey;
        DescriptionKey = descriptionKey;
        IconKey = iconKey ?? string.Empty;
        CardType = cardType;
        Rarity = rarity;
        Keywords = keywords;
        Cost = cost;
        IsUpgraded = isUpgraded;
        Effects = effects ?? new List<CardEffectBase>();
        Arrow = arrow;
        Range = range < 1 ? 1 : range;
        Propagation = propagation;
        PatternType = patternType;
        VfxType = vfxType;
        VfxTarget = vfxTarget;
        ProjectileKey = projectileKey ?? string.Empty;
        HitVfxKey = hitVfxKey ?? string.Empty;
        IsTemporaryFieldOnly = isTemporaryFieldOnly;
        GeneratesCardsOnTurnEnd = generatesCardsOnTurnEnd;
        TurnEndGeneratedCardId = turnEndGeneratedCardId ?? string.Empty;
        TurnEndGeneratedCardCount = turnEndGeneratedCardCount < 0 ? 0 : turnEndGeneratedCardCount;
        IsHandOnlyDisturbance = isHandOnlyDisturbance;
        DealsDamageInHandOnTurnEnd = dealsDamageInHandOnTurnEnd;
        HandTurnEndDamage = handTurnEndDamage < 0 ? 0 : handTurnEndDamage;
    }

    /// <summary>효과 비트 합산 (조회/UI용). 효과 리스트로부터 매번 산출.</summary>
    public ECardEffectFlag GetEffectFlags()
    {
        ECardEffectFlag flags = ECardEffectFlag.None;
        for (int i = 0; i < Effects.Count; i++)
        {
            CardEffectBase effect = Effects[i];
            if (effect != null)
            {
                flags |= effect.EffectFlag;
            }
        }
        return flags;
    }

    /// <summary>키워드 비트 포함 여부 빠른 조회.</summary>
    public bool HasKeyword(ECardKeyword keyword) => (Keywords & keyword) != 0;
}
