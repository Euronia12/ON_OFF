﻿using System.Collections.Generic;
using UnityEngine;

public sealed class SkillRuntimeData
{
    public int Index { get; }
    public string SkillId { get; }
    public string DisplayNameKey { get; }
    public string DescKey { get; }
    public string DescriptionKey { get; }
    public string DirectionPromptKey { get; }
    public string TargetPromptKey { get; }
    public string IconKey { get; }
    public IReadOnlyList<string> DetailIconKeys { get; }
    public int Cooldown { get; }
    public IReadOnlyList<SkillEffectBase> Effects { get; }

    public SkillRuntimeData(
        int index,
        string skillId,
        string displayNameKey,
        string descKey,
        string descriptionKey,
        string directionPromptKey,
        string targetPromptKey,
        string iconKey,
        IReadOnlyList<string> detailIconKeys,
        int cooldown,
        IReadOnlyList<SkillEffectBase> effects)
    {
        Index = index;
        SkillId = skillId ?? string.Empty;
        DisplayNameKey = displayNameKey ?? string.Empty;
        DescKey = descKey ?? string.Empty;
        DescriptionKey = descriptionKey ?? string.Empty;
        DirectionPromptKey = directionPromptKey ?? string.Empty;
        TargetPromptKey = targetPromptKey ?? string.Empty;
        IconKey = iconKey ?? string.Empty;
        DetailIconKeys = CopyDetailIconKeys(detailIconKeys);
        Cooldown = Mathf.Max(SkillDataSO.CooldownMin, cooldown);
        Effects = effects ?? System.Array.Empty<SkillEffectBase>();
    }

    private static IReadOnlyList<string> CopyDetailIconKeys(IReadOnlyList<string> source)
    {
        if (source == null || source.Count == 0)
            return System.Array.Empty<string>();

        string[] copy = new string[source.Count];
        for (int i = 0; i < source.Count; i++)
            copy[i] = source[i] ?? string.Empty;
        return copy;
    }

    public bool RequiresDirectionSelection
    {
        get
        {
            for (int i = 0; i < Effects.Count; i++)
            {
                if (Effects[i] != null && Effects[i].RequiresDirectionSelection)
                    return true;
            }
            return false;
        }
    }

    public ECardDirection DirectionOptions
    {
        get
        {
            ECardDirection options = ECardDirection.None;
            for (int i = 0; i < Effects.Count; i++)
            {
                if (Effects[i] != null)
                    options |= Effects[i].DirectionOptions;
            }
            return options;
        }
    }
}
