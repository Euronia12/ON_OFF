﻿// =================================================================
// [스크립트 목적]  유저 도메인 데이터 공통 베이스. 더티 콜백 보관 + MarkDirty 제공
// [주요 변수]      - _onDirty : UserManager가 주입한 더티 통지 콜백 (직렬화 제외)
// [의존 관계]      - IUserData 구현. 각 도메인(재화·장비 등)이 이 클래스를 상속
// [설계]           도메인은 자기 필드를 수정한 뒤 MarkDirty()만 부르면 매니저에 자동 통지.
//                  콜백은 [NonSerialized] → 저장 데이터에 포함되지 않음(런타임 배선용).
//                  ResetToDefault는 도메인마다 다르므로 abstract로 강제.
// =================================================================
using System;

[Serializable]
public abstract class UserDataBase : IUserData
{
    // 런타임 배선용 콜백. 저장 대상이 아니므로 직렬화 제외.
    [NonSerialized] private Action _onDirty;

    /// <summary>UserManager가 로드/생성 시 주입. 도메인은 변경 시 MarkDirty로 통지.</summary>
    public void BindDirtyNotifier(Action onDirty) => _onDirty = onDirty;

    /// <summary>
    /// 도메인 내부에서 데이터 변경 후 호출. 주입된 콜백을 통해 매니저에 더티 통지.
    /// 콜백 미주입(테스트 등) 상황에서도 안전하게 null 무시.
    /// </summary>
    protected void MarkDirty() => _onDirty?.Invoke();

    /// <summary>신규 유저 생성 시 기본값 초기화. 도메인별 구현.</summary>
    public abstract void ResetToDefault();
}