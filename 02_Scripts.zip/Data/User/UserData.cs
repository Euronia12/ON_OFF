﻿// =================================================================
// [스크립트 목적]  유저 저장 단위. 도메인 데이터(IUserData)들을 조합 + ISaveData 구현
// [주요 변수]      - _domains : 등록된 도메인 목록 (직렬화 대상 + 순회용)
//                  - _lookup  : Type→도메인 조회 인덱스 (런타임 전용, 직렬화 제외)
// [의존 관계]      - ISaveData (SaveManager가 직렬화), UserDataBase 도메인들
// [설계]           프레임워크는 어떤 도메인이 붙는지 모름(재화·장비는 게임 측 콘텐츠).
//                  저장은 List(다형성 $type 보존). 조회는 Dictionary로 O(1).
//                  로드 시 List만 복원되므로 _lookup은 지연 재구성(EnsureLookup).
//                  Newtonsoft가 다형성(_domains의 실제 타입)을 $type으로 보존.
// =================================================================
using System;
using System.Collections.Generic;
using Newtonsoft.Json;
using UnityEngine;
using UnityEngine.Scripting;

[Serializable, Preserve] // IL2CPP 코드 스트리핑 방지 (Newtonsoft 리플렉션 직렬화)
public class UserData : ISaveData
{
    [SerializeField] private int _version = 1;
    public int Version { get => _version; set => _version = value; }

    // 직렬화 대상. Newtonsoft가 각 요소의 실제 타입을 $type으로 직렬화.
    // [JsonProperty] 필수 — Newtonsoft 기본값은 private 필드를 직렬화하지 않음.
    [JsonProperty]
    private List<UserDataBase> _domains = new();

    // Type→도메인 조회 인덱스. 런타임 전용(직렬화 제외).
    // 로드 시 _domains만 복원되므로 EnsureLookup으로 지연 재구성한다.
    [JsonIgnore, NonSerialized]
    private Dictionary<Type, UserDataBase> _lookup;

    /// <summary>
    /// 조회 인덱스 보장. null이면 _domains로부터 재구성(로드 직후 1회).
    /// 등록/로드 어느 경로든 조회 전에 인덱스가 준비되도록 진입점에서 호출.
    /// 손상된 세이브·수동 편집으로 같은 타입이 중복될 경우 첫 항목만 유지하고
    /// _domains에서 중복을 제거해 List와 lookup을 정합시킨다(좀비 도메인 방지).
    /// </summary>
    private void EnsureLookup()
    {
        if (_lookup != null) return;

        _lookup = new Dictionary<Type, UserDataBase>(_domains.Count);
        for (int i = _domains.Count - 1; i >= 0; i--)
        {
            UserDataBase d = _domains[i];

            // null 항목 제거 (직렬화 누락·손상 대비)
            if (d == null)
            {
                _domains.RemoveAt(i);
                continue;
            }

            Type t = d.GetType();
            if (_lookup.ContainsKey(t))
            {
                // 같은 타입 중복 → 뒤 항목 제거(역순 순회이므로 결과적으로 첫 항목 유지)
                _domains.RemoveAt(i);
                continue;
            }
            _lookup[t] = d;
        }
    }

    /// <summary>
    /// 도메인 등록. 게임 측에서 신규/로드 직후 자기 도메인들을 등록한다.
    /// 이미 같은 타입이 있으면 무시(로드된 데이터 우선 → 신규 인스턴스로 덮어쓰기 방지).
    /// </summary>
    public void RegisterDomain(UserDataBase domain)
    {
        if (domain == null) return;
        EnsureLookup();

        Type t = domain.GetType();
        if (_lookup.ContainsKey(t)) return; // 이미 존재(로드된 것) → 보존

        _domains.Add(domain);
        _lookup[t] = domain;
    }

    /// <summary>타입으로 도메인 조회. 없으면 null. O(1).</summary>
    public T GetDomain<T>() where T : UserDataBase
    {
        EnsureLookup();
        return _lookup.TryGetValue(typeof(T), out var d) ? d as T : null;
    }

    /// <summary>등록된 모든 도메인 순회 (콜백 바인딩·일괄 처리용).</summary>
    public IReadOnlyList<UserDataBase> Domains => _domains;

    /// <summary>모든 도메인에 더티 콜백 주입. UserManager가 로드/생성 시 호출.</summary>
    public void BindAll(Action onDirty)
    {
        for (int i = 0; i < _domains.Count; i++)
            _domains[i].BindDirtyNotifier(onDirty);
    }

    /// <summary>신규 유저: 등록된 모든 도메인을 기본값으로 초기화.</summary>
    public void ResetAllToDefault()
    {
        for (int i = 0; i < _domains.Count; i++)
            _domains[i].ResetToDefault();
    }
}