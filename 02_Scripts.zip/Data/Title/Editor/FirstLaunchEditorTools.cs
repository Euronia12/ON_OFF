// =================================================================
// [스크립트 목적]  최초 실행 튜토리얼 자동 진입 플래그를 에디터에서 확인·초기화하는 도구
// [사용법]         메뉴 Tools ▸ Debug ▸ Reset First Launch Flag / Log First Launch Flag
// [의존 관계]      FirstLaunchStore (Assembly-CSharp)
// [주의]           Editor 폴더 하위이므로 빌드에 포함되지 않는다.
// =================================================================
using UnityEditor;
using UnityEngine;

/// <summary>
/// FirstLaunchStore 플래그의 개발·QA용 조작 메뉴.
/// 초기화하면 다음 Play 가 다시 "최초 실행"으로 판정되어 튜토리얼로 자동 진입한다.
/// </summary>
public static class FirstLaunchEditorTools
{
    [MenuItem("Tools/Debug/Reset First Launch Flag")]
    public static void ResetFirstLaunchFlag()
    {
        FirstLaunchStore.Clear();
        Debug.Log("[FirstLaunch] 플래그 초기화 완료 — 다음 Play 시 튜토리얼로 자동 진입합니다.");
    }

    [MenuItem("Tools/Debug/Log First Launch Flag")]
    public static void LogFirstLaunchFlag()
    {
        Debug.Log($"[FirstLaunch] HasEnteredTutorial = {FirstLaunchStore.HasEnteredTutorial}");
    }
}
