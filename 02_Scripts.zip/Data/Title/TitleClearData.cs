// =================================================================
// [스크립트 목적]  타이틀 배경 분기용 "마지막 최종 클리어 날짜" 영속 데이터
// [주요 변수]      - _lastClearDate : 현지시간 기준 마지막 최종 클리어 날짜 ("yyyy-MM-dd")
//                  - _version       : 저장 포맷 버전 (ISaveData)
// [의존 관계]      - ISaveData (SaveManager 저장 대상 표식)
// [주의]           SaveManager는 순수 Newtonsoft 직렬화 → [SerializeField]가 아니라
//                  public get/set 프로퍼티가 저장 대상. 저장 필드는 반드시 프로퍼티로 노출.
// =================================================================
using System;
using UnityEngine;

/// <summary>
/// 타이틀 배경(클리어 전/후) 판정에 쓰는 최소 저장 데이터.
/// SaveManager 슬롯 "title_clear"에 저장된다.
/// 날짜를 로컬 날짜 문자열로 보관 → 타임존/DST 재구성 없이 "같은 날" 판정을 문자열 비교로 처리.
/// </summary>
[Serializable]
public class TitleClearData : ISaveData
{
    // Newtonsoft가 직렬화하는 것은 아래 public 프로퍼티다. [SerializeField]는 인스펙터 표기용.
    [SerializeField] private int _version = 1;
    [SerializeField] private string _lastClearDate = "";

    public int Version
    {
        get => _version;
        set => _version = value;
    }

    /// <summary>현지시간 기준 마지막 최종 클리어 날짜("yyyy-MM-dd"). 빈 문자열이면 기록 없음.</summary>
    public string LastClearDate
    {
        get => _lastClearDate;
        set => _lastClearDate = value;
    }
}
