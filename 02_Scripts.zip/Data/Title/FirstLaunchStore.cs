// =================================================================
// [스크립트 목적]  최초 실행 시 튜토리얼 자동 진입 판정용 플래그 저장/조회 헬퍼
// [의존 관계]      - PlayerPrefs (기기 로컬 저장)
// [설계]           읽는 곳(타이틀)·쓰는 곳(최초 튜토리얼 시작 패널)이 각 한 곳뿐이라 매니저 대신
//                  상태 없는 정적 헬퍼(TitleClearStore 와 동일 패턴).
//                  진실 원천은 PlayerPrefs 하나뿐이며 키는 이 파일에서만 정의한다.
// [PlayerPrefs 사유] 세이브 슬롯 삭제·런 세이브 초기화와 무관하게 "이 기기에서 튜토리얼을
//                  봤는가"가 유지되어야 하고, 값이 bool 하나라 SaveManager(AES+JSON)는 과하다.
// =================================================================
using UnityEngine;

/// <summary>
/// "튜토리얼에 한 번이라도 진입했는가" 플래그의 저장·조회 진입점.
/// 기록 시점은 최초 튜토리얼 시작 패널의 버튼 클릭 직후다.
/// 버튼을 누르기 전에 종료하면 다음 실행에서도 최초 튜토리얼로 다시 진입한다.
/// </summary>
public static class FirstLaunchStore
{
    // LoggingContext 의 "onoff_device_id" 관례를 따른 키 네이밍
    private const string TUTORIAL_ENTERED_KEY = "onoff_tutorial_entered";

    /// <summary>튜토리얼에 한 번이라도 진입한 적이 있는지. false면 최초 실행으로 간주한다.</summary>
    public static bool HasEnteredTutorial => PlayerPrefs.GetInt(TUTORIAL_ENTERED_KEY, 0) != 0;

    /// <summary>
    /// 튜토리얼 진입을 기록. 최초 튜토리얼 시작 버튼 클릭 직후 호출한다.
    /// 앱이 강제 종료돼도 남도록 즉시 Save() 한다.
    /// </summary>
    public static void MarkTutorialEntered()
    {
        if (HasEnteredTutorial)
            return;

        PlayerPrefs.SetInt(TUTORIAL_ENTERED_KEY, 1);
        PlayerPrefs.Save();
    }

    /// <summary>플래그 초기화 (개발·QA용). 다음 실행이 다시 최초 실행으로 판정된다.</summary>
    public static void Clear()
    {
        PlayerPrefs.DeleteKey(TUTORIAL_ENTERED_KEY);
        PlayerPrefs.Save();
    }
}
