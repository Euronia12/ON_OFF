// =================================================================
// [스크립트 목적]  타이틀 배경 분기용 "오늘 최종 클리어했는가" 저장/판정 헬퍼
// [의존 관계]      - SaveManager(슬롯 "title_clear" 로드/저장), TitleClearData
// [설계]           읽는 곳(타이틀)·쓰는 곳(클리어)이 각 한 곳뿐이라 매니저 대신 상태 없는
//                  정적 헬퍼(RunSaveSystem 과 동일 패턴). 진실 원천은 디스크(SaveManager) 하나뿐.
// =================================================================
using System;
using System.Globalization;
using System.Threading;
using Cysharp.Threading.Tasks;

/// <summary>
/// 타이틀 배경(클리어 전/후) 상태의 저장·조회 진입점.
/// 판정 규칙: 저장된 마지막 클리어 날짜(로컬) == 오늘(로컬) 이면 "오늘 클리어".
/// 상태를 보관하지 않고 매 호출 SaveManager(디스크)만 참조한다.
/// </summary>
public static class TitleClearStore
{
    private const string SLOT = "title_clear";

    /// <summary>현지시간 기준 오늘 날짜 문자열. InvariantCulture로 로케일 달력 영향 배제.</summary>
    private static string TodayLocal()
        => DateTime.Now.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture);

    /// <summary>
    /// 오늘(로컬) 최종 클리어 기록이 있는지. 타이틀 배경 A/B 판정용.
    /// </summary>
    public static async UniTask<bool> IsClearedTodayAsync(CancellationToken token = default)
    {
        TitleClearData data = await SaveManager.Instance.LoadAsync<TitleClearData>(SLOT, token);
        return data != null && data.LastClearDate == TodayLocal();
    }

    /// <summary>
    /// 오늘(로컬)을 최종 클리어 날짜로 기록. 클리어 시점에 호출(fire-forget 허용).
    /// 이미 오늘로 기록되어 있으면 디스크 쓰기를 건너뛴다(중복 저장 방지).
    /// </summary>
    public static async UniTask RecordTodayAsync(CancellationToken token = default)
    {
        string today = TodayLocal();

        TitleClearData data = await SaveManager.Instance.LoadAsync<TitleClearData>(SLOT, token)
                              ?? new TitleClearData();
        if (data.LastClearDate == today)
            return;

        data.LastClearDate = today;
        await SaveManager.Instance.SaveAsync(SLOT, data, token); // 실패 로깅은 SaveManager가 담당
    }
}
