// =================================================================
// [스크립트 목적]  적 정의 ScriptableObject. 체력 + 의도(Intent) 패턴 데이터화.
//                 하드코딩 int[] 의도를 데이터로 분리 → 적 추가가 에셋 작업만으로 가능.
// [주요 변수]      - _maxHp        : 적 최대 체력
//                  - _intentPattern: 턴별 의도 큐 (순환)
//                  - _displayNameKey/_prefabKey : 표시·비주얼 연결 키
// [의존 관계]      - EnemyActor 가 이 데이터로 생성됨
//                  - EEnemyIntentType (BattleEnums)
// [설계 노트]      - 의도는 (타입 + 수치 + 히트). 한 턴에 여러 의도 묶음(공+방 동시) 가능
//                  - 비주얼(prefabKey)은 3단계 View/투사체에서 사용
// =================================================================

using System;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// 의도 1개. 타입(공격/방어/설치)과 수치를 묶는다. 한 턴에 여러 개가 묶일 수 있다(EnemyIntentTurn).
/// 플레이어에게 다음 행동을 예고(Intent UI)하는 데이터이자, 실제 행동의 근거.
/// </summary>
[Serializable]
public struct EnemyIntent
{
    [Tooltip("의도 종류 (공격/방어/설치)")]
    public EEnemyIntentType Type;

    [Tooltip("의도 수치. 공격=히트당 피해량 / 방어=방어막량 / 설치=개수 / 선형 그리드 공격=미사용")]
    [Min(0)]
    public int Amount;

    [Tooltip("다단 히트 횟수 (공격 전용). 0 또는 1=단일 타격, 2 이상=연타. 비공격은 무시")]
    [Min(0)]
    public int Hits;

    /// <summary>실제 히트 수 (0/1 모두 1로 보정). 표시·실행 공용.</summary>
    public int EffectiveHits => Hits > 1 ? Hits : 1;
}

/// <summary>
/// 적 한 턴에 동시에 수행하는 의도 묶음 (예: 공격 + 방어 동시).
/// Unity 직렬화가 2차원 배열을 못 다루므로 한 겹 래핑한다.
/// </summary>
[Serializable]
public struct EnemyIntentTurn
{
    [Tooltip("이 턴에 수행할 의도들. 위에서부터 순서대로 실행/표시")]
    public EnemyIntent[] Intents;

    /// <summary>의도 개수 (null 안전).</summary>
    public int Count => Intents != null ? Intents.Length : 0;
}

/// <summary>적 대사 출력 시점.</summary>
public enum EEnemySpeechTrigger
{
    /// <summary>전투 진입 시 1회.</summary>
    BattleStart = 0,

    /// <summary>지정 의도 순번 실행 직전.</summary>
    BeforeIntentOrder = 1,

    /// <summary>지정 적 행동 턴 실행 직전.</summary>
    BeforeEnemyTurn = 2,
}

/// <summary>적 대사 1개. Trigger 에 따라 OrderOrTurn 값을 의도 순번 또는 적 행동 턴으로 해석한다.</summary>
[Serializable]
public struct EnemySpeechLine
{
    [Tooltip("대사 출력 시점")]
    public EEnemySpeechTrigger Trigger;

    [Tooltip("의도 순번 또는 적 행동 턴. 전투 진입 대사는 사용하지 않음")]
    [Min(0)]
    public int OrderOrTurn;

    [Tooltip("말풍선에 표시할 대사. 비우면 출력하지 않음")]
    [TextArea(2, 4)]
    public string Text;

    [Tooltip("말풍선 표시 시간(초). 0 이하면 기본값 사용")]
    [Min(0f)]
    public float Duration;
}

/// <summary>
/// 일반/엘리트 적의 등장 난이도 티어. 슬더스의 easy/hard 풀에 대응.
/// 맵 앞쪽(얕은 depth)은 Easy 풀에서, 뒤쪽은 Hard 풀에서 추첨한다.
/// 등급(EEnemyGrade)과 직교하는 개념 — Boss/Test 는 티어를 사용하지 않는다.
/// </summary>
public enum EEncounterTier
{
    /// <summary>약한 적. 맵 초반(얕은 depth)에 등장.</summary>
    Easy = 0,

    /// <summary>강한 적. 맵 후반(깊은 depth)에 등장.</summary>
    Hard = 1,
}

/// <summary>보스의 2페이즈 이후 데이터. 1페이즈는 EnemyDataSO 기존 필드를 그대로 사용한다.</summary>
[Serializable]
public sealed class BossPhaseData
{
    [Tooltip("이 페이즈의 최대 체력")]
    [Min(1)]
    [SerializeField] private int _maxHp = 30;

    [Tooltip("이 페이즈의 턴별 의도 묶음 큐. 끝나면 처음부터 순환")]
    [SerializeField] private EnemyIntentTurn[] _intentPattern = Array.Empty<EnemyIntentTurn>();

    [Tooltip("이 페이즈 전환 흡수 연출 시작 시 재생할 SFX Addressable 키. 비우면 재생하지 않음")]
    [SerializeField] private string _absorbSfxKey;

    [Tooltip("이 페이즈의 적 비주얼 프리팹 Addressable 키. 비우면 1페이즈 비주얼 유지")]
    [SerializeField] private string _viewPrefabKey;

    public int MaxHp => Mathf.Max(1, _maxHp);
    public int IntentCount => _intentPattern != null ? _intentPattern.Length : 0;
    public string AbsorbSfxKey => _absorbSfxKey;
    public string ViewPrefabKey => _viewPrefabKey;

    public EnemyIntentTurn GetIntentTurn(int index)
    {
        if (_intentPattern == null || _intentPattern.Length == 0)
        {
            return new EnemyIntentTurn { Intents = Array.Empty<EnemyIntent>() };
        }

        index = Mathf.Clamp(index, 0, _intentPattern.Length - 1);
        return _intentPattern[index];
    }
}

/// <summary>
/// 적 1종의 정의 데이터. 체력과 의도 패턴(순환 큐)을 보유한다.
/// 적을 추가할 때 이 SO 에셋만 만들면 되도록 하드코딩을 배제한다.
/// </summary>
[CreateAssetMenu(fileName = "EnemyData", menuName = "Game/Enemy Data", order = 0)]
public sealed class EnemyDataSO : ScriptableObject
{
    [Header("식별")]
    [Tooltip("적 식별 ID (로그·조회용)")]
    [SerializeField] private string _enemyId = "enemy_dummy";

    [Tooltip("표시 이름 로컬라이즈 키 (비우면 ID 사용)")]
    [SerializeField] private string _displayNameKey;

    [Header("분류")]
    [Tooltip("적 등급. 노드 타입(Battle/Elite/Boss/Test)별 적 풀 추첨에 사용")]
    [SerializeField] private EEnemyGrade _grade = EEnemyGrade.Normal;

    [Tooltip("등장 난이도 티어(일반/엘리트 적). 맵 앞=Easy, 뒤=Hard 풀. Boss/Test는 무시")]
    [SerializeField] private EEncounterTier _encounterTier = EEncounterTier.Easy;

    [Header("스탯")]
    [Tooltip("적 최대 체력")]
    [Min(1)]
    [SerializeField] private int _maxHp = 30;

    [Header("의도 패턴")]
    [Tooltip("턴별 의도 묶음 큐. 한 턴에 여러 의도(공+방 등) 가능. 끝나면 처음부터 순환")]
    [SerializeField]
    private EnemyIntentTurn[] _intentPattern = new EnemyIntentTurn[]
    {
        new EnemyIntentTurn
        {
            Intents = new EnemyIntent[]
            {
                new EnemyIntent { Type = EEnemyIntentType.Attack, Amount = 5, Hits = 1 },
                new EnemyIntent { Type = EEnemyIntentType.Defend, Amount = 5 },
            },
        },
    };

    [Header("대사")]
    [Tooltip("전투 진입, 특정 의도 순번 실행 전, 특정 적 행동 턴 실행 전에 출력할 대사")]
    [SerializeField] private EnemySpeechLine[] _speechLines;

    [Header("비주얼 (3단계 연결)")]
    [Tooltip("적 비주얼 프리팹 Addressable 키 (EnemyView). 비우면 비주얼 없음")]
    [SerializeField] private string _viewPrefabKey;

    [Header("보스 추가 페이즈")]
    [Tooltip("2페이즈부터 순서대로 설정. Boss 등급에서만 사용하며 비어 있으면 기존 1페이즈 동작")]
    [SerializeField] private BossPhaseData[] _additionalBossPhases = Array.Empty<BossPhaseData>();

    public string EnemyId => _enemyId;
    public EEnemyGrade Grade => _grade;

    /// <summary>등장 난이도 티어 (일반/엘리트 적 추첨용). Boss/Test 추첨에선 사용하지 않음.</summary>
    public EEncounterTier EncounterTier => _encounterTier;
    public string DisplayNameKey => string.IsNullOrEmpty(_displayNameKey) ? _enemyId : _displayNameKey;
    public int MaxHp => _maxHp;
    public string ViewPrefabKey => _viewPrefabKey;
    public int PhaseCount => _grade == EEnemyGrade.Boss
        ? 1 + (_additionalBossPhases != null ? _additionalBossPhases.Length : 0)
        : 1;

    /// <summary>의도 패턴 (읽기 전용). 비어있으면 길이 0.</summary>
    public IReadOnlyList<EnemyIntentTurn> IntentPattern => _intentPattern;

    /// <summary>적 대사집 (읽기 전용). 비어있으면 대사 없음.</summary>
    public IReadOnlyList<EnemySpeechLine> SpeechLines => _speechLines;

    /// <summary>의도 패턴 길이(턴 수). 0이면 의도 없음(무행동).</summary>
    public int IntentCount => _intentPattern != null ? _intentPattern.Length : 0;

    /// <summary>index 위치의 의도 묶음 반환 (순환은 호출부 책임). 범위 밖/비어있으면 빈 턴.</summary>
    public EnemyIntentTurn GetIntentTurn(int index)
    {
        if (_intentPattern == null || _intentPattern.Length == 0)
        {
            return new EnemyIntentTurn { Intents = Array.Empty<EnemyIntent>() };
        }
        index = Mathf.Clamp(index, 0, _intentPattern.Length - 1);
        return _intentPattern[index];
    }

    public int GetPhaseMaxHp(int phaseIndex)
    {
        BossPhaseData phase = GetAdditionalPhase(phaseIndex);
        return phase != null ? phase.MaxHp : Mathf.Max(1, _maxHp);
    }

    public int GetPhaseIntentCount(int phaseIndex)
    {
        BossPhaseData phase = GetAdditionalPhase(phaseIndex);
        return phase != null ? phase.IntentCount : IntentCount;
    }

    public EnemyIntentTurn GetPhaseIntentTurn(int phaseIndex, int intentIndex)
    {
        BossPhaseData phase = GetAdditionalPhase(phaseIndex);
        return phase != null ? phase.GetIntentTurn(intentIndex) : GetIntentTurn(intentIndex);
    }

    public string GetPhaseViewPrefabKey(int phaseIndex)
    {
        BossPhaseData phase = GetAdditionalPhase(phaseIndex);
        return phase != null && !string.IsNullOrWhiteSpace(phase.ViewPrefabKey)
            ? phase.ViewPrefabKey
            : _viewPrefabKey;
    }

    /// <summary>지정 추가 페이즈의 흡수 연출 SFX 키. 미지정이면 null.</summary>
    public string GetPhaseAbsorbSfxKey(int phaseIndex)
    {
        if (phaseIndex <= 0) return null;

        BossPhaseData phase = GetAdditionalPhase(phaseIndex);
        return phase != null && !string.IsNullOrWhiteSpace(phase.AbsorbSfxKey)
            ? phase.AbsorbSfxKey
            : null;
    }

    public bool TryGetBattleStartSpeech(out EnemySpeechLine speech)
    {
        return TryGetSpeech(EEnemySpeechTrigger.BattleStart, 0, out speech);
    }

    public bool TryGetBeforeEnemyActionSpeech(int enemyTurn, int intentOrder, out EnemySpeechLine speech)
    {
        // 같은 시점에 둘 다 있으면 더 구체적인 의도 순번 대사를 우선한다.
        if (TryGetSpeech(EEnemySpeechTrigger.BeforeIntentOrder, intentOrder, out speech))
        {
            return true;
        }
        return TryGetSpeech(EEnemySpeechTrigger.BeforeEnemyTurn, enemyTurn, out speech);
    }

    private bool TryGetSpeech(EEnemySpeechTrigger trigger, int orderOrTurn, out EnemySpeechLine speech)
    {
        if (_speechLines != null)
        {
            for (int i = 0; i < _speechLines.Length; i++)
            {
                EnemySpeechLine candidate = _speechLines[i];
                if (candidate.Trigger != trigger) continue;
                if (trigger != EEnemySpeechTrigger.BattleStart && candidate.OrderOrTurn != orderOrTurn) continue;
                if (string.IsNullOrWhiteSpace(candidate.Text)) continue;

                speech = candidate;
                return true;
            }
        }

        speech = default;
        return false;
    }

    private BossPhaseData GetAdditionalPhase(int phaseIndex)
    {
        if (_grade != EEnemyGrade.Boss || phaseIndex <= 0 || _additionalBossPhases == null)
        {
            return null;
        }

        int additionalIndex = phaseIndex - 1;
        return additionalIndex < _additionalBossPhases.Length
            ? _additionalBossPhases[additionalIndex]
            : null;
    }
}
