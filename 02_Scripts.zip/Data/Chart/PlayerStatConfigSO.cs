// =================================================================
// [스크립트 목적]  플레이어 시작 기본 스탯(밸런스 수치)의 단일 소유처.
//                 InGameController(런 초기화)와 BattleController(비런 전투 폴백)가 공유 참조한다.
// [설계 노트]      - 읽기 전용 설정. 런타임 가변 상태는 RunContext 가 보유(여기는 절대 수정 안 함).
//                    같은 에셋 1개를 두 컨트롤러 인스펙터에 물려 값 원천을 일원화한다.
// =================================================================

using UnityEngine;

[CreateAssetMenu(fileName = "PlayerStatConfig", menuName = "Game/Player Stat Config", order = 0)]
public sealed class PlayerStatConfigSO : ScriptableObject
{
    [Header("체력")]
    [Tooltip("런 시작 최대 체력(전투 간 유지되는 런 HP).")]
    [Min(1)] [SerializeField] private int _maxHp = 50;

    [Header("자원")]
    [Tooltip("런 시작 최대 마나 (= 전투 최대 에너지).")]
    [Min(0)] [SerializeField] private int _maxMana = 3;

    [Tooltip("턴 시작 드로우 장수.")]
    [Min(1)] [SerializeField] private int _drawPerTurn = 5;

    [Tooltip("손에 들 수 있는 최대 카드 수. 손패가 이 수치면 드로우한 카드는 손에 들어오지 못하고 묘지로 갑니다.")]
    [Min(1)] [SerializeField] private int _maxHandSize = 10;

    [Header("보존")]
    [Tooltip("턴 종료 시 수동 보존 가능한 카드 수.")]
    [Min(0)] [SerializeField] private int _maxPreserveCount = 3;

    [Tooltip("켜면 턴 종료 시 그리드 카드를 전부 유지하고 보존 선택 페이즈를 건너뜁니다.")]
    [SerializeField] private bool _preserveAll = false;

    public int MaxHp => _maxHp;
    public int MaxMana => _maxMana;
    public int DrawPerTurn => _drawPerTurn;
    public int MaxHandSize => _maxHandSize;
    public int MaxPreserveCount => _maxPreserveCount;
    public bool PreserveAll => _preserveAll;
}
