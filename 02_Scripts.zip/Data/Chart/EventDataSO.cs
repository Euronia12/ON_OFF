// =================================================================
// [스크립트 목적]  전역 Event 후보 데이터. Choice 는 단일 UIChoiceEvent 를 데이터 구동하고,
//                 GridPuzzle 은 기존 PrefabKey 프리팹 경로로 실행한다.
// =================================================================

using System.Collections.Generic;
using UnityEngine;

/// <summary>이벤트 실행 방식. Choice=단일 프리팹+SO 데이터 구동, GridPuzzle=전용 프리팹 경로.</summary>
public enum EEventType
{
    Choice = 0,
    GridPuzzle = 1,
}

[CreateAssetMenu(fileName = "EventData", menuName = "Game/Event Data", order = 1)]
public sealed class EventDataSO : ScriptableObject
{
    [Header("식별")]
    [SerializeField] private string _eventId;
    [SerializeField] private bool _enabled = true;
    [Tooltip("Choice=단일 UIChoiceEvent 데이터 구동, GridPuzzle=PrefabKey 프리팹 실행")]
    [SerializeField] private EEventType _type = EEventType.Choice;

    [Header("GridPuzzle 전용")]
    [Tooltip("GridPuzzle 유형에서 열 프리팹 Addressable 키. Choice 는 사용 안 함.")]
    [SerializeField] private string _prefabKey;

    [Header("Choice 데이터")]
    [Tooltip("이벤트 제목 번역 키")]
    [SerializeField] private string _titleKey;
    [Tooltip("이벤트 설명 번역 키")]
    [SerializeField] private string _descKey;
    [Tooltip("이벤트 이미지 Addressable 키(선택). 확장자 뺀 파일명. 없으면 이미지 숨김")]
    [SerializeField] private string _imageKey;
    [SerializeField] private List<EventChoiceData> _choices = new();

    [Header("랜덤")]
    [Tooltip("ON이면 런 시드로 최초 결과를 재현합니다. OFF이면 최초 조우 때 새 난수를 사용합니다. 한번 확정된 결과는 양쪽 모두 저장됩니다.")]
    [SerializeField] private bool _useSeededRandom = true;

    [Header("등장 규칙")]
    [Tooltip("이 이벤트가 등장 가능한 최소 스테이지(1-based). 0 이면 하한 없음.")]
    [Min(0)] [SerializeField] private int _minStage;
    [Tooltip("이 이벤트가 등장 가능한 최대 스테이지(1-based). 0 이면 상한 없음.")]
    [Min(0)] [SerializeField] private int _maxStage;
    [Tooltip("추첨 가중치. 값이 클수록 자주 등장. 0 이하면 후보에서 제외.")]
    [Min(0f)] [SerializeField] private float _weight = 1f;

    [Header("선행 조건 (2단 연쇄)")]
    [Tooltip("이 이벤트가 등장하려면 먼저 골라야 하는 선행 이벤트의 EventId. 비우면 조건 없음")]
    [SerializeField] private string _requiredEventId;
    [Tooltip("선행 이벤트에서 골라야 하는 선택지 번호(0-based). -1 이면 선택지 무관")]
    [SerializeField] private int _requiredChoiceIndex = -1;
    [Tooltip("[호환용] 현재 일반 맵 이벤트는 모두 런 내 중복 없이 배정되므로 이 값과 관계없이 실제 조우 후 재등장하지 않는다")]
    [SerializeField] private bool _uniquePerRun;

    public string EventId => _eventId;
    public bool Enabled => _enabled;
    public EEventType Type => _type;
    public string PrefabKey => _prefabKey;
    public string TitleKey => _titleKey;
    public string DescKey => _descKey;
    public string ImageKey => _imageKey;
    public IReadOnlyList<EventChoiceData> Choices => _choices;
    public bool UseSeededRandom => _useSeededRandom;
    public int MinStage => _minStage;
    public int MaxStage => _maxStage;
    public float Weight => _weight;

    public string RequiredEventId => _requiredEventId;
    public int RequiredChoiceIndex => _requiredChoiceIndex;

    /// <summary>선행 조건이 걸린 후속 이벤트인지.</summary>
    public bool HasPrerequisite => !string.IsNullOrWhiteSpace(_requiredEventId);

    /// <summary>호환용 런당 1회 설정. 현재 일반 맵 배정은 모든 이벤트를 중복 제외한다.</summary>
    public bool UniquePerRun => _uniquePerRun || HasPrerequisite;

    /// <summary>현재 스테이지(1-based)에서 이 이벤트가 등장 가능한지.</summary>
    public bool IsStageAllowed(int stage)
        => (_minStage <= 0 || stage >= _minStage) && (_maxStage <= 0 || stage <= _maxStage);

    /// <summary>
    /// 선행 조건 충족 여부. 조건이 없으면 항상 true.
    /// 판정 근거는 "실제로 고른 선택지" 기록이다 — 맵 배치 이력(HasEncounteredEvent)으로 판정하면
    /// 선행 이벤트를 지나치기만 해도 후속이 등장해버린다.
    /// </summary>
    public bool IsPrerequisiteMet(RunContext run)
        => !HasPrerequisite ||
           (run != null && run.HasEventChoice(_requiredEventId, _requiredChoiceIndex));

    /// <summary>뷰 주입용 경계 POCO 생성(SO 격리). 이미지는 컨트롤러가 키로 로드해 주입.</summary>
    public EventViewData ToViewData(Sprite image)
        => new EventViewData(_eventId, _titleKey, _descKey, image, _choices, _useSeededRandom);
}
