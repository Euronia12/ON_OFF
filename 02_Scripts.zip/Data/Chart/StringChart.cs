// =================================================================
// [스크립트 목적]  다국어 시트 한 행을 담는 런타임 데이터 클래스 (POCO).
//                 DataManager가 StringChart.csv를 자동 파싱해 이 타입으로 등록한다.
// [주요 변수]      - Id   : 로컬라이즈 키 (시트 Id 컬럼, DataManager의 식별자로도 사용)
//                  - KOR~CHT : 언어별 번역 텍스트 (시트 가로 컬럼 = public 필드 1:1 매핑)
// [의존 관계]      - DataManager(CSV 자동 파싱·등록), LocalizationManager(테이블 캐싱 시 소비)
// [주의]           public 필드는 DataParser 리플렉션 매핑 규칙(컬럼명=필드명) 때문에 필수.
//                  프레임워크 일반 규칙(public field 금지)의 예외 — 시트 자동매핑 전용 DTO.
// =================================================================
using System.Collections.Generic;
using UnityEngine;

// 다국어 CSV 한 행 = StringChart 인스턴스 1개.
// 시트 헤더(Key/KOR/ENG/JPN/CHS/CHT)와 필드명이 정확히 일치해야 DataParser가 자동 매핑한다.
[System.Serializable]
[GameData]
public class StringChart
{
    // 시트 컬럼명과 1:1로 맞춘 public 필드 (DataParser 자동 매핑용)
    // Id : 로컬라이즈 키 겸 DataManager의 식별자 컬럼 (DataManager._idKey 기본값 'Id'와 정합)
    public string Id;
    public string KOR;
    public string ENG;
    public string JPN;
    public string CHS;
    public string CHT;
    public string DEU;

    // 컬럼 ↔ SystemLanguage 매핑 테이블 (정적 1회 구성 → 캐싱).
    // 언어 추가 시 여기 + StringChart 필드 + 시트 컬럼만 늘리면 됨.
    private static readonly (string Column, SystemLanguage Language)[] LanguageColumns =
    {
        ("KOR", SystemLanguage.Korean),
        ("ENG", SystemLanguage.English),
        ("JPN", SystemLanguage.Japanese),
        ("CHS", SystemLanguage.ChineseSimplified),
        ("CHT", SystemLanguage.ChineseTraditional),
        ("DEU", SystemLanguage.German),
    };

    /// <summary>
    /// 이 행을 (언어 → 텍스트) 딕셔너리로 변환.
    /// LocalizationManager가 테이블 캐싱 시 1회 호출. 빈 번역은 등록하지 않음.
    /// </summary>
    public Dictionary<SystemLanguage, string> ToLanguageMap()
    {
        var map = new Dictionary<SystemLanguage, string>(LanguageColumns.Length);

        for (int i = 0; i < LanguageColumns.Length; i++)
        {
            string text = GetColumnValue(LanguageColumns[i].Column);
            if (!string.IsNullOrEmpty(text))
                map[LanguageColumns[i].Language] = text;
        }
        return map;
    }

    // 컬럼명 → 해당 필드값 반환 (리플렉션 없이 직접 분기 → GC·박싱 없음)
    private string GetColumnValue(string column)
    {
        switch (column)
        {
            case "KOR": return KOR;
            case "ENG": return ENG;
            case "JPN": return JPN;
            case "CHS": return CHS;
            case "CHT": return CHT;
            case "DEU": return DEU;
            default: return null;
        }
    }
}
