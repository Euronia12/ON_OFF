using System.Collections.Generic;
using UnityEngine;

/// <summary>Start 노드에서 선택할 카드팩의 표시와 포함 카드를 정의한다.</summary>
[CreateAssetMenu(fileName = "StartCardPack_", menuName = "Card/Start Card Pack")]
public sealed class StartCardPackSO : ScriptableObject
{
    [Header("식별")]
    [Tooltip("분석 이벤트에 쓰이는 고유 ID. 영문·숫자·언더바만 사용 (예: pack_aggro).\n" +
             "비워두면 에셋 이름을 대신 쓰지만, 에셋 이름을 바꾸면 과거 로그와 연결이 끊긴다")]
    [SerializeField] private string _packId;

    [Space]
    [Header("해금")]
    [Tooltip("현재 카드팩 해금 여부")]
    [SerializeField] private bool _isUnlocked = true;

    [Tooltip("잠금 상태에서 표시할 해금 조건 설명 다국어 키")]
    [SerializeField] private string _unlockDescriptionKey;

    [Tooltip("카드팩 설명 다국어 키")]
    [SerializeField] private string _descriptionKey;

    [Tooltip("공용 선택 아이템 안에 생성할 UI 전용 프리팹(RectTransform 루트)")]
    [SerializeField] private GameObject _visualPrefab;

    [Tooltip("선택 확정 시 지급할 카드 후보")]
    [SerializeField] private List<CardDataSO> _cards = new List<CardDataSO>();

    [Header("지급")]
    [Tooltip("0이면 후보 카드를 모두 지급하고, 1 이상이면 후보에서 비복원 무작위로 이 수만큼 지급")]
    [SerializeField, Min(0)] private int _randomPickCount;

    [Header("등급 가중치")]
    [Tooltip("활성화하면 이 카드팩의 무작위 지급에 아래 등급별 상대 가중치를 사용")]
    [SerializeField] private bool _useRarityWeights;

    [Tooltip("Common 등급의 상대 가중치")]
    [SerializeField, Min(0f)] private float _commonWeight = 70f;

    [Tooltip("Rare 등급의 상대 가중치")]
    [SerializeField, Min(0f)] private float _rareWeight = 24f;

    [Tooltip("Unique 등급의 상대 가중치")]
    [SerializeField, Min(0f)] private float _uniqueWeight = 5f;

    [Tooltip("Legendary 등급의 상대 가중치")]
    [SerializeField, Min(0f)] private float _legendaryWeight = 1f;

    /// <summary>분석용 고유 ID. 미설정 시 에셋 이름으로 폴백한다(로그가 비는 것보다 낫다).</summary>
    public string PackId => string.IsNullOrEmpty(_packId) ? name : _packId;

    public bool IsUnlocked => _isUnlocked;
    public string UnlockDescriptionKey => _unlockDescriptionKey;
    public string DescriptionKey => _descriptionKey;
    public GameObject VisualPrefab => _visualPrefab;
    public IReadOnlyList<CardDataSO> Cards => _cards;
    public int RandomPickCount => _randomPickCount;
    public bool UseRarityWeights => _useRarityWeights;

    public float GetRarityWeight(ECardRarity rarity)
    {
        return rarity switch
        {
            ECardRarity.Rare => _rareWeight,
            ECardRarity.Unique => _uniqueWeight,
            ECardRarity.Legendary => _legendaryWeight,
            _ => _commonWeight,
        };
    }
}
