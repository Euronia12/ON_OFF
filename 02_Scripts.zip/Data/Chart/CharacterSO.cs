// =================================================================
// [스크립트 목적]  플레이 가능한 캐릭터 1종의 정적 데이터 (SO 에셋).
//                  덱 타입(EStartingDeck) + 스킬 목록(SkillDataSO 1~3개) 을 묶는다.
// [주요 변수]      - _deckType : 이 캐릭터가 사용할 시작 덱 (기존 StartingDeckSO 와 매칭)
//                  - _skills   : 이 캐릭터 스킬 목록. 1개=단일, 3개=off+회전+방향 동시 사용
// [의존 관계]      - EStartingDeck / SkillDataSO
//                  - UIWindowDeckSelect 가 목록 표시·선택, InGameController 가 런 상태로 보관
// [설계 노트]      - "스킬 타입"(off/회전/방향) 은 별도 enum 없이 각 스킬의 Effects 에서 파생한다
//                    (SkillDataSO.RequiresDirectionSelection / DirectionOptions). 단일 소스 유지.
//                  - 3-스킬 캐릭터는 off/회전/방향 각 1개(타입 중복 없음)를 전제로 한다.
// =================================================================

using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// 플레이 가능한 캐릭터 1종의 정적 정의.
/// 덱 타입으로 기존 시작 덱 빌드 경로(StartingDeckProvider)를 재사용하고,
/// 스킬 목록(1~3개)으로 전투 스킬 패널 구성을 결정한다.
/// </summary>
[CreateAssetMenu(fileName = "Character_", menuName = "Character/CharacterData")]
public sealed class CharacterSO : ScriptableObject
{
    [Header("식별")]
    [Tooltip("선택창 정렬 순서. 작을수록 좌측(앞)에 표시")]
    [SerializeField] private int _index;

    [Tooltip("캐릭터 고유 ID (로그/디버그용)")]
    [SerializeField] private string _characterId;

    [Tooltip("표시 이름 로컬라이징 키")]
    [SerializeField] private string _displayNameKey;

    [Tooltip("설명 로컬라이징 키")]
    [SerializeField] private string _descKey;

    [Header("구성")]
    [Tooltip("이 캐릭터가 사용할 시작 덱 종류. 기존 StartingDeckSO 의 DeckType 과 일치해야 함")]
    [SerializeField] private EStartingDeck _deckType = EStartingDeck.None;

    [Tooltip("이 캐릭터 스킬 목록. 1개=단일 스킬, 3개=off+회전+방향 동시 사용. 효과 구성으로 타입이 결정됨")]
    [SerializeField] private List<SkillDataSO> _skills = new List<SkillDataSO>();

    [Header("표시")]
    [Tooltip("선택 화면 초상화 리소스 키")]
    [SerializeField] private string _portraitKey;

    /// <summary>선택창 정렬 순서 (작을수록 앞).</summary>
    public int Index => _index;

    /// <summary>캐릭터 고유 ID.</summary>
    public string CharacterId => _characterId;

    /// <summary>표시 이름 로컬라이징 키.</summary>
    public string DisplayNameKey => _displayNameKey;

    /// <summary>설명 로컬라이징 키.</summary>
    public string DescKey => _descKey;

    /// <summary>이 캐릭터가 사용할 시작 덱 종류.</summary>
    public EStartingDeck DeckType => _deckType;

    /// <summary>이 캐릭터 스킬 목록 (1~3개).</summary>
    public IReadOnlyList<SkillDataSO> Skills => _skills;

    /// <summary>스킬을 2개 이상 보유하는 3-스킬 캐릭터인지.</summary>
    public bool IsMultiSkill => _skills != null && _skills.Count > 1;

    /// <summary>선택 화면 초상화 리소스 키.</summary>
    public string PortraitKey => _portraitKey;
}
