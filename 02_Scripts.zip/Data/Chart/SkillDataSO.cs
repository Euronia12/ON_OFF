﻿using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "Skill_", menuName = "Skill/SkillData")]
public sealed class SkillDataSO : ScriptableObject
{
    [Header("기본 정보")]
    [SerializeField] private int _index;
    [SerializeField] private string _skillId;
    [SerializeField] private string _displayNameKey;
    [SerializeField] private string _descKey;
    [SerializeField] private string _descriptionKey;

    [Header("선택 안내")]
    [Tooltip("방향 선택이 필요한 스킬의 1차 선택 안내 번역 ID")]
    [SerializeField] private string _directionPromptKey;

    [Tooltip("그리드 카드 타겟팅 단계의 안내 번역 ID")]
    [SerializeField] private string _targetPromptKey;

    [Header("아이콘")]
    [SerializeField] private string _iconKey;
    [SerializeField] private List<string> _detailIconKeys = new List<string>();

    /// <summary>스킬 쿨타임 하한. 0 턴(매 턴 무제한 사용) 스킬은 허용하지 않는다.</summary>
    public const int CooldownMin = 1;

    [Header("쿨타임")]
    [Tooltip("스킬 사용 후 재사용까지 필요한 턴 수. 최소 1 (0턴 스킬은 허용하지 않음)")]
    [Min(CooldownMin)]
    [SerializeField] private int _cooldown = 1;

    [Header("효과")]
    [SerializeReference] private List<SkillEffectBase> _effects = new List<SkillEffectBase>();

    public int Index => _index;
    public string SkillId => _skillId;
    public string DisplayNameKey => _displayNameKey;
    public string DescKey => _descKey;
    public string DescriptionKey => _descriptionKey;
    public string DirectionPromptKey => _directionPromptKey;
    public string TargetPromptKey => _targetPromptKey;
    public string IconKey => _iconKey;
    public IReadOnlyList<string> DetailIconKeys => _detailIconKeys;
    public int Cooldown => Mathf.Max(CooldownMin, _cooldown);
    public IReadOnlyList<SkillEffectBase> Effects => _effects;

    /// <summary>
    /// 기본 쿨타임과 런 영속 보정을 합성하는 단일 계산 경계.
    /// 난이도 보정이 추가되면 호출부에서 합산한 delta를 이 경계에 전달한다.
    /// </summary>
    public int ResolveCooldown(int cooldownDelta = 0)
        => Mathf.Max(CooldownMin, Cooldown + cooldownDelta);

    public bool RequiresDirectionSelection
    {
        get
        {
            if (_effects == null) return false;
            for (int i = 0; i < _effects.Count; i++)
            {
                if (_effects[i] != null && _effects[i].RequiresDirectionSelection)
                    return true;
            }
            return false;
        }
    }

    public ECardDirection DirectionOptions
    {
        get
        {
            ECardDirection options = ECardDirection.None;
            if (_effects == null) return options;

            for (int i = 0; i < _effects.Count; i++)
            {
                if (_effects[i] != null)
                    options |= _effects[i].DirectionOptions;
            }

            return options;
        }
    }

    /// <param name="cooldownDelta">런 영속 쿨타임 보정(과충전 코일 등). 적용 후 최소 1 로 클램프.</param>
    public SkillRuntimeData ToRuntimeData(int cooldownDelta = 0)
    {
        List<SkillEffectBase> clonedEffects = new List<SkillEffectBase>(_effects != null ? _effects.Count : 0);
        if (_effects != null)
        {
            for (int i = 0; i < _effects.Count; i++)
            {
                if (_effects[i] != null)
                    clonedEffects.Add(_effects[i].Clone());
            }
        }

        return new SkillRuntimeData(
            _index,
            _skillId,
            _displayNameKey,
            _descKey,
            _descriptionKey,
            _directionPromptKey,
            _targetPromptKey,
            _iconKey,
            _detailIconKeys,
            ResolveCooldown(cooldownDelta),
            clonedEffects);
    }
}
