﻿// =================================================================
// [스크립트 목적]  시작 덱 1종의 정적 데이터 (SO 에셋). enum 키 + 카드 구성 목록
// [주요 변수]      - _deckType : 이 SO 가 어떤 시작 덱인지 (EStartingDeck)
//                  - _entries  : 카드 구성 (CardDataSO + 수량 + 강화여부)
// [의존 관계]      - CardDataSO / EStartingDeck
//                  - InGameController 가 enum→SO 매핑으로 선택, DeckSystem 에 주입
// [설계 노트]      - "어떤 카드를 몇 장" 을 데이터로 표현 (하드코딩 금지, Data-Driven)
//                  - 세션(런) 카드 풀의 임시 대체물. 추후 RunManager 도입 시 교체 지점
// =================================================================

using System;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// 시작 덱 1종의 정적 정의. 어떤 카드를 몇 장, 강화 상태로 넣을지 데이터로 보관한다.
/// 런타임에는 DeckSystem 이 이 정의를 받아 CardFactory 로 Card 인스턴스를 찍어낸다.
/// 현재는 세션 카드 풀의 임시 대체물이며, 추후 seed 기반 RunManager 가 생기면
/// "런 진행 중 획득한 카드 목록" 으로 대체된다 (그때 이 SO 는 '초기 지급분' 으로 축소).
/// </summary>
[CreateAssetMenu(fileName = "StartingDeck_", menuName = "Card/StartingDeck")]
public sealed class StartingDeckSO : ScriptableObject
{
    /// <summary>덱 구성 1줄: 어떤 카드를, 몇 장, 강화 상태로.</summary>
    [Serializable]
    public struct DeckEntry
    {
        [Tooltip("덱에 넣을 카드 데이터")]
        public CardDataSO card;

        [Tooltip("이 카드를 넣을 장수")]
        [Min(1)]
        public int count;

        [Tooltip("강화 상태로 시작할지 여부")]
        public bool upgraded;
    }

    [Header("식별")]
    [Tooltip("이 SO 가 나타내는 시작 덱 종류. InGameController 매핑 키와 일치해야 함")]
    [SerializeField] private EStartingDeck _deckType = EStartingDeck.None;

    [Header("덱 구성")]
    [Tooltip("시작 덱에 포함될 카드 목록 (카드 + 장수 + 강화여부)")]
    [SerializeField] private List<DeckEntry> _entries = new List<DeckEntry>();

    /// <summary>이 SO 가 나타내는 시작 덱 종류.</summary>
    public EStartingDeck DeckType => _deckType;

    /// <summary>덱 구성 목록 (읽기 전용).</summary>
    public IReadOnlyList<DeckEntry> Entries => _entries;

    /// <summary>
    /// 이 정의를 펼쳐 Card 런타임 인스턴스 리스트로 생성한다.
    /// 같은 카드를 count 만큼 각각 독립 인스턴스로 찍는다 (CardFactory 가 효과/스탯 격리).
    /// </summary>
    public List<Card> BuildCards()
    {
        var result = new List<Card>(EstimateCount());

        for (int i = 0; i < _entries.Count; i++)
        {
            DeckEntry entry = _entries[i];
            if (entry.card == null)
            {
                Debug.LogWarning($"[StartingDeckSO] '{name}' 의 {i}번 엔트리에 카드가 비어있습니다. 건너뜁니다.");
                continue;
            }

            int count = Mathf.Max(1, entry.count);
            for (int c = 0; c < count; c++)
            {
                Card card = CardFactory.CreateFromSO(entry.card, entry.upgraded);
                if (card != null)
                {
                    result.Add(card);
                }
            }
        }

        return result;
    }

    /// <summary>리스트 용량 사전 추정 (할당 1회 최적화용).</summary>
    private int EstimateCount()
    {
        int total = 0;
        for (int i = 0; i < _entries.Count; i++)
        {
            total += Mathf.Max(1, _entries[i].count);
        }
        return total;
    }
}