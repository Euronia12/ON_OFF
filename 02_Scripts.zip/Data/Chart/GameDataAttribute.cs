﻿// =================================================================
// [스크립트 목적]  데이터 클래스(CSV/JSON 파싱 대상) 표식 마커
// [주요 변수]      - 없음 (순수 마커)
// [의존 관계]      - DataManager가 부팅 시 이 표식으로 데이터 타입 수집
// =================================================================
using System;

/// <summary>
/// 이 클래스가 DataManager의 CSV/JSON 데이터 대상임을 표시하는 마커.
/// DataManager는 부팅 시 게임 어셈블리에서 이 표식이 붙은 클래스만 수집해
/// "파일명(=클래스명) → Type" 사전을 구성한다. (전체 어셈블리 스캔 제거)
/// 데이터 클래스 정의 시 반드시 부착 — 누락 시 해당 데이터는 로드되지 않음.
/// </summary>
[AttributeUsage(AttributeTargets.Class, Inherited = false, AllowMultiple = false)]
public sealed class GameDataAttribute : Attribute { }