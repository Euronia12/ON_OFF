// =================================================================
// [스크립트 목적]  스테이지별 적 풀 ScriptableObject. 등급별 적 목록 + 적별 가중치.
// [주요 변수]      - _normal : 일반 적 (EnemyDataSO.EncounterTier 로 저층/상층 자동 분리)
//                  - _elite  : 엘리트 적 (EnemyDataSO.EncounterTier 로 저층/상층 자동 분리)
//                  - _boss   : 보스 노드용 적
//                  - _test   : 테스트 노드용 적
// [의존 관계]      - StageDataSO(_enemyPool 로 참조) / EncounterAssigner(등급·가중치 추첨)
//                  - EnemyDataSO(Grade/EncounterTier/EnemyId)
// [설계 노트]      - 전역 풀 대신 스테이지별 적 구성을 데이터로 지정하기 위한 SO.
//                    일반/엘리트 풀은 각 적의 EncounterTier(Easy/Hard)로
//                    한 스테이지 안에서 저층/상층을 가른다(기존 배정 규칙 계승).
//                  - 가중치(WeightedEnemy.Weight)로 적별 등장 빈도를 조절한다.
//                  - StageDataSO 가 직접 드래그 참조 → Addressables 의존성으로 함께 로드됨
//                    (DataManager 별도 등록 불필요).
// =================================================================

using System;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// 적 1종 + 등장 가중치. Weight 가 클수록 자주 추첨된다(같은 등급 풀 내 비례).
/// </summary>
[Serializable]
public struct WeightedEnemy
{
    [Tooltip("적 정의 데이터")]
    public EnemyDataSO Enemy;

    [Tooltip("등장 가중치 (클수록 자주). 같은 등급 풀 안에서 비례 추첨")]
    [Min(1)]
    public int Weight;
}

/// <summary>
/// 한 스테이지에서 등장할 적 풀. 등급별(일반/엘리트/보스/테스트)로 분리하며,
/// 일반/엘리트 적은 각 EnemyDataSO 의 EncounterTier 로 저층(Easy)/상층(Hard)이 자동 분리된다.
/// </summary>
[CreateAssetMenu(fileName = "EnemyPool", menuName = "Game/Enemy Pool", order = 1)]
public sealed class EnemyPoolSO : ScriptableObject
{
    [Header("일반 (EncounterTier 로 저층 Easy / 상층 Hard 자동 분리)")]
    [Tooltip("Battle 노드용 일반 적. 각 적의 EncounterTier 로 맵 앞=Easy, 뒤=Hard 로 나뉜다")]
    [SerializeField] private WeightedEnemy[] _normal = new WeightedEnemy[0];

    [Header("엘리트 (EncounterTier 로 저층 Easy / 상층 Hard 자동 분리)")]
    [Tooltip("Elite 노드용 적. 각 적의 EncounterTier 로 맵 앞=Easy, 뒤=Hard 로 나뉜다")]
    [SerializeField] private WeightedEnemy[] _elite = new WeightedEnemy[0];

    [Header("보스")]
    [Tooltip("Boss 노드용 적")]
    [SerializeField] private WeightedEnemy[] _boss = new WeightedEnemy[0];

    [Header("테스트")]
    [Tooltip("Test 노드용 적")]
    [SerializeField] private WeightedEnemy[] _test = new WeightedEnemy[0];

    /// <summary>일반 적 (EncounterTier 로 Easy/Hard 분리 대상). 읽기 전용.</summary>
    public IReadOnlyList<WeightedEnemy> Normal => _normal;

    /// <summary>엘리트 적 (EncounterTier 로 Easy/Hard 분리 대상). 읽기 전용.</summary>
    public IReadOnlyList<WeightedEnemy> Elite => _elite;

    /// <summary>보스 적. 읽기 전용.</summary>
    public IReadOnlyList<WeightedEnemy> Boss => _boss;

    /// <summary>테스트 적. 읽기 전용.</summary>
    public IReadOnlyList<WeightedEnemy> Test => _test;
}
