// =================================================================
// [스크립트 목적]  카드 1장의 정적 데이터 (SO 에셋). 효과 인라인 보유 + 강화 + 분류(풀/등급/해방)
//                  ★ SO 격리: 게임플레이는 ToRuntimeData() 로 변환된 POCO 만 사용
// [주요 변수]      - _cardId        : 카드 고유 ID (CSV 키)
//                  - _cardType/_rarity/_keywords : 분류·희귀도·키워드 비트
//                  - _pools         : 보상 풀 분류 (상점/일반/보스, [Flags])
//                  - _unlockedByDefault : 기본 해방 여부 (false=잠긴 카드)
//                  - _baseEffects/_upgradeEffects : 효과 리스트 ([SerializeReference])
//                  - _baseArrow/_upgradeArrow     : 방위 화살표
//                  - _range/_upgradedRange/_propagation : 체인 전파
//                  - _vfx*Key       : 연출 풀 키 (prefab 직접참조 제거 → string)
// [의존 관계]      - CardFactory.FromSO 가 ToRuntimeData 로 런타임 POCO 변환
//                  - CardRewardService 가 _pools/_rarity/_unlockedByDefault 로 쿼리
// [설계 노트]      - ★ 외부(게임플레이)는 SO 를 직접 참조하지 않는다. ToRuntimeData() 가 유일 출구.
//                  - 분류(풀/등급/해방)는 카드 자신이 소유 → 보상 테이블 SO 불필요(쿼리 기반).
//                  - 투사체/적중 연출은 prefab 이 아닌 풀 키(string) 보유 → PoolManager.SpawnAsync(key)
// =================================================================

using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Serialization;

/// <summary>
/// 카드 1장의 정적 데이터. 효과는 [SerializeReference] 로 인라인 직렬화된다.
/// 강화는 효과/비용/방향/사거리 리스트를 통째로 교체하는 방식.
/// 보상 분류(풀/등급/해방)를 카드가 직접 소유 → CardRewardService 가 쿼리로 추출(테이블 SO 불필요).
/// ★ 게임플레이 코드는 이 SO 를 직접 보지 않고 ToRuntimeData() 결과(CardRuntimeData)만 사용한다.
/// </summary>
[CreateAssetMenu(fileName = "Card_", menuName = "Card/CardData")]
public sealed class CardDataSO : ScriptableObject
{
    [Header("기본 정보")]
    [Tooltip("인스펙터 확인용 한글 이름. 게임플레이/표시 로직에는 사용하지 않음")]
    [SerializeField] private string _koreanName;

    [Tooltip("카드 고유 ID. CSV 행 키이자 Addressable 키와 매칭")]
    [SerializeField] private string _cardId;

    [Tooltip("카드 표시 이름 다국어 키")]
    [SerializeField] private string _displayNameKey;

    [Tooltip("카드 설명 다국어 키")]
    [SerializeField] private string _descriptionKey;

    [Tooltip("공용 카드 SpriteAtlas 내부 스프라이트 이름")]
    [SerializeField] private string _iconKey;

    [Header("분류 (2축: 분류 + 희귀도 독립)")]
    [Tooltip("카드 분류: 일반/파워/스킬")]
    [SerializeField] private ECardType _cardType = ECardType.Normal;

    [Tooltip("희귀도: 일반/레어/유니크. 보상 가중치·등급 필터 키")]
    [SerializeField] private ECardRarity _rarity = ECardRarity.Common;

    [Tooltip("특수 키워드 비트 (선천성/보존/소멸 등). 동시 보유 가능")]
    [SerializeField] private ECardKeyword _keywords = ECardKeyword.None;

    [Tooltip("이 카드가 속한 시작 덱/공통 카드 풀")]
    [SerializeField] private EStartingDeck _deckType = EStartingDeck.Common;

    [Header("보상 분류 (풀/해방)")]
    [Tooltip("이 카드가 등장할 수 있는 풀 (상점/일반/보스). 동시 선택 가능(비트)\n" +
             "비우면(None) 어느 보상에도 안 나옴")]
    [SerializeField] private ECardPool _pools = ECardPool.Normal;

    [Tooltip("이 카드가 등장할 수 있는 스테이지/챕터. 비우면(None) 어느 스테이지에도 안 나옴")]
    [SerializeField] private ECardStagePool _stagePools = ECardStagePool.All;

    [Tooltip("기본 해방 여부. 체크 해제 시 '잠긴 카드' → 해방되어야만 보상 등장\n" +
             "(해방 판정은 ICardUnlockProvider, 현재는 항상-해방 폴백)")]
    [SerializeField] private bool _unlockedByDefault = true;

    [Header("전투 임시 카드")]
    [Tooltip("덱/묘지에 편입되지 않고 필드에서 제거되는 적 설치 카드")]
    [SerializeField] private bool _isTemporaryFieldOnly;

    [Tooltip("ON 상태로 턴 종료 시 설정된 카드를 플레이어 드로우 더미에 추가")]
    [FormerlySerializedAs("_addsDisturbanceCardsOnTurnEnd")]
    [SerializeField] private bool _generatesCardsOnTurnEnd;

    [Tooltip("ON 상태로 턴 종료 시 생성할 CardDataSO의 에셋 이름")]
    [SerializeField] private string _turnEndGeneratedCardId;

    [Tooltip("ON 상태로 턴 종료 시 블록 한 장당 생성할 카드 수")]
    [Min(0)]
    [SerializeField] private int _turnEndGeneratedCardCount;

    [Tooltip("그리드에 배치할 수 없고 턴 종료 시 묘지 없이 제거되는 손패 카드")]
    [SerializeField] private bool _isHandOnlyDisturbance;

    [Tooltip("손패에 남은 채 턴 종료되면 플레이어에게 피해를 주는 카드. 보통 _isHandOnlyDisturbance 와 함께 사용")]
    [SerializeField] private bool _dealsDamageInHandOnTurnEnd;

    [Tooltip("위 저주가 턴 종료 시 가하는 피해량(HP). 값이 클수록 손패에 남길 때 위험")]
    [Min(0)]
    [SerializeField] private int _handTurnEndDamage = 0;

    [Header("비용")]
    [Min(0)]
    [SerializeField] private int _cost = 1;

    [Tooltip("강화 시 비용. 비용 변화 없으면 _cost 와 동일하게")]
    [Min(0)]
    [SerializeField] private int _upgradedCost = 1;

    [Header("효과 조립 (기본)")]
    [Tooltip("기본 상태 효과 리스트. 공격+방어 동시 가능")]
    [SerializeReference] private List<CardEffectBase> _baseEffects = new List<CardEffectBase>();

    [Header("효과 조립 (강화)")]
    [Tooltip("강화 시 적용될 효과 리스트. 수치 변화·효과 추가 모두 가능. 비강화면 비워둠")]
    [SerializeReference] private List<CardEffectBase> _upgradeEffects = new List<CardEffectBase>();

    [Header("방위 화살표 (기본)")]
    [Tooltip("기본 방위 화살표 설정. 모드(Fixed/Random/Weighted)·후보·가중치")]
    [SerializeField] private ArrowConfig _baseArrow = new ArrowConfig();

    [Header("방위 화살표 (강화)")]
    [Tooltip("강화 시 방위 화살표 설정. 비강화면 무시 (기본 방향 사용)")]
    [SerializeField] private ArrowConfig _upgradeArrow = new ArrowConfig();

    [Tooltip("강화 시 방향도 교체할지. false 면 강화여도 기본 방향 사용")]
    [SerializeField] private bool _hasUpgradeArrow = false;

    [Header("체인 전파 (화살표 신호)")]
    [Tooltip("화살표 방향으로 신호가 뻗는 칸 수. 1=인접만, 2 이상=원거리 전파")]
    [Min(1)]
    [SerializeField] private int _range = 1;

    [Tooltip("강화 시 사거리. 사거리 변화 없으면 _range 와 동일하게")]
    [Min(1)]
    [SerializeField] private int _upgradedRange = 1;

    [Tooltip("경로 차단 규칙. Pierce=관통 / BlockOnFirstCard=첫 카드 정지 / StopOnGap=빈칸 중단")]
    [SerializeField] private EChainPropagation _propagation = EChainPropagation.BlockOnFirstCard;

    [Tooltip("체인 전파 패턴. Line=기본 직선, 나머지는 특수 카드 패턴(형태 고정 — 사거리는 _range 사용)")]
    [SerializeField] private EChainPatternType _patternType = EChainPatternType.Line;

    [Header("발동 연출 (풀 키 기반)")]
    [Tooltip("연출 종류 (없음/투사체/적중/둘다)")]
    [SerializeField] private EVfxType _vfxType = EVfxType.None;

    [Tooltip("연출 대상 방향 (공격형=적 / 버프·방어·회복형=자기)")]
    [SerializeField] private EVfxTarget _vfxTarget = EVfxTarget.Enemy;

    [Tooltip("투사체 풀 키 (PoolManager.SpawnAsync 키). 비우면 투사체 생략")]
    [SerializeField] private string _projectileKey;

    [Tooltip("적중 이펙트 풀 키 (PoolManager.SpawnAsync 키). 비우면 적중 생략")]
    [SerializeField] private string _hitVfxKey;

    // ── 조회 프로퍼티 / 메서드 (에디터·빌더·서비스용 — 게임플레이는 ToRuntimeData 사용) ──

    public string CardId => _cardId;
    public string KoreanName => _koreanName;
    public string DisplayNameKey => _displayNameKey;
    public string DescriptionKey => _descriptionKey;
    public string IconKey => _iconKey;
    public ECardType CardType => _cardType;
    public ECardRarity Rarity => _rarity;
    public ECardKeyword Keywords => ResolveKeywords(_baseEffects);
    public EStartingDeck DeckType => _deckType;
    /// <summary>보상 풀 분류 (상점/일반/보스 비트). CardRewardService 쿼리 키.</summary>
    public ECardPool Pools => _pools;

    /// <summary>등장 가능 스테이지/챕터 비트. CardRewardService 쿼리 키.</summary>
    public ECardStagePool StagePools => _stagePools;

    /// <summary>기본 해방 여부 (false=잠긴 카드). 쿼리 시 해방 필터 1차 판정.</summary>
    public bool UnlockedByDefault => _unlockedByDefault;

    /// <summary>강화 데이터 보유 여부. _upgradeEffects 가 비어있으면 강화 불가 카드.</summary>
    public bool CanUpgrade => _upgradeEffects != null && _upgradeEffects.Count > 0;

    /// <summary>upgraded 여부에 따라 비용 반환.</summary>
    public int GetCost(bool upgraded) => upgraded && CanUpgrade ? _upgradedCost : _cost;

    /// <summary>경로 차단 규칙 (관통/차단/빈칸막힘). 카드 데이터로 설정.</summary>
    public EChainPropagation Propagation => _propagation;
    public EChainPatternType PatternType => _patternType;

    /// <summary>upgraded 여부에 따라 체인 전파 사거리 반환. 최소 1.</summary>
    public int GetRange(bool upgraded)
    {
        int r = upgraded && CanUpgrade ? _upgradedRange : _range;
        return r < 1 ? 1 : r;
    }

    /// <summary>upgraded 여부에 따라 효과 리스트 반환.</summary>
    public IReadOnlyList<CardEffectBase> GetEffects(bool upgraded)
    {
        return upgraded && CanUpgrade ? _upgradeEffects : _baseEffects;
    }

    /// <summary>
    /// upgraded 여부에 따라 방위 화살표 설정 반환.
    /// _hasUpgradeArrow 가 false 면 강화 상태여도 기본 방향을 사용한다.
    /// </summary>
    public ArrowConfig GetArrowConfig(bool upgraded)
    {
        bool useUpgrade = upgraded && CanUpgrade && _hasUpgradeArrow;
        return useUpgrade ? _upgradeArrow : _baseArrow;
    }

    /// <summary>키워드 비트 포함 여부 빠른 조회 (기본 효과 기준).</summary>
    public bool HasKeyword(ECardKeyword keyword) => (ResolveKeywords(_baseEffects) & keyword) != 0;

    /// <summary>
    /// 카드 타입/효과에서 파생되는 키워드를 포함해 반환한다.
    /// effects 는 파생 판정 대상(기본/강화) 효과 리스트 — 강화 상태에 따라 달라지므로 인자로 받는다.
    /// </summary>
    private ECardKeyword ResolveKeywords(IReadOnlyList<CardEffectBase> effects)
    {
        ECardKeyword result = _keywords;
        if (_cardType == ECardType.Reserve)
        {
            result |= ECardKeyword.Reserve;
        }

        // 효과 보유 여부로 키워드를 자동 파생 (에셋별 수동 태깅 불필요).
        if (effects != null)
        {
            for (int i = 0; i < effects.Count; i++)
            {
                switch (effects[i])
                {
                    case DirectionalAbsorbEffect:
                        result |= ECardKeyword.Absorb;
                        break;
                    case SpawnOffspringEffect:
                        result |= ECardKeyword.Offspring;
                        break;
                    case CastingPredateEffect:
                    case ForbiddenRitualEffect:
                        result |= ECardKeyword.Predate;
                        break;
                    case MagicCircleEffect:
                        result |= ECardKeyword.MagicCircle;
                        break;
                }
            }
        }

        return result;
    }

    /// <summary>upgraded 여부에 따른 효과 비트 합산 (조회/UI용).</summary>
    public ECardEffectFlag GetEffectFlags(bool upgraded)
    {
        IReadOnlyList<CardEffectBase> effects = GetEffects(upgraded);
        ECardEffectFlag flags = ECardEffectFlag.None;
        for (int i = 0; i < effects.Count; i++)
        {
            CardEffectBase effect = effects[i];
            if (effect != null)
            {
                flags |= effect.EffectFlag;
            }
        }
        return flags;
    }

    /// <summary>발동 연출 종류.</summary>
    public EVfxType VfxType => _vfxType;

    /// <summary>연출 대상 방향.</summary>
    public EVfxTarget VfxTarget => _vfxTarget;

    /// <summary>투사체 풀 키 (비면 투사체 생략).</summary>
    public string ProjectileKey => _projectileKey;

    /// <summary>적중 이펙트 풀 키 (비면 적중 연출 생략).</summary>
    public string HitVfxKey => _hitVfxKey;

    // ──────────────────────────────────────────────────────────────
    // ★ SO 격리 출구: ToRuntimeData
    // ──────────────────────────────────────────────────────────────

    /// <summary>
    /// 정적 SO 데이터를 런타임 POCO(CardRuntimeData)로 변환한다 (격리 경계).
    /// 강화 분기는 GetXXX(upgraded) 조회 API 를 재사용해 1회 해소한다.
    /// </summary>
    public CardRuntimeData ToRuntimeData(bool upgraded = false)
    {
        bool actualUpgraded = upgraded && CanUpgrade;

        return new CardRuntimeData(
            cardId: _cardId,
            displayNameKey: _displayNameKey,
            descriptionKey: _descriptionKey,
            iconKey: _iconKey,
            cardType: _cardType,
            rarity: _rarity,
            keywords: ResolveKeywords(GetEffects(actualUpgraded)),
            cost: GetCost(actualUpgraded),
            isUpgraded: actualUpgraded,
            effects: GetEffects(actualUpgraded),
            arrow: GetArrowConfig(actualUpgraded),
            range: GetRange(actualUpgraded),
            propagation: _propagation,
            patternType: _patternType,
            vfxType: _vfxType,
            vfxTarget: _vfxTarget,
            projectileKey: _projectileKey,
            hitVfxKey: _hitVfxKey,
            isTemporaryFieldOnly: _isTemporaryFieldOnly,
            generatesCardsOnTurnEnd: _generatesCardsOnTurnEnd,
            turnEndGeneratedCardId: _turnEndGeneratedCardId,
            turnEndGeneratedCardCount: _turnEndGeneratedCardCount,
            isHandOnlyDisturbance: _isHandOnlyDisturbance,
            dealsDamageInHandOnTurnEnd: _dealsDamageInHandOnTurnEnd,
            handTurnEndDamage: _handTurnEndDamage);
    }

#if UNITY_EDITOR
    /// <summary>[에디터 전용] CardDeckBuilder 가 CSV 파싱 결과를 주입 (기본 정보·효과).</summary>
    public void EditorImport(
        string cardId, string koreanName, string displayNameKey, string descriptionKey, string iconKey,
        ECardType cardType, ECardRarity rarity, ECardKeyword keywords,
        int cost, int upgradedCost,
        List<CardEffectBase> baseEffects, List<CardEffectBase> upgradeEffects)
    {
        _cardId = cardId;
        _koreanName = koreanName;
        _displayNameKey = displayNameKey;
        _descriptionKey = descriptionKey;
        _iconKey = iconKey;
        _cardType = cardType;
        _rarity = rarity;
        _keywords = keywords;
        _cost = cost;
        _upgradedCost = upgradedCost;
        _baseEffects = baseEffects ?? new List<CardEffectBase>();
        _upgradeEffects = upgradeEffects ?? new List<CardEffectBase>();
    }

    /// <summary>[에디터 전용] CSV에서 파싱한 방향 데이터 주입.</summary>
    public void EditorImportArrow(
        ArrowConfig baseArrow, ArrowConfig upgradeArrow, bool hasUpgradeArrow)
    {
        _baseArrow = baseArrow ?? new ArrowConfig();
        _upgradeArrow = upgradeArrow ?? new ArrowConfig();
        _hasUpgradeArrow = hasUpgradeArrow;
    }

    public void EditorImportPattern(EChainPatternType patternType)
    {
        _patternType = patternType;
    }

    public void EditorImportChain(int range, int upgradedRange, EChainPropagation propagation)
    {
        _range = Mathf.Max(1, range);
        _upgradedRange = Mathf.Max(1, upgradedRange);
        _propagation = propagation;
    }

    /// <summary>[에디터 전용] 연출 풀 키 주입 (CSV 빌더용).</summary>
    public void EditorImportVfx(
        EVfxType vfxType, EVfxTarget vfxTarget, string projectileKey, string hitVfxKey)
    {
        _vfxType = vfxType;
        _vfxTarget = vfxTarget;
        _projectileKey = projectileKey;
        _hitVfxKey = hitVfxKey;
    }

    /// <summary>
    /// [에디터 전용] 보상 분류 주입 (CSV 빌더용). 풀/해방여부.
    /// CSV 컬럼 예: pools="Shop|Normal|Boss" → 파싱 후 비트 OR 한 ECardPool 전달.
    /// </summary>
    public void EditorImportClassification(
        ECardPool pools,
        bool unlockedByDefault,
        ECardStagePool stagePools = ECardStagePool.All)
    {
        _pools = pools;
        _stagePools = stagePools;
        _unlockedByDefault = unlockedByDefault;
    }

    /// <summary>
    /// [에디터 전용] 카드가 속한 시작 덱/공통 카드 풀 주입.
    /// None 은 "어느 풀에도 미포함"을 뜻하므로 그대로 보존한다 (Common 으로 바꾸지 않음).
    /// </summary>
    public void EditorImportDeckType(EStartingDeck deckType)
    {
        _deckType = deckType;
    }
#endif
}
