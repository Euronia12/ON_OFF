﻿// =================================================================
// [스크립트 목적]  언어별 TMP 폰트 매핑 테이블. LocalizationManager가 직접 보유
// [주요 변수]      - _fonts        : 언어 → TMP_FontAsset 매핑 리스트
//                  - _fallbackFont : 매핑 누락 시 사용할 폴백 폰트
// [의존 관계]      - LocalizationManager가 [SerializeField]로 직접 참조
// =================================================================
using System;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

// 언어별 폰트 매핑 SO. UI 렌더링 리소스이므로 게임플레이 SO 격리 대상이 아님
// (DataManager POCO 변환 파이프라인과 무관 — LocalizationManager가 직접 보유)
[CreateAssetMenu(fileName = "LanguageFontTable", menuName = "Framework/Language Font Table")]
public class LanguageFontTableSO : ScriptableObject
{
    [Serializable]
    public class FontEntry
    {
        [Tooltip("대상 언어")]
        public SystemLanguage Language;

        [Tooltip("이 언어에서 사용할 TMP 폰트 에셋")]
        public TMP_FontAsset Font;
    }

    [Header("언어별 폰트")]
    [Tooltip("지원 언어마다 TMP 폰트를 1개씩 매핑.\n" +
             "LocalizationManager.SupportedLanguages와 동일한 언어 구성 권장")]
    [SerializeField] private List<FontEntry> _fonts = new();

    [Header("폴백")]
    [Tooltip("요청 언어의 폰트가 매핑에 없을 때 사용할 폰트")]
    [SerializeField] private TMP_FontAsset _fallbackFont;

    // 런타임 조회용 캐시 (List 선형 탐색 → Dictionary 1회 구축)
    private Dictionary<SystemLanguage, TMP_FontAsset> _cache;

    /// <summary>언어에 매핑된 폰트 반환. 없으면 폴백 폰트 반환(null일 수 있음).</summary>
    public TMP_FontAsset GetFont(SystemLanguage lang)
    {
        // 최초 호출 시 1회 캐시 구축 (이후 O(1) 조회, GC 0)
        if (_cache == null)
        {
            _cache = new Dictionary<SystemLanguage, TMP_FontAsset>(_fonts.Count);
            foreach (var entry in _fonts)
            {
                if (entry == null || entry.Font == null) continue;
                _cache[entry.Language] = entry.Font; // 중복 언어는 덮어씀
            }
        }

        if (_cache.TryGetValue(lang, out var font) && font != null)
            return font;

        return _fallbackFont; // 누락 시 폴백 (null일 수 있음 — 호출부에서 방어)
    }
}