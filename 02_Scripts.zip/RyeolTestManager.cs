﻿// =================================================================
// [스크립트 목적]  테스트 전용 매니저. 나중에 BattleManager 등으로 교체 예정.
// [배치]           인게임 씬에 빈 GameObject 만들고 부착
// [주의]           이 클래스는 테스트용입니다. 실제 로직으로 교체 시 삭제.
// =================================================================

using UnityEngine;
using Cysharp.Threading.Tasks;
using System.Threading;

public class RyeolTestManager : MonoBehaviour
{
    [Header("테스트 설정")]
    [SerializeField] private UICard _cardPrefab;
    [SerializeField] private int _drawCount = 5;

    private CancellationTokenSource _cts;

    private void Awake()
    {
        _cts = new CancellationTokenSource();
    }

    private void OnDestroy()
    {
        _cts?.Cancel();
        _cts?.Dispose();
    }

    // ─────────────────────────────────────────────
    // 테스트 기능
    // ─────────────────────────────────────────────

    private UICardHand GetHand()
    {
        var battle = UIManager.Instance.Get<UIBattle>();
        return battle?.CardHand;
    }

    /// <summary>드로우 연출 테스트. RyeolController.OnSceneReady에서 호출.</summary>
    public async UniTaskVoid TestDrawAsync()
    {
        if (!CardAnimationSystem.HasInstance) return;

        var hand = GetHand();
        if (hand == null || _cardPrefab == null) return;

        await CardAnimationSystem.Instance.PlayDrawMultipleAnim(_cardPrefab, hand, _drawCount, _cts.Token);
    }

    /// <summary>턴 종료 테스트. UI 버튼에서 호출.</summary>
    public async UniTaskVoid TestEndTurnAsync()
    {
        if (!CardAnimationSystem.HasInstance) return;

        var hand = GetHand();
        if (hand == null) return;

        await CardAnimationSystem.Instance.PlayDiscardAllAnim(hand, _cts.Token);
        await CardAnimationSystem.Instance.PlayDrawMultipleAnim(_cardPrefab, hand, _drawCount, _cts.Token);
    }

    /// <summary>유니티 버튼 OnClick 연결용 래퍼.</summary>
    public void OnEndTurnButtonClicked()
    {
        TestEndTurnAsync().Forget();
    }
}