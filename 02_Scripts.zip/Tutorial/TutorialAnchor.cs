// =================================================================
// [스크립트 목적]  튜토리얼 강조 대상 마커. 실물 UI(뽑을 더미·에너지 등)에 부착해
//                 문자열 ID 로 위치를 노출한다 (정적 레지스트리 등록/해제).
// [주요 변수]      - _anchorId : 대본(TutorialStep.AnchorIds)이 참조할 식별자
//                  - _registry : ID → 활성 앵커 조회 (정적, OnEnable/OnDisable 관리)
// [의존 관계]      - UITutorialPanel(프록시 위치 동기화에서 TryGet 조회)
// [배치]           강조하고 싶은 실물 UI RectTransform 에 부착 + ID 지정
// [설계 노트]      - 실물 UI 는 이 컴포넌트 외에 아무것도 바뀌지 않는다(관전자 원칙).
//                  - 같은 ID 중복 등록 시 마지막 활성 앵커가 이긴다(경고 로그).
// =================================================================

using System;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// 튜토리얼이 가리킬 실물 UI 의 위치 마커. 활성화 동안 ID 로 조회 가능하다.
/// 대본의 AnchorIds 와 패널 프록시(TutorialHighlightProxy)의 ID 를 잇는 다리 역할.
/// </summary>
public sealed class TutorialAnchor : MonoBehaviour
{
    [Tooltip("대본·프록시가 참조할 앵커 식별자 (예: DrawPile, DiscardPile, Energy, EndTurn)")]
    [SerializeField] private string _anchorId;

    private static readonly Dictionary<string, TutorialAnchor> _registry =
        new Dictionary<string, TutorialAnchor>(8, StringComparer.Ordinal);

    public string AnchorId => _anchorId;

    /// <summary>이 앵커의 RectTransform (프록시 위치·크기 동기화 대상).</summary>
    public RectTransform Rect => transform as RectTransform;

    /// <summary>ID 로 활성 앵커를 조회. 없으면 false (호출부는 조용히 생략).</summary>
    public static bool TryGet(string anchorId, out TutorialAnchor anchor)
    {
        anchor = null;
        return !string.IsNullOrEmpty(anchorId) && _registry.TryGetValue(anchorId, out anchor)
            && anchor != null;
    }

    /// <summary>런타임에 생성한 앵커의 ID를 지정하고 즉시 등록한다.</summary>
    public void Configure(string anchorId)
    {
        Unregister();
        _anchorId = anchorId;
        if (isActiveAndEnabled)
            Register();
    }

    private void OnEnable()
    {
        Register();
    }

    private void Register()
    {
        if (string.IsNullOrEmpty(_anchorId))
        {
            Debug.LogWarning($"[TutorialAnchor] ID 가 비어 있어 등록하지 않습니다: {name}", this);
            return;
        }

#if UNITY_EDITOR || DEVELOPMENT_BUILD
        if (_registry.TryGetValue(_anchorId, out TutorialAnchor existing) &&
            existing != null && existing != this)
        {
            Debug.LogWarning(
                $"[TutorialAnchor] 중복 ID '{_anchorId}' — {existing.name} 을 {name} 으로 덮어씁니다.", this);
        }
#endif
        _registry[_anchorId] = this;
    }

    private void OnDisable()
    {
        Unregister();
    }

    private void Unregister()
    {
        if (string.IsNullOrEmpty(_anchorId)) return;

        // 다른 인스턴스가 이미 덮어썼다면 건드리지 않는다.
        if (_registry.TryGetValue(_anchorId, out TutorialAnchor current) && current == this)
            _registry.Remove(_anchorId);
    }
}
