// =================================================================
// [스크립트 목적]  튜토리얼 첫 전투(1층) "멘토 시연" 구동. 첫 일반 전투 진입을 감지해
//                 실제 손패 카드를 한 장씩 그리드로 이동해 체인 발동 배치로 놓고,
//                 유저에게 지정 슬롯 한 칸만 열어 마지막 한 수를 두게 한다.
// [주요 변수]      - _showcase : 시연 각본 SO (배치 목록 + 지정 슬롯 + 대사 키)
// [의존 관계]      - EventManager(OnBattleNodeEntered 구독)
//                  - BattleManager(배치 제한/체인 배치/페이즈) / GridManager(마커/프리뷰)
//                  - UIManager + UITutorialPanel(대사) / UIBattle.CardHand(손패 흐림)
//                  - InGameController 가 IsShowcaseBattleNode/ActiveShowcase 로 시동 덱을 읽어간다
// [배치]           Tutorial 씬 빈 GameObject 에 부착 + 각본 SO 지정
// [설계 노트]      - 멘토 카드는 BattleManager.PlaceCardWithChainForTutorialAsync 로 배치한다.
//                    마나·배치 제한만 우회하고 체인은 정상 배치처럼 장마다 발동 —
//                    앞서 깔린 카드들이 연쇄로 토글되며 판이 자라는 과정을 보여준다.
//                  - 유저의 시동 카드만 완전한 정상 경로(마나 차감 포함)를 탄다.
//                  - 본편 씬에는 이 컴포넌트가 없으므로 본 게임에 영향 없음.
// =================================================================

using System;
using System.Collections.Generic;
using System.Threading;
using Cysharp.Threading.Tasks;
using DG.Tweening;
using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// 튜토리얼 첫 전투(1층)의 멘토 시연 감독.
/// 첫 일반 전투 진입 → 손패 흐림 → 인트로 대사 → 각본 카드 순차 배치(장마다 체인 발동)
/// → 피날레 대사 + 지정 슬롯 마커 → 지정 슬롯만 배치 허용 → 유저 배치 후 정리.
/// </summary>
public sealed class TutorialShowcaseSequence : MonoBehaviour
{
    private const float GuideCardAlpha = 0.45f;

    [Header("각본")]
    [Tooltip("멘토 시연 각본 SO")]
    [SerializeField] private TutorialBossShowcaseSO _showcase;

    [Tooltip("대사 페이지에 실을 프록시 ID 목록. UITutorialPanel 프리팹의 같은 ID " +
             "프록시(TutorialHighlightProxy)가 함께 표시된다 (예: Owl — 부엉이 출연). " +
             "프리팹에 해당 프록시가 없으면 조용히 생략")]
    [SerializeField] private List<string> _mentAnchorIds = new List<string> { "Owl" };

    [Header("연출 타이밍")]
    [Tooltip("대본 패널(전투 진입 안내)이 닫힌 뒤 시연 시작까지의 여유(초)")]
    [Min(0f)]
    [SerializeField] private float _startSettleSeconds = 0.35f;

    [Tooltip("배치 직전 화살표 프리뷰를 보여주는 시간(초)")]
    [Min(0f)]
    [SerializeField] private float _previewBeatSeconds = 0.2f;

    [Tooltip("배치 팝 연출 강도 (슬롯 스케일 펀치)")]
    [Min(0f)]
    [SerializeField] private float _placePunchScale = 0.12f;

    [Tooltip("배치 팝 연출 시간(초)")]
    [Min(0.01f)]
    [SerializeField] private float _placePunchDuration = 0.25f;

    [Tooltip("실제 손패 카드가 목표 슬롯으로 이동하는 시간(초)")]
    [Min(0.01f)]
    [SerializeField] private float _cardMoveDuration = 0.3f;

    [Tooltip("가짜 안내 카드가 목표 도착 후 다시 시작하기까지의 간격(초)")]
    [Min(0f)]
    [SerializeField] private float _guideLoopPauseSeconds = 0.35f;

    [Tooltip("2페이즈 첫 공격 후 적이 화면 밖으로 퇴장하는 시간(초)")]
    [Min(0.01f)]
    [SerializeField] private float _enemyExitDuration = 0.8f;

    private static TutorialShowcaseSequence _instance;

    /// <summary>
    /// 현재 씬의 활성 각본. InGameController 가 시연 전투 컨텍스트 조립 시
    /// 시동 카드 덱을 읽어가는 통로다. 튜토리얼 씬 밖에서는 null.
    /// </summary>
    public static TutorialBossShowcaseSO ActiveShowcase =>
        _instance != null ? _instance._showcase : null;

    /// <summary>
    /// 이 노드 타입 진입이 멘토 시연 전투인지 — 시동 덱 주입(InGameController)과
    /// 시연 시작 게이트가 공유하는 단일 판정. 컨텍스트 조립이 진입 이벤트 발행보다
    /// 먼저 실행되므로, 첫 일반 전투에서 덱 주입 → 시연 시작(_started) 순서가 보장된다.
    /// </summary>
    public static bool IsShowcaseBattleNode(ENodeType nodeType)
    {
        return _instance != null
            && !_instance._started
            && _instance._showcase != null
            && _instance._showcase.PlayerDeck.Count > 0
            && nodeType == ENodeType.Battle;
    }

    /// <summary>
    /// 시연 승리 후 마무리 안내가 아직 표시 중(또는 표시 예정)인지.
    /// InGameController 가 보상창을 이 안내가 닫힌 뒤로 늦추는 데 쓴다.
    /// 유저의 마지막 한 수 배치 시점에 미리 켜 두므로(동기),
    /// 전투 종료 이벤트 구독 순서와 무관하게 보상 흐름이 안전하게 대기한다.
    /// </summary>
    public static bool IsOutroActive =>
        _instance != null && _instance._outroPending;

    /// <summary>첫 전투 보상창 위에 부엉이의 보상 안내를 1회 표시한다.</summary>
    public static UniTask ShowRewardGuideIfPendingAsync(CancellationToken token)
    {
        if (_instance == null
            || !_instance._started
            || _instance._rewardGuideShown
            || _instance._showcase == null)
        {
            return UniTask.CompletedTask;
        }

        _instance._rewardGuideShown = true;
        return _instance.ShowBlockedMentAsync(
            _instance._showcase.RewardBodyKey,
            null,
            token);
    }

    /// <summary>첫 카드 보상 선택창 위에 부엉이의 카드 선택 안내를 1회 표시한다.</summary>
    public static UniTask ShowCardSelectGuideIfPendingAsync(CancellationToken token)
    {
        if (_instance == null
            || !_instance._started
            || !_instance._rewardGuideShown
            || _instance._cardSelectGuideShown
            || _instance._showcase == null)
        {
            return UniTask.CompletedTask;
        }

        _instance._cardSelectGuideShown = true;
        string skipText = LocalizationManager.HasInstance
            ? LocalizationManager.Instance.Get(LocalizationKeys.CardSelect.Skip)
            : LocalizationKeys.CardSelect.Skip;
        return _instance.ShowBlockedMentAsync(
            _instance._showcase.CardSelectBodyKey,
            new object[] { skipText },
            token);
    }

    private readonly List<IDisposableEvent> _subscriptions = new List<IDisposableEvent>(1);
    private CancellationTokenSource _cts;
    private bool _started;
    private bool _placedHandlerAttached;
    private bool _enemyActionHandlerAttached;
    private bool _isForcedInputBlocked;
    private bool _isEscapeBlocked;
    private bool _awaitingEnemyEscape;
    private bool _reviveDialogueShown;
    private bool _outroPending;
    private bool _rewardGuideShown;
    private bool _cardSelectGuideShown;
    private UICardHand _dimmedHand;
    private UIBattle _endTurnLockedUI;
    private GraphicRaycaster _disabledBattleRaycaster;
    private UICard _guideCard;
    private CancellationTokenSource _guideCts;

    private void Awake()
    {
        _instance = this;
        _cts = new CancellationTokenSource();
    }

    private void Start()
    {
        InitializeAsync().Forget();
    }

    private async UniTaskVoid InitializeAsync()
    {
        await BootstrapInitializer.WaitForReadyAsync();
        if (_cts == null || _cts.IsCancellationRequested) return;

        if (_showcase == null)
        {
            Debug.LogWarning("[TutorialShowcaseSequence] 각본(TutorialBossShowcaseSO)이 없어 시연을 생략합니다.");
            return;
        }

        if (!EventManager.HasInstance)
        {
            Debug.LogError("[TutorialShowcaseSequence] EventManager 가 없어 전투 진입을 감지할 수 없습니다.");
            return;
        }

        _subscriptions.Add(
            EventManager.Instance.Subscribe<OnBattleNodeEntered>(HandleBattleNodeEntered));
    }

    private void OnDestroy()
    {
        if (_instance == this) _instance = null;

        for (int i = 0; i < _subscriptions.Count; i++)
            _subscriptions[i]?.Dispose();
        _subscriptions.Clear();

        DetachBattleHandlers();
        ReleaseRestrictions();

        _cts?.Cancel();
        _cts?.Dispose();
        _cts = null;
    }

    // ─────────────────────────────────────────────
    // 진입 감지
    // ─────────────────────────────────────────────

    private void HandleBattleNodeEntered(OnBattleNodeEntered evt)
    {
        if (!IsShowcaseBattleNode(evt.NodeType)) return;
        if (!BattleManager.HasInstance) return;

        _started = true;

        // 시연이 시작되기 전 유저가 선수를 두지 못하게 즉시 잠근다.
        BattleManager.Instance.SetPlacementLocked(true);
        BattleManager.Instance.OnBattleEnded += HandleBattleEnded;
        BattleManager.Instance.OnBeforeEnemyActionAsync += HandleBeforeEnemyActionAsync;
        BattleManager.Instance.OnAfterEnemyActionAsync += HandleAfterEnemyActionAsync;
        _enemyActionHandlerAttached = true;
        BlockBattlePointerInput();
        AcquireForcedInputBlock(allowEscape: true);

        RunShowcaseAsync().Forget();
    }

    // ─────────────────────────────────────────────
    // 시연 본체
    // ─────────────────────────────────────────────

    private async UniTaskVoid RunShowcaseAsync()
    {
        if (_cts == null) return;

        CancellationToken token = _cts.Token;
        BattleManager battle = BattleManager.Instance;
        GridManager grid = GridManager.Instance;
        if (battle == null || grid == null)
        {
            AbortShowcase();
            return;
        }

        try
        {
            // 1) 플레이어 입력 페이즈 진입 대기 (전투 셋업 완료 보장).
            while (battle.CurrentPhase != EBattlePhase.PlayerInput)
                await UniTask.Yield(token);

            // 2) 대본 패널(전투 진입 안내)이 뜨고 닫힐 때까지 대기.
            //    TutorialDirector 의 표시 지연(0.2s)보다 길게 기다린 뒤 닫힘을 확인한다.
            await DelayAsync(0.5f, token);
            while (IsTutorialPanelOpen())
                await UniTask.Yield(token);
            await DelayAsync(_startSettleSeconds, token);

            // 3) 전투 HUD 포인터 + 턴 종료·스킬 잠금
            //    (시연 중 카드 드래그·턴 넘김·스킬 사용은 각본을 깨뜨린다).
            BlockBattlePointerInput();

            // 4) 인트로 대사 ("잘 봐라. 설계는 이렇게 하는 거다.")
            await ShowMentAsync(_showcase.IntroTitleKey, _showcase.IntroBodyKey, token);

            // 5) 실제 손패 카드를 순차 이동·배치한다.
            IReadOnlyList<TutorialBossShowcaseSO.ShowcaseSeed> seeds = _showcase.Seeds;
            for (int i = 0; i < seeds.Count; i++)
            {
                TutorialBossShowcaseSO.ShowcaseSeed seed = seeds[i];
                if (seed == null || seed.Card == null) continue;

                UICard uiCard = FindHandCard(seed.Card.CardId, seed.ForcedArrow);
                Card card = uiCard != null ? uiCard.BoundCard : null;
                if (card == null)
                {
                    Debug.LogError(
                        $"[TutorialShowcaseSequence] 실제 손패 카드가 없습니다 — {seed.Card.CardId}");
                    AbortShowcase();
                    return;
                }

                // 배치 전에 화살표가 어디로 신호를 보낼지 잠깐 보여준다.
                grid.ShowPlacementPreview(card, seed.Position, canPlace: true);
                await DelayAsync(_previewBeatSeconds, token);
                grid.ClearPlacementPreview();

                await MoveHandCardToSlotAsync(uiCard, grid, seed.Position, token);
                PunchSlot(grid, seed.Position);
                PlayPlaceSfx();

                // 실제 배치가 확정되는 즉시 손패 이미지를 회수하고, 체인 완료까지는 계속 대기한다.
                uiCard.Initialize(_dimmedHand);
                bool placed = await battle.PlaceCardWithChainForTutorialAsync(
                    card,
                    seed.Position,
                    uiCard.ConfirmPlaced);
                if (!placed)
                {
                    Debug.LogError(
                        $"[TutorialShowcaseSequence] 시연 배치 실패 — {seed.Card.CardId} @ {seed.Position}");
                    uiCard.SetInteractable(true);
                    uiCard.SetRaycastTarget(true);
                    _dimmedHand?.RefreshLayout();
                    AbortShowcase();
                    return;
                }

                // 체인 중 적이 죽었다면(밸런스 오류) 남은 시연을 중단한다.
                if (!battle.IsBattleActive) return;

                // 체인 처리(IsProcessing)가 끝나며 전투 UI 가 잠금을 되돌렸을 수 있어 재잠금.
                _endTurnLockedUI?.SetEndTurnInteractable(false);
                _endTurnLockedUI?.SetSkillPanelInteractable(false);

                await DelayAsync(seed.DelayAfter, token);
            }

            // 6) 피날레: 지정 슬롯 마커 + 대사 → 가짜 카드 안내 후 그 칸만 연다.
            grid.SetTutorialTargetMarker(_showcase.PlayerSlot, _showcase.MarkerColor);
            await ShowMentAsync(
                _showcase.FinalTitleKey,
                _showcase.FinalBodyKey,
                token,
                allowReplayAfterClose: true);

            battle.OnCardPlaced += HandlePlayerCardPlaced;
            _placedHandlerAttached = true;

            battle.SetPlacementLocked(false);
            battle.SetAllowedPlacementPosition(_showcase.PlayerSlot);
            _dimmedHand?.SetDimmed(false);
            ReleaseBattlePointerInput();
            StartGuideCard();
            ReleaseForcedInputBlock();
        }
        catch (OperationCanceledException)
        {
            // 씬 이탈/파괴 — 정상 종료.
        }
    }

    /// <summary>유저가 지정 슬롯에 시동 카드를 놓는 순간 — 제한·마커·턴 종료 잠금을 정리한다.</summary>
    private void HandlePlayerCardPlaced(Card card, Vector2Int position)
    {
        if (_showcase == null || position != _showcase.PlayerSlot) return;

        if (TutorialDirector.Active != null)
            TutorialDirector.Active.ClearReplayGuide();
        StopGuideCard();
        AcquireForcedInputBlock();
        _awaitingEnemyEscape = true;

        // 마지막 한 수의 체인이 적을 처치하면 마무리 안내가 이어진다.
        // 보상창이 그 안내를 기다리도록 배치 시점(전투 종료 전)에 미리 켠다.
        _outroPending = !string.IsNullOrEmpty(_showcase.OutroBodyKey);

        if (BattleManager.HasInstance)
            BattleManager.Instance.SetAllowedPlacementPosition(null);
        if (GridManager.HasInstance)
            GridManager.Instance.ClearTutorialTargetMarker();

        DetachPlacedHandler();
    }

    /// <summary>2페이즈 전환 완료 후 첫 행동 직전에 부엉이 안내가 닫힐 때까지 전투를 정지한다.</summary>
    private async UniTask HandleBeforeEnemyActionAsync(
        int enemyTurn,
        int intentOrder,
        CancellationToken token)
    {
        if (!_awaitingEnemyEscape || _reviveDialogueShown || !BattleManager.HasInstance)
            return;
        if (BattleManager.Instance.CurrentEnemyPhaseIndex < 1)
            return;

        _reviveDialogueShown = true;
        await ShowMentAsync(
            _showcase.IntroTitleKey,
            _showcase.ReviveBodyKey,
            token);
    }

    /// <summary>2페이즈 첫 행동이 모두 끝난 직후 적을 퇴장시키고 승리 처리한다.</summary>
    private async UniTask HandleAfterEnemyActionAsync(
        int enemyTurn,
        int intentOrder,
        CancellationToken token)
    {
        if (!_awaitingEnemyEscape || !BattleManager.HasInstance)
            return;
        if (BattleManager.Instance.CurrentEnemyPhaseIndex < 1)
            return;

        _awaitingEnemyEscape = false;
        if (BattleController.HasInstance)
        {
            bool escaped = await BattleController.Instance.PlayTutorialEnemyEscapeVictoryAsync(
                _enemyExitDuration,
                token);
            if (!escaped && !token.IsCancellationRequested)
                AbortShowcase();
            return;
        }

        Debug.LogError("[TutorialShowcaseSequence] BattleController가 없어 적 퇴장 연출을 실행할 수 없습니다.");
        AbortShowcase();
    }

    /// <summary>전투 종료 — 남은 제한·연출을 보험으로 정리하고, 승리면 마무리 안내를 띄운다.</summary>
    private void HandleBattleEnded(bool victory)
    {
        ReleaseRestrictions();
        DetachBattleHandlers();

        if (victory && _outroPending)
        {
            AcquireForcedInputBlock();
            ShowOutroAsync().Forget();
        }
        else
            _outroPending = false;
    }

    /// <summary>시연 승리 마무리 안내 표시. 어떤 경로로 끝나든 대기 플래그를 반드시 내린다.</summary>
    private async UniTaskVoid ShowOutroAsync()
    {
        if (_cts == null)
        {
            _outroPending = false;
            return;
        }

        try
        {
            await ShowMentAsync(_showcase.OutroTitleKey, _showcase.OutroBodyKey, _cts.Token);
        }
        catch (OperationCanceledException)
        {
            // 씬 이탈/파괴 — 정상 종료.
        }
        finally
        {
            ReleaseForcedInputBlock();
            _outroPending = false;
        }
    }

    // ─────────────────────────────────────────────
    // 정리·유틸
    // ─────────────────────────────────────────────

    private void ReleaseRestrictions()
    {
        StopGuideCard();
        ReleaseForcedInputBlock();
        ReleaseBattlePointerInput();
        _awaitingEnemyEscape = false;

        if (BattleManager.HasInstance)
        {
            BattleManager.Instance.SetPlacementLocked(false);
            BattleManager.Instance.SetAllowedPlacementPosition(null);
        }

        if (GridManager.HasInstance)
            GridManager.Instance.ClearTutorialTargetMarker();

        if (_dimmedHand != null)
        {
            _dimmedHand.SetDimmed(false);
            _dimmedHand = null;
        }

        RestoreEndTurn();
    }

    /// <summary>시연 중 잠근 턴 종료·스킬 패널 복원. 전투 UI 의 자체 갱신과 충돌하지 않게 1회만.</summary>
    private void RestoreEndTurn()
    {
        if (_endTurnLockedUI == null) return;
        _endTurnLockedUI.SetEndTurnInteractable(true);
        _endTurnLockedUI.SetSkillPanelInteractable(true);
        _endTurnLockedUI = null;
    }

    private void DetachBattleHandlers()
    {
        if (BattleManager.HasInstance)
        {
            BattleManager.Instance.OnBattleEnded -= HandleBattleEnded;
            if (_enemyActionHandlerAttached)
            {
                BattleManager.Instance.OnBeforeEnemyActionAsync -= HandleBeforeEnemyActionAsync;
                BattleManager.Instance.OnAfterEnemyActionAsync -= HandleAfterEnemyActionAsync;
            }
        }
        _enemyActionHandlerAttached = false;
        DetachPlacedHandler();
    }

    private void DetachPlacedHandler()
    {
        if (!_placedHandlerAttached) return;
        if (BattleManager.HasInstance)
            BattleManager.Instance.OnCardPlaced -= HandlePlayerCardPlaced;
        _placedHandlerAttached = false;
    }

    private void AcquireForcedInputBlock(bool allowEscape = false)
    {
        if (_isForcedInputBlocked || !InputManager.HasInstance) return;
        InputManager.Instance.PushInputBlock();
        if (!allowEscape)
        {
            InputManager.Instance.PushEscapeBlock();
            _isEscapeBlocked = true;
        }
        _isForcedInputBlocked = true;
    }

    private void ReleaseForcedInputBlock()
    {
        if (!_isForcedInputBlocked) return;
        if (InputManager.HasInstance)
        {
            if (_isEscapeBlocked)
                InputManager.Instance.PopEscapeBlock();
            InputManager.Instance.PopInputBlock();
        }
        _isEscapeBlocked = false;
        _isForcedInputBlocked = false;
    }

    private void BlockBattlePointerInput()
    {
        UIBattle battleUI = ResolveBattleUI();
        if (battleUI == null) return;

        _dimmedHand = battleUI.CardHand;
        _dimmedHand?.DeselectCurrent();
        _endTurnLockedUI = battleUI;
        _endTurnLockedUI.SetEndTurnInteractable(false);
        _endTurnLockedUI.SetSkillPanelInteractable(false);

        if (_disabledBattleRaycaster != null) return;

        GraphicRaycaster raycaster = battleUI.GetComponentInParent<GraphicRaycaster>();
        if (raycaster != null && raycaster.enabled)
        {
            raycaster.enabled = false;
            _disabledBattleRaycaster = raycaster;
        }
    }

    private void ReleaseBattlePointerInput()
    {
        if (_disabledBattleRaycaster == null) return;
        _disabledBattleRaycaster.enabled = true;
        _disabledBattleRaycaster = null;
    }

    private void AbortShowcase()
    {
        _outroPending = false;
        ReleaseRestrictions();
        DetachBattleHandlers();
    }

    private UICard FindHandCard(
        string cardId,
        ECardDirection forcedArrow = ECardDirection.None)
    {
        if (_dimmedHand == null || string.IsNullOrEmpty(cardId))
            return null;

        IReadOnlyList<UICard> cards = _dimmedHand.Cards;
        for (int i = 0; i < cards.Count; i++)
        {
            UICard uiCard = cards[i];
            if (uiCard != null
                && uiCard.BoundCard != null
                && uiCard.BoundCard.CardId == cardId
                && (forcedArrow == ECardDirection.None
                    || uiCard.BoundCard.Arrow.Current == forcedArrow))
            {
                return uiCard;
            }
        }
        return null;
    }

    private async UniTask MoveHandCardToSlotAsync(
        UICard uiCard,
        GridManager grid,
        Vector2Int position,
        CancellationToken token)
    {
        GridSlot slot = grid.GetSlot(position);
        if (uiCard == null || slot == null) return;

        // UICard의 손패 자세 자동 복귀를 잠시 끊고 연출 트윈이 위치를 전담한다.
        uiCard.Initialize(null);
        uiCard.SetRaycastTarget(false);
        uiCard.SetInteractable(false);
        RectTransform cardRect = uiCard.GetRectTransform();
        cardRect.DOKill();
        cardRect.SetAsLastSibling();
        cardRect.localRotation = Quaternion.identity;
        await cardRect
            .DOMove(ResolveCanvasWorldPosition(slot.transform.position), _cardMoveDuration)
            .SetEase(Ease.InOutCubic)
            .SetUpdate(true)
            .AsUniTask(token);
    }

    private void StartGuideCard()
    {
        StopGuideCard();
        if (_dimmedHand == null || _dimmedHand.CardPrefab == null || !PoolManager.HasInstance)
            return;

        UICard actualCard = null;
        IReadOnlyList<CardDataSO> playerDeck = _showcase.PlayerDeck;
        for (int i = 0; i < playerDeck.Count && actualCard == null; i++)
        {
            if (playerDeck[i] != null)
                actualCard = FindHandCard(playerDeck[i].CardId);
        }
        if (actualCard == null || actualCard.BoundCard == null)
            return;

        _guideCard = PoolManager.Instance.Spawn(_dimmedHand.CardPrefab, _dimmedHand.transform);
        if (_guideCard == null) return;

        _guideCard.Initialize(null);
        _guideCard.Bind(actualCard.BoundCard);
        _guideCard.SetRaycastTarget(false);
        _guideCard.SetInteractable(false);
        _guideCts = CancellationTokenSource.CreateLinkedTokenSource(_cts.Token);
        PlayGuideLoopAsync(actualCard, _guideCts.Token).Forget();
    }

    private async UniTaskVoid PlayGuideLoopAsync(UICard actualCard, CancellationToken token)
    {
        try
        {
            GridSlot slot = GridManager.HasInstance
                ? GridManager.Instance.GetSlot(_showcase.PlayerSlot)
                : null;
            if (slot == null) return;

            RectTransform guideRect = _guideCard.GetRectTransform();
            CanvasGroup guideCanvasGroup = _guideCard.GetComponent<CanvasGroup>();
            while (!token.IsCancellationRequested && actualCard != null && _guideCard != null)
            {
                guideRect.DOKill();
                guideRect.position = actualCard.GetRectTransform().position;
                guideRect.localRotation = Quaternion.identity;
                guideRect.localScale = Vector3.one;
                _guideCard.SetVisualVisible(true);
                if (guideCanvasGroup != null)
                    guideCanvasGroup.alpha = GuideCardAlpha;
                _guideCard.SetRaycastTarget(false);
                _guideCard.SetInteractable(false);

                await guideRect
                    .DOMove(ResolveCanvasWorldPosition(slot.transform.position), _cardMoveDuration)
                    .SetEase(Ease.InOutCubic)
                    .SetUpdate(true)
                    .AsUniTask(token);

                _guideCard.SetVisualVisible(false);
                await DelayAsync(_guideLoopPauseSeconds, token);
            }
        }
        catch (OperationCanceledException)
        {
            // 정상 종료.
        }
    }

    private void StopGuideCard()
    {
        _guideCts?.Cancel();
        _guideCts?.Dispose();
        _guideCts = null;

        if (_guideCard == null) return;
        _guideCard.GetRectTransform().DOKill();
        _guideCard.ReturnToPoolOrDestroy();
        _guideCard = null;
    }

    private static Vector3 ResolveCanvasWorldPosition(Vector3 worldPosition)
    {
        Canvas canvas = UIManager.HasInstance ? UIManager.Instance.RootCanvas : null;
        Camera worldCamera = Camera.main;
        RectTransform canvasRect = canvas != null ? canvas.transform as RectTransform : null;
        if (canvas == null || worldCamera == null || canvasRect == null)
            return worldPosition;

        Vector2 screenPoint = RectTransformUtility.WorldToScreenPoint(worldCamera, worldPosition);
        Camera uiCamera = canvas.renderMode == RenderMode.ScreenSpaceOverlay ? null : canvas.worldCamera;
        return RectTransformUtility.ScreenPointToWorldPointInRectangle(
            canvasRect,
            screenPoint,
            uiCamera,
            out Vector3 canvasWorld)
            ? canvasWorld
            : worldPosition;
    }

    /// <summary>대사 모달 표시. 본문 키가 비어 있으면 생략한다.</summary>
    private async UniTask ShowMentAsync(
        string titleKey,
        string bodyKey,
        CancellationToken token,
        object[] formatArgs = null,
        bool allowReplayAfterClose = false)
    {
        if (string.IsNullOrEmpty(bodyKey) || !UIManager.HasInstance) return;

        UITutorialPanel panel = await UIManager.Instance.OpenAsync<UITutorialPanel>(token);
        if (panel == null)
        {
            Debug.LogError("[TutorialShowcaseSequence] 대사 패널 열기 실패 — 대사를 생략합니다.");
            return;
        }

        var pages = new List<TutorialPageContent>(1)
        {
            new TutorialPageContent(
                bodyKey, null, EPanelPlacement.Bottom, _mentAnchorIds, formatArgs),
        };
        await panel.ShowStepAsync(
            titleKey,
            pages,
            token,
            allowReplayAfterClose: allowReplayAfterClose);
    }

    private async UniTask ShowBlockedMentAsync(
        string bodyKey,
        object[] formatArgs,
        CancellationToken token)
    {
        AcquireForcedInputBlock();
        try
        {
            await ShowMentAsync(_showcase.IntroTitleKey, bodyKey, token, formatArgs);
        }
        finally
        {
            ReleaseForcedInputBlock();
        }
    }

    private static bool IsTutorialPanelOpen()
    {
        if (!UIManager.HasInstance) return false;
        return UIManager.Instance.IsOpen<UITutorialPanel>()
            || UIManager.Instance.IsOpen<UITutorialIllustPanel>();
    }

    private static UIBattle ResolveBattleUI()
    {
        return UIManager.HasInstance ? UIManager.Instance.Get<UIBattle>() : null;
    }

    /// <summary>일반 배치와 동일한 배치음 재생 (CardZoneController.OnCardPlayedToField 참고).</summary>
    private static void PlayPlaceSfx()
    {
        if (AudioManager.HasInstance)
            AudioManager.Instance.PlaySfxAsync(AudioKeys.Card.PLACE).Forget();
    }

    private void PunchSlot(GridManager grid, Vector2Int position)
    {
        if (_placePunchScale <= 0f) return;

        GridSlot slot = grid.GetSlot(position);
        if (slot == null) return;

        slot.transform
            .DOPunchScale(Vector3.one * _placePunchScale, _placePunchDuration, vibrato: 6)
            .SetLink(slot.gameObject);
    }

    private static async UniTask DelayAsync(float seconds, CancellationToken token)
    {
        if (seconds <= 0f) return;
        await UniTask.Delay(
            TimeSpan.FromSeconds(seconds),
            DelayType.UnscaledDeltaTime,
            cancellationToken: token);
    }
}
