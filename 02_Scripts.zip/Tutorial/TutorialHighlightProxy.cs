// =================================================================
// [스크립트 목적]  튜토리얼 패널 안의 프록시(사본) 강조 오브젝트 마커.
//                 딤 위에 그려질 아이콘·화살표 묶음의 루트에 부착한다.
// [주요 변수]      - _anchorId        : 대응하는 실물 TutorialAnchor 의 ID
//                  - _matchAnchorSize : 실물 크기까지 복사할지 (기본 꺼짐 — 프리팹 크기 유지)
// [의존 관계]      - UITutorialPanel(자식에서 자동 수집, 표시 중 위치 동기화)
// [배치]           UITutorialPanel 프리팹의 HighlightRoot 아래에 프록시 루트로 부착,
//                  기본 비활성. 화살표·아이콘은 이 오브젝트의 자식으로 자유 구성.
// [설계 노트]      - 위치는 매 프레임 실물에서 복사(런타임 동기화) — 프리팹에 손배치한
//                    위치가 실물과 어긋나는 이중 관리 문제를 없앤다.
// =================================================================

using UnityEngine;

/// <summary>
/// 딤 위에 표시될 프록시 강조 묶음(아이콘+화살표)의 루트 마커.
/// UITutorialPanel 이 스텝의 AnchorIds 와 매칭해 활성화하고 실물 위치로 옮긴다.
/// </summary>
public sealed class TutorialHighlightProxy : MonoBehaviour
{
    [Tooltip("대응하는 실물 TutorialAnchor 의 ID (같은 문자열이어야 매칭)")]
    [SerializeField] private string _anchorId;

    [Tooltip("켜면 실물 RectTransform 의 크기까지 복사. 끄면 프리팹에 지정한 크기 유지")]
    [SerializeField] private bool _matchAnchorSize = false;

    [Tooltip("켜면 실물 TutorialAnchor 없이도 프리팹에 배치한 위치 그대로 표시. " +
             "고정 위치 화살표·장식 등 실물 추적이 필요 없는 요소용 (위치 자동 추적 없음)")]
    [SerializeField] private bool _showWithoutAnchor = false;

    public string AnchorId => _anchorId;
    public bool MatchAnchorSize => _matchAnchorSize;
    public bool ShowWithoutAnchor => _showWithoutAnchor;

    /// <summary>프록시 루트 RectTransform.</summary>
    public RectTransform Rect => transform as RectTransform;
}
