// =================================================================
// [스크립트 목적]  튜토리얼 보스전 "멘토 시연" 각본 데이터 (SO).
//                 손패에서 순서대로 배치할 카드 + 유저 지정 슬롯 + 시동 덱 + 대사 키.
// [주요 변수]      - _seeds      : 시연 배치 목록 (리스트 순서 = 배치 순서)
//                  - _playerSlot : 유저가 시동 카드를 놓을 지정 슬롯 (마커 + 유일 해제)
//                  - _playerDeck : 보스전 유저 덱 (보통 시동 카드 1장 → 첫 손패 고정)
// [의존 관계]      - TutorialShowcaseSequence(시연 구동) / InGameController(덱 배선)
// [설계 노트]      - 시연 배치는 실제 손패 카드로 정상 체인 파이프라인을 탄다 — 장마다 체인 발동
//                    (BattleManager.PlaceCardWithChainForTutorialAsync).
//                    유저의 시동 카드만 완전한 정상 경로(마나 차감 포함)를 탄다.
//                  - ForcedArrow 로 랜덤 화살표 카드의 방향을 각본에 고정할 수 있다.
//                  - 그리드 크기·마나는 TutorialStageData/TutorialPlayerStatConfig 가
//                    이미 관리하므로 여기 두지 않는다 (중복 금지).
//                  - 화면 텍스트는 StringChart 키로만 관리 (프로젝트 관례).
// =================================================================

using System;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// 튜토리얼 보스전 멘토 시연 각본.
/// 손패에서 한 장씩 자동 배치할 설계(시드)와 유저가 마지막 한 수를 둘 슬롯, 대사 키를 담는다.
/// </summary>
[CreateAssetMenu(fileName = "TutorialBossShowcase", menuName = "Tutorial/BossShowcase")]
public sealed class TutorialBossShowcaseSO : ScriptableObject
{
    /// <summary>멘토 시연 배치 1건 (카드 + 좌표 + 연출 간격).</summary>
    [Serializable]
    public sealed class ShowcaseSeed
    {
        [Tooltip("배치할 카드 데이터")]
        [SerializeField] private CardDataSO _card;

        [Tooltip("배치할 그리드 좌표")]
        [SerializeField] private Vector2Int _position;

        [Tooltip("강화 상태로 생성할지 여부")]
        [SerializeField] private bool _upgraded;

        [Tooltip("화살표 방향 강제 (None=카드 기본 방향 사용). " +
                 "랜덤 화살표 카드도 각본대로 고정할 수 있다 (비트 동시 지정 가능)")]
        [SerializeField] private ECardDirection _forcedArrow = ECardDirection.None;

        [Tooltip("이 카드 배치 후 다음 배치까지의 간격(초)")]
        [Min(0f)]
        [SerializeField] private float _delayAfter = 0.8f;

        public CardDataSO Card => _card;
        public Vector2Int Position => _position;
        public bool Upgraded => _upgraded;
        public ECardDirection ForcedArrow => _forcedArrow;
        public float DelayAfter => _delayAfter;
    }

    [Header("시연 배치 (리스트 순서 = 배치 순서)")]
    [Tooltip("멘토가 순서대로 놓을 카드들. 정상 배치처럼 장마다 체인이 즉시 발동한다")]
    [SerializeField] private List<ShowcaseSeed> _seeds = new List<ShowcaseSeed>();

    [Header("피날레")]
    [Tooltip("유저가 시동 카드를 놓을 지정 슬롯. 마커가 표시되고 이 칸만 배치가 허용된다")]
    [SerializeField] private Vector2Int _playerSlot;

    [Tooltip("지정 슬롯 마커 색 (기존 프리뷰 색과 구분: 경로=노랑/배치=초록/보존=시안/스킬=분홍)")]
    [SerializeField] private Color _markerColor = new Color(1f, 0.75f, 0.1f, 1f);

    [Tooltip("보스전 유저 덱 (카드 SO 직접 지정). 보통 시동 카드 1장 — 첫 손패가 자동 고정된다.\n" +
             "시동 카드는 비용을 기본 마나 이하로, 방향은 화살표 고정 변형 카드" +
             "(예: Magic_Bolt_Right)로 지정해 각본 방향을 보장할 것")]
    [SerializeField] private List<CardDataSO> _playerDeck = new List<CardDataSO>();

    [Header("대사 (StringChart 키 — 비우면 해당 안내 생략)")]
    [Tooltip("시연 시작 안내 제목 키 (예: \"잘 봐라\")")]
    [SerializeField] private string _introTitleKey;

    [Tooltip("시연 시작 안내 본문 키")]
    [SerializeField] private string _introBodyKey;

    [Tooltip("피날레 안내 제목 키 (예: \"마지막 한 수\")")]
    [SerializeField] private string _finalTitleKey;

    [Tooltip("피날레 안내 본문 키 (예: \"여기에 놓아라\")")]
    [SerializeField] private string _finalBodyKey;

    [Tooltip("보스 2페이즈 전환 완료 후 첫 행동 직전 안내 본문 키")]
    [SerializeField] private string _reviveBodyKey;

    [Tooltip("시연 승리 직후(보상창 전) 마무리 안내 제목 키 (예: \"시범 완료\")")]
    [SerializeField] private string _outroTitleKey;

    [Tooltip("시연 승리 직후 마무리 안내 본문 키 (예: \"다음 전투에서 자세히\")")]
    [SerializeField] private string _outroBodyKey;

    [Tooltip("첫 전투 보상창이 열린 직후 안내 본문 키")]
    [SerializeField] private string _rewardBodyKey;

    [Tooltip("첫 카드 보상 선택창이 열린 직후 안내 본문 키")]
    [SerializeField] private string _cardSelectBodyKey;

    public IReadOnlyList<ShowcaseSeed> Seeds => _seeds;
    public Vector2Int PlayerSlot => _playerSlot;
    public Color MarkerColor => _markerColor;
    public IReadOnlyList<CardDataSO> PlayerDeck => _playerDeck;
    public string IntroTitleKey => _introTitleKey;
    public string IntroBodyKey => _introBodyKey;
    public string FinalTitleKey => _finalTitleKey;
    public string FinalBodyKey => _finalBodyKey;
    public string ReviveBodyKey => _reviveBodyKey;
    public string OutroTitleKey => _outroTitleKey;
    public string OutroBodyKey => _outroBodyKey;
    public string RewardBodyKey => _rewardBodyKey;
    public string CardSelectBodyKey => _cardSelectBodyKey;

    /// <summary>시연 카드와 유저의 마지막 카드를 합친 첫 전투 덱을 만든다.</summary>
    public IReadOnlyList<CardDataSO> CreateBattleDeck()
    {
        var deck = new List<CardDataSO>(_seeds.Count + _playerDeck.Count);
        for (int i = 0; i < _seeds.Count; i++)
        {
            CardDataSO card = _seeds[i]?.Card;
            if (card != null)
                deck.Add(card);
        }

        for (int i = 0; i < _playerDeck.Count; i++)
        {
            if (_playerDeck[i] != null)
                deck.Add(_playerDeck[i]);
        }
        return deck;
    }

    /// <summary>CreateBattleDeck 결과와 같은 순서의 최초 화살표 방향을 만든다.</summary>
    public IReadOnlyList<ECardDirection> CreateBattleDeckForcedArrows()
    {
        var directions = new List<ECardDirection>(_seeds.Count + _playerDeck.Count);
        for (int i = 0; i < _seeds.Count; i++)
        {
            ShowcaseSeed seed = _seeds[i];
            if (seed?.Card != null)
                directions.Add(seed.ForcedArrow);
        }

        for (int i = 0; i < _playerDeck.Count; i++)
        {
            if (_playerDeck[i] != null)
                directions.Add(ECardDirection.None);
        }
        return directions;
    }

#if UNITY_EDITOR
    private void OnValidate()
    {
        var used = new HashSet<Vector2Int>();
        for (int i = 0; i < _seeds.Count; i++)
        {
            ShowcaseSeed seed = _seeds[i];
            if (seed == null) continue;

            if (seed.Card == null)
                Debug.LogWarning($"[{name}] 시드 {i}: 카드가 비어 있습니다.", this);

            if (!used.Add(seed.Position))
                Debug.LogWarning($"[{name}] 시드 {i}: 좌표 {seed.Position} 가 중복됩니다.", this);

            if (seed.Position == _playerSlot)
                Debug.LogWarning($"[{name}] 시드 {i}: 유저 지정 슬롯 {_playerSlot} 을 침범합니다.", this);
        }

        if (_playerDeck.Count == 0)
            Debug.LogWarning($"[{name}] 유저 덱이 비어 있습니다 — 시동 카드를 1장 이상 지정하세요.", this);
    }
#endif
}
