// =================================================================
// [스크립트 목적]  튜토리얼 시스템 공용 타입 정의 (트리거 enum + 스텝/페이지 데이터)
// [주요 변수]      - ETutorialTrigger : 스텝을 발동시키는 게임 이벤트 종류
//                  - TutorialStep     : 트리거 1개 + 안내 페이지 목록
//                  - TutorialPage     : 안내 본문 1페이지 (로컬라이즈 키)
// [의존 관계]      - TutorialScriptSO(스텝 목록 보관) / TutorialDirector(트리거 매칭)
// [설계 노트]      - 화면 텍스트는 StringChart 키로만 관리한다.
//                    규칙이 바뀌어도 데이터만 고치면 되도록 코드와 분리.
// =================================================================

using System;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// 튜토리얼 스텝을 발동시키는 게임 이벤트 종류.
/// TutorialDirector 가 EventManager 이벤트를 이 트리거로 변환해 스텝을 매칭한다.
/// </summary>
public enum ETutorialTrigger
{
    /// <summary>미지정 (발동 안 함).</summary>
    None = 0,

    /// <summary>노드맵이 표시되어 노드를 선택할 수 있게 됨 (OnMapPresented).</summary>
    MapPresented = 1,

    /// <summary>일반/엘리트 전투 진입 완료 (OnBattleNodeEntered, Boss 제외).</summary>
    BattleEntered = 2,

    /// <summary>보스 전투 진입 완료 (OnBattleNodeEntered, Boss).</summary>
    BossBattleEntered = 3,

    /// <summary>상점 노드 진입 (OnMapNodeEntered, Shop).</summary>
    ShopEntered = 4,

    /// <summary>휴식 노드 진입 (OnMapNodeEntered, Rest).</summary>
    RestEntered = 5,

    /// <summary>턴 종료 후 보존 선택 페이즈 시작 (BattleManager.OnPhaseChanged, PreserveSelect).</summary>
    PreserveSelectStarted = 8,

    /// <summary>보스 전투 승리 (BattleManager.OnBattleEnded, victory + 보스 노드).</summary>
    BossDefeated = 9,
}

/// <summary>
/// 안내 패널의 화면 배치 프리셋. 스텝이 설명하는 대상을 가리지 않는 위치를
/// 대본 작성자가 스텝별로 선택한다 (패널 크기는 고정, 위치만 변경).
/// </summary>
public enum EPanelPlacement
{
    /// <summary>화면 중앙 (기본).</summary>
    Center = 0,

    /// <summary>하단 중앙 — 그리드/중앙 요소 설명용.</summary>
    Bottom = 1,

    /// <summary>상단 중앙 — 하단 손패/버튼 설명용.</summary>
    Top = 2,

    /// <summary>좌측 중앙 — 우측 요소 설명용.</summary>
    Left = 3,

    /// <summary>우측 중앙 — 좌측 요소 설명용.</summary>
    Right = 4,
}

/// <summary>안내 본문 1페이지. 본문은 StringChart 키로 조회한다.</summary>
[Serializable]
public sealed class TutorialPage
{
    [Tooltip("본문 로컬라이즈 키 (StringChart)")]
    public string BodyKey;

    [Tooltip("이 페이지의 삽화 (선택). 있으면 삽화 패널(UITutorialIllustPanel), " +
             "없으면 텍스트 패널로 표시된다. 페이지 순서가 곧 패널 연출 순서")]
    public Sprite Image;

    [Tooltip("이 페이지의 패널 표시 위치. 설명 대상을 가리지 않는 곳으로 선택")]
    public EPanelPlacement Placement = EPanelPlacement.Center;

    [Tooltip("이 페이지에서 강조할 실물 UI 의 TutorialAnchor ID 목록. " +
             "패널의 같은 ID 프록시가 그 위치에 표시된다. 씬에 없는 앵커는 조용히 생략")]
    public List<string> AnchorIds = new List<string>();
}

/// <summary>
/// 패널에 전달할 페이지 내용(본문 키 + 삽화 + 배치 + 강조 대상).
/// </summary>
public readonly struct TutorialPageContent
{
    public readonly string BodyKey;
    public readonly object[] FormatArgs;
    public readonly Sprite Image;
    public readonly EPanelPlacement Placement;
    public readonly IReadOnlyList<string> AnchorIds;

    public TutorialPageContent(
        string bodyKey,
        Sprite image,
        EPanelPlacement placement,
        IReadOnlyList<string> anchorIds,
        object[] formatArgs = null)
    {
        BodyKey = bodyKey;
        FormatArgs = formatArgs;
        Image = image;
        Placement = placement;
        AnchorIds = anchorIds;
    }
}

/// <summary>
/// 튜토리얼 스텝 1개 = 트리거 + 제목 + 본문 페이지 목록.
/// 같은 트리거의 스텝이 여러 개면 스크립트 순서대로 하나씩 소비된다.
/// </summary>
[Serializable]
public sealed class TutorialStep
{
    [Tooltip("이 스텝을 발동시키는 게임 이벤트")]
    public ETutorialTrigger Trigger = ETutorialTrigger.None;

    [Tooltip("제목 로컬라이즈 키 (StringChart)")]
    public string TitleKey;

    [Tooltip("켜면 1회 표시 후 다시 발동하지 않음. 끄면 트리거마다 반복 표시")]
    public bool ShowOnce = true;

    [Tooltip("안내 본문 페이지 목록 (순서대로 넘겨 봄)")]
    public List<TutorialPage> Pages = new List<TutorialPage>();
}
