// =================================================================
// [스크립트 목적]  튜토리얼 진행 감독. EventManager 이벤트를 구독해 대본(TutorialScriptSO)의
//                 스텝을 트리거 순서대로 소비하고, UITutorialPanel 로 안내를 표시한다.
// [주요 변수]      - _script   : 튜토리얼 대본 SO (트리거+안내문 목록)
//                  - _consumed : 소비된 스텝 인덱스 (ShowOnce 스텝 재발동 방지)
//                  - _pending  : 표시 대기 큐 (패널 표시 중 도착한 트리거 보존)
// [의존 관계]      - EventManager(OnMapRevealed/OnMapNodeEntered/OnBattleNodeEntered 구독)
//                  - UIManager + UITutorialPanel(표시·로컬라이즈 키 해석)
// [배치]           Tutorial 씬에 빈 GameObject 만들고 부착 + 대본 SO 지정
// [설계 노트]      - 게임 로직을 전혀 건드리지 않는 순수 관전자(구독자).
//                    본 게임 씬에는 이 컴포넌트가 없으므로 이벤트는 발행돼도 무해하다.
//                  - 트리거 1회당 스텝 1개만 소비 — 같은 트리거 스텝이 여러 개면
//                    발동 순서대로 하나씩 표시된다 (첫 전투/두 번째 전투 안내 분리 가능).
// =================================================================

using System;
using System.Collections.Generic;
using System.Threading;
using Cysharp.Threading.Tasks;
using UnityEngine;

/// <summary>
/// 튜토리얼 씬의 진행 감독. 게임 이벤트를 구독해 대본 스텝을 매칭하고
/// 안내 패널(UITutorialPanel)을 순서대로 표시한다. 게임 로직에는 관여하지 않는다.
/// </summary>
public sealed class TutorialDirector : MonoBehaviour
{
    [Header("대본")]
    [Tooltip("이 씬에서 실행할 튜토리얼 대본")]
    [SerializeField] private TutorialScriptSO _script;

    [Header("표시 타이밍")]
    [Tooltip("트리거 발동 후 안내 표시까지의 기본 지연(초). 아래 재정의 목록에 없는 " +
             "트리거에 적용. 0이면 즉시 표시")]
    [Min(0f)]
    [SerializeField] private float _showDelaySeconds = 0.5f;

    [Tooltip("트리거별 지연 재정의. 상점·휴식은 팝업 열림을 이미 감지하므로 짧게 잡는 식으로 " +
             "개별 튜닝. 단 지도(MapPresented)는 OnMapRevealed 시점에 즉시 표시로 고정되어 " +
             "여기 값이 무시된다 (GetShowDelay 참고)")]
    [SerializeField] private TriggerDelayOverride[] _delayOverrides = new TriggerDelayOverride[]
    {
        new TriggerDelayOverride { Trigger = ETutorialTrigger.BattleEntered, Seconds = 0.2f },
        new TriggerDelayOverride { Trigger = ETutorialTrigger.BossBattleEntered, Seconds = 0.2f },
        new TriggerDelayOverride { Trigger = ETutorialTrigger.ShopEntered, Seconds = 0.15f },
        new TriggerDelayOverride { Trigger = ETutorialTrigger.RestEntered, Seconds = 0.15f },
    };

    /// <summary>트리거 1종의 표시 지연 재정의 항목.</summary>
    [Serializable]
    private struct TriggerDelayOverride
    {
        [Tooltip("대상 트리거")]
        public ETutorialTrigger Trigger;

        [Tooltip("이 트리거의 표시 지연(초)")]
        [Min(0f)]
        public float Seconds;
    }

    [Tooltip("상점·휴식처럼 트리거보다 늦게 열리는 화면을 기다리는 최대 시간(초). " +
             "이 시간이 지나면 화면이 안 열렸어도 안내를 표시한다 (안내 유실 방지)")]
    [Min(0f)]
    [SerializeField] private float _contextUiTimeoutSeconds = 3f;

    [Tooltip("보스 격파 안내가 '발동조차 하지 않을 때' 런 종료를 기다리는 최대 시간(초). " +
             "안내가 표시 중이면 이 시간은 리셋되어 끝까지 기다린다 (영구 대기 방지)")]
    [Min(0f)]
    [SerializeField] private float _bossDefeatedGuideTimeoutSeconds = 10f;

    private readonly List<IDisposableEvent> _subscriptions = new List<IDisposableEvent>(4);
    private readonly HashSet<int> _consumed = new HashSet<int>();
    private readonly Queue<TutorialStep> _pending = new Queue<TutorialStep>(4);
    private bool _isShowing;
    private bool _lastBattleWasBoss;
    private bool _bossDefeatedTriggered;
    private CancellationTokenSource _cts;
    private bool _hasBossDefeatedGuide;
    private bool _isBossDefeatedGuideDone;
    private readonly List<TutorialPageContent> _replayPages = new List<TutorialPageContent>(4);
    private string _replayTitleKey;
    private Vector3 _replayButtonWorldPosition;
    private bool _hasReplayGuide;
    private bool _isReplayingGuide;

    /// <summary>
    /// 튜토리얼 씬이 살아 있는가. Awake에서 켜지므로 다른 컴포넌트의 Start에서 안전하게 읽을 수 있다.
    /// 튜토리얼도 InGameController로 진짜 런을 돌리므로, 분석 등은 이 플래그로 집계에서 제외한다.
    /// </summary>
    public static bool IsActive { get; private set; }
    public static TutorialDirector Active { get; private set; }
    public event Action ReplayGuideStateChanged;

    public bool CanReplayGuide => _hasReplayGuide
                                  && !_isReplayingGuide
                                  && UIManager.HasInstance
                                  && !UIManager.Instance.IsOpen<UITutorialPanel>()
                                  && !UIManager.Instance.IsOpen<UITutorialIllustPanel>();

    private void Awake()
    {
        IsActive = true;
        Active = this;
        // 튜토리얼은 일반 게임과 세이브 슬롯을 공유하므로, 세션 내내 저장을 억제해
        // 튜토리얼이 기존 이어하기 세이브를 덮어쓰거나 지우지 못하게 한다.
        RunSaveSystem.SuppressPersistence = true;
        _cts = new CancellationTokenSource();
        _hasBossDefeatedGuide = HasStep(ETutorialTrigger.BossDefeated);
        _isBossDefeatedGuideDone = !_hasBossDefeatedGuide;
    }

    /// <summary>
    /// 보스 격파 튜토리얼 안내가 모두 닫힐 때까지 기다린다.
    /// 대본에 스텝이 있어도 구독 실패·이미 소비된 스텝 등으로 안내가 발동하지 못할 수 있으므로,
    /// 표시가 진행되지 않는 동안에만 제한 시간을 세어 런이 영구 대기하지 않게 한다.
    /// </summary>
    public async UniTask WaitForBossDefeatedGuideAsync(CancellationToken token)
    {
        if (_isBossDefeatedGuideDone || !UIManager.HasInstance) return;

        float idleSeconds = 0f;
        while (!_isBossDefeatedGuideDone)
        {
            // 안내가 표시 중이거나 표시 대기 중이면 제한 시간을 리셋해 끝까지 기다린다.
            if (_isShowing || _pending.Count > 0)
                idleSeconds = 0f;
            else
                idleSeconds += Time.unscaledDeltaTime;

            if (idleSeconds >= _bossDefeatedGuideTimeoutSeconds)
            {
                Debug.LogWarning("[TutorialDirector] 보스 격파 안내가 발동하지 않아 대기를 종료합니다.");
                return;
            }

            await UniTask.Yield(PlayerLoopTiming.Update, token);
        }
    }

    /// <summary>
    /// 튜토리얼 보스 승리를 안내 시스템에 직접 통지한다.
    /// BattleManager 이벤트 구독 시점과 관계없이 한 번만 발동한다.
    /// </summary>
    public void NotifyBossDefeated()
    {
        if (_bossDefeatedTriggered) return;

        _bossDefeatedTriggered = true;
        TryFire(ETutorialTrigger.BossDefeated);
    }

    private void Start()
    {
        InitializeAsync().Forget();
    }

    private async UniTaskVoid InitializeAsync()
    {
        // 매니저 준비 완료 대기 (씬 전환 진입 시엔 즉시 통과).
        await BootstrapInitializer.WaitForReadyAsync();
        if (_cts == null || _cts.IsCancellationRequested) return;

        if (_script == null)
        {
            Debug.LogWarning("[TutorialDirector] 대본(TutorialScriptSO)이 지정되지 않았습니다. 안내 없이 진행합니다.");
            return;
        }

        if (!EventManager.HasInstance)
        {
            Debug.LogError("[TutorialDirector] EventManager 가 없어 튜토리얼 트리거를 구독할 수 없습니다.");
            return;
        }

        EventManager em = EventManager.Instance;
        // 지도 안내는 OnMapPresented(안내 화면 뒤에서 준비 완료)가 아니라
        // OnMapRevealed(안내가 걷히고 진입 연출까지 끝나 실제로 보이는 시점)에 발동한다.
        _subscriptions.Add(em.Subscribe<OnMapRevealed>(HandleMapRevealed));
        _subscriptions.Add(em.Subscribe<OnMapNodeEntered>(HandleMapNodeEntered));
        _subscriptions.Add(em.Subscribe<OnBattleNodeEntered>(HandleBattleNodeEntered));

        // 전투 페이즈(보존 선택 등)는 BattleManager C# 이벤트를 직접 구독 (게임 코드 무변경).
        SubscribeBattlePhase();

#if UNITY_EDITOR || DEVELOPMENT_BUILD
        Debug.Log($"[TutorialDirector] 대본 '{_script.ScriptId}' 시작 — 스텝 {_script.Steps.Count}개");
#endif
    }

    private void OnDestroy()
    {
        IsActive = false;
        if (Active == this)
            Active = null;
        // 튜토리얼 세션 종료 — 일반 게임 세이브가 정상 동작하도록 억제를 해제한다.
        RunSaveSystem.SuppressPersistence = false;

        for (int i = 0; i < _subscriptions.Count; i++)
            _subscriptions[i]?.Dispose();
        _subscriptions.Clear();

        if (BattleManager.HasInstance)
        {
            BattleManager.Instance.OnPhaseChanged -= HandleBattlePhaseChanged;
            BattleManager.Instance.OnBattleEnded -= HandleBattleEnded;
        }

        _cts?.Cancel();
        _cts?.Dispose();
        _cts = null;
        ReplayGuideStateChanged = null;
    }

    /// <summary>BattleManager 페이즈·종료 이벤트 구독 (중복 방지 재구독 — 멱등).</summary>
    private void SubscribeBattlePhase()
    {
        if (!BattleManager.HasInstance) return;

        BattleManager.Instance.OnPhaseChanged -= HandleBattlePhaseChanged;
        BattleManager.Instance.OnPhaseChanged += HandleBattlePhaseChanged;
        BattleManager.Instance.OnBattleEnded -= HandleBattleEnded;
        BattleManager.Instance.OnBattleEnded += HandleBattleEnded;
    }

    private void HandleBattlePhaseChanged(EBattlePhase phase)
    {
        ClearReplayGuide();
        if (phase == EBattlePhase.PreserveSelect)
            TryFire(ETutorialTrigger.PreserveSelectStarted);
    }

    public void NotifyTutorialPanelOpened(bool preserveExistingReplay)
    {
        if (!preserveExistingReplay)
            ClearReplayGuide();
        else
            ReplayGuideStateChanged?.Invoke();
    }

    public void NotifyTutorialPanelClosed()
    {
        ReplayGuideStateChanged?.Invoke();
    }

    public void RegisterReplayGuide(
        string titleKey,
        IReadOnlyList<TutorialPageContent> pages,
        Vector3 buttonWorldPosition)
    {
        _replayPages.Clear();
        if (pages != null)
        {
            for (int i = 0; i < pages.Count; i++)
            {
                TutorialPageContent page = pages[i];
                object[] formatArgs = page.FormatArgs != null
                    ? (object[])page.FormatArgs.Clone()
                    : null;
                IReadOnlyList<string> anchorIds = page.AnchorIds != null
                    ? new List<string>(page.AnchorIds)
                    : Array.Empty<string>();
                _replayPages.Add(new TutorialPageContent(
                    page.BodyKey,
                    page.Image,
                    page.Placement,
                    anchorIds,
                    formatArgs));
            }
        }

        _replayTitleKey = titleKey ?? string.Empty;
        _replayButtonWorldPosition = buttonWorldPosition;
        _hasReplayGuide = _replayPages.Count > 0;
        ReplayGuideStateChanged?.Invoke();
    }

    public void ClearReplayGuide()
    {
        if (!_hasReplayGuide && _replayPages.Count == 0) return;

        _hasReplayGuide = false;
        _replayTitleKey = string.Empty;
        _replayPages.Clear();
        ReplayGuideStateChanged?.Invoke();
    }

    public bool TryGetReplayButtonWorldPosition(out Vector3 worldPosition)
    {
        worldPosition = _replayButtonWorldPosition;
        return _hasReplayGuide;
    }

    public void ReplayLatestGuide()
    {
        if (!CanReplayGuide) return;
        ReplayLatestGuideAsync().Forget();
    }

    private async UniTaskVoid ReplayLatestGuideAsync()
    {
        _isReplayingGuide = true;
        ReplayGuideStateChanged?.Invoke();

        try
        {
            UITutorialPanel panel = await UIManager.Instance.OpenAsync<UITutorialPanel>(_cts.Token);
            if (panel == null) return;

            await panel.ShowStepAsync(
                _replayTitleKey,
                new List<TutorialPageContent>(_replayPages),
                _cts.Token,
                isReplayPresentation: true);
        }
        catch (OperationCanceledException)
        {
            // 씬 이탈 중 다시 보기 종료 — 정상 흐름.
        }
        finally
        {
            _isReplayingGuide = false;
            ReplayGuideStateChanged?.Invoke();
        }
    }

    /// <summary>전투 종료 — 보스전 승리면 마무리 멘트 트리거를 발동한다.</summary>
    private void HandleBattleEnded(bool victory)
    {
        if (victory && _lastBattleWasBoss)
            NotifyBossDefeated();
    }

    // ─────────────────────────────────────────────
    // 이벤트 → 트리거 변환
    // ─────────────────────────────────────────────

    private void HandleMapRevealed(OnMapRevealed evt)
    {
        TryFire(ETutorialTrigger.MapPresented);
    }

    private void HandleMapNodeEntered(OnMapNodeEntered evt)
    {
        switch (evt.NodeType)
        {
            case ENodeType.Shop: TryFire(ETutorialTrigger.ShopEntered); break;
            case ENodeType.Rest: TryFire(ETutorialTrigger.RestEntered); break;
        }
    }

    private void HandleBattleNodeEntered(OnBattleNodeEntered evt)
    {
        // 전투 진입 시 페이즈 구독을 보험으로 재확인 (씬 초기화 순서 이슈 대비, 멱등).
        SubscribeBattlePhase();

        _lastBattleWasBoss = evt.NodeType == ENodeType.Boss;
        TryFire(_lastBattleWasBoss
            ? ETutorialTrigger.BossBattleEntered
            : ETutorialTrigger.BattleEntered);
    }

    // ─────────────────────────────────────────────
    // 스텝 매칭 · 표시
    // ─────────────────────────────────────────────

    /// <summary>
    /// 트리거에 대응하는 미소비 스텝을 대본 순서대로 1개 찾아 표시 큐에 넣는다.
    /// ShowOnce 스텝은 즉시 소비 처리해 재발동을 막는다.
    /// </summary>
    private void TryFire(ETutorialTrigger trigger)
    {
        if (_script == null || trigger == ETutorialTrigger.None) return;

        IReadOnlyList<TutorialStep> steps = _script.Steps;
        for (int i = 0; i < steps.Count; i++)
        {
            TutorialStep step = steps[i];
            if (step == null || step.Trigger != trigger) continue;
            if (_consumed.Contains(i)) continue;

            if (step.ShowOnce) _consumed.Add(i);
            _pending.Enqueue(step);
            break; // 트리거 1회당 스텝 1개.
        }

        if (!_isShowing && _pending.Count > 0)
            ShowPendingAsync().Forget();
    }

    /// <summary>대기 큐의 스텝을 순서대로 패널에 표시한다 (동시 표시 1개).</summary>
    private async UniTaskVoid ShowPendingAsync()
    {
        if (_isShowing) return;
        _isShowing = true;

        try
        {
            while (_pending.Count > 0)
            {
                if (_cts == null || _cts.IsCancellationRequested) return;
                if (!UIManager.HasInstance) return;

                TutorialStep step = _pending.Dequeue();
                await ShowStepPagesAsync(step);
                if (step.Trigger == ETutorialTrigger.BossDefeated)
                    _isBossDefeatedGuideDone = true;
            }
        }
        catch (OperationCanceledException)
        {
            // 씬 이탈/파괴 — 정상 종료.
        }
        finally
        {
            _isShowing = false;
        }
    }

    // ─────────────────────────────────────────────
    // 페이지 구성 (텍스트는 패널이 현재 언어로 해석)
    // ─────────────────────────────────────────────

    /// <summary>
    /// 스텝 하나를 표시한다. 페이지를 "이미지 유무가 바뀌는 지점"에서 묶음으로 나눠,
    /// 삽화 묶음은 삽화 패널(UITutorialIllustPanel)로, 텍스트 묶음은 텍스트 패널로
    /// 순서대로 이어 보여준다 — 페이지 배열 순서가 곧 연출 순서다.
    /// </summary>
    private async UniTask ShowStepPagesAsync(TutorialStep step)
    {
        List<TutorialPageContent> pages = BuildPages(step);
        if (pages.Count == 0)
        {
            // 페이지 없는 스텝 = 의도적 자리표시자. 트리거 소비만 하고 표시는 생략한다.
            // (예: 1층 시연 전투 — 진입 안내 없이 시연 대사가 직접 이어지지만,
            //  같은 트리거의 다음 스텝이 다음 전투에서 소비되도록 자리는 지켜야 한다)
            return;
        }

        // 트리거에 대응하는 화면(상점/휴식 팝업)이 실제로 열릴 때까지 먼저 기다린 뒤,
        // 트리거별 지연만큼 쉬고 표시 (화면이 먼저 눈에 들어오도록).
        await WaitForContextUiAsync(step.Trigger);
        float delay = GetShowDelay(step.Trigger);
        if (delay > 0f)
        {
            await UniTask.Delay(
                TimeSpan.FromSeconds(delay),
                DelayType.UnscaledDeltaTime,
                cancellationToken: _cts.Token);
        }

        int index = 0;
        while (index < pages.Count)
        {
            if (_cts == null || _cts.IsCancellationRequested) return;

            // 같은 종류(삽화/텍스트)가 이어지는 구간을 하나의 묶음으로.
            bool illustrated = pages[index].Image != null;
            int end = index + 1;
            while (end < pages.Count && (pages[end].Image != null) == illustrated) end++;

            // 타입이 달라야 UIManager 캐시가 섞이지 않는다 — UITutorialIllustPanel 참고.
            UITutorialPanel panel = illustrated
                ? await UIManager.Instance.OpenAsync<UITutorialIllustPanel>(_cts.Token)
                : await UIManager.Instance.OpenAsync<UITutorialPanel>(_cts.Token);
            if (panel == null)
            {
                Debug.LogError("[TutorialDirector] 튜토리얼 패널 열기 실패 — 남은 안내를 중단합니다.");
                return;
            }

            // 이전 버튼은 패널(묶음) 안의 페이지만 오간다 — 묶음 경계는 넘지 않는다.
            await panel.ShowStepAsync(
                step.TitleKey,
                pages.GetRange(index, end - index),
                _cts.Token,
                allowReplayAfterClose: step.Trigger == ETutorialTrigger.PreserveSelectStarted);
            index = end;
        }
    }

    /// <summary>
    /// 트리거에 대응하는 화면이 실제로 열릴 때까지 대기한다.
    /// 상점·휴식은 트리거 이벤트(OnMapNodeEntered)가 UI 열림보다 먼저 발행되므로,
    /// 여기서 기다리지 않으면 안내가 팝업보다 먼저 뜬다. 지도·전투는 이벤트 자체가
    /// UI 표시 후 발행이라 대기 없이 통과한다. 타임아웃 초과 시 그냥 진행.
    /// </summary>
    private async UniTask WaitForContextUiAsync(ETutorialTrigger trigger)
    {
        Func<bool> isReady = null;
        switch (trigger)
        {
            case ETutorialTrigger.ShopEntered:
                isReady = () => UIManager.HasInstance && UIManager.Instance.IsOpen<UIShopPopup>();
                break;
            case ETutorialTrigger.RestEntered:
                isReady = () => UIManager.HasInstance && UIManager.Instance.IsOpen<UIRestPopup>();
                break;
        }
        if (isReady == null || isReady()) return;

        float deadline = Time.unscaledTime + _contextUiTimeoutSeconds;
        while (!isReady() && Time.unscaledTime < deadline)
        {
            await UniTask.Yield(_cts.Token);
        }
    }

    /// <summary>트리거의 표시 지연 조회. 재정의 목록에 있으면 그 값, 없으면 기본 지연.</summary>
    private float GetShowDelay(ETutorialTrigger trigger)
    {
        // 지도 안내는 지연 없이 즉시. OnMapRevealed 가 이미 "연출이 끝나 맵이 보이는
        // 순간"을 보장하므로 기다릴 이유가 없고, 지연을 두면 그 사이 플레이어가
        // 노드를 눌러 전투에 진입해 안내가 전투 위에 떠 버린다.
        // (씬에 직렬화된 과거 재정의값 — 옛 이벤트 타이밍용 1초 — 은 의도적으로 무시)
        if (trigger == ETutorialTrigger.MapPresented) return 0f;

        if (_delayOverrides != null)
        {
            for (int i = 0; i < _delayOverrides.Length; i++)
            {
                if (_delayOverrides[i].Trigger == trigger)
                    return _delayOverrides[i].Seconds;
            }
        }
        return _showDelaySeconds;
    }

    private static List<TutorialPageContent> BuildPages(TutorialStep step)
    {
        var resolved = new List<TutorialPageContent>(step.Pages != null ? step.Pages.Count : 0);
        if (step.Pages == null) return resolved;

        for (int i = 0; i < step.Pages.Count; i++)
        {
            TutorialPage page = step.Pages[i];
            if (page == null) continue;
            resolved.Add(new TutorialPageContent(
                page.BodyKey, page.Image, page.Placement, page.AnchorIds));
        }
        return resolved;
    }

    private bool HasStep(ETutorialTrigger trigger)
    {
        IReadOnlyList<TutorialStep> steps = _script != null ? _script.Steps : null;
        if (steps == null) return false;

        for (int i = 0; i < steps.Count; i++)
        {
            if (steps[i] != null && steps[i].Trigger == trigger)
                return true;
        }
        return false;
    }
}
