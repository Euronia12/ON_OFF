using System;
using System.Collections.Generic;
using System.Threading;
using Cysharp.Threading.Tasks;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.UI;

/// <summary>튜토리얼 마지막 보스에서 OFF·배치·회수·화살표 추가를 순서대로 실습한다.</summary>
public sealed class TutorialFinalBossSkillSequence : MonoBehaviour
{
    private const string TargetCardAnchorId = "TargetCard";
    private const string SkillPanelAnchorId = "SkillPanel";
    private const ECardDirection AllCardinalDirections =
        ECardDirection.Up | ECardDirection.Down | ECardDirection.Left | ECardDirection.Right;
    private static readonly IReadOnlyList<string> TargetCardAnchorIds =
        new[] { "Owl", TargetCardAnchorId };

    [Header("각본")]
    [Tooltip("마지막 보스 자동 배치와 스킬 실습 대사 데이터")]
    [SerializeField] private TutorialFinalBossSkillsSO _lesson;

    [Tooltip("일반 대사에서 표시할 프록시 ID")]
    [SerializeField] private List<string> _owlAnchorIds = new List<string> { "Owl" };

    [Tooltip("스킬 설명에서 표시할 프록시 ID")]
    [SerializeField] private List<string> _skillAnchorIds = new List<string> { "Owl", SkillPanelAnchorId };

    private readonly List<IDisposableEvent> _subscriptions = new List<IDisposableEvent>(1);
    private CancellationTokenSource _cts;
    private BattleManager _battle;
    private GridManager _grid;
    private UIBattle _battleUI;
    private UICardHand _hand;
    private UIBattleSkillPanel _skillPanel;
    private SkillCastInput _castInput;
    private RectTransform _targetCardAnchorRect;
    private GraphicRaycaster _disabledBattleRaycaster;
    private Card _fireArrow;
    private Card _playerPlacedCard;
    private Vector2Int _playerPlacedPosition;
    private string _expectedSkillId;
    private Card _expectedSkillTarget;
    private ECardDirection _expectedSkillDirection;
    private UniTaskCompletionSource _skillApplied;
    private UniTaskCompletionSource<Card> _placedChainEnded;
    private UniTaskCompletionSource _cardRecalled;
    private bool _started;
    private bool _active;
    private bool _allowSkillInput;
    private bool _isWaitingForSkillSelection;
    private bool _isShowingSkillReminder;
    private bool _waitingForFreePlacement;
    private bool _inputBlocked;
    private bool _handlersAttached;

    private void Awake()
    {
        _cts = new CancellationTokenSource();
    }

    private void Start()
    {
        InitializeAsync().Forget();
    }

    private void Update()
    {
        if (!_active
            || !_isWaitingForSkillSelection
            || _isShowingSkillReminder
            || _castInput == null
            || _castInput.IsCasting
            || (UIManager.HasInstance && UIManager.Instance.IsOpen<UISystemEscMenu>()))
        {
            return;
        }

        if (_expectedSkillDirection != ECardDirection.None
            && _skillPanel.IsTutorialAllowedSkillSelected)
        {
            return;
        }

        Mouse mouse = Mouse.current;
        if (mouse == null || !mouse.leftButton.wasPressedThisFrame) return;

        Vector2 screenPosition = mouse.position.ReadValue();
        if (_skillPanel.IsPointerOverAllowedTutorialControl(screenPosition))
            return;

        ShowSkillReminderAsync().Forget();
    }

    private async UniTaskVoid InitializeAsync()
    {
        await BootstrapInitializer.WaitForReadyAsync();
        if (_cts == null || _cts.IsCancellationRequested) return;

        if (_lesson == null || !EventManager.HasInstance)
        {
            Debug.LogError("[TutorialFinalBossSkillSequence] 각본 또는 EventManager가 없어 실습을 시작할 수 없습니다.");
            return;
        }

        _subscriptions.Add(
            EventManager.Instance.Subscribe<OnBattleNodeEntered>(HandleBattleNodeEntered));
    }

    private void OnDestroy()
    {
        for (int i = 0; i < _subscriptions.Count; i++)
            _subscriptions[i]?.Dispose();
        _subscriptions.Clear();

        ReleaseRestrictions(restoreUi: true);
        DetachBattleHandlers();
        if (_targetCardAnchorRect != null)
            Destroy(_targetCardAnchorRect.gameObject);
        _cts?.Cancel();
        _cts?.Dispose();
        _cts = null;
    }

    private void HandleBattleNodeEntered(OnBattleNodeEntered evt)
    {
        if (_started || evt.NodeType != ENodeType.Boss) return;
        _started = true;

        _battle = BattleManager.HasInstance ? BattleManager.Instance : null;
        _grid = GridManager.HasInstance ? GridManager.Instance : null;
        _battleUI = UIManager.HasInstance ? UIManager.Instance.Get<UIBattle>() : null;
        _hand = _battleUI != null ? _battleUI.CardHand : null;
        _skillPanel = _battleUI != null ? _battleUI.SkillPanel : null;
        _castInput = _skillPanel != null ? _skillPanel.CastInput : null;
        if (_battle == null || _grid == null || _hand == null
            || _skillPanel == null || _castInput == null || _lesson.FireArrow == null)
        {
            Debug.LogError("[TutorialFinalBossSkillSequence] 전투 시스템 또는 실습 카드 참조를 찾지 못했습니다.");
            return;
        }

        CreateTargetCardAnchor();
        _active = true;
        _battle.SetPlacementLocked(true);
        SetAllHandInteractable(false);
        AttachBattleHandlers();
        ApplyUiLocks();
        RunLessonAsync().Forget();
    }

    private async UniTaskVoid RunLessonAsync()
    {
        CancellationToken token = _cts.Token;
        try
        {
            while (_battle != null
                && _battle.IsBattleActive
                && (_battle.CurrentPhase != EBattlePhase.PlayerInput || _battle.IsProcessing))
            {
                await UniTask.Yield(token);
            }

            BlockAutomaticPlacementInput();
            await ShowMentAsync(_lesson.FoundBodyKey, _owlAnchorIds, token);
            await PlaceOwlFireArrowAsync(token);
            ReleaseAutomaticPlacementInput();

            await ShowMentAsync(_lesson.SkillOverviewBodyKey, _skillAnchorIds, token);

            await GuideSkillAsync(
                _lesson.OffSkillId,
                ECardDirection.None,
                _fireArrow,
                _lesson.FireArrowPosition,
                _lesson.OffPromptBodyKey,
                token);
            if (_fireArrow.GridState.IsActivated)
                throw new InvalidOperationException("OFF 실습 후 Fire Arrow가 ON 상태입니다.");
            PointTargetAtGridCard(_fireArrow);
            await ShowMentAsync(
                _lesson.OffResultBodyKey,
                TargetCardAnchorIds,
                EPanelPlacement.Bottom,
                token);

            await GuideFreePlacementAsync(token);

            await GuideRecallAsync(token);
            UICard recalledCard = await WaitForHandCardVisualAsync(_playerPlacedCard, token);
            SetAllHandInteractable(false);
            PointTargetAtUiCard(recalledCard);
            await ShowMentAsync(
                _lesson.RecallResultBodyKey,
                TargetCardAnchorIds,
                EPanelPlacement.Top,
                token);

            await GuideSkillAsync(
                _lesson.AddArrowSkillId,
                _lesson.AddArrowDirection,
                _fireArrow,
                _lesson.FireArrowPosition,
                _lesson.AddUpPromptBodyKey,
                token);
            if ((_fireArrow.Arrow.Current & AllCardinalDirections) != AllCardinalDirections)
                throw new InvalidOperationException("화살표 추가 실습 후 Fire Arrow가 4방향이 아닙니다.");

            PointTargetAtGridCard(_fireArrow);
            await ShowMentAsync(
                _lesson.CompleteBodyKey,
                TargetCardAnchorIds,
                EPanelPlacement.Bottom,
                token);

            _active = false;
            ReleaseRestrictions(restoreUi: true);
            DetachBattleHandlers();
        }
        catch (OperationCanceledException)
        {
            // 전투 종료·씬 이탈 — 정리 경로에서 복구한다.
        }
        catch (Exception exception)
        {
            Debug.LogException(exception, this);
        }
        finally
        {
            if (_active)
            {
                ReleaseRestrictions(restoreUi: true);
                DetachBattleHandlers();
            }
        }
    }

    private async UniTask PlaceOwlFireArrowAsync(CancellationToken token)
    {
        CardRuntimeData runtime = CardFactory.FromSO(_lesson.FireArrow);
        _fireArrow = CardFactory.Create(runtime, _lesson.FireArrowDirections);
        if (_fireArrow == null)
            throw new InvalidOperationException("Fire Arrow 런타임 카드 생성에 실패했습니다.");

        _fireArrow.SetBattleDeckOwner(EBattleDeckOwner.PlayerTemporary);
        bool placed = await _battle.PlaceCardWithChainForTutorialAsync(
            _fireArrow,
            _lesson.FireArrowPosition);
        if (!placed)
            throw new InvalidOperationException("부엉이의 Fire Arrow 자동 배치에 실패했습니다.");

        while (_battle.IsProcessing)
            await UniTask.Yield(token);
    }

    private async UniTask GuideSkillAsync(
        string skillId,
        ECardDirection direction,
        Card target,
        Vector2Int targetPosition,
        string promptBodyKey,
        CancellationToken token)
    {
        _allowSkillInput = false;
        _battle.SetPlacementLocked(true);
        SetAllHandInteractable(false);
        _skillPanel.SetTutorialRestriction(skillId, direction);
        _castInput.SetTutorialAllowedTarget(target);
        _grid.SetTutorialTargetMarker(targetPosition, _lesson.MarkerColor);
        ApplyUiLocks();

        IReadOnlyList<string> promptAnchors = PointTargetAtAllowedSkill()
            ? TargetCardAnchorIds
            : _skillAnchorIds;
        await ShowMentAsync(
            promptBodyKey,
            promptAnchors,
            token,
            allowReplayAfterClose: true);

        _expectedSkillId = skillId;
        _expectedSkillTarget = target;
        _expectedSkillDirection = direction;
        _skillApplied = new UniTaskCompletionSource();
        _isWaitingForSkillSelection = true;
        _allowSkillInput = true;
        ApplyUiLocks();
        await _skillApplied.Task.AttachExternalCancellation(token);
        if (TutorialDirector.Active != null)
            TutorialDirector.Active.ClearReplayGuide();
        await UniTask.Yield(token);

        _allowSkillInput = false;
        _isWaitingForSkillSelection = false;
        _skillApplied = null;
        _expectedSkillId = null;
        _expectedSkillTarget = null;
        _expectedSkillDirection = ECardDirection.None;
        _grid.ClearTutorialTargetMarker();
        ApplyUiLocks();
    }

    private async UniTask GuideFreePlacementAsync(CancellationToken token)
    {
        _skillPanel.ClearTutorialRestriction();
        _castInput.SetTutorialAllowedTarget(null);
        _battle.SetPlacementLocked(true);
        SetAllHandInteractable(false);
        ApplyUiLocks();
        await ShowMentAsync(
            _lesson.PlaceAnyBodyKey,
            _owlAnchorIds,
            token,
            allowReplayAfterClose: true);

        _playerPlacedCard = null;
        _placedChainEnded = new UniTaskCompletionSource<Card>();
        _waitingForFreePlacement = true;
        _battle.SetAllowedPlacementCard(null);
        _battle.SetAllowedPlacementPosition(null);
        _battle.SetPlacementLocked(false);
        SetAllHandInteractable(true);

        await _placedChainEnded.Task.AttachExternalCancellation(token);
        if (TutorialDirector.Active != null)
            TutorialDirector.Active.ClearReplayGuide();
        while (_battle.IsProcessing)
            await UniTask.Yield(token);

        _waitingForFreePlacement = false;
        _placedChainEnded = null;
        _battle.SetPlacementLocked(true);
        SetAllHandInteractable(false);
        ApplyUiLocks();
    }

    private async UniTask GuideRecallAsync(CancellationToken token)
    {
        _skillPanel.SetTutorialRestriction(_lesson.RecallSkillId);
        _castInput.SetTutorialAllowedTarget(_playerPlacedCard);
        _grid.SetTutorialTargetMarker(_playerPlacedPosition, _lesson.MarkerColor);
        ApplyUiLocks();
        IReadOnlyList<string> promptAnchors = PointTargetAtAllowedSkill()
            ? TargetCardAnchorIds
            : _skillAnchorIds;
        await ShowMentAsync(
            _lesson.RecallPromptBodyKey,
            promptAnchors,
            token,
            allowReplayAfterClose: true);

        _cardRecalled = new UniTaskCompletionSource();
        _expectedSkillId = _lesson.RecallSkillId;
        _expectedSkillTarget = _playerPlacedCard;
        _expectedSkillDirection = ECardDirection.None;
        _isWaitingForSkillSelection = true;
        _allowSkillInput = true;
        ApplyUiLocks();
        await _cardRecalled.Task.AttachExternalCancellation(token);
        if (TutorialDirector.Active != null)
            TutorialDirector.Active.ClearReplayGuide();
        while (_battle.IsProcessing)
            await UniTask.Yield(token);

        _allowSkillInput = false;
        _isWaitingForSkillSelection = false;
        _cardRecalled = null;
        _expectedSkillId = null;
        _expectedSkillTarget = null;
        _grid.ClearTutorialTargetMarker();
        ApplyUiLocks();
    }

    private void HandleCardPlaced(Card card, Vector2Int position)
    {
        if (!_active || !_waitingForFreePlacement || _playerPlacedCard != null)
            return;

        _playerPlacedCard = card;
        _playerPlacedPosition = position;
        _battle.SetPlacementLocked(true);
        SetAllHandInteractable(false);
        ApplyUiLocks();
    }

    private UniTask HandleChainEndedAsync(Card card, CancellationToken token)
    {
        if (_waitingForFreePlacement && card == _playerPlacedCard)
            _placedChainEnded?.TrySetResult(card);
        return UniTask.CompletedTask;
    }

    private void HandleCardRecalled(Card card, Vector2Int position)
    {
        if (_active && card == _playerPlacedCard)
            _cardRecalled?.TrySetResult();
    }

    private void HandleSkillApplied(string skillId, Card target, ECardDirection direction)
    {
        if (!_active
            || skillId != _expectedSkillId
            || target != _expectedSkillTarget
            || direction != _expectedSkillDirection)
        {
            return;
        }

        _isWaitingForSkillSelection = false;
        _skillApplied?.TrySetResult();
    }

    private async UniTaskVoid ShowSkillReminderAsync()
    {
        if (_isShowingSkillReminder || !_active || !_isWaitingForSkillSelection)
            return;

        _isShowingSkillReminder = true;
        _allowSkillInput = false;
        _castInput?.CancelCast();
        ApplyUiLocks();
        BlockAutomaticPlacementInput();
        try
        {
            bool isPointingAllowedSkill = PointTargetAtAllowedSkill();
            IReadOnlyList<string> reminderAnchors = isPointingAllowedSkill
                ? TargetCardAnchorIds
                : _skillAnchorIds;
            await ShowMentAsync(
                _lesson.SkillReminderBodyKey,
                reminderAnchors,
                EPanelPlacement.Bottom,
                _cts.Token,
                preserveExistingReplay: true);
        }
        catch (OperationCanceledException)
        {
            // 전투 종료·씬 이탈 — 공통 정리 경로가 제한을 복구한다.
        }
        finally
        {
            ReleaseAutomaticPlacementInput();
            _isShowingSkillReminder = false;
            if (_active && _isWaitingForSkillSelection)
            {
                _allowSkillInput = true;
                ApplyUiLocks();
            }
        }
    }

    private void HandleProcessingChanged(bool processing)
    {
        if (_active && !processing)
            ApplyUiLocks();
    }

    private void HandleBattleEnded(bool victory)
    {
        if (!_active) return;
        ReleaseRestrictions(restoreUi: false);
        DetachBattleHandlers();
        _cts?.Cancel();
    }

    private void AttachBattleHandlers()
    {
        if (_handlersAttached) return;
        _battle.OnCardPlaced += HandleCardPlaced;
        _battle.OnChainEndedAsync += HandleChainEndedAsync;
        _battle.OnCardRecalled += HandleCardRecalled;
        _battle.OnProcessingChanged += HandleProcessingChanged;
        _battle.OnBattleEnded += HandleBattleEnded;
        _castInput.OnSkillApplied += HandleSkillApplied;
        _handlersAttached = true;
    }

    private void DetachBattleHandlers()
    {
        if (!_handlersAttached) return;
        if (_battle != null)
        {
            _battle.OnCardPlaced -= HandleCardPlaced;
            _battle.OnChainEndedAsync -= HandleChainEndedAsync;
            _battle.OnCardRecalled -= HandleCardRecalled;
            _battle.OnProcessingChanged -= HandleProcessingChanged;
            _battle.OnBattleEnded -= HandleBattleEnded;
        }
        if (_castInput != null)
            _castInput.OnSkillApplied -= HandleSkillApplied;
        _handlersAttached = false;
    }

    private void ApplyUiLocks()
    {
        if (!_active || _battleUI == null || _battle == null) return;
        _battleUI.SetEndTurnInteractable(false);
        _battleUI.SetSkillPanelInteractable(_allowSkillInput && !_battle.IsProcessing);
    }

    private void ReleaseRestrictions(bool restoreUi)
    {
        ReleaseAutomaticPlacementInput();
        if (_battle != null)
        {
            _battle.SetPlacementLocked(false);
            _battle.SetAllowedPlacementCard(null);
            _battle.SetAllowedPlacementPosition(null);
        }
        _grid?.ClearTutorialTargetMarker();
        _skillPanel?.ClearTutorialRestriction();
        _castInput?.SetTutorialAllowedTarget(null);
        _isWaitingForSkillSelection = false;
        _isShowingSkillReminder = false;
        SetAllHandInteractable(true);

        if (restoreUi && _battleUI != null && _battle != null
            && _battle.IsBattleActive && _battle.CurrentPhase == EBattlePhase.PlayerInput)
        {
            _battleUI.SetEndTurnInteractable(!_battle.IsProcessing);
            _battleUI.SetSkillPanelInteractable(!_battle.IsProcessing);
        }
        _active = false;
    }

    private void BlockAutomaticPlacementInput()
    {
        if (!_inputBlocked && InputManager.HasInstance)
        {
            InputManager.Instance.PushInputBlock();
            _inputBlocked = true;
        }

        if (_battleUI == null || _disabledBattleRaycaster != null) return;
        GraphicRaycaster raycaster = _battleUI.GetComponentInParent<GraphicRaycaster>();
        if (raycaster != null && raycaster.enabled)
        {
            raycaster.enabled = false;
            _disabledBattleRaycaster = raycaster;
        }
    }

    private void ReleaseAutomaticPlacementInput()
    {
        if (_disabledBattleRaycaster != null)
        {
            _disabledBattleRaycaster.enabled = true;
            _disabledBattleRaycaster = null;
        }
        if (_inputBlocked && InputManager.HasInstance)
            InputManager.Instance.PopInputBlock();
        _inputBlocked = false;
    }

    private void SetAllHandInteractable(bool interactable)
    {
        IReadOnlyList<UICard> cards = _hand != null ? _hand.Cards : null;
        if (cards == null) return;

        for (int i = 0; i < cards.Count; i++)
        {
            UICard card = cards[i];
            if (card == null) continue;
            card.SetInteractable(interactable);
            card.SetRaycastTarget(interactable);
            if (!interactable)
                card.SetTutorialHighlightVisible(false);
        }
    }

    private void CreateTargetCardAnchor()
    {
        if (_targetCardAnchorRect != null || !UIManager.HasInstance
            || UIManager.Instance.RootCanvas == null)
        {
            return;
        }

        var anchorObject = new GameObject("TutorialTargetCardAnchor", typeof(RectTransform));
        anchorObject.SetActive(false);
        anchorObject.layer = _battleUI.gameObject.layer;
        _targetCardAnchorRect = anchorObject.GetComponent<RectTransform>();
        _targetCardAnchorRect.SetParent(UIManager.Instance.RootCanvas.transform, false);
        _targetCardAnchorRect.sizeDelta = new Vector2(100f, 100f);
        anchorObject.AddComponent<TutorialAnchor>().Configure(TargetCardAnchorId);
        anchorObject.SetActive(true);
    }

    private void PointTargetAtGridCard(Card card)
    {
        if (_targetCardAnchorRect == null
            || !_grid.TryGetCardWorldPosition(card, out Vector3 worldPosition)
            || Camera.main == null)
        {
            throw new InvalidOperationException("그리드 카드 안내 위치를 찾지 못했습니다.");
        }

        Canvas canvas = UIManager.Instance.RootCanvas;
        RectTransform canvasRect = canvas.transform as RectTransform;
        Vector2 screenPoint = RectTransformUtility.WorldToScreenPoint(Camera.main, worldPosition);
        Camera uiCamera = canvas.renderMode == RenderMode.ScreenSpaceOverlay
            ? null
            : canvas.worldCamera;
        if (!RectTransformUtility.ScreenPointToWorldPointInRectangle(
                canvasRect,
                screenPoint,
                uiCamera,
                out Vector3 canvasWorld))
        {
            throw new InvalidOperationException("그리드 카드 화면 좌표 변환에 실패했습니다.");
        }

        _targetCardAnchorRect.position = canvasWorld;
    }

    private void PointTargetAtUiCard(UICard card)
    {
        RectTransform cardRect = card != null ? card.GetRectTransform() : null;
        if (_targetCardAnchorRect == null || cardRect == null)
            throw new InvalidOperationException("회수 카드 안내 위치를 찾지 못했습니다.");

        _targetCardAnchorRect.position = cardRect.TransformPoint(
            new Vector2(cardRect.rect.center.x, cardRect.rect.yMax));
    }

    private bool PointTargetAtAllowedSkill()
    {
        if (_targetCardAnchorRect == null
            || _skillPanel == null
            || !_skillPanel.TryGetTutorialAllowedSkillRect(out RectTransform skillRect))
        {
            return false;
        }

        _targetCardAnchorRect.position = skillRect.TransformPoint(skillRect.rect.center);
        return true;
    }

    private async UniTask<UICard> WaitForHandCardVisualAsync(
        Card card,
        CancellationToken token)
    {
        UICard uiCard = null;
        while (uiCard == null)
        {
            IReadOnlyList<UICard> cards = _hand.Cards;
            for (int i = 0; i < cards.Count; i++)
            {
                if (cards[i] != null && cards[i].BoundCard == card)
                {
                    uiCard = cards[i];
                    break;
                }
            }
            if (uiCard == null)
                await UniTask.Yield(token);
        }

        CanvasGroup canvasGroup = uiCard.GetComponent<CanvasGroup>();
        while (canvasGroup != null && canvasGroup.alpha < 0.99f)
            await UniTask.Yield(token);
        return uiCard;
    }

    private async UniTask ShowMentAsync(
        string bodyKey,
        IReadOnlyList<string> anchorIds,
        CancellationToken token,
        bool allowReplayAfterClose = false)
    {
        await ShowMentAsync(
            bodyKey,
            anchorIds,
            EPanelPlacement.Bottom,
            token,
            allowReplayAfterClose);
    }

    private async UniTask ShowMentAsync(
        string bodyKey,
        IReadOnlyList<string> anchorIds,
        EPanelPlacement placement,
        CancellationToken token,
        bool allowReplayAfterClose = false,
        bool preserveExistingReplay = false)
    {
        if (string.IsNullOrEmpty(bodyKey) || !UIManager.HasInstance) return;

        UITutorialPanel panel = await UIManager.Instance.OpenAsync<UITutorialPanel>(token);
        if (panel == null)
            throw new InvalidOperationException("마지막 보스 튜토리얼 대사 패널 열기에 실패했습니다.");

        var pages = new List<TutorialPageContent>(1)
        {
            new TutorialPageContent(bodyKey, null, placement, anchorIds),
        };
        await panel.ShowStepAsync(
            _lesson.SpeakerTitleKey,
            pages,
            token,
            allowReplayAfterClose: allowReplayAfterClose,
            preserveExistingReplay: preserveExistingReplay);
    }
}
