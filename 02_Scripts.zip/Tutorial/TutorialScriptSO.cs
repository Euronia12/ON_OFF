// =================================================================
// [스크립트 목적]  튜토리얼 대본 ScriptableObject. 스텝(트리거+안내문) 목록을 순서대로 보관.
// [주요 변수]      - _scriptId : 로그/식별용 ID
//                  - _steps    : 튜토리얼 스텝 목록 (같은 트리거는 순서대로 소비)
// [의존 관계]      - TutorialDirector(씬에서 참조·실행) / TutorialStep(TutorialTypes)
// [설계 노트]      - 안내 문구를 코드가 아닌 데이터로 분리 — 게임 규칙 변경 시 이 에셋만 수정.
// =================================================================

using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// 튜토리얼 한 벌의 대본. 스텝 목록을 보관하며 실행 로직은 TutorialDirector 가 담당한다.
/// </summary>
[CreateAssetMenu(fileName = "TutorialScript", menuName = "Game/Tutorial Script", order = 2)]
public sealed class TutorialScriptSO : ScriptableObject
{
    [Header("식별")]
    [Tooltip("튜토리얼 대본 식별 ID (로그용)")]
    [SerializeField] private string _scriptId = "tutorial_default";

    [Header("스텝")]
    [Tooltip("튜토리얼 스텝 목록. 같은 트리거의 스텝이 여러 개면 위에서부터 하나씩 소비")]
    [SerializeField] private List<TutorialStep> _steps = new List<TutorialStep>();

    public string ScriptId => _scriptId;
    public IReadOnlyList<TutorialStep> Steps => _steps;
}
