using System;
using System.Collections.Generic;
using UnityEngine;

/// <summary>튜토리얼 두 번째 전투의 첫 손패와 강제 배치 대본.</summary>
[CreateAssetMenu(fileName = "TutorialBattleBasics", menuName = "Tutorial/Battle Basics")]
public sealed class TutorialBattleBasicsSO : ScriptableObject
{
    [Serializable]
    public sealed class GuidedPlacement
    {
        [Tooltip("손패에서 플레이어가 직접 배치할 카드")]
        [SerializeField] private CardDataSO _card;

        [Tooltip("이 카드를 놓을 그리드 좌표")]
        [SerializeField] private Vector2Int _position;

        public CardDataSO Card => _card;
        public Vector2Int Position => _position;
    }

    [Header("첫 손패")]
    [Tooltip("실제 런 덱에서 찾아 첫 턴에 이 순서로 드로우할 카드 7장")]
    [SerializeField] private List<CardDataSO> _firstDrawCards = new List<CardDataSO>();

    [Header("강제 배치")]
    [Tooltip("방어 → 좌측 공격 → 우측 공격 순서의 플레이어 직접 배치")]
    [SerializeField] private List<GuidedPlacement> _placements = new List<GuidedPlacement>();

    [Tooltip("지정 슬롯 마커 색")]
    [SerializeField] private Color _markerColor = new Color(1f, 0.75f, 0.1f, 1f);

    [Header("대사 키")]
    [Tooltip("모든 안내에 사용할 화자 제목 키")]
    [SerializeField] private string _speakerTitleKey;
    [SerializeField] private string _introBodyKey;
    [SerializeField] private string _placeDefenseBodyKey;
    [SerializeField] private string _onArrowBodyKey;
    [SerializeField] private string _turnOffPromptBodyKey;
    [SerializeField] private string _turnedOffBodyKey;
    [SerializeField] private string _reactivatePromptBodyKey;
    [SerializeField] private string _reactivatedBodyKey;
    [SerializeField] private string _intentDefenseBodyKey;
    [SerializeField] private string _manaEmptyBodyKey;

    public IReadOnlyList<CardDataSO> FirstDrawCards => _firstDrawCards;
    public IReadOnlyList<GuidedPlacement> Placements => _placements;
    public Color MarkerColor => _markerColor;
    public string SpeakerTitleKey => _speakerTitleKey;
    public string IntroBodyKey => _introBodyKey;
    public string PlaceDefenseBodyKey => _placeDefenseBodyKey;
    public string OnArrowBodyKey => _onArrowBodyKey;
    public string TurnOffPromptBodyKey => _turnOffPromptBodyKey;
    public string TurnedOffBodyKey => _turnedOffBodyKey;
    public string ReactivatePromptBodyKey => _reactivatePromptBodyKey;
    public string ReactivatedBodyKey => _reactivatedBodyKey;
    public string IntentDefenseBodyKey => _intentDefenseBodyKey;
    public string ManaEmptyBodyKey => _manaEmptyBodyKey;

    public IReadOnlyList<string> CreateFirstDrawCardIds()
    {
        var result = new List<string>(_firstDrawCards.Count);
        for (int i = 0; i < _firstDrawCards.Count; i++)
        {
            CardDataSO card = _firstDrawCards[i];
            if (card != null)
                result.Add(card.CardId);
        }
        return result;
    }

#if UNITY_EDITOR
    private void OnValidate()
    {
        if (_firstDrawCards.Count != 7)
            Debug.LogWarning($"[{name}] 첫 손패는 7장이어야 합니다.", this);
        if (_placements.Count != 3)
            Debug.LogWarning($"[{name}] 강제 배치는 3단계여야 합니다.", this);
    }
#endif
}
