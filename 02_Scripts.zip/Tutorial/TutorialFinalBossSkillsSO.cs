using UnityEngine;

/// <summary>튜토리얼 마지막 보스의 스킬 강제 실습 데이터.</summary>
[CreateAssetMenu(fileName = "TutorialFinalBossSkills", menuName = "Tutorial/Final Boss Skills")]
public sealed class TutorialFinalBossSkillsSO : ScriptableObject
{
    [Header("자동 배치")]
    [Tooltip("부엉이가 그리드에 직접 배치할 원본 카드")]
    [SerializeField] private CardDataSO _fireArrow;

    [Tooltip("Fire Arrow를 배치할 그리드 좌표")]
    [SerializeField] private Vector2Int _fireArrowPosition = new Vector2Int(2, 2);

    [Tooltip("Fire Arrow 생성 시 고정할 화살표 방향")]
    [SerializeField] private ECardDirection _fireArrowDirections =
        ECardDirection.Down | ECardDirection.Left | ECardDirection.Right;

    [Tooltip("스킬 대상 카드에 표시할 마커 색")]
    [SerializeField] private Color _markerColor = new Color(1f, 0.75f, 0.1f, 1f);

    [Header("스킬")]
    [Tooltip("ON 카드를 OFF로 전환하는 스킬 ID")]
    [SerializeField] private string _offSkillId = "Skill_ToggleCard";

    [Tooltip("그리드 카드를 손패로 회수하는 스킬 ID")]
    [SerializeField] private string _recallSkillId = "Skill_TurnArrow";

    [Tooltip("카드에 화살표를 추가하는 스킬 ID")]
    [SerializeField] private string _addArrowSkillId = "Skill_AddArrow";

    [Tooltip("마지막 실습에서 허용할 추가 화살표 방향")]
    [SerializeField] private ECardDirection _addArrowDirection = ECardDirection.Up;

    [Header("대사 키")]
    [Tooltip("모든 안내에 사용할 화자 제목 키")]
    [SerializeField] private string _speakerTitleKey;
    [SerializeField] private string _foundBodyKey;
    [SerializeField] private string _skillOverviewBodyKey;
    [SerializeField] private string _skillReminderBodyKey;
    [SerializeField] private string _offPromptBodyKey;
    [SerializeField] private string _offResultBodyKey;
    [SerializeField] private string _placeAnyBodyKey;
    [SerializeField] private string _recallPromptBodyKey;
    [SerializeField] private string _recallResultBodyKey;
    [SerializeField] private string _addUpPromptBodyKey;
    [SerializeField] private string _completeBodyKey;

    public CardDataSO FireArrow => _fireArrow;
    public Vector2Int FireArrowPosition => _fireArrowPosition;
    public ECardDirection FireArrowDirections => _fireArrowDirections;
    public Color MarkerColor => _markerColor;
    public string OffSkillId => _offSkillId;
    public string RecallSkillId => _recallSkillId;
    public string AddArrowSkillId => _addArrowSkillId;
    public ECardDirection AddArrowDirection => _addArrowDirection;
    public string SpeakerTitleKey => _speakerTitleKey;
    public string FoundBodyKey => _foundBodyKey;
    public string SkillOverviewBodyKey => _skillOverviewBodyKey;
    public string SkillReminderBodyKey => _skillReminderBodyKey;
    public string OffPromptBodyKey => _offPromptBodyKey;
    public string OffResultBodyKey => _offResultBodyKey;
    public string PlaceAnyBodyKey => _placeAnyBodyKey;
    public string RecallPromptBodyKey => _recallPromptBodyKey;
    public string RecallResultBodyKey => _recallResultBodyKey;
    public string AddUpPromptBodyKey => _addUpPromptBodyKey;
    public string CompleteBodyKey => _completeBodyKey;
}
