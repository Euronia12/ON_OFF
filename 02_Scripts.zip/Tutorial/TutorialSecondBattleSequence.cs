using System;
using System.Collections.Generic;
using System.Threading;
using Cysharp.Threading.Tasks;
using UnityEngine;

/// <summary>튜토리얼 2층 전투의 카드 배치·연쇄·마나 소진 실습.</summary>
public sealed class TutorialSecondBattleSequence : MonoBehaviour
{
    private const int LessonFloor = 2;

    [Header("각본")]
    [Tooltip("두 번째 전투의 첫 손패·배치 좌표·대사 키")]
    [SerializeField] private TutorialBattleBasicsSO _basics;

    [Tooltip("일반 대사에서 표시할 프록시 ID")]
    [SerializeField] private List<string> _owlAnchorIds = new List<string> { "Owl" };

    [Tooltip("적 의도 설명에서 표시할 프록시 ID")]
    [SerializeField] private List<string> _intentAnchorIds = new List<string> { "Owl", "EnemyIntent" };

    [Tooltip("마나 소진 설명에서 표시할 프록시 ID")]
    [SerializeField] private List<string> _manaAnchorIds = new List<string> { "Owl", "Cost", "EndTurn" };

    private static TutorialSecondBattleSequence _instance;

    public static TutorialBattleBasicsSO ActiveBasics =>
        _instance != null ? _instance._basics : null;

    public static bool ShouldStageInitialHandPresentation
    {
        get
        {
            RunContext run = InGameController.HasInstance
                ? InGameController.Instance.CurrentRun
                : null;
            MapNode node = run != null && run.Map != null
                ? run.Map.GetNode(run.CurrentNodeId)
                : null;
            return _instance != null
                && _instance._isReady
                && node != null
                && IsLessonBattleNode(node.NodeType, run.CurrentFloor);
        }
    }

    public static bool IsLessonBattleNode(ENodeType nodeType, int floor)
    {
        return _instance != null
            && !_instance._started
            && _instance._basics != null
            && nodeType == ENodeType.Battle
            && floor == LessonFloor;
    }

    private readonly List<IDisposableEvent> _subscriptions = new List<IDisposableEvent>(1);
    private CancellationTokenSource _cts;
    private BattleManager _battle;
    private GridManager _grid;
    private UIBattle _battleUI;
    private UICardHand _hand;
    private Card _waitingCard;
    private Card _defenseCard;
    private UniTaskCompletionSource<Card> _waitingChain;
    private UniTaskCompletionSource _manaZeroChain;
    private UniTaskCompletionSource _turnConfirmed;
    private readonly List<UICard> _lessonHandCards = new List<UICard>(7);
    private readonly List<UICard> _stagedHandCards = new List<UICard>(7);
    private bool _started;
    private bool _isReady;
    private bool _active;
    private bool _manaZeroPending;
    private bool _allowEndTurn;

    private void Awake()
    {
        _instance = this;
        _cts = new CancellationTokenSource();
    }

    private void Start()
    {
        InitializeAsync().Forget();
    }

    private async UniTaskVoid InitializeAsync()
    {
        await BootstrapInitializer.WaitForReadyAsync();
        if (_cts == null || _cts.IsCancellationRequested) return;

        if (_basics == null || !EventManager.HasInstance)
        {
            Debug.LogError("[TutorialSecondBattleSequence] 각본 또는 EventManager가 없어 실습을 시작할 수 없습니다.");
            return;
        }

        _subscriptions.Add(
            EventManager.Instance.Subscribe<OnBattleNodeEntered>(HandleBattleNodeEntered));
        _isReady = true;
    }

    private void OnDestroy()
    {
        if (_instance == this) _instance = null;

        for (int i = 0; i < _subscriptions.Count; i++)
            _subscriptions[i]?.Dispose();
        _subscriptions.Clear();

        ReleaseRestrictions(restoreUi: true);
        DetachBattleHandlers();
        _cts?.Cancel();
        _cts?.Dispose();
        _cts = null;
    }

    private void HandleBattleNodeEntered(OnBattleNodeEntered evt)
    {
        int floor = InGameController.HasInstance && InGameController.Instance.CurrentRun != null
            ? InGameController.Instance.CurrentRun.CurrentFloor
            : 0;
        if (!IsLessonBattleNode(evt.NodeType, floor)) return;

        _started = true;
        _battle = BattleManager.HasInstance ? BattleManager.Instance : null;
        _grid = GridManager.HasInstance ? GridManager.Instance : null;
        _battleUI = UIManager.HasInstance ? UIManager.Instance.Get<UIBattle>() : null;
        _hand = _battleUI != null ? _battleUI.CardHand : null;
        if (_battle == null || _grid == null || _hand == null)
        {
            Debug.LogError("[TutorialSecondBattleSequence] 전투 UI 또는 전투 시스템 참조를 찾지 못했습니다.");
            return;
        }

        _active = true;
        _battle.SetPlacementLocked(true);
        SetAllHandInteractable(false);
        AttachBattleHandlers();
        ApplyUiLocks();
        RunLessonAsync().Forget();
    }

    private async UniTaskVoid RunLessonAsync()
    {
        CancellationToken token = _cts.Token;
        try
        {
            await UniTask.Yield(token);
            if (!PrepareInitialHandPresentation())
            {
                Debug.LogError("[TutorialSecondBattleSequence] 지정한 7장이 첫 손패에 없습니다.");
                return;
            }

            await ShowMentAsync(_basics.IntroBodyKey, _owlAnchorIds, token);

            Card defense = await GuidePlacementAsync(
                0,
                _basics.PlaceDefenseBodyKey,
                token);
            _defenseCard = defense;
            await ShowMentAsync(_basics.OnArrowBodyKey, _owlAnchorIds, token);

            await GuidePlacementAsync(1, _basics.TurnOffPromptBodyKey, token);
            await ShowMentAsync(_basics.TurnedOffBodyKey, _owlAnchorIds, token);

            await GuidePlacementAsync(2, _basics.ReactivatePromptBodyKey, token);
            await ShowMentAsync(_basics.ReactivatedBodyKey, _owlAnchorIds, token);

            await RevealRemainingCardsAsync(token);
            HighlightDefenseCards(true);
            await ShowMentAsync(
                _basics.IntentDefenseBodyKey,
                _intentAnchorIds,
                token,
                allowReplayAfterClose: true);
            HighlightDefenseCards(false);

            _battle.SetAllowedPlacementCard(null);
            _battle.SetAllowedPlacementPosition(null);
            _battle.SetPlacementLocked(false);
            _grid.ClearTutorialTargetMarker();
            SetAllHandInteractable(true);
            ApplyUiLocks();

            _manaZeroChain = new UniTaskCompletionSource();
            if (_battle.PlayerCurrentEnergy == 0)
                _manaZeroPending = true;
            await _manaZeroChain.Task.AttachExternalCancellation(token);
            while (_battle != null && _battle.IsProcessing)
                await UniTask.Yield(token);

            _battle.SetPlacementLocked(true);
            SetAllHandInteractable(false);
            ApplyUiLocks();
            await ShowMentAsync(
                _basics.ManaEmptyBodyKey,
                _manaAnchorIds,
                token,
                allowReplayAfterClose: true);

            _allowEndTurn = true;
            ApplyUiLocks();
            _turnConfirmed = new UniTaskCompletionSource();
            await _turnConfirmed.Task.AttachExternalCancellation(token);
            if (TutorialDirector.Active != null)
                TutorialDirector.Active.ClearReplayGuide();

            _active = false;
            ReleaseRestrictions(restoreUi: false);
            DetachBattleHandlers();
        }
        catch (OperationCanceledException)
        {
            // 전투 종료·씬 이탈 — 정리 경로에서 복구한다.
        }
        finally
        {
            if (_active)
            {
                ReleaseRestrictions(restoreUi: true);
                DetachBattleHandlers();
            }
        }
    }

    private async UniTask<Card> GuidePlacementAsync(
        int placementIndex,
        string promptBodyKey,
        CancellationToken token)
    {
        TutorialBattleBasicsSO.GuidedPlacement placement = _basics.Placements[placementIndex];
        UICard uiCard = FindLessonCard(placement.Card.CardId);
        if (uiCard == null || uiCard.BoundCard == null)
            throw new InvalidOperationException($"필수 실습 카드 없음: {placement.Card.CardId}");

        _battle.SetPlacementLocked(true);
        SetAllHandInteractable(false);
        await RevealStagedCardAsync(uiCard, token);
        _waitingCard = uiCard.BoundCard;
        _battle.SetAllowedPlacementCard(_waitingCard);
        _battle.SetAllowedPlacementPosition(placement.Position);
        _grid.SetTutorialTargetMarker(placement.Position, _basics.MarkerColor);
        _hand.SelectCard(uiCard);
        ApplyUiLocks();
        await ShowMentAsync(
            promptBodyKey,
            _owlAnchorIds,
            token,
            allowReplayAfterClose: true);

        _waitingChain = new UniTaskCompletionSource<Card>();
        SetOnlyCardInteractable(uiCard);
        _hand.SelectCard(uiCard);
        _battle.SetPlacementLocked(false);

        Card placed = await _waitingChain.Task.AttachExternalCancellation(token);
        if (TutorialDirector.Active != null)
            TutorialDirector.Active.ClearReplayGuide();
        while (_battle != null && _battle.IsProcessing)
            await UniTask.Yield(token);

        _waitingCard = null;
        _waitingChain = null;
        _battle.SetPlacementLocked(true);
        _battle.SetAllowedPlacementCard(null);
        _battle.SetAllowedPlacementPosition(null);
        _grid.ClearTutorialTargetMarker();
        SetAllHandInteractable(false);
        ApplyUiLocks();
        return placed;
    }

    private UniTask HandleChainEndedAsync(Card card, CancellationToken token)
    {
        if (_waitingCard == card)
            _waitingChain?.TrySetResult(card);
        if (_manaZeroPending)
        {
            _manaZeroPending = false;
            _manaZeroChain?.TrySetResult();
        }
        return UniTask.CompletedTask;
    }

    private void HandlePlayerEnergyChanged(int current, int max)
    {
        if (_active && current == 0)
            _manaZeroPending = true;
    }

    private void HandleProcessingChanged(bool processing)
    {
        if (_active && !processing)
            ApplyUiLocks();
    }

    private void HandlePlayerTurnConfirmed()
    {
        if (_active && _allowEndTurn)
            _turnConfirmed?.TrySetResult();
    }

    private void HandleBattleEnded(bool victory)
    {
        if (!_active) return;
        ReleaseRestrictions(restoreUi: false);
        DetachBattleHandlers();
        _cts?.Cancel();
    }

    private void AttachBattleHandlers()
    {
        _battle.OnChainEndedAsync += HandleChainEndedAsync;
        _battle.OnPlayerEnergyChanged += HandlePlayerEnergyChanged;
        _battle.OnProcessingChanged += HandleProcessingChanged;
        _battle.OnPlayerTurnConfirmed += HandlePlayerTurnConfirmed;
        _battle.OnBattleEnded += HandleBattleEnded;
    }

    private void DetachBattleHandlers()
    {
        if (_battle == null) return;
        _battle.OnChainEndedAsync -= HandleChainEndedAsync;
        _battle.OnPlayerEnergyChanged -= HandlePlayerEnergyChanged;
        _battle.OnProcessingChanged -= HandleProcessingChanged;
        _battle.OnPlayerTurnConfirmed -= HandlePlayerTurnConfirmed;
        _battle.OnBattleEnded -= HandleBattleEnded;
    }

    private void ApplyUiLocks()
    {
        if (!_active || _battleUI == null) return;
        _battleUI.SetEndTurnInteractable(_allowEndTurn);
        _battleUI.SetSkillPanelInteractable(false);
    }

    private void ReleaseRestrictions(bool restoreUi)
    {
        RestoreStagedHandPresentation();
        if (_battle != null)
        {
            _battle.SetPlacementLocked(false);
            _battle.SetAllowedPlacementCard(null);
            _battle.SetAllowedPlacementPosition(null);
        }
        _grid?.ClearTutorialTargetMarker();
        HighlightDefenseCards(false);
        SetAllHandInteractable(true);

        if (restoreUi && _battleUI != null && _battle != null
            && _battle.IsBattleActive && _battle.CurrentPhase == EBattlePhase.PlayerInput)
        {
            _battleUI.SetEndTurnInteractable(!_battle.IsProcessing);
            _battleUI.SetSkillPanelInteractable(!_battle.IsProcessing);
        }
        _active = false;
    }

    private bool PrepareInitialHandPresentation()
    {
        IReadOnlyList<CardDataSO> firstDrawCards = _basics.FirstDrawCards;
        if (firstDrawCards == null || firstDrawCards.Count != 7
            || _basics.Placements.Count != 3)
        {
            return false;
        }

        _lessonHandCards.Clear();
        _stagedHandCards.Clear();
        for (int i = 0; i < firstDrawCards.Count; i++)
        {
            CardDataSO cardData = firstDrawCards[i];
            UICard uiCard = cardData != null
                ? FindUnusedHandCard(cardData.CardId)
                : null;
            if (uiCard == null)
                return false;

            _lessonHandCards.Add(uiCard);
        }

        for (int i = 0; i < _lessonHandCards.Count; i++)
        {
            UICard uiCard = _lessonHandCards[i];
            if (!_hand.StageCardForTutorial(uiCard))
            {
                RestoreStagedHandPresentation();
                return false;
            }
            _stagedHandCards.Add(uiCard);
        }
        return true;
    }

    private UICard FindUnusedHandCard(string cardId)
    {
        IReadOnlyList<UICard> cards = _hand != null ? _hand.Cards : null;
        if (cards == null) return null;

        for (int i = 0; i < cards.Count; i++)
        {
            UICard card = cards[i];
            if (card != null
                && !_lessonHandCards.Contains(card)
                && card.BoundCard != null
                && card.BoundCard.CardId == cardId)
            {
                return card;
            }
        }
        return null;
    }

    private UICard FindLessonCard(string cardId)
    {
        for (int i = 0; i < _lessonHandCards.Count; i++)
        {
            UICard card = _lessonHandCards[i];
            if (card != null && card.BoundCard != null && card.BoundCard.CardId == cardId)
                return card;
        }
        return null;
    }

    private async UniTask RevealStagedCardAsync(UICard uiCard, CancellationToken token)
    {
        if (uiCard == null || !_stagedHandCards.Remove(uiCard)) return;
        if (!_hand.RestoreTutorialStagedCard(uiCard)) return;

        uiCard.SetVisualVisible(false);
        if (CardAnimationSystem.HasInstance)
            await CardAnimationSystem.Instance.PlayDrawAnim(uiCard, _hand, token);
        else
            uiCard.SetVisualVisible(true);

        uiCard.SetInteractable(false);
        uiCard.SetRaycastTarget(false);
    }

    private async UniTask RevealRemainingCardsAsync(CancellationToken token)
    {
        for (int i = 3; i < _lessonHandCards.Count; i++)
            await RevealStagedCardAsync(_lessonHandCards[i], token);
    }

    private void RestoreStagedHandPresentation()
    {
        if (_hand == null) return;

        _hand.RestoreAllTutorialStagedCards();
        _stagedHandCards.Clear();
        IReadOnlyList<UICard> cards = _hand.Cards;
        for (int i = 0; i < cards.Count; i++)
            cards[i]?.SetVisualVisible(true);
        _lessonHandCards.Clear();
    }

    private void SetOnlyCardInteractable(UICard allowed)
    {
        IReadOnlyList<UICard> cards = _hand.Cards;
        for (int i = 0; i < cards.Count; i++)
        {
            UICard card = cards[i];
            if (card == null) continue;
            bool enabled = card == allowed;
            card.SetInteractable(enabled);
            card.SetRaycastTarget(enabled);
        }
    }

    private void SetAllHandInteractable(bool interactable)
    {
        IReadOnlyList<UICard> cards = _hand != null ? _hand.Cards : null;
        if (cards == null) return;

        for (int i = 0; i < cards.Count; i++)
        {
            UICard card = cards[i];
            if (card == null) continue;
            card.SetInteractable(interactable);
            card.SetRaycastTarget(interactable);
            if (!interactable)
                card.SetTutorialHighlightVisible(false);
        }
    }

    private void HighlightDefenseCards(bool visible)
    {
        if (_defenseCard != null && _grid != null)
            _grid.SetCardPreserveHighlight(_defenseCard, visible);

        IReadOnlyList<UICard> cards = _hand != null ? _hand.Cards : null;
        if (cards == null) return;
        for (int i = 0; i < cards.Count; i++)
        {
            UICard uiCard = cards[i];
            if (uiCard?.BoundCard != null
                && uiCard.BoundCard.HasEffect(ECardEffectFlag.Block))
            {
                uiCard.SetTutorialHighlightVisible(visible);
            }
        }
    }

    private async UniTask ShowMentAsync(
        string bodyKey,
        IReadOnlyList<string> anchorIds,
        CancellationToken token,
        bool allowReplayAfterClose = false)
    {
        if (string.IsNullOrEmpty(bodyKey) || !UIManager.HasInstance) return;

        UITutorialPanel panel = await UIManager.Instance.OpenAsync<UITutorialPanel>(token);
        if (panel == null)
        {
            Debug.LogError("[TutorialSecondBattleSequence] 대사 패널 열기 실패.");
            return;
        }

        var pages = new List<TutorialPageContent>(1)
        {
            new TutorialPageContent(bodyKey, null, EPanelPlacement.Bottom, anchorIds),
        };
        await panel.ShowStepAsync(
            _basics.SpeakerTitleKey,
            pages,
            token,
            allowReplayAfterClose: allowReplayAfterClose);
    }
}
