// =================================================================
// [스크립트 목적]  애널리틱스 단일 진입점. 의미 이벤트 → 2계층(GA/UGS) 라우팅
// [주요 변수]      - _paramBuffer : UGS 이벤트 파라미터 조립용 재사용 딕셔너리
// [의존 관계]      - AnalyticsManager (전송), AnalyticsKeys (문자열), Buffers (축적)
// [비고]           게임플레이 코드는 GA/UGS SDK를 절대 직접 호출하지 않는다. 이 클래스만 안다.
//                  어떤 이벤트가 GA로 가고 어떤 게 UGS로 가는지는 오직 여기서만 결정된다.
//
//                  계층 A (GA)  : 저카디널리티 카운트·집계. 즉시 전송
//                  계층 B (UGS) : 리치 데이터. 노드/런 종료 시 1개로 묶어 전송
//
//                  AnalyticsManager가 없어도(부트스트랩 전, 테스트 씬 등) 조용히 무동작한다.
//                  분석 호출이 게임을 멈추는 일은 없어야 한다.
// =================================================================
using System.Collections.Generic;

/// <summary>애널리틱스 단일 진입점. 게임플레이 코드는 이 클래스만 호출한다.</summary>
public static class GameLog
{
    // UGS 이벤트 파라미터 조립용. 저빈도·단일 스레드라 공유 안전.
    // AnalyticsManager.LogEvent가 즉시 소비하므로 참조가 밖으로 새지 않는다.
    private static readonly Dictionary<string, object> ParamBuffer = new(16);
    private static readonly HashSet<string> LoggedStatisticsRunIds = new HashSet<string>();

    /// <summary>AnalyticsManager가 살아 있는가. 없으면 모든 호출이 무동작.</summary>
    private static bool IsAvailable => AnalyticsManager.HasInstance;

    /// <summary>Live에서 디버그 커맨드 접근이 감지됐을 때 GA Error와 이벤트를 함께 남긴다.</summary>
    public static void DebugCommandBlocked(string command)
    {
        if (!IsAvailable) return;
        string safe = string.IsNullOrWhiteSpace(command) ? "unknown" : command;
        AnalyticsManager.Instance.LogKpiError($"Live debug command blocked: {safe}");
        AnalyticsManager.Instance.LogKpiDesign($"debug_command:live_blocked:{safe}");
        AnalyticsManager.Instance.LogEvent("debug_command_live_blocked", "command", safe);
    }

    // ─────────────────────────────────────────────
    // 런 수명
    // ─────────────────────────────────────────────

    /// <summary>
    /// 런 시작. GA에는 시작 팩만(저카디널리티), UGS에는 시드·덱 정보를 보낸다.
    /// [중요] seed는 GA 이벤트 문자열에 절대 넣지 않는다 — 고유 노드가 무한히 늘어난다.
    /// </summary>
    public static void RunStart(
        string runId,
        int seed,
        IReadOnlyList<string> packIds,
        ERunDifficulty difficulty)
    {
        if (!IsAvailable) return;

        // 계층 A: 시작 팩별 픽률
        if (packIds != null)
        {
            for (int i = 0; i < packIds.Count; i++)
                AnalyticsManager.Instance.LogKpiDesign(AnalyticsKeys.Ga.RunStartPack(packIds[i], difficulty));
        }

        // 계층 B: 재현에 필요한 원본 데이터
        ParamBuffer.Clear();
        ParamBuffer[AnalyticsKeys.Ugs.P_RUN_ID] = runId;
        ParamBuffer[AnalyticsKeys.Ugs.P_DIFFICULTY] = RunDifficultyUtility.ToLogValue(difficulty);
        ParamBuffer[AnalyticsKeys.Ugs.P_SEED] = seed;
        ParamBuffer[AnalyticsKeys.Ugs.P_PACK_IDS] = JoinIds(packIds);

        AnalyticsManager.Instance.LogEvent(AnalyticsKeys.Ugs.EVENT_RUN_START, ParamBuffer);
    }

    /// <summary>진행 중 앱 종료. 확정 결과(abandon)가 아니라 재개 가능한 위치만 GA에 남긴다.</summary>
    public static void RunSuspend(int stageNumber, int floor, ERunDifficulty difficulty)
    {
        if (!IsAvailable) return;
        AnalyticsManager.Instance.LogKpiDesign(AnalyticsKeys.Ga.RunSuspend(stageNumber, floor, difficulty));
    }

    /// <summary>저장 런 이어하기. 신규 run_start와 분리해 시작 횟수 중복을 막는다.</summary>
    public static void RunResume(int stageNumber, int floor, ERunDifficulty difficulty)
    {
        if (!IsAvailable) return;
        AnalyticsManager.Instance.LogKpiDesign(AnalyticsKeys.Ga.RunResume(stageNumber, floor, difficulty));
    }

    /// <summary>스테이지 진입. GA Progression Start.</summary>
    public static void StageStart(int stageNumber, ERunDifficulty difficulty)
    {
        if (!IsAvailable) return;

        AnalyticsManager.Instance.LogKpiProgression(
            EProgressionStatus.Start,
            $"{RunDifficultyUtility.ToLogValue(difficulty)}_{AnalyticsKeys.Ga.Stage(stageNumber)}",
            0);
    }

    /// <summary>스테이지 클리어(보스 격파). GA Progression Complete. score = 도달 층.</summary>
    public static void StageComplete(int stageNumber, int reachedFloor, ERunDifficulty difficulty)
    {
        if (!IsAvailable) return;

        AnalyticsManager.Instance.LogKpiProgression(
            EProgressionStatus.Complete,
            $"{RunDifficultyUtility.ToLogValue(difficulty)}_{AnalyticsKeys.Ga.Stage(stageNumber)}",
            reachedFloor);
    }

    /// <summary>
    /// 사망. GA Progression Fail(진행 깊이) + Design death(사망 원인)를 분리해 쏜다.
    /// 층은 라벨이 아니라 score/value로 실어 카디널리티를 늘리지 않는다.
    /// </summary>
    public static void Death(
        int stageNumber,
        int reachedFloor,
        ENodeType nodeType,
        string enemyId,
        ERunDifficulty difficulty)
    {
        if (!IsAvailable) return;

        AnalyticsManager.Instance.LogKpiProgression(
            EProgressionStatus.Fail,
            $"{RunDifficultyUtility.ToLogValue(difficulty)}_{AnalyticsKeys.Ga.Stage(stageNumber)}",
            reachedFloor);

        AnalyticsManager.Instance.LogKpiDesign(
            AnalyticsKeys.Ga.Death(stageNumber, nodeType, enemyId), reachedFloor);
    }

    /// <summary>런 종료. UGS run_end 1개로 런 전체 요약을 flush한다.</summary>
    public static void RunEnd(
        RunAnalyticsBuffer run,
        ERunEndReason reason,
        float realtimeNow,
        int reachedFloor,
        int reachedStage,
        IReadOnlyList<string> deckCardIds,
        string deathEnemyId,
        string deathIntent,
        string deathNodeJson,
        ERunDifficulty difficulty)
    {
        // 동의가 런 도중 변경되면 AnalyticsBridge가 버퍼를 Clear한다.
        // 빈 RunId로 반쪽짜리 run_end를 보내지 않는다.
        if (!IsAvailable || run == null || string.IsNullOrEmpty(run.RunId)) return;

        ParamBuffer.Clear();
        ParamBuffer[AnalyticsKeys.Ugs.P_RUN_ID] = run.RunId ?? string.Empty;
        ParamBuffer[AnalyticsKeys.Ugs.P_DIFFICULTY] = RunDifficultyUtility.ToLogValue(difficulty);
        ParamBuffer[AnalyticsKeys.Ugs.P_REASON] = AnalyticsKeys.Ugs.Reason(reason);
        ParamBuffer[AnalyticsKeys.Ugs.P_PLAY_SECONDS] = run.PlaySeconds(realtimeNow);
        ParamBuffer[AnalyticsKeys.Ugs.P_REACHED_FLOOR] = reachedFloor;
        ParamBuffer[AnalyticsKeys.Ugs.P_REACHED_STAGE] = reachedStage;
        ParamBuffer[AnalyticsKeys.Ugs.P_DECK_JSON] = RunAnalyticsBuffer.BuildDeckJson(deckCardIds);
        ParamBuffer[AnalyticsKeys.Ugs.P_DAMAGE_MAP_JSON] = run.BuildDamageMapJson();
        ParamBuffer[AnalyticsKeys.Ugs.P_SKILL_USE_JSON] = run.BuildSkillUseJson();
        ParamBuffer[AnalyticsKeys.Ugs.P_INFINITE_LOOP_COUNT] = run.InfiniteLoopCount;

        // 사망 시에만 채운다. 클리어/포기 런에서는 파라미터 자체가 빠진다.
        if (!string.IsNullOrEmpty(deathEnemyId))
        {
            ParamBuffer[AnalyticsKeys.Ugs.P_DEATH_ENEMY_ID] = deathEnemyId;
            ParamBuffer[AnalyticsKeys.Ugs.P_DEATH_INTENT] = deathIntent ?? string.Empty;
            ParamBuffer[AnalyticsKeys.Ugs.P_DEATH_NODE_JSON] = deathNodeJson ?? "{}";
        }

        AnalyticsManager.Instance.LogEvent(AnalyticsKeys.Ugs.EVENT_RUN_END, ParamBuffer);

        // run_end는 런의 마지막 이벤트라 UGS의 60초 업로드 주기를 못 기다리고 유실되기 쉽다.
        // (타이틀 복귀·플레이 모드 종료가 바로 뒤따른다.) 즉시 업로드한다.
        AnalyticsManager.Instance.FlushExternal();
    }

    /// <summary>GA 전용 런 결과와 비교 가능한 한 판 통계를 전송한다. UGS에는 관여하지 않는다.</summary>
    public static void RunStatistics(
        string runId,
        RunStatisticsSnapshot snapshot,
        bool includeActiveRunSeconds,
        ERunDifficulty difficulty)
    {
        if (!IsAvailable || snapshot == null || string.IsNullOrEmpty(runId)) return;
        if (!LoggedStatisticsRunIds.Add(runId)) return;

        AnalyticsManager analytics = AnalyticsManager.Instance;
        ERunEndReason result = snapshot.Result;
        analytics.LogKpiDesign(AnalyticsKeys.Ga.RunResult(result, difficulty));
        // 이어하기 런은 저장 이전 시간이 복원되지 않으므로 전체 런 시간으로 오해될 값을 보내지 않는다.
        if (includeActiveRunSeconds)
            analytics.LogKpiDesign(AnalyticsKeys.Ga.RunStatistic(result, "active_run_seconds", difficulty), snapshot.ActiveRunSeconds);
        analytics.LogKpiDesign(AnalyticsKeys.Ga.RunStatistic(result, "battles_started", difficulty), snapshot.BattlesStarted);
        analytics.LogKpiDesign(AnalyticsKeys.Ga.RunStatistic(result, "max_battle_turns", difficulty), snapshot.MaxBattleTurns);
        analytics.LogKpiDesign(AnalyticsKeys.Ga.RunStatistic(result, "infinite_loops", difficulty), snapshot.InfiniteLoopCount);
        analytics.LogKpiDesign(AnalyticsKeys.Ga.RunStatistic(result, "final_deck_size", difficulty), snapshot.FinalDeckCount);
        analytics.LogKpiDesign(AnalyticsKeys.Ga.RunStatistic(result, "reinforcement_count", difficulty), snapshot.ReinforcementCount);

        if (snapshot.BattlesWon > 0)
            analytics.LogKpiDesign(AnalyticsKeys.Ga.RunStatistic(result, "no_damage_win_ratio", difficulty), snapshot.NoDamageWinRatio);
        if (snapshot.BattlesCompleted > 0)
        {
            analytics.LogKpiDesign(AnalyticsKeys.Ga.RunStatistic(result, "average_turns_per_battle", difficulty), snapshot.AverageTurnsPerBattle);
            analytics.LogKpiDesign(AnalyticsKeys.Ga.RunStatistic(result, "average_damage_per_battle", difficulty), snapshot.AverageDamagePerBattle);
        }
        if (snapshot.TotalPlayerTurns > 0)
            analytics.LogKpiDesign(AnalyticsKeys.Ga.RunStatistic(result, "average_card_placements_per_turn", difficulty), snapshot.AverageCardPlacementsPerTurn);
        if (!string.IsNullOrEmpty(snapshot.TopCardId))
            analytics.LogKpiDesign(AnalyticsKeys.Ga.RunTopCard(result, snapshot.TopCardId, difficulty), snapshot.TopCardCount);
    }

    /// <summary>GA 전용 전투 결과. 이벤트 count=표본/승패 수, value=평균 턴 계산용.</summary>
    public static void BattleResult(ENodeType nodeType, string enemyId, bool victory, int turns)
    {
        if (!IsAvailable) return;
        AnalyticsManager.Instance.LogKpiDesign(
            AnalyticsKeys.Ga.BattleResult(nodeType, enemyId, victory),
            turns > 0 ? turns : 0);
    }

    // ─────────────────────────────────────────────
    // 노드 수명
    // ─────────────────────────────────────────────

    /// <summary>
    /// 노드 방문 집계 (GA). value=체류 시간(초).
    /// 노드 타입별 방문 수·평균 체류 시간을 GA 대시보드에서 바로 볼 수 있게 한다.
    /// </summary>
    public static void NodeVisit(ENodeType nodeType, float durationSeconds)
    {
        if (!IsAvailable) return;

        AnalyticsManager.Instance.LogKpiDesign(AnalyticsKeys.Ga.NodeVisit(nodeType), durationSeconds);
    }

    /// <summary>
    /// 스테이지 1개 분량의 노드 요약을 UGS 이벤트 1개로 전송한다.
    ///
    /// 노드마다 보내면 완주 1회에 32개(=30노드+2)가 나가 UGS Fair Usage 권장치를 빠르게 태운다.
    /// 스테이지 단위로 묶으면 런당 5개가 된다. 노드별 상세 데이터는 nodes_json에 전부 보존되지만,
    /// 대시보드에서 필터·집계는 불가능하다(원본 export 필요) — 그래서 GA node_visit을 함께 쏜다.
    /// </summary>
    public static void StageNodes(
        StageAnalyticsBuffer stage,
        string runId,
        ERunDifficulty difficulty)
    {
        if (!IsAvailable || stage == null || stage.IsEmpty) return;

        ParamBuffer.Clear();
        ParamBuffer[AnalyticsKeys.Ugs.P_RUN_ID] = runId ?? string.Empty;
        ParamBuffer[AnalyticsKeys.Ugs.P_DIFFICULTY] = RunDifficultyUtility.ToLogValue(difficulty);
        ParamBuffer[AnalyticsKeys.Ugs.P_STAGE] = stage.Stage;
        ParamBuffer[AnalyticsKeys.Ugs.P_NODE_COUNT] = stage.Count;
        ParamBuffer[AnalyticsKeys.Ugs.P_NODES_JSON] = stage.BuildNodesJson();

        AnalyticsManager.Instance.LogEvent(AnalyticsKeys.Ugs.EVENT_STAGE_NODES, ParamBuffer);
    }

    // ─────────────────────────────────────────────
    // 계층 A 전용 — 즉시 전송되는 KPI 신호
    // ─────────────────────────────────────────────

    /// <summary>적별 피격. value=데미지 → GA가 합/평균을 자동 집계한다.</summary>
    public static void DamageTaken(string enemyId, int damage)
    {
        if (!IsAvailable || damage <= 0) return;

        AnalyticsManager.Instance.LogKpiDesign(AnalyticsKeys.Ga.DamageTaken(enemyId), damage);
    }

    /// <summary>
    /// 런 종료 시 카드별 사용 횟수를 GA로 1건씩 flush한다.
    ///
    /// [왜 배치마다 쏘지 않는가]
    /// GA Design 이벤트는 집계 가능한 수치가 eventValue(float) 하나뿐이다
    /// (customFields는 raw export 전용이라 대시보드에 안 보인다).
    /// 배치마다 1건씩 쏘면 런당 수백 건이 나가면서 "런당 평균 사용 횟수"는 얻지 못한다.
    /// 런 종료에 카드별 1건 + value=횟수로 보내면 GA가 Mean/Sum을 자동 집계하고
    /// 이벤트 수도 덱 크기 수준으로 줄어든다.
    /// </summary>
    public static void FlushSkillUse(RunAnalyticsBuffer run)
    {
        if (!IsAvailable || run == null) return;

        foreach (KeyValuePair<string, int> pair in run.SkillUse)
        {
            if (pair.Value <= 0) continue;
            AnalyticsManager.Instance.LogKpiDesign(AnalyticsKeys.Ga.SkillUse(pair.Key), pair.Value);
        }
    }

    /// <summary>휴식 노드에서 회복/강화 중 무엇을 골랐는가.</summary>
    public static void RestChoice(bool isUpgrade)
    {
        if (!IsAvailable) return;

        AnalyticsManager.Instance.LogKpiDesign(AnalyticsKeys.Ga.RestNode(isUpgrade));
    }

    /// <summary>보상 노드에서 실제로 선택된 카드.</summary>
    public static void RewardPick(string cardId)
    {
        if (!IsAvailable) return;

        AnalyticsManager.Instance.LogKpiDesign(AnalyticsKeys.Ga.RewardPick(cardId));
    }

    /// <summary>상점 카드 구매. Design 카운트 + 골드 Sink를 함께 쏜다.</summary>
    public static void ShopBuy(string cardId, int price)
    {
        if (!IsAvailable) return;

        AnalyticsManager.Instance.LogKpiDesign(AnalyticsKeys.Ga.ShopBuy(cardId));
        AnalyticsManager.Instance.LogKpiResourceSink(
            AnalyticsKeys.Ga.CURRENCY_GOLD, price, AnalyticsKeys.Ga.ITEM_TYPE_SHOP_BUY, cardId);
    }

    /// <summary>덱에서 카드 제거. Design 카운트 + 골드 Sink를 함께 쏜다.</summary>
    public static void CardRemove(string cardId, int cost)
    {
        if (!IsAvailable) return;

        AnalyticsManager.Instance.LogKpiDesign(AnalyticsKeys.Ga.CardRemove(cardId));
        AnalyticsManager.Instance.LogKpiResourceSink(
            AnalyticsKeys.Ga.CURRENCY_GOLD, cost, AnalyticsKeys.Ga.ITEM_TYPE_CARD_REMOVE, cardId);
    }

    /// <summary>
    /// 무한루프 발동. 매 발동마다 카운트하고, 런 내 첫 발동일 때만 위치까지 남긴다.
    /// isFirstInRun은 RunAnalyticsBuffer.AddInfiniteLoop()의 반환값을 그대로 넘긴다.
    /// </summary>
    public static void InfiniteLoop(bool isFirstInRun, int stageNumber, int floor)
    {
        if (!IsAvailable) return;

        AnalyticsManager.Instance.LogKpiDesign(AnalyticsKeys.Ga.INFINITE_LOOP_TRIGGER);

        if (isFirstInRun)
            AnalyticsManager.Instance.LogKpiDesign(AnalyticsKeys.Ga.InfiniteLoopFirst(stageNumber, floor));
    }

    // ─────────────────────────────────────────────
    // 내부
    // ─────────────────────────────────────────────

    /// <summary>packId 목록을 콤마 구분 문자열로. UGS 파라미터는 배열을 받지 않는다.</summary>
    private static string JoinIds(IReadOnlyList<string> ids)
    {
        if (ids == null || ids.Count == 0) return string.Empty;
        if (ids.Count == 1) return ids[0];

        return string.Join(",", ids);
    }
}
