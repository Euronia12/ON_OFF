// =================================================================
// [스크립트 목적]  기존 게임 이벤트를 구독해 GameLog로 흘려보내는 배선 계층
// [주요 변수]      - _run  : 런 1개 분량 누적 버퍼
//                  - _node : 노드 1개 분량 축적 버퍼 (노드 종료 시 flush)
// [의존 관계]      - InGameController / BattleController / BattleManager
//                  - ShopController / RestController / ReinforceController
//                  - GameLog (전송), RunAnalyticsBuffer / NodeAnalyticsBuffer (축적)
// [배치]           인게임 씬에 1개 배치. InGameController와 같은 GameObject도 무방
// [비고]           단방향 의존을 지킨다 — 이 클래스가 컨트롤러를 구독할 뿐,
//                  컨트롤러는 이 클래스의 존재를 모른다. 게임 로직에 일절 개입하지 않는다.
//
//                  구독 대상 컨트롤러는 SceneSingleton이라 씬 로드 순서가 보장되지 않는다.
//                  그래서 Start()에서 구독하고, 인스턴스가 없으면 그 소스만 조용히 건너뛴다.
//
//                  노드 종료 flush는 InGameController.OnNodeExited 한 지점에서만 일어난다.
//                  전투 노드는 이 시점이면 보상 수령까지 끝나 있으므로 보상 데이터도 함께 실린다.
// =================================================================
using UnityEngine;

/// <summary>게임 이벤트 → GameLog 배선. 게임 로직에 개입하지 않는 순수 관찰자.</summary>
public sealed class AnalyticsBridge : MonoBehaviour
{
    [Header("디버그")]
    [Tooltip("구독/flush 시점을 콘솔에 출력. 이벤트 누락을 추적할 때 켠다")]
    [SerializeField] private bool _verboseLog = false;

    private readonly RunAnalyticsBuffer _run = new RunAnalyticsBuffer();
    private readonly NodeAnalyticsBuffer _node = new NodeAnalyticsBuffer();
    private readonly StageAnalyticsBuffer _stage = new StageAnalyticsBuffer();

    // 현재 노드의 적 ID. 사망 시 run_end에 실린다.
    private string _currentEnemyId;

    // 마지막 노드 메타 스냅샷.
    // FinishRun은 OnNodeExited(=버퍼 flush·clear)를 OnRunFinished보다 먼저 발행한다.
    // 따라서 사망 노드 정보를 _node에서 읽으면 이미 비어 있다. 여기 미리 복사해 둔다.
    private ENodeType _lastNodeType;
    private int _lastNodeId;
    private int _lastFloor;
    private int _lastStage;

    // 구독 성공 여부. OnDestroy에서 해제 대상을 가린다.
    private bool _subscribed;

    // Start가 한 번 실행된 뒤 재활성화될 때 게임 이벤트를 다시 구독하기 위한 플래그.
    private bool _hasStarted;

    // OnEnable에서 구독한 정확한 SettingsManager 대상. OnDisable에서 같은 대상에서 해제한다.
    private SettingsManager _consentSettings;

    private void Start()
    {
        _hasStarted = true;

        // 튜토리얼도 InGameController로 진짜 런(_autoStartRun)을 돌린다.
        // 신규 유저 전원이 거치는 경로라 그대로 집계하면 퍼널·사망분포가 통째로 왜곡된다.
        // 씬에 실수로 배치되더라도 여기서 막는다.
        if (TutorialDirector.IsActive)
        {
            GameLogger.Log(ELogCategory.Analytics, "[AnalyticsBridge] 튜토리얼 씬 - 분석 수집을 건너뜁니다");
            return;
        }

        Subscribe();
    }

    private void OnEnable()
    {
        // wantsToQuit 은 Application.quitting 보다 먼저 불린다.
        // UGS SDK 도 quitting 에 CleanUp(→ FlushToDisk)을 걸어두므로, 우리 버퍼를 이벤트로
        // 넘기려면 반드시 그보다 앞서야 한다. 순서가 뒤집히면 그 런의 데이터가 유실된다.
        Application.wantsToQuit += HandleWantsToQuit;

        if (SettingsManager.HasInstance)
        {
            _consentSettings = SettingsManager.Instance;
            _consentSettings.OnAnalyticsConsentChanged += HandleConsentChanged;
        }

        // 첫 활성화의 게임 이벤트 구독은 Start에서 한다. 이후 재활성화는 여기서 복구한다.
        if (_hasStarted && !TutorialDirector.IsActive)
            Subscribe();
    }

    private void OnDisable()
    {
        Application.wantsToQuit -= HandleWantsToQuit;

        if (_consentSettings != null)
            _consentSettings.OnAnalyticsConsentChanged -= HandleConsentChanged;
        _consentSettings = null;

        Unsubscribe();
    }

    /// <summary>
    /// 수집 동의가 바뀌면 쌓아 둔 버퍼를 통째로 버린다.
    ///
    /// 끌 때 : 비동의 구간에 메모리에 남은 데이터가 나중에 재동의하면 함께 전송되는 것을 막는다.
    /// 켤 때 : run_start 없이 run_end만 올라가 반쪽짜리 런이 집계되는 것을 막는다.
    ///
    /// 버퍼를 비우면 RunId=null / IsActive=false가 되어 이후 flush 경로가 스스로 조기 반환한다.
    /// "동의 상태가 중간에 바뀐 런"은 어느 쪽으로도 정확하지 않으므로 통째로 포기하는 편이 낫다.
    /// </summary>
    private void HandleConsentChanged(bool granted)
    {
        _run.Clear();
        _node.Clear();
        _stage.Clear();
        _currentEnemyId = null;

        if (_verboseLog)
            GameLogger.Log(ELogCategory.Analytics,
                $"[AnalyticsBridge] 수집 동의 변경(granted={granted}) - 진행 중 버퍼 폐기");
    }

    private void OnDestroy() => Unsubscribe();

    /// <summary>
    /// 앱 종료 직전(Alt+F4 / 창 닫기 / 에디터 플레이 정지). 진행 중인 런을 포기로 마무리한다.
    ///
    /// 네트워크 전송이 끝날 때까지 기다릴 필요는 없다. UGS SDK 가 종료 시 버퍼를 디스크에 적고
    /// (AnalyticsServiceInstance.ApplicationQuit → FlushToDisk) 다음 실행의 LoadFromDisk 에서
    /// 올려주기 때문이다. 우리는 RecordEvent 까지만 도달시키면 된다.
    ///
    /// 프로세스 강제 종료·크래시는 이 경로를 타지 않는다(어떤 방법으로도 잡을 수 없다).
    /// </summary>
    /// <returns>항상 true — 종료를 막지 않는다.</returns>
    private bool HandleWantsToQuit()
    {
        if (_subscribed && InGameController.HasInstance)
        {
            InGameController inGame = InGameController.Instance;
            if (inGame.IsRunActive)
            {
                // 앱 종료는 저장 런을 다시 이어갈 수 있으므로 확정 포기(abandon)로 기록하지 않는다.
                // 진행 중 노드 체류 시간은 닫고, 종료 위치만 suspend 이벤트로 남긴다.
                HandleNodeExited();
                RunContext run = inGame.CurrentRun;
                int floor = run != null ? run.CurrentFloor : 0;
                GameLog.RunSuspend(inGame.CurrentStageNumber, floor, inGame.CurrentDifficulty);
            }
        }

        return true;
    }

    // ─────────────────────────────────────────────
    // 구독 / 해제
    // ─────────────────────────────────────────────

    private void Subscribe()
    {
        if (_subscribed) return;

        if (InGameController.HasInstance)
        {
            InGameController inGame = InGameController.Instance;
            inGame.OnRunStarted += HandleRunStarted;
            inGame.OnRunResumed += HandleRunResumed;
            inGame.OnNodeEntered += HandleNodeEntered;
            inGame.OnNodeExited += HandleNodeExited;
            inGame.OnRunFinished += HandleRunFinished;
            inGame.OnRunAbandoned += HandleRunAbandoned;
            inGame.OnBattleResult += HandleBattleResult;
            inGame.OnStageCleared += HandleStageCleared;
            inGame.OnRewardOffered += HandleRewardOffered;
            inGame.OnRewardPicked += HandleRewardPicked;
            inGame.OnRewardGoldClaimed += HandleRewardGoldClaimed;
        }
        else
        {
            GameLogger.LogWarning(ELogCategory.Analytics, "[AnalyticsBridge] InGameController 부재 - 런/노드 이벤트를 수집하지 않습니다");
        }

        if (BattleController.HasInstance)
        {
            BattleController battle = BattleController.Instance;
            battle.OnInfiniteLoopDetected += HandleInfiniteLoop;
            battle.OnPlayerDamageTaken += HandlePlayerDamageTaken;
        }

        if (BattleManager.HasInstance)
        {
            BattleManager battle = BattleManager.Instance;
            battle.OnCardPlaced += HandleCardPlaced;
            battle.OnCardRecalled += HandleCardRecalled;
            battle.OnPlayerTurnConfirmed += HandleTurnConfirmed;
        }

        // 소멸은 그리드가 안다. 회수도 이 경로를 지나므로 HandleCardRecalled 가 뒤에서 바로잡는다.
        if (GridManager.HasInstance)
            GridManager.Instance.OnCardRemovedAt += HandleCardRemovedAt;

        if (ShopController.HasInstance)
        {
            ShopController shop = ShopController.Instance;
            shop.OnInventoryBuilt += HandleShopInventoryBuilt;
            shop.OnCardPurchased += HandleShopPurchase;
            shop.OnCardRemoved += HandleShopRemoval;
        }

        if (RestController.HasInstance)
            RestController.Instance.OnRestChoiceMade += HandleRestChoice;

        if (ReinforceController.HasInstance)
            ReinforceController.Instance.OnCardReinforced += HandleCardReinforced;

        _subscribed = true;

        if (_verboseLog)
            GameLogger.Log(ELogCategory.Analytics, "[AnalyticsBridge] 구독 완료");
    }

    private void Unsubscribe()
    {
        if (!_subscribed) return;

        if (InGameController.HasInstance)
        {
            InGameController inGame = InGameController.Instance;
            inGame.OnRunStarted -= HandleRunStarted;
            inGame.OnRunResumed -= HandleRunResumed;
            inGame.OnNodeEntered -= HandleNodeEntered;
            inGame.OnNodeExited -= HandleNodeExited;
            inGame.OnRunFinished -= HandleRunFinished;
            inGame.OnRunAbandoned -= HandleRunAbandoned;
            inGame.OnBattleResult -= HandleBattleResult;
            inGame.OnStageCleared -= HandleStageCleared;
            inGame.OnRewardOffered -= HandleRewardOffered;
            inGame.OnRewardPicked -= HandleRewardPicked;
            inGame.OnRewardGoldClaimed -= HandleRewardGoldClaimed;
        }

        if (BattleController.HasInstance)
        {
            BattleController battle = BattleController.Instance;
            battle.OnInfiniteLoopDetected -= HandleInfiniteLoop;
            battle.OnPlayerDamageTaken -= HandlePlayerDamageTaken;
        }

        if (BattleManager.HasInstance)
        {
            BattleManager battle = BattleManager.Instance;
            battle.OnCardPlaced -= HandleCardPlaced;
            battle.OnCardRecalled -= HandleCardRecalled;
            battle.OnPlayerTurnConfirmed -= HandleTurnConfirmed;
        }

        if (GridManager.HasInstance)
            GridManager.Instance.OnCardRemovedAt -= HandleCardRemovedAt;

        if (ShopController.HasInstance)
        {
            ShopController shop = ShopController.Instance;
            shop.OnInventoryBuilt -= HandleShopInventoryBuilt;
            shop.OnCardPurchased -= HandleShopPurchase;
            shop.OnCardRemoved -= HandleShopRemoval;
        }

        if (RestController.HasInstance)
            RestController.Instance.OnRestChoiceMade -= HandleRestChoice;

        if (ReinforceController.HasInstance)
            ReinforceController.Instance.OnCardReinforced -= HandleCardReinforced;

        _subscribed = false;
    }

    // ─────────────────────────────────────────────
    // 런 수명
    // ─────────────────────────────────────────────

    private void HandleRunStarted()
    {
        if (!InGameController.HasInstance) return;

        InGameController inGame = InGameController.Instance;
        _run.Begin(inGame.CurrentRunId, inGame.CurrentSeed, Time.realtimeSinceStartup);
        _stage.Clear();
        _currentEnemyId = null;

        GameLog.RunStart(
            inGame.CurrentRunId,
            inGame.CurrentSeed,
            inGame.SelectedPackIds,
            inGame.CurrentDifficulty);

        // 첫 스테이지 진입 (GA Progression Start).
        GameLog.StageStart(inGame.CurrentStageNumber, inGame.CurrentDifficulty);

        if (_verboseLog)
            GameLogger.Log(
                ELogCategory.Analytics,
                $"[AnalyticsBridge] 런 시작 difficulty={RunDifficultyUtility.ToLogValue(inGame.CurrentDifficulty)} " +
                $"seed={inGame.CurrentSeed}");
    }

    private void HandleRunResumed()
    {
        if (!InGameController.HasInstance) return;

        InGameController inGame = InGameController.Instance;
        _run.Begin(inGame.CurrentRunId, inGame.CurrentSeed, Time.realtimeSinceStartup);
        _stage.Clear();
        _currentEnemyId = null;

        RunContext run = inGame.CurrentRun;
        int floor = run != null ? run.CurrentFloor : 0;
        GameLog.RunResume(inGame.CurrentStageNumber, floor, inGame.CurrentDifficulty);

        if (_verboseLog)
            GameLogger.Log(
                ELogCategory.Analytics,
                $"[AnalyticsBridge] 저장 런 이어하기 " +
                $"difficulty={RunDifficultyUtility.ToLogValue(inGame.CurrentDifficulty)} seed={inGame.CurrentSeed}");
    }

    private void HandleStageCleared(int clearedStageIndex)
    {
        if (!InGameController.HasInstance) return;

        RunContext run = InGameController.Instance.CurrentRun;
        int reachedFloor = run != null ? run.CurrentFloor : 0;

        // clearedStageIndex는 0-based → 표시용 1-based로 올린다.
        GameLog.StageComplete(
            clearedStageIndex + 1,
            reachedFloor,
            InGameController.Instance.CurrentDifficulty);

        // 다음 스테이지 진입 통지 (마지막 스테이지였다면 런 종료가 뒤따르므로 무해하다).
        GameLog.StageStart(
            InGameController.Instance.CurrentStageNumber,
            InGameController.Instance.CurrentDifficulty);
    }

    private void HandleRunFinished(bool victory, int reachedFloor)
        => FlushRunEnd(victory ? ERunEndReason.Clear : ERunEndReason.Defeat, reachedFloor, isDeath: !victory);

    private void HandleBattleResult(bool victory)
    {
        int turns = InGameController.HasInstance
            ? InGameController.Instance.LastCompletedBattleTurnCount
            : 0;
        GameLog.BattleResult(_node.NodeType, _currentEnemyId, victory, turns);
    }

    /// <summary>
    /// 유저가 진행 중인 런을 버렸다. FinishRun이 안 불리는 경로라 여기서 run_end를 마무리하지 않으면
    /// 그 런의 스킬·데미지 통계가 통째로 유실된다.
    /// </summary>
    private void HandleRunAbandoned()
    {
        if (!InGameController.HasInstance) return;

        RunContext run = InGameController.Instance.CurrentRun;
        int reachedFloor = run != null ? run.CurrentFloor : 0;

        FlushRunEnd(
            ERunEndReason.Abandon,
            reachedFloor,
            isDeath: false);
    }

    /// <summary>런 종료 공통 처리. 사망 상세는 패배일 때만 채운다.</summary>
    private void FlushRunEnd(ERunEndReason reason, int reachedFloor, bool isDeath)
    {
        if (!InGameController.HasInstance || string.IsNullOrEmpty(_run.RunId)) return;

        InGameController inGame = InGameController.Instance;
        RunContext run = inGame.CurrentRun;

        string deathEnemyId = null;
        string deathIntent = null;
        string deathNodeJson = null;

        if (isDeath)
        {
            deathEnemyId = _currentEnemyId;
            deathIntent = BattleController.HasInstance
                ? BattleController.Instance.CurrentEnemyIntent
                : string.Empty;
            deathNodeJson = BuildDeathNodeJson();

            GameLog.Death(
                inGame.CurrentStageNumber,
                reachedFloor,
                _lastNodeType,
                _currentEnemyId,
                inGame.CurrentDifficulty);
        }

        // 마지막 스테이지의 노드를 먼저 내보낸다. run_end 뒤로 미루면 통째로 유실된다.
        FlushStageNodes();

        // 카드별 런당 사용 횟수를 GA로 flush (_run.Clear() 전에 해야 한다).
        GameLog.FlushSkillUse(_run);
        bool includeActiveRunSeconds = run == null || !run.Statistics.WasRestored;
        GameLog.RunStatistics(
            inGame.CurrentRunId,
            inGame.LastRunStatistics,
            includeActiveRunSeconds,
            inGame.CurrentDifficulty);

        GameLog.RunEnd(
            _run,
            reason,
            Time.realtimeSinceStartup,
            reachedFloor,
            inGame.CurrentStageNumber,
            run != null ? run.DeckCardIds : null,
            deathEnemyId,
            deathIntent,
            deathNodeJson,
            inGame.CurrentDifficulty);

        // 두 계층(RunStatistics ↔ RunAnalyticsBuffer)이 같은 원시 이벤트를 각자 세는데,
        // 값이 어긋나면 구독 누락/중복이다. DEV 빌드에서만 검사하고 데이터 전송은 건드리지 않는다.
        VerifyStatisticsConsistency();

        _run.Clear();
        _node.Clear();
        _stage.Clear();

        if (_verboseLog)
            GameLogger.Log(
                ELogCategory.Analytics,
                $"[AnalyticsBridge] 런 종료 difficulty={RunDifficultyUtility.ToLogValue(inGame.CurrentDifficulty)} " +
                $"reason={reason} floor={reachedFloor}");
    }

    /// <summary>사망 노드의 최소 식별 정보. UGS run_end.death_node_json. 스냅샷에서 읽는다.</summary>
    private string BuildDeathNodeJson()
        => $"{{\"node_id\":{_lastNodeId},\"node_type\":\"{AnalyticsKeys.Ga.NodeType(_lastNodeType)}\",\"floor\":{_lastFloor},\"stage\":{_lastStage}}}";

    // ─────────────────────────────────────────────
    // 통계 드리프트 검증 (DEV 전용)
    // ─────────────────────────────────────────────
    //
    // [설계 배경] 결과 화면·GA run_stat 은 RunContext.Statistics(저장/복원되는 "전체 런" 누적)에서,
    // UGS run_end 는 RunAnalyticsBuffer("이번 세션" 누적)에서 나온다. 둘은 소비처·수명이 달라
    // 의도적으로 분리돼 있다(이 둘을 억지로 단일화하면 이어하기 런의 run_end 의미가 바뀌어
    // 기존 UGS 페이로드가 회귀한다). 대신 같은 원시 이벤트를 각자 세는 스칼라가 어긋나지 않는지를
    // 여기서 감시한다 — 통합이 아니라 "드리프트를 시끄럽게" 만드는 안전장치다.

    /// <summary>
    /// 두 통계 계층의 겹치는 스칼라가 일치하는지 DEV 빌드에서 검사한다.
    /// 이어하기 런은 두 계층의 스코프가 달라(전체 런 vs 세션) 비교 대상에서 제외한다.
    /// 어떤 이벤트도 전송하지 않으며, 릴리스 빌드에서는 호출 자체가 컴파일 제거된다.
    /// </summary>
    [System.Diagnostics.Conditional("UNITY_EDITOR")]
    [System.Diagnostics.Conditional("DEVELOPMENT_BUILD")]
    private void VerifyStatisticsConsistency()
    {
        if (!InGameController.HasInstance) return;
        // 런 도중 동의 변경으로 세션 버퍼가 의도적으로 폐기된 경우 비교 자체가 무의미하다.
        if (string.IsNullOrEmpty(_run.RunId)) return;

        InGameController inGame = InGameController.Instance;
        RunContext runContext = inGame.CurrentRun;
        RunStatisticsSnapshot stats = inGame.LastRunStatistics;
        if (runContext == null || stats == null) return;

        // 이어하기 런: RunStatistics 는 복원분까지 누적하고 세션 버퍼는 이번 세션만 담는다 — 비교 무의미.
        if (runContext.Statistics.WasRestored) return;

        int bufferSkillUse = 0;
        foreach (int used in _run.SkillUse.Values) bufferSkillUse += used;

        WarnIfStatDrift("infinite_loop", stats.InfiniteLoopCount, _run.InfiniteLoopCount);
        WarnIfStatDrift("card_placement", stats.CardPlacementCount, bufferSkillUse);
        WarnIfStatDrift("damage_taken", stats.TotalDamageTaken, _run.TotalDamageTaken);
    }

    private static void WarnIfStatDrift(string metric, int runStatistics, int sessionBuffer)
    {
        if (runStatistics == sessionBuffer) return;

        GameLogger.LogWarning(ELogCategory.Analytics,
            $"[AnalyticsBridge] 통계 드리프트 — {metric}: RunStatistics={runStatistics} vs UGS버퍼={sessionBuffer}. " +
            "같은 원시 이벤트를 세는 두 계층 값이 다릅니다(이어하기 아닌 런). 구독 누락/중복을 점검하세요.");
    }

    // ─────────────────────────────────────────────
    // 노드 수명
    // ─────────────────────────────────────────────

    private void HandleNodeEntered(MapNode node)
    {
        if (node == null || !InGameController.HasInstance) return;

        InGameController inGame = InGameController.Instance;
        _node.Begin(node.NodeType, node.Id, node.Depth, inGame.CurrentStageNumber, Time.realtimeSinceStartup);

        _currentEnemyId = node.EnemyId;
        _node.SetEnemyId(node.EnemyId);

        if (_verboseLog)
            GameLogger.Log(ELogCategory.Analytics, $"[AnalyticsBridge] 노드 진입 {node.NodeType} id={node.Id}");
    }

    private void HandleNodeExited()
    {
        if (!_node.IsActive) return;

        // Clear 전에 메타를 복사한다 (런 종료 경로에서 사망 노드 정보로 쓰인다).
        _lastNodeType = _node.NodeType;
        _lastNodeId = _node.NodeId;
        _lastFloor = _node.Floor;
        _lastStage = _node.Stage;

        float now = Time.realtimeSinceStartup;

        // GA: 노드 타입별 방문 수·평균 체류 시간 (대시보드 집계용).
        GameLog.NodeVisit(_node.NodeType, _node.ElapsedSeconds(now));

        // UGS: 스테이지 버퍼에 쌓는다. 스테이지가 바뀌면 이전 스테이지를 먼저 내보낸다.
        // (OnStageCleared 는 보스 노드 종료보다 먼저 오므로 그 시점에 flush 하면 보스가 누락된다.)
        NodeSummary summary = _node.BuildSummary(now);
        if (!_stage.TryAdd(_node.Stage, summary))
        {
            FlushStageNodes();
            _stage.TryAdd(_node.Stage, summary);
        }

        _node.Clear();

        if (_verboseLog)
            GameLogger.Log(ELogCategory.Analytics, $"[AnalyticsBridge] 노드 종료 - 스테이지 버퍼 {_stage.Count}개");
    }

    /// <summary>쌓인 스테이지 노드를 UGS 이벤트 1개로 내보낸다. 비어 있으면 무동작.</summary>
    private void FlushStageNodes()
    {
        if (_stage.IsEmpty) return;

        GameLog.StageNodes(
            _stage,
            _run.RunId,
            InGameController.HasInstance
                ? InGameController.Instance.CurrentDifficulty
                : ERunDifficulty.Normal);

        if (_verboseLog)
            GameLogger.Log(ELogCategory.Analytics, $"[AnalyticsBridge] stage_nodes flush — stage={_stage.Stage}, {_stage.Count}노드");

        _stage.Clear();
    }

    // ─────────────────────────────────────────────
    // 전투
    // ─────────────────────────────────────────────

    private void HandleCardPlaced(Card card, Vector2Int position)
    {
        if (card == null) return;

        _node.RecordBoardAction(EBoardAction.Place, card.CardId, position.x, position.y);

        // 사용 횟수는 런 버퍼에만 누적한다. GA 전송은 런 종료 시 카드별 1건으로 묶는다
        // (배치마다 쏘면 런당 수백 건이 나가고, 런당 평균도 얻지 못한다).
        _run.AddSkillUse(card.CardId);
    }

    /// <summary>
    /// 그리드에서 카드가 사라짐. 이 시점에는 소멸인지 회수인지 알 수 없으므로 일단 Remove 로 적는다.
    /// 회수라면 같은 프레임에 HandleCardRecalled 가 뒤따라와 Retrieve 로 고쳐 쓴다.
    /// </summary>
    private void HandleCardRemovedAt(Card card, Vector2Int position)
    {
        if (card == null) return;

        _node.RecordBoardAction(EBoardAction.Remove, card.CardId, position.x, position.y);
    }

    private void HandleCardRecalled(Card card, Vector2Int position)
    {
        if (card == null) return;

        // 직전 Remove 를 Retrieve 로 바로잡는다. 재분류에 실패하면(순서가 어긋난 경우) 새로 적는다.
        bool fixedUp = _node.TryReclassifyLastAction(
            EBoardAction.Remove, EBoardAction.Retrieve, card.CardId, position.x, position.y);

        if (!fixedUp)
            _node.RecordBoardAction(EBoardAction.Retrieve, card.CardId, position.x, position.y);
    }

    private void HandleTurnConfirmed() => _node.CommitTurn();

    private void HandlePlayerDamageTaken(int hpDamage)
    {
        if (hpDamage <= 0 || string.IsNullOrEmpty(_currentEnemyId)) return;

        _run.AddDamageTaken(_currentEnemyId, hpDamage);
        GameLog.DamageTaken(_currentEnemyId, hpDamage);
    }

    private void HandleInfiniteLoop(Card card, Vector2Int position)
    {
        if (card == null) return;

        bool isFirst = _run.AddInfiniteLoop();

        string direction = card.Arrow != null ? card.Arrow.Current.ToString() : ECardDirection.None.ToString();
        _node.AddLoopCard(card.CardId, position.x, position.y, direction);

        int stage = InGameController.HasInstance ? InGameController.Instance.CurrentStageNumber : 0;
        GameLog.InfiniteLoop(isFirst, stage, _node.Floor);
    }

    // ─────────────────────────────────────────────
    // 보상 / 상점 / 휴식
    // ─────────────────────────────────────────────

    private void HandleRewardOffered(System.Collections.Generic.IReadOnlyList<string> offered)
        => _node.SetRewardOffered(offered);

    private void HandleRewardPicked(string cardId)
    {
        _node.SetRewardPicked(cardId);
        GameLog.RewardPick(cardId);
    }

    private void HandleRewardGoldClaimed(int gold) => _node.SetRewardGold(gold);

    private void HandleShopInventoryBuilt(System.Collections.Generic.IReadOnlyList<string> offered)
        => _node.SetShopOffered(offered);

    private void HandleShopPurchase(string cardId, int price)
    {
        _node.AddShopBought(cardId, price);
        GameLog.ShopBuy(cardId, price);
    }

    private void HandleShopRemoval(string cardId, int cost)
    {
        _node.AddShopRemoved(cardId, cost);
        GameLog.CardRemove(cardId, cost);
    }

    private void HandleRestChoice(bool isUpgrade)
    {
        _node.SetRestChoice(isUpgrade);
        GameLog.RestChoice(isUpgrade);
    }

    private void HandleCardReinforced(string cardId, ECardDirection oldDirection, ECardDirection addedDirection)
        => _node.SetRestUpgrade(cardId, oldDirection.ToString(), addedDirection.ToString());
}
