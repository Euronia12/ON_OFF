// =================================================================
// [스크립트 목적]  애널리틱스 이벤트명·파라미터명 상수 + GA design 경로 빌더 (매직 스트링 제거)
// [주요 변수]      - Ga     : GameAnalytics(계층 A) 경로 빌더 + Resource 상수
//                  - Ugs    : UGS(계층 B) 이벤트명 + 파라미터명 상수
// [의존 관계]      - 없음 (순수 상수/헬퍼)
// [비고]           GA Design 이벤트 제약 (GAValidator 실측):
//                   - 콜론 최대 5파트, 파트당 1~64자
//                   - 허용 문자: [A-Za-z0-9 \-_.()!?]  → 한글 불가
//                  Sanitize()가 위반 문자를 '_'로 치환하고 64자로 자른다.
//                  Cards.csv의 cardId는 ASCII(Void_Predation 등)라 정상 통과하지만,
//                  데이터가 바뀌어도 이벤트가 조용히 버려지지 않도록 방어한다.
// =================================================================
using System.Collections.Generic;
using System.Text;

/// <summary>애널리틱스 키 중앙 관리. 이벤트 문자열은 반드시 이 클래스를 통해서만 생성한다.</summary>
public static class AnalyticsKeys
{
    /// <summary>GA design 이벤트 파트 1개의 최대 길이 (GAValidator 기준).</summary>
    private const int MAX_PART_LENGTH = 64;

    /// <summary>sanitize 후 빈 문자열이 될 때 대체할 값.</summary>
    private const string UNKNOWN = "unknown";

    // 경로 조립용 재사용 버퍼. 애널리틱스 호출은 단일 스레드·저빈도라 공유 안전.
    private static readonly StringBuilder Builder = new(96);

    // ─────────────────────────────────────────────
    // 계층 A — GameAnalytics
    // ─────────────────────────────────────────────

    /// <summary>GameAnalytics(KPI/퍼널) 키. Design 이벤트는 저카디널리티 카운트/집계 전용.</summary>
    public static class Ga
    {
        // Resource 이벤트 상수.
        // [중요] currency·itemType은 GA 설정 에셋(Resource Currencies / Item Types)에
        // 사전 등록되어 있어야 한다. 미등록 시 GAValidator가 이벤트를 버린다.
        public const string CURRENCY_GOLD = "gold";
        public const string ITEM_TYPE_SHOP_BUY = "shop_buy";
        public const string ITEM_TYPE_CARD_REMOVE = "card_remove";

        // 고정 design 이벤트.
        public const string INFINITE_LOOP_TRIGGER = "infinite_loop:trigger";
        public const string REST_NODE_REST = "rest_node:rest";
        public const string REST_NODE_UPGRADE = "rest_node:upgrade";

        /// <summary>Progression 이벤트의 progression01. 시드 독립적인 유일한 축이라 스테이지만 쓴다.</summary>
        public static string Stage(int stageNumber)
            => Join("stage_", stageNumber.ToString());

        /// <summary>사망 상세. value에는 도달 층을 실어 보낸다.</summary>
        public static string Death(int stageNumber, ENodeType nodeType, string enemyId)
            => Join("death:stage_", stageNumber.ToString(), ":", NodeType(nodeType), ":", Sanitize(enemyId));

        /// <summary>적별 피격. value에는 데미지를 실어 보낸다 → GA가 합/평균 자동 집계.</summary>
        public static string DamageTaken(string enemyId)
            => Join("damage_taken:", Sanitize(enemyId));

        /// <summary>휴식 노드에서 회복/강화 중 무엇을 골랐는가.</summary>
        public static string RestNode(bool isUpgrade)
            => isUpgrade ? REST_NODE_UPGRADE : REST_NODE_REST;

        public static string CardRemove(string cardId)
            => Join("card_remove:", Sanitize(cardId));

        /// <summary>보상 노드에서 실제로 선택된 카드만 기록한다(제시 목록은 UGS로).</summary>
        public static string RewardPick(string cardId)
            => Join("reward_pick:", Sanitize(cardId));

        public static string RunStartPack(string packId, ERunDifficulty difficulty)
            => Join("run_start:", Difficulty(difficulty), ":pack:", Sanitize(packId));

        /// <summary>진행 중 앱 종료. 런 결과가 아니라 재개 가능한 일시중단 위치다.</summary>
        public static string RunSuspend(int stageNumber, int floor, ERunDifficulty difficulty)
            => Join("run_suspend:", Difficulty(difficulty), ":stage_", stageNumber.ToString(), ":floor_", floor.ToString());

        /// <summary>저장 런 이어하기 위치. 신규 런 시작과 분리해 중복 집계를 막는다.</summary>
        public static string RunResume(int stageNumber, int floor, ERunDifficulty difficulty)
            => Join("run_resume:", Difficulty(difficulty), ":stage_", stageNumber.ToString(), ":floor_", floor.ToString());

        /// <summary>런 내 첫 무한루프 발동 위치. 이후 발동은 INFINITE_LOOP_TRIGGER 카운트로만.</summary>
        public static string InfiniteLoopFirst(int stageNumber, int floor)
            => Join("infinite_loop:first:stage_", stageNumber.ToString(), "_floor_", floor.ToString());

        public static string SkillUse(string skillId)
            => Join("skill_use:", Sanitize(skillId));

        /// <summary>
        /// 노드 방문. value=체류 시간(초) → GA가 타입별 방문 수와 평균 체류 시간을 자동 집계한다.
        /// UGS에서 node_type/floor/duration_s 가 JSON 안으로 접히면서 잃은 대시보드 집계를 여기서 메운다.
        /// </summary>
        public static string NodeVisit(ENodeType nodeType)
            => Join("node_visit:", NodeType(nodeType));

        public static string ShopBuy(string cardId)
            => Join("shop_buy:", Sanitize(cardId));

        public static string RunResult(ERunEndReason result, ERunDifficulty difficulty)
            => Join("run_result:", Difficulty(difficulty), ":", Result(result));

        public static string RunStatistic(ERunEndReason result, string metric, ERunDifficulty difficulty)
            => Join("run_stat:", Difficulty(difficulty), ":", Result(result), ":", Sanitize(metric));

        public static string RunTopCard(ERunEndReason result, string cardId, ERunDifficulty difficulty)
            => Join("run_stat:", Difficulty(difficulty), ":", Result(result), ":top_card:", Sanitize(cardId));

        public static string Difficulty(ERunDifficulty difficulty)
            => RunDifficultyUtility.ToLogValue(difficulty);

        public static string BattleResult(ENodeType nodeType, string enemyId, bool victory)
            => Join(
                "battle_result:",
                BattleType(nodeType),
                ":",
                Sanitize(enemyId),
                ":",
                victory ? "win" : "defeat");

        private static string BattleType(ENodeType nodeType)
        {
            switch (nodeType)
            {
                case ENodeType.Elite: return "elite";
                case ENodeType.Boss: return "boss";
                default: return "normal";
            }
        }

        public static string Result(ERunEndReason result)
        {
            switch (result)
            {
                case ERunEndReason.Clear: return "clear";
                case ERunEndReason.Defeat: return "defeat";
                default: return "abandon";
            }
        }

        /// <summary>ENodeType → design 이벤트 파트 문자열 (소문자 ASCII).</summary>
        public static string NodeType(ENodeType nodeType)
        {
            switch (nodeType)
            {
                case ENodeType.Battle: return "battle";
                case ENodeType.Elite: return "elite";
                case ENodeType.Boss: return "boss";
                case ENodeType.Event: return "event";
                case ENodeType.Shop: return "shop";
                case ENodeType.Rest: return "rest";
                case ENodeType.Treasure: return "treasure";
                case ENodeType.Test: return "test";
                default: return UNKNOWN;
            }
        }
    }

    // ─────────────────────────────────────────────
    // 계층 B — UGS
    // ─────────────────────────────────────────────

    /// <summary>
    /// UGS(리치 데이터) 이벤트명·파라미터명.
    /// [중요] 여기 있는 이름·타입은 UGS 대시보드 Event Manager에 사전 선언되어야 한다.
    /// 미선언 이벤트는 에러 없이 조용히 버려진다.
    /// </summary>
    public static class Ugs
    {
        // 이벤트명 (런당 run_start 1 + stage_nodes 3 + run_end 1 = 5개)
        public const string EVENT_RUN_START = "run_start";
        public const string EVENT_STAGE_NODES = "stage_nodes";
        public const string EVENT_RUN_END = "run_end";

        // 공통 파라미터
        public const string P_RUN_ID = "run_id";
        public const string P_DIFFICULTY = "difficulty";

        // run_start
        public const string P_SEED = "seed";
        public const string P_PACK_IDS = "pack_ids";

        // stage_nodes
        public const string P_STAGE = "stage";
        public const string P_NODE_COUNT = "node_count";
        public const string P_NODES_JSON = "nodes_json";

        // run_end
        public const string P_REASON = "reason";
        public const string P_PLAY_SECONDS = "play_seconds";
        public const string P_REACHED_FLOOR = "reached_floor";
        public const string P_REACHED_STAGE = "reached_stage";
        public const string P_DECK_JSON = "deck_json";
        public const string P_DAMAGE_MAP_JSON = "damage_map_json";
        public const string P_SKILL_USE_JSON = "skill_use_json";
        public const string P_INFINITE_LOOP_COUNT = "infinite_loop_count";
        public const string P_DEATH_ENEMY_ID = "death_enemy_id";
        public const string P_DEATH_INTENT = "death_intent";
        public const string P_DEATH_NODE_JSON = "death_node_json";

        /// <summary>ERunEndReason → run_end.reason 문자열.</summary>
        public static string Reason(ERunEndReason reason)
        {
            switch (reason)
            {
                case ERunEndReason.Defeat: return "defeat";
                case ERunEndReason.Clear: return "clear";
                case ERunEndReason.Abandon: return "abandon";
                default: return UNKNOWN;
            }
        }

        /// <summary>EBoardAction → board_turns JSON의 "k" 값.</summary>
        public static string BoardAction(EBoardAction action)
        {
            switch (action)
            {
                case EBoardAction.Place: return "place";
                case EBoardAction.Retrieve: return "retrieve";
                case EBoardAction.Remove: return "remove";
                default: return UNKNOWN;
            }
        }
    }

    // ─────────────────────────────────────────────
    // 내부 헬퍼
    // ─────────────────────────────────────────────

    /// <summary>
    /// GA 이벤트 파트로 안전한 문자열로 변환.
    /// 허용 문자([A-Za-z0-9 \-_.()!?]) 외는 '_'로 치환하고 64자로 자른다.
    /// 콜론(:)은 파트 구분자이므로 반드시 치환된다.
    ///
    /// [경고] 치환이 일어나면 GA 대시보드에서 카드 식별이 불가능해진다.
    /// "화염구_Left" → "____Left" 처럼 한글이 전부 '_'가 되어 다른 카드와 구분되지 않는다.
    /// ID는 반드시 ASCII로 정의해야 한다. 위반 시 개발 빌드에서 경고를 남긴다.
    /// </summary>
    private static string Sanitize(string raw)
    {
        if (string.IsNullOrEmpty(raw)) return UNKNOWN;

        int length = raw.Length < MAX_PART_LENGTH ? raw.Length : MAX_PART_LENGTH;
        bool needsCopy = raw.Length > MAX_PART_LENGTH;

        // 대부분의 cardId/enemyId는 이미 안전하다. 위반 문자가 없으면 원본을 그대로 반환해 할당을 피한다.
        if (!needsCopy)
        {
            bool clean = true;
            for (int i = 0; i < length; i++)
            {
                if (!IsAllowed(raw[i])) { clean = false; break; }
            }
            if (clean) return raw;
        }

        Builder.Clear();
        for (int i = 0; i < length; i++)
        {
            char c = raw[i];
            Builder.Append(IsAllowed(c) ? c : '_');
        }
        string sanitized = Builder.ToString();

        WarnIfMangled(raw, sanitized);
        return sanitized;
    }

    /// <summary>
    /// ID가 GA 규격을 위반해 치환된 경우 경고. 같은 ID는 한 번만 알린다(로그 폭주 방지).
    /// 이 경고가 뜨면 해당 ID를 ASCII(영문·숫자·언더바)로 바꿔야 한다.
    /// </summary>
    [System.Diagnostics.Conditional("UNITY_EDITOR")]
    [System.Diagnostics.Conditional("DEVELOPMENT_BUILD")]
    private static void WarnIfMangled(string raw, string sanitized)
    {
        if (!WarnedIds.Add(raw)) return;

        GameLogger.LogWarning(ELogCategory.Analytics,
            $"[AnalyticsKeys] GA 규격 위반 ID — \"{raw}\" → \"{sanitized}\". " +
            "GA는 ASCII([A-Za-z0-9 -_.()!?])만 허용합니다. 대시보드에서 이 카드를 식별할 수 없습니다. " +
            "ID를 영문으로 변경하세요.");
    }

    // 이미 경고한 ID (중복 경고 방지). 개발 빌드 전용이라 증가해도 무해하다.
    private static readonly HashSet<string> WarnedIds = new();

    /// <summary>GAValidator의 허용 문자 집합 ^[A-Za-z0-9\s\-_\.\(\)\!\?]$ 과 동일.</summary>
    private static bool IsAllowed(char c)
    {
        if (c >= 'A' && c <= 'Z') return true;
        if (c >= 'a' && c <= 'z') return true;
        if (c >= '0' && c <= '9') return true;

        switch (c)
        {
            case ' ':
            case '-':
            case '_':
            case '.':
            case '(':
            case ')':
            case '!':
            case '?':
                return true;
            default:
                return false;
        }
    }

    /// <summary>문자열 조각 결합. string.Concat 대비 중간 배열 할당을 피한다.</summary>
    private static string Join(string a, string b)
    {
        Builder.Clear();
        Builder.Append(a).Append(b);
        return Builder.ToString();
    }

    private static string Join(string a, string b, string c, string d)
    {
        Builder.Clear();
        Builder.Append(a).Append(b).Append(c).Append(d);
        return Builder.ToString();
    }

    private static string Join(string a, string b, string c, string d, string e, string f)
    {
        Builder.Clear();
        Builder.Append(a).Append(b).Append(c).Append(d).Append(e).Append(f);
        return Builder.ToString();
    }
}
