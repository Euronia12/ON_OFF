// =================================================================
// [스크립트 목적]  애널리틱스 계층에서만 쓰는 열거형 모음
// [주요 변수]      - EProgressionStatus : GA Progression 상태 (SDK 열거형과 1:1 대응)
//                  - ERunEndReason      : 런 종료 사유 (UGS run_end.reason)
//                  - EBoardAction       : 보드 조작 종류 (UGS board_turns 압축 표기)
// [의존 관계]      - 없음 (순수 열거형). GaAnalyticsProvider가 GAProgressionStatus로 변환
// [비고]           SDK 열거형(GAProgressionStatus)을 게임플레이 코드에 노출하지 않기 위한
//                  경계 타입이다. GameLog 사용자는 이 열거형만 안다.
// =================================================================

/// <summary>GA Progression 이벤트 상태. GameAnalyticsSDK.GAProgressionStatus와 1:1 대응.</summary>
public enum EProgressionStatus
{
    /// <summary>스테이지 진입.</summary>
    Start = 1,

    /// <summary>스테이지 클리어(보스 격파).</summary>
    Complete = 2,

    /// <summary>스테이지 내 사망.</summary>
    Fail = 3,
}

/// <summary>런이 끝난 사유. UGS run_end.reason 파라미터로 전송(소문자 문자열).</summary>
public enum ERunEndReason
{
    /// <summary>사망으로 종료.</summary>
    Defeat = 0,

    /// <summary>최종 스테이지까지 클리어.</summary>
    Clear = 1,

    /// <summary>타이틀 복귀 등 유저가 런을 버림.</summary>
    Abandon = 2,
}

/// <summary>
/// 전투 보드 조작 종류. UGS board_turns JSON에 짧은 문자열로 접혀 들어간다.
/// 빈 셀은 저장하지 않고, 실제 발생한 조작만 순서대로 기록한다.
///
/// [회수와 소멸 구분]
/// 회수(RecallCard)도 내부에서 GridManager.RemoveCard 를 거치므로,
/// OnCardRemovedAt 만 보면 회수가 소멸로 잘못 기록된다.
/// AnalyticsBridge 는 일단 Remove 로 적은 뒤, 같은 프레임에 뒤따르는
/// BattleManager.OnCardRecalled 를 보고 Retrieve 로 재분류한다.
/// </summary>
public enum EBoardAction
{
    /// <summary>손패 → 보드 배치.</summary>
    Place = 0,

    /// <summary>보드 → 손패 회수(RecallCard).</summary>
    Retrieve = 1,

    /// <summary>보드에서 소멸 (소멸 효과, 턴 종료 임시카드 정리 등). 손패로 돌아오지 않는다.</summary>
    Remove = 2,
}
