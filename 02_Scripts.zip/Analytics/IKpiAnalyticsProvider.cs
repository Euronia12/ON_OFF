// =================================================================
// [스크립트 목적]  KPI/퍼널 전용 분석 제공자 계약 (계층 A). GameAnalytics를 이 인터페이스로 래핑
// [주요 변수]      없음 (인터페이스)
// [의존 관계]      - AnalyticsManager가 _kpiProviders로 보관
//                  - EProgressionStatus (AnalyticsEnums)
// [비고]           기존 IAnalyticsProvider(dict 기반)와 별도로 존재하는 이유:
//                  GA의 Design / Progression / Resource는 파라미터 모양이 서로 다른
//                  3개의 독립 API다. dict 하나로 뭉개면 Provider 쪽에서 키를 다시 파싱해야 하고
//                  타입 안전성이 사라진다. 좁은 인터페이스를 하나 더 두는 편이 정직하다.
//
//                  구현체는 전송 실패를 스스로 삼켜야 한다(예외를 밖으로 던지지 않는다).
//                  분석 실패가 게임 진행을 막아서는 안 된다.
// =================================================================

/// <summary>KPI/퍼널 제공자 계약. 저카디널리티 카운트·집계 전용(계층 A).</summary>
public interface IKpiAnalyticsProvider
{
    void Initialize();

    /// <summary>
    /// Design 이벤트. eventPath는 AnalyticsKeys.Ga의 빌더로만 생성한다.
    /// value는 GA가 합/평균/분포를 자동 집계한다(데미지, 도달 층 등).
    /// </summary>
    void DesignEvent(string eventPath, float value);

    /// <summary>Design 이벤트 (value 없는 순수 카운트).</summary>
    void DesignEvent(string eventPath);

    /// <summary>
    /// Progression 이벤트. stage는 시드 독립적인 유일한 축이라 1세그먼트만 쓴다.
    /// score에는 도달 층을 넣는다 → 카디널리티를 늘리지 않고 진행 깊이를 보존한다.
    /// </summary>
    void ProgressionEvent(EProgressionStatus status, string stage, int score);

    /// <summary>
    /// 재화 소비(Sink). currency·itemType은 GA 설정 에셋에 사전 등록되어 있어야 한다.
    /// amount는 0보다 커야 하며, 아니면 GA가 이벤트를 버린다.
    /// </summary>
    void ResourceSink(string currency, float amount, string itemType, string itemId);

    /// <summary>운영 오류 이벤트. 분석 실패는 반드시 호출부로 전파하지 않는다.</summary>
    void ErrorEvent(string message);
}
