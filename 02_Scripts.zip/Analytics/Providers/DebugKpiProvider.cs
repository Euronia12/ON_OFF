// =================================================================
// [스크립트 목적]  GA(계층 A) 호출을 콘솔에 그대로 출력하는 개발용 제공자
// [주요 변수]      없음 (상태 없음)
// [의존 관계]      - IKpiAnalyticsProvider, GameLogger
// [비고]           존재 이유:
//                  GameAnalytics SDK는 에디터에서 이벤트를 전송하지 않는다.
//                  GetPlatformIndex()가 Application.platform(WindowsEditor)을
//                  설정의 Platforms 목록(WindowsPlayer)에서 못 찾아 -1을 반환하고,
//                  키를 래퍼에 넘기지 않은 채 경고만 남긴다.
//                  → 에디터에서는 GA 대시보드로 검증이 불가능하다.
//
//                  기존 DebugAnalyticsProvider는 dict 기반 IAnalyticsProvider라
//                  UGS 계열 이벤트만 찍고 GA Design/Progression/Resource는 지나가지 않는다.
//                  이 제공자가 그 공백을 메운다. 빌드에서는 등록되지 않는다.
// =================================================================

/// <summary>GA로 나갈 KPI 이벤트를 콘솔에 출력. 에디터 검증 전용(전송하지 않음).</summary>
public sealed class DebugKpiProvider : IKpiAnalyticsProvider
{
    public void Initialize()
        => GameLogger.Log(ELogCategory.Analytics, "DebugKpiProvider 초기화 (GA 호출을 콘솔로만 출력)");

    public void DesignEvent(string eventPath, float value)
        => GameLogger.Log(ELogCategory.Analytics, $"[GA] Design  {eventPath}  value={value}");

    public void DesignEvent(string eventPath)
        => GameLogger.Log(ELogCategory.Analytics, $"[GA] Design  {eventPath}");

    public void ProgressionEvent(EProgressionStatus status, string stage, int score)
        => GameLogger.Log(ELogCategory.Analytics, $"[GA] Progression  {status}  {stage}  score={score}");

    public void ResourceSink(string currency, float amount, string itemType, string itemId)
        => GameLogger.Log(ELogCategory.Analytics, $"[GA] Sink  {currency} -{amount}  {itemType}/{itemId}");

    public void ErrorEvent(string message)
        => GameLogger.LogError(ELogCategory.Analytics, $"[GA] Error  {message}");
}
