// =================================================================
// [스크립트 목적]  Unity Gaming Services Analytics 래퍼 (계층 B — 리치 데이터)
// [주요 변수]      - _isReady     : UnityServices 초기화 + 데이터 수집 시작 완료 여부
//                  - _pending     : 초기화 완료 전에 들어온 이벤트 대기열 (상한 있음)
//                  - MAX_PENDING  : 대기열 상한. 오프라인 장기 플레이 시 무한 증식 방지
// [의존 관계]      - Unity.Services.Core, Unity.Services.Analytics
//                  - IAnalyticsProvider (AnalyticsManager)
// [비고]           UnityServices.InitializeAsync()는 비동기인데 IAnalyticsProvider.Initialize()는
//                  동기다. 그래서 초기화를 Forget()으로 띄우고, 그 사이 들어온 이벤트는
//                  큐에 담았다가 준비되면 한 번에 흘려보낸다.
//
//                  [계약 — 중요] AnalyticsManager는 파라미터 Dictionary를 재사용한다.
//                  따라서 LogEvent 안에서 즉시 CustomEvent로 복사해야 한다. 참조를 보관하면
//                  다음 호출 때 내용이 덮어써진다.
//
//                  UGS는 대시보드에 사전 선언되지 않은 이벤트/파라미터를 조용히 버린다.
//                  전송이 안 될 때 가장 먼저 의심할 지점이다.
// =================================================================
using System;
using System.Collections.Generic;
using Cysharp.Threading.Tasks;
using Unity.Services.Analytics;
using Unity.Services.Core;
#if ENABLE_UNITY_CONSENT
using UnityEngine.UnityConsent;
#endif

/// <summary>UGS Analytics 래퍼. 노드/런 단위 리치 이벤트 전송 담당.</summary>
public sealed class UgsAnalyticsProvider : IAnalyticsProvider
{
    /// <summary>초기화 지연 중 쌓아 둘 수 있는 최대 이벤트 수. 넘으면 가장 오래된 것부터 버린다.</summary>
    private const int MAX_PENDING = 32;

    private bool _isReady;
    private bool _isInitializing;

    // 동의 미획득·철회로 차단된 상태.
    // 초기화는 비동기라 "대기 중에 철회"가 실제로 발생한다 — 그 경우 수집을 시작해서는 안 된다.
    private bool _isDisabled;

    // 초기화 전 유입 이벤트 대기열. CustomEvent는 이미 값이 복사된 상태라 보관해도 안전하다.
    private readonly Queue<CustomEvent> _pending = new(MAX_PENDING);

    public void Initialize()
    {
        if (_isDisabled || _isReady || _isInitializing) return;

        _isInitializing = true;
        InitializeAsync().Forget();
    }

    /// <summary>
    /// UGS 초기화 → 데이터 수집 시작 → 대기열 배출.
    /// 실패해도 예외를 밖으로 내지 않는다. 이후 전송은 조용히 무시된다.
    ///
    /// 동의를 껐다 켠 경우 이 인스턴스는 새로 만들어지고 UnityServices는 이미 초기화된 상태다.
    /// InitializeAsync는 그 경우 완료된 Task를 즉시 돌려주고, StartCollection이 수집을 재개한다
    /// (SDK의 Activate는 이미 활성이면 무동작이라 껐다 켜기를 반복해도 안전하다).
    /// </summary>
    private async UniTaskVoid InitializeAsync()
    {
        try
        {
            await UnityServices.InitializeAsync();

            // 대기 중에 동의가 철회됐다면 수집을 시작하지 않는다.
            if (_isDisabled)
            {
                _pending.Clear();
                return;
            }

            StartCollection();

            _isReady = true;
            GameLogger.Log(ELogCategory.Analytics, "UgsAnalyticsProvider 초기화 완료");

            FlushPending();
        }
        catch (Exception e)
        {
            // 프로젝트 미링크 / 네트워크 차단 / 동의 미획득 등.
            GameLogger.LogError(ELogCategory.Analytics, $"UGS Analytics 초기화 실패: {e.Message}");
            _pending.Clear();
        }
        finally
        {
            _isInitializing = false;
        }
    }

    public void LogEvent(string eventName, IReadOnlyDictionary<string, object> parameters)
    {
        if (_isDisabled || string.IsNullOrEmpty(eventName)) return;

        // 재사용 버퍼 계약 준수: 여기서 즉시 값을 복사해 CustomEvent로 옮긴다.
        CustomEvent customEvent = BuildEvent(eventName, parameters);
        if (customEvent == null) return;

        if (!_isReady)
        {
            Enqueue(customEvent);
            return;
        }

        Record(customEvent);
    }

    /// <summary>
    /// UGS는 사용자 속성(User Property) 개념을 커스텀 파라미터로 대체한다.
    /// 별도 API가 없으므로 무동작. GA/로컬 로그 쪽에서 처리한다.
    /// </summary>
    public void SetUserProperty(string key, string value) { }

    /// <summary>
    /// 버퍼에 쌓인 이벤트를 즉시 업로드한다.
    ///
    /// UGS는 기본 60초 주기로만 이벤트를 묶어 올린다. 그래서 런 종료 직후나
    /// 플레이 모드 종료·앱 종료 시점에 버퍼에 남은 이벤트(run_end 등)가 통째로 유실된다.
    /// 중요한 시점에는 반드시 이 메서드를 불러야 한다.
    /// </summary>
    public void Flush()
    {
        if (!_isReady) return;

        try
        {
            AnalyticsService.Instance.Flush();
        }
        catch (Exception e)
        {
            GameLogger.LogWarning(ELogCategory.Analytics, $"UGS Flush 실패: {e.Message}");
        }
    }

    /// <summary>
    /// 개인정보 수집 비동의·철회 시 호출. 대기열을 버리고 UGS 수집을 중단한다.
    /// 초기화 전·초기화 도중에 불려도 안전하다 — 미초기화 상태에서는 SDK를 호출하지 않는다
    /// (초기화 전 AnalyticsService.Instance 접근은 예외를 던진다).
    /// </summary>
    public void Disable()
    {
        _isDisabled = true;
        _pending.Clear();

        if (!_isReady)
            return;

        _isReady = false;

        // Flush 실패가 수집 중단을 막으면 안 되므로 두 호출을 각각 보호한다.
        // (한 try로 묶으면 Flush 예외 때 중단이 통째로 건너뛰어져 수집이 계속된다)
        try
        {
            // 중단 전에 이미 쌓인 이벤트를 먼저 올린다.
            // 그냥 멈추면 그 이벤트들이 디스크 버퍼에 남았다가 다음에 수집을 재개하는 순간
            // "꺼둔 뒤에 올라가는" 모양이 된다. 동의가 살아 있는 지금 비워 두는 편이 깨끗하다.
            AnalyticsService.Instance.Flush();
        }
        catch (Exception e)
        {
            GameLogger.LogWarning(ELogCategory.Analytics, $"UGS 중단 전 Flush 실패: {e.Message}");
        }

        try
        {
            StopCollection();
        }
        catch (Exception e)
        {
            GameLogger.LogWarning(ELogCategory.Analytics, $"UGS 수집 중단 실패: {e.Message}");
        }
    }

    // ─────────────────────────────────────────────
    // 수집 시작 / 중단 (패키지 구성별 경로 분기)
    // ─────────────────────────────────────────────
    //
    // [중요] UGS Analytics 6.x는 수집 제어 경로가 둘이고 서로 섞어 쓸 수 없다.
    //
    //   ENABLE_UNITY_CONSENT 정의 → Developer Data framework (EndUserConsent). 최신 권장 경로
    //   미정의                     → Start/StopDataCollection. 이 프로젝트의 현재 경로
    //
    // 이 define은 별도 consent 패키지가 있어야 켜진다. 현재 프로젝트에는 설치돼 있지 않으므로
    // UnityEngine.UnityConsent 네임스페이스 자체가 존재하지 않는다(무조건 참조하면 컴파일 에러).
    // SDK는 먼저 사용된 쪽으로 흐름을 고정(LockInOriginalFlow)하고, 이후 반대편 API를 부르면
    // InvalidOperationException을 던진다. 그래서 한 경로만 타도록 컴파일 단계에서 갈라 둔다.

    /// <summary>수집 시작. 재개(껐다 켬)로 다시 불려도 SDK가 중복 활성화를 스스로 막는다.</summary>
    private static void StartCollection()
    {
#if ENABLE_UNITY_CONSENT
        ConsentState consentState = EndUserConsent.GetConsentState();
        consentState.AnalyticsIntent = ConsentStatus.Granted;
        EndUserConsent.SetConsentState(consentState);
#else
        // Obsolete 경고 억제 — consent 패키지가 없는 환경에서는 이쪽이 유일한 정식 경로다.
#pragma warning disable CS0618
        AnalyticsService.Instance.StartDataCollection();
#pragma warning restore CS0618
#endif
    }

    /// <summary>수집 중단. 동의 철회 시 호출한다.</summary>
    private static void StopCollection()
    {
#if ENABLE_UNITY_CONSENT
        ConsentState consentState = EndUserConsent.GetConsentState();
        consentState.AnalyticsIntent = ConsentStatus.Denied;
        EndUserConsent.SetConsentState(consentState);
#else
#pragma warning disable CS0618
        AnalyticsService.Instance.StopDataCollection();
#pragma warning restore CS0618
#endif
    }

    // ─────────────────────────────────────────────
    // 내부
    // ─────────────────────────────────────────────

    /// <summary>
    /// dict → CustomEvent 복사. UGS가 받는 값은 string/int/long/float/double/bool 뿐이라
    /// 그 외 타입은 ToString()으로 낮춰 보낸다(전송 실패보다 문자열이 낫다).
    /// </summary>
    private CustomEvent BuildEvent(string eventName, IReadOnlyDictionary<string, object> parameters)
    {
        try
        {
            var customEvent = new CustomEvent(eventName);
            if (parameters == null) return customEvent;

            foreach (KeyValuePair<string, object> pair in parameters)
            {
                if (string.IsNullOrEmpty(pair.Key) || pair.Value == null) continue;
                customEvent[pair.Key] = Normalize(pair.Value);
            }

            return customEvent;
        }
        catch (Exception e)
        {
            GameLogger.LogWarning(ELogCategory.Analytics, $"UGS 이벤트 조립 실패 [{eventName}]: {e.Message}");
            return null;
        }
    }

    /// <summary>UGS가 허용하는 원시 타입으로 강등한다.</summary>
    private static object Normalize(object value)
    {
        switch (value)
        {
            case string _:
            case int _:
            case long _:
            case float _:
            case double _:
            case bool _:
                return value;
            default:
                return value.ToString();
        }
    }

    private void Record(CustomEvent customEvent)
    {
        if (!_isReady || _isDisabled || customEvent == null) return;

        try
        {
            AnalyticsService.Instance.RecordEvent(customEvent);
        }
        catch (Exception e)
        {
            // 전송 실패는 삼킨다. 다음 이벤트는 정상적으로 시도된다.
            GameLogger.LogWarning(ELogCategory.Analytics, $"UGS RecordEvent 실패: {e.Message}");
        }
    }

    /// <summary>초기화 완료 전 유입 이벤트를 보관. 상한 초과 시 가장 오래된 것을 버린다.</summary>
    private void Enqueue(CustomEvent customEvent)
    {
        if (_pending.Count >= MAX_PENDING)
        {
            _pending.Dequeue();
            GameLogger.LogWarning(ELogCategory.Analytics, "UGS 대기열 초과 - 가장 오래된 이벤트 폐기");
        }

        _pending.Enqueue(customEvent);
    }

    private void FlushPending()
    {
        while (_pending.Count > 0)
            Record(_pending.Dequeue());
    }
}
