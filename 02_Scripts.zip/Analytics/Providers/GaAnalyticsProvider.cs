// =================================================================
// [스크립트 목적]  GameAnalytics SDK 래퍼 (계층 A — KPI/퍼널)
// [주요 변수]      - _isReady : GameAnalytics.Initialize() 완료 여부
// [의존 관계]      - GameAnalyticsSDK (Assets/GameAnalytics)
//                  - IKpiAnalyticsProvider, EProgressionStatus
// [비고]           GA Design 이벤트 제약 (GAValidator 실측):
//                   - 콜론 최대 5파트, 파트당 1~64자, 허용문자 [A-Za-z0-9 \-_.()!?]
//                  Resource 이벤트 제약:
//                   - currency / itemType이 GA 설정 에셋에 사전 등록되어 있어야 한다
//                   - amount > 0 이어야 한다 (0 이하면 SDK가 버린다)
//
//                  이벤트 문자열 조립은 전부 AnalyticsKeys.Ga가 담당한다.
//                  이 클래스는 "검증 + SDK 호출"만 하고 문자열을 만들지 않는다.
//
//                  모든 호출은 예외를 밖으로 던지지 않는다. 분석 실패가 게임을 멈추면 안 된다.
// =================================================================
using System;
using GameAnalyticsSDK;

/// <summary>GameAnalytics 래퍼. KPI/퍼널 이벤트 전송 담당.</summary>
public sealed class GaAnalyticsProvider : IKpiAnalyticsProvider
{
    private bool _isReady;

    // 동의 미획득·철회로 차단된 상태. 한 번 내려가면 이 인스턴스는 다시 켜지지 않는다
    // (재동의는 AnalyticsManager가 Provider를 새로 만들어 처리한다).
    private bool _isDisabled;

    public void Initialize()
    {
        if (_isDisabled || _isReady) return;

        try
        {
            // [중요] GameAnalytics.Initialize()에는 중복 호출 가드가 없다 —
            // 두 번 부르면 GA_Wrapper.Initialize(key, secret)가 그대로 재실행돼 세션이 중복 생성된다.
            // 동의를 껐다 켠 경우(옵션 토글)는 SDK가 이미 살아 있으므로 전송 스위치만 다시 올린다.
            // SetEnabledEventSubmission(false)로 내려간 상태는 재초기화로는 복구되지 않는다.
            if (GameAnalytics.Initialized)
            {
                GameAnalytics.SetEnabledEventSubmission(true);
                GameLogger.Log(ELogCategory.Analytics, "GaAnalyticsProvider 전송 재개 (SDK는 이미 초기화됨)");
            }
            else
            {
                GameAnalytics.Initialize();
                GameLogger.Log(ELogCategory.Analytics, "GaAnalyticsProvider 초기화 완료");
            }

            _isReady = true;
        }
        catch (Exception e)
        {
            // GA 설정(Game Key/Secret Key) 누락 등. 이후 모든 전송은 조용히 무시된다.
            _isReady = false;
            GameLogger.LogError(ELogCategory.Analytics, $"GameAnalytics 초기화 실패: {e.Message}");
        }
    }

    public void DesignEvent(string eventPath, float value)
    {
        if (!_isReady || string.IsNullOrEmpty(eventPath)) return;

        try
        {
            GameAnalytics.NewDesignEvent(eventPath, value);
        }
        catch (Exception e)
        {
            GameLogger.LogWarning(ELogCategory.Analytics, $"GA DesignEvent 실패 [{eventPath}]: {e.Message}");
        }
    }

    public void DesignEvent(string eventPath)
    {
        if (!_isReady || string.IsNullOrEmpty(eventPath)) return;

        try
        {
            GameAnalytics.NewDesignEvent(eventPath);
        }
        catch (Exception e)
        {
            GameLogger.LogWarning(ELogCategory.Analytics, $"GA DesignEvent 실패 [{eventPath}]: {e.Message}");
        }
    }

    public void ProgressionEvent(EProgressionStatus status, string stage, int score)
    {
        if (!_isReady || string.IsNullOrEmpty(stage)) return;

        try
        {
            GameAnalytics.NewProgressionEvent(ToGaStatus(status), stage, score);
        }
        catch (Exception e)
        {
            GameLogger.LogWarning(ELogCategory.Analytics, $"GA ProgressionEvent 실패 [{stage}]: {e.Message}");
        }
    }

    public void ResourceSink(string currency, float amount, string itemType, string itemId)
    {
        if (!_isReady) return;

        // GA는 amount <= 0 인 Resource 이벤트를 버린다. 여기서 미리 걸러 로그 노이즈를 줄인다.
        if (amount <= 0f) return;

        try
        {
            GameAnalytics.NewResourceEvent(GAResourceFlowType.Sink, currency, amount, itemType, itemId);
        }
        catch (Exception e)
        {
            GameLogger.LogWarning(ELogCategory.Analytics, $"GA ResourceSink 실패 [{itemType}/{itemId}]: {e.Message}");
        }
    }

    public void ErrorEvent(string message)
    {
        if (!_isReady || string.IsNullOrWhiteSpace(message)) return;

        try
        {
            GameAnalytics.NewErrorEvent(GAErrorSeverity.Error, message);
        }
        catch (Exception e)
        {
            GameLogger.LogWarning(ELogCategory.Analytics, $"GA ErrorEvent 실패: {e.Message}");
        }
    }

    /// <summary>
    /// 개인정보 수집 비동의·철회 시 호출. 이후 모든 전송이 차단된다.
    /// 초기화 전에 불려도 안전하다 — SDK를 건드리지 않고 플래그만 내린다.
    /// </summary>
    public void Disable()
    {
        _isDisabled = true;

        if (!_isReady)
            return;

        _isReady = false;

        try
        {
            // doCache:false — 오프라인 캐시(로컬 DB)에도 쌓지 않는다.
            GameAnalytics.SetEnabledEventSubmission(false, false);
        }
        catch (Exception e)
        {
            GameLogger.LogWarning(ELogCategory.Analytics, $"GA 전송 비활성화 실패: {e.Message}");
        }
    }

    /// <summary>
    /// 경계 변환. 숫자값이 같더라도 명시적으로 매핑한다 —
    /// SDK 열거형이 바뀌어도 컴파일 타임에 잡히도록.
    /// </summary>
    private static GAProgressionStatus ToGaStatus(EProgressionStatus status)
    {
        switch (status)
        {
            case EProgressionStatus.Start: return GAProgressionStatus.Start;
            case EProgressionStatus.Complete: return GAProgressionStatus.Complete;
            case EProgressionStatus.Fail: return GAProgressionStatus.Fail;
            default: return GAProgressionStatus.Undefined;
        }
    }
}
