// =================================================================
// [스크립트 목적]  스테이지 1개 분량의 노드 요약을 모아 UGS 이벤트 1개로 묶는 버퍼
// [주요 변수]      - _nodes : 이 스테이지에서 지나온 노드 요약 목록
//                  - Stage  : 현재 모으는 중인 스테이지 번호 (1-based)
// [의존 관계]      - NodeSummary, Newtonsoft.Json. MonoBehaviour 아님
// [비고]           존재 이유:
//                  노드마다 UGS 이벤트를 보내면 완주 1회에 32개가 나간다
//                  (스테이지 깊이 8+10+12 = 30노드 + run_start + run_end).
//                  UGS Fair Usage 권장치가 MAU당 월 500 커스텀 이벤트라 유저당 월 15완주가
//                  상한이 된다. 스테이지 단위로 묶으면 런당 5개로 줄어든다.
//
//                  [flush 시점 주의]
//                  OnStageCleared 는 보스 노드의 OnNodeExited 보다 먼저 발행된다.
//                  그래서 "스테이지 클리어 시 flush"로 잡으면 보스 노드가 누락된다.
//                  대신 다른 스테이지의 노드가 들어오는 순간 이전 스테이지를 flush 한다(lazy).
//                  마지막 스테이지는 런 종료 시 flush 된다.
// =================================================================
using System.Collections.Generic;
using Newtonsoft.Json;

/// <summary>스테이지 1개 분량의 노드 요약 누적기. UGS stage_nodes 이벤트 1개로 flush된다.</summary>
public sealed class StageAnalyticsBuffer
{
    private readonly List<NodeSummary> _nodes = new(16);

    /// <summary>현재 모으는 중인 스테이지 번호 (1-based). 비어 있으면 0.</summary>
    public int Stage { get; private set; }

    /// <summary>쌓인 노드 수.</summary>
    public int Count => _nodes.Count;

    public bool IsEmpty => _nodes.Count == 0;

    /// <summary>
    /// 노드 요약을 추가한다. 스테이지가 바뀌면 false를 반환하므로,
    /// 호출부가 먼저 flush 한 뒤 다시 호출해야 한다.
    /// </summary>
    /// <returns>같은 스테이지라 바로 담았으면 true. 스테이지가 달라 담지 못했으면 false.</returns>
    public bool TryAdd(int stage, NodeSummary summary)
    {
        if (summary == null) return true;

        if (IsEmpty)
        {
            Stage = stage;
        }
        else if (Stage != stage)
        {
            return false;
        }

        _nodes.Add(summary);
        return true;
    }

    /// <summary>쌓인 노드 요약을 JSON 배열로 직렬화. 직렬화는 스테이지당 정확히 1회.</summary>
    public string BuildNodesJson() => JsonConvert.SerializeObject(_nodes);

    public void Clear()
    {
        _nodes.Clear();
        Stage = 0;
    }
}
