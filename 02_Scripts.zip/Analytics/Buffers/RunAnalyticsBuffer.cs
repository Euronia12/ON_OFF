// =================================================================
// [스크립트 목적]  런 1개 분량의 누적 통계를 담는 런타임 버퍼 (순수 POCO)
// [주요 변수]      - _damageMap        : enemyId → 그 적에게 받은 누적 데미지
//                  - _skillUse         : skillId → 사용 횟수
//                  - InfiniteLoopCount : 런 내 무한루프 발동 총 횟수
// [의존 관계]      - Newtonsoft.Json. MonoBehaviour 아님. AnalyticsBridge가 소유
// [비고]           run_end 이벤트 1개로 flush된다. Dictionary 순회는 flush 시점에만 일어나므로
//                  전투 중 GC에 영향이 없다.
//
//                  RunId/Seed는 InGameController가 이미 만들어 둔 값을 복사해 온다.
//                  이 버퍼는 게임 상태를 만들지 않고 관찰만 한다.
// =================================================================
using System.Collections.Generic;
using Newtonsoft.Json;

/// <summary>런 1개 분량의 애널리틱스 누적기. run_end 시 JSON으로 flush된다.</summary>
public sealed class RunAnalyticsBuffer
{
    /// <summary>InGameController.CurrentRunId 복사본.</summary>
    public string RunId { get; private set; }

    public int Seed { get; private set; }

    /// <summary>런 내 무한루프 발동 총 횟수.</summary>
    public int InfiniteLoopCount { get; private set; }

    /// <summary>이번 런에서 무한루프가 이미 한 번이라도 발동했는가 (GA 첫 발동 이벤트용).</summary>
    public bool HasLoggedFirstInfiniteLoop { get; private set; }

    /// <summary>Begin() 이후 흐른 실시간 초.</summary>
    public float PlaySeconds(float realtimeNow) => realtimeNow - _startedAtRealtime;

    private float _startedAtRealtime;

    // enemyId → 누적 피격 데미지
    private readonly Dictionary<string, int> _damageMap = new(8);

    // skillId → 사용 횟수
    private readonly Dictionary<string, int> _skillUse = new(16);

    /// <summary>
    /// skillId → 이번 런의 사용 횟수. 런 종료 시 GA로 카드별 1건씩 flush하는 데 쓴다.
    /// 순회는 run_end 시점에만 일어나므로 전투 중 GC에 영향이 없다.
    /// </summary>
    public IReadOnlyDictionary<string, int> SkillUse => _skillUse;

    /// <summary>
    /// 이번 세션 런에서 적에게 받은 총 피해(=_damageMap 합). 드리프트 검증(DEV) 전용.
    /// 순회는 run_end 시점에만 일어나므로 전투 중 비용이 없다.
    /// </summary>
    public int TotalDamageTaken
    {
        get
        {
            int sum = 0;
            foreach (int value in _damageMap.Values) sum += value;
            return sum;
        }
    }

    // ─────────────────────────────────────────────
    // 수명
    // ─────────────────────────────────────────────

    /// <summary>런 시작. 이전 런의 잔여 데이터를 전부 버린다.</summary>
    public void Begin(string runId, int seed, float realtimeNow)
    {
        Clear();

        RunId = runId;
        Seed = seed;
        _startedAtRealtime = realtimeNow;
    }

    public void Clear()
    {
        RunId = null;
        Seed = 0;
        InfiniteLoopCount = 0;
        HasLoggedFirstInfiniteLoop = false;
        _startedAtRealtime = 0f;

        _damageMap.Clear();
        _skillUse.Clear();
    }

    // ─────────────────────────────────────────────
    // 축적
    // ─────────────────────────────────────────────

    /// <summary>적에게 받은 데미지 누적. enemyId가 비면 무시한다.</summary>
    public void AddDamageTaken(string enemyId, int damage)
    {
        if (string.IsNullOrEmpty(enemyId) || damage <= 0) return;

        _damageMap.TryGetValue(enemyId, out int current);
        _damageMap[enemyId] = current + damage;
    }

    /// <summary>스킬(카드) 사용 횟수 누적.</summary>
    public void AddSkillUse(string skillId)
    {
        if (string.IsNullOrEmpty(skillId)) return;

        _skillUse.TryGetValue(skillId, out int current);
        _skillUse[skillId] = current + 1;
    }

    /// <summary>
    /// 무한루프 발동 1회 기록.
    /// 반환값이 true면 이번이 런 내 첫 발동이다 (GA first 이벤트를 쏠지 판단하는 데 쓴다).
    /// </summary>
    public bool AddInfiniteLoop()
    {
        InfiniteLoopCount++;

        if (HasLoggedFirstInfiniteLoop)
            return false;

        HasLoggedFirstInfiniteLoop = true;
        return true;
    }

    // ─────────────────────────────────────────────
    // Flush
    // ─────────────────────────────────────────────

    /// <summary>enemyId → 누적 데미지 JSON. run_end.damage_map_json.</summary>
    public string BuildDamageMapJson() => JsonConvert.SerializeObject(_damageMap);

    /// <summary>skillId → 사용 횟수 JSON. run_end.skill_use_json.</summary>
    public string BuildSkillUseJson() => JsonConvert.SerializeObject(_skillUse);

    /// <summary>런 종료 시점의 덱 구성 JSON. run_end.deck_json.</summary>
    public static string BuildDeckJson(IReadOnlyList<string> deckCardIds)
        => JsonConvert.SerializeObject(deckCardIds ?? System.Array.Empty<string>());
}
