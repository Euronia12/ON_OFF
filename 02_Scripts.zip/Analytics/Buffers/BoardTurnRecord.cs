// =================================================================
// [스크립트 목적]  UGS payload_json에 접혀 들어가는 직렬화 레코드 정의 (순수 POCO)
// [주요 변수]      - BoardActionRecord : 보드 조작 1건 (종류/카드/좌표)
//                  - BoardTurnRecord   : 턴 1개 = 조작 순서열
//                  - *Payload          : 노드 타입별 payload_json 루트
// [의존 관계]      - Newtonsoft.Json (com.unity.nuget.newtonsoft-json)
//                  - EBoardAction, AnalyticsKeys
// [비고]           JsonUtility 대신 Newtonsoft를 쓴다. JsonUtility는 최상위 배열을 다루지 못해
//                  래퍼 클래스를 겹겹이 만들어야 하고, Dictionary 직렬화도 불가능하다.
//
//                  JSON 키를 1~2글자로 줄인 이유: UGS 이벤트는 5MB 제한이 있고
//                  board_turns는 전투당 수십~수백 건까지 늘어난다. 키 길이가 곧 용량이다.
//                  빈 셀은 저장하지 않고 실제 발생한 조작만 순서대로 담는다.
// =================================================================
using System.Collections.Generic;
using Newtonsoft.Json;

/// <summary>보드 조작 1건. place / retrieve / remove 중 하나.</summary>
public readonly struct BoardActionRecord
{
    /// <summary>조작 종류 ("place" / "retrieve" / "remove").</summary>
    [JsonProperty("k")] public string Kind { get; }

    /// <summary>대상 카드 ID.</summary>
    [JsonProperty("c")] public string CardId { get; }

    [JsonProperty("x")] public int X { get; }

    [JsonProperty("y")] public int Y { get; }

    public BoardActionRecord(EBoardAction action, string cardId, int x, int y)
    {
        Kind = AnalyticsKeys.Ugs.BoardAction(action);
        CardId = cardId;
        X = x;
        Y = y;
    }
}

/// <summary>턴 1개. 그 턴에 일어난 조작을 순서대로 담는다(턴당 1행 압축).</summary>
public sealed class BoardTurnRecord
{
    /// <summary>0-based 턴 인덱스.</summary>
    [JsonProperty("t")] public int Turn { get; }

    /// <summary>발생 순서대로의 조작 목록.</summary>
    [JsonProperty("a")] public List<BoardActionRecord> Actions { get; }

    public BoardTurnRecord(int turn)
    {
        Turn = turn;
        Actions = new List<BoardActionRecord>(8);
    }
}

/// <summary>무한루프를 유발한 카드의 위치·방향.</summary>
public readonly struct LoopCardRecord
{
    [JsonProperty("c")] public string CardId { get; }
    [JsonProperty("x")] public int X { get; }
    [JsonProperty("y")] public int Y { get; }

    /// <summary>화살표 방향. ECardDirection은 [Flags]라 "Left, Up" 형태가 될 수 있다.</summary>
    [JsonProperty("d")] public string Direction { get; }

    public LoopCardRecord(string cardId, int x, int y, string direction)
    {
        CardId = cardId;
        X = x;
        Y = y;
        Direction = direction;
    }
}

/// <summary>상점에서 사고/지운 카드 1건.</summary>
public readonly struct ShopTradeRecord
{
    [JsonProperty("c")] public string CardId { get; }

    /// <summary>지불한 골드.</summary>
    [JsonProperty("p")] public int Price { get; }

    public ShopTradeRecord(string cardId, int price)
    {
        CardId = cardId;
        Price = price;
    }
}

// ─────────────────────────────────────────────
// payload_json 루트 (노드 타입별)
// ─────────────────────────────────────────────

/// <summary>전투 노드 payload. 턴별 보드 조작 + 무한루프 카드.</summary>
public sealed class BattleNodePayload
{
    [JsonProperty("board_turns")] public List<BoardTurnRecord> BoardTurns { get; set; }

    /// <summary>무한루프가 없었으면 null (직렬화에서 제외).</summary>
    [JsonProperty("loop_cards", NullValueHandling = NullValueHandling.Ignore)]
    public List<LoopCardRecord> LoopCards { get; set; }

    [JsonProperty("enemy_id")] public string EnemyId { get; set; }

    /// <summary>전투에 걸린 총 턴 수.</summary>
    [JsonProperty("turns")] public int Turns { get; set; }

    /// <summary>
    /// 승리 보상. 보상은 전투 노드 수명 안에서 일어나므로 별도 노드가 아니라 여기 실린다.
    /// 패배해서 보상창이 뜨지 않았으면 null (직렬화에서 제외).
    /// </summary>
    [JsonProperty("reward", NullValueHandling = NullValueHandling.Ignore)]
    public RewardNodePayload Reward { get; set; }
}

/// <summary>상점 노드 payload. 제시된 목록 + 실제 구매/제거.</summary>
public sealed class ShopNodePayload
{
    [JsonProperty("offered")] public List<string> Offered { get; set; }
    [JsonProperty("bought")] public List<ShopTradeRecord> Bought { get; set; }
    [JsonProperty("removed")] public List<ShopTradeRecord> Removed { get; set; }
}

/// <summary>전투 승리 보상 payload. 제시 목록 + 선택 결과.</summary>
public sealed class RewardNodePayload
{
    [JsonProperty("offered")] public List<string> Offered { get; set; }

    /// <summary>선택하지 않고 넘겼으면 null.</summary>
    [JsonProperty("picked", NullValueHandling = NullValueHandling.Ignore)]
    public string Picked { get; set; }

    [JsonProperty("gold")] public int Gold { get; set; }
}

/// <summary>
/// 노드 1개 요약. stage_nodes 이벤트의 nodes_json 배열 원소.
///
/// node_type / floor / duration_s 는 예전에 UGS 최상위 파라미터였다가 여기로 접혔다.
/// 그 대신 대시보드 집계는 GA node_visit:{nodeType} 이 담당한다(계층 분리).
/// </summary>
public sealed class NodeSummary
{
    [JsonProperty("node_type")] public string NodeType { get; set; }
    [JsonProperty("node_id")] public int NodeId { get; set; }
    [JsonProperty("floor")] public int Floor { get; set; }
    [JsonProperty("duration_s")] public float DurationSeconds { get; set; }

    /// <summary>노드 타입별 상세. BattleNodePayload / ShopNodePayload / RestNodePayload 중 하나.</summary>
    [JsonProperty("data", NullValueHandling = NullValueHandling.Ignore)]
    public object Data { get; set; }
}

/// <summary>휴식 노드 payload. 회복이면 card_id 이하가 전부 null.</summary>
public sealed class RestNodePayload
{
    /// <summary>"rest" 또는 "upgrade".</summary>
    [JsonProperty("choice")] public string Choice { get; set; }

    [JsonProperty("card_id", NullValueHandling = NullValueHandling.Ignore)]
    public string CardId { get; set; }

    /// <summary>강화 전 화살표 방향.</summary>
    [JsonProperty("old_dirs", NullValueHandling = NullValueHandling.Ignore)]
    public string OldDirs { get; set; }

    /// <summary>이번에 추가된 화살표 방향.</summary>
    [JsonProperty("added_dirs", NullValueHandling = NullValueHandling.Ignore)]
    public string AddedDirs { get; set; }
}
