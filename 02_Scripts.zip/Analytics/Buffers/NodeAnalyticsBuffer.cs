// =================================================================
// [스크립트 목적]  노드 1개 분량의 UGS 리치 데이터를 축적하는 런타임 버퍼 (순수 POCO)
// [주요 변수]      - _boardTurns  : 전투 노드의 턴별 조작 순서열
//                  - _currentTurn : 현재 턴 레코드 (턴 확정 시 교체)
//                  - _offered/_bought/_removed : 상점·보상 노드용
// [의존 관계]      - BoardTurnRecord 계열 DTO, AnalyticsKeys, Newtonsoft.Json
//                  - MonoBehaviour 아님. AnalyticsBridge가 소유·수명 관리
// [비고]           노드 진입 시 Begin() → 진행 중 축적(SDK 호출 없음) → 종료 시
//                  BuildSummary() 1회 → Clear(). 실제 직렬화는 StageAnalyticsBuffer 가
//                  스테이지 단위로 flush 할 때 한 번만 일어난다.
//
//                  이 버퍼는 게임 상태를 소유하지 않는다. 전부 값 복사본이다.
//                  ScriptableObject를 절대 참조하지 않는다.
// =================================================================
using System.Collections.Generic;
using Newtonsoft.Json;

/// <summary>노드 1개 분량의 애널리틱스 데이터 축적기. 노드 종료 시 JSON 1개로 flush된다.</summary>
public sealed class NodeAnalyticsBuffer
{
    // 노드 메타
    private ENodeType _nodeType;
    private int _nodeId;
    private int _floor;
    private int _stage;
    private float _startedAtRealtime;

    /// <summary>Begin()과 End() 사이인가. 노드 밖에서 들어온 기록을 무시하는 데 쓴다.</summary>
    public bool IsActive { get; private set; }

    public ENodeType NodeType => _nodeType;
    public int NodeId => _nodeId;
    public int Floor => _floor;
    public int Stage => _stage;

    // ── 전투 노드 ──
    private readonly List<BoardTurnRecord> _boardTurns = new(16);
    private BoardTurnRecord _currentTurn;
    private List<LoopCardRecord> _loopCards;
    private string _enemyId;

    // ── 상점 노드 ──
    private List<string> _shopOffered;
    private readonly List<ShopTradeRecord> _shopBought = new(4);
    private readonly List<ShopTradeRecord> _shopRemoved = new(4);

    // ── 보상 노드 ──
    private List<string> _rewardOffered;
    private string _rewardPicked;
    private int _rewardGold;

    // ── 휴식 노드 ──
    private bool _restIsUpgrade;
    private string _restCardId;
    private string _restOldDirs;
    private string _restAddedDirs;

    // ─────────────────────────────────────────────
    // 수명
    // ─────────────────────────────────────────────

    /// <summary>노드 진입. 이전 내용을 전부 버리고 새 노드로 시작한다.</summary>
    public void Begin(ENodeType nodeType, int nodeId, int floor, int stage, float realtimeNow)
    {
        Clear();

        _nodeType = nodeType;
        _nodeId = nodeId;
        _floor = floor;
        _stage = stage;
        _startedAtRealtime = realtimeNow;
        IsActive = true;

        // 전투는 0턴부터 조작이 들어온다. 다른 노드 타입에선 쓰이지 않는다.
        _currentTurn = new BoardTurnRecord(0);
    }

    /// <summary>노드에 머문 시간(초).</summary>
    public float ElapsedSeconds(float realtimeNow)
        => realtimeNow - _startedAtRealtime;

    /// <summary>모든 축적 데이터를 비우고 비활성화한다.</summary>
    public void Clear()
    {
        IsActive = false;

        _boardTurns.Clear();
        _currentTurn = null;
        _loopCards = null;
        _enemyId = null;

        _shopOffered = null;
        _shopBought.Clear();
        _shopRemoved.Clear();

        _rewardOffered = null;
        _rewardPicked = null;
        _rewardGold = 0;

        _restIsUpgrade = false;
        _restCardId = null;
        _restOldDirs = null;
        _restAddedDirs = null;
    }

    // ─────────────────────────────────────────────
    // 전투 노드 축적
    // ─────────────────────────────────────────────

    public void SetEnemyId(string enemyId)
    {
        if (!IsActive) return;
        _enemyId = enemyId;
    }

    /// <summary>보드 조작 1건 기록. 현재 턴의 순서열 끝에 붙는다.</summary>
    public void RecordBoardAction(EBoardAction action, string cardId, int x, int y)
    {
        if (!IsActive || _currentTurn == null) return;
        _currentTurn.Actions.Add(new BoardActionRecord(action, cardId, x, y));
    }

    /// <summary>
    /// 직전에 기록한 조작을 다른 종류로 다시 분류한다. 같은 카드·같은 좌표일 때만 바꾼다.
    ///
    /// 회수(RecallCard)는 내부에서 GridManager.RemoveCard 를 거치므로 소멸로 먼저 잡힌다.
    /// 곧바로 뒤따르는 회수 통지를 받아 이 메서드로 바로잡는다.
    /// </summary>
    /// <returns>재분류에 성공하면 true.</returns>
    public bool TryReclassifyLastAction(EBoardAction from, EBoardAction to, string cardId, int x, int y)
    {
        if (!IsActive || _currentTurn == null) return false;

        int last = _currentTurn.Actions.Count - 1;
        if (last < 0) return false;

        BoardActionRecord record = _currentTurn.Actions[last];
        if (record.Kind != AnalyticsKeys.Ugs.BoardAction(from)) return false;
        if (record.CardId != cardId || record.X != x || record.Y != y) return false;

        _currentTurn.Actions[last] = new BoardActionRecord(to, cardId, x, y);
        return true;
    }

    /// <summary>
    /// 플레이어 턴 확정. 현재 턴을 확정 목록으로 넘기고 다음 턴 레코드를 연다.
    /// 조작이 하나도 없던 턴은 저장하지 않는다(빈 행 제거).
    /// </summary>
    public void CommitTurn()
    {
        if (!IsActive || _currentTurn == null) return;

        if (_currentTurn.Actions.Count > 0)
            _boardTurns.Add(_currentTurn);

        _currentTurn = new BoardTurnRecord(_currentTurn.Turn + 1);
    }

    /// <summary>무한루프를 유발한 카드 기록. 첫 기록 시에만 리스트를 만든다.</summary>
    public void AddLoopCard(string cardId, int x, int y, string direction)
    {
        if (!IsActive) return;

        _loopCards ??= new List<LoopCardRecord>(4);
        _loopCards.Add(new LoopCardRecord(cardId, x, y, direction));
    }

    // ─────────────────────────────────────────────
    // 상점 노드 축적
    // ─────────────────────────────────────────────

    public void SetShopOffered(IReadOnlyList<string> offered)
    {
        if (!IsActive || offered == null) return;

        _shopOffered = new List<string>(offered.Count);
        for (int i = 0; i < offered.Count; i++)
            _shopOffered.Add(offered[i]);
    }

    public void AddShopBought(string cardId, int price)
    {
        if (!IsActive) return;
        _shopBought.Add(new ShopTradeRecord(cardId, price));
    }

    public void AddShopRemoved(string cardId, int cost)
    {
        if (!IsActive) return;
        _shopRemoved.Add(new ShopTradeRecord(cardId, cost));
    }

    // ─────────────────────────────────────────────
    // 보상 노드 축적
    // ─────────────────────────────────────────────

    public void SetRewardOffered(IReadOnlyList<string> offered)
    {
        if (!IsActive || offered == null) return;

        _rewardOffered = new List<string>(offered.Count);
        for (int i = 0; i < offered.Count; i++)
            _rewardOffered.Add(offered[i]);
    }

    public void SetRewardPicked(string cardId)
    {
        if (!IsActive) return;
        _rewardPicked = cardId;
    }

    public void SetRewardGold(int gold)
    {
        if (!IsActive) return;
        _rewardGold = gold;
    }

    // ─────────────────────────────────────────────
    // 휴식 노드 축적
    // ─────────────────────────────────────────────

    public void SetRestChoice(bool isUpgrade)
    {
        if (!IsActive) return;
        _restIsUpgrade = isUpgrade;
    }

    /// <summary>강화 선택 시의 상세. oldDirs/addedDirs는 ECardDirection.ToString() 결과.</summary>
    public void SetRestUpgrade(string cardId, string oldDirs, string addedDirs)
    {
        if (!IsActive) return;

        _restIsUpgrade = true;
        _restCardId = cardId;
        _restOldDirs = oldDirs;
        _restAddedDirs = addedDirs;
    }

    // ─────────────────────────────────────────────
    // Flush
    // ─────────────────────────────────────────────

    /// <summary>
    /// 노드 1개 요약을 만든다. 노드 종료 시 정확히 1회 호출하고, StageAnalyticsBuffer에 쌓는다.
    /// 직렬화는 스테이지 단위 flush 때 한 번만 일어난다.
    /// </summary>
    public NodeSummary BuildSummary(float realtimeNow)
    {
        return new NodeSummary
        {
            NodeType = AnalyticsKeys.Ga.NodeType(_nodeType),
            NodeId = _nodeId,
            Floor = _floor,
            DurationSeconds = ElapsedSeconds(realtimeNow),
            Data = BuildPayload(),
        };
    }

    /// <summary>노드 타입별 상세 payload. 알 수 없는 타입은 null(직렬화에서 빠진다).</summary>
    private object BuildPayload()
    {
        switch (_nodeType)
        {
            case ENodeType.Battle:
            case ENodeType.Elite:
            case ENodeType.Boss:
            case ENodeType.Test:
                return BuildBattlePayload();

            case ENodeType.Shop:
                return new ShopNodePayload
                {
                    Offered = _shopOffered ?? new List<string>(0),
                    Bought = _shopBought,
                    Removed = _shopRemoved,
                };

            case ENodeType.Rest:
                return new RestNodePayload
                {
                    // GA 이벤트 경로("rest_node:upgrade")가 아니라 순수 선택값만 넣는다.
                    Choice = _restIsUpgrade ? "upgrade" : "rest",
                    CardId = _restCardId,
                    OldDirs = _restOldDirs,
                    AddedDirs = _restAddedDirs,
                };

            default:
                return null;
        }
    }

    /// <summary>
    /// 전투 노드는 보상 데이터도 함께 실린다(승리 보상은 전투 노드에 종속).
    /// 보상이 없었으면(패배) offered가 비어 있다.
    /// </summary>
    private BattleNodePayload BuildBattlePayload()
    {
        // 마지막 턴에 남은 조작이 있으면 흘리지 않고 담는다.
        if (_currentTurn != null && _currentTurn.Actions.Count > 0)
        {
            _boardTurns.Add(_currentTurn);
            _currentTurn = null;
        }

        return new BattleNodePayload
        {
            BoardTurns = _boardTurns,
            LoopCards = _loopCards,
            EnemyId = _enemyId,
            Turns = _boardTurns.Count,
            Reward = BuildRewardPayload(),
        };
    }

    /// <summary>승리 보상 payload. 보상창이 뜨지 않았으면(패배) null → 직렬화에서 빠진다.</summary>
    private RewardNodePayload BuildRewardPayload()
    {
        if (_rewardOffered == null && _rewardGold == 0)
            return null;

        return new RewardNodePayload
        {
            Offered = _rewardOffered ?? new List<string>(0),
            Picked = _rewardPicked,
            Gold = _rewardGold,
        };
    }
}
