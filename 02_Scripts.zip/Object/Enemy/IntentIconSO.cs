// =================================================================
// [스크립트 목적]  적 의도 타입별 아이콘 매핑 ScriptableObject.
//                 UIEnemyIntentView 가 의도 타입 → Sprite 조회에 사용.
// [주요 변수]      - _attack/_defend/_installBlankCards/_installOnDisturbanceBlocks
// [의존 관계]      - EEnemyIntentType (BattleEnums)
// [설계 노트]      - 아이콘이 흩어지지 않게 SO 한 곳에 모음. 의도 타입 추가 시 여기만 확장
//                  - Resolve(type) 로 조회. 미설정 타입은 null 반환 (호출부에서 숨김 처리)
// =================================================================

using UnityEngine;

/// <summary>
/// 적 의도 타입(EEnemyIntentType) → 표시 아이콘(Sprite) 매핑 데이터.
/// 의도 UI(UIEnemyIntentView)가 이 SO 로 아이콘을 조회한다.
/// </summary>
[CreateAssetMenu(fileName = "IntentIconSO", menuName = "Game/Intent Icon Set", order = 1)]
public sealed class IntentIconSO : ScriptableObject
{
    [Tooltip("공격 의도 아이콘")]
    [SerializeField] private Sprite _attack;

    [Tooltip("선형 그리드 공격 의도 아이콘")]
    [SerializeField] private Sprite _gridLineAttack;

    [Tooltip("방어 의도 아이콘")]
    [SerializeField] private Sprite _defend;

    [Tooltip("빈 카드 설치 의도 아이콘")]
    [SerializeField] private Sprite _installBlankCards;

    [Tooltip("ON 방해 블록 설치 의도 아이콘")]
    [SerializeField] private Sprite _installOnDisturbanceBlocks;

    [Tooltip("카드 정보 말소 의도 아이콘")]
    [SerializeField] private Sprite _eraseInfo;

    [Tooltip("마나 획득 반응 방어 버프 의도 아이콘")]
    [SerializeField] private Sprite _buffBlockOnPlayerManaGain;

    [Tooltip("드로우 반응 피해 버프 의도 아이콘")]
    [SerializeField] private Sprite _buffDamageOnPlayerDraw;

    [Tooltip("카드 ON 누적 방해물 설치 버프 의도 아이콘")]
    [SerializeField] private Sprite _buffInstallDisturbanceOnCardToggle;

    [Tooltip("카드 종류만 은폐(화살표 유지) 의도 아이콘")]
    [SerializeField] private Sprite _eraseCardKindOnly;

    [Tooltip("ON 상태 저주 블록 설치 의도 아이콘")]
    [SerializeField] private Sprite _installHandCurse;

    [Tooltip("세 가지 버프형 기믹이 적의 의도로 표시될 때 사용하는 공통 아이콘")]
    [SerializeField] private Sprite _beneficialEffectIntent;

    public Sprite ResolveForIntent(EEnemyIntentType type)
    {
        return EnemyIntentInfo.IsBeneficialBuffIntent(type)
            ? _beneficialEffectIntent
            : Resolve(type);
    }

    /// <summary>의도 타입에 해당하는 아이콘 반환. 미설정이면 null.</summary>
    public Sprite Resolve(EEnemyIntentType type)
    {
        return type switch
        {
            EEnemyIntentType.Attack => _attack,
            EEnemyIntentType.GridLineAttack => _gridLineAttack,
            EEnemyIntentType.Defend => _defend,
            EEnemyIntentType.InstallBlankCards => _installBlankCards,
            EEnemyIntentType.InstallOnDisturbanceBlocks => _installOnDisturbanceBlocks,
            EEnemyIntentType.EraseInfo => _eraseInfo,
            EEnemyIntentType.EraseCardKindOnly => _eraseCardKindOnly,
            EEnemyIntentType.InstallHandCurse => _installHandCurse,
            EEnemyIntentType.BuffBlockOnPlayerManaGain => _buffBlockOnPlayerManaGain,
            EEnemyIntentType.BuffDamageOnPlayerDraw => _buffDamageOnPlayerDraw,
            EEnemyIntentType.BuffInstallDisturbanceOnCardToggle => _buffInstallDisturbanceOnCardToggle,
            _ => null,
        };
    }
}
