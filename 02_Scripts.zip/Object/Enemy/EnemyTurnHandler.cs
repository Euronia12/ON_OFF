// =================================================================
// [스크립트 목적]  적 턴 행동 핸들러 (IEnemyTurnHandler). EnemyActor 의 의도대로 행동 수행.
//                 기존 SimpleEnemyHandler 개명 + 인터페이스 전체 멤버 구현.
// [주요 변수]      - _enemy        : 행동 주체 적 액터 (의도·방어막·HP 보유)
//                  - _attackDelay  : 행동 연출 대기(초)
//                  - _grid         : 적 패턴이 개입할 플레이어 그리드
// [의존 관계]      - IEnemyTurnHandler / EnemyActor / EnemyIntent / IBattleActor / IStageProvider
//                  - BattleManager 가 EnemyResolve 페이즈에서 호출
// [설계 노트]      - 의도 타입별 분기: Attack → target.TakeDamage / Defend → _enemy.GainBlock
//                  - IsEnemyAlive 는 EnemyActor HP 기반 (OnDied 와 일관)
//                  - 연출(투사체·피격)은 3단계 Presenter 담당. 여기선 수치+대기만
// =================================================================

using System;
using System.Collections.Generic;
using System.Threading;
using Cysharp.Threading.Tasks;
using UnityEngine;

/// <summary>
/// EnemyActor 의 현재 의도를 읽어 한 턴 행동을 수행하는 핸들러.
/// 공격 의도면 플레이어에게 피해, 방어 의도면 자신에게 방어막을 부여한다.
/// 적 생존 여부는 EnemyActor 의 HP 로 판정해 전투 종료 판정과 일관성을 유지한다.
/// </summary>
public sealed class EnemyTurnHandler : IEnemyTurnHandler
{
    private const string BlankCardId = "Mana_Disturbance";
    private const string DisturbanceBlockCardId = "ManaPollution_NAME";
    private const string HandCurseBlockCardId = "ManaPollutionEvolved_NAME";

    private readonly EnemyActor _enemy;
    private readonly float _attackDelay;
    private readonly GridManager _grid;
    private readonly Func<int> _getCurrentIntentOrder;
    private Func<CancellationToken, UniTask> _attackMotionAsync;
    private Func<CancellationToken, UniTask> _gridLineAttackAsync;
    private Func<CancellationToken, UniTask> _eraseInfoAsync;
    private EnemyEliteBuffController _eliteBuffController;

    // 의도 전진 정책 콜백 (Enemy 의 DecideNextIntent → SetIntent). 주입되면 이걸 우선 사용.
    private readonly System.Action _advanceIntent;

    /// <summary>현재 의도 묶음 (Intent UI 표시용 위임).</summary>
    public IReadOnlyList<EnemyIntent> CurrentIntents => _enemy != null
        ? _enemy.CurrentIntents
        : System.Array.Empty<EnemyIntent>();

    /// <summary>적 생존 여부 (전투 종료 판정용). EnemyActor HP 기반.</summary>
    public bool IsEnemyAlive => _enemy != null && _enemy.IsAlive;

    public int CurrentIntentOrder => _getCurrentIntentOrder != null ? Mathf.Max(0, _getCurrentIntentOrder.Invoke()) : 0;

    /// <param name="enemy">행동 주체 적 액터.</param>
    /// <param name="attackDelay">행동 연출 대기 시간(초).</param>
    /// <param name="advanceIntent">의도 전진 콜백 (Enemy.AdvanceIntent). null 이면 Actor 의 SO 순환 폴백.</param>
    /// <param name="grid">적 패턴이 개입할 플레이어 그리드.</param>
    public EnemyTurnHandler(
        EnemyActor enemy,
        float attackDelay = 0.3f,
        System.Action advanceIntent = null,
        GridManager grid = null,
        Func<int> getCurrentIntentOrder = null)
    {
        _enemy = enemy;
        _attackDelay = Mathf.Max(0f, attackDelay);
        _advanceIntent = advanceIntent;
        _grid = grid;
        _getCurrentIntentOrder = getCurrentIntentOrder;
    }

    /// <summary>전투 조립자가 실제 선형 그리드 공격 처리를 연결한다.</summary>
    public void SetGridLineAttackHandler(Func<CancellationToken, UniTask> handler)
    {
        _gridLineAttackAsync = handler;
    }

    /// <summary>전투 조립자가 일반 공격 모션 연출을 연결한다.</summary>
    public void SetAttackMotionHandler(Func<CancellationToken, UniTask> handler)
    {
        _attackMotionAsync = handler;
    }

    /// <summary>전투 조립자가 EraseInfo 독 투척 연출을 연결한다.</summary>
    public void SetEraseInfoHandler(Func<CancellationToken, UniTask> handler)
    {
        _eraseInfoAsync = handler;
    }

    public void SetEliteBuffController(EnemyEliteBuffController controller)
    {
        _eliteBuffController = controller;
    }

    // ── IEnemyTurnHandler ───────────────────────────────────

    /// <summary>현재 의도 묶음대로 행동 수행 (연출 텀 포함). 공+방 동시 등 여러 의도를 순서대로 실행.</summary>
    public async UniTask ExecuteTurnAsync(IBattleActor target, CancellationToken token)
    {
        if (_enemy == null || !_enemy.IsAlive) return;

        IReadOnlyList<EnemyIntent> intents = _enemy.CurrentIntents;
        if (intents == null || intents.Count == 0) return;

        // 연출 대기 (피격·투사체 자리 — 3단계 Presenter 가 채움).
        if (_attackDelay > 0f)
        {
            await UniTask.Delay(TimeSpan.FromSeconds(_attackDelay), cancellationToken: token);
        }
        if (token.IsCancellationRequested) return;

        // 묶음 내 의도를 순서대로 실행. 중간에 적이 죽거나 취소되면 중단.
        for (int i = 0; i < intents.Count; i++)
        {
            if (token.IsCancellationRequested || !_enemy.IsAlive) return;

            EnemyIntent intent = intents[i];

#if UNITY_EDITOR || DEVELOPMENT_BUILD
            Debug.Log($"[EnemyTurnHandler] 적 행동 — {intent.Type} {intent.Amount} x{intent.EffectiveHits}");
#endif

            switch (intent.Type)
            {
                case EEnemyIntentType.Attack:
                    // 다단 히트: 히트당 Amount 피해를 EffectiveHits 번 적용.
                    for (int h = 0; h < intent.EffectiveHits; h++)
                    {
                        if (token.IsCancellationRequested) return;
                        if (_attackMotionAsync != null)
                        {
                            await _attackMotionAsync.Invoke(token);
                            if (token.IsCancellationRequested) return;
                        }
                        target?.TakeDamage(intent.Amount);
                    }
                    break;

                case EEnemyIntentType.GridLineAttack:
                    if (_gridLineAttackAsync != null)
                    {
                        await _gridLineAttackAsync.Invoke(token);
                    }
                    break;

                case EEnemyIntentType.Defend:
                    _enemy.GainBlock(intent.Amount);
                    break;

                case EEnemyIntentType.InstallBlankCards:
                    InstallManaDisturbanceCards(intent.Amount);
                    break;

                case EEnemyIntentType.InstallOnDisturbanceBlocks:
                    InstallOnDisturbanceBlocks(intent.Amount);
                    break;

                case EEnemyIntentType.InstallHandCurse:
                    InstallHandCurseBlocks(intent.Amount);
                    break;

                case EEnemyIntentType.EraseInfo:
                    if (_eraseInfoAsync != null)
                    {
                        await _eraseInfoAsync.Invoke(token);
                        if (token.IsCancellationRequested) return;
                    }
                    _grid?.SetCardInfoHidden(true);
                    break;

                case EEnemyIntentType.EraseCardKindOnly:
                    // 카드 종류(이름/스탯)만 숨기고 방향 화살표는 유지 — EraseInfo 완화판.
                    if (_eraseInfoAsync != null)
                    {
                        await _eraseInfoAsync.Invoke(token);
                        if (token.IsCancellationRequested) return;
                    }
                    _grid?.SetCardInfoHidden(true, keepArrow: true);
                    break;

                case EEnemyIntentType.BuffBlockOnPlayerManaGain:
                case EEnemyIntentType.BuffDamageOnPlayerDraw:
                case EEnemyIntentType.BuffInstallDisturbanceOnCardToggle:
                    _eliteBuffController?.Activate(intent);
                    break;
            }
        }
    }

    /// <summary>빈 그리드 칸에 적 전용 임시 무방향 카드를 설치한다.</summary>
    public void InstallManaDisturbanceCards(int count)
    {
        if (_grid == null || count <= 0) return;

        List<GridSlot> emptySlots = _grid.GetEmptySlots();
        Shuffle(emptySlots);

        int placed = 0;
        for (int i = 0; i < emptySlots.Count && placed < count; i++)
        {
            GridSlot slot = emptySlots[i];
            if (slot == null || !slot.IsEmpty) continue;

            Card card = CreateEnemyTemporaryCard(BlankCardId);
            if (card == null) continue;

            if (_grid.TryPlaceCard(card, slot.Position))
            {
                card.GridState.SetActivated(true);
                _grid.SetCardActivated(card, true);
                placed++;
            }
        }

#if UNITY_EDITOR || DEVELOPMENT_BUILD
        Debug.Log($"[EnemyTurnHandler] 임시 무방향 카드 설치 — 요청 {count}, 성공 {placed}");
#endif
    }

    /// <summary>빈 그리드 칸에 ON 상태 방해 블록을 설치한다.</summary>
    public void InstallOnDisturbanceBlocks(int count)
    {
        InstallOnBlocks(count, DisturbanceBlockCardId, "ON 방해 블록");
    }

    /// <summary>빈 그리드 칸에 ON 상태 저주 블록을 설치한다.</summary>
    public void InstallHandCurseBlocks(int count)
    {
        InstallOnBlocks(count, HandCurseBlockCardId, "ON 저주 블록");
    }

    private void InstallOnBlocks(int count, string cardId, string logLabel)
    {
        if (_grid == null || count <= 0) return;

        List<GridSlot> emptySlots = _grid.GetEmptySlots();
        Shuffle(emptySlots);

        int placed = 0;
        for (int i = 0; i < emptySlots.Count && placed < count; i++)
        {
            GridSlot slot = emptySlots[i];
            if (slot == null || !slot.IsEmpty) continue;

            Card card = CreateEnemyTemporaryCard(cardId);
            if (card == null) continue;

            if (_grid.TryPlaceCard(card, slot.Position))
            {
                card.GridState.SetActivated(true);
                _grid.SetCardActivated(card, true);
                placed++;
            }
        }

#if UNITY_EDITOR || DEVELOPMENT_BUILD
        Debug.Log($"[EnemyTurnHandler] {logLabel} 설치 — 요청 {count}, 성공 {placed}");
#endif
    }

    private static Card CreateEnemyTemporaryCard(string cardId)
    {
        if (!DataManager.HasInstance || !DataManager.Instance.IsLoaded) return null;

        CardDataSO data = DataManager.Instance.GetData<CardDataSO>(cardId);
        Card card = data != null ? CardFactory.CreateFromSO(data) : null;
        card?.SetBattleDeckOwner(EBattleDeckOwner.EnemyTemporary);
        return card;
    }

    private static void Shuffle<T>(IList<T> list)
    {
        if (list == null) return;

        for (int i = list.Count - 1; i > 0; i--)
        {
            int j = UnityEngine.Random.Range(0, i + 1);
            (list[i], list[j]) = (list[j], list[i]);
        }
    }

    /// <summary>
    /// 다음 의도로 전진. Enemy 의 패턴 결정 콜백이 주입됐으면 그것을(상태 기반 패턴),
    /// 없으면 Actor 의 SO 순환을 폴백으로 사용한다.
    /// </summary>
    public void AdvanceIntent()
    {
        if (_advanceIntent != null)
        {
            _advanceIntent.Invoke();
        }
        else
        {
            _enemy?.AdvanceIntent();
        }
    }
}
