using System;
using System.Collections.Generic;
using System.Threading;
using Cysharp.Threading.Tasks;
using UnityEngine;

public readonly struct EnemyEliteBuffView
{
    public int Id { get; }
    public EEnemyIntentType Type { get; }
    public int Amount { get; }
    public int Threshold { get; }
    public int RemainingCount { get; }

    public EnemyEliteBuffView(int id, EEnemyIntentType type, int amount, int threshold, int remainingCount)
    {
        Id = id;
        Type = type;
        Amount = amount;
        Threshold = threshold;
        RemainingCount = remainingCount;
    }
}

public sealed class EnemyEliteBuffController : IDisposable
{
    private const int DefaultToggleThreshold = 10;

    private readonly EnemyActor _enemy;
    private readonly PlayerActor _player;
    private readonly DeckSystem _deck;
    private readonly BattleManager _battle;
    private readonly Action<int> _installDisturbanceBlocks;
    private readonly Func<CancellationToken, UniTask> _attackMotionAsync;
    private readonly CancellationTokenSource _motionCts = new CancellationTokenSource();
    private readonly List<EnemyEliteBuffView> _activeBuffViews = new List<EnemyEliteBuffView>(3);

    private int _blockOnManaGain;
    private int _damageOnDraw;
    private int _toggleInstallCount;
    private int _toggleThreshold;
    private int _toggleRemainingCount;
    private int _lastEnergy;
    private bool _attackMotionPlaying;
    private bool _disposed;

    public IReadOnlyList<EnemyEliteBuffView> ActiveBuffViews => _activeBuffViews;
    public event Action OnBuffChanged;

    public EnemyEliteBuffController(
        EnemyActor enemy,
        PlayerActor player,
        DeckSystem deck,
        BattleManager battle,
        Action<int> installDisturbanceBlocks,
        Func<CancellationToken, UniTask> attackMotionAsync)
    {
        _enemy = enemy;
        _player = player;
        _deck = deck;
        _battle = battle;
        _installDisturbanceBlocks = installDisturbanceBlocks;
        _attackMotionAsync = attackMotionAsync;
        _lastEnergy = player != null ? player.Energy : 0;

        if (_player != null)
        {
            _player.OnEnergyChanged += HandleEnergyChanged;
        }

        if (_deck != null)
        {
            _deck.OnCardDrawnByCardEffect += HandleCardDrawnByCardEffect;
        }

        if (_battle != null)
        {
            _battle.OnCardToggled += HandleCardToggled;
        }
    }

    public void Activate(EnemyIntent intent)
    {
        switch (intent.Type)
        {
            case EEnemyIntentType.BuffBlockOnPlayerManaGain:
                _blockOnManaGain = Mathf.Max(0, intent.Amount);
                _lastEnergy = _player != null ? _player.Energy : 0;
                SetActiveBuff(intent.Type, _blockOnManaGain, 0, 0);
                break;

            case EEnemyIntentType.BuffDamageOnPlayerDraw:
                _damageOnDraw = Mathf.Max(0, intent.Amount);
                SetActiveBuff(intent.Type, _damageOnDraw, 0, 0);
                break;

            case EEnemyIntentType.BuffInstallDisturbanceOnCardToggle:
                _toggleInstallCount = Mathf.Max(1, intent.Amount);
                _toggleThreshold = intent.EffectiveHits > 1 ? intent.EffectiveHits : DefaultToggleThreshold;
                _toggleRemainingCount = _toggleThreshold;
                SetActiveBuff(intent.Type, _toggleInstallCount, _toggleThreshold, _toggleRemainingCount);
                break;
        }
    }

    public void Clear()
    {
        _blockOnManaGain = 0;
        _damageOnDraw = 0;
        _toggleInstallCount = 0;
        _toggleThreshold = 0;
        _toggleRemainingCount = 0;
        _lastEnergy = _player != null ? _player.Energy : 0;
        if (_activeBuffViews.Count > 0)
        {
            _activeBuffViews.Clear();
            OnBuffChanged?.Invoke();
        }
    }

    public void Dispose()
    {
        if (_disposed)
        {
            return;
        }

        _disposed = true;
        if (_player != null)
        {
            _player.OnEnergyChanged -= HandleEnergyChanged;
        }

        if (_deck != null)
        {
            _deck.OnCardDrawnByCardEffect -= HandleCardDrawnByCardEffect;
        }

        if (_battle != null)
        {
            _battle.OnCardToggled -= HandleCardToggled;
        }

        Clear();
        _motionCts.Cancel();
        _motionCts.Dispose();
    }

    private void SetActiveBuff(EEnemyIntentType type, int amount, int threshold, int remainingCount)
    {
        int id = (int)type;
        EnemyEliteBuffView view = new EnemyEliteBuffView(id, type, amount, threshold, remainingCount);
        for (int i = 0; i < _activeBuffViews.Count; i++)
        {
            if (_activeBuffViews[i].Id == id)
            {
                _activeBuffViews[i] = view;
                OnBuffChanged?.Invoke();
                return;
            }
        }

        _activeBuffViews.Add(view);
        OnBuffChanged?.Invoke();
    }

    private void HandleEnergyChanged(int current, int max)
    {
        int delta = current - _lastEnergy;
        _lastEnergy = current;
        if (_blockOnManaGain <= 0 || delta <= 0 || _enemy == null || !_enemy.IsAlive)
        {
            return;
        }

        _enemy.GainBlock(_blockOnManaGain * delta);
    }

    private void HandleCardDrawnByCardEffect(Card card, Card source)
    {
        if (_damageOnDraw <= 0 || _player == null || !_player.IsAlive)
        {
            return;
        }

        PlayAttackMotion();
        _player.TakeDamage(_damageOnDraw);
    }

    private void PlayAttackMotion()
    {
        if (_disposed || _attackMotionPlaying || _attackMotionAsync == null || _motionCts.IsCancellationRequested)
        {
            return;
        }

        PlayAttackMotionSafelyAsync().Forget();
    }

    private async UniTaskVoid PlayAttackMotionSafelyAsync()
    {
        _attackMotionPlaying = true;
        try
        {
            await _attackMotionAsync.Invoke(_motionCts.Token);
        }
        catch (OperationCanceledException)
        {
        }
        catch (Exception ex)
        {
            Debug.LogWarning($"[EnemyEliteBuffController] 디버프 공격 모션 재생 실패: {ex.Message}");
        }
        finally
        {
            _attackMotionPlaying = false;
        }
    }

    private void HandleCardToggled(Card card, bool activated)
    {
        if (_toggleInstallCount <= 0 || _toggleThreshold <= 0 || !activated)
        {
            return;
        }

        if (_toggleRemainingCount <= 1)
        {
            _installDisturbanceBlocks?.Invoke(_toggleInstallCount);
            _toggleRemainingCount = _toggleThreshold;
        }
        else
        {
            _toggleRemainingCount--;
        }

        SetActiveBuff(
            EEnemyIntentType.BuffInstallDisturbanceOnCardToggle,
            _toggleInstallCount,
            _toggleThreshold,
            _toggleRemainingCount);
    }
}
