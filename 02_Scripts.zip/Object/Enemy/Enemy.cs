// =================================================================
// [스크립트 목적]  적 '대표 객체' (PoolableMonoBehaviour). 하이어라키에 존재하며
//                 EnemyActor(로직)와 EnemyView(그림)를 소유한다. 적의 주체.
//                 의도(공격 패턴) 결정을 가상 메서드로 열어 다양한 적을 상속으로 확장.
// [주요 변수]      - _view   : 자식 비주얼 (그림·피격연출). 위치 제공
//                  - _actor  : 적 로직 액터 (HP·방어막·의도). 코드 생성·소유
//                  - _handler: 의도 실행 핸들러 (Enemy 가 소유, BattleManager 에 제공)
// [의존 관계]      - PoolableMonoBehaviour / EnemyActor / EnemyView / EnemyDataSO
//                  - IEnemyTurnHandler / EnemyTurnHandler / EnemyIntent
// [배치]           World 카테고리 풀 프리팹. 자식에 EnemyView(+SpriteRenderer).
// [설계 노트]      - View 는 그림만, 대표는 이 Enemy. Actor 는 POCO 라 Enemy 가 생성·소유.
//                  - 공격 패턴 다양화: DecideNextIntent() 오버라이드 (기본=SO 순환은 PatternEnemy).
//                  - 풀 재사용: OnSpawnFromPool 에서 Setup, OnReturnToPool 에서 구독 해제.
//                  - 상태 전파: Actor 가 이벤트 발행 → View·UI·BattleManager 가 직접 구독.
//                    Enemy 는 Actor/View 를 잇고 '의도 결정'만 책임진다.
// =================================================================

using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// 적 대표 객체의 추상 베이스. EnemyActor(로직)와 EnemyView(그림)를 소유·연결하고,
/// 의도(공격 패턴) 결정을 DecideNextIntent() 가상 메서드로 열어 상속으로 다양한 적을 만든다.
/// 풀링 대상(PoolableMonoBehaviour)이라 적 교체 시 Spawn/Despawn 으로 재사용된다.
/// </summary>
public abstract class Enemy : PoolableMonoBehaviour
{
    [Header("비주얼")]
    [Tooltip("적 그림·피격 연출 담당 자식 View. 위치(Anchor) 제공")]
    [SerializeField] private EnemyView _view;

    private EnemyView _defaultView;

    // 로직 액터 (코드 생성·소유). 비주얼/위치는 _view 가 담당.
    private EnemyActor _actor;

    // 의도 실행 핸들러 (Enemy 소유 → BattleController 가 BattleManager 에 주입).
    private EnemyTurnHandler _handler;

    // 마지막으로 셋업된 데이터 (의도 결정 정책에서 참조).
    private EnemyDataSO _data;

    /// <summary>적 로직 액터 (HP·방어막·의도·이벤트). 외부는 이걸 구독한다.</summary>
    public EnemyActor Actor => _actor;

    /// <summary>적 비주얼 View (위치 제공 ICombatTarget).</summary>
    public EnemyView View => _view;

    /// <summary>의도 실행 핸들러 (BattleManager 의 적 턴 수행 대상).</summary>
    public IEnemyTurnHandler Handler => _handler;

    /// <summary>이 적의 데이터 (의도 결정·표시용).</summary>
    public EnemyDataSO Data => _data;

    /// <summary>현재 실행 예정인 의도 순번(1부터 시작). 패턴이 없으면 0.</summary>
    public int CurrentIntentOrder { get; private set; }

    /// <summary>현재 보스 페이즈 인덱스(0-based).</summary>
    public int CurrentPhaseIndex => _actor != null ? _actor.CurrentPhaseIndex : 0;

    // ── 풀 생명주기 ─────────────────────────────────────────

    protected override void OnPoolCreate()
    {
        // 자식 View 자동 수집 (Inspector 미연결 폴백).
        if (_view == null)
        {
            _view = GetComponentInChildren<EnemyView>(includeInactive: true);
        }
        _defaultView = _view;
    }

    public override void OnReturnToPool()
    {
        // 구독 해제 (View 의 Actor 구독 정리). Actor 는 다음 Setup 에서 새로 만들거나 재사용.
        _view?.Unbind();
        ResetRuntimeView();
        _handler = null;
        base.OnReturnToPool();
    }

    // ── 셋업 (적 등장 시) ───────────────────────────────────

    /// <summary>
    /// 적 데이터로 이 객체를 구성. EnemyActor 를 만들고 View 에 바인딩한 뒤,
    /// 의도 핸들러를 준비하고 첫 의도를 결정(DecideNextIntent)해 주입한다.
    /// BattleController 가 Spawn 직후 호출한다.
    /// </summary>
    /// <param name="data">이 적의 정의 SO (체력·의도 패턴 원천).</param>
    /// <param name="attackDelay">의도 실행 연출 대기(초).</param>
    /// <param name="grid">적 패턴이 개입할 플레이어 그리드.</param>
    public void Setup(EnemyDataSO data, float attackDelay = 0.3f, GridManager grid = null)
    {
        _data = data;

        // 로직 액터 생성·셋업 (HP/방어막/의도 초기화 + 이벤트 발행).
        _actor = new EnemyActor(data);
        _actor.Setup(data != null ? data.MaxHp : 1);

        // 의도 실행 핸들러 (Enemy 가 소유, BattleManager 에 제공).
        // AdvanceIntent 는 이 Enemy 의 패턴 결정으로 라우팅 (상태 기반 의도 가능).
        _handler = new EnemyTurnHandler(_actor, attackDelay, AdvanceIntent, grid, () => CurrentIntentOrder);

        // 비주얼 바인딩 (피격·사망 연출 구독). View 활성화.
        if (_view != null)
        {
            _view.gameObject.SetActive(true);
            _view.Bind(_actor);
        }

        // 첫 의도 결정 → Actor 주입 (패턴 정책은 파생 클래스가 결정).
        IReadOnlyList<EnemyIntent> first = DecideNextIntent(isFirst: true);
        _actor.SetIntents(first);
    }

    /// <summary>SO별 런타임 View 로 교체한다. null 이면 기본 View 유지.</summary>
    public void SetRuntimeView(EnemyView runtimeView)
    {
        if (runtimeView == null || runtimeView == _view) return;

        _view?.Unbind();
        if (_defaultView != null && _defaultView != runtimeView)
        {
            _defaultView.gameObject.SetActive(false);
        }

        _view = runtimeView;
        _view.gameObject.SetActive(true);

        if (_actor != null)
        {
            _view.Bind(_actor);
        }
    }

    /// <summary>런타임 View 교체 상태를 해제하고 기본 View 로 되돌린다.</summary>
    public void ResetRuntimeView()
    {
        if (_view != null && _view != _defaultView)
        {
            _view.Unbind();
        }

        _view = _defaultView;
        if (_view != null)
        {
            _view.gameObject.SetActive(true);
        }
    }

    /// <summary>
    /// 다음 턴 의도로 전진. Enemy 가 패턴을 결정(DecideNextIntent)해 Actor 에 주입한다.
    /// BattleManager 의 AdvanceIntent 흐름에서 호출되도록 핸들러가 위임받는 지점.
    /// </summary>
    public void AdvanceIntent()
    {
        if (_actor == null) return;
        IReadOnlyList<EnemyIntent> next = DecideNextIntent(isFirst: false);
        _actor.SetIntents(next);
    }

    /// <summary>다음 보스 페이즈로 전환하고 해당 페이즈의 첫 의도를 주입한다.</summary>
    public bool TryAdvancePhase()
    {
        if (_actor == null || !_actor.TryAdvancePhase()) return false;

        IReadOnlyList<EnemyIntent> first = DecideNextIntent(isFirst: true);
        _actor.SetIntents(first);
        return true;
    }

    // ── 의도 결정 (확장 지점) ───────────────────────────────

    /// <summary>
    /// 다음 의도 묶음을 결정한다. 적마다 오버라이드해 공격 패턴을 다양화한다.
    /// 한 턴에 여러 의도(공+방 동시)를 반환할 수 있다.
    /// </summary>
    /// <param name="isFirst">전투 시작 첫 의도면 true (인덱스 0 기준), 이후 전진이면 false.</param>
    protected abstract IReadOnlyList<EnemyIntent> DecideNextIntent(bool isFirst);

    /// <summary>SO 패턴 인덱스 순환 헬퍼 (파생 클래스 공용). 데이터 없으면 빈 묶음.</summary>
    protected IReadOnlyList<EnemyIntent> GetPatternIntentTurn(int index)
    {
        int phaseIndex = CurrentPhaseIndex;
        int intentCount = _data != null ? _data.GetPhaseIntentCount(phaseIndex) : 0;
        if (intentCount == 0)
        {
            CurrentIntentOrder = 0;
            return System.Array.Empty<EnemyIntent>();
        }

        int normalized = index % intentCount;
        CurrentIntentOrder = normalized + 1;
        return _data.GetPhaseIntentTurn(phaseIndex, normalized).Intents ?? System.Array.Empty<EnemyIntent>();
    }
}
