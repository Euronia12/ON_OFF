// =================================================================
// [스크립트 목적]  의도 1개 표시 엔트리 (아이콘 + 수치 텍스트). UIEnemyIntentView 가
//                 의도 묶음을 그릴 때 칸 단위로 재사용한다.
// [주요 변수]      - _icon : 의도 아이콘 이미지
//                  - _text : 수치 텍스트 (예: "5", "5x3"). 비면 숨김
// [의존 관계]      - 단순 MonoBehaviour. 풀 인프라 미사용 (뷰가 로컬 리스트로 재사용)
// [설계 노트]      - Setup(sprite, valueText) 로 갱신. sprite 없으면 아이콘 숨김
//                  - 선택적으로 호버 콜백을 연결해 개별 칸의 툴팁을 표시할 수 있다.
// =================================================================

using System;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

/// <summary>
/// 의도 1개를 나타내는 표시 칸. 아이콘과 수치 텍스트를 가진다.
/// UIEnemyIntentView 가 의도 개수에 맞춰 이 엔트리를 켜고 끄며 재사용한다.
/// </summary>
public sealed class UIIntentEntry : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler
{
    [Tooltip("의도 아이콘 이미지")]
    [SerializeField] private Image _icon;

    [Tooltip("의도 수치 텍스트 (예: 5, 5x3). 비면 숨김")]
    [SerializeField] private TMP_Text _text;

    private Action<UIIntentEntry> _pointerEnter;
    private Action<UIIntentEntry> _pointerExit;

    /// <summary>아이콘·수치 갱신. sprite 가 null 이면 아이콘 숨김.</summary>
    public void Setup(Sprite sprite, string valueText)
    {
        if (_icon != null)
        {
            _icon.sprite = sprite;
            _icon.enabled = sprite != null;
        }
        if (_text != null)
        {
            LocalizedFontUtility.ApplyCurrentFont(_text);
            _text.text = valueText ?? string.Empty;
            _text.enabled = !string.IsNullOrEmpty(valueText);
        }
    }

    public void SetHoverHandlers(Action<UIIntentEntry> pointerEnter, Action<UIIntentEntry> pointerExit)
    {
        _pointerEnter = pointerEnter;
        _pointerExit = pointerExit;
    }

    public void OnPointerEnter(PointerEventData eventData)
    {
        _pointerEnter?.Invoke(this);
    }

    public void OnPointerExit(PointerEventData eventData)
    {
        _pointerExit?.Invoke(this);
    }
}
