using System.Collections.Generic;
using UnityEngine;

public sealed class UIEnemyEliteBuffStatusPanel : MonoBehaviour
{
    [SerializeField] private Transform _container;
    [SerializeField] private UIBattleBuffIcon _buffIconPrefab;
    [SerializeField] private IntentIconSO _iconSet;
    [Tooltip("2페이즈 이상 보스가 1페이즈 동안 표시할 타락한 영혼 아이콘")]
    [SerializeField] private Sprite _corruptedSoulIcon;
    [SerializeField] private UIEnemyIntentPanel _tooltipPanel;
    [SerializeField] private Vector2 _tooltipOffset = new Vector2(0f, -12f);

    private readonly List<UIBattleBuffIcon> _entries = new List<UIBattleBuffIcon>(3);
    private readonly List<EnemyEliteBuffView> _visibleViews = new List<EnemyEliteBuffView>(3);
    private EnemyEliteBuffController _controller;
    private EnemyActor _enemy;
    private UIBattleBuffIcon _corruptedSoulEntry;

    public void Bind(EnemyEliteBuffController controller, EnemyActor enemy)
    {
        if (_controller == controller && _enemy == enemy)
        {
            Refresh();
            return;
        }

        Unbind();
        _controller = controller;
        _enemy = enemy;
        if (_controller != null)
        {
            _controller.OnBuffChanged += Refresh;
        }

        Refresh();
    }

    public void Unbind()
    {
        if (_controller != null)
        {
            _controller.OnBuffChanged -= Refresh;
            _controller = null;
        }
        _enemy = null;
        _corruptedSoulEntry = null;

        _tooltipPanel?.Hide();
        Render(null);
    }

    private void OnDestroy()
    {
        Unbind();
    }

    private void Refresh()
    {
        Render(_controller?.ActiveBuffViews);
    }

    public void RefreshBossPhase()
    {
        Refresh();
    }

    private void Render(IReadOnlyList<EnemyEliteBuffView> views)
    {
        int count = views != null ? views.Count : 0;
        bool showCorruptedSoul = _enemy != null &&
                                 _enemy.Data != null &&
                                 _enemy.Data.PhaseCount > 1 &&
                                 _enemy.CurrentPhaseIndex == 0;
        int entryOffset = showCorruptedSoul ? 1 : 0;
        _tooltipPanel?.Hide();
        _visibleViews.Clear();
        SetPanelVisible(showCorruptedSoul || count > 0);

        if (showCorruptedSoul)
        {
            _corruptedSoulEntry = GetOrCreateEntry(0);
            if (_corruptedSoulEntry != null)
            {
                _corruptedSoulEntry.Bind(_corruptedSoulIcon, string.Empty);
                _corruptedSoulEntry.gameObject.SetActive(true);
                _corruptedSoulEntry.SetHoverHandlers(HandleEntryPointerEnter, HandleEntryPointerExit);
            }
        }
        else
        {
            _corruptedSoulEntry = null;
        }

        for (int i = 0; i < count; i++)
        {
            UIBattleBuffIcon entry = GetOrCreateEntry(i + entryOffset);
            if (entry == null)
            {
                continue;
            }

            EnemyEliteBuffView view = views[i];
            _visibleViews.Add(view);
            Sprite icon = _iconSet != null ? _iconSet.Resolve(view.Type) : null;
            entry.Bind(icon, BuildValueText(view));
            entry.gameObject.SetActive(true);
            entry.SetHoverHandlers(HandleEntryPointerEnter, HandleEntryPointerExit);
        }

        for (int i = count + entryOffset; i < _entries.Count; i++)
        {
            if (_entries[i] != null)
            {
                _entries[i].gameObject.SetActive(false);
            }
        }
    }

    private void HandleEntryPointerEnter(UIBattleBuffIcon entry)
    {
        if (_tooltipPanel == null || entry == null)
        {
            return;
        }

        if (entry == _corruptedSoulEntry)
        {
            _tooltipPanel.Show(
                default,
                LocalizationKeys.Battle.CorruptedSoulBuffName,
                LocalizationKeys.Battle.CorruptedSoulBuffDesc);
            _tooltipPanel.MoveBelow((RectTransform)entry.transform, _tooltipOffset);
            return;
        }

        int index = _entries.IndexOf(entry);
        if (_corruptedSoulEntry != null)
        {
            index--;
        }
        if (index < 0 || index >= _visibleViews.Count)
        {
            return;
        }

        EnemyEliteBuffView view = _visibleViews[index];
        EnemyIntent intent = new EnemyIntent
        {
            Type = view.Type,
            Amount = view.Amount,
            Hits = view.Threshold,
        };
        _tooltipPanel.Show(intent);
        _tooltipPanel.MoveBelow((RectTransform)entry.transform, _tooltipOffset);
    }

    private void HandleEntryPointerExit(UIBattleBuffIcon entry)
    {
        _tooltipPanel?.Hide();
    }

    private void OnDisable()
    {
        _tooltipPanel?.Hide();
    }

    private UIBattleBuffIcon GetOrCreateEntry(int index)
    {
        if (index < _entries.Count)
        {
            return _entries[index];
        }

        if (_buffIconPrefab == null || _container == null)
        {
#if UNITY_EDITOR || DEVELOPMENT_BUILD
            Debug.LogWarning($"[UIEnemyEliteBuffStatusPanel] '{name}' _buffIconPrefab 또는 _container 미연결.");
#endif
            return null;
        }

        UIBattleBuffIcon created = Instantiate(_buffIconPrefab, _container);
        _entries.Add(created);
        return created;
    }

    private void SetPanelVisible(bool visible)
    {
        if (_container != null)
        {
            _container.gameObject.SetActive(visible);
            return;
        }

        gameObject.SetActive(visible);
    }

    private static string BuildValueText(EnemyEliteBuffView view)
    {
        if (view.Type == EEnemyIntentType.BuffInstallDisturbanceOnCardToggle)
        {
            return view.RemainingCount.ToString();
        }

        return view.Amount > 0 ? view.Amount.ToString() : string.Empty;
    }
}
