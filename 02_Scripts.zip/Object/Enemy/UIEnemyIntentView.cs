// =================================================================
// [스크립트 목적]  적의 의도 묶음(공+방 동시 등)을 아이콘+수치 리스트로 표시하는 위젯.
//                 EnemyActor.OnIntentChanged 구독으로 의도 변동 시 자동 갱신.
//                 UIActorStatus 에서 분리 — 의도는 다중·확장 가능성이 커 독립 컴포넌트로.
// [주요 변수]      - _container   : 엔트리들이 배치될 부모 (LayoutGroup 권장)
//                  - _entryPrefab : 의도 1칸 프리팹 (UIIntentEntry)
//                  - _iconSet     : 의도 타입 → 아이콘 매핑 SO
//                  - _entries     : 생성해 둔 엔트리 로컬 캐시 (재사용)
// [의존 관계]      - EnemyActor (OnIntentChanged), EnemyIntent, IntentIconSO, UIIntentEntry
// [설계 노트]      - 풀 인프라 대신 로컬 리스트 재사용: 필요 수만큼 활성화, 모자라면 그때 생성.
//                    의도 칸 수가 적어(보통 1~3) GC 이득 대비 풀 관리 비용이 커서 이 방식 채택
//                  - 수치 규칙: 공격 다단=「피해x히트」, 그 외 수치>0이면 숫자, 0이면 빈칸
// =================================================================

using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;

/// <summary>
/// 한 적의 의도 묶음을 아이콘+수치 칸 리스트로 표시하는 위젯.
/// Bind 로 적 액터를 연결하면 OnIntentChanged 를 구독해 의도 변동 시 자동 갱신한다.
/// 엔트리는 로컬 리스트로 재사용하며, 필요 개수보다 많으면 남는 칸은 비활성화한다.
/// 의도 영역 위에 마우스를 올리면 툴팁 패널에 의도 전체 설명을 표시한다.
/// </summary>
public sealed class UIEnemyIntentView : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler, ILocalizable
{
    [Tooltip("적 의도 라벨 텍스트. 캐싱/연결은 인스펙터에서 수행")]
    [SerializeField] private TMP_Text _intentLabelText;

    [Tooltip("의도 엔트리가 배치될 부모 (HorizontalLayoutGroup 등 권장)")]
    [SerializeField] private Transform _container;

    [Tooltip("의도 1칸 프리팹 (UIIntentEntry)")]
    [SerializeField] private UIIntentEntry _entryPrefab;

    [Tooltip("의도 타입 → 아이콘 매핑 SO")]
    [SerializeField] private IntentIconSO _iconSet;

    [Tooltip("호버 시 의도 설명을 띄울 툴팁 패널. 비우면 툴팁 없이 동작")]
    [SerializeField] private UIEnemyIntentPanel _tooltipPanel;

    // 생성해 둔 엔트리 캐시. 의도 수에 맞춰 앞에서부터 재사용하고 나머지는 비활성.
    private readonly List<UIIntentEntry> _entries = new();

    // 현재 표시 중인 의도 묶음 (영역 호버 시 툴팁에 전달). Render 시 갱신.
    private IReadOnlyList<EnemyIntent> _currentIntents;

    // 현재 바인딩된 적 (구독 해제용 참조).
    private EnemyActor _enemy;

    private void OnEnable()
    {
        if (LocalizationManager.HasInstance)
            LocalizationManager.Instance.Register(this);
        else
            OnLocalize();
    }

    private void OnDisable()
    {
        if (LocalizationManager.HasInstance)
            LocalizationManager.Instance.Unregister(this);
    }

    public void OnLocalize()
    {
        if (_intentLabelText == null)
        {
            return;
        }

        LocalizedFontUtility.ApplyCurrentFont(_intentLabelText);
        _intentLabelText.text = LocalizationManager.HasInstance
            ? LocalizationManager.Instance.Get(LocalizationKeys.Battle.EnemyIntent)
            : LocalizationKeys.Battle.EnemyIntent;
    }

    // ── 바인딩 ──────────────────────────────────────────────

    /// <summary>적 액터 바인딩 — 의도 변동 구독. 현재 의도 즉시 반영.</summary>
    public void Bind(EnemyActor enemy)
    {
        Unbind();
        _enemy = enemy;
        if (enemy == null)
        {
            Render(null);
            return;
        }

        enemy.OnIntentChanged += HandleIntentChanged;
        HandleIntentChanged(enemy.CurrentIntents);
    }

    /// <summary>구독 해제 (재바인딩·파괴 시). 중복 호출 안전.</summary>
    public void Unbind()
    {
        if (_enemy != null)
        {
            _enemy.OnIntentChanged -= HandleIntentChanged;
            _enemy = null;
        }
        if (_tooltipPanel != null) _tooltipPanel.Hide();
    }

    private void OnDestroy()
    {
        if (LocalizationManager.HasInstance)
            LocalizationManager.Instance.Unregister(this);

        Unbind();
    }

    // ── 이벤트 핸들러 ───────────────────────────────────────

    private void HandleIntentChanged(IReadOnlyList<EnemyIntent> intents) => Render(intents);

    /// <summary>의도 영역 호버 진입 — 툴팁에 의도 전체 표시, 위치는 영역 왼쪽에 맞춤.</summary>
    public void OnPointerEnter(PointerEventData eventData)
    {
        if (_tooltipPanel == null) return;

        _tooltipPanel.Show(_currentIntents);
        _tooltipPanel.MoveTo((RectTransform)transform);
    }

    /// <summary>의도 영역 호버 이탈 — 툴팁 숨김.</summary>
    public void OnPointerExit(PointerEventData eventData)
    {
        if (_tooltipPanel != null) _tooltipPanel.Hide();
    }

    // ── 렌더 ────────────────────────────────────────────────

    /// <summary>의도 묶음을 엔트리 리스트에 반영. 부족하면 생성, 남으면 비활성.</summary>
    private void Render(IReadOnlyList<EnemyIntent> intents)
    {
        _currentIntents = intents;
        int count = intents != null ? intents.Count : 0;

        for (int i = 0; i < count; i++)
        {
            UIIntentEntry entry = GetOrCreateEntry(i);
            if (entry == null) continue;

            EnemyIntent intent = intents[i];
            Sprite icon = _iconSet != null ? _iconSet.ResolveForIntent(intent.Type) : null;
            entry.Setup(icon, BuildValueText(intent));
            entry.gameObject.SetActive(true);
        }

        // 남는 엔트리 비활성화 (재사용 대기).
        for (int i = count; i < _entries.Count; i++)
        {
            if (_entries[i] != null)
            {
                _entries[i].gameObject.SetActive(false);
            }
        }
    }

    /// <summary>index 위치 엔트리 반환. 없으면 생성해 캐시에 추가.</summary>
    private UIIntentEntry GetOrCreateEntry(int index)
    {
        if (index < _entries.Count)
        {
            return _entries[index];
        }

        if (_entryPrefab == null || _container == null)
        {
#if UNITY_EDITOR || DEVELOPMENT_BUILD
            Debug.LogWarning($"[UIEnemyIntentView] '{name}' _entryPrefab 또는 _container 미연결 — 의도 칸 생성 불가");
#endif
            return null;
        }

        UIIntentEntry created = Instantiate(_entryPrefab, _container);
        _entries.Add(created);
        return created;
    }

    /// <summary>의도 수치 표시 문자열. 공격 다단=「피해x히트」, 그 외 수치>0이면 숫자, 0이면 빈칸.</summary>
    private static string BuildValueText(EnemyIntent intent)
    {
        if (EnemyIntentInfo.IsBeneficialBuffIntent(intent.Type))
        {
            return string.Empty;
        }

        // 정보 은폐 계열은 수치가 없다. GridLineAttack 은 Amount(자를 라인 수)를 아래 기본 분기에서 표시.
        if (intent.Type == EEnemyIntentType.EraseInfo ||
            intent.Type == EEnemyIntentType.EraseCardKindOnly)
        {
            return string.Empty;
        }
        if (intent.Type == EEnemyIntentType.Attack && intent.EffectiveHits > 1)
        {
            return $"{intent.Amount}x{intent.EffectiveHits}";
        }
        return intent.Amount > 0 ? intent.Amount.ToString() : string.Empty;
    }
}
