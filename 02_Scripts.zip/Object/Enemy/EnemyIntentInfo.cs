// =================================================================
// [스크립트 목적]  적 의도 1개를 호버 툴팁용 (이름 + 설명) 텍스트로 변환한다.
//                 CardKeywordInfo 의 의도판 대응물 — 타입별 로컬라이즈 키를 모아두고,
//                 수치(Amount/Hits)를 끼워 설명 문장을 만든다.
// [의존 관계]      - EEnemyIntentType (BattleEnums), EnemyIntent (EnemyDataSO),
//                    LocalizationManager (Get / Get+args)
// [설계 노트]      - 데이터 구조 변경 없이 타입+수치로 자동 생성(요구: 가-방식).
//                  - 로컬라이즈 키가 없으면 키 문자열이 그대로 나오므로, 키만 시트에 등록하면 됨.
//                  - 설명 포맷 인자: 공격={0}=피해, {1}=히트 / 그 외={0}=수치.
// =================================================================

/// <summary>의도 툴팁에 들어갈 이름·설명 문자열 한 쌍.</summary>
public readonly struct IntentDisplayText
{
    public readonly string Name;
    public readonly string Description;

    public IntentDisplayText(string name, string description)
    {
        Name = name;
        Description = description;
    }
}

/// <summary>적 의도 타입 → 툴팁 텍스트 변환 정적 헬퍼.</summary>
public static class EnemyIntentInfo
{
    private const string BeneficialEffectNameKey = "INTENT_BENEFICIAL_EFFECT_NAME";
    private const string BeneficialEffectDescKey = "INTENT_BENEFICIAL_EFFECT_DESC";

    public static bool IsBeneficialBuffIntent(EEnemyIntentType type)
    {
        return type == EEnemyIntentType.BuffBlockOnPlayerManaGain ||
               type == EEnemyIntentType.BuffDamageOnPlayerDraw ||
               type == EEnemyIntentType.BuffInstallDisturbanceOnCardToggle;
    }

    // 이름 키: 의도 칸 위 제목("공격" 등). 키 표기는 프로젝트 컨벤션(KEYWORD_*_NAME)과 통일.
    private static string NameKey(EEnemyIntentType type) => type switch
    {
        EEnemyIntentType.Attack => "INTENT_ATTACK_NAME",
        EEnemyIntentType.GridLineAttack => "INTENT_GRID_LINE_ATTACK_NAME",
        EEnemyIntentType.Defend => "INTENT_DEFEND_NAME",
        EEnemyIntentType.InstallBlankCards => "INTENT_INSTALL_BLANK_NAME",
        EEnemyIntentType.InstallOnDisturbanceBlocks => "INTENT_INSTALL_DISTURBANCE_NAME",
        EEnemyIntentType.EraseInfo => "INTENT_ERASE_INFO_NAME",
        EEnemyIntentType.EraseCardKindOnly => "INTENT_ERASE_CARD_KIND_NAME",
        EEnemyIntentType.InstallHandCurse => "INTENT_INSTALL_HAND_CURSE_NAME",
        EEnemyIntentType.BuffBlockOnPlayerManaGain => "INTENT_BUFF_BLOCK_ON_MANA_NAME",
        EEnemyIntentType.BuffDamageOnPlayerDraw => "INTENT_BUFF_DAMAGE_ON_DRAW_NAME",
        EEnemyIntentType.BuffInstallDisturbanceOnCardToggle => "INTENT_BUFF_INSTALL_ON_TOGGLE_NAME",
        _ => "INTENT_UNKNOWN_NAME",
    };

    // 설명 키: 수치를 끼울 포맷 문자열. 컨벤션(KEYWORD_*_DESC)과 통일.
    private static string DescKey(EEnemyIntentType type) => type switch
    {
        EEnemyIntentType.Attack => "INTENT_ATTACK_DESC",
        EEnemyIntentType.GridLineAttack => "INTENT_GRID_LINE_ATTACK_DESC",
        EEnemyIntentType.Defend => "INTENT_DEFEND_DESC",
        EEnemyIntentType.InstallBlankCards => "INTENT_INSTALL_BLANK_DESC",
        EEnemyIntentType.InstallOnDisturbanceBlocks => "INTENT_INSTALL_DISTURBANCE_DESC",
        EEnemyIntentType.EraseInfo => "INTENT_ERASE_INFO_DESC",
        EEnemyIntentType.EraseCardKindOnly => "INTENT_ERASE_CARD_KIND_DESC",
        EEnemyIntentType.InstallHandCurse => "INTENT_INSTALL_HAND_CURSE_DESC",
        EEnemyIntentType.BuffBlockOnPlayerManaGain => "INTENT_BUFF_BLOCK_ON_MANA_DESC",
        EEnemyIntentType.BuffDamageOnPlayerDraw => "INTENT_BUFF_DAMAGE_ON_DRAW_DESC",
        EEnemyIntentType.BuffInstallDisturbanceOnCardToggle => "INTENT_BUFF_INSTALL_ON_TOGGLE_DESC",
        _ => "INTENT_UNKNOWN_DESC",
    };

    /// <summary>의도 1개를 이름+설명 텍스트로 변환. 공격은 다단 히트까지 인자로 전달.</summary>
    public static IntentDisplayText Resolve(in EnemyIntent intent)
    {
        string name = Localize(NameKey(intent.Type));

        string desc = intent.Type switch
        {
            EEnemyIntentType.Attack => Localize(
                DescKey(intent.Type), intent.Amount, intent.EffectiveHits),
            // 자를 라인 수(Amount)를 인자로 전달. Amount 0/1 이면 1로 표시(하위호환).
            EEnemyIntentType.GridLineAttack => Localize(
                DescKey(intent.Type), intent.Amount > 1 ? intent.Amount : 1),
            EEnemyIntentType.EraseInfo => Localize(DescKey(intent.Type)),
            EEnemyIntentType.EraseCardKindOnly => Localize(DescKey(intent.Type)),
            EEnemyIntentType.BuffInstallDisturbanceOnCardToggle => Localize(
                DescKey(intent.Type), intent.Amount, intent.EffectiveHits > 1 ? intent.EffectiveHits : 10),
            _ => Localize(DescKey(intent.Type), intent.Amount),
        };

        return new IntentDisplayText(name, desc);
    }

    public static IntentDisplayText ResolveForIntent(in EnemyIntent intent)
    {
        if (!IsBeneficialBuffIntent(intent.Type))
        {
            return Resolve(intent);
        }

        return new IntentDisplayText(
            Localize(BeneficialEffectNameKey),
            Localize(BeneficialEffectDescKey));
    }

    private static string Localize(string key)
    {
        if (string.IsNullOrEmpty(key)) return string.Empty;
        return LocalizationManager.HasInstance ? LocalizationManager.Instance.Get(key) : key;
    }

    private static string Localize(string key, params object[] args)
    {
        if (string.IsNullOrEmpty(key)) return string.Empty;
        return LocalizationManager.HasInstance ? LocalizationManager.Instance.Get(key, args) : key;
    }
}
