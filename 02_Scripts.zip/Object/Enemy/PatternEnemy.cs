// =================================================================
// [스크립트 목적]  기본 적 — SO 의도 패턴을 순서대로 순환 (현재 동작 그대로).
//                 Enemy 의 가장 단순한 구체 구현. 대부분의 일반 적에 사용.
// [의존 관계]      - Enemy(추상) / EnemyIntent
// [배치]           World 풀 프리팹. Enemy 계열 중 기본형.
// [설계 노트]      - DecideNextIntent 는 내부 카운터를 1씩 올리며 SO 패턴을 순환한다.
//                    (EnemyActor 의 기존 AdvanceIntent 순환과 동일한 결과)
// =================================================================

using System.Collections.Generic;

/// <summary>
/// SO 의도 패턴을 순서대로 반복하는 기본 적.
/// 첫 턴은 패턴 0번, 이후 턴마다 다음 인덱스로 순환한다 (Slay the Spire 의 단순 적 패턴).
/// </summary>
public sealed class PatternEnemy : Enemy
{
    // 현재 패턴 인덱스 (순환). Setup 시 첫 의도에서 0으로 시작.
    private int _patternIndex;

    protected override IReadOnlyList<EnemyIntent> DecideNextIntent(bool isFirst)
    {
        if (isFirst)
        {
            _patternIndex = 0;
        }
        else
        {
            _patternIndex++;
        }

        return GetPatternIntentTurn(_patternIndex);
    }
}