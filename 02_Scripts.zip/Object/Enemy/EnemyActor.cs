// =================================================================
// [스크립트 목적]  적 전투 액터 (IBattleActor). 체력·방어막 자체 관리 + 의도 패턴 보유.
//                 PlayerActor 와 대칭 구조. 외부 처치 통지 대신 OnDied 로 사망 발행.
// [주요 변수]      - _hp/_maxHp/_block : 체력·방어막
//                  - _data             : 적 정의 SO (의도 패턴 원천)
//                  - _intentIndex      : 현재 의도 인덱스 (순환)
// [의존 관계]      - IBattleActor : ICombatActor / EnemyDataSO / EnemyIntent
//                  - BattleManager 가 OnDied 구독해 승리 판정
//                  - SimpleEnemyHandler 가 이 액터로 턴 행동 수행
// [설계 노트]      - POCO (MonoBehaviour 아님): 로직만. 비주얼/위치는 3단계 EnemyView 가 담당
//                  - 방어막: 피해 우선 흡수, 자기 턴 시작 시 정리(소모형) — 여기선 ResetBlock 으로
//                  - HP/방어막/의도 변동 이벤트로 UI 분리 (PlayerActor 와 동일 패턴)
// =================================================================

using System;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// 적 액터의 동작 구현. 체력·방어막·피해/회복을 자체 관리하는 POCO.
/// 의도(Intent) 패턴을 SO 에서 받아 순환하며, 사망 시 OnDied 를 발행해
/// BattleManager 가 승리를 판정하게 한다 (외부 처치 통지 방식 대체).
/// 비주얼·월드 위치는 EnemyView(3단계)가 이벤트 구독으로 분리 담당한다.
/// </summary>
public sealed class EnemyActor : IBattleActor
{
    private readonly EnemyDataSO _data;

    private int _hp;
    private int _maxHp;
    private int _block;
    private int _intentIndex;
    private int _currentPhaseIndex;

    public int Hp => _hp;
    public int MaxHp => _maxHp;
    public int Block => _block;
    public bool IsAlive => _hp > 0;
    public int CurrentPhaseIndex => _currentPhaseIndex;
    public bool HasNextPhase => _data != null && _currentPhaseIndex + 1 < _data.PhaseCount;

    /// <summary>적 정의 데이터 (표시·비주얼 키 조회용).</summary>
    public EnemyDataSO Data => _data;

    public event Action OnDied;

    /// <summary>중간 페이즈 체력이 소진됐을 때 통지. 인자는 전환할 다음 페이즈 인덱스(0-based).</summary>
    public event Action<int> OnPhaseDepleted;

    /// <summary>체력 변동 통지 (HP바 UI). (현재값, 최대값)</summary>
    public event Action<int, int> OnHpChanged;

    /// <summary>피해 적용 통지. (요청 피해, HP 피해, 방어막 흡수량)</summary>
    public event Action<int, int, int> OnDamageTaken;

    /// <summary>방어막 변동 통지.</summary>
    public event Action<int> OnBlockChanged;

    /// <summary>의도 변경 통지 (Intent UI 갱신). 새 현재 의도 묶음을 전달.</summary>
    public event Action<IReadOnlyList<EnemyIntent>> OnIntentChanged;

    public EnemyActor(EnemyDataSO data)
    {
        _data = data;
    }

    /// <summary>현재(다음 수행) 의도 묶음. SetIntents 로 주입되며, 미주입 시 SO 패턴/폴백을 사용.</summary>
    public IReadOnlyList<EnemyIntent> CurrentIntents =>
        _hasInjectedIntents ? _injectedIntents
        : (_data != null ? _data.GetPhaseIntentTurn(_currentPhaseIndex, _intentIndex).Intents ?? Array.Empty<EnemyIntent>()
                         : Array.Empty<EnemyIntent>());

    // 외부(Enemy 계층)가 주입한 의도 묶음. 패턴 결정 정책을 Enemy 가 담당하기 위함.
    private IReadOnlyList<EnemyIntent> _injectedIntents = Array.Empty<EnemyIntent>();
    private bool _hasInjectedIntents;

    /// <summary>
    /// 다음 의도 묶음을 외부에서 주입 (Enemy 의 DecideNextIntent 결과).
    /// 의도 결정 정책(순환/조건부/랜덤)은 Enemy 계층이 담당하고, Actor 는 보관·통지만 한다.
    /// </summary>
    public void SetIntents(IReadOnlyList<EnemyIntent> intents)
    {
        _injectedIntents = intents ?? Array.Empty<EnemyIntent>();
        _hasInjectedIntents = true;
        OnIntentChanged?.Invoke(CurrentIntents);
    }

    // ── IBattleActor ────────────────────────────────────────

    /// <summary>전투 시작 초기화. SO 체력으로 채우고 의도 인덱스 리셋.</summary>
    public void Setup(int maxHp)
    {
        // SO 가 있으면 SO 체력 우선, 인자는 폴백 (BattleManager 는 플레이어 기준 호출).
        _currentPhaseIndex = 0;
        _maxHp = _data != null ? _data.GetPhaseMaxHp(_currentPhaseIndex) : Mathf.Max(1, maxHp);
        _hp = _maxHp;
        _block = 0;
        _intentIndex = 0;
        _hasInjectedIntents = false; // 주입 의도 리셋 — 전투 시작 시 Enemy 가 다시 결정

        OnHpChanged?.Invoke(_hp, _maxHp);
        OnBlockChanged?.Invoke(_block);
        OnIntentChanged?.Invoke(CurrentIntents);
    }

    /// <summary>현재 체력 지정 오버로드 — 적은 항상 풀피이므로 currentHp 무시.</summary>
    public void Setup(int maxHp, int currentHp)
    {
        Setup(maxHp); // 적은 SO 체력으로 풀피 시작 (currentHp 무시)
    }

    /// <summary>턴 경계 방어막 정리 (소모형 블록).</summary>
    public void ResetBlock()
    {
        if (_block == 0) return;
        _block = 0;
        OnBlockChanged?.Invoke(_block);
    }

    /// <summary>현재 방어막을 지정량만큼 직접 소비한다 (피해 흡수와 무관).</summary>
    public void ConsumeBlock(int amount)
    {
        amount = Mathf.Clamp(amount, 0, _block);
        if (amount == 0) return;
        _block -= amount;
        OnBlockChanged?.Invoke(_block);
    }

    // ── ICombatActor ────────────────────────────────────────

    /// <summary>피해 적용. 방어막이 먼저 흡수하고 초과분만 체력 차감. 0 도달 시 OnDied.</summary>
    public void TakeDamage(int amount)
    {
        if (amount <= 0 || !IsAlive)
        {
#if UNITY_EDITOR || DEVELOPMENT_BUILD
            Debug.LogWarning($"[EnemyActor] TakeDamage 무시 — amount={amount}, IsAlive={IsAlive} (HP {_hp}/{_maxHp})");
#endif
            return;
        }

        int before = _hp;
        int blockAbsorbed = 0;
        int remaining = amount;

        // 방어막 우선 흡수.
        if (_block > 0)
        {
            int absorbed = Mathf.Min(_block, remaining);
            _block -= absorbed;
            remaining -= absorbed;
            blockAbsorbed = absorbed;
            OnBlockChanged?.Invoke(_block);
        }

        if (remaining > 0)
        {
            _hp = Mathf.Max(0, _hp - remaining);
            OnHpChanged?.Invoke(_hp, _maxHp);
        }

        int hpDamage = before - _hp;
        if (hpDamage > 0 || blockAbsorbed > 0)
        {
            OnDamageTaken?.Invoke(amount, hpDamage, blockAbsorbed);
        }

#if UNITY_EDITOR || DEVELOPMENT_BUILD
        Debug.Log($"[EnemyActor] TakeDamage {amount} → HP {before}→{_hp}/{_maxHp} (block {_block})");
#endif

        if (_hp == 0)
        {
            if (HasNextPhase)
            {
                OnPhaseDepleted?.Invoke(_currentPhaseIndex + 1);
            }
            else
            {
                OnDied?.Invoke();
            }
        }
    }

    /// <summary>다음 보스 페이즈로 전환하고 새 최대 체력과 첫 의도로 초기화한다.</summary>
    public bool TryAdvancePhase()
    {
        if (!HasNextPhase) return false;

        _currentPhaseIndex++;
        _maxHp = _data.GetPhaseMaxHp(_currentPhaseIndex);
        _hp = _maxHp;
        _block = 0;
        _intentIndex = 0;
        _hasInjectedIntents = false;

        OnHpChanged?.Invoke(_hp, _maxHp);
        OnBlockChanged?.Invoke(_block);
        OnIntentChanged?.Invoke(CurrentIntents);
        return true;
    }

    /// <summary>방어막 획득 (적의 Defend 의도).</summary>
    public void GainBlock(int amount)
    {
        if (amount <= 0) return;
        _block += amount;
        OnBlockChanged?.Invoke(_block);
    }

    /// <summary>회복. 최대 체력 한도.</summary>
    public void Heal(int amount)
    {
        if (amount <= 0 || !IsAlive) return;
        _hp = Mathf.Min(_maxHp, _hp + amount);
        OnHpChanged?.Invoke(_hp, _maxHp);
    }

    // ── 의도 진행 ───────────────────────────────────────────

    /// <summary>다음 의도로 전진 (순환). 의도 변경 통지.</summary>
    public void AdvanceIntent()
    {
        int count = _data != null ? _data.GetPhaseIntentCount(_currentPhaseIndex) : 0;
        if (count == 0) return;

        _intentIndex = (_intentIndex + 1) % count;
        OnIntentChanged?.Invoke(CurrentIntents);
    }
}
