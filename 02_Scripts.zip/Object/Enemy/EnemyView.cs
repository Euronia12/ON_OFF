// =================================================================
// [스크립트 목적]  적 비주얼 표현체. 월드 위치(ICombatTarget) 제공 + 피격 연출 훅.
//                 EnemyActor(로직)와 분리 — 위치/연출만 담당.
// [주요 변수]      - _anchor    : 투사체 도착점·이펙트 위치 (없으면 자기 Transform)
//                  - _spriteRoot: 피격 흔들림 대상 (선택)
// [의존 관계]      - ICombatTarget / EnemyActor (이벤트 구독)
//                  - BattleVfxPresenter 가 AnchorTransform 참조
// [배치]           전투 씬의 적 위치에 배치 (또는 Addressable 로 생성)
// [설계 노트]      - 위치 제공이 핵심. 피격 흔들림은 가벼운 부가 연출 (DOTween)
//                  - 액터 사망 시 비주얼 처리 (페이드/숨김) 훅 제공
// =================================================================

using System;
using System.Threading;
using Cysharp.Threading.Tasks;
using DG.Tweening;
using UnityEngine;

/// <summary>
/// 적의 씬 비주얼. 투사체·이펙트가 향할 월드 위치를 제공하고,
/// EnemyActor 의 피격·사망 이벤트에 가벼운 연출(흔들림·숨김)로 반응한다.
/// 전투 로직은 EnemyActor 가, 위치·연출은 이 컴포넌트가 담당해 분리한다.
/// </summary>
public sealed class EnemyView : MonoBehaviour, ICombatTarget
{
    private static readonly int FadeAmountId = Shader.PropertyToID("_FadeAmount");
    private static readonly int PixelateSizeId = Shader.PropertyToID("_PixelateSize");
    private const string DeathMaterialResourcePath = "EnemyDeathDissolve";

    [Header("연출 기준점")]
    [Tooltip("투사체 도착·이펙트 재생 위치. 비우면 자기 Transform 사용")]
    [SerializeField] private Transform _anchor;

    [Header("피격 연출 (선택)")]
    [Tooltip("피격 시 흔들 대상 (스프라이트 루트). 비우면 흔들림 생략")]
    [SerializeField] private Transform _spriteRoot;

    [Tooltip("피격 흔들림 세기")]
    [SerializeField] private float _hitShakeStrength = 0.2f;

    [Tooltip("피격 흔들림 시간(초)")]
    [SerializeField] private float _hitShakeDuration = 0.2f;

    [Header("공격 연출 (선택)")]
    [Tooltip("공격 시 좌우로 움직일 대상. 비우면 피격 흔들 대상(_spriteRoot)을 사용")]
    [SerializeField] private Transform _attackRoot;

    [Tooltip("공격 시 옆으로 밀리는 거리")]
    [SerializeField] private float _attackMoveX = 0.35f;

    [Tooltip("공격 방향으로 움직이는 시간(초)")]
    [SerializeField] private float _attackForwardDuration = 0.08f;

    [Tooltip("반대 방향으로 되튕기는 시간(초)")]
    [SerializeField] private float _attackBackDuration = 0.08f;

    [Tooltip("기준 위치로 돌아오는 시간(초)")]
    [SerializeField] private float _attackReturnDuration = 0.08f;

    [Header("사망 연출")]
    [Tooltip("사망 소멸 시간(초)")]
    [SerializeField, Min(0.01f)] private float _deathDuration = 3f;

    [Tooltip("사망 소멸 픽셀 크기")]
    [SerializeField, Range(4f, 512f)] private float _deathPixelateSize = 32f;

    public Transform AnchorTransform => _anchor != null ? _anchor : transform;

    /// <summary>사망 소멸 연출 총 재생 시간(초). 전투 BGM 페이드아웃 등 외부 동기화용.</summary>
    public float DeathMotionDuration => Mathf.Max(0.01f, _deathDuration) * 1.4f;

    private EnemyActor _enemy;
    private Tween _hitTween;
    private Tween _attackTween;
    private Tween _deathTween;
    private SpriteRenderer _deathSpriteRenderer;
    private Material _originalSpriteMaterial;
    private Material _deathMaterial;
    private UniTaskCompletionSource _deathCompletion;
    private Vector3 _spriteRootBaseLocalPosition;
    private bool _hasSpriteRootBaseLocalPosition;
    private Vector3 _attackRootBaseLocalPosition;
    private bool _hasAttackRootBaseLocalPosition;

    /// <summary>적 액터 바인딩 — HP 변동(피격)·사망 연출 구독.</summary>
    public void Bind(EnemyActor enemy)
    {
        Unbind();
        gameObject.SetActive(true);
        _enemy = enemy;
        if (enemy == null) return;

        _lastHp = enemy.Hp;
        enemy.OnHpChanged += HandleHpChanged;
    }

    private void Awake()
    {
        CaptureSpriteRootBasePosition();
        CaptureAttackRootBasePosition();
    }

    public void Unbind()
    {
        StopHitTweenAndRestore();
        StopAttackTweenAndRestore();
        StopDeathTween();

        if (_enemy != null)
        {
            _enemy.OnHpChanged -= HandleHpChanged;
            _enemy = null;
        }
        _lastHp = -1;
    }

    private int _lastHp = -1;

    private void HandleHpChanged(int current, int max)
    {
        // 체력이 줄었을 때만 피격 흔들림 (회복은 제외).
        if (_lastHp >= 0 && current < _lastHp)
        {
            PlayHitShake();
        }
        _lastHp = current;
    }

    private void PlayHitShake()
    {
        if (_spriteRoot == null) return;
        CaptureSpriteRootBasePosition();
        StopHitTweenAndRestore();
        _hitTween = _spriteRoot.DOShakePosition(_hitShakeDuration, _hitShakeStrength);
    }

    public async UniTask PlayAttackMotionAsync(CancellationToken token)
    {
        Transform target = AttackRoot;
        if (target == null) return;

        CaptureAttackRootBasePosition();
        StopAttackTweenAndRestore();

        float forwardDuration = Mathf.Max(0.01f, _attackForwardDuration);
        float backDuration = Mathf.Max(0.01f, _attackBackDuration);
        float returnDuration = Mathf.Max(0.01f, _attackReturnDuration);
        float baseX = _attackRootBaseLocalPosition.x;

        _attackTween = DOTween.Sequence().SetTarget(target)
            .Append(target.DOLocalMoveX(baseX + _attackMoveX, forwardDuration).SetEase(Ease.OutQuad))
            .Append(target.DOLocalMoveX(baseX - _attackMoveX * 0.35f, backDuration).SetEase(Ease.InOutQuad))
            .Append(target.DOLocalMoveX(baseX, returnDuration).SetEase(Ease.OutQuad));

        try
        {
            await _attackTween.AsUniTask(token);
        }
        finally
        {
            StopAttackTweenAndRestore();
        }
    }

    public UniTask PlayDeathMotionAsync(CancellationToken token)
    {
        if (_deathCompletion != null)
            return _deathCompletion.Task.AttachExternalCancellation(token);

        StopHitTweenAndRestore();
        StopAttackTweenAndRestore();
        UniTaskCompletionSource completion = new UniTaskCompletionSource();
        _deathCompletion = completion;
        PlayDeathMotionInternalAsync(completion).Forget();
        return completion.Task.AttachExternalCancellation(token);
    }

    private async UniTaskVoid PlayDeathMotionInternalAsync(UniTaskCompletionSource completion)
    {
        bool completedNormally = false;
        try
        {
            _deathSpriteRenderer = GetComponentInChildren<SpriteRenderer>(includeInactive: true);
            Material source = Resources.Load<Material>(DeathMaterialResourcePath);
            if (_deathSpriteRenderer == null || source == null)
            {
                completedNormally = true;
                return;
            }

            _originalSpriteMaterial = _deathSpriteRenderer.sharedMaterial;
            _deathMaterial = new Material(source);
            _deathMaterial.EnableKeyword("FADE_ON");
            _deathMaterial.EnableKeyword("PIXELATE_ON");
            _deathMaterial.SetFloat(FadeAmountId, -0.1f);
            _deathMaterial.SetFloat(PixelateSizeId, _deathPixelateSize);
            _deathSpriteRenderer.material = _deathMaterial;

            float duration = Mathf.Max(0.01f, _deathDuration);
            const float firstPhaseRatio = 1f / 1.4f;
            _deathTween = DOTween.To(
                    () => 0f,
                    value =>
                    {
                        if (_deathMaterial == null) return;
                        float fade = value <= firstPhaseRatio
                            ? Mathf.Lerp(-0.1f, 0.5f, value / firstPhaseRatio)
                            : Mathf.Lerp(0.5f, 1f, (value - firstPhaseRatio) / (1f - firstPhaseRatio));
                        _deathMaterial.SetFloat(FadeAmountId, fade);
                    },
                    1f,
                    duration)
                .SetEase(Ease.Linear)
                .SetUpdate(true)
                .SetTarget(this);

            await _deathTween.AsUniTask();
            completedNormally = true;
        }
        catch (OperationCanceledException)
        {
            // View 해제·씬 파괴로 tween이 중단되는 것은 정상 종료다.
        }
        finally
        {
            FinishDeathMotion(completion, completedNormally);
        }
    }

    private void CaptureSpriteRootBasePosition()
    {
        if (_spriteRoot == null || _hasSpriteRootBaseLocalPosition) return;
        _spriteRootBaseLocalPosition = _spriteRoot.localPosition;
        _hasSpriteRootBaseLocalPosition = true;
    }

    private Transform AttackRoot => _attackRoot != null ? _attackRoot : _spriteRoot;

    private void CaptureAttackRootBasePosition()
    {
        Transform target = AttackRoot;
        if (target == null || _hasAttackRootBaseLocalPosition) return;
        _attackRootBaseLocalPosition = target.localPosition;
        _hasAttackRootBaseLocalPosition = true;
    }

    private void StopHitTweenAndRestore()
    {
        _hitTween?.Kill();
        _hitTween = null;

        if (_spriteRoot != null && _hasSpriteRootBaseLocalPosition)
        {
            _spriteRoot.localPosition = _spriteRootBaseLocalPosition;
        }
    }

    private void StopAttackTweenAndRestore()
    {
        _attackTween?.Kill();
        _attackTween = null;

        Transform target = AttackRoot;
        if (target != null && _hasAttackRootBaseLocalPosition)
        {
            target.localPosition = _attackRootBaseLocalPosition;
        }
    }

    private void StopDeathTween()
    {
        UniTaskCompletionSource completion = _deathCompletion;
        _deathCompletion = null;
        _deathTween?.Kill();
        _deathTween = null;

        RestoreDeathVisual();
        completion?.TrySetResult();
    }

    private void FinishDeathMotion(UniTaskCompletionSource completion, bool completedNormally)
    {
        if (!ReferenceEquals(_deathCompletion, completion)) return;

        _deathTween = null;
        if (completedNormally)
        {
            gameObject.SetActive(false);
        }

        _deathCompletion = null;
        RestoreDeathVisual();
        completion.TrySetResult();
    }

    private void RestoreDeathVisual()
    {
        if (_deathSpriteRenderer != null)
        {
            _deathSpriteRenderer.sharedMaterial = _originalSpriteMaterial;
            _deathSpriteRenderer = null;
            _originalSpriteMaterial = null;
        }

        if (_deathMaterial != null)
        {
            Destroy(_deathMaterial);
            _deathMaterial = null;
        }
    }

    private void OnDestroy()
    {
        StopHitTweenAndRestore();
        StopAttackTweenAndRestore();
        StopDeathTween();
        Unbind();
    }
}
