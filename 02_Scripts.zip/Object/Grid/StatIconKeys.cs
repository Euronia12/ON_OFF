// =================================================================
// [스크립트 목적]  EStatType → 아이콘 키 매핑 확장메서드
// [의존 관계]      - AtlasKeys.Common (CommonAtlas 키 레지스트리)
//                  - EStatType (CardEnums)
// [설계 노트]      - CommonAtlas 키(데이터)는 AtlasKeys 에, 매핑(로직)은 여기에 분리
//                  - TMP Sprite name 은 Atlas 와 다른 아이콘을 쓸 수 있어 여기서 별도로 관리
//                  - Extensions.cs 는 "범용 유틸·매니저 호출 금지" 원칙이라
//                    게임 도메인 매핑은 별도 파일로 둠
// =================================================================

/// <summary>
/// 스탯 타입을 CommonAtlas 아이콘 스프라이트 키로 변환한다.
/// 매핑 대상이 아닌 스탯(None·DirectionalDamageBonus 등)은 null 을 반환한다.
/// </summary>
public static class StatIconKeys
{
    public const string GridSlotTmpIconAttack  = "icon_attack";
    public const string GridSlotTmpIconBlock   = "icon_block";
    public const string GridSlotTmpIconHeal    = "icon_heal";
    public const string GridSlotTmpIconDraw    = "icon_draw";
    public const string GridSlotTmpIconEnergy  = "icon_energy";
    public const string GridSlotTmpIconCasting = "icon_casting";

    /// <summary>스탯 타입에 대응하는 CommonAtlas 아이콘 키. 매핑 없으면 null.</summary>
    public static string ToIconKey(this EStatType type)
    {
        return type switch
        {
            EStatType.Damage   => AtlasKeys.Common.ICON_ATTACK,
            EStatType.Block    => AtlasKeys.Common.ICON_BLOCK,
            EStatType.Heal     => AtlasKeys.Common.ICON_HEAL,
            EStatType.DrawCard => AtlasKeys.Common.ICON_DRAW,
            EStatType.Energy   => AtlasKeys.Common.ICON_ENERGY,
            _ => null,
        };
    }

    /// <summary>GridSlot TMP Sprite Asset 내부 name. 매핑 없으면 null.</summary>
    public static string ToGridSlotTmpIconName(this EStatType type)
    {
        return type switch
        {
            EStatType.Damage   => GridSlotTmpIconAttack,
            EStatType.Block    => GridSlotTmpIconBlock,
            EStatType.Heal     => GridSlotTmpIconHeal,
            EStatType.DrawCard => GridSlotTmpIconDraw,
            EStatType.Energy   => GridSlotTmpIconEnergy,
            _ => null,
        };
    }
}
