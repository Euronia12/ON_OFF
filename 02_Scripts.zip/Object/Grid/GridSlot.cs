// =================================================================
// [스크립트 목적]  월드 그리드 1칸의 비주얼. 점유/빈칸 표시, 카드 화살표,
//                 ON 강조, 배치 프리뷰 하이라이트, 방향 신호 펄스 표현.
// [주요 변수]      - _emptyVisual/_occupiedVisual : 칸 바닥 상태 비주얼
//                  - _highlightOverlay  : 드래그 호버 하이라이트(빈칸 한정)
//                  - _emptyVisual/_occupiedVisual : 현재 슬롯 상태에 맞는 범위 셰이더 대상
//                  - _cardIcon          : ON/OFF 상태에 따라 밝기 변경
//                  - _arrowUp/Down/Left/Right : 4방위 화살표 오브젝트
//                  - _signalPulse       : 신호 도달 시 1회 깜빡일 펄스(선택)
// [의존 관계]      - GridManager 가 Setup/AssignCard/ClearCard/하이라이트 호출
//                  - Card / ECardDirection
// [설계 노트]      - 하이라이트(호버)와 프리뷰(경로)를 분리: 호버는 빈칸만,
//                    프리뷰는 신호가 닿는 점유칸도 강조해야 하므로 별도 오버레이.
//                  - 방향선(카드↔카드) 트레일 연출은 IChainPresenter 구현체(팀원) 담당.
//                    슬롯은 자기 칸에 도달한 신호의 '도착 펄스'만 옵션으로 표현.
// =================================================================

using System;
using System.Collections;
using System.Collections.Generic;
using System.Threading;
using Cysharp.Threading.Tasks;
using DG.Tweening;
using TMPro;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Serialization;

[RequireComponent(typeof(BoxCollider))]
public sealed class GridSlot : MonoBehaviour, ILocalizable
{
    private const string DoubleArrowCardId = "Infinite_Archive";

    private static readonly Color TurnEndGeneratorOnColor = new Color32(0x86, 0x00, 0x00, 0xFF);
    private static readonly Color OccupiedVisualOffColor = new Color32(0x68, 0x68, 0x64, 0xFF);
    // 버프로 기본 수치보다 높아진 값의 글자 색 (팔레트 GreenLight #6EB870).
    // 카드 설명(CardDescriptionBuilder)의 증가 수치 색과 동일하게 유지한다.
    private static readonly Color BuffedStatColor = EUIColor.GreenLight.ToColor();
    private static readonly int BorderOnPropertyId = Shader.PropertyToID("_BorderOn");
    private static readonly int BorderColorPropertyId = Shader.PropertyToID("_BorderColor");
    private const string ActiveIconColorTag = "#FFFFFF";

    [Header("셀 바닥 비주얼")]
    [Tooltip("빈 칸일 때 켜지는 비주얼")]
    [SerializeField] private GameObject _emptyVisual;

    [Tooltip("카드가 점유 중일 때 켜지는 비주얼")]
    [SerializeField] private GameObject _occupiedVisual;

    [Tooltip("드래그 호버 하이라이트. 빈 칸에서만 켜진다(배치 가능 표시)")]
    [SerializeField] private GameObject _highlightOverlay;

    [Tooltip("배치/효과 범위 테두리를 표시하는 BorderVis 오브젝트")]
    [FormerlySerializedAs("_borderOverlay")]
    [SerializeField] private GameObject _borderVis;

    [Tooltip("기본 배치/효과 범위 프리뷰 테두리 색상")]
    [SerializeField] private Color _previewColor = Color.yellow;

    [Tooltip("이번 턴 보존 선택한 카드 테두리 색상 (시안)")]
    [SerializeField] private Color _preserveColor = new Color(0.35f, 0.95f, 1f, 1f);

    [Tooltip("효과로 이미 보존된(보존 수치 보유) 카드 구분용 연한 파랑 테두리 색상")]
    [SerializeField] private Color _effectPreservedColor = new Color(0.6f, 0.8f, 1f, 1f);

    [Header("슬롯 렌더링 순서")]
    [SerializeField] private SortingGroup _sortingGroup;

    private SpriteRenderer _borderRenderer;
    private MaterialPropertyBlock _borderPropertyBlock;

    [Header("점유 카드 비주얼")]
    [Tooltip("카드 식별용 라벨(임시 디버그/팀원 비주얼 대체 전)")]
    [SerializeField] private TMP_Text _label;

    [SerializeField] private SpriteRenderer _cardIcon;
    [SerializeField] private GameObject _cardInfoRoot;
    [FormerlySerializedAs("_statRoot")]
    [SerializeField] private GameObject _infoRoot;
    [Tooltip("스탯 아이콘(TMP 스프라이트 태그)+수치 표기 텍스트")]
    [FormerlySerializedAs("_statText")]
    [SerializeField] private TMP_Text _infoText;


    [Tooltip("카드 ON(활성) 상태 비주얼 밝기 배율")]
    [Min(0f)]
    [SerializeField] private float _activatedBrightness = 1f;

    [Tooltip("카드 OFF(비활성) 상태 비주얼 밝기 배율")]
    [Min(0f)]
    [SerializeField] private float _deactivatedBrightness = 0.35f;

    [Tooltip("카드 토글 시 흔들림 연출 시간")]
    [Min(0f)]
    [SerializeField] private float _toggleFeedbackDuration = 0.18f;

    [Tooltip("도미노 토글: 신호 진행 방향으로 젖히는 최대 각도(도). 70 권장, 90 에 가까울수록 완전히 눕는 느낌")]
    [Range(0f, 90f)]
    [SerializeField] private float _toggleTiltAngle = 70f;

    [Header("그리드 파괴 연출")]
    [Tooltip("파괴될 때 슬롯이 먼저 위로 튀어 오르는 높이")]
    [Min(0f)]
    [SerializeField] private float _breakJumpHeight = 0.35f;

    [Tooltip("슬롯이 위로 튀어 오르는 데 걸리는 시간")]
    [Min(0f)]
    [SerializeField] private float _breakRiseDuration = 0.12f;

    [Tooltip("튀어 오른 슬롯이 원래 위치 아래로 떨어질 거리")]
    [Min(0f)]
    [SerializeField] private float _breakFallDistance = 8f;

    [Tooltip("슬롯이 화면 아래로 떨어지는 데 걸리는 시간")]
    [Min(0f)]
    [SerializeField] private float _breakFallDuration = 0.45f;

    [Tooltip("복구 시작 시 원래 크기에 곱할 배율")]
    [Range(0.01f, 1f)]
    [SerializeField] private float _restoreStartScale = 0.8f;

    [Tooltip("복구 스케일 팝 연출 시간")]
    [Min(0f)]
    [SerializeField] private float _restoreDuration = 0.18f;

    [Header("방향 화살표")]
    [SerializeField] private GameObject _arrowRoot;
    [SerializeField] private GameObject _arrowUp;
    [SerializeField] private GameObject _arrowDown;
    [SerializeField] private GameObject _arrowLeft;
    [SerializeField] private GameObject _arrowRight;
    [SerializeField] private GameObject _arrowUpLeft;
    [SerializeField] private GameObject _arrowUpRight;
    [SerializeField] private GameObject _arrowDownLeft;
    [SerializeField] private GameObject _arrowDownRight;

    [Header("2칸 화살표 표시")]
    [Tooltip("2칸 화살표 카드의 위쪽 복제 화살표")]
    [SerializeField] private GameObject _doubleArrowUp;

    [Tooltip("2칸 화살표 카드의 아래쪽 복제 화살표")]
    [SerializeField] private GameObject _doubleArrowDown;

    [Tooltip("2칸 화살표 카드의 왼쪽 복제 화살표")]
    [SerializeField] private GameObject _doubleArrowLeft;

    [Tooltip("2칸 화살표 카드의 오른쪽 복제 화살표")]
    [SerializeField] private GameObject _doubleArrowRight;

    [Tooltip("기본 화살표 색")]
    [SerializeField] private Color _defaultArrowColor = Color.white;

    [Tooltip("스킬로 임시 추가된 화살표 색")]
    [SerializeField] private Color _passiveArrowColor = Color.cyan;

    [Header("신호 도착 펄스 (선택)")]
    [Tooltip("방향 신호가 이 칸에 도달했을 때 1회 켜질 펄스 오브젝트. 없으면 생략")]
    [SerializeField] private GameObject _signalPulse;

    public Vector2Int Position { get; private set; }
    public Card OccupiedCard { get; private set; }
    public bool IsEmpty => OccupiedCard == null;
    public bool IsBroken { get; private set; }
    public bool IsUsable => !IsBroken;
    private Coroutine _toggleFeedbackRoutine;
    private CastingEffect _castingEffect;
    private PoolableMonoBehaviour _totemAura;
    private int _visualVersion;
    private bool _isActivated;
    private bool _showDoubleArrows;
    private bool _visualColorsCached;
    private GridManager _gridManager;
    private readonly List<SpriteRenderer> _cardRenderers = new();
    private readonly List<Color> _cardRendererBaseColors = new();
    private readonly List<TMP_Text> _cardTexts = new();
    private readonly List<Color> _cardTextBaseColors = new();
    private Vector3 _restingLocalPosition;
    private Vector3 _restingLocalScale;

    public void Setup(Vector2Int position, int sortingIndex, GridManager gridManager)
    {
        ApplyLocalizedFonts();
        _gridManager = gridManager;
        _restingLocalPosition = transform.localPosition;
        _restingLocalScale = transform.localScale;
        if (IsBroken)
        {
            RestoreBrokenImmediate();
        }
        if (_sortingGroup == null)
            TryGetComponent(out _sortingGroup);
        if (_sortingGroup != null)
            _sortingGroup.sortingOrder = sortingIndex;

        EnsureRuntimeCardUi();
        CacheCardVisualColors();
        CacheBorderRenderers();
        Position = position;
        OccupiedCard = null;
        name = $"Slot_{position.x}_{position.y}";
        SetHighlight(false);
        SetPreview(false);
        SetSignalPulse(false);
        ResetCardVisual();
        SetCardInfoHidden(_gridManager != null && _gridManager.IsCardInfoHidden);
        RefreshVisual();
    }

    /// <summary>슬롯을 위로 튀긴 뒤 아래로 낙하시켜 한 턴간 비활성화한다.</summary>
    public async UniTask PlayBreakAsync(CancellationToken token)
    {
        if (IsBroken) return;

        IsBroken = true;
        DOTween.Kill(transform);
        transform.localPosition = _restingLocalPosition;
        transform.localScale = _restingLocalScale;

        Sequence sequence = DOTween.Sequence().SetTarget(transform)
            .Append(transform.DOLocalMoveY(
                _restingLocalPosition.y + _breakJumpHeight,
                _breakRiseDuration).SetEase(Ease.OutQuad))
            .Append(transform.DOLocalMoveY(
                _restingLocalPosition.y - _breakFallDistance,
                _breakFallDuration).SetEase(Ease.InQuad));

        try
        {
            await sequence.AsUniTask(token);
            if (this == null) return;

            token.ThrowIfCancellationRequested();

            if (IsBroken)
            {
                transform.localPosition = _restingLocalPosition;
                transform.localScale = _restingLocalScale;
                gameObject.SetActive(false);
            }
        }
        catch (OperationCanceledException)
        {
            if (this == null) return;
            RestoreBrokenImmediate();
            throw;
        }
    }

    /// <summary>파괴 슬롯을 활성화하고 원래 크기로 짧게 팝 복구한다.</summary>
    public async UniTask RestoreBrokenAsync(CancellationToken token)
    {
        if (!IsBroken) return;

        DOTween.Kill(transform);
        IsBroken = false;
        transform.localPosition = _restingLocalPosition;
        transform.localScale = _restingLocalScale * _restoreStartScale;
        gameObject.SetActive(true);

        Tween tween = transform.DOScale(_restingLocalScale, _restoreDuration)
            .SetEase(Ease.OutBack);
        try
        {
            await tween.AsUniTask(token);
            if (this == null) return;

            token.ThrowIfCancellationRequested();
        }
        catch (OperationCanceledException)
        {
            if (this == null) return;
            RestoreBrokenImmediate();
            throw;
        }
        finally
        {
            if (this != null)
            {
                transform.localScale = _restingLocalScale;
            }
        }
    }

    /// <summary>전투 종료·재구성 시 트윈 없이 즉시 원상 복구한다.</summary>
    public void RestoreBrokenImmediate()
    {
        if (this == null) return;

        DOTween.Kill(transform);
        bool wasBroken = IsBroken;
        IsBroken = false;
        transform.localPosition = _restingLocalPosition;
        transform.localScale = _restingLocalScale;
        if (wasBroken && !gameObject.activeSelf)
        {
            gameObject.SetActive(true);
        }
    }

    public void AssignCard(Card card)
    {
        UnbindCardState();
        OccupiedCard = card;
        _showDoubleArrows = card != null && card.CardId == DoubleArrowCardId;
        _visualVersion++;

        if (_label != null)
            _label.text = card != null ? ResolveName(card) : string.Empty;

        if (card != null)
        {
            card.Stats.OnChanged += RefreshStats;
            _castingEffect = FindCastingEffect(card);
            RefreshStats();
            LoadCardIconAsync(card, _visualVersion).Forget();
        }

        SetActivated(false);

        ECardDirection dirs = (card != null && card.Arrow != null)
            ? card.Arrow.Current
            : ECardDirection.None;

#if UNITY_EDITOR || DEVELOPMENT_BUILD
        // 화살표 미표시 원인 진단 (둘 중 어느 문제인지 즉시 구분).
        if (card != null)
        {
            if (dirs == ECardDirection.None)
            {
                Debug.LogWarning($"[GridSlot] '{card.CardId}' 화살표 방향이 None 입니다. " +
                    "CardDataSO 의 BaseArrow(Mode/FixedDirs)를 확인하세요. " +
                    "(Fixed 모드인데 FixedDirs 가 None 이면 화살표가 표시되지 않습니다)");
            }
            else if (!HasVisualForAnyDirection(dirs))
            {
                Debug.LogError($"[GridSlot] '{name}' 에 '{dirs}' 방향 비주얼이 연결되지 않았습니다. " +
                    "GridSlot 프리팹의 해당 _arrow 필드를 연결하세요.");
            }
        }
#endif

        SetHighlight(false);
        SetPreview(false);
        RefreshVisual();
        ShowArrows(dirs);
    }

    public void ClearCard()
    {
        UnbindCardState();
        _visualVersion++;
        OccupiedCard = null;
        _showDoubleArrows = false;
        ResetCardVisual();
        SetPreview(false);
        SetSignalPulse(false);
        RefreshVisual();
    }

    public void SetActivated(bool activated)
    {
        _isActivated = activated;

        RefreshCardVisualBrightness();
        RefreshStats();

        RefreshTotemAura(activated);
    }

    /// <summary>카드 정보와 화살표 렌더링만 숨긴다. 카드 상태와 슬롯 입력은 유지된다.</summary>
    /// <param name="hidden">true 면 숨김.</param>
    /// <param name="keepArrow">true 면 카드 종류(이름/스탯)만 숨기고 방향 화살표는 그대로 표시.</param>
    public void SetCardInfoHidden(bool hidden, bool keepArrow = false)
    {
        bool visible = !hidden;
        if (_cardInfoRoot != null && _cardInfoRoot.activeSelf != visible)
            _cardInfoRoot.SetActive(visible);

        // 화살표는 keepArrow 면 항상 켜둔다(숨김 대상에서 제외). 원복 시엔 정상적으로 다시 표시.
        bool arrowVisible = visible || keepArrow;
        if (_arrowRoot != null && _arrowRoot.activeSelf != arrowVisible)
            _arrowRoot.SetActive(arrowVisible);
    }

    /// <summary>카드가 토글될 때 카드 비주얼을 1회 흔든다.</summary>
    public void PlayToggleFeedback()
    {
        Transform target = GetCardVisualTransform();
        if (target == null || _toggleFeedbackDuration <= 0f) return;

        if (_toggleFeedbackRoutine != null)
        {
            StopCoroutine(_toggleFeedbackRoutine);
            ResetToggleFeedback(target);
        }

        _toggleFeedbackRoutine = StartCoroutine(PlayToggleFeedback(
            BattleSpeedUtility.ScaleDuration(_toggleFeedbackDuration),
            target));
    }

    /// <summary>카드 토글 피드백을 재생하고 완료까지 기다린다. (방향 없음 = 기존 흔들림)</summary>
    public async UniTask PlayToggleFeedbackAsync(CancellationToken token)
    {
        await PlayToggleFeedbackAsync(ECardDirection.None, token);
    }

    /// <summary>카드 토글 피드백 재생 + 대기. fromDirection 이 8방향 중 하나면
    /// 그 진행 방향으로 도미노처럼 젖혔다 복귀하고, None 이면 기존 흔들림을 쓴다.</summary>
    public async UniTask PlayToggleFeedbackAsync(ECardDirection fromDirection, CancellationToken token)
    {
        await PlayToggleFeedbackAsync(fromDirection, 1f, 0f, token);
    }

    /// <summary>토글 피드백을 체인별 배속으로 재생한다.</summary>
    public async UniTask PlayToggleFeedbackAsync(
        ECardDirection fromDirection,
        float visualSpeedMultiplier,
        float minimumDuration,
        CancellationToken token)
    {
        Transform target = GetCardVisualTransform();
        if (target == null || _toggleFeedbackDuration <= 0f) return;

        if (_toggleFeedbackRoutine != null)
        {
            StopCoroutine(_toggleFeedbackRoutine);
            _toggleFeedbackRoutine = null;
            ResetToggleFeedback(target);
        }

        if (fromDirection == ECardDirection.None)
        {
            await PlayToggleFeedbackAsync(
                BattleSpeedUtility.ScaleDuration(_toggleFeedbackDuration, visualSpeedMultiplier, minimumDuration),
                target,
                token);
            return;
        }

        await PlayDominoFeedbackAsync(
            BattleSpeedUtility.ScaleDuration(_toggleFeedbackDuration, visualSpeedMultiplier, minimumDuration),
            target,
            fromDirection,
            token);
    }

    private IEnumerator PlayToggleFeedback(float duration, Transform target)
    {
        if (target == null) yield break;

        float elapsed = 0f;
        float angle = UnityEngine.Random.value > 0.5f ? 10f : -10f;

        while (elapsed < duration)
        {
            float t = elapsed / duration;
            float wiggle = Mathf.Sin(t * Mathf.PI * 5f) * (1f - t);
            float punch = Mathf.Sin(t * Mathf.PI);

            target.localRotation = Quaternion.Euler(0f, 0f, wiggle * angle);
            target.localScale = new Vector3(1f + 0.08f * punch, 1f - 0.08f * punch, 1f);

            elapsed += Time.deltaTime;
            yield return null;
        }

        ResetToggleFeedback(target);
        _toggleFeedbackRoutine = null;
    }

    private async UniTask PlayToggleFeedbackAsync(float duration, Transform target, CancellationToken token)
    {
        if (target == null) return;

        float elapsed = 0f;
        float angle = UnityEngine.Random.value > 0.5f ? 10f : -10f;

        try
        {
            while (elapsed < duration)
            {
                token.ThrowIfCancellationRequested();

                float t = elapsed / duration;
                float wiggle = Mathf.Sin(t * Mathf.PI * 5f) * (1f - t);
                float punch = Mathf.Sin(t * Mathf.PI);

                target.localRotation = Quaternion.Euler(0f, 0f, wiggle * angle);
                target.localScale = new Vector3(1f + 0.08f * punch, 1f - 0.08f * punch, 1f);

                elapsed += Time.deltaTime;
                await UniTask.Yield(PlayerLoopTiming.Update, token);
            }
        }
        finally
        {
            if (target != null)
            {
                ResetToggleFeedback(target);
            }
        }
    }

    /// <summary>
    /// 도미노 토글: 신호 진행 방향을 회전축으로 삼아 카드를 _toggleTiltAngle 까지 젖혔다 복귀시킨다.
    /// 좌우 진행=세로축(Y) 회전, 상하 진행=가로축(X) 회전, 대각선=두 축 합성.
    /// 끝까지 넘기지 않고 "쓰러지는 시늉"만 — 절반 지점에서 최대로 젖히고 되돌아온다.
    /// </summary>
    private async UniTask PlayDominoFeedbackAsync(
        float duration, Transform target, ECardDirection fromDirection, CancellationToken token)
    {
        if (target == null) return;

        Vector3 axis = TiltAxisFor(fromDirection);
        if (axis == Vector3.zero)
        {
            // 방향 해석 실패 시 기존 흔들림으로 폴백.
            await PlayToggleFeedbackAsync(duration, target, token);
            return;
        }

        float elapsed = 0f;
        try
        {
            while (elapsed < duration)
            {
                token.ThrowIfCancellationRequested();

                float t = elapsed / duration;
                // 0→1→0 (절반에서 최대로 젖히고 복귀). Sin(t·π) 로 부드럽게.
                float tilt = Mathf.Sin(t * Mathf.PI) * _toggleTiltAngle;
                float punch = Mathf.Sin(t * Mathf.PI);

                target.localRotation = Quaternion.AngleAxis(tilt, axis);
                target.localScale = new Vector3(1f + 0.06f * punch, 1f - 0.06f * punch, 1f);

                elapsed += Time.deltaTime;
                await UniTask.Yield(PlayerLoopTiming.Update, token);
            }
        }
        finally
        {
            if (target != null)
            {
                ResetToggleFeedback(target);
            }
        }
    }

    /// <summary>
    /// 신호 진행 방향 → 카드를 그 방향으로 쓰러뜨릴 회전축(로컬). 8방향 지원.
    /// 오른쪽 진행이면 카드 오른쪽 모서리가 화면 안쪽으로 넘어가도록 +Y 축을 돌린다.
    /// 대각선은 두 축을 합쳐 정규화하므로 사선으로 쓰러진다.
    /// </summary>
    private static Vector3 TiltAxisFor(ECardDirection dir)
    {
        // 진행 방향의 (dx, dy). 회전축은 진행 방향에 수직: 가로 이동=세로축, 세로 이동=가로축.
        float dx = 0f, dy = 0f;
        if ((dir & ECardDirection.Right) != 0) dx += 1f;
        if ((dir & ECardDirection.Left) != 0) dx -= 1f;
        if ((dir & ECardDirection.Up) != 0) dy += 1f;
        if ((dir & ECardDirection.Down) != 0) dy -= 1f;

        // 대각선 비트(UpRight 등)도 분해.
        if ((dir & ECardDirection.UpRight) != 0) { dx += 1f; dy += 1f; }
        if ((dir & ECardDirection.UpLeft) != 0) { dx -= 1f; dy += 1f; }
        if ((dir & ECardDirection.DownRight) != 0) { dx += 1f; dy -= 1f; }
        if ((dir & ECardDirection.DownLeft) != 0) { dx -= 1f; dy -= 1f; }

        if (dx == 0f && dy == 0f) return Vector3.zero;

        // 진행 방향 (dx,dy) 으로 "넘어지게" 하려면 그에 수직인 축으로 회전:
        // 오른쪽(+x) 진행 → +y 축 / 위(+y) 진행 → -x 축. => axis = (-dy, dx, 0).
        return new Vector3(-dy, dx, 0f).normalized;
    }

    public void ShowArrows(ECardDirection directions)
    {
        ShowArrows(directions, ECardDirection.None);
    }

    /// <summary>
    /// 화살표 표시. highlightDirs 에 포함된 방향만 패시브 강조색으로 칠한다.
    /// (화살표 "추가"로 생긴 방향만 강조 — 회전·기본 방향은 기본색)
    /// </summary>
    public void ShowArrows(ECardDirection directions, ECardDirection highlightDirs)
    {
        SetArrow(_arrowUp, (directions & ECardDirection.Up) != 0, (highlightDirs & ECardDirection.Up) != 0);
        SetArrow(_arrowDown, (directions & ECardDirection.Down) != 0, (highlightDirs & ECardDirection.Down) != 0);
        SetArrow(_arrowLeft, (directions & ECardDirection.Left) != 0, (highlightDirs & ECardDirection.Left) != 0);
        SetArrow(_arrowRight, (directions & ECardDirection.Right) != 0, (highlightDirs & ECardDirection.Right) != 0);
        SetArrow(_arrowUpLeft, (directions & ECardDirection.UpLeft) != 0, (highlightDirs & ECardDirection.UpLeft) != 0);
        SetArrow(_arrowUpRight, (directions & ECardDirection.UpRight) != 0, (highlightDirs & ECardDirection.UpRight) != 0);
        SetArrow(_arrowDownLeft, (directions & ECardDirection.DownLeft) != 0, (highlightDirs & ECardDirection.DownLeft) != 0);
        SetArrow(_arrowDownRight, (directions & ECardDirection.DownRight) != 0, (highlightDirs & ECardDirection.DownRight) != 0);
        SetArrow(_doubleArrowUp, _showDoubleArrows && (directions & ECardDirection.Up) != 0, (highlightDirs & ECardDirection.Up) != 0);
        SetArrow(_doubleArrowDown, _showDoubleArrows && (directions & ECardDirection.Down) != 0, (highlightDirs & ECardDirection.Down) != 0);
        SetArrow(_doubleArrowLeft, _showDoubleArrows && (directions & ECardDirection.Left) != 0, (highlightDirs & ECardDirection.Left) != 0);
        SetArrow(_doubleArrowRight, _showDoubleArrows && (directions & ECardDirection.Right) != 0, (highlightDirs & ECardDirection.Right) != 0);
    }

    /// <summary>드래그 호버 하이라이트. 빈 칸에서만 켜진다(배치 가능 표시).</summary>
    public void SetHighlight(bool highlight)
    {
        if (_highlightOverlay != null && _highlightOverlay.activeSelf != highlight)
            _highlightOverlay.SetActive(highlight);
    }

    /// <summary>
    /// 배치 및 효과 범위를 슬롯 셰이더의 BorderOn으로 표시한다.
    /// 빈 슬롯은 BaseVis, 점유 슬롯은 OccupidVis 렌더러에 적용한다.
    /// </summary>
    public void SetPreview(bool preview)
    {
        SetPreview(preview, _previewColor);
    }

    private void EnsureRuntimeCardUi()
    {
        if (_label == null) return;

        if (_cardIcon == null)
        {
            GameObject iconObject = new GameObject("CardIcon");
            iconObject.transform.SetParent(_label.transform.parent, false);
            iconObject.transform.localPosition = new Vector3(0f, 0.08f, -0.01f);
            iconObject.transform.localScale = Vector3.one * 0.6f;
            _cardIcon = iconObject.AddComponent<SpriteRenderer>();
            _cardIcon.sortingLayerName = "FrontEffect";
            _cardIcon.enabled = false;
        }

        if (_infoText == null)
            _infoText = CreateRuntimeText("InfoText", new Vector3(0f, -0.3f, -0.02f));

        _infoRoot ??= _infoText != null ? _infoText.gameObject : null;
    }

    private TMP_Text CreateRuntimeText(string objectName, Vector3 localPosition)
    {
        TMP_Text clone = Instantiate(_label, _label.transform.parent);
        LocalizedFontUtility.ApplyCurrentFont(clone);
        clone.name = objectName;
        clone.transform.localPosition = localPosition;
        clone.transform.localRotation = Quaternion.identity;
        clone.transform.localScale = Vector3.one * 0.65f;
        clone.text = string.Empty;
        return clone;
    }

    public void OnLocalize()
    {
        ApplyLocalizedFonts();

        if (_label != null)
            _label.text = OccupiedCard != null ? ResolveName(OccupiedCard) : string.Empty;

        RefreshStats();
    }

    public void SetPreview(bool preview, Color borderColor)
    {
        CacheBorderRenderers();
        SetBorder(_borderRenderer, preview, borderColor);
        if (_borderVis != null && _borderVis.activeSelf != preview)
            _borderVis.SetActive(preview);
    }

    /// <summary>보존 표시용 테두리. isEffectPreserved=true 면 연한 파랑(효과 보존), 아니면 시안(이번 턴 선택).</summary>
    public void SetPreserveHighlight(bool on, bool isEffectPreserved = false)
    {
        SetPreview(on, isEffectPreserved ? _effectPreservedColor : _preserveColor);
    }

    private void CacheBorderRenderers()
    {
        if (_borderRenderer == null && _borderVis != null)
            _borderRenderer = _borderVis.GetComponent<SpriteRenderer>();

        _borderPropertyBlock ??= new MaterialPropertyBlock();
    }

    private void SetBorder(SpriteRenderer targetRenderer, bool enabled, Color borderColor)
    {
        if (targetRenderer == null) return;

        _borderPropertyBlock.Clear();
        targetRenderer.GetPropertyBlock(_borderPropertyBlock);
        _borderPropertyBlock.SetFloat(BorderOnPropertyId, enabled ? 1f : 0f);
        _borderPropertyBlock.SetColor(BorderColorPropertyId, borderColor);
        targetRenderer.SetPropertyBlock(_borderPropertyBlock);
    }

    /// <summary>방향 신호 도착 펄스 on/off (선택 연출). 없으면 무시.</summary>
    public void SetSignalPulse(bool on)
    {
        if (_signalPulse != null && _signalPulse.activeSelf != on)
            _signalPulse.SetActive(on);
    }

    /// <summary>슬롯 BoxCollider 기준 외곽선 월드 좌표를 시계 방향으로 채운다.</summary>
    public bool TryGetWorldOutline(Vector3[] corners, float padding = 0f, float zOffset = 0f)
    {
        if (corners == null || corners.Length < 4) return false;
        if (!TryGetComponent(out BoxCollider box)) return false;

        Vector3 half = box.size * 0.5f;
        half.x += padding;
        half.y += padding;

        corners[0] = transform.TransformPoint(box.center + new Vector3(-half.x, half.y, 0f));
        corners[1] = transform.TransformPoint(box.center + new Vector3(half.x, half.y, 0f));
        corners[2] = transform.TransformPoint(box.center + new Vector3(half.x, -half.y, 0f));
        corners[3] = transform.TransformPoint(box.center + new Vector3(-half.x, -half.y, 0f));

        for (int i = 0; i < 4; i++)
        {
            corners[i].z += zOffset;
        }

        return true;
    }

    private void ResetCardVisual()
    {
        Transform target = GetCardVisualTransform();
        if (_toggleFeedbackRoutine != null)
        {
            StopCoroutine(_toggleFeedbackRoutine);
            _toggleFeedbackRoutine = null;
        }
        ResetToggleFeedback(target);

        SetActivated(false);
        ShowArrows(ECardDirection.None);
        if (_label != null) _label.text = string.Empty;
        if (_cardIcon != null)
        {
            _cardIcon.sprite = null;
            _cardIcon.enabled = false;
        }
        if (_infoRoot != null) _infoRoot.SetActive(false);
        if (_infoText != null) _infoText.text = string.Empty;
    }

    // RefreshStats 에서 스탯 표기 순서 (아이콘 대응 스탯만).
    private static readonly EStatType[] StatDisplayOrder =
    {
        EStatType.Damage, EStatType.Block, EStatType.Heal,
        EStatType.DrawCard, EStatType.Energy,
    };

    public void RefreshStats()
    {
        Card card = OccupiedCard;
        if (card == null) return;

        // 타입 문자열 대신 TMP 스프라이트 태그로 아이콘을 인라인 표기한다.
        // 아이콘만 흰색/회색 color 태그 + tint=1 로 처리해 글자는 검은색을 유지하고 아이콘만 원색/디밍한다.
        var parts = new List<string>(6);
        for (int i = 0; i < StatDisplayOrder.Length; i++)
        {
            EStatType type = StatDisplayOrder[i];
            if (!TryBuildStatValue(card, type, out string valueText)) continue;
            parts.Add($"{BuildSpriteTag(type.ToGridSlotTmpIconName())}{valueText}");
        }

        // 캐스팅: CastingEffect 는 EStatType 이 아니라 별도 효과라 여기서 TMP 스프라이트 키를 직접 쓴다.
        if (_castingEffect != null)
        {
            parts.Add($"{BuildSpriteTag(StatIconKeys.GridSlotTmpIconCasting)}{_castingEffect.RequiredCount}");
        }

        bool visible = parts.Count > 0;
        if (_infoRoot != null) _infoRoot.SetActive(visible);
        if (_infoText != null)
            _infoText.text = visible ? string.Join("  ", parts) : string.Empty;
    }

    private string BuildSpriteTag(string iconKey)
    {
        return string.IsNullOrEmpty(iconKey)
            ? string.Empty
            : $"<color={GetIconColorTag()}><sprite name=\"{iconKey}\" tint=1></color>";
    }

    private string GetIconColorTag()
    {
        if (_isActivated) return ActiveIconColorTag;

        byte value = (byte)Mathf.RoundToInt(Mathf.Clamp01(_deactivatedBrightness) * 255f);
        return $"#{value:X2}{value:X2}{value:X2}";
    }

    /// <summary>스탯 최종 수치(버프 반영)를 계산해 표기 문자열을 만든다. 표시 대상 아니면 false.</summary>
    private bool TryBuildStatValue(Card card, EStatType type, out string valueText)
    {
        valueText = null;
        if (!card.TryGetPreviewStat(type, out int baseValue) || baseValue <= 0) return false;
        int value = Mathf.Max(0, Mathf.RoundToInt(
            card.Stats.ComputeWithExtraFlat(type, baseValue)));
        value = Mathf.Max(0, Mathf.RoundToInt(
            value * card.GetConditionalEffectMultiplier()));
        if (value <= 0) return false;

        int bonusBaseValue = GetBonusBaseValue(card, type, baseValue);
        bonusBaseValue = Mathf.Max(0, Mathf.RoundToInt(
            bonusBaseValue * card.GetConditionalEffectMultiplier()));
        int bonusValue = value - bonusBaseValue;
        float brightness = _isActivated ? _activatedBrightness : _deactivatedBrightness;
        Color buffedColor = ApplyBrightness(BuffedStatColor, brightness);
        valueText = bonusValue > 0
            ? $"<color=#{ColorUtility.ToHtmlStringRGBA(buffedColor)}>{value}</color>(+{bonusValue})"
            : value.ToString();
        return true;
    }

    /// <summary>
    /// 얼음 단도는 자체 감쇠를 고유 수치에만 반영하고, 토템 등 외부 보너스는 괄호에 분리한다.
    /// 다른 카드는 기존 표시 기준값을 그대로 사용한다.
    /// </summary>
    private static int GetBonusBaseValue(Card card, EStatType type, int baseValue)
    {
        if (type != EStatType.Damage || card == null)
            return baseValue;

        IReadOnlyList<CardEffectBase> effects = card.Effects;
        for (int i = 0; i < effects.Count; i++)
        {
            if (effects[i] is GlassBladeDecayEffect decay)
                return Mathf.Max(0, baseValue - decay.CurrentDamageLoss);
        }

        return baseValue;
    }

    private void UnbindCardState()
    {
        if (OccupiedCard != null)
        {
            OccupiedCard.Stats.OnChanged -= RefreshStats;
        }
        _castingEffect = null;
        DespawnTotemAura();
    }

    private static CastingEffect FindCastingEffect(Card card)
    {
        if (card == null) return null;
        for (int i = 0; i < card.Effects.Count; i++)
        {
            if (card.Effects[i] is CastingEffect casting) return casting;
        }
        return null;
    }

    private static string ResolveName(Card card)
    {
        string key = card?.Data != null ? card.Data.DisplayNameKey : card?.CardId;
        return LocalizationManager.HasInstance && !string.IsNullOrEmpty(key)
            ? LocalizationManager.Instance.Get(key)
            : key ?? string.Empty;
    }

    private async UniTaskVoid LoadCardIconAsync(Card card, int version)
    {
        if (_cardIcon == null || card?.Data == null ||
            string.IsNullOrEmpty(card.Data.IconKey) || !ResourceManager.HasInstance)
            return;

        Sprite sprite = await ResourceManager.Instance.LoadAtlasSpriteAsync(
            EAtlasType.CardIcon, card.Data.IconKey, this.GetCancellationTokenOnDestroy());
        if (this == null || version != _visualVersion || OccupiedCard != card) return;
        _cardIcon.sprite = sprite;
        RefreshCardVisualBrightness();
        _cardIcon.enabled = sprite != null;
    }

    private void CacheCardVisualColors()
    {
        // 슬롯 풀 재사용 시 이미 디밍(×0.35)된 색을 base 로 재캐싱하면
        // 다음 디밍에서 595959 → 1F1F1F 로 계속 어두워진다. authored 색은 최초 1회만 캐싱.
        if (_visualColorsCached) return;

        _cardRenderers.Clear();
        _cardRendererBaseColors.Clear();
        _cardTexts.Clear();
        _cardTextBaseColors.Clear();

        Transform root = GetCardVisualTransform();
        if (root == null) return;

        root.GetComponentsInChildren(true, _cardRenderers);
        for (int i = 0; i < _cardRenderers.Count; i++)
            _cardRendererBaseColors.Add(_cardRenderers[i].color);

        root.GetComponentsInChildren(true, _cardTexts);
        for (int i = 0; i < _cardTexts.Count; i++)
            _cardTextBaseColors.Add(_cardTexts[i].color);

        // 프리팹에 따라 라벨/최종 수치 텍스트가 _occupiedVisual 밖의 형제일 수 있다.
        // 활성 밝기 대상에 직렬화 참조를 명시적으로 포함해 계층 구조 차이의 영향을 없앤다.
        AddCardRenderer(_cardIcon);
        AddCardText(_label);
        AddCardText(_infoText);

        _visualColorsCached = true;
    }

    private void AddCardRenderer(SpriteRenderer renderer)
    {
        if (renderer == null || _cardRenderers.Contains(renderer)) return;
        _cardRenderers.Add(renderer);
        _cardRendererBaseColors.Add(renderer.color);
    }

    private void AddCardText(TMP_Text text)
    {
        if (text == null || _cardTexts.Contains(text)) return;
        _cardTexts.Add(text);
        _cardTextBaseColors.Add(text.color);
    }

    private void RefreshCardVisualBrightness()
    {
        if (_cardRenderers.Count == 0 && _cardTexts.Count == 0)
            CacheCardVisualColors();

        float brightness = _isActivated ? _activatedBrightness : _deactivatedBrightness;
        for (int i = 0; i < _cardRenderers.Count; i++)
        {
            if (_cardRenderers[i] != null)
                _cardRenderers[i].color = ApplyBrightness(_cardRendererBaseColors[i], brightness);
        }

        for (int i = 0; i < _cardTexts.Count; i++)
        {
            if (_cardTexts[i] != null)
                _cardTexts[i].color = ApplyBrightness(_cardTextBaseColors[i], brightness);
        }

        if (_isActivated && OccupiedCard != null &&
            OccupiedCard.IsTemporaryFieldOnly && OccupiedCard.GeneratesCardsOnTurnEnd &&
            _occupiedVisual != null && _occupiedVisual.TryGetComponent(out SpriteRenderer occupiedRenderer))
        {
            occupiedRenderer.color = TurnEndGeneratorOnColor;
        }
        else if (!_isActivated && _occupiedVisual != null &&
                 _occupiedVisual.TryGetComponent(out SpriteRenderer offRenderer))
        {
            offRenderer.color = OccupiedVisualOffColor;
        }
    }

    private static Color ApplyBrightness(Color baseColor, float brightness)
    {
        return new Color(
            baseColor.r * brightness,
            baseColor.g * brightness,
            baseColor.b * brightness,
            baseColor.a);
    }

    private void RefreshTotemAura(bool activated)
    {
        Card card = OccupiedCard;
        bool shouldShow = activated && card?.Data != null &&
                          card.Data.CardType == ECardType.Totem &&
                          !string.IsNullOrEmpty(card.Data.ProjectileKey);
        if (!shouldShow)
        {
            DespawnTotemAura();
            return;
        }
        if (_totemAura == null)
            SpawnTotemAuraAsync(card, _visualVersion).Forget();
    }

    private async UniTaskVoid SpawnTotemAuraAsync(Card card, int version)
    {
        if (!PoolManager.HasInstance) return;
        PoolableMonoBehaviour aura = await PoolManager.Instance.SpawnAsync<PoolableMonoBehaviour>(
            card.Data.ProjectileKey, transform.position, Quaternion.identity,
            transform, this.GetCancellationTokenOnDestroy());
        if (aura == null) return;

        if (this == null || version != _visualVersion || OccupiedCard != card ||
            !card.GridState.IsActivated || _totemAura != null)
        {
            if (PoolManager.HasInstance &&
                PoolManager.Instance.IsPooledInstance(aura.gameObject))
                PoolManager.Instance.Despawn(aura);
            return;
        }
        _totemAura = aura;
    }

    private void DespawnTotemAura()
    {
        if (_totemAura == null) return;
        if (PoolManager.HasInstance &&
            PoolManager.Instance.IsPooledInstance(_totemAura.gameObject))
            PoolManager.Instance.Despawn(_totemAura);
        _totemAura = null;
    }

    private void OnDestroy()
    {
        DOTween.Kill(transform);
        UnbindCardState();
        if (LocalizationManager.HasInstance)
            LocalizationManager.Instance.Unregister(this);
    }

    private void OnEnable()
    {
        if (LocalizationManager.HasInstance)
            LocalizationManager.Instance.Register(this);
        else
            ApplyLocalizedFonts();
    }

    private void OnDisable()
    {
        if (LocalizationManager.HasInstance)
            LocalizationManager.Instance.Unregister(this);
    }

    private void ApplyLocalizedFonts()
    {
        TMP_FontAsset font = LocalizedFontUtility.CurrentFont;
        LocalizedFontUtility.ApplyFont(_label, font);
        LocalizedFontUtility.ApplyFont(_infoText, font);
        for (int i = 0; i < _cardTexts.Count; i++)
            LocalizedFontUtility.ApplyFont(_cardTexts[i], font);
    }

    private void RefreshVisual()
    {
        bool occupied = !IsEmpty;
        if (_emptyVisual != null) _emptyVisual.SetActive(!occupied);
        if (_occupiedVisual != null) _occupiedVisual.SetActive(occupied);
    }

    private void SetArrow(GameObject arrow, bool active, bool isOverlayed)
    {
        if (arrow == null) return;
        if (arrow.activeSelf != active)
            arrow.SetActive(active);
        if (active)
            ApplyArrowTint(arrow, isOverlayed);
    }

    // 스킬 강화 화살표 색 구분. (틴트 vs 머티리얼 스왑은 추후 결정 — 적용 지점은 여기로 격리)
    private void ApplyArrowTint(GameObject arrow, bool isOverlayed)
    {
        Color color = isOverlayed ? _passiveArrowColor : _defaultArrowColor;

        var sprite = arrow.GetComponent<SpriteRenderer>();
        if (sprite != null) { sprite.color = color; return; }

        var graphic = arrow.GetComponent<UnityEngine.UI.Graphic>();
        if (graphic != null) graphic.color = color;
    }

    private bool HasVisualForAnyDirection(ECardDirection directions)
    {
        return ((directions & ECardDirection.Up) != 0 && _arrowUp != null) ||
               ((directions & ECardDirection.Down) != 0 && _arrowDown != null) ||
               ((directions & ECardDirection.Left) != 0 && _arrowLeft != null) ||
               ((directions & ECardDirection.Right) != 0 && _arrowRight != null) ||
               ((directions & ECardDirection.UpLeft) != 0 && _arrowUpLeft != null) ||
               ((directions & ECardDirection.UpRight) != 0 && _arrowUpRight != null) ||
               ((directions & ECardDirection.DownLeft) != 0 && _arrowDownLeft != null) ||
               ((directions & ECardDirection.DownRight) != 0 && _arrowDownRight != null);
    }

    private Transform GetCardVisualTransform()
    {
        if (_occupiedVisual != null) return _occupiedVisual.transform;
        if (_label != null) return _label.transform;
        return transform;
    }

    private static void ResetToggleFeedback(Transform target)
    {
        if (target == null) return;
        target.localRotation = Quaternion.identity;
        target.localScale = Vector3.one * 1.1f;
    }
}
