﻿// =================================================================
// [스크립트 목적]  그리드에 배치된 카드의 활성화 상태 (ON/OFF + 턴 ON 횟수)
// [주요 변수]      - IsActivated  : 현재 ON 상태
//                  - TurnOnCount  : 이번 턴에 ON 된 횟수 (임계/카운터 효과용)
// [의존 관계]      - GridManager 가 Card 별로 생성·관리
//                  - ChainExecutor 가 토글, EGridCountScope.SelfTurnOnCount 집계 원천
// [설계 노트]      - 활성화는 "그리드에 있을 때만" 의미 → Card(데이터)와 분리
//                    카드가 슬롯을 옮겨도 상태는 카드를 따라간다 (GridManager 가 Card 키로 관리)
// =================================================================

/// <summary>
/// 그리드 카드 1장의 활성화 런타임 상태.
/// 카드가 그리드에 배치되어 있는 동안만 유효하며, 회수 시 폐기된다.
/// zip 의 CardView.IsActivated + CardPersistentState.TurnOnCount 를 분리·이식.
/// </summary>
public sealed class GridCardState
{
    /// <summary>현재 ON(활성) 상태.</summary>
    public bool IsActivated { get; private set; }

    /// <summary>이번 턴에 ON 된 누적 횟수 (임계 활성화·카운터 효과의 Self 집계).</summary>
    public int TurnOnCount { get; private set; }

    /// <summary>이번 턴에 플레이어가 처음 배치한 카드인지 여부.</summary>
    public bool IsFirstPlacedThisTurn { get; private set; }

    /// <summary>
    /// 보존 스택. 1 이상이면 그리드 정리 시 회수되지 않고 유지된다.
    /// "보존 1 = 다음 회수 1회를 버팀". 회수 대상이 될 때 1 차감된다(ConsumePreserve).
    /// </summary>
    public int PreserveStack { get; private set; }

    /// <summary>보존 여부 빠른 조회 (스택이 1 이상인가).</summary>
    public bool IsPreserved => PreserveStack > 0;


    /// <summary>ON/OFF 토글. 새 상태를 반환한다.</summary>
    public bool Toggle()
    {
        IsActivated = !IsActivated;
        return IsActivated;
    }

    /// <summary>명시적으로 활성 상태 설정.</summary>
    public void SetActivated(bool activated)
    {
        IsActivated = activated;
    }

    /// <summary>이번 턴 ON 횟수 1 증가 (ON 으로 전환될 때 호출).</summary>
    public void IncrementTurnOnCount()
    {
        TurnOnCount++;
    }

    /// <summary>턴 종료 시 ON 횟수 초기화 (활성 상태는 유지).</summary>
    public void ResetTurnOnCount()
    {
        TurnOnCount = 0;
    }

    public void SetFirstPlacedThisTurn(bool value)
    {
        IsFirstPlacedThisTurn = value;
    }

    public void ResetTurnState()
    {
        TurnOnCount = 0;
        IsFirstPlacedThisTurn = false;
    }

    /// <summary>보존 스택을 amount 만큼 더한다 (보존 효과가 호출). 음수면 무시.</summary>
    public void AddPreserve(int amount)
    {
        if (amount <= 0) return;
        PreserveStack += amount;
    }

    /// <summary>보존 스택을 직접 설정한다 (UI/디버그용). 0 미만은 0 으로 보정.</summary>
    public void SetPreserveStack(int stack)
    {
        PreserveStack = stack < 0 ? 0 : stack;
    }

    /// <summary>
    /// 회수 시점에 보존을 1 소모한다. 소모 후에도 스택이 남아있으면 true(이번 회수는 버팀).
    /// 스택이 0 이면 false(회수 대상). 방식 A: 회수 시도가 있을 때만 줄어든다.
    /// </summary>
    public bool ConsumePreserve()
    {
        if (PreserveStack <= 0) return false;
        PreserveStack--;
        return true;
    }

    /// <summary>전투 종료·카드 회수 시 전체 초기화.</summary>
    public void Reset()
    {
        IsActivated = false;
        TurnOnCount = 0;
        IsFirstPlacedThisTurn = false;
        PreserveStack = 0;
    }
}
