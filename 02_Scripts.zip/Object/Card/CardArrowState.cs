// =================================================================
// [스크립트 목적]  카드 방위 화살표의 런타임 상태. 모드별로 방향을 결정·보관
// [주요 변수]      - _config   : SO 설정 (모드/후보/가중치) 참조
//                  - _current  : 현재 활성 방향 비트 (Flags 동시 가능)
//                  - _resolved : 이미 한 번 결정됐는지 (Fixed/고정 결과 캐시용)
// [의존 관계]      - ArrowConfig / ECardDirection / EArrowMode
//                  - CardFactory 가 생성, 그리드 배치 로직이 Resolve 호출
// [설계 노트]      - Resolve 는 배치 시점 1회 호출 가정 (매 프레임 호출 금지)
//                  - 가중치 합산 루프만 사용, 힙 할당 없음 (GC Zero)
// =================================================================

using UnityEngine;

/// <summary>
/// 카드 1장의 방위 화살표 런타임 상태.
/// Fixed 면 SO 지정 방향을 그대로, Random/Weighted 면 후보에서 굴려 최종 방향을 정한다.
/// 결과는 _current(Flags)에 보관하며, 동시 선택(여러 비트)을 지원한다.
/// </summary>
public sealed class CardArrowState
{
    private readonly ArrowConfig _config;
    private ECardDirection _current;
    private bool _resolved;

    // ── 패시브 오버레이 (즉시 상태변경형 화살표 변경/복원) ──
    // 패시브로 화살표를 바꾸기 직전의 _current 를 1회 백업한다.
    // 영구 변경이 없으므로(기획) 턴/전투 종료 시 RevertOverlay 로 원복한다.
    private ECardDirection _overlayBackup;
    private bool _hasOverlay;

    // 패시브 "화살표 추가"로 강조 표시할 방향 비트.
    // 회전은 이 비트를 같이 돌리기만 하고 새로 추가하지 않는다(회전은 색 안 바뀜).
    private ECardDirection _highlightDirs;

    /// <summary>현재 활성 방향 비트 (Flags). 미결정 시 None.</summary>
    public ECardDirection Current => _current;

    /// <summary>패시브로 화살표가 변경된 상태인지 (비주얼 강조·복원 판단용).</summary>
    public bool HasOverlay => _hasOverlay;

    /// <summary>강조색으로 표시할 방향 비트 (패시브 "추가"로 생긴 화살표만). 회전은 따라 돌되 추가 안 함.</summary>
    public ECardDirection HighlightDirs => _highlightDirs;

    /// <summary>화살표가 하나도 없는 무방향 상태인지.</summary>
    public bool IsNone => _current == ECardDirection.None;

    /// <summary>이미 방향이 결정됐는지 (재배치 판단용).</summary>
    public bool IsResolved => _resolved;

    public CardArrowState(ArrowConfig config)
    {
        _config = config;
        _current = ECardDirection.None;
        _resolved = false;
    }

    /// <summary>
    /// 방향 결정. 배치 시점에 1회 호출한다 (매 프레임 호출 금지 — 랜덤 모드는 재호출마다 결과 변동).
    /// Fixed 는 SO 지정값 확정, Random/Weighted 는 후보에서 PickCount 만큼 뽑는다.
    /// </summary>
    /// <param name="forceReroll">true 면 이미 결정됐어도 다시 굴린다 (재배치·리롤 효과용).</param>
    /// <returns>결정된 방향 비트.</returns>
    public ECardDirection Resolve(bool forceReroll = false)
    {
        if (_resolved && !forceReroll)
        {
            return _current;
        }

        if (_config == null)
        {
            _current = ECardDirection.None;
            _resolved = true;
            return _current;
        }

        switch (_config.Mode)
        {
            case EArrowMode.Fixed:
                _current = _config.FixedDirs;
                break;

            case EArrowMode.Random:
                _current = PickRandom(weighted: false);
                break;

            case EArrowMode.Weighted:
                _current = PickRandom(weighted: true);
                break;

            default:
                _current = ECardDirection.None;
                break;
        }

        _resolved = true;
        return _current;
    }

    /// <summary>특정 방향이 현재 활성인지 빠른 조회.</summary>
    public bool Has(ECardDirection direction) => (_current & direction) != 0;

    /// <summary>방향 상태 초기화 (카드 회수·전투 종료 시).</summary>
    public void Reset()
    {
        _current = ECardDirection.None;
        _resolved = false;
        _overlayBackup = ECardDirection.None;
        _hasOverlay = false;
        _highlightDirs = ECardDirection.None;
    }

    public void Restore(ECardDirection directions)
    {
        _current = directions;
        _resolved = true;
    }

    public void RotateClockwise(int steps = 1)
    {
        if (!_resolved) Resolve();
        _current = RotateDirections(_current, steps);
    }

    /// <summary>방향 비트마스크를 시계방향으로 steps×90° 회전한 결과를 반환한다 (순수 함수).</summary>
    private static ECardDirection RotateDirections(ECardDirection dirs, int steps)
    {
        steps = ((steps % 4) + 4) % 4;
        for (int i = 0; i < steps; i++)
        {
            ECardDirection rotated = ECardDirection.None;
            RotateBit(dirs, ECardDirection.Up, ECardDirection.Right, ref rotated);
            RotateBit(dirs, ECardDirection.Right, ECardDirection.Down, ref rotated);
            RotateBit(dirs, ECardDirection.Down, ECardDirection.Left, ref rotated);
            RotateBit(dirs, ECardDirection.Left, ECardDirection.Up, ref rotated);
            RotateBit(dirs, ECardDirection.UpRight, ECardDirection.DownRight, ref rotated);
            RotateBit(dirs, ECardDirection.DownRight, ECardDirection.DownLeft, ref rotated);
            RotateBit(dirs, ECardDirection.DownLeft, ECardDirection.UpLeft, ref rotated);
            RotateBit(dirs, ECardDirection.UpLeft, ECardDirection.UpRight, ref rotated);
            dirs = rotated;
        }
        return dirs;
    }

    private static void RotateBit(ECardDirection source, ECardDirection from, ECardDirection to, ref ECardDirection result)
    {
        if ((source & from) != 0) result |= to;
    }

    // ── 패시브 오버레이 적용/복원 ───────────────────────────

    /// <summary>
    /// 패시브(즉시 상태변경형)가 화살표를 바꾸기 직전에 호출한다.
    /// 최초 1회만 현재 방향을 백업하고, 이후 RevertOverlay 로 원복 가능하게 만든다.
    /// (같은 카드에 화살표 패시브를 여러 번 걸어도 "최초 원본"으로 되돌린다)
    /// </summary>
    private void EnsureOverlayBackup()
    {
        if (!_resolved) Resolve();
        if (!_hasOverlay)
        {
            _overlayBackup = _current;
            _hasOverlay = true;
        }
    }

    /// <summary>패시브: 기존 방향에 방향 비트를 추가한다 (오버레이). 추가된 방향은 강조 대상.</summary>
    public void AddDirectionsOverlay(ECardDirection directions)
    {
        EnsureOverlayBackup();
        // 이미 있던 방향은 강조하지 않고, 실제로 새로 생기는 방향만 강조에 더한다.
        ECardDirection newlyAdded = directions & ~_current;
        _current |= directions;
        _highlightDirs |= newlyAdded;
    }

    /// <summary>패시브: 방향을 통째로 교체한다 (오버레이). 강조 기준이 모호하므로 강조는 비운다.</summary>
    public void SetDirectionsOverlay(ECardDirection directions)
    {
        EnsureOverlayBackup();
        _current = directions;
        _highlightDirs = ECardDirection.None;
    }

    /// <summary>패시브: 시계방향 회전 (오버레이). 강조 방향도 같이 돌되 새 강조는 만들지 않는다.</summary>
    public void RotateOverlay(int steps = 1)
    {
        EnsureOverlayBackup();
        RotateClockwise(steps);
        _highlightDirs = RotateDirections(_highlightDirs, steps);
    }

    /// <summary>패시브 오버레이를 최초 원본으로 되돌린다 (턴/전투 종료 정리).</summary>
    public void RevertOverlay()
    {
        if (!_hasOverlay) return;
        _current = _overlayBackup;
        _hasOverlay = false;
        _highlightDirs = ECardDirection.None;
    }

    /// <summary>
    /// 손패 등에서 "배치 전 미리 보여줄 방향". Resolve 를 호출하지 않아 랜덤 결과에 영향 없음.
    /// - 이미 결정됨(재배치 등): 현재 방향
    /// - Fixed 모드: SO 확정 방향 (미리 보여도 안전)
    /// - Random/Weighted 미결정: None (배치 시 굴림 — 미리보기는 팀원 확장: 물음표 등)
    /// </summary>
    public ECardDirection PreviewDirs
    {
        get
        {
            if (_resolved) return _current;
            if (_config != null && _config.Mode == EArrowMode.Fixed) return _config.FixedDirs;
            return ECardDirection.None;
        }
    }

    // ── 내부: 랜덤 선택 ─────────────────────────────────────

    /// <summary>
    /// 후보에서 PickCount 만큼 비복원 추출하여 Flags 로 합친다.
    /// weighted=true 면 가중치 비례, false 면 균등.
    /// 후보 수가 적어 선형 탐색으로 충분하며 힙 할당이 없다 (GC Zero).
    /// </summary>
    private ECardDirection PickRandom(bool weighted)
    {
        var candidates = _config.Candidates;
        if (candidates == null || candidates.Count == 0)
        {
            return ECardDirection.None;
        }

        // usedMask 가 int 비트라 후보 32개 초과 시 추적 불가 — 방어 (4방위는 무관).
        if (candidates.Count > 31)
        {
            Debug.LogWarning("[CardArrowState] 후보가 31개를 초과합니다. 앞 31개만 사용됩니다.");
        }

        int pickCount = Mathf.Clamp(ResolvePickCount(), 1, candidates.Count);

        if (pickCount == 2 && TryPickPairGroup(out ECardDirection pair))
        {
            return pair;
        }

        ECardDirection result = ECardDirection.None;

        // 이미 뽑은 후보를 비트로 추적해 중복 방지 (인덱스 마스크).
        int usedMask = 0;

        for (int picked = 0; picked < pickCount; picked++)
        {
            int index = weighted
                ? PickWeightedIndex(usedMask)
                : PickUniformIndex(usedMask);

            if (index < 0)
            {
                break; // 더 뽑을 후보 없음
            }

            usedMask |= (1 << index);
            result |= NormalizeCandidateDirection(candidates[index].direction);
        }

        return result;
    }

    private bool TryPickPairGroup(out ECardDirection pair)
    {
        pair = ECardDirection.None;

        if (_config.PairGroups != null && _config.PairGroups.Count > 0)
        {
            int pairIndex = Random.Range(0, _config.PairGroups.Count);
            pair = _config.PairGroups[pairIndex];
            return pair != ECardDirection.None;
        }

        ECardDirection available = GetCandidateDirections();
        bool canUpDown = (available & (ECardDirection.Up | ECardDirection.Down)) ==
                         (ECardDirection.Up | ECardDirection.Down);
        bool canLeftRight = (available & (ECardDirection.Left | ECardDirection.Right)) ==
                            (ECardDirection.Left | ECardDirection.Right);

        if (canUpDown && canLeftRight)
        {
            pair = Random.Range(0, 2) == 0
                ? ECardDirection.Up | ECardDirection.Down
                : ECardDirection.Left | ECardDirection.Right;
            return true;
        }

        if (canUpDown)
        {
            pair = ECardDirection.Up | ECardDirection.Down;
            return true;
        }

        if (canLeftRight)
        {
            pair = ECardDirection.Left | ECardDirection.Right;
            return true;
        }

        return false;
    }

    private ECardDirection GetCandidateDirections()
    {
        ECardDirection directions = ECardDirection.None;
        var candidates = _config.Candidates;
        for (int i = 0, n = Mathf.Min(candidates.Count, 31); i < n; i++)
        {
            directions |= NormalizeCandidateDirection(candidates[i].direction);
        }
        return directions;
    }

    private static ECardDirection NormalizeCandidateDirection(ECardDirection direction)
    {
        if (direction == ECardDirection.None)
            return ECardDirection.None;

        // Random/Weighted 후보 1개는 단일 방향이어야 한다. 기존 데이터에 복합 Flags가
        // 들어와도 후보 하나가 여러 방향을 동시에 켜지 않도록 가장 낮은 비트만 사용한다.
        int raw = (int)direction;
        int singleBit = raw & -raw;
        return (ECardDirection)singleBit;
    }

    private int ResolvePickCount()
    {
        var countWeights = _config.CountWeights;
        if (countWeights == null || countWeights.Count == 0)
        {
            return _config.PickCount;
        }

        float total = 0f;
        for (int i = 0; i < countWeights.Count; i++)
        {
            total += Mathf.Max(0f, countWeights[i].weight);
        }

        if (total <= 0f)
        {
            return _config.PickCount;
        }

        float roll = Random.value * total;
        float accumulated = 0f;
        for (int i = 0; i < countWeights.Count; i++)
        {
            accumulated += Mathf.Max(0f, countWeights[i].weight);
            if (roll <= accumulated)
            {
                return Mathf.Max(1, countWeights[i].count);
            }
        }

        return Mathf.Max(1, countWeights[countWeights.Count - 1].count);
    }

    /// <summary>아직 안 쓴 후보 중 균등 랜덤 인덱스. 없으면 -1.</summary>
    private int PickUniformIndex(int usedMask)
    {
        var candidates = _config.Candidates;

        // 남은 후보 수 카운트.
        int remaining = 0;
        for (int i = 0, n = Mathf.Min(candidates.Count, 31); i < n; i++)
        {
            if ((usedMask & (1 << i)) == 0) remaining++;
        }
        if (remaining == 0) return -1;

        // 남은 것 중 n번째 선택.
        int target = Random.Range(0, remaining);
        int seen = 0;
        for (int i = 0, n = Mathf.Min(candidates.Count, 31); i < n; i++)
        {
            if ((usedMask & (1 << i)) != 0) continue;
            if (seen == target) return i;
            seen++;
        }
        return -1;
    }

    /// <summary>아직 안 쓴 후보 중 가중치 비례 랜덤 인덱스. 없으면 -1.</summary>
    private int PickWeightedIndex(int usedMask)
    {
        var candidates = _config.Candidates;

        // 남은 후보 가중치 합.
        float totalWeight = 0f;
        for (int i = 0, n = Mathf.Min(candidates.Count, 31); i < n; i++)
        {
            if ((usedMask & (1 << i)) != 0) continue;
            totalWeight += Mathf.Max(0f, candidates[i].weight);
        }

        // 가중치 합이 0이면 균등으로 폴백.
        if (totalWeight <= 0f)
        {
            return PickUniformIndex(usedMask);
        }

        float roll = Random.value * totalWeight;
        float accum = 0f;
        for (int i = 0, n = Mathf.Min(candidates.Count, 31); i < n; i++)
        {
            if ((usedMask & (1 << i)) != 0) continue;
            accum += Mathf.Max(0f, candidates[i].weight);
            if (roll <= accum) return i;
        }

        // 부동소수 오차 대비: 마지막 미사용 후보 반환.
        for (int i = Mathf.Min(candidates.Count, 31) - 1; i >= 0; i--)
        {
            if ((usedMask & (1 << i)) == 0) return i;
        }
        return -1;
    }
}
