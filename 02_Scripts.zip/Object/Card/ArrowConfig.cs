﻿// =================================================================
// [스크립트 목적]  방위 화살표의 SO 설정 데이터 ([Serializable], CardDataSO 인라인 보유)
// [주요 변수]      - _mode       : 방향 결정 모드 (Fixed/Random/Weighted)
//                  - _candidates : 후보 방향 목록 (각 방향 + 가중치)
//                  - _fixedDirs  : Fixed 모드에서 사용할 확정 방향 비트
// [의존 관계]      - CardDataSO 가 보유, CardArrowState 가 런타임 해석
// =================================================================

using System;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// 단일 후보 방향 + 가중치. Weighted 모드에서 가중치를 사용한다.
/// Random 모드에서는 가중치를 무시하고 후보를 균등 취급한다.
/// </summary>
[Serializable]
public struct ArrowCandidate
{
    [Tooltip("후보 방향. Flags 지만 후보 1개당 단일 방향 권장")]
    public ECardDirection direction;

    [Tooltip("가중치. Weighted 모드에서만 사용. 클수록 자주 선택됨 (음수는 0 취급)")]
    [Min(0f)]
    public float weight;
}

[Serializable]
public struct ArrowCountWeight
{
    [Min(1)]
    public int count;

    [Min(0f)]
    public float weight;
}

/// <summary>
/// 카드 방위 화살표의 정적 설정. CardDataSO 안에 인라인 직렬화된다.
/// Fixed 면 _fixedDirs 를, Random/Weighted 면 _candidates 를 런타임에 해석한다.
/// </summary>
[Serializable]
public sealed class ArrowConfig
{
    [Header("방향 결정 모드")]
    [Tooltip("Fixed=지정 방향 확정 / Random=균등 랜덤 / Weighted=가중치 랜덤")]
    [SerializeField] private EArrowMode _mode = EArrowMode.Fixed;

    [Header("Fixed 전용")]
    [Tooltip("Fixed 모드에서 확정 출력할 방향 (Flags 동시 선택 가능). None 이면 무방향")]
    [SerializeField] private ECardDirection _fixedDirs = ECardDirection.None;

    [Header("Random / Weighted 전용")]
    [Tooltip("랜덤 시 뽑을 후보 방향 목록")]
    [SerializeField] private List<ArrowCandidate> _candidates = new List<ArrowCandidate>();

    [Tooltip("랜덤 시 동시에 활성화할 방향 개수 (Flags 동시 선택). 1이면 단일 방향")]
    [Min(1)]
    [SerializeField] private int _pickCount = 1;

    [Tooltip("화살표 개수별 가중치. 비어 있으면 Pick Count를 고정 사용")]
    [SerializeField] private List<ArrowCountWeight> _countWeights = new List<ArrowCountWeight>();

    [Tooltip("선택 개수가 2일 때 허용할 방향 묶음. 비어 있으면 일반 비복원 추출")]
    [SerializeField] private List<ECardDirection> _pairGroups = new List<ECardDirection>();

    public EArrowMode Mode => _mode;
    public ECardDirection FixedDirs => _fixedDirs;
    public IReadOnlyList<ArrowCandidate> Candidates => _candidates;
    public int PickCount => _pickCount;
    public IReadOnlyList<ArrowCountWeight> CountWeights => _countWeights;
    public IReadOnlyList<ECardDirection> PairGroups => _pairGroups;

#if UNITY_EDITOR
    public void EditorImport(
        EArrowMode mode,
        ECardDirection fixedDirs,
        List<ArrowCandidate> candidates,
        int pickCount,
        List<ArrowCountWeight> countWeights = null,
        List<ECardDirection> pairGroups = null)
    {
        _mode = mode;
        _fixedDirs = fixedDirs;
        _candidates = candidates ?? new List<ArrowCandidate>();
        _pickCount = Mathf.Max(1, pickCount);
        _countWeights = countWeights ?? new List<ArrowCountWeight>();
        _pairGroups = pairGroups ?? new List<ECardDirection>();
    }
#endif
}
