// =================================================================
// [스크립트 목적]  포식(금단의 의식) — 화살표 방향 카드를 묘지로 소비(포식)하고,
//                  소비한 장수만큼 공격력을 누적한다.
// [주요 변수]      - _damagePerExhaustedCard : 포식 1장당 얻는 공격력
//                  - _accumulated            : 누적 공격력 총량 (OnLeaveGrid 에 초기화)
// [의존 관계]      - CardEffectBase 상속
//                  - CardDirectionUtility.Collect 로 화살표 방향 카드 수집
//                  - context.Service.DiscardGridCardAsync 로 대상 카드를 묘지로 소비
//                  - context.Owner.Stats 에 source 키로 누적 모디파이어 부여
// [설계 노트]      - ★ 재작성 (요구사항 반영):
//                    1) ON 전환 시 화살표 방향 카드를 포식하고 공격력을 누적한다.
//                    2) 배치 직후 첫 ON 과 이후 재활성화(ON)를 같은 경로로 처리한다.
//                    3) 포식 대상이 없으면 공격력 추가 없음.
//                    4) 누적치는 단일 source 키로 관리(누적 총량 덮어쓰기) → 재계산/회수 정확.
//                  - 누적 수명: OnLeaveGrid — 그리드에서 내려가면 전부 초기화. OFF 만으로는 유지.
//                  - source 키를 인스턴스별 고유화 → 여러 포식 카드가 함께 있어도 키 충돌 없음.
// =================================================================

using System;
using System.Collections.Generic;
using System.Threading;
using Cysharp.Threading.Tasks;
using UnityEngine;

/// <summary>
/// 화살표 방향의 카드를 묘지로 포식하고, 포식한 장수 × 단가만큼 공격력을 누적한다.
/// ON 전환마다 포식해 누적이 중첩된다. 배치 직후 첫 ON 은 기존 체인 흐름이 담당한다.
/// 누적 공격력은 그리드를 떠날 때(OnLeaveGrid) 전부 초기화된다(OFF 만으로는 유지).
/// </summary>
[Serializable]
public sealed class ForbiddenRitualEffect : CardEffectBase
{
    [Header("포식 설정")]
    [Tooltip("포식(소비)한 카드 1장당 얻는 공격력")]
    [Min(0)]
    [SerializeField] private int _damagePerExhaustedCard = 1;

    [NonSerialized] private int _accumulated;
    [NonSerialized] private List<Card> _scratch = new List<Card>(8);
    [NonSerialized] private string _sourceKey;

    // 이 카드가 삼킨 카드의 누적 장수. 업적 "하나의 포식 카드로 N장" 판정용.
    // 수명은 _accumulated 와 동일 — 그리드를 떠나면(OnLeaveGrid) 초기화된다.
    [NonSerialized] private int _totalDevoured;

    public override ECardEffectFlag EffectFlag => ECardEffectFlag.ApplyBuff;

    public override UniTask ExecuteAsync(CardEffectContext context, CancellationToken token)
    {
        return UniTask.CompletedTask;
    }

    /// <summary>ON 될 때마다 포식 — 중첩 누적. OFF 는 누적 유지.</summary>
    public override async UniTask OnOwnerActivationChangedAsync(
        CardRuntimeEventContext context, bool isActive, CancellationToken token)
    {
        if (!isActive)
        {
            return; // OFF 는 누적 유지 (그리드를 떠날 때만 초기화).
        }

        await PredateOnceAsync(context, token);
    }

    /// <summary>그리드에서 내려가면 누적 공격력을 전부 초기화한다.</summary>
    public override UniTask OnOwnerRemovedAsync(CardRuntimeEventContext context, CancellationToken token)
    {
        ClearAccumulation(context.Owner);
        return UniTask.CompletedTask;
    }

    /// <summary>
    /// 화살표 방향 카드들을 묘지로 소비(포식)하고, 소비 장수만큼 공격력을 누적한다.
    /// 포식 대상이 없으면 누적 변화 없음.
    /// </summary>
    private async UniTask PredateOnceAsync(CardRuntimeEventContext context, CancellationToken token)
    {
        Card owner = context.Owner;
        GridManager grid = context.Service?.Grid;
        if (owner == null || grid == null || context.Service == null)
        {
            return;
        }

        EnsureSourceKey(owner);

        // 화살표 방향 이웃 카드 수집 후 별도 배열로 고정 (Discard 중 그리드가 변하므로).
        CardDirectionUtility.Collect(grid, owner, _scratch);
        if (_scratch.Count == 0)
        {
            return; // 포식 대상 없음 → 공격력 추가 없음.
        }

        Card[] targets = _scratch.ToArray();
        int exhausted = 0;

        for (int i = 0; i < targets.Length; i++)
        {
            Card target = targets[i];
            if (target == null || target == owner) continue;

            await context.Service.DiscardGridCardAsync(target, token);
            if (token.IsCancellationRequested) return;
            exhausted++;
        }

        if (exhausted <= 0)
        {
            return;
        }

        // ★ 중첩 누적: 누적 총량에 더한 뒤 단일 키로 반영.
        _accumulated += exhausted * _damagePerExhaustedCard;
        ApplyAccumulatedModifier(owner);

        // 업적 신호: 이번 1회 포식 장수(최대 8 = 8방향) + 이 카드가 삼킨 누적 장수.
        _totalDevoured += exhausted;
        if (EventManager.HasInstance)
            EventManager.Instance.Publish(new PredationSignal(exhausted, _totalDevoured));

#if UNITY_EDITOR || DEVELOPMENT_BUILD
        Debug.Log($"[ForbiddenRitual] {owner.CardId} 포식 {exhausted}장 → 공격력 누적 {_accumulated}");
#endif
    }

    /// <summary>현재 누적 공격력을 source 키 단일 모디파이어로 반영한다.</summary>
    private void ApplyAccumulatedModifier(Card owner)
    {
        if (owner == null) return;
        owner.Stats.RemoveModifiersBySource(_sourceKey);
        if (_accumulated > 0)
        {
            owner.Stats.AddModifier(StatModifier.Flat(
                EStatType.Damage, _accumulated, EStatModifierLifetime.Transient, _sourceKey));
        }
    }

    private void ClearAccumulation(Card owner)
    {
        if (owner != null && !string.IsNullOrEmpty(_sourceKey))
        {
            owner.Stats.RemoveModifiersBySource(_sourceKey);
        }
        _accumulated = 0;
        _totalDevoured = 0; // 그리드를 떠나면 누적 포식 장수도 초기화.
    }

    private void EnsureSourceKey(Card owner)
    {
        if (string.IsNullOrEmpty(_sourceKey))
        {
            _sourceKey = $"ForbiddenRitual:{owner.CardId}:{GetHashCode()}";
        }
    }

    public override CardEffectBase Clone()
    {
        ForbiddenRitualEffect clone = (ForbiddenRitualEffect)base.Clone();
        clone._scratch = new List<Card>(8);
        clone._sourceKey = null;
        clone._accumulated = 0;
        clone._totalDevoured = 0; // 새 카드 인스턴스는 누적 포식 장수도 새로 센다.
        return clone;
    }

#if UNITY_EDITOR
    public override void ImportNumeric(int amount, int secondaryValue)
    {
        _damagePerExhaustedCard = Mathf.Max(0, amount);
    }
#endif
}
