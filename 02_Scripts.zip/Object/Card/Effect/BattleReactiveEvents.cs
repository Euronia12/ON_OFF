using System;
using System.Collections.Generic;
using Cysharp.Threading.Tasks;
using UnityEngine;

public enum EReactiveEventType
{
    CardDrawn,
    EnergyChanged,
    EnemyDamaged,
    CardDiscarded,
    CardExhausted,
    CardPlaced,
    CardToggled,
    DrawEffectResolved,
}

public enum EReactiveValueChange
{
    Any,
    Increased,
    Decreased,
    Unchanged,
}

public enum EReactiveOwnerState
{
    Any,
    Active,
    Inactive,
}

public readonly struct BattleReactiveEvent
{
    public EReactiveEventType Type { get; }
    public Card SourceCard { get; }
    public Card TargetCard { get; }
    public ICombatActor TargetActor { get; }
    public int Amount { get; }
    public int PreviousValue { get; }
    public int CurrentValue { get; }
    public EBattleDeckOwner Owner { get; }

    public int Delta => CurrentValue - PreviousValue;

    public BattleReactiveEvent(
        EReactiveEventType type,
        Card sourceCard = null,
        Card targetCard = null,
        ICombatActor targetActor = null,
        int amount = 0,
        int previousValue = 0,
        int currentValue = 0,
        EBattleDeckOwner owner = EBattleDeckOwner.RunDeck)
    {
        Type = type;
        SourceCard = sourceCard;
        TargetCard = targetCard;
        TargetActor = targetActor;
        Amount = amount;
        PreviousValue = previousValue;
        CurrentValue = currentValue;
        Owner = owner;
    }
}

public sealed class BattleReactiveEventBus
{
    private int _suppressCount;

    public event Action<BattleReactiveEvent> OnEvent;

    public IDisposable BeginSuppressScope()
    {
        _suppressCount++;
        return new SuppressScope(this);
    }

    public void Publish(BattleReactiveEvent evt)
    {
        if (_suppressCount > 0)
        {
            return;
        }

        OnEvent?.Invoke(evt);
    }

    public void Clear()
    {
        OnEvent = null;
        _suppressCount = 0;
    }

    private void EndSuppressScope()
    {
        if (_suppressCount > 0)
        {
            _suppressCount--;
        }
    }

    private sealed class SuppressScope : IDisposable
    {
        private BattleReactiveEventBus _owner;

        public SuppressScope(BattleReactiveEventBus owner)
        {
            _owner = owner;
        }

        public void Dispose()
        {
            BattleReactiveEventBus owner = _owner;
            if (owner == null)
            {
                return;
            }

            _owner = null;
            owner.EndSuppressScope();
        }
    }
}

public sealed class ReactiveToggleQueue
{
    private readonly Queue<Card> _queue = new Queue<Card>(8);
    private ChainExecutor _chain;
    private GridManager _grid;
    private bool _isFlushing;
    private int _deferFlushCount;

    public void Bind(ChainExecutor chain, GridManager grid)
    {
        _chain = chain;
        _grid = grid;
    }

    public IDisposable BeginDeferFlushScope()
    {
        _deferFlushCount++;
        return new DeferFlushScope(this);
    }

    public void Enqueue(Card owner)
    {
        if (owner == null)
        {
            return;
        }

        _queue.Enqueue(owner);
    }

    public async UniTask FlushAsync(System.Threading.CancellationToken token)
    {
        if (_deferFlushCount > 0 || _isFlushing || _chain == null || _grid == null)
        {
            return;
        }

        if (_chain.HasReachedActivationLimit)
        {
            Clear();
            return;
        }

        _isFlushing = true;
        try
        {
            while (_queue.Count > 0 && !token.IsCancellationRequested)
            {
                Card owner = _queue.Dequeue();
                if (owner == null || !_grid.TryGetPosition(owner, out _))
                {
                    continue;
                }

                await _chain.ExecuteReactiveSelfToggleAsync(owner, token);
                if (_chain.HasReachedActivationLimit)
                {
                    Clear();
                    return;
                }
                if (token.IsCancellationRequested)
                {
                    return;
                }
            }
        }
        finally
        {
            _isFlushing = false;
        }
    }

    public void Clear()
    {
        _queue.Clear();
    }

    private void EndDeferFlushScope()
    {
        if (_deferFlushCount > 0)
        {
            _deferFlushCount--;
        }
    }

    private sealed class DeferFlushScope : IDisposable
    {
        private ReactiveToggleQueue _owner;

        public DeferFlushScope(ReactiveToggleQueue owner)
        {
            _owner = owner;
        }

        public void Dispose()
        {
            ReactiveToggleQueue owner = _owner;
            if (owner == null)
            {
                return;
            }

            _owner = null;
            owner.EndDeferFlushScope();
        }
    }
}
