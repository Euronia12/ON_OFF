// =================================================================
// [스크립트 목적]  방밀. 현재 방어도의 절반(반올림)만큼 적에게 데미지 (방어도는 소비하지 않음)
// [주요 변수]      - 없음 (데미지 수치는 시전자 현재 방어도에서 파생)
// [의존 관계]      - CardEffectBase 상속, context.Caster(IBattleActor) 의 Block 을 읽음
//                  - ICombatActor.TakeDamage 로 적에게 피해
// [설계 노트]      - 기준 데미지는 방어도에서 파생되지만 카드 Damage modifier는 동일하게 적용
//                  - 데미지 = DamageModifier(Round(block / 2)), 방어도는 그대로 유지
// =================================================================

using System;
using System.Collections.Generic;
using System.Threading;
using Cysharp.Threading.Tasks;
using UnityEngine;

/// <summary>
/// 현재 방어도의 절반(반올림)만큼 적에게 데미지를 주는 효과. 방어도는 소비하지 않고 유지한다.
/// 방어도가 0이면 아무 일도 하지 않는다.
/// </summary>
[Serializable]
public sealed class BlockToDamageEffect : CardEffectBase
{
    public override ECardEffectFlag EffectFlag => ECardEffectFlag.Damage;
    public override DescValue DescAmount => new DescValue(
        EDescDynamicValue.CurrentBlockToDamageAmount, EStatType.Damage);

    public override UniTask ExecuteAsync(CardEffectContext context, CancellationToken token)
    {
        if (context.Caster is not IBattleActor actor)
        {
            return UniTask.CompletedTask;
        }

        int half = Mathf.RoundToInt(actor.Block * 0.5f); // 방어도 절반(반올림)
        if (half <= 0)
        {
            return UniTask.CompletedTask;
        }

        int damage = context.CalculateEffectAmount(EStatType.Damage, half);
        List<ICombatActor> targets = context.Targets;
        for (int i = 0; i < targets.Count; i++)
        {
            ICombatActor target = targets[i];
            if (target != null && target.IsAlive)
            {
                target.TakeDamage(damage);
            }
        }

#if UNITY_EDITOR || DEVELOPMENT_BUILD
        Debug.Log($"[Card Action] {context.Source?.CardId ?? "(unknown)"} 카드가 " +
            $"방어도 절반 {half} → {damage} 피해 (방어도 유지, 대상 {targets.Count})");
#endif
        return UniTask.CompletedTask;
    }

#if UNITY_EDITOR
    /// <summary>수치는 방어도에서 파생되므로 임포트 수치는 사용하지 않는다.</summary>
    public override void ImportNumeric(int amount, int secondaryValue)
    {
    }
#endif
}
