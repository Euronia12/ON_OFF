// =================================================================
// [스크립트 목적]  소유 카드의 체인 설정으로 추가 ON/OFF 신호를 전파하는 효과
// [주요 변수]      - 없음
// [의존 관계]      - CardEffectBase / ICardRuntimeEventService.PropagateToggleAsync
// =================================================================

using System;
using System.Threading;
using Cysharp.Threading.Tasks;

/// <summary>
/// 소유 카드의 체인 설정으로 첫 대상을 찾고, 그 대상부터 추가 ON/OFF 체인을 시작한다.
/// 발신 카드 자체의 상태는 변경하지 않는다.
/// </summary>
[Serializable]
public sealed class ToggleEffect : CardEffectBase
{
    public override ECardEffectFlag EffectFlag => ECardEffectFlag.Toggle;

    public override async UniTask ExecuteAsync(CardEffectContext context, CancellationToken token)
    {
        if (context?.Source == null || context.RuntimeService == null)
        {
            return;
        }

        await context.RuntimeService.PropagateToggleAsync(context.Source, token);
    }

#if UNITY_EDITOR
    public override void ImportNumeric(int amount, int secondaryValue)
    {
    }
#endif
}
