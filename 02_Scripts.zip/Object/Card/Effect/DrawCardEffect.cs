// =================================================================
// [스크립트 목적]  카드 드로우 효과. 대상 액터가 아닌 덱 시스템에 작용
// [주요 변수]      - _drawCount : 뽑을 카드 수
// [의존 관계]      - CardEffectBase 상속, context.Service.DrawCards 호출
// =================================================================

using Cysharp.Threading.Tasks;
using System;
using System.Threading;
using UnityEngine;

/// <summary>드로우 효과. 대상이 없으므로 _targetType = None 권장.</summary>
[Serializable]
public sealed class DrawCardEffect : CardEffectBase
{
    [Header("드로우 설정")]
    [Tooltip("뽑을 카드 수")]
    [Min(0)]
    [SerializeField] private int _drawCount = 1;

    public override ECardEffectFlag EffectFlag => ECardEffectFlag.DrawCard;

    public override UniTask ExecuteAsync(CardEffectContext context, CancellationToken token)
    {
        int drawCount = context.ApplyEffectMultiplier(_drawCount);

        // 드로우는 덱 시스템에 작용 — Service 경유.
        if (context.Service != null)
        {
            context.Service.DrawCards(drawCount, context.Source);
        }
        else
        {
            Debug.LogWarning("[DrawCardEffect] ICardGameService 가 컨텍스트에 없습니다. 드로우 무시됨.");
        }

#if UNITY_EDITOR || DEVELOPMENT_BUILD
        Debug.Log($"[Card Action] {context.Source?.CardId ?? "(unknown)"} 카드가 " +
            $"카드 {drawCount}장을 드로우함");
#endif
        return UniTask.CompletedTask;
    }

    public override bool TryGetPreviewStat(EStatType statType, out int value)
    {
        value = _drawCount;
        return statType == EStatType.DrawCard && _drawCount > 0;
    }

    public override DescValue DescAmount => new DescValue(_drawCount);

#if UNITY_EDITOR
    /// <summary>amount=드로우 수. 보조 수치 미사용.</summary>
    public override void ImportNumeric(int amount, int secondaryValue)
    {
        _drawCount = amount;
    }
#endif
}
