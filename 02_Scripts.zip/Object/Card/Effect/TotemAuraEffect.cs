// =================================================================
// [스크립트 목적]  주변 카드에 오라(버프/디버프)를 부여하는 토템 효과 (단일 범위·단일 값)
// [주요 변수]      - _buffScope / _buffStat / _buffModifierType / _buffValue : 오라 1계층
//                  - _activeOnly : ON 상태일 때만 오라 적용 여부
// [의존 관계]      - GridManager.GetCardsInAura 로 범위별 대상 수집
//                  - 대상 Card.Stats 에 source 키로 모디파이어 부여/회수
// [설계 노트]      - 버프/디버프는 별도 계층이 아니라 부호로 표현한다 (양수=버프, 음수=디버프).
//                    예) +2 공격(버프) / -1 공격(디버프). Flat/Percent 모두 가능.
//                  - 토템도 일반 카드처럼 OFF 상태로 배치되고 최초 루트 신호로 ON 된다.
//                    활성화 변경 훅에서 오라를 적용/회수하므로 이후 토글도 같은 규칙을 따른다.
// =================================================================

using System;
using System.Collections.Generic;
using System.Threading;
using Cysharp.Threading.Tasks;
using UnityEngine;

/// <summary>
/// 지정 범위의 주변 카드에 오라를 부여하는 토템. 수치 부호로 버프/디버프를 표현한다
/// (양수=버프, 음수=디버프). 단일 source 키로 회수·재계산을 관리한다.
/// </summary>
[Serializable]
public sealed class TotemAuraEffect : CardEffectBase
{
    [Header("오라 (양수=버프 / 음수=디버프)")]
    [Tooltip("오라를 줄 범위. None 이면 오라 없음")]
    [SerializeField] private ECardAuraScope _buffScope = ECardAuraScope.Adjacent8;
    [SerializeField] private EStatType _buffStat = EStatType.Damage;
    [SerializeField] private EStatModifierType _buffModifierType = EStatModifierType.Flat;
    [Tooltip("오라 수치. 양수=버프, 음수=디버프. Flat=정수 / Percent=비율")]
    [SerializeField] private float _buffValue = 1f;

    [Header("공통")]
    [Tooltip("ON 상태일 때만 오라 적용. false 면 배치만 해도 적용")]
    [SerializeField] private bool _activeOnly = true;

    [NonSerialized] private string _buffKey;
    [NonSerialized] private List<Card> _scratch = new List<Card>(16);
    [NonSerialized] private List<Card> _affectedCards = new List<Card>(16);

    public override ECardEffectFlag EffectFlag => ECardEffectFlag.ApplyBuff;
    public ECardAuraScope BuffScope => _buffScope;

    public override UniTask ExecuteAsync(CardEffectContext context, CancellationToken token)
    {
        return UniTask.CompletedTask;
    }

    public override UniTask OnOwnerActivationChangedAsync(
        CardRuntimeEventContext context, bool isActive, CancellationToken token)
    {
        return RefreshAura(context, isActive);
    }

    public override UniTask OnOwnerRemovedAsync(CardRuntimeEventContext context, CancellationToken token)
    {
        return RefreshAura(context, false);
    }

    public override UniTask OnOwnerPlacedAsync(CardRuntimeEventContext context, CancellationToken token)
    {
        Card owner = context.Owner;
        bool shouldApply = !_activeOnly || (owner != null && owner.GridState.IsActivated);
        return RefreshAura(context, shouldApply);
    }

    public override UniTask OnGridTopologyChangedAsync(CardRuntimeEventContext context, CancellationToken token)
    {
        bool shouldApply = !_activeOnly || (context.Owner != null && context.Owner.GridState.IsActivated);
        return RefreshAura(context, shouldApply);
    }

    public override CardEffectBase Clone()
    {
        TotemAuraEffect clone = (TotemAuraEffect)base.Clone();
        clone._buffKey = null;
        clone._scratch = new List<Card>(16);
        clone._affectedCards = new List<Card>(16);
        return clone;
    }

    private UniTask RefreshAura(CardRuntimeEventContext context, bool shouldApply)
    {
        Card owner = context.Owner;
        GridManager grid = context.Service != null ? context.Service.Grid : null;
        if (owner == null || grid == null)
        {
            return UniTask.CompletedTask;
        }

        EnsureKeys(owner);

        // 모든 배치 카드에서 이 토템의 오라 키를 먼저 거둔다 (재계산 전 정리).
        // 그리드를 이미 떠난 카드도 포함해야 묘지에서 재드로우된 뒤 오라가 남지 않는다.
        for (int i = 0; i < _affectedCards.Count; i++)
        {
            Card affected = _affectedCards[i];
            if (affected == null) continue;
            affected.Stats.RemoveModifiersBySource(_buffKey);
        }
        _affectedCards.Clear();

        if (!shouldApply)
        {
            return UniTask.CompletedTask;
        }

        // 오라 적용 (수치 부호로 버프/디버프 결정).
        ApplyLayer(grid, owner, _buffScope, _buffStat, _buffModifierType, _buffValue, _buffKey);

        return UniTask.CompletedTask;
    }

    /// <summary>오라를 범위 내 카드에 부여. scope=None 또는 값 0 이면 생략.</summary>
    private void ApplyLayer(
        GridManager grid, Card owner,
        ECardAuraScope scope, EStatType stat, EStatModifierType modType, float value, string sourceKey)
    {
        if (scope == ECardAuraScope.None || Mathf.Approximately(value, 0f))
        {
            return;
        }

        _scratch.Clear();
        grid.GetCardsInAura(owner, scope, _scratch);
        for (int i = 0; i < _scratch.Count; i++)
        {
            Card target = _scratch[i];
            if (target == null || target == owner) continue;
            target.Stats.AddModifier(CreateModifier(stat, modType, value, sourceKey));
            _affectedCards.Add(target);
        }
    }

    private void EnsureKeys(Card owner)
    {
        if (string.IsNullOrEmpty(_buffKey))
        {
            _buffKey = $"TotemAura:{owner.CardId}:{GetHashCode()}";
        }
    }

    private static StatModifier CreateModifier(EStatType stat, EStatModifierType modType, float value, string sourceKey)
    {
        return modType switch
        {
            EStatModifierType.PercentAdd => StatModifier.PercentAdd(stat, value, source: sourceKey),
            EStatModifierType.PercentMult => StatModifier.PercentMult(stat, value, source: sourceKey),
            _ => StatModifier.Flat(stat, value, source: sourceKey),
        };
    }

#if UNITY_EDITOR
    /// <summary>amount=오라 수치(양수=버프/음수=디버프). 범위·스탯은 EditorImportAura 로 주입.</summary>
    public override void ImportNumeric(int amount, int secondaryValue)
    {
        _buffValue = amount;
    }

    /// <summary>
    /// 오라 주입 (빌더 파싱용). 수치 부호로 버프(양수)/디버프(음수)를 표현한다.
    /// </summary>
    public void EditorImportAura(
        ECardAuraScope scope,
        EStatType statType,
        EStatModifierType modifierType,
        float modifierValue,
        bool activeOnly)
    {
        _buffScope = scope;
        _buffStat = statType;
        _buffModifierType = modifierType;
        _buffValue = modifierValue;
        _activeOnly = activeOnly;
    }
#endif
}
