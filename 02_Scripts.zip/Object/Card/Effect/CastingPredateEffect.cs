// =================================================================
// [스크립트 목적]  캐스팅 payload 실행 시점에 화살표 방향 카드를 포식하고,
//                  포식한 수만큼 같은 payload 안의 DamageEffect 를 강화한다.
// [주요 변수]      - _damagePerConsumedCard : 포식 1장당 얻는 Damage 보너스
// [의존 관계]      - CardDirectionUtility.Collect 로 화살표 방향 카드 수집
//                  - ICardRuntimeEventService.DiscardGridCardAsync 로 그리드 카드 묘지 이동
//                  - ICardRuntimeEventService.RegisterDispatchModifierCleanup 로 payload 종료 정리
// [설계 노트]      - ForbiddenRitualEffect 와 달리 배치/ON hook 을 사용하지 않는다.
//                  - 캐스팅 완료 시 원본 카드의 현재 효과 인스턴스에서 실행되어 누적 상태를 유지한다.
// =================================================================

using System;
using System.Collections.Generic;
using System.Threading;
using Cysharp.Threading.Tasks;
using UnityEngine;

/// <summary>
/// 캐스팅 완료 시점에 화살표 방향 카드를 묘지로 포식하고, 같은 dispatch 안의 Damage 를 임시 강화한다.
/// 강화 모디파이어는 dispatch 종료 시 즉시 제거되므로 뒤따르는 DamageEffect 전용 버프로 동작한다.
/// </summary>
[Serializable]
public sealed class CastingPredateEffect : CardEffectBase
{
    [Header("캐스팅 포식 설정")]
    [Tooltip("포식(소비)한 카드 1장당 같은 payload 안에서 얻는 Damage 보너스")]
    [Min(0)]
    [SerializeField] private int _damagePerConsumedCard = 1;

    [NonSerialized] private List<Card> _scratch = new List<Card>(8);
    [NonSerialized] private string _sourceKey;

    // 이 카드가 삼킨 카드의 누적 장수. 업적 "하나의 포식 카드로 N장" 판정용.
    // 그리드를 떠나면(OnLeaveGrid) 초기화된다.
    [NonSerialized] private int _totalDevoured;

    public override ECardEffectFlag EffectFlag => ECardEffectFlag.ApplyBuff;
    public override DescValue DescAmount => new DescValue(_damagePerConsumedCard);

    public CastingPredateEffect()
    {
        _targetType = ETargetType.None;
        _triggerPhase = ETriggerPhase.BattleAttack;
    }

    public override async UniTask ExecuteAsync(CardEffectContext context, CancellationToken token)
    {
        Card owner = context?.Source;
        ICardRuntimeEventService runtimeService = context?.RuntimeService;
        GridManager grid = runtimeService?.Grid;
        if (owner == null || runtimeService == null || grid == null || _damagePerConsumedCard <= 0)
        {
            return;
        }

        CardDirectionUtility.Collect(grid, owner, _scratch);
        if (_scratch.Count == 0)
        {
            return;
        }

        Card[] targets = _scratch.ToArray();
        int consumed = 0;

        for (int i = 0; i < targets.Length; i++)
        {
            Card target = targets[i];
            if (target == null || target == owner)
            {
                continue;
            }

            await runtimeService.DiscardGridCardAsync(target, token);
            if (token.IsCancellationRequested)
            {
                return;
            }

            consumed++;
        }

        if (consumed <= 0)
        {
            return;
        }

        EnsureSourceKey(owner);
        int bonus = consumed * _damagePerConsumedCard;
        owner.Stats.AddModifier(StatModifier.Flat(
            EStatType.Damage,
            bonus,
            EStatModifierLifetime.Transient,
            _sourceKey));
        runtimeService.RegisterDispatchModifierCleanup(owner, _sourceKey);

        // 업적 신호: 이번 1회 포식 장수(최대 8 = 8방향) + 이 카드가 삼킨 누적 장수.
        _totalDevoured += consumed;
        if (EventManager.HasInstance)
            EventManager.Instance.Publish(new PredationSignal(consumed, _totalDevoured));

#if UNITY_EDITOR || DEVELOPMENT_BUILD
        Debug.Log($"[CastingPredate] {owner.CardId} 포식 {consumed}장 → 이번 payload Damage +{bonus}");
#endif
    }

    /// <summary>그리드에서 내려가면 누적 포식 장수를 초기화한다(업적 판정 기준 일치).</summary>
    public override UniTask OnOwnerRemovedAsync(CardRuntimeEventContext context, CancellationToken token)
    {
        _totalDevoured = 0;
        return UniTask.CompletedTask;
    }

    private void EnsureSourceKey(Card owner)
    {
        if (string.IsNullOrEmpty(_sourceKey))
        {
            _sourceKey = $"CastingPredate:{owner.CardId}:{GetHashCode()}";
        }
    }

    public override CardEffectBase Clone()
    {
        CastingPredateEffect clone = (CastingPredateEffect)base.Clone();
        clone._scratch = new List<Card>(8);
        clone._sourceKey = null;
        clone._totalDevoured = 0; // 새 카드 인스턴스는 누적 포식 장수도 새로 센다.
        return clone;
    }

#if UNITY_EDITOR
    public override void ImportNumeric(int amount, int secondaryValue)
    {
        _damagePerConsumedCard = Mathf.Max(0, amount);
    }
#endif
}
