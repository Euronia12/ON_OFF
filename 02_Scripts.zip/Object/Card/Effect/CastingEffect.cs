using System;
using System.Threading;
using Cysharp.Threading.Tasks;
using UnityEngine;

[Serializable]
public sealed class CastingEffect : CardEffectBase
{
    [Header("캐스팅 설정")]
    [Min(1)]
    [SerializeField] private int _requiredCount = 3;

    [Tooltip("카운트 완료 시 실행할 동일 카드 내 후속 페이즈")]
    [SerializeField] private ETriggerPhase _payloadPhase = ETriggerPhase.BattleAttack;

    public int RequiredCount => _requiredCount;
    public ETriggerPhase PayloadPhase => _payloadPhase;

    public override ECardEffectFlag EffectFlag => ECardEffectFlag.None;
    public override DescValue DescAmount => new DescValue(_requiredCount);

    public override UniTask ExecuteAsync(CardEffectContext context, CancellationToken token)
    {
        context.RuntimeService?.RegisterCastingPayload(context.Source, this);
        return UniTask.CompletedTask;
    }

#if UNITY_EDITOR
    public override void ImportNumeric(int amount, int secondaryValue)
    {
        _requiredCount = Mathf.Max(1, amount);
    }

    public void EditorImportCasting(
        int requiredCount,
        ETriggerPhase payloadPhase)
    {
        _requiredCount = Mathf.Max(1, requiredCount);
        _payloadPhase = payloadPhase;
    }
#endif
}
