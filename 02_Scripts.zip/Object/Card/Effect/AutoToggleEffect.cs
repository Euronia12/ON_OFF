using System;
using System.Threading;
using Cysharp.Threading.Tasks;
using UnityEngine;

/// <summary>
/// 최상위 토글 연쇄 종료 시 현재 ON 카드 수가 임계값 이상이면 소유 카드를 토글한다.
/// 조건을 벗어났다가 다시 진입해야 재발동한다.
/// </summary>
[Serializable]
public sealed class AutoToggleEffect : CardEffectBase
{
    [Header("자동 토글 설정")]
    [Tooltip("체인 종료 시 현재 ON 카드 수가 이 값 이상이면 자신을 토글")]
    [Min(1)]
    [SerializeField] private int _threshold = 5;

    [NonSerialized] private bool _armed = true;

    public int Threshold => _threshold;
    public override ECardEffectFlag EffectFlag => ECardEffectFlag.Toggle;

    public override UniTask ExecuteAsync(CardEffectContext context, CancellationToken token)
    {
        return UniTask.CompletedTask;
    }

    public override DescValue DescThreshold => new DescValue(_threshold);

    /// <summary>현재 조건을 반영하고 이번 체인 종료에서 발동해야 하는지 반환한다.</summary>
    public bool Evaluate(int activatedCardCount)
    {
        if (activatedCardCount < _threshold)
        {
            _armed = true;
            return false;
        }

        if (!_armed)
        {
            return false;
        }

        _armed = false;
        return true;
    }

    public override UniTask OnOwnerRemovedAsync(
        CardRuntimeEventContext context,
        CancellationToken token)
    {
        _armed = true;
        return UniTask.CompletedTask;
    }

    public override CardEffectBase Clone()
    {
        AutoToggleEffect clone = (AutoToggleEffect)base.Clone();
        clone._armed = true;
        return clone;
    }

#if UNITY_EDITOR
    public override void ImportNumeric(int amount, int secondaryValue)
    {
        _threshold = Mathf.Max(1, amount);
    }

    public void EditorImportThreshold(int threshold)
    {
        _threshold = Mathf.Max(1, threshold);
    }
#endif
}
