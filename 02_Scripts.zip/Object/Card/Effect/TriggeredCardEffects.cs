using System;
using System.Collections.Generic;
using System.Threading;
using Cysharp.Threading.Tasks;
using UnityEngine;

[Serializable]
public sealed class GlassBladeDecayEffect : CardEffectBase
{
    [Min(0)]
    [SerializeField] private int _damageLossPerTrigger = 1;

    [NonSerialized] private int _totalLoss;
    [NonSerialized] private string _sourceKey;

    public override ECardEffectFlag EffectFlag => ECardEffectFlag.ApplyDebuff;
    public override DescValue DescAmount => new DescValue(_damageLossPerTrigger);
    public int CurrentDamageLoss => _totalLoss;

    public override UniTask ExecuteAsync(CardEffectContext context, CancellationToken token)
    {
        Card owner = context.Source;
        if (owner == null || _damageLossPerTrigger <= 0)
            return UniTask.CompletedTask;

        // 감소 대상은 이 카드의 DamageEffect.amount 뿐이다.
        // 토템 등 외부 모디파이어는 감소시키지 않고, 고유 피해가 0이면 더 누적하지 않는다.
        if (!owner.TryGetPreviewStat(EStatType.Damage, out int intrinsicDamage) || intrinsicDamage <= 0)
            return UniTask.CompletedTask;

        int remainingIntrinsicDamage = Mathf.Max(0, intrinsicDamage - _totalLoss);
        if (remainingIntrinsicDamage <= 0)
            return UniTask.CompletedTask;

        _sourceKey ??= $"GlassBladeDecay:{owner.CardId}:{GetHashCode()}";
        _totalLoss += Mathf.Min(_damageLossPerTrigger, remainingIntrinsicDamage);
        owner.Stats.RemoveModifiersBySource(_sourceKey);
        owner.Stats.AddModifier(StatModifier.Flat(
            EStatType.Damage,
            -_totalLoss,
            EStatModifierLifetime.Transient,
            _sourceKey));

        // 외부 버프와 무관하게 고유 피해가 처음 0에 도달한 순간 업적 신호를 발행한다.
        if (_totalLoss >= intrinsicDamage && EventManager.HasInstance)
            EventManager.Instance.Publish(new GlassBladeDamageZeroSignal());

        return UniTask.CompletedTask;
    }

    public override void ClearDurationState(Card owner, EEffectDuration duration)
    {
        if (_duration != duration || owner == null) return;
        if (!string.IsNullOrEmpty(_sourceKey))
            owner.Stats.RemoveModifiersBySource(_sourceKey);
        _totalLoss = 0;
    }

    public override CardEffectBase Clone()
    {
        GlassBladeDecayEffect clone = (GlassBladeDecayEffect)base.Clone();
        clone._totalLoss = 0;
        clone._sourceKey = null;
        return clone;
    }

#if UNITY_EDITOR
    public override void ImportNumeric(int amount, int secondaryValue)
    {
        _damageLossPerTrigger = Mathf.Max(0, amount);
    }
#endif
}

[Serializable]
public sealed class FinisherDamageEffect : CardEffectBase, IDeferredDamageEffect
{
    [Min(0)]
    [SerializeField] private int _damagePerCard = 3;
    [SerializeField] private EGridCountScope _countScope = EGridCountScope.Total;

    public override ECardEffectFlag EffectFlag => ECardEffectFlag.Damage;

    public override async UniTask ExecuteAsync(CardEffectContext context, CancellationToken token)
    {
        DeferredDamagePayload payload = CreateDeferredDamagePayload(context);
        await payload.ApplyAsync(token);
    }

    public DeferredDamagePayload CreateDeferredDamagePayload(CardEffectContext context)
    {
        return new DeferredDamagePayload(
            new List<ICombatActor>(context.Targets),
            ResolveDamage(context),
            1,
            0f);
    }

    private int ResolveDamage(CardEffectContext context)
    {
        if (context.Source == null || context.StatCalculator == null)
            return 0;

        int count = context.StatCalculator.GetGridCount(context.Source, _countScope);
        return context.CalculateEffectAmount(
            EStatType.Damage, Mathf.Max(0, count * _damagePerCard));
    }

#if UNITY_EDITOR
    public override void ImportNumeric(int amount, int secondaryValue)
    {
        _damagePerCard = Mathf.Max(0, amount);
    }

    public void EditorImportScope(EGridCountScope scope)
    {
        _countScope = scope == EGridCountScope.InactiveTotal
            ? EGridCountScope.InactiveTotal
            : EGridCountScope.Total;
    }
#endif
}

[Serializable]
public sealed class DualStateTriggerEffect : CardEffectBase
{
    [SerializeField] private ETriggerPhase _onPhase = ETriggerPhase.BattleAttack;
    [SerializeField] private ETriggerPhase _offPhase = ETriggerPhase.BattleResolve;

    public override ECardEffectFlag EffectFlag => ECardEffectFlag.ApplyBuff;

    public override UniTask ExecuteAsync(CardEffectContext context, CancellationToken token)
        => UniTask.CompletedTask;

    public override async UniTask OnOwnerActivationChangedAsync(
        CardRuntimeEventContext context,
        bool isActive,
        CancellationToken token)
    {
        if (context.Owner == null || context.Service == null) return;
        await context.Service.DispatchPhaseAsync(
            context.Owner,
            isActive ? _onPhase : _offPhase,
            token);
    }

#if UNITY_EDITOR
    public override void ImportNumeric(int amount, int offPhase)
    {
        if (Enum.IsDefined(typeof(ETriggerPhase), amount))
            _onPhase = (ETriggerPhase)amount;
        if (Enum.IsDefined(typeof(ETriggerPhase), offPhase))
            _offPhase = (ETriggerPhase)offPhase;
    }

    public void EditorImportPhases(ETriggerPhase onPhase, ETriggerPhase offPhase)
    {
        _onPhase = onPhase;
        _offPhase = offPhase;
    }
#endif
}

[Serializable]
public sealed class SelfOnTriggerEffect : CardEffectBase
{
    [Min(1)]
    [SerializeField] private int _requiredCount = 3;
    [SerializeField] private ETriggerPhase _payloadPhase = ETriggerPhase.BattleAttack;
    [SerializeField] private bool _resetEachTurn;

    [NonSerialized] private int _count;

    public override ECardEffectFlag EffectFlag => ECardEffectFlag.ApplyBuff;

    public override UniTask ExecuteAsync(CardEffectContext context, CancellationToken token)
        => UniTask.CompletedTask;

    public override async UniTask OnOwnerActivationChangedAsync(
        CardRuntimeEventContext context,
        bool isActive,
        CancellationToken token)
    {
        if (!isActive || context.Owner == null || context.Service == null) return;

        _count++;
        if (_count < _requiredCount) return;

        _count = 0;
        await context.Service.DispatchPhaseAsync(context.Owner, _payloadPhase, token);
    }

    public override void ClearDurationState(Card owner, EEffectDuration duration)
    {
        if (_resetEachTurn && duration == EEffectDuration.EndOfTurn)
            _count = 0;
    }

    public override UniTask OnOwnerRemovedAsync(
        CardRuntimeEventContext context,
        CancellationToken token)
    {
        _count = 0;
        return UniTask.CompletedTask;
    }

    public override CardEffectBase Clone()
    {
        SelfOnTriggerEffect clone = (SelfOnTriggerEffect)base.Clone();
        clone._count = 0;
        return clone;
    }

#if UNITY_EDITOR
    public override void ImportNumeric(int amount, int secondaryValue)
    {
        _requiredCount = Mathf.Max(1, amount);
    }

    public void EditorImportTrigger(
        int requiredCount,
        ETriggerPhase payloadPhase,
        bool resetEachTurn)
    {
        _requiredCount = Mathf.Max(1, requiredCount);
        _payloadPhase = payloadPhase;
        _resetEachTurn = resetEachTurn;
    }
#endif
}
