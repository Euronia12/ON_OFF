// =================================================================
// [스크립트 목적]  마나폭발. 남은 마나(에너지)를 타격 횟수로 삼아 amount 데미지를 마나 수만큼 다단히트
// [주요 변수]      - _amount : 타격 1회당 기본 데미지
// [의존 관계]      - CardEffectBase 상속, context.Caster(PlayerActor) 의 Energy 읽기/소비
//                  - ICombatActor.TakeDamage 로 적에게 피해
// [설계 노트]      - 코스트 X 카드: 에너지가 1 이상일 때만 배치 가능하며, 배치 cost=0.
//                    효과가 남은 마나를 전량 소비
//                    (UI 는 Card.IsVariableCost → ManaBurst 플래그로 "X" 표기)
//                  - 배치 시 SpendEnergy(0) 후 에너지가 그대로 남아 있어 실행 시점에 전량 소비 가능
//                  - 마나 = 타격 횟수. 방어도 흡수가 타격마다 개별 적용 → 단일 합산과 체감이 다름
// =================================================================

using System;
using System.Collections.Generic;
using System.Threading;
using Cysharp.Threading.Tasks;
using UnityEngine;

/// <summary>
/// 남은 마나를 전부 소비하고, 소비한 마나량에 비례한 데미지를 적에게 주는 효과.
/// 마나가 0이면 배치할 수 없으며, 실행 시에는 안전하게 아무 일도 하지 않는다.
/// </summary>
[Serializable]
public sealed class ManaBurstEffect : CardEffectBase, IDeferredDamageEffect
{
    [Header("마나폭발 설정")]
    [Tooltip("타격 1회당 기본 데미지. 남은 마나 수만큼 이 데미지로 다단히트한다")]
    [Min(0)]
    [SerializeField] private int _amount = 1;

    [Tooltip("히트 사이 추가 대기 시간. 0이면 투사체 도착 직후 다음 발이 나갑니다.")]
    [Min(0f)]
    [SerializeField] private float _perHitDelay = 0f;

    public override ECardEffectFlag EffectFlag => ECardEffectFlag.ManaBurst;

    public override UniTask ExecuteAsync(CardEffectContext context, CancellationToken token)
    {
        if (context.Caster is not PlayerActor player)
        {
            return UniTask.CompletedTask;
        }

        int hits = player.Energy; // 마나 = 타격 횟수
        if (hits <= 0)
        {
            return UniTask.CompletedTask;
        }

        int perHit = context.CalculateEffectAmount(EStatType.Damage, _amount); // 토템 등 피해 modifier 포함
        List<ICombatActor> targets = context.Targets;
        for (int h = 0; h < hits; h++)
        {
            for (int i = 0; i < targets.Count; i++)
            {
                ICombatActor target = targets[i];
                if (target != null && target.IsAlive)
                {
                    target.TakeDamage(perHit);
                }
            }
        }

        player.SpendEnergy(hits); // 남은 마나 전량 소비

#if UNITY_EDITOR || DEVELOPMENT_BUILD
        Debug.Log($"[Card Action] {context.Source?.CardId ?? "(unknown)"} 카드가 " +
            $"마나 {hits} 소비 → {perHit} 피해 x{hits}회 (대상 {targets.Count})");
#endif
        return UniTask.CompletedTask;
    }

    public DeferredDamagePayload CreateDeferredDamagePayload(CardEffectContext context)
    {
        if (context.Caster is not PlayerActor player)
        {
            return new DeferredDamagePayload(Array.Empty<ICombatActor>(), 0, 1, 0f);
        }

        int hits = player.Energy;
        if (hits <= 0)
        {
            return new DeferredDamagePayload(Array.Empty<ICombatActor>(), 0, 1, 0f);
        }

        int perHit = context.CalculateEffectAmount(EStatType.Damage, _amount);
        List<ICombatActor> targets = new List<ICombatActor>(context.Targets);
        player.SpendEnergy(hits);

#if UNITY_EDITOR || DEVELOPMENT_BUILD
        Debug.Log($"[Card Action] {context.Source?.CardId ?? "(unknown)"} ManaBurst 예약: " +
            $"mana {hits} -> {perHit} damage x{hits} (targets {targets.Count})");
#endif
        return new DeferredDamagePayload(targets, perHit, hits, _perHitDelay);
    }

    public override DescValue DescAmount => new DescValue(_amount, EStatType.Damage);
    public override DescValue DescHitCount => new DescValue(EDescDynamicValue.CurrentEnergy);

#if UNITY_EDITOR
    /// <summary>amount=소비 마나 1당 데미지 계수.</summary>
    public override void ImportNumeric(int amount, int secondaryValue)
    {
        _amount = Mathf.Max(0, amount);
    }
#endif
}
