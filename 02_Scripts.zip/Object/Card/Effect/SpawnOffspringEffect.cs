// =================================================================
// [스크립트 목적]  새끼낳기. 카드가 ON(OnPlay) 될 때마다 지정 카드(SO)를 조회해 복제하여 핸드에 생성
// [주요 변수]      - _spawnCardId : 생성할 새끼카드의 cardId (CSV 에 deckType=None 으로 정의)
// [의존 관계]      - CardEffectBase 상속, ExecuteAsync(OnPlay) 에서 발동
//                  - DataManager.GetData<CardDataSO>(id) → CardFactory.CreateFromSO 로 복제
//                  - context.Service(ICardGameService).AddCardToHand 로 손패에 추가
// [설계 노트]      - 새끼카드는 CSV 에 deckType=None/pools=None 으로 정의 → 덱/보상엔 안 나오되 SO 로 존재
//                  - 생성 직후 SetVanishOnDiscard(true) — 묘지로 갈 때 소멸(그리드 보존 시 유지)
//                  - SetBattleDeckOwner(PlayerTemporary) — 전투 한정, 런 원본 덱 미편입
//                  - OnPlay 는 ChainExecutor 가 카드 ON 마다 재디스패치 → "켜질때마다 매번"과 일치
// =================================================================

using System;
using System.Threading;
using Cysharp.Threading.Tasks;
using UnityEngine;

/// <summary>
/// 카드가 ON(OnPlay) 될 때마다 지정 cardId 의 새끼카드를 SO 에서 복제해 손패에 생성하는 효과.
/// 생성된 카드는 묘지로 갈 때 소멸하며 런 원본 덱에는 편입되지 않는다 (전투 한정).
/// </summary>
[Serializable]
public sealed class SpawnOffspringEffect : CardEffectBase
{
    [Header("새끼낳기 설정")]
    [Tooltip("생성할 새끼카드의 cardId. CSV 에 deckType=None/pools=None 으로 정의해 둘 것")]
    [SerializeField] private string _spawnCardId = string.Empty;

    public override ECardEffectFlag EffectFlag => ECardEffectFlag.Spawn;

    /// <summary>이 효과가 생성하는 새끼카드의 cardId. 데이터(CSV) 기준이라 하드코딩 없이 조회 가능.</summary>
    public string SpawnCardId => _spawnCardId;

    /// <summary>ON(OnPlay) 될 때마다 새끼카드 1장을 SO 에서 복제해 손패에 생성 (상한 없음).</summary>
    public override UniTask ExecuteAsync(CardEffectContext context, CancellationToken token)
    {
        ICardGameService gameService = context.Service;
        if (gameService == null || string.IsNullOrEmpty(_spawnCardId) || !DataManager.HasInstance)
        {
            return UniTask.CompletedTask;
        }

        CardDataSO data = DataManager.Instance.GetData<CardDataSO>(_spawnCardId);
        if (data == null)
        {
#if UNITY_EDITOR || DEVELOPMENT_BUILD
            Debug.LogWarning($"[SpawnOffspringEffect] 새끼카드 '{_spawnCardId}' SO 를 찾지 못했습니다.");
#endif
            return UniTask.CompletedTask;
        }

        Card offspring = CardFactory.CreateFromSO(data);
        if (offspring != null)
        {
            offspring.SetBattleDeckOwner(EBattleDeckOwner.PlayerTemporary);
            offspring.SetVanishOnDiscard(true);
            gameService.AddCardToHand(offspring);
#if UNITY_EDITOR || DEVELOPMENT_BUILD
            Debug.Log($"[Card Action] {context.Source?.CardId ?? "(unknown)"} 카드가 " +
                $"새끼카드 '{_spawnCardId}' 를 손패에 생성함");
#endif
        }

        return UniTask.CompletedTask;
    }

#if UNITY_EDITOR
    /// <summary>수치 미사용. 생성 대상은 spawnCardId 컬럼으로 지정한다.</summary>
    public override void ImportNumeric(int amount, int secondaryValue)
    {
    }

    /// <summary>빌더가 CSV 의 spawnCardId 컬럼을 주입.</summary>
    public void EditorImportSpawn(string spawnCardId)
    {
        _spawnCardId = spawnCardId ?? string.Empty;
    }
#endif
}
