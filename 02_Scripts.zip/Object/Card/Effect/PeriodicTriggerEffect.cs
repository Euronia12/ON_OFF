﻿// =================================================================
// [스크립트 목적]  N회 ON 마다 후속 페이즈를 1회 발동시키는 주기형 트리거
// [주요 변수]      - _interval     : 발동 주기 (N회 ON 마다)
//                  - _payloadPhase : 임계 도달 시 실행할 동일 카드 내 후속 페이즈
//                  - _resetEachTurn: 턴 종료 시 카운트 초기화 여부
// [의존 관계]      - CardEffectBase 상속, context.Service.DispatchPhaseAsync 호출
// [설계 노트]      - ★ 수정: 기존엔 _activationCount 가 전투 내내 누적 →
//                    "3회마다" 가 턴을 넘겨 누적되어 의도와 어긋날 수 있었음.
//                    → _resetEachTurn(기본 false) 추가 + OnTurnEnd 훅에서 리셋 가능.
//                  - EffectFlag 를 None → ApplyBuff 성격으로 노출(UI/툴팁 식별용).
// =================================================================

using System;
using System.Threading;
using Cysharp.Threading.Tasks;
using UnityEngine;

/// <summary>
/// 카드가 _interval 회 ON 될 때마다 _payloadPhase 를 1회 발동한다 (예: 3회마다 강타).
/// _resetEachTurn 이 true 면 매 턴 카운트를 0으로 되돌려 "턴 안에서 N회" 의미가 된다.
/// </summary>
[Serializable]
public sealed class PeriodicTriggerEffect : CardEffectBase
{
    [Header("주기 트리거 설정")]
    [Tooltip("발동 주기. N회 ON 마다 후속 페이즈 1회 실행")]
    [Min(1)]
    [SerializeField] private int _interval = 3;

    [Tooltip("임계 도달 시 실행할 동일 카드 내 후속 페이즈")]
    [SerializeField] private ETriggerPhase _payloadPhase = ETriggerPhase.BattleAttack;

    [Tooltip("턴 종료 시 ON 카운트를 0으로 초기화할지. true=턴당 N회 / false=전투 누적")]
    [SerializeField] private bool _resetEachTurn = false;

    [NonSerialized] private int _activationCount;
    [NonSerialized] private bool _hasEnteredGrid;

    // EffectFlag 를 노출해 UI/필터가 "효과 카드" 로 인식하게 한다.
    public override ECardEffectFlag EffectFlag => ECardEffectFlag.ApplyBuff;

    public override UniTask ExecuteAsync(CardEffectContext context, CancellationToken token)
    {
        return UniTask.CompletedTask;
    }

    public override DescValue DescThreshold => new DescValue(_interval);

    public override async UniTask OnOwnerActivationChangedAsync(
        CardRuntimeEventContext context, bool isActive, CancellationToken token)
    {
        if (!isActive || context.Owner == null || context.Service == null)
        {
            return;
        }

        if (!_hasEnteredGrid)
        {
            _hasEnteredGrid = true;
            return;
        }

        _activationCount++;
        if (_activationCount % _interval == 0)
        {
            await context.Service.DispatchPhaseAsync(context.Owner, _payloadPhase, token);
        }
    }

    /// <summary>턴 종료 시 카운트 리셋 (옵션). 그리드 회수 시에도 안전하게 0 으로.</summary>
    public override UniTask OnOwnerRemovedAsync(CardRuntimeEventContext context, CancellationToken token)
    {
        if (_resetEachTurn)
        {
            _activationCount = 0;
        }
        _hasEnteredGrid = false;
        return UniTask.CompletedTask;
    }

    public override CardEffectBase Clone()
    {
        PeriodicTriggerEffect clone = (PeriodicTriggerEffect)base.Clone();
        clone._activationCount = 0;
        clone._hasEnteredGrid = false;
        return clone;
    }

#if UNITY_EDITOR
    /// <summary>amount=주기(N). 후속 페이즈는 payloadPhase 컬럼으로 설정한다.</summary>
    public override void ImportNumeric(int amount, int secondaryValue)
    {
        _interval = Mathf.Max(1, amount);
    }

    public void EditorImportTrigger(int interval, ETriggerPhase payloadPhase, bool resetEachTurn = false)
    {
        _interval = Mathf.Max(1, interval);
        _payloadPhase = payloadPhase;
        _resetEachTurn = resetEachTurn;
    }
#endif
}
