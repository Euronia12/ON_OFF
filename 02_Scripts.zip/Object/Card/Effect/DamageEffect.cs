// =================================================================
// [스크립트 목적]  데미지 효과 (공격). 데미지 수치는 카드 스탯에서 산출, 다단히트 지원
// [주요 변수]      - _hitCount     : 히트 횟수 (다단히트, 1이면 단일타) — 수치 아닌 횟수
//                  - _perHitDelay  : 히트 간 연출 딜레이(초)
//                  - _gridScope    : 그리드 집계 범위 (데미지 보너스 합류). None 이면 미사용
// [의존 관계]      - CardEffectBase 상속, context.StatCalculator 로 데미지 산출
//                  - ICombatActor.TakeDamage 호출
// [설계 노트]      - 데미지 "수치"는 효과가 갖지 않고 Card.Stats[Damage] 일원화
//                    → Base/강화/버프/그리드 보너스가 자동 반영 (단일 진실 원천)
//                  - 효과는 "몇 번 때리나(_hitCount)"와 "어떤 그리드 범위(_gridScope)"만 보유
// =================================================================

using Cysharp.Threading.Tasks;
using System;
using System.Collections.Generic;
using System.Threading;
using UnityEngine;

/// <summary>
/// 데미지 효과. "3 × 5" 다단히트를 _hitCount 로 표현하되, 1히트당 데미지는 카드 스탯에서 가져온다.
/// 단일타는 _hitCount = 1. 각 히트마다 연출 텀이 필요하면 _perHitDelay 사용.
/// _gridScope 가 None 이 아니면 그리드 집계 보너스가 데미지에 합류된다 (인싸형·카운터형 등).
/// </summary>
[Serializable]
public sealed class DamageEffect : CardEffectBase, IDeferredDamageEffect
{
    [Header("데미지 설정")]
    [Tooltip("1히트당 기본 데미지. effect 가 직접 소유하는 기준 수치")]
    [Min(0)]
    [SerializeField] private int _amount = 0;

    [Tooltip("히트 횟수. 다단히트용 (예: 3이면 3연타). 1이면 단일타. 데미지 수치는 카드 스탯에서 산출")]
    [Min(1)]
    [SerializeField] private int _hitCount = 1;

    [Tooltip("히트 간 연출 딜레이(초). 0이면 즉시 연타. 다단히트 연출용")]
    [Min(0f)]
    [SerializeField] private float _perHitDelay = 0f;

    [Header("그리드 보너스")]
    [Tooltip("데미지에 합류할 그리드 집계 범위. None 이면 그리드 보너스 없음")]
    [SerializeField] private EGridCountScope _gridScope = EGridCountScope.None;

    [Tooltip("그리드 집계 1개당 추가 데미지 가중치 (zip 의 ×value). _gridScope 사용 시")]
    [Min(0f)]
    [SerializeField] private float _gridWeight = 1f;

    public override ECardEffectFlag EffectFlag => ECardEffectFlag.Damage;

    public override async UniTask ExecuteAsync(CardEffectContext context, CancellationToken token)
    {
        DeferredDamagePayload payload = CreateDeferredDamagePayload(context);
        await payload.ApplyAsync(token);

#if UNITY_EDITOR || DEVELOPMENT_BUILD
        int damage = ResolveDamage(context);
        Debug.Log($"[Card Action] {context.Source?.CardId ?? "(unknown)"} 카드가 " +
            $"{damage * _hitCount} 피해를 입힘 ({damage} x {_hitCount}, 대상 {context.Targets.Count})");
#endif
    }

    public DeferredDamagePayload CreateDeferredDamagePayload(CardEffectContext context)
    {
        return new DeferredDamagePayload(
            new List<ICombatActor>(context.Targets),
            ResolveDamage(context),
            _hitCount,
            _perHitDelay);
    }

    /// <summary>
    /// 1히트당 데미지를 effect 수치 + 카드 modifier 계층으로 산출.
    /// 계산기·시전 카드가 없으면 0 (방어). _gridScope 가 있으면 그리드 보너스 합류.
    /// </summary>
    private int ResolveDamage(CardEffectContext context)
    {
        Card source = context.Source;
        CardStatCalculator calc = context.StatCalculator;

        if (source == null || calc == null)
        {
#if UNITY_EDITOR || DEVELOPMENT_BUILD
            Debug.LogWarning("[DealDamageEffect] Source 또는 StatCalculator 가 없어 데미지 0 처리.");
#endif
            return 0;
        }

        return _gridScope == EGridCountScope.None
            ? context.CalculateEffectAmount(EStatType.Damage, _amount)
            : context.CalculateEffectAmountWithGrid(EStatType.Damage, _amount, _gridScope, _gridWeight);
    }

#if UNITY_EDITOR
    /// <summary>amount=기본 데미지, hitCount=히트수(0이면 1로 보정).</summary>
    public override void ImportNumeric(int amount, int hitCount)
    {
        _amount = Mathf.Max(0, amount);
        _hitCount = hitCount > 0 ? hitCount : 1;
    }
#endif

    public override bool TryGetPreviewStat(EStatType statType, out int value)
    {
        value = _amount;
        return statType == EStatType.Damage && _amount > 0;
    }

    public override DescValue DescAmount => new DescValue(_amount, EStatType.Damage);
    public override DescValue DescHitCount => _hitCount > 1 ? new DescValue(_hitCount) : DescValue.None;
}
