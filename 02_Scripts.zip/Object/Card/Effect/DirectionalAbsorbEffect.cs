// =================================================================
// [스크립트 목적]  화살표 방향 카드들의 "지정 스탯" 수치를 흡수해 자신의 같은 스탯에 더한다.
//                  (공격 흡수: 대상 Damage → 자기 Damage / 방어 흡수: 대상 Block → 자기 Block)
// [주요 변수]      - _statType : 흡수할 스탯 (Damage=공격 흡수 / Block=방어 흡수)
//                  - _ratio    : 흡수 비율 (1=100%)
// [의존 관계]      - CardDirectionUtility.Collect 로 화살표 방향 이웃 수집
//                  - context.Owner.Stats 에 source 키로 모디파이어 관리
// [설계 노트]      - ★ 변경: 기존 Damage 고정 → _statType 으로 공격/방어 흡수 선택 가능.
//                    "같은 타입끼리 1:1 대응" (공격→공격, 방어→방어).
//                  - source 키로 단일 모디파이어 덮어쓰기 → 재계산/제거 시 정확히 원복.
//                  - "주변 카드 수가 많으면 증가" 는 흡수가 아니라 그리드 스케일이므로
//                    DamageEffect._gridScope=Adjacent8 를 쓸 것.
//                  - 흡수 제외 대상: 다른 흡수 카드가 흡수해서 불어난 수치, 캐스팅 분류 카드 전체.
// =================================================================

using System;
using System.Collections.Generic;
using System.Threading;
using Cysharp.Threading.Tasks;
using UnityEngine;

/// <summary>
/// 화살표가 가리키는 인접 카드들의 _statType 수치를 비율만큼 흡수해 자신의 같은 스탯에 더한다.
/// 공격 흡수면 대상 Damage 를 흡수해 자기 Damage 로, 방어 흡수면 Block→Block 으로 1:1 대응한다.
/// 흡수 결과는 source 키 단일 모디파이어로 관리되어 재계산/제거 시 정확히 원복된다.
/// </summary>
[Serializable]
public sealed class DirectionalAbsorbEffect : CardEffectBase
{
    [Header("흡수 설정")]
    [Tooltip("흡수할 스탯. Damage=공격 흡수 / Block=방어 흡수 (같은 타입끼리 대응)")]
    [SerializeField] private EStatType _statType = EStatType.Damage;

    [Tooltip("흡수 비율. 1=대상 수치 100% 흡수")]
    [Min(0f)]
    [SerializeField] private float _ratio = 1f;

    [NonSerialized] private List<Card> _scratch = new List<Card>(8);
    [NonSerialized] private string _sourceKey;

    // 모든 흡수 효과가 공유하는 출처 접두사. 다른 흡수 카드의 "흡수된 수치" 를
    // 재흡수하지 않고 기본 수치만 흡수하도록 판별하는 데 사용한다.
    private const string SourcePrefix = "DirectionalAbsorb:";

    public override ECardEffectFlag EffectFlag => ECardEffectFlag.ApplyBuff;

    public override UniTask ExecuteAsync(CardEffectContext context, CancellationToken token)
    {
        return UniTask.CompletedTask;
    }

    public override UniTask OnOwnerActivationChangedAsync(
        CardRuntimeEventContext context, bool isActive, CancellationToken token)
    {
        return RefreshAbsorb(context);
    }

    /// <summary>
    /// 주변 카드의 활성화 효과가 모두 끝난 뒤 현재 수치로 다시 흡수한다.
    /// 얼음 단도 감쇠와 토템 오라처럼 활성화 중 변경된 모디파이어를 즉시 반영한다.
    /// </summary>
    public override UniTask OnOtherCardActivatedAsync(
        CardRuntimeEventContext context, CancellationToken token)
    {
        return RefreshAbsorb(context);
    }

    /// <summary>그리드 구성이 바뀌면 흡수 대상이 달라지므로 재계산한다.</summary>
    public override UniTask OnGridTopologyChangedAsync(CardRuntimeEventContext context, CancellationToken token)
    {
        return RefreshAbsorb(context);
    }

    public override UniTask OnOwnerRemovedAsync(CardRuntimeEventContext context, CancellationToken token)
    {
        if (context.Owner != null && !string.IsNullOrEmpty(_sourceKey))
        {
            context.Owner.Stats.RemoveModifiersBySource(_sourceKey);
        }
        return UniTask.CompletedTask;
    }

    private UniTask RefreshAbsorb(CardRuntimeEventContext context)
    {
        Card owner = context.Owner;
        if (owner == null || context.Service?.Grid == null)
        {
            return UniTask.CompletedTask;
        }

        EnsureSourceKey(owner);

        // OFF 상태에서도 카드 전면 표시용 수치는 현재 그리드 기준으로 갱신한다.
        // 실제 효과 실행은 활성 카드만 대상으로 하므로 전투 효과가 추가 발동하지는 않는다.
        owner.Stats.RemoveModifiersBySource(_sourceKey); // 재계산 전 기존 흡수치 회수

        CardDirectionUtility.Collect(context.Service.Grid, owner, _scratch);
        int total = 0;
        for (int i = 0; i < _scratch.Count; i++)
        {
            Card target = _scratch[i];
            if (target == null || target == owner) continue;

            // 캐스팅 카드의 수치는 흡수하지 않는다. (흡수된 수치를 재흡수하지 못하는 것과 같은 규칙 —
            // 캐스팅은 발동 대기 중인 예약 수치라 흡수로 선취하면 이중 이득이 된다.)
            if (IsCastingCard(target)) continue;

            // 대상의 "같은 타입" 수치를 흡수. 대상이 그 스탯 프리뷰를 안 가지면 0.
            // 대상이 흡수 카드인 경우, 흡수로 불어난 수치(SourcePrefix 출처)는 제외하고
            // 기본 수치만 흡수한다.
            if (target.TryGetPreviewStat(_statType, out int statValue))
            {
                if (target.Stats != null)
                {
                    float baseValue = target.Stats.ComputeWithExtraFlatExcludingSource(
                        _statType, statValue, SourcePrefix);
                    total += Mathf.Max(0, Mathf.RoundToInt(baseValue));
                }
                else
                {
                    total += statValue;
                }
            }
        }

        if (total > 0)
        {
            owner.Stats.AddModifier(StatModifier.Flat(
                _statType, total * _ratio, EStatModifierLifetime.Transient, _sourceKey));
        }
        return UniTask.CompletedTask;
    }

    /// <summary>캐스팅 분류 카드 여부. 캐스팅 대기 수치는 흡수 대상에서 제외한다.</summary>
    private static bool IsCastingCard(Card card)
    {
        return card.Data != null && card.Data.CardType == ECardType.Casting;
    }

    private void EnsureSourceKey(Card owner)
    {
        if (string.IsNullOrEmpty(_sourceKey))
        {
            _sourceKey = $"{SourcePrefix}{owner.CardId}:{GetHashCode()}";
        }
    }

    public override CardEffectBase Clone()
    {
        DirectionalAbsorbEffect clone = (DirectionalAbsorbEffect)base.Clone();
        clone._scratch = new List<Card>(8);
        clone._sourceKey = null;
        return clone;
    }

#if UNITY_EDITOR
    /// <summary>amount=흡수 비율(0이면 1). 보조 수치 미사용.</summary>
    public override void ImportNumeric(int amount, int secondaryValue)
    {
        _ratio = amount == 0 ? 1f : amount;
    }

    /// <summary>흡수 스탯 타입 주입 (Damage=공격 흡수 / Block=방어 흡수).</summary>
    public void EditorImportAbsorb(EStatType statType)
    {
        _statType = statType;
    }
#endif
}
