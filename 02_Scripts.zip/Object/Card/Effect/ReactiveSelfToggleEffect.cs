using System;
using System.Collections.Generic;
using System.Threading;
using Cysharp.Threading.Tasks;
using UnityEngine;

[Serializable]
public sealed class ReactiveSelfToggleEffect : CardEffectBase
{
    [Header("반응형 토글")]
    [Tooltip("조건을 만족하면 자기 자신을 토글 요청")]
    [SerializeReference] private CardReactiveConditionBase _condition =
        new ReactiveAllCondition
        {
            Conditions = new List<CardReactiveConditionBase>
            {
                new ReactiveEventTypeCondition(),
                new ReactiveOwnerOnGridCondition()
            }
        };

    [NonSerialized] private BattleReactiveEventBus _bus;
    [NonSerialized] private Card _owner;

    public override ECardEffectFlag EffectFlag => ECardEffectFlag.Toggle;

    public override UniTask ExecuteAsync(CardEffectContext context, CancellationToken token)
    {
        return UniTask.CompletedTask;
    }

    public override UniTask OnOwnerPlacedAsync(CardRuntimeEventContext context, CancellationToken token)
    {
        Unsubscribe();
        _owner = context.Owner;
        _bus = context.Service?.ReactiveEvents;
        if (_bus != null)
        {
            _bus.OnEvent += HandleReactiveEvent;
        }
        return UniTask.CompletedTask;
    }

    public override UniTask OnOwnerRemovedAsync(CardRuntimeEventContext context, CancellationToken token)
    {
        Unsubscribe();
        _owner = null;
        return UniTask.CompletedTask;
    }

    private void HandleReactiveEvent(BattleReactiveEvent evt)
    {
        if (_owner == null || _condition == null)
        {
            return;
        }

        ICardRuntimeEventService service = CardPhaseDispatcher.ActiveRuntimeService;
        if (service == null || service.Grid == null || !service.Grid.TryGetPosition(_owner, out _))
        {
            return;
        }

        if (_condition.Evaluate(_owner, evt, service))
        {
            service.ReactiveToggles?.Enqueue(_owner);
        }
    }

    private void Unsubscribe()
    {
        if (_bus != null)
        {
            _bus.OnEvent -= HandleReactiveEvent;
            _bus = null;
        }
    }

    public override void ClearDurationState(Card owner, EEffectDuration duration)
    {
        _condition?.ClearDurationState(duration);
    }

    public override CardEffectBase Clone()
    {
        ReactiveSelfToggleEffect clone = (ReactiveSelfToggleEffect)base.Clone();
        clone._condition = _condition?.Clone();
        clone._bus = null;
        clone._owner = null;
        return clone;
    }

#if UNITY_EDITOR
    public override void ImportNumeric(int amount, int secondaryValue)
    {
    }

    public void EditorImportSimple(
        EReactiveEventType eventType,
        int minAmount,
        EReactiveValueChange change,
        EReactiveOwnerState ownerState,
        int triggerLimit,
        bool oncePerTurn)
    {
        ReactiveAllCondition root = new ReactiveAllCondition();
        root.Conditions.Add(new ReactiveEventTypeCondition { EventType = eventType });
        root.Conditions.Add(new ReactiveOwnerOnGridCondition());
        if (minAmount > 0)
        {
            root.Conditions.Add(new ReactiveMinAmountCondition { MinAmount = minAmount });
        }
        if (change != EReactiveValueChange.Any)
        {
            root.Conditions.Add(new ReactiveValueChangeCondition { Change = change });
        }
        if (ownerState != EReactiveOwnerState.Any)
        {
            root.Conditions.Add(new ReactiveOwnerStateCondition { OwnerState = ownerState });
        }
        if (triggerLimit > 0 || oncePerTurn)
        {
            root.Conditions.Add(new ReactiveTriggerLimitCondition
            {
                Limit = triggerLimit,
                OncePerTurn = oncePerTurn
            });
        }
        _condition = root;
    }
#endif
}

[Serializable]
public abstract class CardReactiveConditionBase
{
    public abstract bool Evaluate(Card owner, BattleReactiveEvent evt, ICardRuntimeEventService service);

    public virtual CardReactiveConditionBase Clone()
    {
        return (CardReactiveConditionBase)MemberwiseClone();
    }

    public virtual void ClearDurationState(EEffectDuration duration)
    {
    }
}

[Serializable]
public sealed class ReactiveAllCondition : CardReactiveConditionBase
{
    [SerializeReference] public List<CardReactiveConditionBase> Conditions = new List<CardReactiveConditionBase>();

    public override bool Evaluate(Card owner, BattleReactiveEvent evt, ICardRuntimeEventService service)
    {
        for (int i = 0; i < Conditions.Count; i++)
        {
            if (Conditions[i] is ReactiveTriggerLimitCondition)
            {
                continue;
            }

            if (Conditions[i] != null && !Conditions[i].Evaluate(owner, evt, service))
            {
                return false;
            }
        }

        for (int i = 0; i < Conditions.Count; i++)
        {
            if (Conditions[i] is ReactiveTriggerLimitCondition limit &&
                !limit.Evaluate(owner, evt, service))
            {
                return false;
            }
        }
        return true;
    }

    public override CardReactiveConditionBase Clone()
    {
        ReactiveAllCondition clone = (ReactiveAllCondition)base.Clone();
        clone.Conditions = CloneList(Conditions);
        return clone;
    }

    public override void ClearDurationState(EEffectDuration duration)
    {
        for (int i = 0; i < Conditions.Count; i++)
        {
            Conditions[i]?.ClearDurationState(duration);
        }
    }

    internal static List<CardReactiveConditionBase> CloneList(List<CardReactiveConditionBase> source)
    {
        List<CardReactiveConditionBase> clone = new List<CardReactiveConditionBase>(source != null ? source.Count : 0);
        if (source == null) return clone;
        for (int i = 0; i < source.Count; i++)
        {
            clone.Add(source[i]?.Clone());
        }
        return clone;
    }
}

[Serializable]
public sealed class ReactiveAnyCondition : CardReactiveConditionBase
{
    [SerializeReference] public List<CardReactiveConditionBase> Conditions = new List<CardReactiveConditionBase>();

    public override bool Evaluate(Card owner, BattleReactiveEvent evt, ICardRuntimeEventService service)
    {
        for (int i = 0; i < Conditions.Count; i++)
        {
            if (Conditions[i] != null && Conditions[i].Evaluate(owner, evt, service))
            {
                return true;
            }
        }
        return false;
    }

    public override CardReactiveConditionBase Clone()
    {
        ReactiveAnyCondition clone = (ReactiveAnyCondition)base.Clone();
        clone.Conditions = ReactiveAllCondition.CloneList(Conditions);
        return clone;
    }

    public override void ClearDurationState(EEffectDuration duration)
    {
        for (int i = 0; i < Conditions.Count; i++)
        {
            Conditions[i]?.ClearDurationState(duration);
        }
    }
}

[Serializable]
public sealed class ReactiveNotCondition : CardReactiveConditionBase
{
    [SerializeReference] public CardReactiveConditionBase Condition;

    public override bool Evaluate(Card owner, BattleReactiveEvent evt, ICardRuntimeEventService service)
    {
        return Condition == null || !Condition.Evaluate(owner, evt, service);
    }

    public override CardReactiveConditionBase Clone()
    {
        ReactiveNotCondition clone = (ReactiveNotCondition)base.Clone();
        clone.Condition = Condition?.Clone();
        return clone;
    }

    public override void ClearDurationState(EEffectDuration duration)
    {
        Condition?.ClearDurationState(duration);
    }
}

[Serializable]
public sealed class ReactiveEventTypeCondition : CardReactiveConditionBase
{
    [Tooltip("감지할 반응형 이벤트")]
    public EReactiveEventType EventType = EReactiveEventType.CardDrawn;

    public override bool Evaluate(Card owner, BattleReactiveEvent evt, ICardRuntimeEventService service)
    {
        return evt.Type == EventType;
    }
}

[Serializable]
public sealed class ReactiveMinAmountCondition : CardReactiveConditionBase
{
    [Min(0)] public int MinAmount = 1;

    public override bool Evaluate(Card owner, BattleReactiveEvent evt, ICardRuntimeEventService service)
    {
        return evt.Amount >= MinAmount;
    }
}

[Serializable]
public sealed class ReactiveValueChangeCondition : CardReactiveConditionBase
{
    public EReactiveValueChange Change = EReactiveValueChange.Increased;

    public override bool Evaluate(Card owner, BattleReactiveEvent evt, ICardRuntimeEventService service)
    {
        return Change switch
        {
            EReactiveValueChange.Increased => evt.CurrentValue > evt.PreviousValue,
            EReactiveValueChange.Decreased => evt.CurrentValue < evt.PreviousValue,
            EReactiveValueChange.Unchanged => evt.CurrentValue == evt.PreviousValue,
            _ => true
        };
    }
}

[Serializable]
public sealed class ReactiveTargetIsEnemyCondition : CardReactiveConditionBase
{
    public override bool Evaluate(Card owner, BattleReactiveEvent evt, ICardRuntimeEventService service)
    {
        return evt.TargetActor is EnemyActor;
    }
}

[Serializable]
public sealed class ReactiveSourceIsOwnerCondition : CardReactiveConditionBase
{
    public override bool Evaluate(Card owner, BattleReactiveEvent evt, ICardRuntimeEventService service)
    {
        return owner != null && evt.SourceCard == owner;
    }
}

[Serializable]
public sealed class ReactiveOwnerOnGridCondition : CardReactiveConditionBase
{
    public override bool Evaluate(Card owner, BattleReactiveEvent evt, ICardRuntimeEventService service)
    {
        return owner != null && service?.Grid != null && service.Grid.TryGetPosition(owner, out _);
    }
}

[Serializable]
public sealed class ReactiveOwnerStateCondition : CardReactiveConditionBase
{
    public EReactiveOwnerState OwnerState = EReactiveOwnerState.Any;

    public override bool Evaluate(Card owner, BattleReactiveEvent evt, ICardRuntimeEventService service)
    {
        if (OwnerState == EReactiveOwnerState.Any || owner?.GridState == null)
        {
            return true;
        }

        return OwnerState == EReactiveOwnerState.Active
            ? owner.GridState.IsActivated
            : !owner.GridState.IsActivated;
    }
}

[Serializable]
public sealed class ReactiveTriggerLimitCondition : CardReactiveConditionBase
{
    [Min(0)] public int Limit = 0;
    public bool OncePerTurn;

    [NonSerialized] private int _battleCount;
    [NonSerialized] private bool _triggeredThisTurn;

    public override bool Evaluate(Card owner, BattleReactiveEvent evt, ICardRuntimeEventService service)
    {
        if (OncePerTurn && _triggeredThisTurn)
        {
            return false;
        }
        if (Limit > 0 && _battleCount >= Limit)
        {
            return false;
        }

        _battleCount++;
        _triggeredThisTurn = true;
        return true;
    }

    public override void ClearDurationState(EEffectDuration duration)
    {
        if (duration == EEffectDuration.EndOfTurn)
        {
            _triggeredThisTurn = false;
        }
        if (duration == EEffectDuration.EndOfBattle)
        {
            _battleCount = 0;
            _triggeredThisTurn = false;
        }
    }

    public override CardReactiveConditionBase Clone()
    {
        ReactiveTriggerLimitCondition clone = (ReactiveTriggerLimitCondition)base.Clone();
        clone._battleCount = 0;
        clone._triggeredThisTurn = false;
        return clone;
    }
}
