// =================================================================
// [스크립트 목적]  카드 효과 추상 베이스 ([Serializable] 클래스, SO 아님)
//                  CardDataSO 안에 [SerializeReference] 로 인라인 직렬화됨
// [주요 변수]      - _targetType   : 대상 분류 (인스펙터/CSV 설정)
//                  - _triggerPhase : 발동 페이즈
//                  - _duration     : 지속(소멸) 타이밍
// [의존 관계]      - CardDataSO 가 List<CardEffectBase> 로 보유
//                  - CardFactory 가 Clone() 으로 런타임 복사본 생성
//                  - UniTask (비동기 연출 대응)
// =================================================================

using Cysharp.Threading.Tasks;
using System;
using System.Collections.Generic;
using System.Reflection;
using System.Threading;
using UnityEngine;

public readonly struct DescValue
{
    public static readonly DescValue None = new DescValue(int.MinValue, (EStatType?)null, EDescDynamicValue.None);

    public int StaticValue { get; }
    public EStatType? StatType { get; }
    public EDescDynamicValue DynamicValue { get; }
    public bool HasValue => StaticValue != int.MinValue;

    public DescValue(int staticValue)
        : this(staticValue, null, EDescDynamicValue.None)
    {
    }

    public DescValue(int staticValue, EStatType statType)
        : this(staticValue, (EStatType?)statType, EDescDynamicValue.None)
    {
    }

    public DescValue(EDescDynamicValue dynamicValue)
        : this(0, null, dynamicValue)
    {
    }

    public DescValue(EDescDynamicValue dynamicValue, EStatType statType)
        : this(0, statType, dynamicValue)
    {
    }

    private DescValue(int staticValue, EStatType? statType, EDescDynamicValue dynamicValue)
    {
        StaticValue = staticValue;
        StatType = statType;
        DynamicValue = dynamicValue;
    }
}

public enum EDescDynamicValue
{
    None = 0,
    CurrentBlockToDamageAmount = 1,
    CurrentEnergy = 2,
}

/// <summary>
/// 효과 정의와 런타임 실행을 겸하는 추상 클래스.
/// SO 모듈 방식과 달리 효과별 고유 수치 필드를 자기 클래스에 직접 보유한다.
/// [SerializeReference] 로 CardDataSO 안에 다형성 인라인 직렬화된다.
/// 런타임 상태(스택 누적 등)를 가질 수 있으므로 카드 인스턴스마다 Clone() 한다.
/// </summary>
[Serializable]
public abstract class CardEffectBase
{
    private static readonly Dictionary<Type, FieldInfo> DescAmountFieldCache = new Dictionary<Type, FieldInfo>();
    private static readonly string[] DescAmountFieldNames =
    {
        "_amount",
        "_baseAmount",
        "_drawCount",
        "_amountPerActivation",
        "_preserveAmount",
    };

    [Header("효과 공통")]
    [Tooltip("효과 적용 대상 분류")]
    [SerializeField] protected ETargetType _targetType = ETargetType.SingleEnemy;

    [Tooltip("효과 발동 타이밍 페이즈")]
    [SerializeField] protected ETriggerPhase _triggerPhase = ETriggerPhase.OnPlay;

    [Tooltip("효과 지속(소멸) 타이밍. 즉발 효과는 Instant")]
    [SerializeField] protected EEffectDuration _duration = EEffectDuration.Instant;

    public ETargetType TargetType => _targetType;
    public ETriggerPhase TriggerPhase => _triggerPhase;
    public EEffectDuration Duration => _duration;

    /// <summary>이 효과가 켜는 비트. 구현 클래스가 고정 반환 (조회/UI/필터용).</summary>
    public abstract ECardEffectFlag EffectFlag { get; }

    /// <summary>
    /// 효과 실행. 타겟은 context.Targets 에 이미 해결되어 있다.
    /// 연출 대기가 필요하면 await, 즉시 처리면 UniTask.CompletedTask.
    /// </summary>
    public abstract UniTask ExecuteAsync(CardEffectContext context, CancellationToken token);

    /// <summary>
    /// 런타임 복사본 생성. 카드 인스턴스마다 독립 상태를 갖기 위함.
    /// 상태 없는 단순 효과는 MemberwiseClone 로 충분.
    /// 참조형 내부 필드를 가진 효과는 override 하여 깊은 복사 구현.
    /// </summary>
    public virtual CardEffectBase Clone()
    {
        return (CardEffectBase)MemberwiseClone();
    }

    /// <summary>카드가 그리드에 배치됐을 때의 런타임 훅. 기본 no-op.</summary>
    public virtual UniTask OnOwnerPlacedAsync(CardRuntimeEventContext context, CancellationToken token)
    {
        return UniTask.CompletedTask;
    }

    /// <summary>카드가 그리드에서 제거될 때의 런타임 훅. 기본 no-op.</summary>
    public virtual UniTask OnOwnerRemovedAsync(CardRuntimeEventContext context, CancellationToken token)
    {
        return UniTask.CompletedTask;
    }

    /// <summary>카드의 활성 상태가 바뀔 때의 런타임 훅. 기본 no-op.</summary>
    public virtual UniTask OnOwnerActivationChangedAsync(
        CardRuntimeEventContext context,
        bool isActive,
        CancellationToken token)
    {
        return UniTask.CompletedTask;
    }

    /// <summary>다른 카드가 ON 되었을 때의 런타임 훅. 기본 no-op.</summary>
    public virtual UniTask OnOtherCardActivatedAsync(CardRuntimeEventContext context, CancellationToken token)
    {
        return UniTask.CompletedTask;
    }

    /// <summary>카드 배치/제거로 그리드 구성이 바뀌었을 때의 런타임 훅. 기본 no-op.</summary>
    public virtual UniTask OnGridTopologyChangedAsync(CardRuntimeEventContext context, CancellationToken token)
    {
        return UniTask.CompletedTask;
    }

    /// <summary>duration 수명 경계에서 효과가 가진 스탯/상태를 정리한다.</summary>
    public virtual void ClearDurationState(Card owner, EEffectDuration duration)
    {
    }

    /// <summary>런에 남길 영구 효과 상태를 기록한다.</summary>
    public virtual void CapturePersistentState(Card owner, RunCardPersistentState state)
    {
    }

    /// <summary>런에 저장된 영구 효과 상태를 새 전투 카드에 복원한다.</summary>
    public virtual void RestorePersistentState(Card owner, RunCardPersistentState state)
    {
    }

    /// <summary>손패/툴팁 등에서 보여줄 대표 수치. 없으면 false.</summary>
    public virtual bool TryGetPreviewStat(EStatType statType, out int value)
    {
        value = 0;
        return false;
    }

    public virtual DescValue DescAmount
    {
        get
        {
            return TryGetDefaultDescAmount(out DescValue value)
                ? value
                : DescValue.None;
        }
    }
    public virtual DescValue DescHitCount => DescValue.None;
    public virtual DescValue DescThreshold => DescValue.None;
    public virtual DescValue DescModifier => DescValue.None;

    private bool TryGetDefaultDescAmount(out DescValue value)
    {
        FieldInfo field = GetDescAmountField(GetType());
        if (field == null)
        {
            value = DescValue.None;
            return false;
        }

        object raw = field.GetValue(this);
        if (raw is int intValue)
        {
            value = new DescValue(Mathf.Max(0, intValue));
            return true;
        }

        if (raw is float floatValue)
        {
            value = new DescValue(Mathf.Max(0, Mathf.RoundToInt(floatValue)));
            return true;
        }

        value = DescValue.None;
        return false;
    }

    private static FieldInfo GetDescAmountField(Type type)
    {
        if (type == null)
        {
            return null;
        }

        if (DescAmountFieldCache.TryGetValue(type, out FieldInfo cached))
        {
            return cached;
        }

        const BindingFlags flags = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;
        for (int i = 0; i < DescAmountFieldNames.Length; i++)
        {
            FieldInfo field = type.GetField(DescAmountFieldNames[i], flags);
            if (field == null) continue;

            Type fieldType = field.FieldType;
            if (fieldType == typeof(int) || fieldType == typeof(float))
            {
                DescAmountFieldCache[type] = field;
                return field;
            }
        }

        DescAmountFieldCache[type] = null;
        return null;
    }

#if UNITY_EDITOR
    /// <summary>
    /// [에디터 전용] 빌더가 CSV 공통 컬럼(target/phase/duration)을 주입.
    /// 런타임에는 사용되지 않으며 에셋 빌드 타임에만 호출된다.
    /// </summary>
    public void ImportCommon(ETargetType target, ETriggerPhase phase, EEffectDuration duration)
    {
        _targetType = target;
        _triggerPhase = phase;
        _duration = duration;
    }

    /// <summary>
    /// [에디터 전용] 빌더가 CSV 수치 컬럼(amount 및 효과별 보조 수치)을 효과에 주입.
    /// 예시 - Damage: amount=데미지, hitCount=히트수 / Block: amount=방어량.
    /// </summary>
    public abstract void ImportNumeric(int amount, int secondaryValue);
#endif
}

public enum EMagicCircleBuffType
{
    DamageBonus = 0,
    RepeatOnPlay = 1,
    RandomCardinalArrow = 2,
}

/// <summary>이후 ON 카드에 횟수 제한 전투 버프를 부여한다.</summary>
[Serializable]
public sealed class MagicCircleEffect : CardEffectBase
{
    [Header("마법진 버프")]
    [SerializeField] private EMagicCircleBuffType _buffType = EMagicCircleBuffType.DamageBonus;

    [Tooltip("버프를 적용할 이후 ON 카드 수")]
    [Min(1)]
    [SerializeField] private int _toggleCount = 1;

    [Tooltip("DamageBonus의 데미지 Flat 보너스. 다른 버프 타입은 사용하지 않음")]
    [Min(0)]
    [SerializeField] private int _bonusAmount;

    public EMagicCircleBuffType BuffType => _buffType;
    public int ToggleCount => _toggleCount;
    public int BonusAmount => _bonusAmount;

    public override ECardEffectFlag EffectFlag => ECardEffectFlag.ApplyBuff;
    public override DescValue DescAmount => _buffType == EMagicCircleBuffType.DamageBonus
        ? new DescValue(_bonusAmount)
        : DescValue.None;
    public override DescValue DescThreshold => new DescValue(_toggleCount);

    public override UniTask ExecuteAsync(CardEffectContext context, CancellationToken token)
    {
        context.RuntimeService?.RegisterMagicCircleBuff(
            context.Source,
            _buffType,
            _toggleCount,
            _bonusAmount);
        return UniTask.CompletedTask;
    }

#if UNITY_EDITOR
    public override void ImportNumeric(int amount, int secondaryValue)
    {
        _bonusAmount = Mathf.Max(0, amount);
    }

    public void EditorImportMagicCircle(
        EMagicCircleBuffType buffType,
        int toggleCount,
        int bonusAmount)
    {
        _buffType = buffType;
        _toggleCount = Mathf.Max(1, toggleCount);
        _bonusAmount = Mathf.Max(0, bonusAmount);
    }
#endif
}

/// <summary>VFX 도착 시점까지 미뤄도 되는 데미지 실행 스냅샷.</summary>
public readonly struct DeferredDamagePayload
{
    private readonly IReadOnlyList<ICombatActor> _targets;
    private readonly int _damagePerHit;
    private readonly int _hitCount;
    private readonly float _perHitDelay;

    public DeferredDamagePayload(
        IReadOnlyList<ICombatActor> targets,
        int damagePerHit,
        int hitCount,
        float perHitDelay)
    {
        _targets = targets;
        _damagePerHit = damagePerHit;
        _hitCount = hitCount > 0 ? hitCount : 1;
        _perHitDelay = perHitDelay > 0f ? perHitDelay : 0f;
    }

    public bool ContainsTarget(ICombatActor actor)
    {
        if (actor == null || _targets == null)
        {
            return false;
        }

        for (int i = 0; i < _targets.Count; i++)
        {
            if (ReferenceEquals(_targets[i], actor))
            {
                return true;
            }
        }

        return false;
    }

    public int HitCount => _hitCount;
    public float PerHitDelay => _perHitDelay;

    public UniTask ApplySingleHitAsync(
        CancellationToken token,
        Func<ICombatActor, bool> canApplyToTarget = null,
        Action<ICombatActor, int> onDamageApplied = null)
    {
        ApplySingleHit(canApplyToTarget, onDamageApplied);
        return token.IsCancellationRequested ? UniTask.FromCanceled(token) : UniTask.CompletedTask;
    }

    public async UniTask ApplyAsync(
        CancellationToken token,
        Func<ICombatActor, bool> canApplyToTarget = null,
        Action<ICombatActor, int> onDamageApplied = null)
    {
        if (_targets == null || _damagePerHit <= 0)
        {
            return;
        }

        for (int hit = 0; hit < _hitCount; hit++)
        {
            ApplySingleHit(canApplyToTarget, onDamageApplied);

            if (_perHitDelay > 0f && hit < _hitCount - 1)
            {
                await UniTask.Delay(TimeSpan.FromSeconds(_perHitDelay), cancellationToken: token);
            }

            if (token.IsCancellationRequested)
            {
                return;
            }
        }
    }

    private void ApplySingleHit(
        Func<ICombatActor, bool> canApplyToTarget,
        Action<ICombatActor, int> onDamageApplied)
    {
        if (_targets == null || _damagePerHit <= 0)
        {
            return;
        }

        for (int i = 0; i < _targets.Count; i++)
        {
            ICombatActor target = _targets[i];
            if (target != null &&
                target.IsAlive &&
                (canApplyToTarget == null || canApplyToTarget(target)))
            {
                target.TakeDamage(_damagePerHit);
                onDamageApplied?.Invoke(target, _damagePerHit);
            }
        }
    }
}

public interface IDeferredDamageEffect
{
    DeferredDamagePayload CreateDeferredDamagePayload(CardEffectContext context);
}

