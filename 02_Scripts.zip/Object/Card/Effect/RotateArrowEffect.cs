using System;
using System.Threading;
using Cysharp.Threading.Tasks;
using UnityEngine;

[Serializable]
public sealed class RotateArrowEffect : CardEffectBase
{
    [SerializeField] private int _clockwiseSteps = 1;

    public override ECardEffectFlag EffectFlag => ECardEffectFlag.None;

    public override UniTask ExecuteAsync(CardEffectContext context, CancellationToken token)
    {
        return UniTask.CompletedTask;
    }

    public override UniTask OnOwnerActivationChangedAsync(
        CardRuntimeEventContext context, bool isActive, CancellationToken token)
    {
        if (!isActive && context.Owner != null)
        {
            ECardDirection before = context.Owner.Arrow != null
                ? context.Owner.Arrow.Current
                : ECardDirection.None;
            context.Owner.Arrow?.RotateClockwise(_clockwiseSteps);
            context.Service?.Grid?.RefreshCardArrows(context.Owner);
#if UNITY_EDITOR || DEVELOPMENT_BUILD
            ECardDirection after = context.Owner.Arrow != null
                ? context.Owner.Arrow.Current
                : ECardDirection.None;
            Debug.Log($"[Card Action] {context.Owner.CardId} 카드가 화살표를 회전함 " +
                $"({before} → {after}, 90도 x {_clockwiseSteps})");
#endif
        }
        return UniTask.CompletedTask;
    }

#if UNITY_EDITOR
    public override void ImportNumeric(int amount, int secondaryValue)
    {
        _clockwiseSteps = amount == 0 ? 1 : amount;
    }
#endif
}
