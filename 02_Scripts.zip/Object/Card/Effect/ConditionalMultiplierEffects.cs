using System;
using System.Threading;
using Cysharp.Threading.Tasks;
using UnityEngine;

[Serializable]
public sealed class FirstPlacementMultiplierEffect : CardEffectBase
{
    [Min(1)]
    [SerializeField] private int _multiplier = 2;

    public int Multiplier => _multiplier;
    public override ECardEffectFlag EffectFlag => ECardEffectFlag.ApplyBuff;

    public override UniTask ExecuteAsync(CardEffectContext context, CancellationToken token)
        => UniTask.CompletedTask;

#if UNITY_EDITOR
    public override void ImportNumeric(int amount, int secondaryValue)
    {
        _multiplier = Mathf.Max(1, amount);
    }
#endif
}

