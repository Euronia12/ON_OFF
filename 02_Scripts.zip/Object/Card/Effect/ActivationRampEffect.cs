﻿// =================================================================
// [스크립트 목적]  ON 될 때마다 지정 스탯이 누적 상승하는 램프업 효과 (예: 칠 때마다 강해지는 카드)
// [주요 변수]      - _statType           : 상승시킬 스탯 (기본 Damage)
//                  - _amountPerActivation : ON 1회당 상승량
//                  - _stackCap           : 최대 누적 스택 (0 이면 무제한)
// [의존 관계]      - CardEffectBase 상속, context.Owner.Stats 에 source 키로 모디파이어 관리
// [설계 노트]      - ★ 수정: 기존엔 source 키 없이 ON 마다 Flat 을 무한 누적 →
//                    OFF/재배치 시 정리 불가 + OFF 때 줄어들지 않는 버그.
//                    → source 키 1개로 "현재 스택 = 누적값" 을 매번 덮어쓰는 방식으로 교체.
//                  - OFF·제거 시 명시적으로 모디파이어를 거둬 누수 차단.
// =================================================================

using System;
using System.Threading;
using Cysharp.Threading.Tasks;
using UnityEngine;

/// <summary>
/// 활성화될 때마다 스탯이 한 단계씩 오르는 램프업 효과.
/// 누적 스택은 효과 내부(_stacks)에 들고, 카드 스탯에는 source 키로 단일 모디파이어를 덮어쓴다.
/// 이렇게 하면 OFF/제거 시 그 키만 거둬 정확히 원복되고, 재계산해도 중복 누적이 없다.
/// </summary>
[Serializable]
public sealed class ActivationRampEffect : CardEffectBase
{
    [Header("램프업 설정")]
    [Tooltip("상승시킬 스탯 종류 (기본 데미지)")]
    [SerializeField] private EStatType _statType = EStatType.Damage;

    [Tooltip("ON 1회당 상승량")]
    [Min(0f)]
    [SerializeField] private float _amountPerActivation = 1f;

    [Tooltip("최대 누적 스택 수. 0 이면 무제한")]
    [Min(0)]
    [SerializeField] private int _stackCap = 0;

    // 누적 스택. 카드 인스턴스마다 독립이어야 하므로 NonSerialized + Clone 시 0 으로 시작.
    [NonSerialized] private int _stacks;
    [NonSerialized] private string _sourceKey;
    [NonSerialized] private bool _hasEnteredGrid;

    public override ECardEffectFlag EffectFlag => ECardEffectFlag.ApplyBuff;

    public override UniTask ExecuteAsync(CardEffectContext context, CancellationToken token)
    {
        return UniTask.CompletedTask;
    }

    public override UniTask OnOwnerPlacedAsync(CardRuntimeEventContext context, CancellationToken token)
    {
        _hasEnteredGrid = false;
        return UniTask.CompletedTask;
    }

    public override UniTask OnOwnerActivationChangedAsync(
        CardRuntimeEventContext context, bool isActive, CancellationToken token)
    {
        Card owner = context.Owner;
        if (owner == null)
        {
            return UniTask.CompletedTask;
        }

        EnsureSourceKey(owner);

        if (isActive)
        {
            if (!_hasEnteredGrid)
            {
                _hasEnteredGrid = true;
                return UniTask.CompletedTask;
            }

            _stacks++;
            if (_stackCap > 0 && _stacks > _stackCap)
            {
                _stacks = _stackCap;
            }
            ApplyStackModifier(owner);
        }

        return UniTask.CompletedTask;
    }

    /// <summary>그리드에서 제거될 때 OnLeaveGrid 수명만 정리한다.</summary>
    public override UniTask OnOwnerRemovedAsync(CardRuntimeEventContext context, CancellationToken token)
    {
        ClearDurationState(context.Owner, EEffectDuration.OnLeaveGrid);
        _hasEnteredGrid = false;
        return UniTask.CompletedTask;
    }

    public override void ClearDurationState(Card owner, EEffectDuration duration)
    {
        if (_duration != duration) return;
        ClearStack(owner);
    }

    public override void CapturePersistentState(Card owner, RunCardPersistentState state)
    {
        if (_duration != EEffectDuration.Permanent || state == null) return;
        state.SetInt(GetPersistentKey(), _stacks);
    }

    public override void RestorePersistentState(Card owner, RunCardPersistentState state)
    {
        if (_duration != EEffectDuration.Permanent || owner == null || state == null) return;
        if (!state.TryGetInt(GetPersistentKey(), out int stacks)) return;

        _stacks = _stackCap > 0 ? Mathf.Min(stacks, _stackCap) : Mathf.Max(0, stacks);
        EnsureSourceKey(owner);
        ApplyStackModifier(owner);
    }

    /// <summary>현재 스택값을 source 키 단일 모디파이어로 덮어쓴다 (중복 누적 방지).</summary>
    private void ApplyStackModifier(Card owner)
    {
        if (owner == null) return;
        owner.Stats.RemoveModifiersBySource(_sourceKey);
        float total = _stacks * _amountPerActivation;
        if (total > 0f)
        {
            owner.Stats.AddModifier(StatModifier.Flat(
                _statType, total, EStatModifierLifetime.Transient, _sourceKey));
        }
    }

    private void EnsureSourceKey(Card owner)
    {
        if (string.IsNullOrEmpty(_sourceKey))
        {
            _sourceKey = $"ActivationRamp:{owner.CardId}:{GetHashCode()}";
        }
    }

    private void ClearStack(Card owner)
    {
        if (owner != null && !string.IsNullOrEmpty(_sourceKey))
        {
            owner.Stats.RemoveModifiersBySource(_sourceKey);
        }
        _stacks = 0;
    }

    private string GetPersistentKey()
    {
        return $"ActivationRamp:{_statType}:{_amountPerActivation}:{_stackCap}";
    }

    public override CardEffectBase Clone()
    {
        ActivationRampEffect clone = (ActivationRampEffect)base.Clone();
        clone._stacks = 0;
        clone._sourceKey = null;
        clone._hasEnteredGrid = false;
        return clone;
    }

#if UNITY_EDITOR
    /// <summary>amount=ON 1회당 상승량, stackCap=최대 스택(0=무제한).</summary>
    public override void ImportNumeric(int amount, int stackCap)
    {
        _amountPerActivation = Mathf.Max(0, amount);
        _stackCap = Mathf.Max(0, stackCap);
    }

    public void EditorImportStat(EStatType statType)
    {
        _statType = statType;
    }
#endif
}
