using System;
using System.Threading;
using Cysharp.Threading.Tasks;
using UnityEngine;

[Serializable]
public sealed class GainManaEffect : CardEffectBase
{
    [Header("마나 획득 설정")]
    [Min(0)]
    [SerializeField] private int _amount = 1;

    public override ECardEffectFlag EffectFlag => ECardEffectFlag.GainMana;

    public override UniTask ExecuteAsync(CardEffectContext context, CancellationToken token)
    {
        int amount = context.ApplyEffectMultiplier(_amount);
        context.Service?.GainEnergy(amount);
#if UNITY_EDITOR || DEVELOPMENT_BUILD
        Debug.Log($"[Card Action] {context.Source?.CardId ?? "(unknown)"} 카드가 " +
            $"에너지 {amount}를 획득함");
#endif
        return UniTask.CompletedTask;
    }

    public override bool TryGetPreviewStat(EStatType statType, out int value)
    {
        value = _amount;
        return statType == EStatType.Energy && _amount > 0;
    }

    public override DescValue DescAmount => new DescValue(_amount);

#if UNITY_EDITOR
    public override void ImportNumeric(int amount, int secondaryValue)
    {
        _amount = Mathf.Max(0, amount);
    }
#endif
}
