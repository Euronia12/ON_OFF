﻿// =================================================================
// [스크립트 목적]  화살표 방향에 인접한 카드들에게 보존 스택을 부여하는 효과.
//                  보존 스택이 있는 카드는 턴 종료 회수 시 유지되며, 회수 시점에 1 감소한다.
// [주요 변수]      - _preserveAmount : 부여할 보존 스택 수 (1 = 다음 턴 회수 1번 버팀)
//                  - _includeSelf    : 자기 자신에게도 보존을 부여할지 (기본 false)
// [의존 관계]      - CardEffectBase 상속
//                  - CardDirectionUtility.Collect 로 화살표 방향 이웃 카드 수집
//                  - GridCardState.AddPreserve 로 스택 부여 (보존 수치화 패치 선행 필요)
// [설계 노트]      - ★ 변경: 기존 "자기 자신 bool 보존" → "화살표 방향 카드 스택 보존".
//                  - 턴 종료 그리드 정리는 GridManager 가 담당하고,
//                    이 효과는 보존 스택 부여만 한다 (책임 분리).
//                  - 즉발이 아니라 ON 시점(OnOwnerActivationChangedAsync)에 부여 →
//                    그리드에 배치·활성화돼야 방향 이웃이 결정되므로.
// =================================================================

using System;
using System.Collections.Generic;
using System.Threading;
using Cysharp.Threading.Tasks;
using UnityEngine;

/// <summary>
/// 화살표가 가리키는 인접 카드들에게 보존 스택을 부여한다.
/// 보존 스택이 있는 카드는 턴 종료 회수에서 제외되며, 회수 시점마다 1씩 소모된다(방식 B).
/// _preserveAmount 만큼 한 번에 부여하므로, 2 이상이면 여러 턴을 버틴다.
/// </summary>
[Serializable]
public sealed class ReserveEffect : CardEffectBase
{
    [Header("보존 설정")]
    [Tooltip("화살표 방향 카드에 부여할 보존 스택. 1 = 다음 턴 회수 1번 버팀")]
    [Min(0)]
    [SerializeField] private int _preserveAmount = 1;

    [Tooltip("자기 자신에게도 보존을 부여할지. 기본 false (방향 카드만)")]
    [SerializeField] private bool _includeSelf = false;

    [NonSerialized] private List<Card> _scratch = new List<Card>(8);

    public override ECardEffectFlag EffectFlag => ECardEffectFlag.Reserve;

    // 즉발 페이즈에서는 동작 안 함 — ON 시점 훅에서 방향 카드를 보존한다.
    public override UniTask ExecuteAsync(CardEffectContext context, CancellationToken token)
    {
        return UniTask.CompletedTask;
    }

    public override UniTask OnOwnerActivationChangedAsync(
        CardRuntimeEventContext context, bool isActive, CancellationToken token)
    {
        if (!isActive || _preserveAmount <= 0)
        {
            return UniTask.CompletedTask;
        }

        Card owner = context.Owner;
        GridManager grid = context.Service?.Grid;
        if (owner == null || grid == null)
        {
            return UniTask.CompletedTask;
        }

        // 화살표 방향 이웃 카드 수집 (DirectionalAbsorb/ForbiddenRitual 과 동일 유틸).
        CardDirectionUtility.Collect(grid, owner, _scratch);
        for (int i = 0; i < _scratch.Count; i++)
        {
            Card target = _scratch[i];
            if (target == null) continue;
            if (target == owner && !_includeSelf) continue;
            target.GridState.AddPreserve(_preserveAmount);
        }

        // 옵션: 자기 자신도 보존 (방향 이웃에 자신이 안 잡히는 경우 대비).
        if (_includeSelf)
        {
            owner.GridState.AddPreserve(_preserveAmount);
        }

#if UNITY_EDITOR || DEVELOPMENT_BUILD
        Debug.Log($"[ReserveEffect] 방향 카드 {_scratch.Count}장에 보존 +{_preserveAmount}");
#endif
        return UniTask.CompletedTask;
    }

    public override CardEffectBase Clone()
    {
        ReserveEffect clone = (ReserveEffect)base.Clone();
        clone._scratch = new List<Card>(8);
        return clone;
    }

#if UNITY_EDITOR
    /// <summary>amount=보존 스택 수, includeSelf=자기포함 여부(0=false, 그 외=true).</summary>
    public override void ImportNumeric(int amount, int includeSelf)
    {
        _preserveAmount = Mathf.Max(0, amount);
        _includeSelf = includeSelf != 0;
    }
#endif
}
