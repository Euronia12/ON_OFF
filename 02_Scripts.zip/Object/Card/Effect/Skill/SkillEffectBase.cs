using System;
using UnityEngine;

public interface ISkillApplyService
{
    void ToggleCard(Card target);
    void AddArrow(Card target, ECardDirection directions);
    void RotateArrow(Card target, int steps);
}

[Serializable]
public abstract class SkillEffectBase
{
    public virtual bool RequiresDirectionSelection => false;
    public virtual ECardDirection DirectionOptions => ECardDirection.None;
    public abstract void ApplyToCard(Card target, ISkillApplyService service, SkillCastContext context);
    public virtual bool CanApplyToCard(Card target, SkillCastContext context) => target != null;

    public virtual SkillEffectBase Clone()
    {
        return (SkillEffectBase)MemberwiseClone();
    }
}

public readonly struct SkillCastContext
{
    public static readonly SkillCastContext None = new SkillCastContext(ECardDirection.None);

    public ECardDirection Direction { get; }

    public SkillCastContext(ECardDirection direction)
    {
        Direction = direction;
    }
}

[Serializable]
public sealed class SkillToggleEffect : SkillEffectBase
{
    public override void ApplyToCard(Card target, ISkillApplyService service, SkillCastContext context)
    {
        if (!CanApplyToCard(target, context))
            return;

        service?.ToggleCard(target);
    }

    public override bool CanApplyToCard(Card target, SkillCastContext context)
    {
        return target?.GridState != null && target.GridState.IsActivated;
    }
}

[Serializable]
public sealed class SkillRecallCardEffect : SkillEffectBase
{
    public override void ApplyToCard(Card target, ISkillApplyService service, SkillCastContext context)
    {
        if (!CanApplyToCard(target, context))
            return;

        BattleManager.Instance.RecallCard(target);
    }

    public override bool CanApplyToCard(Card target, SkillCastContext context)
    {
        return BattleManager.HasInstance && BattleManager.Instance.CanRecallCard(target);
    }
}

[Serializable]
public sealed class SkillAddArrowEffect : SkillEffectBase
{
    [Tooltip("방향 선택이 없을 때 사용할 기본 추가 방향")]
    [SerializeField] private ECardDirection _fallbackDirections = ECardDirection.None;

    public override bool RequiresDirectionSelection => true;
    public override ECardDirection DirectionOptions =>
        ECardDirection.Up | ECardDirection.Down | ECardDirection.Left | ECardDirection.Right;

    public override void ApplyToCard(Card target, ISkillApplyService service, SkillCastContext context)
    {
        ECardDirection directions = context.Direction != ECardDirection.None
            ? context.Direction
            : _fallbackDirections;
        if (directions == ECardDirection.None) return;
        service?.AddArrow(target, directions);
    }

    public override bool CanApplyToCard(Card target, SkillCastContext context)
    {
        if (target == null || target.Arrow == null) return false;
        ECardDirection directions = context.Direction != ECardDirection.None
            ? context.Direction
            : _fallbackDirections;
        if (directions == ECardDirection.None) return false;
        return (directions & ~target.Arrow.Current) != 0;
    }
}

[Serializable]
public sealed class SkillRotateArrowEffect : SkillEffectBase
{
    [Tooltip("방향 선택이 없을 때 시계방향 90도 회전할지 여부")]
    [SerializeField] private bool _clockwiseByDefault = true;

    public override bool RequiresDirectionSelection => true;
    public override ECardDirection DirectionOptions =>
        ECardDirection.Left | ECardDirection.Right;

    public override void ApplyToCard(Card target, ISkillApplyService service, SkillCastContext context)
    {
        int steps = DirectionToSteps(context.Direction);
        if (steps == 0)
            steps = _clockwiseByDefault ? 1 : 3;
        service?.RotateArrow(target, steps);
    }

    private static int DirectionToSteps(ECardDirection direction)
    {
        return direction switch
        {
            ECardDirection.Right => 1,
            ECardDirection.Left => 3,
            _ => 0
        };
    }
}
