using System.Collections.Generic;
using UnityEngine;

public static class CardDirectionUtility
{
    public static void Collect(GridManager grid, Card owner, List<Card> result)
    {
        result.Clear();
        if (grid == null || owner == null || !grid.TryGetPosition(owner, out Vector2Int origin)) return;

        ECardDirection dirs = owner.Arrow != null ? owner.Arrow.Current : ECardDirection.None;
        Add(grid, origin, dirs, ECardDirection.Up, new Vector2Int(0, 1), result);
        Add(grid, origin, dirs, ECardDirection.Down, new Vector2Int(0, -1), result);
        Add(grid, origin, dirs, ECardDirection.Left, new Vector2Int(-1, 0), result);
        Add(grid, origin, dirs, ECardDirection.Right, new Vector2Int(1, 0), result);
        Add(grid, origin, dirs, ECardDirection.UpLeft, new Vector2Int(-1, 1), result);
        Add(grid, origin, dirs, ECardDirection.UpRight, new Vector2Int(1, 1), result);
        Add(grid, origin, dirs, ECardDirection.DownLeft, new Vector2Int(-1, -1), result);
        Add(grid, origin, dirs, ECardDirection.DownRight, new Vector2Int(1, -1), result);
    }

    private static void Add(
        GridManager grid,
        Vector2Int origin,
        ECardDirection dirs,
        ECardDirection direction,
        Vector2Int delta,
        List<Card> result)
    {
        if ((dirs & direction) != 0 && grid.TryGetOccupiedCard(origin + delta, out Card card))
        {
            result.Add(card);
        }
    }
}
