using System;
using System.Collections.Generic;
using System.Threading;
using Cysharp.Threading.Tasks;
using UnityEngine;

[Serializable]
public sealed class GridScaledDamageEffect : CardEffectBase, IDeferredDamageEffect
{
    [SerializeField] private int _baseAmount;
    [SerializeField] private EGridCountScope _countScope = EGridCountScope.GridTurnOnCount;
    [SerializeField] private float _damagePerCount = 1f;

    public override ECardEffectFlag EffectFlag => ECardEffectFlag.Damage;

    public override async UniTask ExecuteAsync(CardEffectContext context, CancellationToken token)
    {
        DeferredDamagePayload payload = CreateDeferredDamagePayload(context);
        await payload.ApplyAsync(token);
#if UNITY_EDITOR || DEVELOPMENT_BUILD
        int damage = ResolveDamage(context);
        Debug.Log($"[Card Action] {context.Source?.CardId ?? "(unknown)"} 카드가 {damage} 피해를 입힘 " +
            $"(대상 {context.Targets.Count}, {_countScope} 비례)");
#endif
    }

    public DeferredDamagePayload CreateDeferredDamagePayload(CardEffectContext context)
    {
        return new DeferredDamagePayload(
            new List<ICombatActor>(context.Targets),
            ResolveDamage(context),
            1,
            0f);
    }

    private int ResolveDamage(CardEffectContext context)
    {
        Card source = context.Source;
        if (source == null || context.StatCalculator == null) return 0;

        return context.CalculateEffectAmountWithGrid(
            EStatType.Damage, _baseAmount, _countScope, _damagePerCount);
    }

    public override bool TryGetPreviewStat(EStatType statType, out int value)
    {
        value = _baseAmount;
        return statType == EStatType.Damage;
    }

#if UNITY_EDITOR
    public override void ImportNumeric(int amount, int damagePerCount)
    {
        _baseAmount = Mathf.Max(0, amount);
        _damagePerCount = damagePerCount == 0 ? 1f : damagePerCount;
    }

    public void EditorImportScope(EGridCountScope scope)
    {
        _countScope = scope;
    }
#endif
}
