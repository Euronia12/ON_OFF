// =================================================================
// [스크립트 목적]  체력 회복 효과. 수치는 카드 스탯에서 산출
// [주요 변수]      - _gridScope  : 그리드 집계 범위 (회복 보너스 합류). None 이면 미사용
//                  - _gridWeight : 집계 1개당 추가 회복 가중치
// [의존 관계]      - CardEffectBase 상속, context.StatCalculator 로 회복량 산출
//                  - ICombatActor.Heal 호출
// [설계 노트]      - 회복 "수치"는 효과가 갖지 않고 Card.Stats[Heal] 일원화 (DealDamage 와 동일 패턴)
// =================================================================

using Cysharp.Threading.Tasks;
using System;
using System.Collections.Generic;
using System.Threading;
using UnityEngine;

/// <summary>
/// 회복 효과. 대상은 Self/SingleAlly/AllAllies 등.
/// 회복 수치는 카드 스탯(EStatType.Heal)에서 산출한다 — 효과는 수치를 갖지 않는다.
/// </summary>
[Serializable]
public sealed class HealEffect : CardEffectBase
{
    [Header("회복 설정")]
    [Tooltip("기본 회복 수치. effect 가 직접 소유하는 기준 수치")]
    [Min(0)]
    [SerializeField] private int _amount = 0;

    [Header("그리드 보너스")]
    [Tooltip("회복에 합류할 그리드 집계 범위. None 이면 그리드 보너스 없음")]
    [SerializeField] private EGridCountScope _gridScope = EGridCountScope.None;

    [Tooltip("그리드 집계 1개당 추가 회복 가중치. _gridScope 사용 시")]
    [Min(0f)]
    [SerializeField] private float _gridWeight = 1f;

    public override ECardEffectFlag EffectFlag => ECardEffectFlag.Heal;

    public override UniTask ExecuteAsync(CardEffectContext context, CancellationToken token)
    {
        int heal = ResolveHeal(context);

        List<ICombatActor> targets = context.Targets;
        for (int i = 0; i < targets.Count; i++)
        {
            ICombatActor target = targets[i];
            if (target != null && target.IsAlive)
            {
                target.Heal(heal);
            }
        }

#if UNITY_EDITOR || DEVELOPMENT_BUILD
        Debug.Log($"[Card Action] {context.Source?.CardId ?? "(unknown)"} 카드가 " +
            $"{heal} 체력을 회복함 (대상 {targets.Count})");
#endif
        return UniTask.CompletedTask;
    }

    /// <summary>1회 회복량을 effect 수치 + 카드 modifier 계층으로 산출. 계산기·시전 카드 없으면 0.</summary>
    private int ResolveHeal(CardEffectContext context)
    {
        Card source = context.Source;
        CardStatCalculator calc = context.StatCalculator;

        if (source == null || calc == null)
        {
#if UNITY_EDITOR || DEVELOPMENT_BUILD
            Debug.LogWarning("[HealEffect] Source 또는 StatCalculator 가 없어 회복 0 처리.");
#endif
            return 0;
        }

        return _gridScope == EGridCountScope.None
            ? context.CalculateEffectAmount(EStatType.Heal, _amount)
            : context.CalculateEffectAmountWithGrid(EStatType.Heal, _amount, _gridScope, _gridWeight);
    }

#if UNITY_EDITOR
    /// <summary>amount=기본 회복 수치. 보조 수치 미사용.</summary>
    public override void ImportNumeric(int amount, int secondaryValue)
    {
        _amount = Mathf.Max(0, amount);
    }
#endif

    public override bool TryGetPreviewStat(EStatType statType, out int value)
    {
        value = _amount;
        return statType == EStatType.Heal && _amount > 0;
    }
}
