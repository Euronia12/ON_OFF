﻿// =================================================================
// [스크립트 목적]  덱 영역. 맨 위에서 드로우, 셔플
// [의존 관계]      - CardPile 상속. CardZoneController 가 드로우/재채움에 사용
// [설계 노트]      - 리스트의 마지막을 "맨 위"로 취급 (RemoveAt(last) = O(1))
// =================================================================

/// <summary>
/// 뽑을 카드 더미. 리스트의 마지막 원소를 맨 위로 취급해 O(1) 드로우한다.
/// 셔플은 CardPile.Shuffle 사용.
/// </summary>
public sealed class Deck : CardPile
{
    /// <summary>
    /// 맨 위 카드 1장 뽑기. 비어있으면 null.
    /// 호출자가 빈 덱 처리(묘지 재채움)를 담당한다 (CardZoneController).
    /// </summary>
    public Card DrawTop()
    {
        if (_cards.Count == 0) return null;

        int last = _cards.Count - 1;
        Card card = _cards[last];
        _cards.RemoveAt(last); // 마지막 = 맨 위, O(1)
        // OnCardRemoved 통지 (베이스 Remove 를 거치지 않으므로 직접 호출 대신 Add/Remove 패턴 통일).
        RaiseRemoved(card);
        return card;
    }

    /// <summary>여러 장을 한 번에 덱에 채움 (초기 덱 구성·재채움용).</summary>
    public void AddRange(System.Collections.Generic.IEnumerable<Card> cards)
    {
        if (cards == null) return;
        foreach (Card card in cards)
        {
            Add(card);
        }
    }
}