﻿// =================================================================
// [스크립트 목적]  카드 영역(Deck/Hand/Graveyard) 공통 베이스. 카드 리스트 + 이동 + 이벤트
// [주요 변수]      - _cards     : 보유 카드 리스트
//                  - OnCardAdded/Removed : 비주얼(팀원) 구독용 이벤트
// [의존 관계]      - Deck/Hand/Graveyard 가 상속
//                  - CardZoneController 가 영역 간 이동에 사용
// [설계 노트]      - 데이터만 담당. 비주얼은 이벤트 구독으로 분리 (GridManager 와 동일 패턴)
// =================================================================

using System;
using System.Collections.Generic;

/// <summary>
/// 카드가 머무는 영역의 공통 베이스 (덱/핸드/묘지).
/// 카드 리스트와 추가/제거를 담당하고, 변경을 이벤트로 통지해 비주얼과 분리한다.
/// 셔플 등 공통 동작을 제공하며, 영역별 규칙은 파생 클래스가 추가한다.
/// </summary>
public abstract class CardPile
{
    protected readonly List<Card> _cards = new List<Card>(32);

    /// <summary>보유 카드 (읽기 전용).</summary>
    public IReadOnlyList<Card> Cards => _cards;

    /// <summary>현재 카드 수.</summary>
    public int Count => _cards.Count;

    /// <summary>비어있는지.</summary>
    public bool IsEmpty => _cards.Count == 0;

    /// <summary>카드 추가 시 발행 (비주얼 갱신용).</summary>
    public event Action<Card> OnCardAdded;

    /// <summary>카드 제거 시 발행 (비주얼 갱신용).</summary>
    public event Action<Card> OnCardRemoved;

    /// <summary>영역에 카드 추가 (기본: 맨 끝). 파생 클래스가 위치 규칙 재정의 가능.</summary>
    public virtual void Add(Card card)
    {
        if (card == null) return;
        _cards.Add(card);
        OnCardAdded?.Invoke(card);
    }

    /// <summary>특정 카드 제거. 성공 시 true.</summary>
    public virtual bool Remove(Card card)
    {
        if (card == null) return false;
        if (_cards.Remove(card))
        {
            OnCardRemoved?.Invoke(card);
            return true;
        }
        return false;
    }

    /// <summary>전체 비우기 (이벤트는 카드별로 발행하지 않고 일괄 — 비주얼은 Clear 훅 사용).</summary>
    public virtual void Clear()
    {
        _cards.Clear();
    }

    /// <summary>특정 카드 보유 여부.</summary>
    public bool Contains(Card card) => card != null && _cards.Contains(card);

    /// <summary>Fisher-Yates 셔플. 시드 주입 가능(슬더스식 결정론적 셔플 대비).</summary>
    public void Shuffle(System.Random rng)
    {
        if (rng == null) rng = new System.Random();
        for (int i = _cards.Count - 1; i > 0; i--)
        {
            int j = rng.Next(i + 1);
            (_cards[i], _cards[j]) = (_cards[j], _cards[i]);
        }
    }

    /// <summary>파생 클래스가 커스텀 제거(예: DrawTop) 후 이벤트를 발행할 때 사용.</summary>
    protected void RaiseRemoved(Card card)
    {
        if (card != null) OnCardRemoved?.Invoke(card);
    }

    /// <summary>파생 클래스가 커스텀 추가 후 이벤트를 발행할 때 사용.</summary>
    protected void RaiseAdded(Card card)
    {
        if (card != null) OnCardAdded?.Invoke(card);
    }
}