﻿// =================================================================
// [스크립트 목적]  묘지(버림 더미) 영역. 버려진 카드를 쌓고, 덱 재채움 시 전체 반환
// [의존 관계]      - CardPile 상속. CardZoneController 가 덱 소진 시 재채움 소스로 사용
// [설계 노트]      - 특별 규칙 없음(쌓기). 재채움 시 TakeAll 로 전부 빼냄
// =================================================================

using System.Collections.Generic;

/// <summary>
/// 버려진 카드가 쌓이는 묘지. 덱이 소진되면 이 카드들을 섞어 덱으로 되돌린다(순환).
/// </summary>
public sealed class Graveyard : CardPile
{
    /// <summary>
    /// 묘지의 모든 카드를 꺼내 반환하고 묘지를 비운다 (덱 재채움용).
    /// 반환된 리스트는 호출자가 셔플 후 덱에 넣는다.
    /// </summary>
    public List<Card> TakeAll()
    {
        var taken = new List<Card>(_cards);
        // 개별 제거 이벤트는 생략(대량) — 비주얼은 Clear 시점에 일괄 갱신.
        _cards.Clear();
        return taken;
    }
}