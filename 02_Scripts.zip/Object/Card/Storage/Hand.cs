﻿// =================================================================
// [스크립트 목적]  핸드(손패) 영역. 최대 손패 수 제한
// [주요 변수]      - _maxHandSize : 최대 손패 수 (초과 드로우는 거부/오버플로우 처리)
// [의존 관계]      - CardPile 상속. CardZoneController 가 드로우 대상으로 사용
// [설계 노트]      - 손패 초과 시 Add 는 false 반환 → 호출자가 오버플로우(묘지행) 결정
// =================================================================

/// <summary>
/// 손패 영역. 최대 손패 수를 제한한다.
/// 초과 시 추가를 거부하고, 오버플로우 처리(버리기 등)는 호출자가 결정한다.
/// </summary>
public sealed class Hand : CardPile
{
    private int _maxHandSize;

    public int MaxHandSize => _maxHandSize;

    /// <summary>손패가 가득 찼는지.</summary>
    public bool IsFull => _cards.Count >= _maxHandSize;

    public Hand(int maxHandSize = 10)
    {
        _maxHandSize = System.Math.Max(1, maxHandSize);
    }

    /// <summary>최대 손패 수 변경 (버프·유물 등).</summary>
    public void SetMaxHandSize(int max)
    {
        _maxHandSize = System.Math.Max(1, max);
    }

    /// <summary>
    /// 손패에 추가. 가득 찼으면 거부(베이스 Add 안 함).
    /// 성공 여부를 알려면 TryAdd 사용.
    /// </summary>
    public override void Add(Card card)
    {
        if (IsFull) return;
        base.Add(card);
    }

    /// <summary>손패 추가 시도. 가득 차서 못 넣으면 false (호출자가 오버플로우 처리).</summary>
    public bool TryAdd(Card card)
    {
        if (card == null || IsFull) return false;
        base.Add(card);
        return true;
    }
}