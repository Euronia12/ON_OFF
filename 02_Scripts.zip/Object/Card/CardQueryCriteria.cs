﻿// =================================================================
// [스크립트 목적]  카드 쿼리 조건 (POCO struct). "어떤 카드를 뽑을지" 필터 명세.
// [주요 변수]      - Pool         : 대상 풀 (Shop/Normal/Boss 등, 비트 AND 매칭)
//                  - StagePool    : 대상 스테이지/챕터 (Stage1/Stage2/Stage3, 비트 AND 매칭)
//                  - Rarity       : 등급 필터 (null 이면 등급 무관)
//                  - UnlockedOnly : 해방된 카드만 (true 면 잠긴 카드 제외)
//                  - ExcludeIds   : 제외할 카드 ID (이미 보유/중복 방지)
// [의존 관계]      - ECardPool / ECardStagePool / ECardRarity / CardRewardService
// [설계 노트]      - struct (불변 의도, 값 전달). 조건 조합으로 다양한 보상 시나리오 표현.
//                  - Rarity 가 nullable → "등급 무관 전체" 와 "특정 등급" 을 한 타입으로.
//                  - ExcludeIds 는 선택 (null 허용). 중복 보상 방지에 사용.
// =================================================================

using System.Collections.Generic;

/// <summary>
/// 카드 추출 조건. CardRewardService 가 이 명세로 전체 카드를 필터링한다.
/// 풀(필수) + 스테이지 + 등급(선택) + 해방여부 + 제외목록 조합으로 보상/상점/스타팅 등을 표현.
/// </summary>
public readonly struct CardQueryCriteria
{
    /// <summary>대상 풀 (비트 AND 으로 매칭. 카드의 _pools 와 겹치면 후보).</summary>
    public readonly ECardPool Pool;

    /// <summary>대상 스테이지/챕터 (비트 AND 으로 매칭. 카드의 _stagePools 와 겹치면 후보).</summary>
    public readonly ECardStagePool StagePool;

    /// <summary>등급 필터. null 이면 등급 무관(전체 등급).</summary>
    public readonly ECardRarity? Rarity;

    /// <summary>true 면 해방된 카드만 (잠긴 카드 제외).</summary>
    public readonly bool UnlockedOnly;

    /// <summary>제외할 카드 ID 집합 (null 허용). 중복/보유 카드 배제용.</summary>
    public readonly HashSet<string> ExcludeIds;

    public CardQueryCriteria(
        ECardPool pool,
        ECardRarity? rarity = null,
        bool unlockedOnly = true,
        HashSet<string> excludeIds = null,
        ECardStagePool stagePool = ECardStagePool.All)
    {
        Pool = pool;
        StagePool = stagePool;
        Rarity = rarity;
        UnlockedOnly = unlockedOnly;
        ExcludeIds = excludeIds;
    }

    /// <summary>풀만 지정한 간편 생성 (등급 무관, 해방 카드만).</summary>
    public static CardQueryCriteria ForPool(ECardPool pool) => new CardQueryCriteria(pool);

    /// <summary>
    /// 1-based 막 번호를 카드 스테이지 풀로 매핑한다(보상·상점 공용).
    /// ECardStagePool 은 Stage1~3 뿐이므로, 막이 더 많아도 마지막 챕터(Stage3)로 수렴한다.
    /// </summary>
    public static ECardStagePool StageForNumber(int stageNumber)
    {
        return stageNumber switch
        {
            <= 1 => ECardStagePool.Stage1,
            2 => ECardStagePool.Stage2,
            _ => ECardStagePool.Stage3,
        };
    }
}
