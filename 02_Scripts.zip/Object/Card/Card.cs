// =================================================================
// [스크립트 목적]  런타임 카드 1장. SO 의존 제거 → CardRuntimeData(POCO) 기반.
//                  가변 상태(강화/비용/스탯/방향)는 여기서 관리
// [주요 변수]      - _data        : 런타임 데이터 (CardRuntimeData, SO 아님)
//                  - _effects     : Clone 된 실행용 효과 인스턴스 리스트
//                  - _stats       : 런타임 스탯 (Base+Modifiers)
//                  - _arrow       : 런타임 방위 화살표 상태
//                  - _gridState   : 그리드 배치 상태 (ON/턴ON횟수/보존)
//                  - IsUpgraded   : 강화 적용 여부
//                  - EffectFlags  : 조회/UI용 비트
//                  - CurrentCost  : 런타임 가변 비용
//                  - Range/Propagation : 체인 전파 사거리·차단 규칙
// [의존 관계]      - CardFactory 가 생성 (FromSO → Create), CardPhaseDispatcher 가 효과 실행
//                  - CardStatCalculator 가 _stats 로 최종 수치 산출
// [설계 노트]      - ★ Card 는 더 이상 CardDataSO 를 참조하지 않는다 (SO 격리 완료)
//                  - POCO/런타임 객체(_data·_arrow)는 직렬화 대상 아님 → [SerializeField] 없음
//                  - Range/Propagation/Vfx 등 전파·연출 데이터도 _data(POCO) 경유로 노출
// =================================================================

using System.Collections.Generic;
using System;
using UnityEngine;

/// <summary>
/// 런타임 카드 인스턴스. 정적 데이터는 CardRuntimeData(POCO)로 보유하며 SO 를 직접 참조하지 않는다.
/// 가변 상태(비용·스탯·방향·그리드)는 이 인스턴스에서만 다룬다.
/// 효과는 CardFactory 에서 Clone 된 독립 인스턴스 — 카드별 런타임 상태 격리.
/// 비트마스크(빠른 조회)와 효과 리스트(실제 실행)를 병행 보유.
/// </summary>
public sealed class Card
{
    private readonly CardRuntimeData _data;
    private readonly List<CardEffectBase> _effects;
    private readonly CardStats _stats;
    private readonly CardArrowState _arrow;
    private readonly GridCardState _gridState = new GridCardState();

    /// <summary>런타임 데이터 (POCO). SO 아님.</summary>
    public CardRuntimeData Data => _data;
    public string CardId => _data.CardId;

    /// <summary>필드 전용 임시 카드 여부. true 면 턴 종료 시 묘지로 가지 않고 제거된다.</summary>
    public bool IsTemporaryFieldOnly => _data.IsTemporaryFieldOnly;

    /// <summary>ON 상태로 턴 종료 시 설정된 카드를 플레이어 드로우 더미에 추가하는 블록 여부.</summary>
    public bool GeneratesCardsOnTurnEnd => _data.GeneratesCardsOnTurnEnd;

    /// <summary>ON 상태로 턴 종료 시 생성할 CardDataSO의 에셋 이름.</summary>
    public string TurnEndGeneratedCardId => _data.TurnEndGeneratedCardId;

    /// <summary>ON 상태로 턴 종료 시 블록 한 장당 생성할 카드 수.</summary>
    public int TurnEndGeneratedCardCount => _data.TurnEndGeneratedCardCount;

    /// <summary>손패 전용 방해 카드 여부. 그리드 배치 불가, 턴 종료 시 묘지 없이 제거된다.</summary>
    public bool IsHandOnlyDisturbance => _data.IsHandOnlyDisturbance;

    /// <summary>손패에 남은 채 턴 종료되면 플레이어에게 피해를 주는 카드 여부.</summary>
    public bool DealsDamageInHandOnTurnEnd => _data.DealsDamageInHandOnTurnEnd;

    /// <summary>손패 저주 발동 시 턴 종료 데미지량.</summary>
    public int HandTurnEndDamage => _data.HandTurnEndDamage;

    /// <summary>
    /// 묘지로 편입되는 순간 소멸하는 전투 한정 생성 카드 여부 (새끼낳기 자식카드).
    /// SO/CSV 가 아닌 생성 시점(SetVanishOnDiscard)에 부여되는 런타임 수명 플래그.
    /// </summary>
    public bool VanishesOnDiscard { get; private set; }

    /// <summary>가변(X) 코스트 카드 여부. 남은 마나 전량을 코스트로 쓰는 카드 등. UI 표기용.</summary>
    public bool IsVariableCost => HasEffect(ECardEffectFlag.ManaBurst);

    /// <summary>
    /// 배치 확정 시 즉시 지불하는 에너지.
    /// ManaBurst 는 효과 실행 시 남은 에너지를 전량 소비하므로 배치 단계에서는 소비하지 않는다.
    /// </summary>
    public int PlacementCost => IsVariableCost ? 0 : CurrentCost;

    /// <summary>
    /// 현재 에너지로 배치할 수 있는지 판정한다.
    /// ManaBurst 는 효과로 소비할 에너지가 최소 1은 있어야 한다.
    /// </summary>
    public bool CanAffordPlacement(int currentEnergy)
    {
        return IsVariableCost ? currentEnergy > 0 : currentEnergy >= CurrentCost;
    }

    /// <summary>강화 적용 여부.</summary>
    public bool IsUpgraded { get; }

    /// <summary>이번 전투 덱에 이 카드가 들어온 출처.</summary>
    public EBattleDeckOwner BattleDeckOwner { get; private set; } = EBattleDeckOwner.RunDeck;
    public int RunDeckEntryId { get; private set; }

    /// <summary>보유 효과 비트 합산 (조회/필터/UI용).</summary>
    public ECardEffectFlag EffectFlags { get; }

    /// <summary>키워드 비트 (선천성/보존 등).</summary>
    public ECardKeyword Keywords => _data.Keywords;

    /// <summary>런타임 가변 비용.</summary>
    public int BaseCost { get; }
    public int CurrentCost { get; private set; }
    public bool HasRecallCostOverride { get; private set; }
    public event Action<int> OnCostChanged;

    /// <summary>
    /// 런 영속 비용 보정(각인 이벤트 등). 전투 덱 생성·덱 뷰에서 1회 주입한다.
    /// ResetCost 로도 사라지지 않는다는 점이 회수 스킬의 1회용 보정과 다르다.
    /// </summary>
    public int PermanentCostDelta { get; private set; }

    /// <summary>영구 비용 보정의 하한. 0 코스트 카드가 정상 설계이므로 0 이다.</summary>
    private const int CostMin = 0;

    /// <summary>체인 전파 사거리 (강화 반영). 런타임 데이터에서 캐싱.</summary>
    public int Range { get; }

    /// <summary>경로 차단 규칙 (관통/차단/빈칸막힘). 런타임 데이터에서 노출.</summary>
    public EChainPropagation Propagation => _data.Propagation;

    /// <summary>체인 전파 패턴. 기본 Line, 특수 카드는 별도 패턴.</summary>
    public EChainPatternType PatternType => _data.PatternType;


    /// <summary>실행용 효과 인스턴스 목록 (읽기 전용 노출).</summary>
    public IReadOnlyList<CardEffectBase> Effects => _effects;

    /// <summary>런타임 스탯 (Base + Modifiers). 데미지·방어 등 수치의 원천.</summary>
    public CardStats Stats => _stats;

    /// <summary>런타임 방위 화살표 상태. 배치 시 Resolve 로 방향 결정.</summary>
    public CardArrowState Arrow => _arrow;

    /// <summary>
    /// 그리드 배치 상태 (ON 여부·이번 턴 ON 횟수·보존 선택).
    /// 카드 인스턴스가 소유 → 배치/회수마다 생성·폐기하지 않음 (GC 없음).
    /// 그리드를 떠날 때는 Reset 으로 초기화만 한다.
    /// </summary>
    public GridCardState GridState => _gridState;

    public Card(
        CardRuntimeData data,
        List<CardEffectBase> effects,
        CardStats stats,
        CardArrowState arrow,
        bool isUpgraded)
    {
        _data = data;
        _effects = effects;
        _stats = stats;
        _arrow = arrow;
        IsUpgraded = isUpgraded;
        EffectFlags = data.GetEffectFlags();
        BaseCost = data.Cost;
        CurrentCost = BaseCost;
        Range = data.Range;
    }

    /// <summary>효과 비트 포함 여부 빠른 조회.</summary>
    public bool HasEffect(ECardEffectFlag flag) => (EffectFlags & flag) != 0;

    /// <summary>키워드 포함 여부 빠른 조회.</summary>
    public bool HasKeyword(ECardKeyword keyword) => (Keywords & keyword) != 0;

    /// <summary>전투 덱 편입 시 출처를 지정한다. SO 원본과 런 덱 구성은 변경하지 않는다.</summary>
    public void SetBattleDeckOwner(EBattleDeckOwner owner)
    {
        BattleDeckOwner = owner;
    }

    /// <summary>묘지 편입 시 소멸하는 전투 한정 카드로 표시한다 (새끼낳기가 생성 직후 호출).</summary>
    public void SetVanishOnDiscard(bool vanish)
    {
        VanishesOnDiscard = vanish;
    }

    public void SetRunDeckEntryId(int entryId)
    {
        RunDeckEntryId = entryId;
    }

    /// <summary>비용 변경 (할인/증가). 데이터 원본 불변.</summary>
    public void ModifyCost(int delta)
    {
        CurrentCost += delta;
        if (CurrentCost < 0)
        {
            CurrentCost = 0;
        }
        OnCostChanged?.Invoke(CurrentCost);
    }

    /// <summary>회수 스킬로 손패에 돌아온 카드의 이번 턴 1회용 비용을 1 낮춘다.</summary>
    public void ApplyRecallCostOverride()
    {
        // ManaBurst 는 숫자 코스트가 아니라 남은 에너지 전량을 소비하므로
        // 회수로 인한 비용 감소를 적용하지 않는다.
        if (IsVariableCost)
            return;

        HasRecallCostOverride = true;
        CurrentCost = Mathf.Max(0, CurrentCost - 1);
        OnCostChanged?.Invoke(CurrentCost);
    }

    /// <summary>회수 스킬 비용 보정을 제거하고 원래 비용으로 되돌린다.</summary>
    public void ClearRecallCostOverride()
    {
        if (!HasRecallCostOverride)
            return;

        HasRecallCostOverride = false;
        ResetCost();
    }

    /// <summary>
    /// 런 영속 비용 보정을 적용한다(각인 등). 전투 덱 생성·덱 뷰에서 1회 호출.
    /// </summary>
    public void ApplyPermanentCostDelta(int delta)
    {
        PermanentCostDelta = delta;
        CurrentCost = ResolvePermanentCost();
        OnCostChanged?.Invoke(CurrentCost);
    }

    /// <summary>비용 원복 (런타임 데이터 + 영구 보정 기준).</summary>
    public void ResetCost()
    {
        HasRecallCostOverride = false;
        // 영구 보정은 회수 스킬 해제 후에도 유지되어야 한다(각인 효과가 증발하지 않도록).
        CurrentCost = ResolvePermanentCost();
        OnCostChanged?.Invoke(CurrentCost);
    }

    /// <summary>영구 보정을 반영한 기준 비용(0 하한).</summary>
    private int ResolvePermanentCost()
        => Mathf.Max(CostMin, BaseCost + PermanentCostDelta);

    /// <summary>
    /// 카드가 그리드를 떠날 때의 정리. 그리드 배치 상태를 초기화하고,
    /// 스킬로 건 화살표 오버레이를 제거한다.
    /// </summary>
    public void OnLeaveGrid()
    {
        _gridState.Reset();
        _arrow?.RevertOverlay();
    }

    public bool TryGetPreviewStat(EStatType statType, out int value)
    {
        for (int i = 0; i < _effects.Count; i++)
        {
            if (_effects[i] != null && _effects[i].TryGetPreviewStat(statType, out value))
            {
                return true;
            }
        }

        value = 0;
        return false;
    }

    public float GetConditionalEffectMultiplier()
    {
        float multiplier = 1f;
        for (int i = 0; i < _effects.Count; i++)
        {
            if (_effects[i] is FirstPlacementMultiplierEffect first &&
                _gridState.IsFirstPlacedThisTurn)
            {
                multiplier += first.Multiplier - 1f;
            }
        }

        return Mathf.Max(1f, multiplier);
    }
}
