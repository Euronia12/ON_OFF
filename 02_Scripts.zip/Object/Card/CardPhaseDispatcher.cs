// =================================================================
// [스크립트 목적]  특정 페이즈에 해당하는 카드 효과를 리졸브·실행하는 디스패처
// [주요 변수]      - _resolver   : 타겟 해결 주입 (전투 시스템 구현)
//                  - _service    : 덱/에너지 작용 서비스 (드로우 등)
//                  - _calculator : 스탯 최종값 산출기 (그리드 합류)
//                  - _context    : 재사용 컨텍스트 (GC 최소화)
// [의존 관계]      - ITargetResolver / ICardGameService / CardStatCalculator
//                  - Card / CardEffectBase / UniTask (순차 비동기 실행)
// =================================================================

using Cysharp.Threading.Tasks;
using System;
using System.Collections.Generic;
using System.Threading;
using UnityEngine;

/// <summary>카드 효과 디스패치 중 발생한 연출 결과.</summary>
public readonly struct CardDispatchResult
{
    public static readonly CardDispatchResult None = new CardDispatchResult(false);

    public bool PlayedImpactVfx { get; }

    public CardDispatchResult(bool playedImpactVfx)
    {
        PlayedImpactVfx = playedImpactVfx;
    }
}

public enum EBattleBuffKind
{
    Casting = 0,
    MagicCircle = 1,
}

public readonly struct BattleBuffView
{
    public int Id { get; }
    public string IconKey { get; }
    public int RemainingCount { get; }
    public EBattleBuffKind Kind { get; }

    public BattleBuffView(int id, string iconKey, int remainingCount, EBattleBuffKind kind)
    {
        Id = id;
        IconKey = iconKey ?? string.Empty;
        RemainingCount = remainingCount;
        Kind = kind;
    }
}

/// <summary>
/// 카드의 효과 중 현재 페이즈에 매칭되는 것만 골라 실행하는 디스패처.
/// 타겟 해결은 ITargetResolver, 덱 작용은 ICardGameService, 스탯 산출은 CardStatCalculator 에 위임 — 책임 분리.
/// 컨텍스트·타겟 리스트를 재사용해 실행마다 발생하는 GC 를 최소화한다.
/// </summary>
public sealed class CardPhaseDispatcher : ICardRuntimeEventService
{
    private static readonly ECardDirection[] CardinalDirections =
    {
        ECardDirection.Up,
        ECardDirection.Down,
        ECardDirection.Left,
        ECardDirection.Right,
    };

    private readonly ITargetResolver _resolver;
    private readonly ICardGameService _service;
    private readonly CardStatCalculator _calculator;
    private readonly GridManager _grid;
    private readonly BattleVfxPresenter _vfxPresenter;
    private readonly CardEffectContext _context = new CardEffectContext();
    private readonly CardRuntimeEventContext _runtimeContext = new CardRuntimeEventContext();
    private readonly List<PendingImpactDamageGroup> _pendingDamageGroups = new List<PendingImpactDamageGroup>(8);
    private readonly HashSet<ICombatActor> _cancelledPendingTargets = new HashSet<ICombatActor>();
    private readonly List<PendingCastingEntry> _pendingCastingEntries = new List<PendingCastingEntry>(8);
    private readonly List<BattleBuffView> _activeBuffViews = new List<BattleBuffView>(8);
    private readonly List<List<DispatchModifierCleanup>> _dispatchModifierCleanupStack =
        new List<List<DispatchModifierCleanup>>(4);
    private ICombatActor _currentCaster;
    private ChainExecutor _chainExecutor;
    private BattleReactiveEventBus _reactiveEvents;
    private ReactiveToggleQueue _reactiveToggles;
    private UniTaskCompletionSource _pendingDamageSource;
    private int _battleGeneration;
    private int _enemyGeneration;
    private int _castingEntryId;
    private int _castingActivationSequence;
    private MagicCircleBuffState _magicCircleBuff;

    public CardPhaseDispatcher(
        ITargetResolver resolver,
        ICardGameService service,
        CardStatCalculator calculator,
        GridManager grid,
        BattleVfxPresenter vfxPresenter = null)
    {
        _resolver = resolver;
        _service = service;
        _calculator = calculator;
        _grid = grid;
        _vfxPresenter = vfxPresenter;
    }

    public ICombatActor Caster => _currentCaster;
    public ICardGameService GameService => _service;
    public CardStatCalculator StatCalculator => _calculator;
    public GridManager Grid => _grid;
    public BattleReactiveEventBus ReactiveEvents => _reactiveEvents;
    public ReactiveToggleQueue ReactiveToggles => _reactiveToggles;
    public IReadOnlyList<BattleBuffView> ActiveBuffViews => _activeBuffViews;
    public static ICardRuntimeEventService ActiveRuntimeService { get; private set; }
    public event Action OnBuffChanged;

    public float GetEffectMultiplier(Card owner)
    {
        if (owner == null) return 1f;
        return owner.GetConditionalEffectMultiplier();
    }

    public void BindChainExecutor(ChainExecutor chainExecutor)
    {
        _chainExecutor = chainExecutor;
    }

    public void BindReactiveSystems(BattleReactiveEventBus reactiveEvents, ReactiveToggleQueue reactiveToggles)
    {
        _reactiveEvents = reactiveEvents;
        _reactiveToggles = reactiveToggles;
        ActiveRuntimeService = this;
    }

    public UniTask WaitForPendingDamageAsync(CancellationToken token)
    {
        if (_pendingDamageGroups.Count <= 0)
        {
            return UniTask.CompletedTask;
        }

        return _pendingDamageSource.Task.AttachExternalCancellation(token);
    }

    public void BeginBattleGeneration()
    {
        _battleGeneration++;
        _cancelledPendingTargets.Clear();
        CancelAllPendingDamage();
        ClearCastingQueue();
    }

    public void AdvanceEnemyGeneration()
    {
        _enemyGeneration++;
        _cancelledPendingTargets.Clear();
    }

    public void CancelPendingForTarget(ICombatActor target)
    {
        if (target == null) return;

        _cancelledPendingTargets.Add(target);
        for (int i = _pendingDamageGroups.Count - 1; i >= 0; i--)
        {
            PendingImpactDamageGroup group = _pendingDamageGroups[i];
            if (group != null && group.ContainsTarget(target))
            {
                group.Cancel();
                _pendingDamageGroups.RemoveAt(i);
            }
        }

        CompletePendingIfEmpty();
    }

    public void CancelAllPendingDamage()
    {
        for (int i = 0; i < _pendingDamageGroups.Count; i++)
        {
            _pendingDamageGroups[i]?.Cancel();
        }

        _pendingDamageGroups.Clear();
        CompletePendingIfEmpty();
    }

    /// <summary>
    /// 카드의 효과 중 phase 에 해당하는 것을 순차 실행.
    /// picked 는 플레이어가 직접 지정한 단일 대상(없으면 null).
    /// </summary>
    public async UniTask<CardDispatchResult> DispatchAsync(
        Card card,
        ICombatActor caster,
        ETriggerPhase phase,
        ICombatActor picked,
        CancellationToken token)
    {
        return await DispatchInternalAsync(card, caster, phase, picked, false, token, null);
    }

    /// <summary>정상 체인 ON 카드에만 MagicCircle 버프를 적용해 OnPlay 효과를 실행한다.</summary>
    public async UniTask<CardDispatchResult> DispatchActivationAsync(
        Card card,
        ICombatActor caster,
        ICombatActor picked,
        CancellationToken token)
    {
        MagicCircleBuffState buff = _magicCircleBuff;
        if (buff == null)
        {
            return await DispatchInternalAsync(
                card, caster, ETriggerPhase.OnPlay, picked, false, token, null);
        }

        _vfxPresenter?.PlayMagicCircleConsumeVfx(buff.ConsumeVfxKey, card);

        string modifierSource = null;
        bool applyStandaloneDamage =
            card != null &&
            buff.BuffType == EMagicCircleBuffType.DamageBonus &&
            buff.BonusAmount > 0 &&
            !HasOnPlayDamageEffect(card);
        if (buff.BuffType == EMagicCircleBuffType.DamageBonus &&
            buff.BonusAmount > 0 &&
            !applyStandaloneDamage)
        {
            modifierSource = $"MagicCircle:{buff.Id}";
            card?.Stats?.AddModifier(StatModifier.Flat(
                EStatType.Damage,
                buff.BonusAmount,
                EStatModifierLifetime.Transient,
                modifierSource));
        }
        else if (buff.BuffType == EMagicCircleBuffType.RandomCardinalArrow)
        {
            AddRandomCardinalArrow(card);
        }

        CardDispatchResult result = CardDispatchResult.None;
        int dispatchCount = buff.BuffType == EMagicCircleBuffType.RepeatOnPlay ? 2 : 1;
        try
        {
            for (int i = 0; i < dispatchCount; i++)
            {
                CardDispatchResult current = await DispatchInternalAsync(
                    card, caster, ETriggerPhase.OnPlay, picked, false, token, null);
                result = new CardDispatchResult(result.PlayedImpactVfx || current.PlayedImpactVfx);
                if (token.IsCancellationRequested) break;
            }

            if (applyStandaloneDamage && !token.IsCancellationRequested)
            {
                _context.Set(caster, card, ETriggerPhase.OnPlay, _service, _calculator, this);
                _resolver.Resolve(ETargetType.SingleEnemy, caster, picked, _context.Targets);
                DeferredDamagePayload payload = new DeferredDamagePayload(
                    _context.Targets,
                    buff.BonusAmount,
                    1,
                    0f);
                await payload.ApplyAsync(
                    token,
                    null,
                    (target, amount) => PublishEnemyDamageEvent(card, target, amount));
                await FlushReactiveTogglesAsync(token);
            }

            return result;
        }
        finally
        {
            if (!string.IsNullOrEmpty(modifierSource))
            {
                card?.Stats?.RemoveModifiersBySource(modifierSource);
            }

            ConsumeMagicCircleBuff(buff);
        }
    }

    private static bool HasOnPlayDamageEffect(Card card)
    {
        if (card == null) return false;

        IReadOnlyList<CardEffectBase> effects = card.Effects;
        for (int i = 0; i < effects.Count; i++)
        {
            CardEffectBase effect = effects[i];
            if (effect == null || effect.TriggerPhase != ETriggerPhase.OnPlay)
            {
                continue;
            }

            if (effect is IDeferredDamageEffect ||
                (effect.EffectFlag & ECardEffectFlag.Damage) != 0)
            {
                return true;
            }
        }

        return false;
    }

    private async UniTask<CardDispatchResult> DispatchInternalAsync(
        Card card,
        ICombatActor caster,
        ETriggerPhase phase,
        ICombatActor picked,
        bool isCastingPayload,
        CancellationToken token,
        IReadOnlyList<CardEffectBase> overrideEffects = null,
        Vector3? vfxStartOverride = null)
    {
        if (card == null)
        {
            return CardDispatchResult.None;
        }

        _currentCaster = caster;

        IReadOnlyList<CardEffectBase> effects = overrideEffects ?? card.Effects;
        int executedEffectCount = 0;
        bool playedImpactVfx = false;
        PendingImpactDamageGroup impactDamageGroup = null;
        List<DispatchModifierCleanup> dispatchCleanups = new List<DispatchModifierCleanup>(2);
        _dispatchModifierCleanupStack.Add(dispatchCleanups);
        try
        {
            for (int i = 0; i < effects.Count; i++)
            {
                CardEffectBase effect = effects[i];
                // 현재 페이즈에 매칭되는 효과만 실행.
                if (effect.TriggerPhase != phase)
                {
                    continue;
                }

                // 캐스팅 카드는 최초 ON 시 카운터만 시작하고 payload 효과는 완료 시점까지 억제한다.
                if (!isCastingPayload &&
                    phase == ETriggerPhase.OnPlay &&
                    card.Data != null &&
                    card.Data.CardType == ECardType.Casting &&
                    effect is not CastingEffect)
                {
                    continue;
                }

                if (isCastingPayload && effect is CastingEffect)
                {
                    continue;
                }

                // 컨텍스트 세팅 (Targets 는 Set 내부에서 Clear 됨).
                _context.Set(caster, card, phase, _service, _calculator, this);

                // 타겟 해결을 리졸버에 위임.
                _resolver.Resolve(effect.TargetType, caster, picked, _context.Targets);

#if UNITY_EDITOR || DEVELOPMENT_BUILD
                Debug.Log($"[Card Action] {card.CardId} 카드 효과 실행: " +
                    $"{effect.GetType().Name} (페이즈 {phase}, 대상 {_context.Targets.Count})");
#endif

                if (effect is IDeferredDamageEffect deferredDamage)
                {
                    DeferredDamagePayload payload = deferredDamage.CreateDeferredDamagePayload(_context);
                    if (_vfxPresenter != null && impactDamageGroup != null)
                    {
                        impactDamageGroup.Add(card, payload);
                        executedEffectCount++;
                        continue;
                    }

                    if (_vfxPresenter != null &&
                        !playedImpactVfx &&
                        _vfxPresenter.TryCreateImpactVfxRequest(card, vfxStartOverride, out BattleVfxRequest vfxRequest))
                    {
                        impactDamageGroup = ScheduleImpactDamage(vfxRequest, token);
                        impactDamageGroup.Add(card, payload);
                        playedImpactVfx = true;
                        executedEffectCount++;
                        continue;
                    }

                    await payload.ApplyAsync(token, null, (target, amount) => PublishEnemyDamageEvent(card, target, amount));
                    await FlushReactiveTogglesAsync(token);
                    executedEffectCount++;
                    continue;
                }

                // 효과 실행 (연출 대기 시 await).
                await effect.ExecuteAsync(_context, token);
                await FlushReactiveTogglesAsync(token);
                executedEffectCount++;

                // 취소 요청 시 즉시 중단 (씬 전환·전투 종료 대응).
                if (token.IsCancellationRequested)
                {
                    return new CardDispatchResult(playedImpactVfx);
                }
            }
        }
        finally
        {
            impactDamageGroup?.Seal();
            CleanupDispatchModifiers(dispatchCleanups);
            if (_dispatchModifierCleanupStack.Count > 0 &&
                ReferenceEquals(_dispatchModifierCleanupStack[_dispatchModifierCleanupStack.Count - 1], dispatchCleanups))
            {
                _dispatchModifierCleanupStack.RemoveAt(_dispatchModifierCleanupStack.Count - 1);
            }
            else
            {
                _dispatchModifierCleanupStack.Remove(dispatchCleanups);
            }
        }

        if (executedEffectCount > 0 &&
            !playedImpactVfx &&
            phase != ETriggerPhase.OnPlay &&
            card.Data != null &&
            card.Data.CardType == ECardType.Casting &&
            _vfxPresenter != null)
        {
            await _vfxPresenter.PlayCastingPayloadVfxAsync(card, vfxStartOverride, token);
            playedImpactVfx = true;
        }

        return new CardDispatchResult(playedImpactVfx);
    }

    public void RegisterDispatchModifierCleanup(Card owner, string sourceKey)
    {
        if (owner == null || string.IsNullOrEmpty(sourceKey))
        {
            return;
        }

        if (_dispatchModifierCleanupStack.Count == 0)
        {
            owner.Stats?.RemoveModifiersBySource(sourceKey);
            return;
        }

        List<DispatchModifierCleanup> current =
            _dispatchModifierCleanupStack[_dispatchModifierCleanupStack.Count - 1];
        current.Add(new DispatchModifierCleanup(owner, sourceKey));
    }

    private static void CleanupDispatchModifiers(List<DispatchModifierCleanup> cleanups)
    {
        if (cleanups == null)
        {
            return;
        }

        for (int i = cleanups.Count - 1; i >= 0; i--)
        {
            DispatchModifierCleanup cleanup = cleanups[i];
            cleanup.Owner?.Stats?.RemoveModifiersBySource(cleanup.SourceKey);
        }

        cleanups.Clear();
    }

    private readonly struct DispatchModifierCleanup
    {
        public Card Owner { get; }
        public string SourceKey { get; }

        public DispatchModifierCleanup(Card owner, string sourceKey)
        {
            Owner = owner;
            SourceKey = sourceKey;
        }
    }

    private PendingImpactDamageGroup ScheduleImpactDamage(BattleVfxRequest vfxRequest, CancellationToken token)
    {
        if (_pendingDamageGroups.Count == 0)
        {
            _pendingDamageSource = new UniTaskCompletionSource();
        }

        PendingImpactDamageGroup group = new PendingImpactDamageGroup(_battleGeneration, _enemyGeneration);
        _pendingDamageGroups.Add(group);
        ApplyImpactDamageAsync(vfxRequest, group, token).Forget();
        return group;
    }

    private async UniTaskVoid ApplyImpactDamageAsync(
        BattleVfxRequest vfxRequest,
        PendingImpactDamageGroup group,
        CancellationToken token)
    {
        try
        {
            bool played = true;
            try
            {
                await UniTask.CompletedTask;
            }
            catch (OperationCanceledException)
            {
                return;
            }
            catch (Exception ex)
            {
                Debug.LogWarning($"[CardPhaseDispatcher] Impact VFX 재생 실패 — 데미지는 즉시 적용합니다. {ex.Message}");
            }

            if (token.IsCancellationRequested || group.IsCanceled)
            {
                return;
            }

            await group.WaitUntilSealedAsync(token);
            if (token.IsCancellationRequested || group.IsCanceled)
            {
                return;
            }

            if (!played)
            {
#if UNITY_EDITOR || DEVELOPMENT_BUILD
                Debug.LogWarning("[CardPhaseDispatcher] Impact VFX 미재생 — 예약 데미지를 즉시 적용합니다.");
#endif
            }

            if (group.BattleGeneration != _battleGeneration ||
                group.EnemyGeneration != _enemyGeneration)
            {
                return;
            }

            if (_vfxPresenter != null)
            {
                await group.PlayImpactVfxAndApplyAsync(
                    vfxRequest,
                    _vfxPresenter,
                    token,
                    CanApplyPendingDamageToTarget,
                    PublishEnemyDamageEvent);
            }
            else
            {
                await group.ApplyAsync(token, CanApplyPendingDamageToTarget, PublishEnemyDamageEvent);
            }
            await FlushReactiveTogglesAsync(token);
        }
        finally
        {
            _pendingDamageGroups.Remove(group);
            CompletePendingIfEmpty();
        }
    }

    private bool CanApplyPendingDamageToTarget(ICombatActor target)
    {
        return target != null &&
               target.IsAlive &&
               !_cancelledPendingTargets.Contains(target);
    }

    private void CompletePendingIfEmpty()
    {
        if (_pendingDamageGroups.Count == 0)
        {
            _pendingDamageSource?.TrySetResult();
            _pendingDamageSource = null;
        }
    }

    public UniTask FlushReactiveTogglesAsync(CancellationToken token)
    {
        return _reactiveToggles != null
            ? _reactiveToggles.FlushAsync(token)
            : UniTask.CompletedTask;
    }

    private void PublishEnemyDamageEvent(Card source, ICombatActor target, int amount)
    {
        if (_reactiveEvents == null || source == null || amount <= 0 || target is not EnemyActor)
        {
            return;
        }

        _reactiveEvents.Publish(new BattleReactiveEvent(
            EReactiveEventType.EnemyDamaged,
            sourceCard: source,
            targetActor: target,
            amount: amount));
    }

    private sealed class PendingImpactDamageGroup
    {
        private readonly List<DeferredDamagePayload> _payloads = new List<DeferredDamagePayload>(2);
        private readonly List<Card> _sourceCards = new List<Card>(2);
        private readonly UniTaskCompletionSource _sealedSource = new UniTaskCompletionSource();
        private bool _sealed;

        public int BattleGeneration { get; }
        public int EnemyGeneration { get; }
        public bool IsCanceled { get; private set; }

        public PendingImpactDamageGroup(int battleGeneration, int enemyGeneration)
        {
            BattleGeneration = battleGeneration;
            EnemyGeneration = enemyGeneration;
        }

        public void Add(Card source, DeferredDamagePayload payload)
        {
            _sourceCards.Add(source);
            _payloads.Add(payload);
        }

        public void Seal()
        {
            if (_sealed) return;
            _sealed = true;
            _sealedSource.TrySetResult();
        }

        public void Cancel()
        {
            IsCanceled = true;
            Seal();
        }

        public UniTask WaitUntilSealedAsync(CancellationToken token)
        {
            return _sealed
                ? UniTask.CompletedTask
                : _sealedSource.Task.AttachExternalCancellation(token);
        }

        public bool ContainsTarget(ICombatActor target)
        {
            for (int i = 0; i < _payloads.Count; i++)
            {
                if (_payloads[i].ContainsTarget(target))
                {
                    return true;
                }
            }

            return false;
        }

        public async UniTask ApplyAsync(
            CancellationToken token,
            Func<ICombatActor, bool> canApplyToTarget,
            Action<Card, ICombatActor, int> onDamageApplied)
        {
            for (int i = 0; i < _payloads.Count; i++)
            {
                if (IsCanceled)
                {
                    return;
                }

                Card source = i < _sourceCards.Count ? _sourceCards[i] : null;
                await _payloads[i].ApplyAsync(
                    token,
                    target => !IsCanceled && (canApplyToTarget == null || canApplyToTarget(target)),
                    (target, amount) => onDamageApplied?.Invoke(source, target, amount));
                if (token.IsCancellationRequested || IsCanceled)
                {
                    return;
                }
            }
        }

        public async UniTask PlayImpactVfxAndApplyAsync(
            BattleVfxRequest vfxRequest,
            BattleVfxPresenter vfxPresenter,
            CancellationToken token,
            Func<ICombatActor, bool> canApplyToTarget,
            Action<Card, ICombatActor, int> onDamageApplied)
        {
            if (vfxPresenter == null)
            {
                await ApplyAsync(token, canApplyToTarget, onDamageApplied);
                return;
            }

            for (int i = 0; i < _payloads.Count; i++)
            {
                if (IsCanceled)
                {
                    return;
                }

                Card source = i < _sourceCards.Count ? _sourceCards[i] : null;
                DeferredDamagePayload payload = _payloads[i];
                int hitCount = Mathf.Max(1, payload.HitCount);

                for (int hit = 0; hit < hitCount; hit++)
                {
                    bool damageApplied = false;
                    try
                    {
                        await vfxPresenter.PlayImpactVfxAsync(
                            vfxRequest,
                            token,
                            () =>
                            {
                                damageApplied = true;
                                return payload.ApplySingleHitAsync(
                                    token,
                                    target => !IsCanceled && (canApplyToTarget == null || canApplyToTarget(target)),
                                    (target, amount) => onDamageApplied?.Invoke(source, target, amount));
                            },
                            hit,
                            hitCount);

                        if (!damageApplied)
                        {
                            await payload.ApplySingleHitAsync(
                                token,
                                target => !IsCanceled && (canApplyToTarget == null || canApplyToTarget(target)),
                                (target, amount) => onDamageApplied?.Invoke(source, target, amount));
                        }
                    }
                    catch (OperationCanceledException)
                    {
                        return;
                    }
                    catch (Exception ex)
                    {
                        Debug.LogWarning($"[CardPhaseDispatcher] Impact VFX 재생 실패 — 데미지를 즉시 적용합니다. {ex.Message}");
                        if (!damageApplied)
                        {
                            await payload.ApplySingleHitAsync(
                                token,
                                target => !IsCanceled && (canApplyToTarget == null || canApplyToTarget(target)),
                                (target, amount) => onDamageApplied?.Invoke(source, target, amount));
                        }
                    }

                    if (token.IsCancellationRequested || IsCanceled)
                    {
                        return;
                    }

                }
            }
        }
    }

    public async UniTask DispatchPhaseAsync(Card owner, ETriggerPhase phase, CancellationToken token)
    {
        await DispatchAsync(owner, _currentCaster, phase, null, token);
    }

    public async UniTask DispatchCastingPayloadAsync(
        Card owner,
        ETriggerPhase phase,
        CancellationToken token)
    {
        await DispatchInternalAsync(owner, _currentCaster, phase, null, true, token, null);
    }

    public void RegisterCastingPayload(Card owner, CastingEffect sourceEffect)
    {
        if (owner == null || sourceEffect == null)
        {
            return;
        }

        ETriggerPhase payloadPhase = sourceEffect.PayloadPhase;
        bool hasPayloadEffect = false;
        // 오브는 카운트만 독립적으로 보관한다. 효과는 완료 시점의 원본 카드 상태를 사용한다.
        for (int i = 0; i < owner.Effects.Count; i++)
        {
            CardEffectBase effect = owner.Effects[i];
            if (effect == null ||
                effect is CastingEffect ||
                effect.TriggerPhase != payloadPhase)
            {
                continue;
            }

            hasPayloadEffect = true;
            break;
        }

        if (!hasPayloadEffect)
        {
#if UNITY_EDITOR || DEVELOPMENT_BUILD
            Debug.LogWarning($"[CardPhaseDispatcher] '{owner.CardId}' 캐스팅 payload effect가 없습니다.");
#endif
            return;
        }

        PendingCastingEntry entry = new PendingCastingEntry(
            ++_castingEntryId,
            owner,
            sourceEffect.RequiredCount,
            payloadPhase,
            _castingActivationSequence + 1);
        _pendingCastingEntries.Add(entry);
        _vfxPresenter?.CreateCastingOrb(entry.Id, entry.RemainingCount, entry.SourceCard);
        RebuildActiveBuffViews();

        // 동시 시전대기 캐스팅 개수 업적 신호.
        if (EventManager.HasInstance)
            EventManager.Instance.Publish(new PendingCastingCountSignal(_pendingCastingEntries.Count));
    }

    public void RegisterMagicCircleBuff(
        Card owner,
        EMagicCircleBuffType buffType,
        int toggleCount,
        int bonusAmount)
    {
        if (owner == null) return;

        ClearMagicCircleBuff(notify: false);

        int id = ++_castingEntryId;
        CardRuntimeData data = owner.Data;
        _magicCircleBuff = new MagicCircleBuffState(
            id,
            buffType,
            Mathf.Max(1, toggleCount),
            Mathf.Max(0, bonusAmount),
            data.IconKey,
            data.ProjectileKey,
            data.HitVfxKey);
        _vfxPresenter?.CreateMagicCircleVfx(id, data.ProjectileKey);
        RebuildActiveBuffViews();
    }

    public async UniTask AdvanceCastingQueueAsync(Card activatedCard, CancellationToken token)
    {
        if (activatedCard == null || _pendingCastingEntries.Count == 0)
        {
            _castingActivationSequence++;
            return;
        }

        _castingActivationSequence++;
        List<PendingCastingEntry> readyEntries = null;
        bool changed = false;

        for (int i = _pendingCastingEntries.Count - 1; i >= 0; i--)
        {
            PendingCastingEntry entry = _pendingCastingEntries[i];
            if (entry.CreatedActivationSequence >= _castingActivationSequence)
            {
                continue;
            }

            entry.Decrement();
            _vfxPresenter?.UpdateCastingOrb(entry.Id, entry.RemainingCount);
            changed = true;
            if (entry.RemainingCount <= 0)
            {
                _pendingCastingEntries.RemoveAt(i);
                readyEntries ??= new List<PendingCastingEntry>(4);
                readyEntries.Add(entry);
            }
        }

        if (changed)
        {
            RebuildActiveBuffViews();
        }

        if (readyEntries == null || readyEntries.Count == 0)
        {
            return;
        }

        readyEntries.Reverse();
        for (int i = 0; i < readyEntries.Count; i++)
        {
            PendingCastingEntry entry = readyEntries[i];
            await DispatchPendingCastingAsync(entry, token);
            if (token.IsCancellationRequested)
            {
                break;
            }
        }
    }

    public void CancelCastingForOwner(Card owner)
    {
        if (owner == null || _pendingCastingEntries.Count == 0)
        {
            return;
        }

        bool changed = false;
        for (int i = _pendingCastingEntries.Count - 1; i >= 0; i--)
        {
            if (_pendingCastingEntries[i].SourceCard == owner)
            {
                _vfxPresenter?.RemoveCastingOrb(_pendingCastingEntries[i].Id);
                _pendingCastingEntries.RemoveAt(i);
                changed = true;
            }
        }

        if (changed)
        {
            RebuildActiveBuffViews();
        }
    }

    public void ClearCastingQueue()
    {
        ClearMagicCircleBuff(notify: false);

        if (_pendingCastingEntries.Count == 0)
        {
            _vfxPresenter?.ClearCastingOrbs();
            RebuildActiveBuffViews();
            return;
        }

        _pendingCastingEntries.Clear();
        _vfxPresenter?.ClearCastingOrbs();
        RebuildActiveBuffViews();
    }

    private void ConsumeMagicCircleBuff(MagicCircleBuffState consumed)
    {
        if (consumed == null || !ReferenceEquals(_magicCircleBuff, consumed)) return;

        consumed.Decrement();
        if (consumed.RemainingCount <= 0)
        {
            ClearMagicCircleBuff();
        }
        else
        {
            RebuildActiveBuffViews();
        }
    }

    private void ClearMagicCircleBuff(bool notify = true)
    {
        if (_magicCircleBuff == null) return;
        _vfxPresenter?.RemoveMagicCircleVfx(_magicCircleBuff.Id);
        _magicCircleBuff = null;
        if (notify)
        {
            RebuildActiveBuffViews();
        }
    }

    private void AddRandomCardinalArrow(Card card)
    {
        if (card?.Arrow == null || _grid == null) return;

        int availableCount = 0;
        for (int i = 0; i < CardinalDirections.Length; i++)
        {
            if (!card.Arrow.Has(CardinalDirections[i])) availableCount++;
        }
        if (availableCount == 0) return;

        int selected = UnityEngine.Random.Range(0, availableCount);
        for (int i = 0; i < CardinalDirections.Length; i++)
        {
            ECardDirection direction = CardinalDirections[i];
            if (card.Arrow.Has(direction)) continue;
            if (selected-- > 0) continue;

            _grid.AddArrow(card, direction);
            return;
        }
    }

    private async UniTask DispatchPendingCastingAsync(PendingCastingEntry entry, CancellationToken token)
    {
        if (entry == null || entry.SourceCard == null)
        {
            return;
        }

        // 캐스팅 카운트 소진 → 효과 발동 시점 업적 신호.
        if (EventManager.HasInstance)
            EventManager.Instance.Publish(new CastingResolvedSignal());

        Vector3? startOverride = null;
        if (_vfxPresenter != null &&
            _vfxPresenter.TryGetCastingOrbPosition(entry.Id, out Vector3 orbPosition))
        {
            startOverride = orbPosition;
        }

        try
        {
            // overrideEffects를 지정하지 않아 원본 카드의 현재 효과와 Stats를 실행 시점에 반영한다.
            await DispatchInternalAsync(
                entry.SourceCard,
                _currentCaster,
                entry.PayloadPhase,
                null,
                true,
                token,
                null,
                startOverride);
        }
        finally
        {
            _vfxPresenter?.RemoveCastingOrb(entry.Id);
        }
    }

    private void RebuildActiveBuffViews()
    {
        _pendingCastingEntries.Sort(static (a, b) =>
        {
            int remainCompare = a.RemainingCount.CompareTo(b.RemainingCount);
            return remainCompare != 0 ? remainCompare : a.Id.CompareTo(b.Id);
        });

        _activeBuffViews.Clear();
        for (int i = 0; i < _pendingCastingEntries.Count; i++)
        {
            PendingCastingEntry entry = _pendingCastingEntries[i];
            _activeBuffViews.Add(new BattleBuffView(
                entry.Id,
                entry.SourceCard?.Data?.IconKey,
                entry.RemainingCount,
                EBattleBuffKind.Casting));
        }

        if (_magicCircleBuff != null)
        {
            _activeBuffViews.Add(new BattleBuffView(
                _magicCircleBuff.Id,
                _magicCircleBuff.IconKey,
                _magicCircleBuff.RemainingCount,
                EBattleBuffKind.MagicCircle));
        }

        OnBuffChanged?.Invoke();
    }

    private sealed class PendingCastingEntry
    {
        public int Id { get; }
        public Card SourceCard { get; }
        public int RemainingCount { get; private set; }
        public ETriggerPhase PayloadPhase { get; }
        public int CreatedActivationSequence { get; }

        public PendingCastingEntry(
            int id,
            Card sourceCard,
            int requiredCount,
            ETriggerPhase payloadPhase,
            int createdActivationSequence)
        {
            Id = id;
            SourceCard = sourceCard;
            RemainingCount = Mathf.Max(1, requiredCount);
            PayloadPhase = payloadPhase;
            CreatedActivationSequence = createdActivationSequence;
        }

        public void Decrement()
        {
            RemainingCount = Mathf.Max(0, RemainingCount - 1);
        }
    }

    private sealed class MagicCircleBuffState
    {
        public int Id { get; }
        public EMagicCircleBuffType BuffType { get; }
        public int BonusAmount { get; }
        public string IconKey { get; }
        public string PersistentVfxKey { get; }
        public string ConsumeVfxKey { get; }
        public int RemainingCount { get; private set; }

        public MagicCircleBuffState(
            int id,
            EMagicCircleBuffType buffType,
            int remainingCount,
            int bonusAmount,
            string iconKey,
            string persistentVfxKey,
            string consumeVfxKey)
        {
            Id = id;
            BuffType = buffType;
            RemainingCount = remainingCount;
            BonusAmount = bonusAmount;
            IconKey = iconKey ?? string.Empty;
            PersistentVfxKey = persistentVfxKey ?? string.Empty;
            ConsumeVfxKey = consumeVfxKey ?? string.Empty;
        }

        public void Decrement()
        {
            RemainingCount = Mathf.Max(0, RemainingCount - 1);
        }
    }

    public async UniTask PropagateToggleAsync(Card owner, CancellationToken token)
    {
        if (_chainExecutor == null || owner == null)
        {
            return;
        }

        await _chainExecutor.ExecuteFromEmitterAsync(owner, token);
    }

    public UniTask ExhaustGridCardAsync(Card card, CancellationToken token)
    {
        return ExhaustGridCardAsync(card, _currentCaster, token);
    }

    public async UniTask ExhaustGridCardAsync(
        Card card,
        ICombatActor caster,
        CancellationToken token)
    {
        if (card == null || _grid == null || !_grid.TryGetPosition(card, out UnityEngine.Vector2Int position))
        {
            return;
        }

        await DispatchAsync(card, caster, ETriggerPhase.OnExhaust, null, token);
        if (token.IsCancellationRequested) return;

        await WaitForPendingDamageAsync(token);
        if (token.IsCancellationRequested) return;

        await NotifyCardRemovedAsync(card, caster, token);
        if (token.IsCancellationRequested) return;

        _grid.RemoveCard(position);
        _service?.ExhaustCard(card);
        await FlushReactiveTogglesAsync(token);

        var snapshot = new List<Card>(_grid.PlacedCards);
        for (int i = 0; i < snapshot.Count; i++)
        {
            await NotifyGridTopologyChangedAsync(snapshot[i], card, caster, token);
            if (token.IsCancellationRequested) return;
        }
    }

    public UniTask DiscardGridCardAsync(Card card, CancellationToken token)
    {
        return DiscardGridCardAsync(card, _currentCaster, token);
    }

    public async UniTask DiscardGridCardAsync(Card card, ICombatActor caster, CancellationToken token)
    {
        if (card == null || _grid == null || !_grid.TryGetPosition(card, out UnityEngine.Vector2Int position))
        {
            return;
        }

        await NotifyCardRemovedAsync(card, caster, token);
        if (token.IsCancellationRequested) return;

        _grid.RemoveCard(position);
        if (!card.IsTemporaryFieldOnly && _service is ICardZoneService zones)
        {
            zones.DiscardFromField(card);
        }
        await FlushReactiveTogglesAsync(token);

        var snapshot = new List<Card>(_grid.PlacedCards);
        for (int i = 0; i < snapshot.Count; i++)
        {
            await NotifyGridTopologyChangedAsync(snapshot[i], card, caster, token);
            if (token.IsCancellationRequested) return;
        }
    }

    public async UniTask NotifyCardPlacedAsync(Card owner, ICombatActor caster, CancellationToken token)
    {
        await NotifyHooksAsync(owner, caster, null, token, static (effect, ctx, ct) => effect.OnOwnerPlacedAsync(ctx, ct));
    }

    public async UniTask NotifyCardRemovedAsync(Card owner, ICombatActor caster, CancellationToken token)
    {
        CancelCastingForOwner(owner);
        await NotifyHooksAsync(owner, caster, null, token, static (effect, ctx, ct) => effect.OnOwnerRemovedAsync(ctx, ct));
    }

    public async UniTask NotifyActivationChangedAsync(
        Card owner,
        ICombatActor caster,
        bool isActive,
        CancellationToken token)
    {
        await NotifyHooksAsync(
            owner,
            caster,
            null,
            token,
            (effect, ctx, ct) => effect.OnOwnerActivationChangedAsync(ctx, isActive, ct));
    }

    public async UniTask NotifyOtherCardActivatedAsync(
        Card owner,
        Card otherCard,
        ICombatActor caster,
        CancellationToken token)
    {
        await NotifyHooksAsync(
            owner,
            caster,
            otherCard,
            token,
            static (effect, ctx, ct) => effect.OnOtherCardActivatedAsync(ctx, ct));
    }

    public async UniTask NotifyGridTopologyChangedAsync(
        Card owner,
        Card changedCard,
        ICombatActor caster,
        CancellationToken token)
    {
        await NotifyHooksAsync(
            owner,
            caster,
            changedCard,
            token,
            static (effect, ctx, ct) => effect.OnGridTopologyChangedAsync(ctx, ct));
    }

    public void ClearDurationState(Card owner, EEffectDuration duration)
    {
        if (owner == null) return;

        IReadOnlyList<CardEffectBase> effects = owner.Effects;
        for (int i = 0; i < effects.Count; i++)
        {
            effects[i]?.ClearDurationState(owner, duration);
        }
    }

    public void CapturePersistentState(Card owner, RunCardPersistentState state)
    {
        if (owner == null || state == null) return;

        IReadOnlyList<CardEffectBase> effects = owner.Effects;
        for (int i = 0; i < effects.Count; i++)
        {
            effects[i]?.CapturePersistentState(owner, state);
        }
    }

    public void RestorePersistentState(Card owner, RunCardPersistentState state)
    {
        if (owner == null || state == null) return;

        IReadOnlyList<CardEffectBase> effects = owner.Effects;
        for (int i = 0; i < effects.Count; i++)
        {
            effects[i]?.RestorePersistentState(owner, state);
        }
    }

    private async UniTask NotifyHooksAsync(
        Card owner,
        ICombatActor caster,
        Card otherCard,
        CancellationToken token,
        System.Func<CardEffectBase, CardRuntimeEventContext, CancellationToken, UniTask> callback)
    {
        if (owner == null)
        {
            return;
        }

        _currentCaster = caster;
        IReadOnlyList<CardEffectBase> effects = owner.Effects;
        for (int i = 0; i < effects.Count; i++)
        {
            CardEffectBase effect = effects[i];
            if (effect == null) continue;

            _runtimeContext.Set(owner, otherCard, this);
            await callback(effect, _runtimeContext, token);
            if (token.IsCancellationRequested)
            {
                return;
            }
        }
    }
}
