// =================================================================
// [스크립트 목적]  카드 앞면 표시 (이름/데미지/화살표). UICard 가 Bind 시 Setup 호출
// [주요 변수]      - _nameText    : 카드 이름 (로컬라이즈 키 → 표시)
//                  - _damageText  : 데미지 수치 (CardStats 산출)
//                  - _arrowRoots  : 방향별 화살표 오브젝트 (4방위)
// [의존 관계]      - UICard 가 보유, Card 데이터에서 표시값 추출
//                  - LocalizationManager(있으면) 로 이름 키 → 현지화 텍스트
// [설계 노트]      - 팀원(UI 담당) 확장 지점: 비용·설명·아이콘·등급 테두리 등 추가
//                    여기선 "데이터가 화면에 연결된다" 검증용 최소 표시만
//                  - 데미지는 Base 만 표시 (그리드 보너스는 배치 후 동적이라 손패선 Base)
// =================================================================

using Cysharp.Threading.Tasks;
using DG.Tweening;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// 카드 앞면 표시 컴포넌트(최소 구현). UICard.Bind 가 Setup 으로 데이터를 흘려보낸다.
/// 손패 상태의 카드 정보(이름·데미지·방향)를 그린다.
/// 실제 디자인(아이콘·테두리·설명문 등)은 UI 담당이 이 클래스를 확장한다.
/// </summary>
public sealed class UICardFrontView : MonoBehaviour, ILocalizable
{
    private const string DoubleArrowCardId = "Infinite_Archive";

    [Header("텍스트")]
    [Tooltip("카드 이름 표시. 비우면 생략")]
    [SerializeField] private TMP_Text _nameText;

    [Tooltip("데미지 수치 표시. 비우면 생략")]
    [SerializeField] private TMP_Text _damageText;

    [Tooltip("현재 마나 비용")]
    [SerializeField] private TMP_Text _costText;

    [Tooltip("원본 비용보다 현재 비용이 낮을 때 표시할 색상")]
    [SerializeField] private Color _discountedCostColor = new Color(0.35f, 1f, 0.45f, 1f);

    [Tooltip("현재 에너지로 지불할 수 없을 때 표시할 색상")]
    [SerializeField] private Color _unaffordableCostColor = Color.red;

    [Tooltip("공용 카드 아틀라스에서 가져온 카드 이미지")]
    [SerializeField] private Image _iconImage;

    [Header("카드 배경")]
    [Tooltip("카드 배경 Image")]
    [SerializeField] private Image _backgroundImage;

    [Header("레어도 비주얼")]
    [Tooltip("레어도에 따라 스프라이트가 교체되는 프레임 Image. 비우면 생략")]
    [SerializeField] private Image _rarityFrameImage;

    [Tooltip("비용 배경 Image. 비우면 생략")]
    [SerializeField] private Image _costBgImage;

    [Tooltip("상단 장식 라인 Image. 비우면 생략")]
    [SerializeField] private Image _lineUpImage;

    [Tooltip("하단 장식 라인 Image. 비우면 생략")]
    [SerializeField] private Image _lineDownImage;

    [Tooltip("일반 등급 스프라이트 세트")]
    [SerializeField] private RaritySkin _commonSkin;

    [Tooltip("레어 등급 스프라이트 세트")]
    [SerializeField] private RaritySkin _rareSkin;

    [Tooltip("유니크 등급 스프라이트 세트")]
    [SerializeField] private RaritySkin _uniqueSkin;

    [Tooltip("전설 등급 스프라이트 세트")]
    [SerializeField] private RaritySkin _legendarySkin;

    /// <summary>레어도별로 교체되는 스프라이트 묶음. 비워둔 항목은 기존 스프라이트를 유지한다.</summary>
    [System.Serializable]
    private struct RaritySkin
    {
        [Tooltip("테두리 프레임")] public Sprite frame;
        [Tooltip("카드 배경")] public Sprite background;
        [Tooltip("비용 배경")] public Sprite costBg;
        [Tooltip("상단 장식 라인")] public Sprite lineUp;
        [Tooltip("하단 장식 라인")] public Sprite lineDown;
    }

    [System.Serializable]
    private struct KeywordBadgeIcon
    {
        [Tooltip("아이콘과 연결할 단일 카드 키워드")]
        [SerializeField] private ECardKeyword _keyword;

        [Tooltip("해당 키워드를 나타내는 배지 아이콘")]
        [SerializeField] private Sprite _icon;

        public ECardKeyword Keyword => _keyword;
        public Sprite Icon => _icon;
    }

    [Header("키워드 배지")]
    [Tooltip("키워드 표시 순서대로 채울 배지 Image 슬롯")]
    [SerializeField] private Image[] _keywordBadgeImages;

    [Tooltip("카드 키워드와 배지 아이콘의 1:1 매핑")]
    [SerializeField] private KeywordBadgeIcon[] _keywordBadgeIcons;

    private int _bindVersion;
    private Color _costBaseColor;
    private bool _costColorCached;
    private Color _bgBaseColor;
    private bool _bgColorCached;
    private Card _boundCard;
    private CardStats _boundStats;
    private int _currentEnergy = int.MaxValue;

    [Header("방향 화살표 (4방위)")]
    [Tooltip("위쪽 화살표 오브젝트")]
    [SerializeField] private GameObject _arrowUp;

    [Tooltip("아래쪽 화살표 오브젝트")]
    [SerializeField] private GameObject _arrowDown;

    [Tooltip("왼쪽 화살표 오브젝트")]
    [SerializeField] private GameObject _arrowLeft;

    [Tooltip("오른쪽 화살표 오브젝트")]
    [SerializeField] private GameObject _arrowRight;

    [Tooltip("좌상단 화살표 오브젝트")]
    [SerializeField] private GameObject _arrowUpLeft;

    [Tooltip("우상단 화살표 오브젝트")]
    [SerializeField] private GameObject _arrowUpRight;

    [Tooltip("좌하단 화살표 오브젝트")]
    [SerializeField] private GameObject _arrowDownLeft;

    [Tooltip("우하단 화살표 오브젝트")]
    [SerializeField] private GameObject _arrowDownRight;

    [Header("2칸 화살표 표시")]
    [Tooltip("2칸 화살표 카드의 위쪽 복제 화살표")]
    [SerializeField] private GameObject _doubleArrowUp;

    [Tooltip("2칸 화살표 카드의 아래쪽 복제 화살표")]
    [SerializeField] private GameObject _doubleArrowDown;

    [Tooltip("2칸 화살표 카드의 왼쪽 복제 화살표")]
    [SerializeField] private GameObject _doubleArrowLeft;

    [Tooltip("2칸 화살표 카드의 오른쪽 복제 화살표")]
    [SerializeField] private GameObject _doubleArrowRight;

    private bool _showDoubleArrows;

    /// <summary>카드 데이터로 앞면 갱신. UICard.Bind 가 호출.</summary>
    public void Setup(Card card)
    {
        ApplyLocalizedFonts();
        UnbindCost();
        EnsureRuntimeIcon();
        int version = ++_bindVersion;
        if (card == null)
        {
            Clear();
            return;
        }

        _showDoubleArrows = card.CardId == DoubleArrowCardId;

        // 이름: 로컬라이즈 키 → 현지화 텍스트 (매니저 없으면 키 그대로).
        if (_nameText != null)
        {
            _nameText.text = ResolveName(card);
        }

        BindStats(card);
        RefreshDamage();

        if (_costText != null)
        {
            CacheCostBaseColor();
            _boundCard = card;
            _boundCard.OnCostChanged += HandleCostChanged;
            RefreshCost();
        }

        RestoreBackgroundColor();
        ApplyRaritySkin(card);
        RefreshKeywordBadges(card.Keywords);

        LoadIconAsync(card, version).Forget();

        // 화살표: 손패 카드는 아직 방향 미결정(배치 시 Resolve)이므로
        // Fixed 모드면 설정 방향을, 그 외(Random/Weighted)는 표시 안 함(물음표 등은 팀원 확장).
        ShowArrowsForHand(card);
    }

    /// <summary>방향 비트에 맞춰 화살표 표시 (배치 후 GridCardObject 와 공유 가능한 로직).</summary>
    public void ShowArrows(ECardDirection directions)
    {
        SetArrow(_arrowUp, (directions & ECardDirection.Up) != 0);
        SetArrow(_arrowDown, (directions & ECardDirection.Down) != 0);
        SetArrow(_arrowLeft, (directions & ECardDirection.Left) != 0);
        SetArrow(_arrowRight, (directions & ECardDirection.Right) != 0);
        SetArrow(_arrowUpLeft, (directions & ECardDirection.UpLeft) != 0);
        SetArrow(_arrowUpRight, (directions & ECardDirection.UpRight) != 0);
        SetArrow(_arrowDownLeft, (directions & ECardDirection.DownLeft) != 0);
        SetArrow(_arrowDownRight, (directions & ECardDirection.DownRight) != 0);
        SetArrow(_doubleArrowUp, _showDoubleArrows && (directions & ECardDirection.Up) != 0);
        SetArrow(_doubleArrowDown, _showDoubleArrows && (directions & ECardDirection.Down) != 0);
        SetArrow(_doubleArrowLeft, _showDoubleArrows && (directions & ECardDirection.Left) != 0);
        SetArrow(_doubleArrowRight, _showDoubleArrows && (directions & ECardDirection.Right) != 0);
    }

    /// <summary>새 화살표가 위에서 내려와 카드에 찍히는 강화 연출.</summary>
    public Tween PlayArrowStamp(ECardDirection direction)
    {
        GameObject arrow = GetArrow(direction);
        if (arrow == null) return null;

        Transform target = arrow.transform;
        target.DOKill();

        Vector3 position = target.localPosition;
        Vector3 scale = target.localScale;
        arrow.SetActive(true);
        target.localPosition = position + Vector3.up * 80f;
        target.localScale = scale * 1.4f;

        Sequence sequence = DOTween.Sequence()
            .Append(target.DOLocalMove(position, 0.32f).SetEase(Ease.InCubic))
            .Join(target.DOScale(scale, 0.32f).SetEase(Ease.InCubic))
            .Append(target.DOPunchScale(scale * 0.2f, 0.18f, vibrato: 6, elasticity: 0.4f))
            .SetUpdate(true);

        sequence.OnKill(() =>
        {
            if (target == null) return;
            target.localPosition = position;
            target.localScale = scale;
        });
        return sequence;
    }

    /// <summary>표시 비우기.</summary>
    public void Clear()
    {
        UnbindCost();
        UnbindStats();
        _bindVersion++;
        RestoreBackgroundColor(); // 풀 재사용 대비 — 기본 색 복원
        if (_nameText != null) _nameText.text = string.Empty;
        if (_damageText != null) _damageText.text = string.Empty;
        if (_costText != null)
        {
            CacheCostBaseColor();
            _costText.text = string.Empty;
            _costText.color = _costBaseColor;
        }
        if (_iconImage != null)
        {
            _iconImage.sprite = null;
            _iconImage.enabled = false;
        }
        ClearKeywordBadges();
        _showDoubleArrows = false;
        ShowArrows(ECardDirection.None);
    }

    private void EnsureRuntimeIcon()
    {
        if (_iconImage != null) return;

        GameObject iconObject = new GameObject(
            "CardIcon", typeof(RectTransform), typeof(CanvasRenderer), typeof(Image));
        RectTransform rect = (RectTransform)iconObject.transform;
        rect.SetParent(transform, false);
        rect.anchorMin = new Vector2(0.15f, 0.28f);
        rect.anchorMax = new Vector2(0.85f, 0.78f);
        rect.offsetMin = Vector2.zero;
        rect.offsetMax = Vector2.zero;
        rect.SetAsFirstSibling();
        _iconImage = iconObject.GetComponent<Image>();
        _iconImage.preserveAspect = true;
        _iconImage.raycastTarget = false;
        _iconImage.enabled = false;
    }

    private void CacheCostBaseColor()
    {
        if (_costColorCached || _costText == null) return;
        _costBaseColor = _costText.color;
        _costColorCached = true;
    }

    /// <summary>
    /// 배경색을 원래 색으로 되돌린다.
    /// 최초 1회 원본 색을 캐시해 풀 재사용 시 정확히 복원한다.
    /// </summary>
    private void RestoreBackgroundColor()
    {
        if (_backgroundImage == null) return;
        if (!_bgColorCached)
        {
            _bgBaseColor = _backgroundImage.color;
            _bgColorCached = true;
        }
        _backgroundImage.color = _bgBaseColor;
    }

    /// <summary>레어도에 맞는 스프라이트 세트(프레임/배경/비용/라인)로 교체. 비어 있는 항목은 기존 스프라이트 유지.</summary>
    private void ApplyRaritySkin(Card card)
    {
        if (card?.Data == null) return;

        RaritySkin skin = GetSkin(card.Data.Rarity);
        SwapSprite(_rarityFrameImage, skin.frame);
        SwapSprite(_backgroundImage, skin.background);
        SwapSprite(_costBgImage, skin.costBg);
        SwapSprite(_lineUpImage, skin.lineUp);
        SwapSprite(_lineDownImage, skin.lineDown);
    }

    private RaritySkin GetSkin(ECardRarity rarity)
    {
        switch (rarity)
        {
            case ECardRarity.Rare: return _rareSkin;
            case ECardRarity.Unique: return _uniqueSkin;
            case ECardRarity.Legendary: return _legendarySkin;
            default: return _commonSkin;
        }
    }

    private static void SwapSprite(Image image, Sprite sprite)
    {
        if (image == null || sprite == null) return;
        image.sprite = sprite;
    }

    private void RefreshKeywordBadges(ECardKeyword keywords)
    {
        ClearKeywordBadges();
        if (_keywordBadgeImages == null || _keywordBadgeIcons == null) return;

        int badgeIndex = 0;
        foreach (ECardKeyword keyword in CardKeywordInfo.EnumerateKeywords(keywords))
        {
            if (!TryGetKeywordBadgeIcon(keyword, out Sprite icon)) continue;

            while (badgeIndex < _keywordBadgeImages.Length && _keywordBadgeImages[badgeIndex] == null)
            {
                badgeIndex++;
            }
            if (badgeIndex >= _keywordBadgeImages.Length) break;

            Image badge = _keywordBadgeImages[badgeIndex++];
            badge.sprite = icon;
            badge.gameObject.SetActive(true);
        }
    }

    private bool TryGetKeywordBadgeIcon(ECardKeyword keyword, out Sprite icon)
    {
        for (int i = 0; i < _keywordBadgeIcons.Length; i++)
        {
            KeywordBadgeIcon mapping = _keywordBadgeIcons[i];
            if (mapping.Keyword != keyword || mapping.Icon == null) continue;

            icon = mapping.Icon;
            return true;
        }

        icon = null;
        return false;
    }

    private void ClearKeywordBadges()
    {
        if (_keywordBadgeImages == null) return;

        for (int i = 0; i < _keywordBadgeImages.Length; i++)
        {
            Image badge = _keywordBadgeImages[i];
            if (badge == null) continue;

            badge.sprite = null;
            if (badge.gameObject.activeSelf)
            {
                badge.gameObject.SetActive(false);
            }
        }
    }

    private void HandleCostChanged(int currentCost)
    {
        RefreshCost();
    }

    private void RefreshCost()
    {
        if (_costText == null || _boundCard == null) return;

        // 가변(X) 코스트 카드는 숫자 대신 "X" 표기. 남은 마나 전량 소비 등.
        if (_boundCard.IsVariableCost)
        {
            _costText.text = "X";
            _costText.color = _currentEnergy <= 0
                ? _unaffordableCostColor
                : GetCostColor(_boundCard.BaseCost);
            return;
        }

        _costText.text = _boundCard.CurrentCost.ToString();
        if (_currentEnergy < _boundCard.CurrentCost)
            _costText.color = _unaffordableCostColor;
        else if (_boundCard.CurrentCost < _boundCard.BaseCost)
            _costText.color = _discountedCostColor;
        else
            _costText.color = GetCostColor(_boundCard.BaseCost);
    }

    public void SetCurrentEnergy(int currentEnergy)
    {
        _currentEnergy = currentEnergy;
        RefreshCost();
    }

    public void OnLocalize()
    {
        RefreshLocalization();
    }

    public void RefreshLocalization()
    {
        ApplyLocalizedFonts();

        if (_nameText != null)
            _nameText.text = _boundCard != null ? ResolveName(_boundCard) : string.Empty;

        RefreshDamage();
        RefreshCost();
    }

    private static Color GetCostColor(int cost)
    {
        return new Color(216f / 255f, 224f / 255f, 216f / 255f, 1f);
    }

    private void UnbindCost()
    {
        if (_boundCard != null)
            _boundCard.OnCostChanged -= HandleCostChanged;
        _boundCard = null;
    }

    private void BindStats(Card card)
    {
        UnbindStats();
        _boundStats = card != null ? card.Stats : null;
        if (_boundStats != null)
            _boundStats.OnChanged += HandleStatsChanged;
    }

    private void UnbindStats()
    {
        if (_boundStats != null)
            _boundStats.OnChanged -= HandleStatsChanged;
        _boundStats = null;
    }

    private void HandleStatsChanged()
    {
        RefreshDamage();
    }

    private void RefreshDamage()
    {
        if (_damageText == null)
            return;

        int damage = 0;
        if (_boundCard != null)
        {
            damage = _boundCard.TryGetPreviewStat(EStatType.Damage, out int baseValue)
                ? Mathf.Max(0, Mathf.RoundToInt(_boundCard.Stats.ComputeWithExtraFlat(EStatType.Damage, baseValue)))
                : _boundCard.Stats.GetValueInt(EStatType.Damage);
        }

        _damageText.text = damage > 0 ? damage.ToString() : string.Empty;
    }

    private void OnDestroy()
    {
        UnbindCost();
        UnbindStats();
        if (LocalizationManager.HasInstance)
            LocalizationManager.Instance.Unregister(this);
    }

    private void OnEnable()
    {
        if (LocalizationManager.HasInstance)
            LocalizationManager.Instance.Register(this);
        else
            ApplyLocalizedFonts();
    }

    private void OnDisable()
    {
        if (LocalizationManager.HasInstance)
            LocalizationManager.Instance.Unregister(this);
    }

    private void ApplyLocalizedFonts()
    {
        TMP_FontAsset font = LocalizedFontUtility.CurrentFont;
        LocalizedFontUtility.ApplyFont(_nameText, font);
        LocalizedFontUtility.ApplyFont(_damageText, font);
        LocalizedFontUtility.ApplyFont(_costText, font);
    }

    private async UniTaskVoid LoadIconAsync(Card card, int version)
    {
        if (_iconImage == null) return;

        _iconImage.sprite = null;
        _iconImage.enabled = false;
        if (card?.Data == null || string.IsNullOrEmpty(card.Data.IconKey) ||
            !ResourceManager.HasInstance)
        {
            return;
        }

        Sprite sprite = await ResourceManager.Instance.LoadAtlasSpriteAsync(
            EAtlasType.CardIcon, card.Data.IconKey, this.GetCancellationTokenOnDestroy());
        if (this == null || version != _bindVersion) return;

        _iconImage.sprite = sprite;
        _iconImage.enabled = sprite != null;
    }

    // ── 내부 ───────────────────────────────────────────────

    /// <summary>손패 표시용 화살표. 확정 방향 또는 안전하게 공개 가능한 Fixed 방향만 표시.</summary>
    private void ShowArrowsForHand(Card card)
    {
        ECardDirection dirs = card.Arrow != null ? card.Arrow.PreviewDirs : ECardDirection.None;
        ShowArrows(dirs);

#if UNITY_EDITOR || DEVELOPMENT_BUILD
        if (dirs != ECardDirection.None && !HasVisualForAnyDirection(dirs))
        {
            Debug.LogError($"[UICardFrontView] '{card.CardId}' 의 '{dirs}' 방향 비주얼이 연결되지 않았습니다.");
        }
#endif
    }

    /// <summary>로컬라이즈 키 → 텍스트. 매니저 없으면 키 문자열 폴백.</summary>
    private string ResolveName(Card card)
    {
        string key = card.Data != null ? card.Data.DisplayNameKey : card.CardId;

        if (LocalizationManager.HasInstance && !string.IsNullOrEmpty(key))
        {
            return LocalizationManager.Instance.Get(key);
        }
        return key;
    }

    private static void SetArrow(GameObject arrow, bool active)
    {
        if (arrow != null && arrow.activeSelf != active)
        {
            arrow.SetActive(active);
        }
    }

    private GameObject GetArrow(ECardDirection direction)
    {
        switch (direction)
        {
            case ECardDirection.Up: return _arrowUp;
            case ECardDirection.Down: return _arrowDown;
            case ECardDirection.Left: return _arrowLeft;
            case ECardDirection.Right: return _arrowRight;
            case ECardDirection.UpLeft: return _arrowUpLeft;
            case ECardDirection.UpRight: return _arrowUpRight;
            case ECardDirection.DownLeft: return _arrowDownLeft;
            case ECardDirection.DownRight: return _arrowDownRight;
            default: return null;
        }
    }

    private bool HasVisualForAnyDirection(ECardDirection directions)
    {
        return ((directions & ECardDirection.Up) != 0 && _arrowUp != null) ||
               ((directions & ECardDirection.Down) != 0 && _arrowDown != null) ||
               ((directions & ECardDirection.Left) != 0 && _arrowLeft != null) ||
               ((directions & ECardDirection.Right) != 0 && _arrowRight != null) ||
               ((directions & ECardDirection.UpLeft) != 0 && _arrowUpLeft != null) ||
               ((directions & ECardDirection.UpRight) != 0 && _arrowUpRight != null) ||
               ((directions & ECardDirection.DownLeft) != 0 && _arrowDownLeft != null) ||
               ((directions & ECardDirection.DownRight) != 0 && _arrowDownRight != null);
    }
}
