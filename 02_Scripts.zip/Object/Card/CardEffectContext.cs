// =================================================================
// [스크립트 목적]  카드 효과 실행 시 전달되는 컨텍스트 묶음
// [주요 변수]      - Caster        : 효과 시전 주체
//                  - Targets       : 해결된 최종 대상 목록 (ITargetResolver 결과)
//                  - Source        : 효과를 발생시킨 카드 런타임
//                  - Service       : 덱/에너지 등 게임 시스템 접근 (드로우 효과용)
//                  - StatCalculator: 스탯 최종값 산출기 (그리드 합류 데미지 등)
// [의존 관계]      - CardEffectBase.ExecuteAsync 가 인자로 받음
//                  - CardStatCalculator (스탯 계층 합류 계산)
// =================================================================

using System.Collections.Generic;
using System.Threading;
using Cysharp.Threading.Tasks;
using UnityEngine;

/// <summary>전투 참여 액터 추상화. 카드 시스템은 이 인터페이스로만 액터를 다룬다.</summary>
public interface ICombatActor
{
    bool IsAlive { get; }
    void TakeDamage(int amount);
    void GainBlock(int amount);
    void Heal(int amount);
    // 버프/디버프 스택 등은 전투 시스템에 맞춰 확장.
}

/// <summary>
/// 덱·에너지 등 액터가 아닌 게임 시스템에 작용하는 효과용 서비스.
/// 드로우/자원 획득처럼 특정 대상이 없는 효과가 사용. 전투 시스템이 구현 주입.
/// </summary>
public interface ICardGameService
{
    /// <summary>카드를 count 장 드로우.</summary>
    void DrawCards(int count, Card source = null);

    /// <summary>이미 생성된 카드 1장을 곧바로 손패에 추가한다 (드로우 더미 경유 없음).</summary>
    void AddCardToHand(Card card);

    /// <summary>에너지(자원)를 amount 만큼 획득.</summary>
    void GainEnergy(int amount);

    /// <summary>카드를 이번 전투의 소멸 영역으로 이동한다.</summary>
    void ExhaustCard(Card card);

    /// <summary>
    /// 전투 시작 시 초기 핸드 구성. 유저 덱에서 count 장 뽑아 핸드에 채운다.
    /// 덱 추출(랜덤)·핸드 추가·드로우 연출 전달은 구현체(덱 시스템)가 담당.
    /// </summary>
    void DrawInitialHand(int count);
}

/// <summary>
/// 카드 effect 런타임 훅이 참조하는 전투 서비스.
/// 일반 ExecuteAsync 보다 넓은 범위의 컨텍스트를 제공한다.
/// </summary>
public interface ICardRuntimeEventService
{
    ICombatActor Caster { get; }
    ICardGameService GameService { get; }
    CardStatCalculator StatCalculator { get; }
    GridManager Grid { get; }
    BattleReactiveEventBus ReactiveEvents { get; }
    ReactiveToggleQueue ReactiveToggles { get; }
    float GetEffectMultiplier(Card owner);

    void RegisterCastingPayload(Card owner, CastingEffect sourceEffect);
    void RegisterMagicCircleBuff(
        Card owner,
        EMagicCircleBuffType buffType,
        int toggleCount,
        int bonusAmount);
    void RegisterDispatchModifierCleanup(Card owner, string sourceKey);
    UniTask AdvanceCastingQueueAsync(Card activatedCard, CancellationToken token);
    void CancelCastingForOwner(Card owner);
    void ClearCastingQueue();
    UniTask DispatchPhaseAsync(Card owner, ETriggerPhase phase, CancellationToken token);
    UniTask DispatchCastingPayloadAsync(Card owner, ETriggerPhase phase, CancellationToken token);
    UniTask PropagateToggleAsync(Card owner, CancellationToken token);
    UniTask ExhaustGridCardAsync(Card card, CancellationToken token);
    UniTask DiscardGridCardAsync(Card card, CancellationToken token);
}

/// <summary>
/// 효과 실행에 필요한 모든 정보를 담는 컨텍스트.
/// 효과는 이 컨텍스트만 보고 동작하므로 외부 매니저에 직접 의존하지 않는다.
/// 풀링 재사용으로 실행마다 GC 를 발생시키지 않는다.
/// 스탯 수치 산출은 StatCalculator 에 위임 — 효과는 계산 로직을 직접 알지 않는다.
/// </summary>
public sealed class CardEffectContext
{
    public ICombatActor Caster { get; private set; }
    public List<ICombatActor> Targets { get; private set; }
    public Card Source { get; private set; }
    public ETriggerPhase Phase { get; private set; }

    /// <summary>덱/에너지 작용 효과용 서비스 (드로우 등). 없으면 null.</summary>
    public ICardGameService Service { get; private set; }

    /// <summary>스탯 최종값 산출기 (Base+Modifiers+Grid 합류). 데미지·방어 산출에 사용.</summary>
    public CardStatCalculator StatCalculator { get; private set; }

    /// <summary>추가 체인 전파처럼 전투 런타임 훅이 필요한 효과용 서비스.</summary>
    public ICardRuntimeEventService RuntimeService { get; private set; }
    public float EffectMultiplier { get; private set; } = 1f;

    public CardEffectContext()
    {
        Targets = new List<ICombatActor>(8);
    }

    /// <summary>컨텍스트 값 세팅. 재사용 시 매번 호출하여 상태 갱신.</summary>
    public void Set(
        ICombatActor caster,
        Card source,
        ETriggerPhase phase,
        ICardGameService service,
        CardStatCalculator statCalculator,
        ICardRuntimeEventService runtimeService)
    {
        Caster = caster;
        Source = source;
        Phase = phase;
        Service = service;
        StatCalculator = statCalculator;
        RuntimeService = runtimeService;
        EffectMultiplier = runtimeService != null
            ? Mathf.Max(1f, runtimeService.GetEffectMultiplier(source))
            : 1f;
        Targets.Clear();
    }

    public int ApplyEffectMultiplier(int value)
    {
        return Mathf.Max(0, Mathf.RoundToInt(value * EffectMultiplier));
    }

    /// <summary>
    /// 효과 기준값에 카드 스탯 modifier와 조건부 효과 배율을 순서대로 적용한다.
    /// 피해/방어/회복 효과는 이 진입점을 사용해 버프 계산 누락을 방지한다.
    /// </summary>
    public int CalculateEffectAmount(EStatType statType, int baseAmount)
    {
        if (Source == null || StatCalculator == null) return 0;

        int amount = StatCalculator.CalculateEffectAmount(Source.Stats, statType, baseAmount);
        return ApplyEffectMultiplier(amount);
    }

    /// <summary>카드 스탯 modifier, 그리드 보너스, 조건부 효과 배율을 순서대로 적용한다.</summary>
    public int CalculateEffectAmountWithGrid(
        EStatType statType,
        int baseAmount,
        EGridCountScope gridScope,
        float gridWeight)
    {
        if (Source == null || StatCalculator == null) return 0;

        int amount = StatCalculator.CalculateEffectAmountWithGrid(
            Source.Stats, Source, statType, baseAmount, gridScope, gridWeight);
        return ApplyEffectMultiplier(amount);
    }

}

/// <summary>
/// 카드 effect 의 배치/활성/외부 토글 훅에 전달되는 컨텍스트.
/// 카드별 clone 된 effect 인스턴스가 이 값을 통해 그리드와 디스패처에 접근한다.
/// </summary>
public sealed class CardRuntimeEventContext
{
    public Card Owner { get; private set; }
    public Card OtherCard { get; private set; }
    public ICardRuntimeEventService Service { get; private set; }

    public void Set(Card owner, Card otherCard, ICardRuntimeEventService service)
    {
        Owner = owner;
        OtherCard = otherCard;
        Service = service;
    }
}
