// =================================================================
// [스크립트 목적]  카드 생성 팩토리. SO 격리를 위해 변환/생성 2단계로 분리.
//                  FromSO: CardDataSO → CardRuntimeData (SO 를 만지는 유일한 통로)
//                  Create: CardRuntimeData → 런타임 Card (SO 를 모름)
// [주요 변수]      - 없음 (무상태 팩토리)
// [의존 관계]      - CardDataSO / CardRuntimeData / CardEffectBase.Clone
//                  - CardStats / CardArrowState / Card
//                  - 덱 매니저·드로우 시스템이 호출
// [설계 노트]      - ★ SO 의존이 FromSO 한 메서드에만 격리됨. Create 는 POCO 만 받음
//                  - 효과 Clone 은 Create 시점 — 카드 인스턴스별 런타임 상태 격리
//                  - 방향은 Create 시점에 1회 Resolve, CreatePreview 는 UI용 미결정 상태 유지
//                  - CreateFromSO 는 FromSO+Create 편의 래퍼 (기존 호출부 최소 수정용)
// =================================================================

using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// 카드 생성 팩토리. 정적 SO → 런타임 POCO 변환과, POCO → 런타임 카드 생성을 분리한다.
/// 효과를 Clone 하여 카드 인스턴스마다 독립된 런타임 상태를 갖게 한다
/// (SO/POCO 의 효과 인스턴스를 공유하면 한 카드의 상태가 다른 카드에 전염됨).
/// 스탯(CardStats)·방향(CardArrowState)도 카드별 독립 객체로 생성한다.
/// 무상태 — static 제공하되 전역 가변 상태는 두지 않는다 (C-5 준수).
/// </summary>
public static class CardFactory
{
    // ──────────────────────────────────────────────────────────────
    // ① 변환: CardDataSO → CardRuntimeData (SO 를 만지는 유일한 통로)
    // ──────────────────────────────────────────────────────────────

    /// <summary>
    /// 정적 SO 데이터를 런타임 POCO 로 변환한다 (SO 격리 경계).
    /// 강화 분기(기본/강화 선택)는 SO.ToRuntimeData 에서 1회 해소된다.
    /// </summary>
    public static CardRuntimeData FromSO(CardDataSO data, bool upgraded = false)
    {
        if (data == null)
        {
            Debug.LogError("[CardFactory] CardDataSO 가 null 입니다.");
            return null;
        }
        return data.ToRuntimeData(upgraded);
    }

    // ──────────────────────────────────────────────────────────────
    // ② 생성: CardRuntimeData → 런타임 Card (SO 를 모름)
    // ──────────────────────────────────────────────────────────────

    /// <summary>
    /// 런타임 POCO 로부터 런타임 카드 1장 생성.
    /// 효과를 Clone 하여 카드 인스턴스별 독립 상태를 보장한다.
    /// </summary>
    public static Card Create(CardRuntimeData runtime)
    {
        return CreateInternal(runtime, ECardDirection.None, false, true);
    }

    public static Card Create(CardRuntimeData runtime, ECardDirection resolvedDirection)
    {
        return CreateInternal(runtime, resolvedDirection, true, false);
    }

    /// <summary>런 덱 엔트리 UI 미리보기 생성. 런 영속 코스트 보정까지 반영한다.</summary>
    public static Card CreateRunDeckEntryPreview(RunDeckEntry entry, RunContext run)
    {
        if (entry?.RuntimeData == null) return null;

        Card card = Create(entry.RuntimeData, entry.ArrowDirection);
        if (card == null || run == null) return card;

        int costDelta = run.GetCardCostDelta(entry.EntryId);
        if (costDelta != 0) card.ApplyPermanentCostDelta(costDelta);
        return card;
    }

    /// <summary>UI 미리보기용 카드 생성. Random/Weighted 방향을 굴리지 않고 미결정 상태로 둔다.</summary>
    public static Card CreatePreview(CardRuntimeData runtime)
    {
        return CreateInternal(runtime, ECardDirection.None, false, false);
    }

    private static Card CreateInternal(
        CardRuntimeData runtime,
        ECardDirection resolvedDirection,
        bool useResolvedDirection,
        bool resolveDirection)
    {
        if (runtime == null)
        {
            Debug.LogError("[CardFactory] CardRuntimeData 가 null 입니다.");
            return null;
        }

        // ① 효과 복제 — 런타임 상태 격리.
        IReadOnlyList<CardEffectBase> sourceEffects = runtime.Effects;
        List<CardEffectBase> cloned = new List<CardEffectBase>(sourceEffects.Count);

        for (int i = 0; i < sourceEffects.Count; i++)
        {
            CardEffectBase src = sourceEffects[i];
            if (src == null)
            {
                Debug.LogWarning($"[CardFactory] '{runtime.CardId}' 의 {i}번 효과가 비어있습니다. 건너뜁니다.");
                continue;
            }
            cloned.Add(src.Clone());
        }

        // ② 수치 기준값은 Effect가 소유한다. CardStats는 런타임 modifier만 관리한다.
        CardStats stats = new CardStats();

        // ③ 방향 — 독립 런타임 상태 생성 후 "생성 시점에 1회 확정".
        //    Random/Weighted 도 여기서 굴려 카드의 평생 방향이 된다 (배치마다 변동 X).
        //    이후 손패·그리드 어디서나 동일 방향 유지 (덱빌더 정체성).
        CardArrowState arrow = new CardArrowState(runtime.Arrow);
        if (useResolvedDirection)
            arrow.Restore(resolvedDirection);
        else if (resolveDirection)
            arrow.Resolve();

        return new Card(runtime, cloned, stats, arrow, runtime.IsUpgraded);
    }

    // ──────────────────────────────────────────────────────────────
    // ③ 편의 래퍼: FromSO + Create (기존 호출부 최소 수정용)
    // ──────────────────────────────────────────────────────────────

    /// <summary>
    /// SO 로부터 곧바로 런타임 카드 생성 (FromSO + Create).
    /// 기존 Create(CardDataSO) 호출부는 이 메서드로 교체하면 인자 구조 그대로 동작한다.
    /// </summary>
    public static Card CreateFromSO(CardDataSO data, bool upgraded = false)
    {
        CardRuntimeData runtime = FromSO(data, upgraded);
        return runtime == null ? null : Create(runtime);
    }

    /// <summary>SO로부터 UI 미리보기용 카드를 생성한다. 게임 RNG와 보상 방향에는 영향을 주지 않는다.</summary>
    public static Card CreatePreviewFromSO(CardDataSO data, bool upgraded = false)
    {
        CardRuntimeData runtime = FromSO(data, upgraded);
        return runtime == null ? null : CreatePreview(runtime);
    }
}
