﻿// =================================================================
// [스크립트 목적]  Base + Modifiers + Grid 를 합친 최종 스탯 산출 (계산 계층)
// [주요 변수]      - _gridProvider : 그리드 집계 주입 (없으면 그리드 보너스 0)
// [의존 관계]      - CardStats (Base+Modifiers) / IGridStatProvider (Grid)
//                  - 효과(CardEffectBase 구현)가 데미지/방어 산출 시 호출
// [설계 노트]      - 그리드 집계는 매번 변하므로 CardStats 캐시 밖에서 합류
//                  - 그리드 보너스는 Flat 계층에 합류 → Base 와 동일 취급 후 %적용
// =================================================================

using UnityEngine;

/// <summary>
/// 카드 스탯의 최종값을 산출하는 계산 계층.
/// CardStats(Base+Modifiers) 에 그리드 집계 보너스를 합류시켜 최종 수치를 만든다.
/// 그리드 보너스는 "Flat 가산"으로 취급하므로, %모디파이어가 그리드 보너스까지 함께 증폭한다.
/// 그리드 시스템이 없거나 scope 가 None 이면 CardStats 값과 동일하다.
/// 무상태에 가까우며(주입된 provider 만 보유), 효과 실행 중 재사용해도 안전하다.
/// </summary>
public sealed class CardStatCalculator
{
    private readonly IGridStatProvider _gridProvider;

    /// <param name="gridProvider">그리드 집계 제공자. null 이면 그리드 보너스 없이 동작.</param>
    public CardStatCalculator(IGridStatProvider gridProvider)
    {
        _gridProvider = gridProvider;
    }

    /// <summary>
    /// 그리드 미반영 최종값 (Base + Modifiers 만).
    /// 그리드 집계가 필요 없는 스탯 조회 시 사용.
    /// </summary>
    public int Calculate(CardStats stats, EStatType stat)
    {
        if (stats == null) return 0;
        return stats.GetValueInt(stat);
    }

    /// <summary>
    /// effect 가 가진 기본 수치(baseAmount)에 카드 modifier 계층을 합쳐 최종값 계산.
    /// CardStats 의 base 값은 0이어도 동작하며, effect 소유 수치를 Flat 기준선으로 취급한다.
    /// </summary>
    public int CalculateEffectAmount(CardStats stats, EStatType stat, int baseAmount)
    {
        if (stats == null)
        {
            return Mathf.Max(0, baseAmount);
        }

        float value = stats.ComputeWithExtraFlat(stat, baseAmount);
        return Mathf.Max(0, Mathf.RoundToInt(value));
    }

    /// <summary>
    /// 그리드 집계까지 합류한 최종값.
    /// 계산: CardStats 의 (Base+ΣFlat) 단계에 (gridCount × gridWeight) 를 더한 뒤,
    /// CardStats 가 보유한 % 모디파이어가 함께 적용된 값을 돌려준다.
    ///
    /// 단, CardStats 의 % 계층은 내부에서만 적용되므로,
    /// 그리드 보너스에도 동일 % 를 태우려면 그리드 가산을 임시 모디파이어로 합류시킨다.
    /// 여기서는 부수효과(임시 모디파이어 추가) 없이, 그리드 가산을 Flat 으로 직접 합산해
    /// "(GetValue 결과) + (그리드 보너스)" 가 아닌 정확한 파이프라인 결과를 만든다.
    /// </summary>
    /// <param name="stats">대상 카드의 스탯 (Base+Modifiers).</param>
    /// <param name="card">그리드 집계 기준 카드 (위치/소유 조회용).</param>
    /// <param name="stat">조회할 스탯 종류.</param>
    /// <param name="scope">그리드 집계 범위. None 이면 그리드 보너스 없음.</param>
    /// <param name="gridWeight">집계 1개당 가중치 (zip 의 × value 대응). 기본 1.</param>
    public int CalculateWithGrid(
        CardStats stats,
        Card card,
        EStatType stat,
        EGridCountScope scope,
        float gridWeight = 1f)
    {
        if (stats == null) return 0;

        // 그리드 보너스가 없으면 일반 경로와 동일.
        if (scope == EGridCountScope.None || _gridProvider == null || card == null)
        {
            return stats.GetValueInt(stat);
        }

        int gridCount = _gridProvider.GetGridCount(card, scope);
        float gridBonus = gridCount * gridWeight;

        // 그리드 보너스를 Flat 계층에 합류시킨 최종값을 산출.
        // CardStats 에 임시 모디파이어를 넣었다 빼는 방식은 캐시 무효화·통지를 유발하므로,
        // 외부에서 동일 파이프라인을 1스탯에 한정해 재계산한다 (부수효과 없음).
        float withGrid = stats.ComputeWithExtraFlat(stat, gridBonus);
        return Mathf.Max(0, Mathf.RoundToInt(withGrid));
    }

    /// <summary>
    /// effect 기본 수치 + 그리드 보너스 + 카드 modifier 계층을 함께 반영한 최종값 계산.
    /// </summary>
    public int CalculateEffectAmountWithGrid(
        CardStats stats,
        Card card,
        EStatType stat,
        int baseAmount,
        EGridCountScope scope,
        float gridWeight = 1f)
    {
        if (stats == null)
        {
            return Mathf.Max(0, baseAmount);
        }

        float gridBonus = 0f;
        if (scope != EGridCountScope.None && _gridProvider != null && card != null)
        {
            int gridCount = _gridProvider.GetGridCount(card, scope);
            gridBonus = gridCount * gridWeight;
        }

        float value = stats.ComputeWithExtraFlat(stat, baseAmount + gridBonus);
        return Mathf.Max(0, Mathf.RoundToInt(value));
    }

    /// <summary>
    /// 그리드 집계 "수" 를 그대로 반환한다 (가중치·데미지 변환 없이 순수 카운트).
    /// 데미지가 아니라 횟수·개수 자체가 필요한 효과(타격수 스케일 등)가 사용한다.
    /// GridProvider 가 없거나 scope 가 None 이면 0.
    /// </summary>
    public int GetGridCount(Card card, EGridCountScope scope)
    {
        if (_gridProvider == null || card == null || scope == EGridCountScope.None)
        {
            return 0;
        }
        return _gridProvider.GetGridCount(card, scope);
    }
}
