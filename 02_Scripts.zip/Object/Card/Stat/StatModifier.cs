// =================================================================
// [스크립트 목적]  단일 스탯 모디파이어 (값 1개 + 연산 계층 + 생존주기 + 출처)
// [주요 변수]      - StatType : 어떤 스탯에 적용되는지
//                  - Type     : 연산 계층 (Flat/PercentAdd/PercentMult)
//                  - Value    : 모디파이어 값 (Flat=정수의미, Percent=0.5=50%)
//                  - Lifetime : 생존주기 (Transient=전투 종료 시 제거 / Permanent=유지)
//                  - Source   : 출처 식별자 (해제 시 일괄 제거용, 없으면 null)
// [의존 관계]      - CardStats 가 List 로 누적 관리
// [설계 노트]      - struct: 다량 누적 시 GC 회피. Source 만 참조형(string)
//                  - 강화 등 영구 변경은 Permanent 로, 전투용 버프는 Transient 로 구분
// =================================================================

using System;

/// <summary>
/// 스탯 1개에 대한 단일 보정값.
/// 값 타입(struct)으로 두어 다수 누적 시에도 힙 할당을 피한다.
/// Lifetime 으로 전투 종료 시 제거 여부를 구분한다 (영구 강화 보존용).
/// Source 는 효과/버프 단위 일괄 제거를 위한 식별자다 (예: 카드 인스턴스 ID, 버프 이름).
/// </summary>
[Serializable]
public readonly struct StatModifier
{
    /// <summary>적용 대상 스탯.</summary>
    public readonly EStatType StatType;

    /// <summary>연산 계층.</summary>
    public readonly EStatModifierType Type;

    /// <summary>보정 값. Flat 은 정수 의미, Percent 계열은 비율(0.5 = 50%).</summary>
    public readonly float Value;

    /// <summary>생존주기. Transient = 전투 종료 시 제거, Permanent = 유지(강화 등).</summary>
    public readonly EStatModifierLifetime Lifetime;

    /// <summary>출처 식별자. 같은 출처를 한 번에 제거할 때 사용. 없으면 null.</summary>
    public readonly string Source;

    public StatModifier(
        EStatType statType,
        EStatModifierType type,
        float value,
        EStatModifierLifetime lifetime = EStatModifierLifetime.Transient,
        string source = null)
    {
        StatType = statType;
        Type = type;
        Value = value;
        Lifetime = lifetime;
        Source = source;
    }

    // ── 간편 생성자 (Transient 기본) ────────────────────────

    /// <summary>Flat 모디파이어 간편 생성 (기본 Transient).</summary>
    public static StatModifier Flat(
        EStatType stat, float value,
        EStatModifierLifetime lifetime = EStatModifierLifetime.Transient, string source = null)
        => new StatModifier(stat, EStatModifierType.Flat, value, lifetime, source);

    /// <summary>% 가산 모디파이어 간편 생성 (0.5 = +50%, 기본 Transient).</summary>
    public static StatModifier PercentAdd(
        EStatType stat, float value,
        EStatModifierLifetime lifetime = EStatModifierLifetime.Transient, string source = null)
        => new StatModifier(stat, EStatModifierType.PercentAdd, value, lifetime, source);

    /// <summary>% 승산 모디파이어 간편 생성 (0.5 = ×1.5, 기본 Transient).</summary>
    public static StatModifier PercentMult(
        EStatType stat, float value,
        EStatModifierLifetime lifetime = EStatModifierLifetime.Transient, string source = null)
        => new StatModifier(stat, EStatModifierType.PercentMult, value, lifetime, source);

    /// <summary>영구 Flat 강화 간편 생성 (카드 강화·영구 업그레이드용).</summary>
    public static StatModifier PermanentFlat(EStatType stat, float value, string source = null)
        => new StatModifier(stat, EStatModifierType.Flat, value, EStatModifierLifetime.Permanent, source);
}
