﻿// =================================================================
// [스크립트 목적]  Effect 수치에 합류할 런타임 Modifiers 관리
// [주요 변수]      - _modifiers  : 런타임 누적 보정 리스트
//                  - _dirty      : 캐시 무효화 플래그 (변경 시에만 재계산)
//                  - _cache      : 스탯별 최종값 캐시 (그리드 미포함)
// [의존 관계]      - StatModifier / EStatType / EStatModifierType
//                  - CardStatCalculator 가 그리드 합류 후 최종값 산출에 사용
// [설계 노트]      - 그리드 집계는 매 조회마다 변하므로 이 클래스 캐시에 포함하지 않음
//                  - zip 의 BonusDamage = Flat(Damage) 모디파이어로 대체됨
//                  - Base 는 SO 기준선으로 불변. 강화 등 영구 변경도 Permanent 모디파이어로 누적
//                    (원본 불변 + 변경은 레이어로 — DataManager 철학과 일관, 추적·원복 용이)
// =================================================================

using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// 카드 1장의 스탯 상태. 두 계층으로 구성된다.
/// 1) Base   : SO 기준선(런타임 카드의 출발점). 이 인스턴스 안에서는 변하지 않는다.
///             ※ DataManager 원본 SO 가 아니라 그 복사값이다 — SO 원본은 별도로 영구 불변.
/// 2) Modifiers : 런타임 누적 보정값 (Flat/%Add/%Mult).
///             - Transient : 전투 종료 시 제거 (이번 전투용 버프).
///             - Permanent : 전투 종료에도 유지 (카드 강화·영구 업그레이드).
/// 그리드 동적 집계는 매번 변하므로 이 클래스가 아닌 CardStatCalculator 에서 합류시킨다.
/// 모디파이어 변경이 없으면 캐시를 재사용해 반복 조회 시 연산을 피한다.
/// </summary>
public sealed class CardStats
{
    // ── Base 계층 (불변 기준값) ──────────────────────────────
    private readonly Dictionary<EStatType, float> _baseStats;

    // ── Modifiers 계층 (런타임 누적 보정) ───────────────────
    private readonly List<StatModifier> _modifiers = new List<StatModifier>(8);

    // ── 캐시 (모디파이어까지 반영, 그리드 미포함) ───────────
    private readonly Dictionary<EStatType, float> _cache = new Dictionary<EStatType, float>();
    private bool _dirty = true;

    /// <summary>스탯/모디파이어 변경 알림 (UI 갱신용). zip 의 OnChanged 대응.</summary>
    public event System.Action OnChanged;

    /// <summary>읽기 전용 모디파이어 목록 (디버그/조회용).</summary>
    public IReadOnlyList<StatModifier> Modifiers => _modifiers;

    /// <summary>
    /// Base 스탯 맵으로 초기화. SO → CardFactory 단계에서 복사된 값을 받는다.
    /// 전달된 맵은 복사하여 보관하므로 호출 측 원본과 격리된다.
    /// </summary>
    public CardStats(IReadOnlyDictionary<EStatType, float> baseStats)
    {
        _baseStats = new Dictionary<EStatType, float>(baseStats != null ? baseStats.Count : 0);
        if (baseStats != null)
        {
            foreach (KeyValuePair<EStatType, float> kv in baseStats)
            {
                _baseStats[kv.Key] = kv.Value;
            }
        }
    }

    public CardStats()
    {
        _baseStats = new Dictionary<EStatType, float>();
    }

    // ── Base 계층 조회 ──────────────────────────────────────

    /// <summary>Base 기준값 조회 (모디파이어·그리드 미반영). 없으면 0.</summary>
    public float GetBase(EStatType stat)
    {
        return _baseStats.TryGetValue(stat, out float value) ? value : 0f;
    }

    // ── Modifiers 계층 관리 ─────────────────────────────────

    /// <summary>모디파이어 추가. 캐시를 무효화하고 변경을 통지한다.</summary>
    public void AddModifier(in StatModifier modifier)
    {
        _modifiers.Add(modifier);
        MarkDirty();
    }

    /// <summary>
    /// 특정 출처의 모디파이어 일괄 제거 (버프 해제·효과 종료용).
    /// 출처가 일치하는 항목을 모두 제거한다. 제거된 게 있으면 true.
    /// </summary>
    public bool RemoveModifiersBySource(string source)
    {
        if (string.IsNullOrEmpty(source)) return false;

        int removed = _modifiers.RemoveAll(m => m.Source == source);
        if (removed > 0)
        {
            MarkDirty();
            return true;
        }
        return false;
    }

    /// <summary>
    /// 임시(Transient) 모디파이어만 제거. 전투 종료 시 사용 (zip ClearCombatState 대응).
    /// 영구(Permanent) 모디파이어(강화 등)는 유지된다.
    /// </summary>
    public void ClearTransientModifiers()
    {
        int removed = _modifiers.RemoveAll(m => m.Lifetime == EStatModifierLifetime.Transient);
        if (removed > 0)
        {
            MarkDirty();
        }
    }

    /// <summary>
    /// 모든 모디파이어 제거 (영구 포함). 카드 인스턴스 폐기·완전 초기화 시에만 사용.
    /// 전투 종료 정리는 ClearTransientModifiers 를 사용할 것.
    /// </summary>
    public void ClearAllModifiers()
    {
        if (_modifiers.Count == 0) return;
        _modifiers.Clear();
        MarkDirty();
    }

    // ── 계산 (Base + Modifiers, 그리드 미포함) ──────────────

    /// <summary>
    /// Base + Modifiers 까지 반영한 값 조회 (그리드 보너스는 미포함).
    /// 그리드까지 합친 최종값은 CardStatCalculator 를 사용한다.
    /// 캐시가 유효하면 재계산 없이 반환한다.
    /// </summary>
    public float GetValue(EStatType stat)
    {
        if (_dirty)
        {
            RebuildCache();
        }
        return _cache.TryGetValue(stat, out float value) ? value : GetBase(stat);
    }

    /// <summary>int 형 최종값 (그리드 미포함). 데미지·방어 등 정수 스탯용.</summary>
    public int GetValueInt(EStatType stat)
    {
        // 음수 방지는 호출 도메인에 맡기지 않고 스탯 특성상 0 하한 적용.
        return Mathf.Max(0, Mathf.RoundToInt(GetValue(stat)));
    }

    /// <summary>
    /// 그리드 보너스(extraFlat)를 Flat 계층에 합류시킨 단일 스탯 계산.
    /// CardStatCalculator 가 그리드 집계값을 넘겨 호출한다.
    /// 모디파이어 리스트를 건드리지 않으므로 캐시 무효화·OnChanged 가 발생하지 않는다(부수효과 없음).
    /// extraFlat 은 Base·기존 Flat 과 함께 합산되어 동일하게 % 계층의 증폭을 받는다.
    /// </summary>
    public float ComputeWithExtraFlat(EStatType stat, float extraFlat)
    {
        // baseValue 에 그리드 보너스를 더해 동일 파이프라인을 태운다.
        return ComputeStat(stat, GetBase(stat) + extraFlat);
    }

    /// <summary>
    /// ComputeWithExtraFlat 과 동일하나, Source 가 excludeSourcePrefix 로 시작하는
    /// 모디파이어를 계산에서 제외한다. (흡수 카드가 다른 흡수 카드의 "흡수된 수치"를
    /// 다시 흡수하지 않고 기본 수치만 흡수하도록 하는 용도)
    /// </summary>
    public float ComputeWithExtraFlatExcludingSource(EStatType stat, float extraFlat, string excludeSourcePrefix)
    {
        return ComputeStat(stat, GetBase(stat) + extraFlat, excludeSourcePrefix);
    }

    // ── 내부 ────────────────────────────────────────────────

    /// <summary>
    /// 전체 스탯 캐시 재구성.
    /// 파이프라인: (Base + ΣFlat) × (1 + ΣPercentAdd) × Π(1 + PercentMult).
    /// 그리드 집계는 매 조회마다 변하므로 여기서 더하지 않는다.
    /// </summary>
    private void RebuildCache()
    {
        _cache.Clear();

        // Base 값을 먼저 시드. 모디파이어만 있고 Base 없는 스탯도 0 시드로 처리.
        foreach (KeyValuePair<EStatType, float> kv in _baseStats)
        {
            _cache[kv.Key] = ComputeStat(kv.Key, kv.Value);
        }

        // Base 에는 없지만 모디파이어로만 존재하는 스탯 보강.
        for (int i = 0; i < _modifiers.Count; i++)
        {
            EStatType stat = _modifiers[i].StatType;
            if (!_cache.ContainsKey(stat))
            {
                _cache[stat] = ComputeStat(stat, 0f);
            }
        }

        _dirty = false;
    }

    /// <summary>
    /// 단일 스탯의 파이프라인 계산.
    /// Flat 은 base 에 가산, PercentAdd 는 합산 후 1회 곱, PercentMult 는 개별 곱.
    /// </summary>
    private float ComputeStat(EStatType stat, float baseValue, string excludeSourcePrefix = null)
    {
        float flatSum = 0f;
        float percentAddSum = 0f;
        float percentMultProduct = 1f;

        for (int i = 0; i < _modifiers.Count; i++)
        {
            StatModifier mod = _modifiers[i];
            if (mod.StatType != stat) continue;

            // 지정 출처(예: 다른 흡수 카드의 흡수 결과)는 계산에서 제외.
            if (excludeSourcePrefix != null && mod.Source != null &&
                mod.Source.StartsWith(excludeSourcePrefix, System.StringComparison.Ordinal))
            {
                continue;
            }

            switch (mod.Type)
            {
                case EStatModifierType.Flat:
                    flatSum += mod.Value;
                    break;
                case EStatModifierType.PercentAdd:
                    percentAddSum += mod.Value;
                    break;
                case EStatModifierType.PercentMult:
                    percentMultProduct *= (1f + mod.Value);
                    break;
            }
        }

        float result = (baseValue + flatSum) * (1f + percentAddSum) * percentMultProduct;
        return result;
    }

    /// <summary>캐시 무효화 + 변경 통지.</summary>
    private void MarkDirty()
    {
        _dirty = true;
        OnChanged?.Invoke();
    }
}
