﻿// =================================================================
// [스크립트 목적]  SO 직렬화용 스탯 엔트리 ([Serializable]). Dictionary 직렬화 불가 대체
// [주요 변수]      - statType : 스탯 종류
//                  - value    : 기준값 (Base)
// [의존 관계]      - CardDataSO 가 List<StatEntry> 로 보유
//                  - CardStats 생성 시 Dictionary 로 변환되어 주입
// =================================================================

using System;
using UnityEngine;

/// <summary>
/// 인스펙터에서 스탯 1개를 설정하기 위한 직렬화 엔트리.
/// Unity 는 Dictionary 를 직렬화하지 못하므로 List 형태로 SO 에 보관하고,
/// 런타임에 CardStats 가 Dictionary 로 변환해 받는다.
/// </summary>
[Serializable]
public struct StatEntry
{
    [Tooltip("스탯 종류")]
    public EStatType statType;

    [Tooltip("기준값 (Base). 정수 스탯도 float 로 보관 후 계산 시 반올림")]
    public float value;

    public StatEntry(EStatType statType, float value)
    {
        this.statType = statType;
        this.value = value;
    }
}