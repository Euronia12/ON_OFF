// =================================================================
// [스크립트 목적]  카드 설명 템플릿의 {amount}/{hitCount} 등 토큰을 효과 수치로 치환
// [주요 변수]      - _tokens   : 위치 기반 토큰 캐시 (키=이름·인덱스 정수 인코딩, 값=수치+버프여부)
//                  - _sb       : Regex 치환 결과 빌더
//                  - _cardData : 카드 자체 데이터 토큰({range}) 해석용
// [의존 관계]      - CardRuntimeData / Card / CardEffectBase / CardStatCalculator
// [설계 노트]      - 토큰 값을 string 이 아닌 int 로 들고 있다가 _sb.Append(int) 로 직접 쓴다.
//                    StringBuilder.Append(int) 는 내부 버퍼에 숫자를 바로 포맷하므로 중간 문자열이
//                    생기지 않는다. (사전에 string 으로 담으면 템플릿이 쓰지도 않는 토큰까지
//                    ToString 으로 힙에 만들었다 버리게 된다 — 설명은 호버마다 재생성된다)
//                  - 사전 키도 "amount" + index 문자열 연결 대신 정수 인코딩을 써 할당을 없앤다.
// =================================================================

using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using UnityEngine;

public readonly struct CardDescriptionContext
{
    public int CurrentEnergy { get; }
    public int CurrentBlock { get; }

    public CardDescriptionContext(int currentEnergy, int currentBlock)
    {
        CurrentEnergy = Mathf.Max(0, currentEnergy);
        CurrentBlock = Mathf.Max(0, currentBlock);
    }
}

public sealed class CardDescriptionBuilder
{
    private static readonly Regex TokenRegex = new Regex(@"\{(\w+)\}", RegexOptions.Compiled);

    // 효과가 노출하는 토큰 이름. 배열 인덱스가 곧 사전 키의 이름 부분이 된다 (순서 변경 금지).
    private static readonly string[] FieldNames = { "amount", "hitCount", "threshold", "modifier" };

    // 버프로 올라간 수치를 감싸는 리치텍스트 태그. 매번 문자열을 만들지 않도록 1회만 생성한다.
    private static readonly string BuffedColorOpenTag = $"<color={EUIColor.GreenLight.ToHex()}>";
    private const string ColorCloseTag = "</color>";

    // 토큰 인덱스 상한. 사전 키 인코딩(nameIndex * IndexStride + index)과 파싱 자릿수 제한이 맞물린다.
    private const int IndexStride = 10000;
    private const int MaxIndexDigits = 4; // 9999 까지 — 그 이상은 비정상 토큰으로 보고 무시한다.

    /// <summary>토큰 1개의 해석 결과. 문자열이 아닌 수치로 들고 있다가 출력 시점에 직접 쓴다.</summary>
    private readonly struct TokenValue
    {
        public readonly int Value;
        public readonly bool IsBuffed; // 기본 수치보다 올라감 → 강화 색으로 감싼다.

        public TokenValue(int value, bool isBuffed)
        {
            Value = value;
            IsBuffed = isBuffed;
        }
    }

    // 키 = EncodeKey(이름 인덱스, 토큰 인덱스). 문자열 키를 쓰지 않아 조회·등록 모두 할당이 없다.
    private readonly Dictionary<int, TokenValue> _tokens = new Dictionary<int, TokenValue>(32);

    private readonly StringBuilder _sb = new StringBuilder(256);

    // 이번 Build 대상 카드의 정적 데이터. 카드 레벨 토큰({range}) 해석에 쓴다.
    private CardRuntimeData _cardData;

    public string Build(CardRuntimeData data, string template)
    {
        if (data == null || string.IsNullOrEmpty(template))
        {
            return template ?? string.Empty;
        }

        BuildTokens(data.Effects, null, null, default);
        return ReplaceTokens(template, data);
    }

    public string Build(Card card, CardStatCalculator calculator, string template)
    {
        return Build(card, calculator, template, default);
    }

    public string Build(Card card, CardStatCalculator calculator, string template, CardDescriptionContext descriptionContext)
    {
        if (card == null || string.IsNullOrEmpty(template))
        {
            return template ?? string.Empty;
        }

        BuildTokens(card.Effects, card, calculator, descriptionContext);
        return ReplaceTokens(template, card.Data);
    }

    private void BuildTokens(
        IReadOnlyList<CardEffectBase> effects,
        Card card,
        CardStatCalculator calculator,
        CardDescriptionContext descriptionContext)
    {
        _tokens.Clear();
        if (effects == null)
        {
            return;
        }

        int exposedIndex = 0;
        for (int i = 0; i < effects.Count; i++)
        {
            CardEffectBase effect = effects[i];
            if (effect == null)
            {
                continue;
            }

            bool exposesAny = false;
            RegisterField(effect.DescAmount, 0, exposedIndex, card, calculator, descriptionContext, ref exposesAny);
            RegisterField(effect.DescHitCount, 1, exposedIndex, card, calculator, descriptionContext, ref exposesAny);
            RegisterField(effect.DescThreshold, 2, exposedIndex, card, calculator, descriptionContext, ref exposesAny);
            RegisterField(effect.DescModifier, 3, exposedIndex, card, calculator, descriptionContext, ref exposesAny);

            if (exposesAny)
            {
                exposedIndex++;
            }
        }
    }

    /// <summary>
    /// 효과 필드 1개를 토큰으로 등록한다. 값은 수치 그대로 담고, 출력 문자열은 만들지 않는다.
    /// 인덱스 0 은 {amount} 처럼 인덱스 없는 토큰으로도 조회되므로 별도 등록이 필요 없다
    /// (조회 시 인덱스가 없으면 0 으로 파싱되어 같은 키가 된다).
    /// </summary>
    private void RegisterField(
        DescValue value,
        int nameIndex,
        int index,
        Card card,
        CardStatCalculator calculator,
        CardDescriptionContext descriptionContext,
        ref bool exposesAny)
    {
        if (!value.HasValue)
        {
            return;
        }

        exposesAny = true;

        // 인덱스가 상한을 넘으면 사전 키가 다른 이름과 충돌한다 — 등록하지 않고 알린다.
        if (index < 0 || index >= IndexStride)
        {
            WarnIndexOutOfRange(nameIndex, index);
            return;
        }

        int resolved = ResolveValue(value, card, calculator, descriptionContext);
        _tokens[EncodeKey(nameIndex, index)] = new TokenValue(resolved, IsBuffed(resolved, value));
    }

    /// <summary>
    /// 최종 수치가 기본 수치(StaticValue)보다 올라갔는가 (= 강화 색으로 감쌀 대상인가).
    /// ActivationRamp 등으로 스탯 모디파이어가 붙은 경우 GridSlot 과 동일하게 증가분을 눈에 띄게 표기.
    /// 동적 값(현재 마나/방어도 기반)은 비교 기준이 없어 색을 입히지 않는다.
    /// </summary>
    private static bool IsBuffed(int resolved, DescValue value)
    {
        bool comparable = value.StatType.HasValue && value.DynamicValue == EDescDynamicValue.None;
        return comparable && resolved > value.StaticValue;
    }

    private static int ResolveValue(
        DescValue value,
        Card card,
        CardStatCalculator calculator,
        CardDescriptionContext descriptionContext)
    {
        int dynamicBaseValue;
        switch (value.DynamicValue)
        {
            case EDescDynamicValue.CurrentBlockToDamageAmount:
                dynamicBaseValue = Mathf.Max(0, Mathf.RoundToInt(descriptionContext.CurrentBlock * 0.5f));
                return ResolveStatValue(value, dynamicBaseValue, card, calculator);
            case EDescDynamicValue.CurrentEnergy:
                return Mathf.Max(0, descriptionContext.CurrentEnergy);
        }

        if (value.StatType.HasValue && card != null)
        {
            return ResolveStatValue(value, value.StaticValue, card, calculator);
        }

        return Mathf.Max(0, value.StaticValue);
    }

    private static int ResolveStatValue(
        DescValue value,
        int baseValue,
        Card card,
        CardStatCalculator calculator)
    {
        if (!value.StatType.HasValue || card == null)
        {
            return Mathf.Max(0, baseValue);
        }

        if (calculator != null)
        {
            return calculator.CalculateEffectAmount(card.Stats, value.StatType.Value, baseValue);
        }

        if (card.Stats != null)
        {
            float currentValue = card.Stats.ComputeWithExtraFlat(value.StatType.Value, baseValue);
            return Mathf.Max(0, Mathf.RoundToInt(currentValue));
        }

        return Mathf.Max(0, baseValue);
    }

    private static int EncodeKey(int nameIndex, int index)
    {
        return nameIndex * IndexStride + index;
    }

    private string ReplaceTokens(string template, CardRuntimeData cardData)
    {
        _cardData = cardData;
        _sb.Clear();

        int lastIndex = 0;
        MatchCollection matches = TokenRegex.Matches(template);
        for (int i = 0; i < matches.Count; i++)
        {
            Match match = matches[i];
            _sb.Append(template, lastIndex, match.Index - lastIndex);

            string key = match.Groups[1].Value;
            if (!TryAppendToken(key))
            {
                _sb.Append(match.Value); // 미해석 토큰은 원문 그대로 남겨 눈에 띄게 한다.
                WarnMissingTokenOnce(key, template);
            }

            lastIndex = match.Index + match.Length;
        }

        _sb.Append(template, lastIndex, template.Length - lastIndex);

        _cardData = null; // 다음 Build 까지 카드 데이터를 붙들고 있지 않는다.
        return _sb.ToString();
    }

    /// <summary>토큰 1개를 _sb 에 쓴다. 해석 실패면 false (호출부가 원문을 남긴다).</summary>
    private bool TryAppendToken(string key)
    {
        if (string.IsNullOrEmpty(key))
        {
            return false;
        }

        // 1) 효과 토큰 ({amount} / {amount1} …)
        if (TryParseFieldToken(key, out int nameIndex, out int index) &&
            _tokens.TryGetValue(EncodeKey(nameIndex, index), out TokenValue token))
        {
            AppendTokenValue(token);
            return true;
        }

        // 2) 카드 자체 데이터 토큰 ({range})
        return TryAppendCardToken(key);
    }

    /// <summary>수치를 _sb 에 직접 쓴다. 버프로 올라간 값은 강화 색 태그로 감싼다 (문자열 할당 없음).</summary>
    private void AppendTokenValue(TokenValue token)
    {
        if (!token.IsBuffed)
        {
            _sb.Append(token.Value);
            return;
        }

        _sb.Append(BuffedColorOpenTag);
        _sb.Append(token.Value);
        _sb.Append(ColorCloseTag);
    }

    /// <summary>
    /// "amount" / "amount1" 형태의 토큰 이름을 이름 인덱스 + 숫자 인덱스로 파싱한다.
    /// Substring 은 문자열을 새로 할당하므로 쓰지 않고, 접두사 비교 + 자릿수 순회로 처리한다.
    /// 숫자가 없으면 인덱스 0 (= {amount} 는 첫 번째 효과의 amount).
    /// </summary>
    private static bool TryParseFieldToken(string key, out int nameIndex, out int index)
    {
        nameIndex = -1;
        index = 0;

        for (int i = 0; i < FieldNames.Length; i++)
        {
            string name = FieldNames[i];
            if (key.Length < name.Length)
            {
                continue;
            }

            if (string.Compare(key, 0, name, 0, name.Length, StringComparison.OrdinalIgnoreCase) != 0)
            {
                continue;
            }

            int digitCount = key.Length - name.Length;
            if (digitCount > MaxIndexDigits)
            {
                continue; // 인덱스가 비정상적으로 길다 — 이 이름이 아닌 것으로 본다.
            }

            int parsed = 0;
            bool allDigits = true;
            for (int c = name.Length; c < key.Length; c++)
            {
                char ch = key[c];
                if (ch < '0' || ch > '9')
                {
                    allDigits = false; // "amountX" 같은 오타는 이 이름으로 매칭하지 않는다.
                    break;
                }

                parsed = parsed * 10 + (ch - '0');
            }

            if (!allDigits)
            {
                continue;
            }

            nameIndex = i;
            index = parsed;
            return true;
        }

        return false;
    }

    /// <summary>
    /// 효과가 아닌 "카드 자체" 데이터 토큰({range})을 _sb 에 직접 쓴다.
    /// 사거리는 CardRuntimeData 가 이미 강화 반영값을 들고 있어 그대로 쓴다.
    /// </summary>
    private bool TryAppendCardToken(string key)
    {
        if (_cardData == null)
        {
            return false;
        }

        if (IsToken(key, "range"))
        {
            _sb.Append(_cardData.Range);
            return true;
        }

        return false;
    }

    private static bool IsToken(string key, string name)
    {
        return string.Equals(key, name, StringComparison.OrdinalIgnoreCase);
    }

    [System.Diagnostics.Conditional("UNITY_EDITOR"), System.Diagnostics.Conditional("DEVELOPMENT_BUILD")]
    private static void WarnMissingTokenOnce(string token, string template)
    {
#if UNITY_EDITOR || DEVELOPMENT_BUILD
        Debug.LogWarning($"[CardDescriptionBuilder] 설명 토큰 '{{{token}}}' 값을 찾지 못했습니다. template='{template}'");
#endif
    }

    [System.Diagnostics.Conditional("UNITY_EDITOR"), System.Diagnostics.Conditional("DEVELOPMENT_BUILD")]
    private static void WarnIndexOutOfRange(int nameIndex, int index)
    {
#if UNITY_EDITOR || DEVELOPMENT_BUILD
        string name = (nameIndex >= 0 && nameIndex < FieldNames.Length) ? FieldNames[nameIndex] : "?";
        Debug.LogWarning($"[CardDescriptionBuilder] 토큰 '{name}' 의 효과 인덱스({index})가 상한({IndexStride - 1})을 넘어 등록하지 않았습니다.");
#endif
    }
}
