// =================================================================
// [스크립트 목적]  "카드 앞면 + 설명"을 한 덩어리로 그리는 재사용 뷰.
//                 UICardFrontView 가 '앞면'만 담당한다면, 이것은 '앞면 + 설명'을
//                 담당하는 한 단계 위 조각. 손패 확대본/상점/보상 등에서 공통 재사용.
// [주요 변수]      - _frontView       : 카드 앞면(이름/그림/화살표/비용) 표시 컴포넌트
//                  - _descriptionText : 카드 설명 (DescriptionKey 로컬라이즈)
// [의존 관계]      - UICardFrontView(재사용) / Card / LocalizationManager(있으면)
// [배치]           카드 상세를 보여줄 프리팹 조각에 부착. 표시/숨김/위치는 관여 안 함.
// [설계 노트]      - 순수하게 "카드 한 장의 앞면+설명을 그린다"만 책임진다.
//                    표시 토글(CanvasGroup)·위치·가격·구매버튼 등은 이 뷰를 품는 상위가 담당.
//                  - 설명 로컬라이즈 규칙은 UICardFrontView 와 동일(매니저 없으면 키 폴백).
// =================================================================

using TMPro;
using UnityEngine;

/// <summary>
/// 카드 앞면 + 설명을 함께 그리는 재사용 뷰.
/// Setup(Card) 한 번으로 둘 다 채운다. 표시/위치 제어는 상위 컴포넌트가 한다.
/// </summary>
public sealed class UICardDetailView : MonoBehaviour, ILocalizable
{
    [Header("카드 앞면")]
    [Tooltip("카드 앞면 표시 컴포넌트")]
    [SerializeField] private UICardFrontView _frontView;

    [Header("상세 텍스트")]
    [Tooltip("카드 설명 표시. 비우면 생략")]
    [SerializeField] private TMP_Text _descriptionText;

    private Card _boundCard;
    private CardStatCalculator _boundCalculator;
    private int _currentEnergy;
    private int _currentBlock;

    /// <summary>카드 데이터로 앞면·설명을 채운다.</summary>
    public void Setup(Card card)
    {
        Setup(card, null);
    }

    public void Setup(Card card, CardStatCalculator calculator)
    {
        if (card == null) return;

        ApplyLocalizedFonts();
        _boundCard = card;
        _boundCalculator = calculator;

        if (_frontView != null)
        {
            _frontView.Setup(card);
        }

        RefreshDescription();
    }

    public void OnLocalize()
    {
        ApplyLocalizedFonts();
        _frontView?.RefreshLocalization();
        RefreshDescription();
    }

    /// <summary>현재 에너지 표시 갱신을 내부 앞면 뷰로 위임 (비용 부족 표시 등).</summary>
    public void SetCurrentEnergy(int currentEnergy)
    {
        _currentEnergy = Mathf.Max(0, currentEnergy);
        _frontView?.SetCurrentEnergy(currentEnergy);
        RefreshDescription();
    }

    public void SetCurrentBlock(int currentBlock)
    {
        _currentBlock = Mathf.Max(0, currentBlock);
        RefreshDescription();
    }

    // ── 내부 ───────────────────────────────────────────────

    private void RefreshDescription()
    {
        if (_descriptionText == null)
        {
            return;
        }

        string description = ResolveDescription(
            _boundCard,
            _boundCalculator,
            new CardDescriptionContext(_currentEnergy, _currentBlock));

        // TMP 의 text setter 는 내용이 같아도 새 문자열이면 메시를 다시 만든다.
        // 설명은 매번 새 string 으로 생성되므로, 내용 비교로 불필요한 재빌드를 막는다.
        if (_descriptionText.text != description)
        {
            _descriptionText.text = description;
        }
    }

    private static string ResolveDescription(
        Card card,
        CardStatCalculator calculator,
        CardDescriptionContext descriptionContext)
    {
        if (card?.Data == null || string.IsNullOrEmpty(card.Data.DescriptionKey))
        {
            return string.Empty;
        }

        if (LocalizationManager.HasInstance)
        {
            return LocalizationManager.Instance.GetCardDescription(card, calculator, descriptionContext);
        }
        return card.Data.DescriptionKey;
    }

    private void OnEnable()
    {
        if (LocalizationManager.HasInstance)
            LocalizationManager.Instance.Register(this);
        else
            ApplyLocalizedFonts();
    }

    private void OnDisable()
    {
        if (LocalizationManager.HasInstance)
            LocalizationManager.Instance.Unregister(this);
    }

    private void OnDestroy()
    {
        if (LocalizationManager.HasInstance)
            LocalizationManager.Instance.Unregister(this);
    }

    private void ApplyLocalizedFonts()
    {
        LocalizedFontUtility.ApplyCurrentFont(_descriptionText);
    }
}
