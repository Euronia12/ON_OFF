// =================================================================
// [스크립트 목적]  플레이어 전투 액터 (IBattleActor). 체력·방어막·에너지(카드 코스트 자원) 관리
// [주요 변수]      - _hp/_maxHp/_block : 체력·방어막
//                  - _energy/_maxEnergy : 에너지 = 카드 코스트 자원 (턴당 완전 회복)
// [의존 관계]      - IBattleActor : ICombatActor 구현
//                  - BattleManager 가 인터페이스로 제어 + 에너지 소모/회복 호출
//                  - UIActorStatus 가 변동 이벤트 구독해 표시
// [설계 노트]      - POCO(MonoBehaviour 아님): 수치만. 비주얼/위치는 PlayerView(3단계)가 분리
//                  - 에너지: 슬더슬식 — 턴 시작 시 최대로 완전 회복, 카드 배치 시 코스트만큼 소모
//                  - 방어막: 피해 우선 흡수, 턴 경계(ResetBlock)에서 소모
// =================================================================

using System;
using UnityEngine;

/// <summary>
/// 플레이어 액터 구현. 체력·방어막·에너지를 자체 관리하는 POCO.
/// 에너지는 카드 코스트 자원으로, 턴마다 최대치로 완전 회복되고 카드 배치 시 소모된다.
/// 모든 수치 변동은 이벤트로 통지해 UI(비주얼)와 분리한다.
/// </summary>
public sealed class PlayerActor : IBattleActor
{
    private int _hp;
    private int _maxHp;
    private int _block;
    private int _energy;
    private int _maxEnergy;

    public int Hp => _hp;
    public int MaxHp => _maxHp;
    public int Block => _block;
    public bool IsAlive => _hp > 0;

    /// <summary>현재 에너지 (= 사용 가능한 카드 코스트 자원).</summary>
    public int Energy => _energy;

    /// <summary>턴당 최대 에너지.</summary>
    public int MaxEnergy => _maxEnergy;

    public event Action OnDied;

    /// <summary>체력 변동 통지 (HP바 UI). (현재값, 최대값)</summary>
    public event Action<int, int> OnHpChanged;

    /// <summary>피해 적용 통지. (요청 피해, HP 피해, 방어막 흡수량)</summary>
    public event Action<int, int, int> OnDamageTaken;

    /// <summary>방어막 변동 통지.</summary>
    public event Action<int> OnBlockChanged;

    /// <summary>에너지 변동 통지 (에너지 UI). (현재값, 최대값)</summary>
    public event Action<int, int> OnEnergyChanged;

    // ── IBattleActor ────────────────────────────────────────

    /// <summary>전투 시작 초기화. 체력 가득, 방어막 0, 에너지 가득.</summary>
    public void Setup(int maxHp)
    {
        _maxHp = Mathf.Max(1, maxHp);
        _hp = _maxHp;
        _block = 0;

        OnHpChanged?.Invoke(_hp, _maxHp);
        OnBlockChanged?.Invoke(_block);

        // 에너지 최대치가 설정돼 있으면 가득 채움 (SetupEnergy 가 먼저 불릴 수도 있음).
        if (_maxEnergy > 0)
        {
            _energy = _maxEnergy;
            OnEnergyChanged?.Invoke(_energy, _maxEnergy);
        }
    }

    /// <summary>전투 시작 초기화 (현재 체력 지정). 런 HP 유지용 — currentHp 로 시작 체력 설정.</summary>
    public void Setup(int maxHp, int currentHp)
    {
        _maxHp = Mathf.Max(1, maxHp);
        _hp = Mathf.Clamp(currentHp, 1, _maxHp); // 시작 시 최소 1 (0이면 즉사 방지)
        _block = 0;

        OnHpChanged?.Invoke(_hp, _maxHp);
        OnBlockChanged?.Invoke(_block);

        if (_maxEnergy > 0)
        {
            _energy = _maxEnergy;
            OnEnergyChanged?.Invoke(_energy, _maxEnergy);
        }
    }

    /// <summary>턴 경계 방어막 정리 (소모형 블록).</summary>
    public void ResetBlock()
    {
        if (_block == 0) return;
        _block = 0;
        OnBlockChanged?.Invoke(_block);
    }

    /// <summary>현재 방어막을 지정량만큼 직접 소비한다 (피해 흡수와 무관, 방밀 등 방어도 소모 효과용).</summary>
    public void ConsumeBlock(int amount)
    {
        amount = Mathf.Clamp(amount, 0, _block);
        if (amount == 0) return;
        _block -= amount;
        OnBlockChanged?.Invoke(_block);
    }

    // ── 에너지 (카드 코스트 자원) ───────────────────────────

    /// <summary>최대 에너지 설정 (전투 시작 시 1회). 설정 즉시 가득 채움.</summary>
    public void SetupEnergy(int maxEnergy)
    {
        _maxEnergy = Mathf.Max(0, maxEnergy);
        _energy = _maxEnergy;
        OnEnergyChanged?.Invoke(_energy, _maxEnergy);
        PublishManaSignal(_energy);
    }

    /// <summary>턴 시작 시 에너지를 최대치로 완전 회복 (슬더슬 방식).</summary>
    public void RefillEnergy()
    {
        if (_energy == _maxEnergy) return;
        _energy = _maxEnergy;
        OnEnergyChanged?.Invoke(_energy, _maxEnergy);
        PublishManaSignal(_energy);
    }

    /// <summary>코스트만큼 지불 가능한지 여부.</summary>
    public bool CanAfford(int cost) => _energy >= cost;

    /// <summary>에너지 소모. 부족하면 false 반환(미소모). 성공 시 차감 후 true.</summary>
    public bool SpendEnergy(int cost)
    {
        if (cost < 0) cost = 0;
        if (_energy < cost) return false;

        _energy -= cost;
        OnEnergyChanged?.Invoke(_energy, _maxEnergy);
        return true;
    }

    /// <summary>에너지 획득 (효과용 ICardGameService.GainEnergy 위임 대상). 최대 초과 허용.</summary>
    public void GainEnergy(int amount)
    {
        if (amount <= 0) return;
        _energy += amount;
        OnEnergyChanged?.Invoke(_energy, _maxEnergy);
        PublishManaSignal(_energy);
    }

    // 마나(Energy) 값 변경을 업적 신호로 발행 (증가 경로 한정). Bridge가 임계값(10)을 판정.
    private static void PublishManaSignal(int current)
    {
        if (EventManager.HasInstance)
            EventManager.Instance.Publish(new ManaChangedSignal(current));
    }

    // ── ICombatActor ────────────────────────────────────────

    /// <summary>피해 적용. 방어막이 먼저 흡수하고 초과분만 체력 차감.</summary>
    public void TakeDamage(int amount)
    {
        if (amount <= 0 || !IsAlive) return;

        int beforeHp = _hp;
        int blockAbsorbed = 0;
        int remaining = amount;

        // 방어막 우선 흡수.
        if (_block > 0)
        {
            int absorbed = Mathf.Min(_block, remaining);
            _block -= absorbed;
            remaining -= absorbed;
            blockAbsorbed = absorbed;
            OnBlockChanged?.Invoke(_block);
        }

        if (remaining > 0)
        {
            _hp = Mathf.Max(0, _hp - remaining);
            OnHpChanged?.Invoke(_hp, _maxHp);
        }

        int hpDamage = beforeHp - _hp;
        if (hpDamage > 0 || blockAbsorbed > 0)
        {
            OnDamageTaken?.Invoke(amount, hpDamage, blockAbsorbed);
        }

        if (_hp == 0)
        {
            OnDied?.Invoke();
        }
    }

    /// <summary>방어막 획득.</summary>
    public void GainBlock(int amount)
    {
        if (amount <= 0) return;
        _block += amount;
        OnBlockChanged?.Invoke(_block);
    }

    /// <summary>회복. 최대 체력 한도.</summary>
    public void Heal(int amount)
    {
        if (amount <= 0 || !IsAlive) return;
        _hp = Mathf.Min(_maxHp, _hp + amount);
        OnHpChanged?.Invoke(_hp, _maxHp);
    }

    /// <summary>Dev/Test 커맨드가 방어막을 무시하고 현재 체력만 직접 낮추는 좁은 경계.</summary>
    public void DebugReduceHp(int amount)
    {
        if (amount <= 0 || !IsAlive) return;

        int beforeHp = _hp;
        _hp = Mathf.Max(0, _hp - amount);
        OnHpChanged?.Invoke(_hp, _maxHp);

        int hpDamage = beforeHp - _hp;
        if (hpDamage > 0) OnDamageTaken?.Invoke(hpDamage, hpDamage, 0);

        if (_hp == 0) OnDied?.Invoke();
    }
}
