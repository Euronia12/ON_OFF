﻿// =================================================================
// [스크립트 목적]  플레이어 '대표 객체' (PoolableMonoBehaviour). 하이어라키에 존재하며
//                 PlayerActor(로직)와 PlayerView(그림)를 소유한다. 플레이어의 주체.
// [주요 변수]      - _view  : 자식 비주얼 (그림·피격연출). 위치 제공
//                  - _actor : 플레이어 로직 액터 (HP·방어막·에너지). 코드 생성·소유
// [의존 관계]      - PoolableMonoBehaviour / PlayerActor / PlayerView
// [배치]           World 카테고리 풀 프리팹. 자식에 PlayerView(+SpriteRenderer).
// [설계 노트]      - 플레이어는 1종이라 sealed (적과 달리 상속 확장 불필요).
//                  - View 는 그림만, 대표는 이 Player. Actor 는 POCO 라 Player 가 생성·소유.
//                  - 상태 전파: Actor 이벤트 → View·UI 직접 구독. Player 는 잇기만.
// =================================================================

using UnityEngine;

/// <summary>
/// 플레이어 대표 객체. PlayerActor(로직)와 PlayerView(그림)를 소유·연결한다.
/// 풀링 대상이지만 보통 전투당 1개 재사용된다 (적처럼 자주 교체되진 않음).
/// </summary>
public sealed class Player : PoolableMonoBehaviour
{
    [Header("비주얼")]
    [Tooltip("플레이어 그림·피격 연출 담당 자식 View. 위치(Anchor) 제공")]
    [SerializeField] private PlayerView _view;

    // 로직 액터 (코드 생성·소유).
    private PlayerActor _actor;

    /// <summary>플레이어 로직 액터 (HP·방어막·에너지·이벤트). 외부는 이걸 구독한다.</summary>
    public PlayerActor Actor => _actor;

    /// <summary>플레이어 비주얼 View (위치 제공 ICombatTarget).</summary>
    public PlayerView View => _view;

    protected override void OnPoolCreate()
    {
        if (_view == null)
        {
            _view = GetComponentInChildren<PlayerView>(includeInactive: true);
        }
    }

    public override void OnReturnToPool()
    {
        _view?.Unbind();
        base.OnReturnToPool();
    }

    /// <summary>
    /// 플레이어 객체 구성. PlayerActor 를 만들고 체력·에너지를 셋업한 뒤 View 에 바인딩한다.
    /// BattleController 가 Spawn 직후 호출한다. Actor 는 이후 외부(UI·BattleManager)가 구독.
    /// </summary>
    /// <param name="maxHp">최대 체력.</param>
    /// <param name="maxEnergy">최대 에너지(카드 코스트 자원).</param>
    public void Setup(int maxHp, int maxEnergy)
    {
        _actor = new PlayerActor();
        _actor.SetupEnergy(maxEnergy);
        _actor.Setup(maxHp);

        if (_view != null)
        {
            _view.gameObject.SetActive(true);
            _view.Bind(_actor);
        }
    }
}