// =================================================================
// [스크립트 목적]  플레이어 비주얼 표현체. 월드 위치(ICombatTarget) 제공 + 피격 연출 훅.
//                 PlayerActor(로직)와 분리 — 위치/연출만 담당.
// [주요 변수]      - _anchor    : 투사체 도착점·이펙트 위치 (없으면 자기 Transform)
//                  - _spriteRoot: 피격 흔들림 대상 (선택)
// [의존 관계]      - ICombatTarget / PlayerActor (이벤트 구독)
//                  - BattleVfxPresenter 가 AnchorTransform 참조 (자기 대상 연출)
// [배치]           전투 씬의 플레이어 위치에 배치
// [설계 노트]      - 버프·회복·방어 연출의 도착점. 그리드 카드 출발점의 반대편
// =================================================================

using System.Collections;
using System.Threading;
using Cysharp.Threading.Tasks;
using DG.Tweening;
using UnityEngine;

/// <summary>
/// 플레이어의 씬 비주얼. 자기 대상 연출(버프·회복·방어)의 월드 위치를 제공하고,
/// PlayerActor 의 피격 이벤트에 가벼운 흔들림으로 반응한다.
/// </summary>
public sealed class PlayerView : MonoBehaviour, ICombatTarget
{
    [Header("연출 기준점")]
    [Tooltip("투사체 도착·이펙트 재생 위치. 비우면 자기 Transform 사용")]
    [SerializeField] private Transform _anchor;

    [Header("효과 발동 애니메이션 (선택)")]
    [Tooltip("카드 효과 발동 시 재생할 Animator. 비우면 재생 생략")]
    [SerializeField] private Animator _effectAnimator;

    [Tooltip("재생할 Animator 상태의 전체 경로")]
    [SerializeField] private string _effectAnimationStateName = "Base Layer.Player_Attack";

    [Tooltip("역방향 효과 Animator 상태의 전체 경로")]
    [SerializeField] private string _reverseEffectAnimationStateName = "Base Layer.Player_Attack_Reverse";

    [Tooltip("비피해 카드 체인 시작 Animator 상태의 전체 경로")]
    [SerializeField] private string _attack2StartAnimationStateName = "Base Layer.Player_Attack2_Start";

    [Tooltip("비피해 카드 체인 반복 Animator 상태의 전체 경로")]
    [SerializeField] private string _attack2LoopAnimationStateName = "Base Layer.Player_Attack2_Loop";

    [Tooltip("비피해 카드 체인 종료 Animator 상태의 전체 경로")]
    [SerializeField] private string _attack2EndAnimationStateName = "Base Layer.Player_Attack2_End";

    [Tooltip("대기 요청 소진 후 복귀할 Animator 상태의 전체 경로")]
    [SerializeField] private string _idleAnimationStateName = "Base Layer.Player_Idle";

    [Tooltip("맵에서 전투로 이동할 때 재생할 Animator 상태의 전체 경로")]
    [SerializeField] private string _walkAnimationStateName = "Base Layer.Player_Walk";

    [Tooltip("피격 시 재생할 Animator 상태의 전체 경로")]
    [SerializeField] private string _hitAnimationStateName = "Base Layer.Player_Hit";

    [Tooltip("패배 시 재생할 Animator 상태의 전체 경로")]
    [SerializeField] private string _defeatAnimationStateName = "Base Layer.Player_Defeated";

    [Tooltip("승리 시 재생할 Animator 상태의 전체 경로")]
    [SerializeField] private string _victoryAnimationStateName = "Base Layer.Player_Win";

    [Tooltip("캐릭터 좌우 반전에 사용할 SpriteRenderer. 비우면 같은 오브젝트에서 자동 탐색")]
    [SerializeField] private SpriteRenderer _spriteRenderer;

    [Header("피격 연출 (선택)")]
    [Tooltip("피격 시 흔들 대상. 비우면 흔들림 생략")]
    [SerializeField] private Transform _spriteRoot;

    [Tooltip("피격 흔들림 세기")]
    [SerializeField] private float _hitShakeStrength = 0.2f;

    [Tooltip("피격 흔들림 시간(초)")]
    [SerializeField] private float _hitShakeDuration = 0.2f;

    public Transform AnchorTransform => _anchor != null ? _anchor : transform;

    private PlayerActor _player;
    private Tween _hitTween;
    private Vector3 _spriteRootBaseLocalPosition;
    private bool _hasSpriteRootBaseLocalPosition;
    private int _effectAnimationStateHash;
    private int _reverseEffectAnimationStateHash;
    private int _attack2StartAnimationStateHash;
    private int _attack2LoopAnimationStateHash;
    private int _attack2EndAnimationStateHash;
    private int _idleAnimationStateHash;
    private int _walkAnimationStateHash;
    private int _hitAnimationStateHash;
    private int _defeatAnimationStateHash;
    private int _victoryAnimationStateHash;
    private EChainAttackAnimationMode _chainAttackAnimationMode;
    private Coroutine _chainAttackAnimationRoutine;

    private enum EChainAttackAnimationMode
    {
        None,
        Damage,
        NonDamage,
    }

    /// <summary>연쇄의 첫 카드 ON 시 효과 종류에 맞는 체인 애니메이션을 시작한다.</summary>
    public void PlayChainAttackAnimation(bool useNonDamageAnimation)
    {
        if (_effectAnimator == null || _chainAttackAnimationMode != EChainAttackAnimationMode.None)
        {
            return;
        }

        EChainAttackAnimationMode mode;
        if (useNonDamageAnimation && HasNonDamageChainAnimationStates())
        {
            mode = EChainAttackAnimationMode.NonDamage;
        }
        else if (HasDamageChainAnimationStates())
        {
            mode = EChainAttackAnimationMode.Damage;
        }
        else
        {
            return;
        }

        _chainAttackAnimationMode = mode;
        _chainAttackAnimationRoutine = StartCoroutine(PlayChainAttackAnimationRoutine(mode));
    }

    /// <summary>플레이어 액터 바인딩 — 실제 피격(HP 피해) 연출 구독.</summary>
    public void Bind(PlayerActor player)
    {
        Unbind();
        _player = player;
        if (player == null) return;

        // 전투 시작 HP 세팅(Setup)·회복(Heal)은 OnHpChanged만 발행하고 OnDamageTaken은 발행하지 않는다.
        // 피격 연출을 OnDamageTaken에 묶어 초기화·회복을 피격으로 오인하지 않도록 한다.
        player.OnDamageTaken += HandleDamageTaken;
    }

    private void Awake()
    {
        if (_spriteRenderer == null)
            _spriteRenderer = GetComponent<SpriteRenderer>();

        _effectAnimationStateHash = Animator.StringToHash(_effectAnimationStateName);
        _reverseEffectAnimationStateHash = Animator.StringToHash(_reverseEffectAnimationStateName);
        _attack2StartAnimationStateHash = Animator.StringToHash(_attack2StartAnimationStateName);
        _attack2LoopAnimationStateHash = Animator.StringToHash(_attack2LoopAnimationStateName);
        _attack2EndAnimationStateHash = Animator.StringToHash(_attack2EndAnimationStateName);
        _idleAnimationStateHash = Animator.StringToHash(_idleAnimationStateName);
        _walkAnimationStateHash = Animator.StringToHash(_walkAnimationStateName);
        _hitAnimationStateHash = Animator.StringToHash(_hitAnimationStateName);
        _defeatAnimationStateHash = Animator.StringToHash(_defeatAnimationStateName);
        _victoryAnimationStateHash = Animator.StringToHash(_victoryAnimationStateName);
        CaptureSpriteRootBasePosition();
    }

    /// <summary>전투 진입 이동 중 Walk 애니메이션을 재생한다.</summary>
    public void PlayWalkAnimation()
    {
        if (_effectAnimator == null || !_effectAnimator.HasState(0, _walkAnimationStateHash)) return;

        ResetChainAttackAnimation();
        _effectAnimator.Play(_walkAnimationStateHash, 0, 0f);
    }

    /// <summary>전투 진입 이동 종료 후 Idle 애니메이션으로 복귀한다.</summary>
    public void PlayIdleAnimation()
    {
        ResetChainAttackAnimation();
    }

    public void Unbind()
    {
        ResetChainAttackAnimation();
        StopHitTweenAndRestore();

        if (_player != null)
        {
            _player.OnDamageTaken -= HandleDamageTaken;
            _player = null;
        }
    }

    /// <summary>연쇄 종료 시 현재 모드의 종료 모션을 재생하고 Idle로 복귀한다.</summary>
    public async UniTask FinishChainAttackAnimationAsync(CancellationToken token)
    {
        EChainAttackAnimationMode mode = _chainAttackAnimationMode;
        if (mode == EChainAttackAnimationMode.None || _effectAnimator == null)
        {
            return;
        }

        while (_chainAttackAnimationRoutine != null)
        {
            await UniTask.Yield(PlayerLoopTiming.Update, token);
        }

        if (_chainAttackAnimationMode != mode || _effectAnimator == null)
        {
            return;
        }

        int finishStateHash = mode == EChainAttackAnimationMode.NonDamage
            ? _attack2EndAnimationStateHash
            : _reverseEffectAnimationStateHash;
        _effectAnimator.speed = 1f;
        _effectAnimator.Play(finishStateHash, 0, 0f);
        _effectAnimator.Update(0f);
        await UniTask.WaitUntil(
            () => _effectAnimator == null ||
                  _chainAttackAnimationMode != mode ||
                  IsAnimationStateComplete(finishStateHash),
            cancellationToken: token);

        if (_chainAttackAnimationMode != mode || _effectAnimator == null)
        {
            return;
        }

        _effectAnimator.speed = 1f;
        _effectAnimator.Play(_idleAnimationStateHash, 0, 0f);
        _chainAttackAnimationMode = EChainAttackAnimationMode.None;
    }

    /// <summary>전투 종료 시 연쇄 공격 애니메이션 상태를 초기화.</summary>
    public void ResetEffectAnimation()
    {
        ResetChainAttackAnimation();
    }

    /// <summary>패배 애니메이션을 처음부터 재생하고 마지막 프레임까지 기다린다.</summary>
    public async UniTask PlayDefeatAnimationAsync(CancellationToken token)
    {
        if (_effectAnimator == null || !_effectAnimator.HasState(0, _defeatAnimationStateHash))
        {
            return;
        }

        ResetChainAttackAnimation();
        StopHitTweenAndRestore();
        _effectAnimator.speed = 1f;
        _effectAnimator.Play(_defeatAnimationStateHash, 0, 0f);
        _effectAnimator.Update(0f);

        await UniTask.WaitUntil(
            () => _effectAnimator == null ||
                  _effectAnimator.GetCurrentAnimatorStateInfo(0).normalizedTime >= 1f,
            cancellationToken: token);
    }

    /// <summary>승리 애니메이션을 처음부터 1회 재생한다. 상태 전이가 없어 마지막 프레임을 유지한다.</summary>
    public void PlayVictoryAnimation()
    {
        if (_effectAnimator == null || !_effectAnimator.HasState(0, _victoryAnimationStateHash)) return;

        ResetChainAttackAnimation();
        _effectAnimator.speed = 1f;
        _effectAnimator.Play(_victoryAnimationStateHash, 0, 0f);
    }

    /// <summary>승리 애니메이션을 처음부터 1회 재생하고 마지막 프레임까지 기다린다.</summary>
    public async UniTask PlayVictoryAnimationAsync(CancellationToken token)
    {
        if (_effectAnimator == null || !_effectAnimator.HasState(0, _victoryAnimationStateHash))
            return;

        ResetChainAttackAnimation();
        StopHitTweenAndRestore();
        _effectAnimator.speed = 1f;
        _effectAnimator.Play(_victoryAnimationStateHash, 0, 0f);
        _effectAnimator.Update(0f);

        await UniTask.WaitUntil(
            () => _effectAnimator == null || IsAnimationStateComplete(_victoryAnimationStateHash),
            cancellationToken: token);
    }

    /// <summary>캐릭터 스프라이트의 좌우 방향을 설정한다.</summary>
    public void SetFlipX(bool flipX)
    {
        if (_spriteRenderer != null)
            _spriteRenderer.flipX = flipX;
    }

    private IEnumerator PlayChainAttackAnimationRoutine(EChainAttackAnimationMode mode)
    {
        int startStateHash = mode == EChainAttackAnimationMode.NonDamage
            ? _attack2StartAnimationStateHash
            : _effectAnimationStateHash;
        _effectAnimator.speed = 1f;
        _effectAnimator.Play(startStateHash, 0, 0f);
        _effectAnimator.Update(0f);

        while (_effectAnimator != null &&
               _chainAttackAnimationMode == mode &&
               !IsAnimationStateComplete(startStateHash))
        {
            yield return null;
        }

        if (_effectAnimator != null && _chainAttackAnimationMode == mode)
        {
            if (mode == EChainAttackAnimationMode.NonDamage)
            {
                _effectAnimator.Play(_attack2LoopAnimationStateHash, 0, 0f);
                _effectAnimator.Update(0f);
                _effectAnimator.speed = 1f;
            }
            else
            {
                _effectAnimator.Play(_effectAnimationStateHash, 0, 1f);
                _effectAnimator.Update(0f);
                _effectAnimator.speed = 0f;
            }
        }

        _chainAttackAnimationRoutine = null;
    }

    private bool HasDamageChainAnimationStates()
    {
        return _effectAnimator.HasState(0, _effectAnimationStateHash) &&
               _effectAnimator.HasState(0, _reverseEffectAnimationStateHash) &&
               _effectAnimator.HasState(0, _idleAnimationStateHash);
    }

    private bool HasNonDamageChainAnimationStates()
    {
        return _effectAnimator.HasState(0, _attack2StartAnimationStateHash) &&
               _effectAnimator.HasState(0, _attack2LoopAnimationStateHash) &&
               _effectAnimator.HasState(0, _attack2EndAnimationStateHash) &&
               _effectAnimator.HasState(0, _idleAnimationStateHash);
    }

    private bool IsAnimationStateComplete(int stateHash)
    {
        AnimatorStateInfo stateInfo = _effectAnimator.GetCurrentAnimatorStateInfo(0);
        return stateInfo.fullPathHash == stateHash && stateInfo.normalizedTime >= 1f;
    }

    private void ResetChainAttackAnimation()
    {
        if (_chainAttackAnimationRoutine != null)
        {
            StopCoroutine(_chainAttackAnimationRoutine);
            _chainAttackAnimationRoutine = null;
        }

        _chainAttackAnimationMode = EChainAttackAnimationMode.None;
        if (_effectAnimator == null) return;

        _effectAnimator.speed = 1f;
        if (_effectAnimator.HasState(0, _idleAnimationStateHash))
        {
            _effectAnimator.Play(_idleAnimationStateHash, 0, 0f);
        }
    }

    // 실제 HP 피해가 발생했을 때만 피격 연출. 방어막 전량 흡수(hpDamage=0)와
    // 사망 타격(패배 연출이 담당)은 제외한다.
    private void HandleDamageTaken(int amount, int hpDamage, int blockAbsorbed)
    {
        if (hpDamage <= 0) return;
        if (_player != null && _player.Hp <= 0) return;

        PlayHitAnimation();
        PlayHitShake();
    }

    private void PlayHitAnimation()
    {
        if (_effectAnimator == null || !_effectAnimator.HasState(0, _hitAnimationStateHash)) return;

        ResetChainAttackAnimation();
        _effectAnimator.speed = 1f;
        _effectAnimator.Play(_hitAnimationStateHash, 0, 0f);
    }

    private void PlayHitShake()
    {
        if (_spriteRoot == null) return;
        CaptureSpriteRootBasePosition();
        StopHitTweenAndRestore();
        _hitTween = _spriteRoot.DOShakePosition(_hitShakeDuration, _hitShakeStrength);
    }

    private void CaptureSpriteRootBasePosition()
    {
        if (_spriteRoot == null || _hasSpriteRootBaseLocalPosition) return;
        _spriteRootBaseLocalPosition = _spriteRoot.localPosition;
        _hasSpriteRootBaseLocalPosition = true;
    }

    private void StopHitTweenAndRestore()
    {
        _hitTween?.Kill();
        _hitTween = null;

        if (_spriteRoot != null && _hasSpriteRootBaseLocalPosition)
        {
            _spriteRoot.localPosition = _spriteRootBaseLocalPosition;
        }
    }

    private void OnDestroy()
    {
        StopHitTweenAndRestore();
        Unbind();
    }
}
