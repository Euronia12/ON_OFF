using UnityEngine;

/// <summary>MagicCircle 버프가 유지되는 동안 플레이어 앵커에 고정되는 VFX.</summary>
public sealed class MagicCircleVfxView : PoolableMonoBehaviour
{
    [Header("파티클 (선택)")]
    [SerializeField] private ParticleSystem[] _particleSystems;

    [Header("렌더 정렬")]
    [SerializeField] private string _sortingLayerName = "BackEffect";
    [SerializeField] private int _sortingOrder;

    private Renderer[] _renderers;

    protected override void OnPoolCreate()
    {
        base.OnPoolCreate();
        CacheComponents();
    }

    public override void OnSpawnFromPool()
    {
        base.OnSpawnFromPool();
        CacheComponents();
        ApplyRendererSorting();

        for (int i = 0; i < _particleSystems.Length; i++)
        {
            ParticleSystem particle = _particleSystems[i];
            if (particle == null) continue;
            particle.Clear(true);
            particle.Play(true);
        }
    }

    public override void OnReturnToPool()
    {
        for (int i = 0; i < _particleSystems.Length; i++)
        {
            ParticleSystem particle = _particleSystems[i];
            if (particle != null)
            {
                particle.Stop(true, ParticleSystemStopBehavior.StopEmittingAndClear);
            }
        }

        base.OnReturnToPool();
    }

    private void CacheComponents()
    {
        if (_particleSystems == null || _particleSystems.Length == 0)
        {
            _particleSystems = GetComponentsInChildren<ParticleSystem>(true);
        }

        _renderers = GetComponentsInChildren<Renderer>(true);
    }

    private void ApplyRendererSorting()
    {
        for (int i = 0; i < _renderers.Length; i++)
        {
            Renderer renderer = _renderers[i];
            if (renderer == null) continue;
            renderer.sortingLayerName = _sortingLayerName;
            renderer.sortingOrder = _sortingOrder;
        }
    }
}
