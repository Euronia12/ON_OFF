using UnityEngine;

/// <summary>Z축 기준으로 오브젝트를 시계방향 회전시킨다.</summary>
public sealed class RotateZClockwise : MonoBehaviour
{
    [SerializeField] private float _degreesPerSecond = 90f;

    private void Update()
    {
        transform.Rotate(0f, 0f, -_degreesPerSecond * Time.deltaTime, Space.Self);
    }
}
