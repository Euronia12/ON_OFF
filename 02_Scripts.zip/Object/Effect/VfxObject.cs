﻿// =================================================================
// [스크립트 목적]  풀링 적중 이펙트 오브젝트 (World 카테고리). 타겟 위치에 재생 후 자동 반환.
// [주요 변수]      - _autoReturnDelay : 재생 후 자동 반환까지 시간(초)
//                  - _particleSystem  : 파티클 (선택, 있으면 Play/Stop 제어)
//                  - _sortingLayerName/_sortingOrder : 스폰 시 렌더 정렬 강제값
// [의존 관계]      - PoolableMonoBehaviour / PoolManager
//                  - BattleVfxPresenter 가 Spawn (위치 세팅) → 자동 반환
// [설계 노트]      - 자동 반환: 스폰 시 코루틴/Invoke 로 일정 시간 뒤 Despawn (재생-망각 패턴)
//                  - presenter 가 완료를 await 할 필요 없는 fire-and-forget 연출
// =================================================================

using UnityEngine;

/// <summary>
/// 타겟 위치에서 재생되는 일회성 적중 이펙트. 스폰되면 파티클을 재생하고
/// 지정 시간 뒤 스스로 풀에 반환된다 (fire-and-forget).
/// </summary>
public sealed class VfxObject : PoolableMonoBehaviour
{
    [Header("자동 반환")]
    [Tooltip("재생 후 풀 반환까지 시간(초). 이펙트 길이에 맞춤")]
    [Min(0.05f)]
    [SerializeField] private float _autoReturnDelay = 1f;

    [Header("파티클 (선택)")]
    [Tooltip("재생할 파티클 시스템. 비우면 시간 경과만으로 반환")]
    [SerializeField] private ParticleSystem _particleSystem;

    [Header("렌더 정렬")]
    [Tooltip("스폰 시 하위 Renderer 에 강제 적용할 Sorting Layer")]
    [SerializeField] private string _sortingLayerName = "FrontEffect";

    [Tooltip("스폰 시 하위 Renderer 에 강제 적용할 Order in Layer")]
    [SerializeField] private int _sortingOrder = 0;

    private Renderer[] _renderers;
    private float _baseParticleSimulationSpeed = 1f;

    protected override void OnPoolCreate()
    {
        base.OnPoolCreate();
        CacheRenderers();
        if (_particleSystem != null)
        {
            _baseParticleSimulationSpeed = _particleSystem.main.simulationSpeed;
        }
    }

    /// <summary>스폰 시 — 파티클 재생 + 자동 반환 예약.</summary>
    public override void OnSpawnFromPool()
    {
        base.OnSpawnFromPool();
        ApplyRendererSorting();

        if (_particleSystem != null)
        {
            _particleSystem.Clear();
            _particleSystem.Play();
        }

        // 자동 반환 예약 (재호출 대비 기존 예약 취소 후).
        CancelInvoke(nameof(ReturnSelf));
        Invoke(nameof(ReturnSelf), _autoReturnDelay);
    }

    /// <summary>반환 시 — 파티클 정지 + 예약 취소.</summary>
    public override void OnReturnToPool()
    {
        CancelInvoke(nameof(ReturnSelf));
        if (_particleSystem != null)
        {
            _particleSystem.Stop();
            ParticleSystem.MainModule main = _particleSystem.main;
            main.simulationSpeed = _baseParticleSimulationSpeed;
        }
        base.OnReturnToPool();
    }

    /// <summary>지정 위치에 배치 (presenter 가 스폰 직후 호출).</summary>
    public void SetPosition(Vector3 worldPos)
    {
        transform.position = worldPos;
    }

    /// <summary>체인 VFX용 파티클 재생·반환 속도를 조정한다.</summary>
    public void SetPlaybackSpeed(float visualSpeedMultiplier, float minimumDuration)
    {
        float speed = Mathf.Max(0.0001f, BattleSpeedUtility.Multiplier * visualSpeedMultiplier);
        if (_particleSystem != null)
        {
            ParticleSystem.MainModule main = _particleSystem.main;
            main.simulationSpeed = _baseParticleSimulationSpeed * speed;
        }

        CancelInvoke(nameof(ReturnSelf));
        Invoke(nameof(ReturnSelf), Mathf.Max(minimumDuration, _autoReturnDelay / speed));
    }

    private void ReturnSelf()
    {
        if (PoolManager.HasInstance && PoolManager.Instance.IsPooledInstance(gameObject))
        {
            PoolManager.Instance.Despawn(this);
        }
        else
        {
            gameObject.SetActive(false);
        }
    }

    private void CacheRenderers()
    {
        _renderers = GetComponentsInChildren<Renderer>(true);
    }

    private void ApplyRendererSorting()
    {
        if (_renderers == null || _renderers.Length == 0)
        {
            CacheRenderers();
        }

        for (int i = 0; i < _renderers.Length; i++)
        {
            Renderer renderer = _renderers[i];
            if (renderer == null) continue;

            renderer.sortingLayerName = _sortingLayerName;
            renderer.sortingOrder = _sortingOrder;
        }
    }
}
