﻿// =================================================================
// [스크립트 목적]  풀링 투사체 오브젝트 (World 카테고리). 카드 → 타겟 이동 비주얼.
//                 이동 제어는 BattleVfxPresenter(UniTask)가, 자체는 풀 생명주기·리셋만 담당.
// [주요 변수]      - _trail : 트레일 렌더러 (반환 시 잔상 제거용, 선택)
// [의존 관계]      - PoolableMonoBehaviour / PoolManager
//                  - BattleVfxPresenter 가 Spawn → 이동 → Despawn 제어
// [설계 노트]      - 이동 로직을 오브젝트에 넣지 않음: presenter 가 await 로 묶어 타이밍 일원화.
//                    오브젝트는 풀 재사용 안전(트레일 클리어)만 책임.
// =================================================================

using UnityEngine;

/// <summary>
/// 풀에서 스폰되는 투사체 비주얼. 이동은 외부(presenter)가 UniTask 로 제어하고,
/// 이 컴포넌트는 풀 재사용 시 트레일 잔상 제거 등 상태 리셋만 담당한다.
/// </summary>
public sealed class ProjectileObject : PoolableMonoBehaviour
{
    [Header("트레일 (선택)")]
    [Tooltip("이동 잔상 트레일. 풀 반환 시 Clear 해 다음 사용에 잔상이 남지 않게 함")]
    [SerializeField] private TrailRenderer _trail;

    [Header("렌더 정렬")]
    [Tooltip("스폰 시 하위 Renderer 에 강제 적용할 Sorting Layer")]
    [SerializeField] private string _sortingLayerName = "FrontEffect";

    [Tooltip("스폰 시 하위 Renderer 에 강제 적용할 Order in Layer")]
    [SerializeField] private int _sortingOrder = 0;

    private Renderer[] _renderers;

    protected override void OnPoolCreate()
    {
        base.OnPoolCreate();
        CacheRenderers();
    }

    /// <summary>스폰 시 — 위치 세팅 후 트레일 초기화.</summary>
    public override void OnSpawnFromPool()
    {
        base.OnSpawnFromPool();
        ApplyRendererSorting();
        ClearTrail();
    }

    /// <summary>반환 시 — 트레일 잔상 제거 (다음 재사용 대비).</summary>
    public override void OnReturnToPool()
    {
        ClearTrail();
        base.OnReturnToPool();
    }

    /// <summary>출발 위치·방향 세팅 (presenter 가 이동 시작 전 호출).</summary>
    public void SetStart(Vector3 startPos, Vector3 targetPos)
    {
        transform.position = startPos;

        SetDirection(targetPos - startPos);

        ClearTrail();
    }

    public void SetDirection(Vector3 direction)
    {
        if (direction.sqrMagnitude > 0.0001f)
        {
            transform.rotation = Quaternion.LookRotation(Vector3.forward, direction);
        }
    }

    private void ClearTrail()
    {
        if (_trail != null)
        {
            _trail.Clear();
        }
    }

    private void CacheRenderers()
    {
        _renderers = GetComponentsInChildren<Renderer>(true);
    }

    private void ApplyRendererSorting()
    {
        if (_renderers == null || _renderers.Length == 0)
        {
            CacheRenderers();
        }

        for (int i = 0; i < _renderers.Length; i++)
        {
            Renderer renderer = _renderers[i];
            if (renderer == null) continue;

            renderer.sortingLayerName = _sortingLayerName;
            renderer.sortingOrder = _sortingOrder;
        }
    }
}
