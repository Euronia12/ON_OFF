// =================================================================
// [스크립트 목적]  게임 흐름·입력·오디오 관련 enum 묶음
//                 (GameFlowManager / GameManager / InputManager / AudioManager)
// =================================================================

/// <summary>
/// 빌드 환경 구분. 로컬 로그·디버그 기능 노출 범위 제어용.
/// Live(출시)에서는 로컬 파일 로그 비활성 등 운영 정책 분기에 사용.
/// </summary>
public enum EBuildEnv
{
    /// <summary>개발 환경 (개발자 PC). 모든 디버그·로컬 로그 활성</summary>
    Dev,

    /// <summary>테스트 환경 (QA·내부 테스트). 로컬 로그 활성</summary>
    Test,

    /// <summary>출시 환경 (실 서비스). 로컬 파일 로그 비활성</summary>
    Live
}

/// <summary>GameFlowManager 전역 상태 머신</summary>
public enum EGameState
{
    /// <summary>부팅 중 (매니저 초기화)</summary>
    Boot,

    /// <summary>타이틀 화면</summary>
    Title,

    /// <summary>씬 로딩 중</summary>
    Loading,

    /// <summary>게임 진행 중</summary>
    InGame,

    /// <summary>일시정지</summary>
    Paused,

    /// <summary>결과 화면 (클리어/실패)</summary>
    Result
}

/// <summary>
/// InputManager Action Map 식별자.
/// [주의] Input Actions 에셋의 Action Map 이름과 정확히 일치해야 함
/// </summary>
public enum EActionMap
{
    /// <summary>게임플레이 (이동, 공격 등)</summary>
    Gameplay,

    /// <summary>UI 조작 (메뉴 내비게이션)</summary>
    UI,

    /// <summary>메뉴 전용</summary>
    Menu,

    /// <summary>Dev/Test 환경에서만 추가 활성화하는 테스트 커맨드</summary>
    TestCommand
}

/// <summary>AudioManager 채널 구분. AudioMixer Exposed Parameter와 매핑</summary>
public enum EAudioChannel
{
    /// <summary>마스터 (전체)</summary>
    Master,

    /// <summary>BGM (배경음)</summary>
    Bgm,

    /// <summary>SFX (효과음)</summary>
    Sfx,

    /// <summary>UI 효과음</summary>
    Ui
}

/// <summary>화면 표시 모드. Unity FullScreenMode와 매핑</summary>
public enum EScreenMode
{
    FullScreen,        // 전용 전체화면 (배타적, 최고 성능)
    FullScreenWindow,  // 테두리 없는 창 전체화면 (기본 권장)
    Windowed           // 창 모드
}

/// <summary>게임 내 지원 언어. 옵션 UI는 이 enum 기준으로만 노출한다.</summary>
public enum EGameLanguage
{
    Korean,
    English,
    ChineseSimplified,
    ChineseTraditional,
    Japanese,
    German
}

/// <summary>옵션에서 선택 가능한 프레임 제한.</summary>
public enum EFrameRateOption
{
    Fps30,
    Fps60,
    Fps120
}

/// <summary>옵션에서 선택 가능한 해상도.</summary>
public enum EResolutionOption
{
    R1280x720,
    R1280x800,
    R1600x900,
    R1680x1050,
    R1920x1080,
    R1920x1200,
    R2560x1440,
    R2560x1600,
    R3840x2160
}

/// <summary>설정 카테고리. 카테고리별 초기화(ResetCategory) 분기용</summary>
public enum ESettingsCategory
{
    Sound,      // 볼륨·음소거·백그라운드 음소거
    Graphics,   // 품질·VSync·프레임·밝기
    Screen,     // 해상도·화면모드·주사율
    Gameplay    // 진동·화면흔들림·고속모드·텍스트효과
}
