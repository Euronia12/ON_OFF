﻿// =================================================================
// [스크립트 목적]  UI 관련 enum 묶음 (UIManager / UIBase)
// =================================================================

/// <summary>
/// UI가 그려질 공간(Canvas 종류). 프리팹에서 지정 → UIManager가 알맞은 루트에 배치.
/// Screen : 화면 고정 UI (Screen Space - Camera). UIRoot(영속)에 배치.
/// World  : 3D 공간 UI (World Space). 씬 종속 WorldRoot에 배치 (씬 전환 시 정리).
/// </summary>
public enum EUISpace
{
    /// <summary>화면 고정 UI (HUD·팝업·옵션 등). Screen Space - Camera 모드</summary>
    Screen,

    /// <summary>3D 공간 UI (머리 위 체력바·월드 마커 등). World Space 모드, 씬 종속</summary>
    World
}

/// <summary>
/// UI 레이어. UIManager가 레이어별 부모 Transform 생성·관리.
/// 열거 순서가 곧 렌더링 순서 (뒤쪽이 더 위에 표시됨).
/// Screen / World 두 공간 모두 동일한 레이어 계층을 각자 생성.
/// (World는 보통 HUD/Window 정도만 쓰지만 일관성을 위해 동일 enum 재사용)
/// </summary>
public enum EUILayer
{
    /// <summary>상시 표시 (체력바, 미니맵)</summary>
    HUD,

    /// <summary>일반 창 (인벤토리, 상점)</summary>
    Window,

    /// <summary>노드 맵. 일반 창 위, 일반 팝업 아래에 표시된다.</summary>
    Node,

    /// <summary>노드 맵 위에 고정 표시하는 정보 UI. 일반 팝업 아래에 표시된다.</summary>
    NodeOverlay,

    /// <summary>팝업 (확인 다이얼로그). ESC로 닫기 가능</summary>
    Popup,

    /// <summary>토스트/알림. 게임 막지 않고 잠깐 뜨는 가벼운 메시지. Popup 위, System 아래</summary>
    Notice,

    /// <summary>시스템 (옵션, 일시정지). 게임 진행 막는 전역 UI</summary>
    System,

    /// <summary>로딩 인디케이터(스피너 등). 로딩 중 입력 차단. System 위, Fade 아래</summary>
    Loading,

    /// <summary>화면 전환 페이드 + 로딩화면. 위 모든 것을 덮지만 Top보다는 아래</summary>
    Fade,

    /// <summary>최상위 (마우스 클릭 이펙트 등). 페이드 중에도 보임</summary>
    Top
}
