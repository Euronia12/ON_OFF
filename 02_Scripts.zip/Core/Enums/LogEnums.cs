// =================================================================
// [스크립트 목적]  GameLogger 카테고리 비트플래그
//                 비트 연산 기반 필터링으로 GC·성능 모두 우수
// [사용 예시]      GameLogger.SetEnabledCategories(ELogCategory.System | ELogCategory.Resource);
// =================================================================
using System;

[Flags]
public enum ELogCategory
{
    None      = 0,
    System    = 1 << 0,
    Resource  = 1 << 1,
    UI        = 1 << 2,
    Audio     = 1 << 3,
    Input     = 1 << 4,
    Save      = 1 << 5,
    Data      = 1 << 6,
    Pool      = 1 << 7,
    Scene     = 1 << 8,
    Network   = 1 << 9,
    Analytics = 1 << 10,
    Gameplay  = 1 << 11,
    All       = ~0
}
