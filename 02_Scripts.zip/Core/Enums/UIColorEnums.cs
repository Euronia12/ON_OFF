// =================================================================
// [스크립트 목적]  UI 색상 팔레트. 그룹(Gray/Red/Yellow/Green/Blue)별 4단계(어두움→밝음)를
//                  enum + 확장 메서드로 받아오게 한다 (하드코딩 색상 분산 방지).
// [사용 예시]      _priceText.color = EUIColor.RedDark.ToColor();   // 티켓 부족(#744848)
//                  string hex = EUIColor.RedDark.ToHex();           // 리치텍스트용 "#744848"
// [설계 노트]      - 색을 바꿀 땐 이 파일의 hex 한 곳만 수정 → 전 UI 일괄 반영.
//                  - 단계: Darkest < Dark < Light < Lightest (값이 클수록 밝음).
// =================================================================

using UnityEngine;

/// <summary>UI 팔레트 색. 그룹별 4단계(어두움→밝음).</summary>
public enum EUIColor
{
    // Base Gray
    GrayDarkest, GrayDark, GrayLight, GrayLightest,
    // Red
    RedDarkest, RedDark, RedLight, RedLightest,
    // Yellow
    YellowDarkest, YellowDark, YellowLight, YellowLightest,
    // Green
    GreenDarkest, GreenDark, GreenLight, GreenLightest,
    // Blue
    BlueDarkest, BlueDark, BlueLight, BlueLightest,
}

/// <summary>EUIColor → Color/hex 변환 확장. 색 정의(hex)를 여기 한 곳에 집중한다.</summary>
public static class UIColorExtensions
{
    public static string ToHexString(this EUIColor color)
    {
        switch (color)
        {
            // Base Gray
            case EUIColor.GrayDarkest: return "#2C2C2C";
            case EUIColor.GrayDark: return "#686864";
            case EUIColor.GrayLight: return "#A0A4A0";
            case EUIColor.GrayLightest: return "#D8E0D8";
            // Red
            case EUIColor.RedDarkest: return "#421E1E";
            case EUIColor.RedDark: return "#8A3E3E";
            case EUIColor.RedLight: return "#C56A62";
            case EUIColor.RedLightest: return "#EEBCB0";
            // Yellow
            case EUIColor.YellowDarkest: return "#3E2E14";
            case EUIColor.YellowDark: return "#8A6E28";
            case EUIColor.YellowLight: return "#C6AE4A";
            case EUIColor.YellowLightest: return "#EFE08A";
            // Green
            case EUIColor.GreenDarkest: return "#1E3A26";
            case EUIColor.GreenDark: return "#3E7A44";
            case EUIColor.GreenLight: return "#6EB870";
            case EUIColor.GreenLightest: return "#BCE6B4";
            // Blue
            case EUIColor.BlueDarkest: return "#182E44";
            case EUIColor.BlueDark: return "#345E86";
            case EUIColor.BlueLight: return "#6494BE";
            case EUIColor.BlueLightest: return "#B6D6EE";
            default: return "#FFFFFF";
        }
    }

    /// <summary>팔레트 색 → Color.</summary>
    public static Color ToColor(this EUIColor color) => FromHex(color.ToHexString());

    /// <summary>TMP 리치텍스트용 "#RRGGBB" 문자열 (숫자만 색 입힐 때 등).</summary>
    public static string ToHex(this EUIColor color) => color.ToHexString();

    /// <summary>hex 문자열 → Color. 파싱 실패 시 흰색 폴백.</summary>
    public static Color FromHex(string hex)
    {
        return ColorUtility.TryParseHtmlString(hex, out Color c) ? c : Color.white;
    }
}
