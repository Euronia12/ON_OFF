// =================================================================
// [스크립트 목적]  풀링 관련 enum 묶음 (PoolManager / PoolableMonoBehaviour)
// =================================================================

/// <summary>풀링 오브젝트 카테고리. 카테고리별로 부모 Transform 자동 배정</summary>
public enum EPoolCategory
{
    /// <summary>월드 오브젝트 (적, 발사체). 일반 풀 루트 하위</summary>
    World,

    /// <summary>UI 요소 (팝업 카드, 토스트). 지정된 UI Canvas 하위</summary>
    UI,

    /// <summary>VFX / 파티클. 별도 Effect 그룹</summary>
    Effect,

    /// <summary>AudioSource 풀. AudioManager 풀 루트 하위</summary>
    Audio
}

/// <summary>풀 최대 크기 초과 시 정책</summary>
public enum EPoolOverflow
{
    /// <summary>최대치 초과분은 Despawn 시 파괴 (메모리 절약)</summary>
    DestroyExcess,

    /// <summary>제한 없이 모두 보관 (재사용 우선, 메모리 증가 허용)</summary>
    KeepAll
}
