// =================================================================
// [스크립트 목적]  전투 페이즈 상태 정의 enum (입력/처리/경계 3축 세분화)
// [주요 항목]      - BattleStart/End : 전투 경계
//                  - PlayerInput     : 플레이어 조작 대기
//                  - PreserveSelect  : 보존 카드 선택
//                  - PlayerResolve   : 플레이어 턴 해결 처리
//                  - EnemyResolve    : 적 턴 해결 처리
// [의존 관계]      - BattleManager 가 상태머신으로 사용
// [설계 노트]      - zip 의 _isBattleActive 등 bool 플래그를 페이즈로 승격 (상태 명확화)
//                  - Input(입력 대기) vs Resolve(처리 중) 네이밍 일관
// =================================================================

/// <summary>
/// 전투 진행 페이즈. 입력 대기/처리 중/경계를 명확히 구분한다.
/// 확장 시 EnemyIntent(의도 표시)·TurnStart(턴 시작 효과) 등을 사이에 끼워넣을 수 있다.
/// </summary>
public enum EBattlePhase
{
    /// <summary>비활성 (전투 전/종료 후).</summary>
    None = 0,

    /// <summary>전투 초기화 (액터 셋업, 1회).</summary>
    BattleStart = 1,

    /// <summary>플레이어 조작 대기 (카드 배치·확정 입력).</summary>
    PlayerInput = 2,

    /// <summary>보존 카드 선택 (턴 종료 시 남길 카드).</summary>
    PreserveSelect = 3,

    /// <summary>플레이어 턴 해결 처리 (턴종료 효과·누적 공격 적용).</summary>
    PlayerResolve = 4,

    /// <summary>적 턴 해결 처리 (적 행동·방어 정리).</summary>
    EnemyResolve = 5,

    /// <summary>전투 종료 (승/패 판정).</summary>
    BattleEnd = 6,
}

/// <summary>
/// 적의 한 턴 의도 종류. 플레이어에게 미리 표시되는 행동 예고에 사용.
/// 공격/방어와 그리드 개입 패턴을 지원하며, 버프·디버프·복합 행동은 추후 확장한다.
/// </summary>
public enum EEnemyIntentType
{
    /// <summary>플레이어를 공격 (Amount = 피해량).</summary>
    Attack = 0,

    /// <summary>자신에게 방어막 부여 (Amount = 방어량).</summary>
    Defend = 1,

    /// <summary>플레이어 그리드의 빈 칸에 임시 무방향 카드를 설치 (Amount = 설치 개수).</summary>
    InstallBlankCards = 2,

    /// <summary>빈 칸에 ON 상태 방해 블록을 설치 (Amount = 설치 개수).</summary>
    InstallOnDisturbanceBlocks = 3,

    /// <summary>예고한 행 또는 열의 그리드를 한 턴 동안 파괴.</summary>
    GridLineAttack = 4,

    /// <summary>다음 플레이어 턴 동안 그리드 카드 정보를 숨김.</summary>
    EraseInfo = 5,

    /// <summary>한 턴 동안 플레이어가 마나를 획득할 때마다 적이 방어도를 얻는다. Amount = 획득 방어도.</summary>
    BuffBlockOnPlayerManaGain = 6,

    /// <summary>한 턴 동안 플레이어가 카드를 드로우할 때마다 플레이어에게 피해를 준다. Amount = 피해량.</summary>
    BuffDamageOnPlayerDraw = 7,

    /// <summary>한 턴 동안 카드가 일정 횟수 ON 될 때마다 방해 블록을 설치한다. Amount = 설치 수, Hits = 필요 ON 횟수(0이면 10).</summary>
    BuffInstallDisturbanceOnCardToggle = 8,

    /// <summary>다음 플레이어 턴 동안 그리드 카드 종류(이름/스탯)만 숨기고 방향 화살표는 그대로 보인다. EraseInfo 의 완화판.</summary>
    EraseCardKindOnly = 9,

    /// <summary>플레이어 손패에 저주 카드를 직접 설치한다. 손패에 남은 채 턴 종료되면 플레이어가 피해를 입고 소멸. Amount = 설치 장수.</summary>
    InstallHandCurse = 10,
}

/// <summary>선형 그리드 공격이 가로 행을 지나는지 세로 열을 지나는지 구분한다.</summary>
public enum EGridLineAxis
{
    Row = 0,
    Column = 1,
}

/// <summary>경고 표시와 실제 공격이 공유하는 선형 공격 경로.</summary>
public readonly struct GridLineAttackPlan
{
    public EGridLineAxis Axis { get; }
    public int Index { get; }
    public bool Forward { get; }

    public GridLineAttackPlan(EGridLineAxis axis, int index, bool forward)
    {
        Axis = axis;
        Index = index;
        Forward = forward;
    }
}

/// <summary>
/// 적 등급. 노드맵의 전투 노드 타입(Battle/Elite/Boss/Test)과 대응하며,
/// EncounterAssigner 가 노드 타입에 맞는 등급의 적 풀에서 추첨한다.
/// </summary>
public enum EEnemyGrade
{
    /// <summary>일반 전투 적.</summary>
    Normal = 0,

    /// <summary>엘리트 전투 적.</summary>
    Elite = 1,

    /// <summary>보스 적.</summary>
    Boss = 2,

    /// <summary>테스트 노드 전용 적.</summary>
    Test = 3,
}
