﻿// =================================================================
// [스크립트 목적]  카드 시스템 전역 enum 정의 (효과 비트/타겟/페이즈/등급/지속/키워드 + 스탯)
// [주요 변수]      - ECardEffectFlag : 동시 보유 가능 효과 비트 (조회/UI/필터용)
//                  - ETargetType     : 효과 적용 대상 분류
//                  - ETriggerPhase   : 효과 발동 타이밍
//                  - EEffectDuration : 효과·버프 지속(소멸) 타이밍
//                  - ECardType       : 카드 분류 (일반/파워/스킬)
//                  - ECardRarity     : 카드 희귀도 (일반/레어/유니크)
//                  - ECardKeyword    : 특수 키워드 비트 (선천성/보존 등)
//                  - EStatType         : 스탯 수치의 종류 (계산용)
//                  - EStatModifierType : 스탯 모디파이어 연산 계층
//                  - EGridCountScope   : 그리드 동적 집계 범위
// [의존 관계]      - 카드 데이터·효과·디스패처·스탯 계층 전반에서 참조
// =================================================================

using System;

/// <summary>
/// 카드가 동시에 보유할 수 있는 효과 종류 비트마스크.
/// 공격·방어가 한 카드에 레이어처럼 동시 존재 가능하도록 [Flags] 사용.
/// 비트는 "조회/필터/UI" 용도이며, 실제 실행은 효과 인스턴스 리스트가 담당한다.
/// </summary>
[Flags]
public enum ECardEffectFlag
{
    None = 0,
    Damage = 1 << 0, // 공격
    Block = 1 << 1, // 방어
    Heal = 1 << 2, // 회복
    DrawCard = 1 << 3, // 드로우
    GainMana = 1 << 4, // 자원 획득
    ApplyBuff = 1 << 5, // 버프 부여
    ApplyDebuff = 1 << 6, // 디버프 부여
    Reserve = 1 << 7, //보존 부여
    Toggle = 1 << 8,
    Spawn = 1 << 9, // 카드 생성 (핸드에 임시 카드 추가)
    ManaBurst = 1 << 10, // 마나 전량 소비 데미지 (X 가변 코스트)
    // 확장 시 1 << n 으로 추가.
}

/// <summary>효과가 적용될 대상 분류. 복합 타겟팅(자신/아군/적군/AoE)을 표현한다.</summary>
public enum ETargetType
{
    Self,            // 시전자 자신
    SingleEnemy,     // 적 단일 (선택)
    AllEnemies,      // 적 전체 (AoE)
    RandomEnemy,     // 적 무작위 1
    Card,            // 주변 카드 대상

    None,            // 대상 없음 (자원 획득·드로우 등)
}

/// <summary>
/// 효과 발동 타이밍. 카드 생명주기 훅과 전투 페이즈를 단일 enum으로 통합.
/// 디스패처가 현재 페이즈에 매칭되는 효과만 실행한다.
/// </summary>
public enum ETriggerPhase
{
    OnDraw,        // 손으로 뽑을 때
    OnPlay,        // 사용(플레이)할 때 ※ 가장 일반적
    OnDiscard,     // 버려질 때
    OnExhaust,     // 소멸될 때
    OnTurnStart,   // 턴 시작 시
    OnTurnEnd,     // 턴 종료 시
    BattlePrepare, // 전투 준비 페이즈
    BattleAttack,  // 전투 공격 페이즈
    BattleResolve, // 전투 해결 페이즈
}

/// <summary>
/// 효과·버프의 지속(소멸) 타이밍. "언제까지 유지되는가".
/// 버프/디버프 지속 관리 및 그리드 회수 처리에 사용.
/// </summary>
public enum EEffectDuration
{
    Instant,      // 즉발 (지속 없음)
    EndOfTurn,    // 이번 턴 종료 시 소멸
    OnLeaveGrid,  // 그리드에서 회수될 때 소멸
    EndOfBattle,  // 전투 종료 시 소멸
    Permanent,    // 영구 (해당 전투 내내 유지)
}

/// <summary>카드 분류 축. 효과 성격에 따른 구분 (희귀도와 독립).</summary>
public enum ECardType
{
    Normal, // 일반
    Casting,  // 캐스팅
    Totem,  // 토템
    Reserve, // 보존
}

/// <summary>카드 희귀도 축. 등장 빈도·가치 (분류와 독립).</summary>
public enum ECardRarity
{
    Common, // 일반
    Rare,   // 레어
    Unique, // 유니크
    Legendary, // 전설
}

/// <summary>
/// 카드가 등장할 수 있는 스테이지/챕터 비트마스크.
/// pools 는 노드 타입(상점/일반/엘리트/보스), stages 는 진행 구간을 담당한다.
/// </summary>
[Flags]
public enum ECardStagePool
{
    None = 0,
    Stage1 = 1 << 0,
    Stage2 = 1 << 1,
    Stage3 = 1 << 2,
    All = Stage1 | Stage2 | Stage3,
}

/// <summary>
/// 카드 특수 키워드 비트마스크. 효과가 아닌 카드 "속성".
/// 동시 보유 가능하므로 [Flags].
/// </summary>
[Flags]
public enum ECardKeyword
{
    None = 0,
    Innate = 1 << 0, // 선천성: 전투 첫 턴 손패에 보장
    Retain = 1 << 1, // 보존: 턴 종료 시 버려지지 않음
    Exhaust = 1 << 2, // 소멸: 사용 후 덱에서 제거
    Ethereal = 1 << 3, // 휘발: 사용 안 하면 턴 끝에 소멸
    Unplayable = 1 << 4, // 사용 불가 (특수 카드)
    Casting = 1 << 5, // 캐스팅: 다른 카드 발동 시 수치 감소 후 0되면 발동
    Reserve = 1 << 6, // 보존: 카드의 보존 상태를 부여
    Absorb = 1 << 7, // 흡수: 화살표 방향 카드의 스탯을 흡수 (흡수된 수치는 재흡수 불가)
    Offspring = 1 << 8, // 분신: ON 될 때마다 새끼카드를 손패에 생성
    Predate = 1 << 9, // 포식: 캐스팅 발동 시 화살표 방향 카드를 포식해 위력 강화
    MagicCircle = 1 << 10, // 마법진: 이후 ON 카드에 횟수 제한 버프 부여
    // 확장 시 1 << n 으로 추가.
}

/// <summary>전투 덱에 들어온 카드의 출처. 런 저장 여부와 전투 종료 시 수명을 구분한다.</summary>
public enum EBattleDeckOwner
{
    RunDeck = 0,
    PlayerTemporary = 1,
    EnemyTemporary = 2,
}

// =================================================================
// 스탯 계층 enum (Base + Modifiers + Grid 계산용)
// =================================================================

/// <summary>
/// 카드가 보유할 수 있는 스탯 수치의 종류 (계산용 키).
/// ECardEffectFlag(효과 "보유 여부" 비트)와 역할이 다르다 — 이쪽은 "수치 값"을 다룬다.
/// 명명은 ECardEffectFlag 와 정렬: DealDamage↔Damage, GainBlock↔Block, Heal↔Heal.
/// 고정 구조체 대신 enum 키로 다루어, 스탯 추가 시 계산 로직 변경 없이 확장한다.
/// 직렬화 호환을 위해 명시적 정수값을 유지한다.
/// </summary>
public enum EStatType
{
    None = 0,

    /// <summary>공격 데미지 (ECardEffectFlag.DealDamage 와 대응).</summary>
    Damage = 1,

    /// <summary>방어(블록)량 (ECardEffectFlag.GainBlock 과 대응).</summary>
    Block = 2,

    /// <summary>회복량 (ECardEffectFlag.Heal 과 대응).</summary>
    Heal = 3,

    /// <summary>방향 연결 시 추가되는 데미지 보너스 (zip DirectionalDamageBonus).</summary>
    DirectionalDamageBonus = 4,

    /// <summary>카드 드로우 수.</summary>
    DrawCard = 5,

    /// <summary>획득 에너지 수.</summary>
    Energy = 6,
}

/// <summary>
/// 모디파이어 적용 계층. enum 정수값이 곧 계산 파이프라인의 적용 순서다.
/// 최종값 = (Base + ΣFlat) × (1 + ΣPercentAdd) × Π(1 + PercentMult).
/// 현재 zip 효과는 전부 Flat 이지만, %증가 효과 확장에 대비해 계층을 미리 둔다.
/// </summary>
public enum EStatModifierType
{
    /// <summary>정수 가산. Base 및 그리드 집계값과 같은 계층에서 합산된다.</summary>
    Flat = 100,

    /// <summary>비율 가산. 모두 합산한 뒤 (1 + 합) 으로 한 번만 곱한다. 예: +50% +30% → ×1.8.</summary>
    PercentAdd = 200,

    /// <summary>비율 승산. 각 모디파이어를 (1 + 값) 으로 개별 곱한다. 예: +50% ×2 → ×2.25.</summary>
    PercentMult = 300,
}

/// <summary>
/// 모디파이어의 생존 주기. 전투 종료 시 임시 보정은 제거하되 영구 변경(강화 등)은 보존한다.
/// Base 는 SO 기준선으로 불변 유지하고, 강화 같은 영구 변경도 Permanent 모디파이어로 누적한다
/// (DataManager 의 "원본 불변 + 변경은 레이어로" 철학과 일관 — 추적·원복 용이).
/// </summary>
public enum EStatModifierLifetime
{
    /// <summary>임시 보정. 전투 종료(ClearTransient) 시 제거된다. 예: 이번 전투용 버프.</summary>
    Transient = 0,

    /// <summary>영구 보정. 전투 종료에도 유지된다. 예: 카드 강화·영구 업그레이드.</summary>
    Permanent = 1,
}

/// <summary>
/// 그리드 기반 동적 집계 범위.
/// zip 의 CountScope 를 명명 규칙(C-7: E 접두사)에 맞춰 이식.
/// 집계 "정의"만 담당하고, 실제 집계 값은 IGridStatProvider 구현이 계산한다.
/// </summary>
public enum EGridCountScope
{
    /// <summary>집계 없음 (그리드 보너스 미사용).</summary>
    None = 0,

    /// <summary>같은 행(Row)의 대상 카드 수.</summary>
    Row = 1,

    /// <summary>같은 열(Column)의 대상 카드 수.</summary>
    Column = 2,

    /// <summary>행 + 열(십자) 범위의 대상 카드 수.</summary>
    Cross = 3,

    /// <summary>그리드 전체의 대상 카드 수.</summary>
    Total = 4,

    /// <summary>이 카드가 이번 턴에 ON 된 횟수 (zip Self / TurnOnCount).</summary>
    SelfTurnOnCount = 5,

    /// <summary>그리드 전체가 이번 턴에 ON 된 횟수 (zip GridTotal / _turnToggleCount).</summary>
    GridTurnOnCount = 6,

    /// <summary>자신을 제외한 인접 8칸의 카드 수.</summary>
    Adjacent8 = 7,

    /// <summary>그리드에 배치된 OFF 카드 수. 빈 슬롯은 제외.</summary>
    InactiveTotal = 8,
}

// =================================================================
// 방위 화살표 enum (4방위 + 동시 선택 + 결정 모드)
// =================================================================

/// <summary>
/// 카드의 방위 화살표. 4방위 기준이며 동시 보유 가능하므로 [Flags].
/// None 은 화살표 없음(무방향 카드). 비트값은 대각선 확장 여지를 두고 배치한다.
/// 확장 시 UpRight = 1 << 4 식으로 대각선 비트를 추가하면 된다.
/// </summary>
[Flags]
public enum ECardDirection
{
    None = 0,
    Up = 1 << 0,
    Down = 1 << 1,
    Left = 1 << 2,
    Right = 1 << 3,
    UpLeft = 1 << 4,
    UpRight = 1 << 5,
    DownLeft = 1 << 6,
    DownRight = 1 << 7,
    Special = 1 << 8,
    // 확장 예약: UpRight = 1 << 4, DownRight = 1 << 5, ... (대각선)
}

/// <summary>
/// 방위 화살표의 런타임 결정 방식.
/// SO 에 명시하여 카드 데이터만으로 동작이 예측되도록 한다 (Data-Driven).
/// </summary>
public enum EArrowMode
{
    /// <summary>확정: SO 에 지정된 방향을 그대로 사용 (랜덤 없음).</summary>
    Fixed = 0,

    /// <summary>일반 랜덤: 후보 방향 중 균등 확률로 선택.</summary>
    Random = 1,

    /// <summary>가중치 랜덤: 후보 방향별 가중치에 비례해 선택.</summary>
    Weighted = 2,
}

/// <summary>
/// 시작 덱 식별자. StartingDeckSO 에셋을 이 키로 선택해 전투 시작 덱을 구성한다.
/// InGameController 가 (enum → StartingDeckSO) 매핑 리스트를 Inspector 로 보유한다.
/// </summary>
public enum EStartingDeck
{
    /// <summary>미지정 (선택 안 됨 / 폴백).</summary>
    None = 0,

    /// <summary>모든 시작 덱에서 공통으로 획득 가능한 카드 풀.</summary>
    Common = 1,

    /// <summary>기본(노멀) 시작 덱.</summary>
    Normal = 3,

    /// <summary>[추정] 테스트용 기본 덱.</summary>
    Test = 99,
}

/// <summary>
/// 카드 발동 시 재생할 연출 종류. 투사체와 적중 이펙트를 조합한다.
/// 연출이 필요 없는 카드는 None.
/// </summary>
public enum EVfxType
{
    /// <summary>연출 없음.</summary>
    None = 0,

    /// <summary>투사체만 (카드 → 타겟으로 날아감).</summary>
    Projectile = 1,

    /// <summary>적중 이펙트만 (타겟 위치에 재생).</summary>
    Hit = 2,

    /// <summary>투사체 + 적중 이펙트 (날아가서 터짐).</summary>
    Both = 3,
}

/// <summary>
/// 카드 연출의 주 대상 방향. 효과 로직과 별개로 연출이 향할 곳을 데이터로 명시한다.
/// (공격형 → 적 / 버프·방어·회복형 → 자기 자신)
/// </summary>
public enum EVfxTarget
{
    /// <summary>적을 향함 (공격 연출).</summary>
    Enemy = 0,

    /// <summary>자기 자신(플레이어)을 향함 (버프·방어·회복 연출).</summary>
    Self = 1,
}

/// <summary>
/// 카드가 등장할 수 있는 보상 풀(용도) 비트마스크.
/// 한 카드가 여러 풀에 속할 수 있어 [Flags] 로 정의한다 (예: 상점 + 일반 동시).
/// 쿼리(CardQueryCriteria)에서 "이 풀에 속한 카드만" 필터링하는 키로 쓰인다.
/// </summary>
[Flags]
public enum ECardPool
{
    /// <summary>어느 풀에도 속하지 않음 (보상 후보 제외).</summary>
    None = 0,

    /// <summary>상점 판매 후보.</summary>
    Shop = 1 << 0,

    /// <summary>일반 전투 보상 후보.</summary>
    Normal = 1 << 1,

    /// <summary>보스 전투 보상 후보.</summary>
    Boss = 1 << 2,

    /// <summary>엘리트 전투 보상 후보.</summary>
    Elite = 1 << 3,

    // [확장 자리] 필요 시 아래처럼 추가 (기존 비트 유지):
    // FloorEarly = 1 << 4,
    // FloorMid   = 1 << 5,
    // Event      = 1 << 6,

    /// <summary>모든 풀 (편의용 — 디버그/전체 조회).</summary>
    All = Shop | Normal | Boss | Elite,
}
