﻿// =================================================================
// [스크립트 목적]  체인 전파(화살표 신호) 관련 enum 모음.
//                 기존 CardEnums.cs 를 건드리지 않고 분리 추가 (팀원 충돌 회피).
// [주요 타입]      - EChainPropagation : 방향 이웃 전파 시 '경로 차단' 규칙 타입
// [의존 관계]      - CardDataSO 가 카드별로 보유, ChainExecutor 가 전파 시 해석
// [설계 노트]      - 차단 규칙을 고정값이 아닌 카드 데이터(타입)로 두어 확장성 확보.
//                    카드마다 "관통형/차단형/빈칸막힘형" 을 SO 에서 선택 가능.
// =================================================================

/// <summary>
/// 방향 이웃으로 체인 신호가 뻗어 나갈 때, range 경로 위의 카드/빈칸을 어떻게 취급할지.
/// 카드 데이터(CardDataSO)에 두어 카드마다 독립적으로 설정한다 (Data-Driven).
/// range 가 1 이면 세 규칙의 결과가 동일하므로, range 가 2 이상일 때 의미가 갈린다.
/// </summary>
public enum EChainPropagation
{
    /// <summary>
    /// 관통: range 칸까지 빈칸·카드 구분 없이 진행하며 만나는 모든 카드를 전파 대상에 넣는다.
    /// (zip 구버전의 기본 동작. 장거리 다중 연결 콤보형 카드에 적합)
    /// </summary>
    Pierce = 0,

    /// <summary>
    /// 차단: 방향으로 진행하다 첫 번째 점유 카드를 만나면 그 카드까지만 전파하고 멈춘다.
    /// 빈칸은 통과한다. (배치 퍼즐성 — 중간 카드로 신호를 끊거나 징검다리로 잇는 전략)
    /// </summary>
    BlockOnFirstCard = 1,

    /// <summary>
    /// 빈칸 막힘: 인접 칸(거리 1)이 비어 있으면 그 방향 전파를 즉시 중단한다.
    /// 카드가 연속으로 붙어 있을 때만 신호가 흐른다 (밀집 배치 보상형).
    /// </summary>
    StopOnGap = 2,
}

/// <summary>
/// 카드의 체인 전파 패턴 타입.
/// 기본은 방향+사거리 기반 직선 전파(Line)이며, 특수 카드만 별도 패턴을 사용한다.
/// </summary>
public enum EChainPatternType
{
    /// <summary>기본 직선 전파.</summary>
    Line = 0,

    /// <summary>2칸 앞 충돌 지점과 그 좌우를 함께 토글.</summary>
    FrontCone2 = 1,

    /// <summary>화살표 방향의 인접 칸은 건너뛰고 정확히 2칸 앞 카드만 토글.</summary>
    ForwardSkip1 = 3,

    /// <summary>2칸 앞 지점을 중심으로 십자(상하좌우)를 토글.</summary>
    ImpactCrossForward2 = 4,

    /// <summary>
    /// 샷건(파편 화살): 1칸 앞 + 2칸 앞 + 2칸 앞의 진행방향 양옆 4칸을 토글.
    /// 우측 방향 예시: (1,0)(2,0)(2,1)(2,-1). 화살촉/부채꼴 형태.
    /// </summary>
    ShotgunForward2 = 5,
}

/// <summary>
/// 토템/오라형 효과가 조회할 카드 범위.
/// </summary>
public enum ECardAuraScope
{
    None = 0,
    Adjacent4 = 1,
    Adjacent8 = 2,
    Row = 3,
    Column = 4,
    Cross = 5,
    All = 6,
}
