// =================================================================
// [스크립트 목적]  리소스/Addressable 관련 enum 묶음
//                 (ResourceManager / AddressableMapBuilder / AddressableKeyTable)
// =================================================================

/// <summary>ResourceManager의 기본 로더 모드 선택</summary>
public enum EResourceMode
{
    /// <summary>Addressables 사용 (Production 권장)</summary>
    Addressable,

    /// <summary>Resources 폴더 사용 (PoC / 동기 로드 필요 시 / 작은 프로젝트)</summary>
    Resource
}

/// <summary>
/// Addressable 그룹 분류. 그룹명과 1:1 매칭되어 폴더 스캔 매핑에 사용.
/// [주의] Addressables 그룹 이름을 이 enum 이름과 정확히 일치시킬 것
/// (예: Addressables 그룹 "Prefab" ↔ EAddressableGroup.Prefab)
/// </summary>
public enum EAddressableGroup
{
    Default,
    Prefab,     // 풀링/일반 프리팹
    UI,         // UI 프리팹
    DebugUI,    // QA UI 프리팹
    Sound,      // 오디오 클립
    Data,       // ScriptableObject (.asset)
    Sprite,     // Sprite/Atlas, Sprite/Sprite
    Font,
}

/// <summary>SpriteAtlas 종류. ResourceManager의 아틀라스 키 매핑에 사용.</summary>
public enum EAtlasType
{
    CardIcon,
    Common,
}

/// <summary>에셋 종류. 프리로드 시 올바른 타입으로 로드하기 위한 분류</summary>
public enum EAssetKind
{
    Prefab = 0,
    Sprite,
    SpriteAtlas,
    JsonData,
    ScriptableObject,
    AudioClip,
    Csv,        // CSV 텍스트 데이터 (TextAsset)
}
