// =================================================================
// [스크립트 목적]  IInitializable 구현체 등록·정렬·일괄 초기화·역순 종료
// [주요 변수]      - _initializables : 등록된 매니저 리스트
//                  - _isInitializing : 초기화 진행 중 등록 차단 플래그
// [의존 관계]      - BootstrapInitializer가 호출
//                  - 매니저는 IInitializable (또는 ManagerBase<T>) 구현 필수
// [개선]           필수/선택 매니저 분기. 선택 매니저 실패는 경고 후 계속
// =================================================================
using System;
using System.Collections.Generic;
using System.Threading;
using Cysharp.Threading.Tasks;
using UnityEngine;

public static class ManagerRegistry
{
    private static readonly List<IInitializable> _initializables = new(32);
    private static bool _isInitializing;

    public static IReadOnlyList<IInitializable> Registered => _initializables;
    public static int Count => _initializables.Count;

    /// <summary>IInitializable 구현체 등록. 중복 / null / 초기화 진행 중 등록은 무시.</summary>
    public static void Register(IInitializable target)
    {
        if (target == null)
        {
            Debug.LogError("[ManagerRegistry] null 등록 시도");
            return;
        }

        if (_isInitializing)
        {
            Debug.LogError($"[ManagerRegistry] 초기화 진행 중 등록 시도: {target.GetType().Name}");
            return;
        }

        if (_initializables.Contains(target)) return;
        _initializables.Add(target);
    }

    /// <summary>
    /// GameObject 트리에서 IInitializable을 모두 찾아 자동 등록.
    /// 비활성 자식도 포함하여 검색.
    /// </summary>
    public static void RegisterFromHierarchy(GameObject root)
    {
        if (root == null)
        {
            Debug.LogError("[ManagerRegistry] RegisterFromHierarchy: root가 null");
            return;
        }

        var found = root.GetComponentsInChildren<IInitializable>(includeInactive: true);
        for (int i = 0; i < found.Length; i++)
            Register(found[i]);
    }

    /// <summary>
    /// 등록된 매니저를 InitOrder 오름차순으로 정렬 후 순차 InitializeAsync 호출.
    /// 필수 매니저(IsCritical=true) 실패 시 throw, 선택 매니저는 경고 후 계속.
    /// </summary>
    public static async UniTask InitializeAllAsync(CancellationToken token)
    {
        if (_isInitializing)
        {
            Debug.LogError("[ManagerRegistry] 이미 초기화 진행 중");
            return;
        }

        _isInitializing = true;

        try
        {
            _initializables.Sort(static (a, b) => a.InitOrder.CompareTo(b.InitOrder));

            for (int i = 0; i < _initializables.Count; i++)
            {
                token.ThrowIfCancellationRequested();

                var target = _initializables[i];
                if (target.IsInitialized) continue;

#if UNITY_EDITOR || DEVELOPMENT_BUILD
                var typeName = target.GetType().Name;
                var startTime = Time.realtimeSinceStartup;
                Debug.Log($"[ManagerRegistry] Init [{i + 1}/{_initializables.Count}] {typeName} (Order: {target.InitOrder})");
#endif

                try
                {
                    await target.InitializeAsync(token);
                }
                catch (OperationCanceledException) { throw; }
                catch (Exception e)
                {
                    if (target.IsCritical)
                    {
                        Debug.LogError($"[ManagerRegistry] [필수 매니저 실패] {target.GetType().Name}: {e.Message}");
                        throw; // BootstrapInitializer가 잡아서 OnInitializeFailed 발행
                    }

                    // 선택 매니저는 경고 후 계속 (게임은 진행)
                    Debug.LogWarning($"[ManagerRegistry] [선택 매니저 실패, 건너뜀] {target.GetType().Name}: {e.Message}");
                }

#if UNITY_EDITOR || DEVELOPMENT_BUILD
                var elapsed = (Time.realtimeSinceStartup - startTime) * 1000f;
                Debug.Log($"[ManagerRegistry] OK {typeName} ready ({elapsed:F1}ms)");
#endif
            }
        }
        finally
        {
            _isInitializing = false;
        }
    }

    /// <summary>등록된 매니저를 InitOrder 역순으로 종료. 게임 종료 시 호출.</summary>
    public static async UniTask ShutdownAllAsync()
    {
        for (int i = _initializables.Count - 1; i >= 0; i--)
        {
            if (_initializables[i] is IShutdownable shutdownable)
            {
                try
                {
                    await shutdownable.OnShutdownAsync();
                }
                catch (Exception e)
                {
                    Debug.LogError($"[ManagerRegistry] 종료 예외 {_initializables[i].GetType().Name}: {e.Message}");
                }
            }
        }
    }

    /// <summary>
    /// Domain Reload OFF 환경에서 정적 상태 초기화용.
    /// BootstrapInitializer가 자동 호출.
    /// </summary>
    public static void Reset()
    {
        _initializables.Clear();
        _isInitializing = false;
    }
}
