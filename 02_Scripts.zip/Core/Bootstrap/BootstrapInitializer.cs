﻿// =================================================================
// [스크립트 목적]  게임 시작 자동 진입점
//                 Resources/Bootstrap.prefab 로드 → 매니저 등록 → 일괄 초기화
// [주요 변수]      - _bootstrapInstance : Bootstrap 인스턴스 (DontDestroyOnLoad)
//                  - _readySource       : 준비 완료 대기용 (WaitForReadyAsync 지원)
//                  - _bootstrapCts      : 초기화 취소 토큰 소스
// [의존 관계]      - Resources/Bootstrap.prefab (사용자 생성 필수)
//                  - ManagerRegistry
// =================================================================
using System;
using System.Collections;
using System.Threading;
using Cysharp.Threading.Tasks;
using UnityEngine;

public static class BootstrapInitializer
{
    /// <summary>Resources 폴더 기준 Bootstrap Prefab 경로 (확장자 제외)</summary>
    private const string BOOTSTRAP_PREFAB_PATH = "Bootstrap";

    private static GameObject _bootstrapInstance;
    private static bool _isInitialized;
    private static bool _isInitializing;
    private static bool _isFailed;          // 초기화 실패/취소 여부 (코루틴 대기 무한 행 방지)
    private static UniTaskCompletionSource _readySource;
    private static CancellationTokenSource _bootstrapCts;

    public static bool IsInitialized => _isInitialized;
    public static bool IsInitializing => _isInitializing;
    public static GameObject BootstrapRoot => _bootstrapInstance;

    /// <summary>매니저 전체 초기화 완료 시 발행 (1회).</summary>
    public static event Action OnAllManagersReady;

    /// <summary>초기화 실패 시 발행. Exception 전달. 호출부에서 에러 화면 표시 등 처리.</summary>
    public static event Action<Exception> OnInitializeFailed;

    /// <summary>첫 씬 로드 전 자동 실행. 직접 호출하지 말 것.</summary>
    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
    private static void AutoInitialize()
    {
        // Domain Reload OFF 환경 대응
        ResetStaticState();

        InitializeInternalAsync().Forget();
    }

    private static async UniTaskVoid InitializeInternalAsync()
    {
        if (_isInitialized || _isInitializing) return;

        _isInitializing = true;
        _readySource = new UniTaskCompletionSource();
        _bootstrapCts = new CancellationTokenSource();

        try
        {
            // 1. Bootstrap Prefab 로드 (부트 시점에는 Resources 동기 로드가 가장 안전)
            var prefab = Resources.Load<GameObject>(BOOTSTRAP_PREFAB_PATH);
            if (prefab == null)
            {
                throw new InvalidOperationException(
                    $"[BootstrapInitializer] Resources/{BOOTSTRAP_PREFAB_PATH}.prefab 을 찾을 수 없습니다. " +
                    "프로젝트에 Bootstrap Prefab을 추가하세요.");
            }

            // 2. 인스턴스화 → 각 매니저 Awake에서 Singleton 자동 등록
            _bootstrapInstance = UnityEngine.Object.Instantiate(prefab);
            _bootstrapInstance.name = "[Bootstrap]";
            UnityEngine.Object.DontDestroyOnLoad(_bootstrapInstance);

            // 3. IInitializable 자동 수집·등록
            ManagerRegistry.RegisterFromHierarchy(_bootstrapInstance);

#if UNITY_EDITOR || DEVELOPMENT_BUILD
            Debug.Log($"[BootstrapInitializer] {ManagerRegistry.Count}개 매니저 등록. 초기화 시작.");
#endif

            // 4. 일괄 초기화
            await ManagerRegistry.InitializeAllAsync(_bootstrapCts.Token);

            _isInitialized = true;
            _isInitializing = false;

#if UNITY_EDITOR || DEVELOPMENT_BUILD
            Debug.Log("[BootstrapInitializer] 모든 매니저 초기화 완료.");
#endif

            _readySource.TrySetResult();
            OnAllManagersReady?.Invoke();
        }
        catch (OperationCanceledException)
        {
            _isInitializing = false;
            _isFailed = true;
            _readySource.TrySetCanceled();
            Debug.LogWarning("[BootstrapInitializer] 초기화 취소");
        }
        catch (Exception e)
        {
            _isInitializing = false;
            _isFailed = true;
            _readySource.TrySetException(e);
            Debug.LogError($"[BootstrapInitializer] 초기화 실패: {e}");
            OnInitializeFailed?.Invoke(e);
        }
    }

    /// <summary>
    /// 매니저 초기화 완료까지 대기. 이미 완료 시 즉시 반환.
    /// 첫 씬의 Start에서 매니저 사용 전 호출 권장.
    /// </summary>
    public static async UniTask WaitForReadyAsync(CancellationToken token = default)
    {
        if (_isInitialized) return;

        if (_readySource == null)
            await UniTask.WaitUntil(() => _readySource != null, cancellationToken: token);

        await _readySource.Task.AttachExternalCancellation(token);
    }

    /// <summary>Coroutine 환경용 대기. UniTask 미사용 코드 호환.
    /// 초기화 실패/취소 시에도 즉시 탈출(무한 대기 방지). 성공 여부는 IsInitialized로 확인.</summary>
    public static IEnumerator WaitForReadyCoroutine()
    {
        while (!_isInitialized && !_isFailed)
            yield return null;
    }

    /// <summary>매니저 역순 종료 보장. 저장 등 비동기 작업 완료 후 종료.</summary>
    public static async UniTask ShutdownAsync()
    {
        await ManagerRegistry.ShutdownAllAsync();
        Shutdown();
    }

    /// <summary>CTS만 정리. 동기 종료 (긴급 종료용).</summary>
    public static void Shutdown()
    {
        _bootstrapCts?.Cancel();
        _bootstrapCts?.Dispose();
        _bootstrapCts = null;
    }

    /// <summary>Domain Reload OFF 환경 대응. AutoInitialize 진입 시 정적 상태 초기화.</summary>
    private static void ResetStaticState()
    {
        _bootstrapInstance = null;
        _isInitialized = false;
        _isInitializing = false;
        _isFailed = false;
        _readySource = null;
        _bootstrapCts?.Dispose();
        _bootstrapCts = null;
        OnAllManagersReady = null;
        OnInitializeFailed = null;
        ManagerRegistry.Reset();
    }
}