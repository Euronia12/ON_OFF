﻿// =================================================================
// [스크립트 목적]  EntityManager 자동 등록/해제 컴포넌트 베이스 (CRTP 패턴)
//                 OnEnable에 등록 / OnDisable에 해제 / 이동 시 UpdatePosition
// [주요 변수]      - _teamId          : 팀 ID
//                  - _autoUpdatePos   : 매 프레임 위치 자동 갱신
//                  - _updateInterval  : 위치 갱신 인터벌 (0 = 매 프레임)
// [의존 관계]      - IRegisterableEntity, EntityManager
// [사용 가이드]    public class Enemy : RegisterableEntity<Enemy>
// =================================================================
using UnityEngine;

public abstract class RegisterableEntity<TSelf> : MonoBehaviour, IRegisterableEntity
    where TSelf : RegisterableEntity<TSelf>
{
    [Header("엔티티 등록 설정")]
    [Tooltip("팀/팩션 ID. 0=중립, 1=플레이어, 2~=적/동맹 (프로젝트 규약)")]
    [SerializeField] protected int _teamId = 0;

    [Tooltip("매 프레임 위치 자동 갱신. 정적 오브젝트는 false로 두면 GC·연산 절감")]
    [SerializeField] protected bool _autoUpdatePos = true;

    [Tooltip("위치 갱신 인터벌(초). 0=매 프레임, 0.1=10Hz 등.\n빠른 이동체는 0, 느린 NPC는 0.1~0.2 권장")]
    [Range(0f, 1f)]
    [SerializeField] protected float _updateInterval = 0f;

    private float _updateTimer;
    private bool _isRegistered;

    public Transform Transform => transform;
    public virtual int TeamId => _teamId;
    public virtual bool IsAlive => isActiveAndEnabled;

    protected virtual void OnEnable()
    {
        if (EntityManager.HasInstance && !_isRegistered)
        {
            EntityManager.Instance.Register((TSelf)this);
            _isRegistered = true;
        }
    }

    protected virtual void OnDisable()
    {
        if (EntityManager.HasInstance && _isRegistered)
        {
            EntityManager.Instance.Unregister((TSelf)this);
            _isRegistered = false;
        }
    }

    protected virtual void Update()
    {
        if (!_autoUpdatePos || !_isRegistered) return;

        // 종료·씬 전환 시 EntityManager가 먼저 파괴되고 이 Update가 한 번 더 돌 수 있음
        if (!EntityManager.HasInstance) return;

        if (_updateInterval <= 0f)
        {
            EntityManager.Instance.UpdatePosition((TSelf)this);
            return;
        }

        _updateTimer += Time.deltaTime;
        if (_updateTimer >= _updateInterval)
        {
            _updateTimer = 0f;
            EntityManager.Instance.UpdatePosition((TSelf)this);
        }
    }

    /// <summary>외부에서 팀 변경 시 호출 (포섭·세뇌 메카닉 등).</summary>
    public virtual void SetTeam(int teamId) => _teamId = teamId;

    /// <summary>수동 위치 갱신 (auto 끄고 이동 시점에만 호출하는 케이스).</summary>
    public void ForceUpdatePosition()
    {
        if (_isRegistered && EntityManager.HasInstance)
            EntityManager.Instance.UpdatePosition((TSelf)this);
    }
}