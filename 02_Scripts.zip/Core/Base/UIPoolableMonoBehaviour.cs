// =================================================================
// [스크립트 목적]  UI 풀링 객체 베이스. RectTransform 자동 리셋 + 트윈 정리
//                 (PoolableMonoBehaviour 상속 — PoolManager는 동일하게 처리)
// [주요 변수]      - _resetAnchoredPosition : 반환 시 anchoredPosition 0으로 리셋
//                  - _resetSizeDelta        : 반환 시 sizeDelta 원본으로 리셋
//                  - _resetLocalScale       : 트윈으로 0이 된 scale 복구
// [의존 관계]      - PoolableMonoBehaviour, DOTween
// [사용 가이드]    UI 풀링이 필요한 컴포넌트(UIDamageText·UIToast 등)는 이걸 상속
// =================================================================
using UnityEngine;

[RequireComponent(typeof(RectTransform))]
public abstract class UIPoolableMonoBehaviour : PoolableMonoBehaviour
{
    [Header("UI 풀 리셋 정책")]
    [Tooltip("Despawn 시 anchoredPosition을 (0,0)으로 리셋")]
    [SerializeField] private bool _resetAnchoredPosition = true;

    [Tooltip("Despawn 시 sizeDelta를 prefab 원본 값으로 리셋")]
    [SerializeField] private bool _resetSizeDelta = false;

    [Tooltip("Despawn 시 localScale을 (1,1,1)로 리셋 (트윈으로 0이 된 경우 대응)")]
    [SerializeField] private bool _resetLocalScale = true;

    [Tooltip("Despawn 시 localRotation을 identity로 리셋")]
    [SerializeField] private bool _resetLocalRotation = true;

    [Header("UI 풀 배치")]
    [Tooltip("parent를 명시하지 않고 Spawn할 때 배치될 UI 레이어")]
    [SerializeField] private EUILayer _targetLayer = EUILayer.Top;

    private RectTransform _rectTransform;
    private Vector2 _originalSizeDelta;
    private CanvasGroup _cachedCanvasGroup;

    public EUILayer TargetLayer => _targetLayer;

    protected RectTransform RectTransform => _rectTransform;
    protected CanvasGroup CanvasGroup => _cachedCanvasGroup;

    protected override void OnPoolCreate()
    {
        _rectTransform = GetComponent<RectTransform>();
        _originalSizeDelta = _rectTransform.sizeDelta;
        TryGetComponent(out _cachedCanvasGroup); // 없어도 OK
        base.OnPoolCreate();
    }

    public override void OnReturnToPool()
    {
        // RectTransform 리셋
        if (_rectTransform != null)
        {
            if (_resetAnchoredPosition) _rectTransform.anchoredPosition = Vector2.zero;
            if (_resetSizeDelta) _rectTransform.sizeDelta = _originalSizeDelta;
            if (_resetLocalScale) _rectTransform.localScale = Vector3.one;
            if (_resetLocalRotation) _rectTransform.localRotation = Quaternion.identity;
        }

        // CanvasGroup 리셋 (트윈으로 0이 된 alpha 복구)
        if (_cachedCanvasGroup != null)
        {
            _cachedCanvasGroup.alpha = 1f;
            _cachedCanvasGroup.interactable = true;
            _cachedCanvasGroup.blocksRaycasts = true;
        }

        // DOTween 잔여 트윈 정리 (UI 풀의 가장 흔한 함정)
        DG.Tweening.DOTween.Kill(transform);
        if (_cachedCanvasGroup != null)
            DG.Tweening.DOTween.Kill(_cachedCanvasGroup);

        base.OnReturnToPool();
    }
}
