// =================================================================
// [스크립트 목적]  로직 없는 풀 오브젝트(VFX/데코/사운드 등)용 기본 컴포넌트
//                 PoolableMonoBehaviour를 상속만 한 빈 클래스
//                 → 순수 GameObject도 이것만 붙이면 풀링 가능 (별도 클래스 작성 불필요)
// [사용 가이드]    Spawn 콜백이 필요 없는 단순 오브젝트 prefab에 부착
//                 커스텀 로직이 필요하면 PoolableMonoBehaviour를 직접 상속해 작성
// =================================================================
public sealed class SimplePoolable : PoolableMonoBehaviour { }
