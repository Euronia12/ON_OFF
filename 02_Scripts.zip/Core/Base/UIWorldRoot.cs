﻿// =================================================================
// [스크립트 목적]  World Space UI 컨테이너("도화지"). 하나의 World Canvas에
//                 여러 World UI(고정 표지·풀링 HP바 등)를 레이어별로 담는다.
// [주요 변수]      - _canvas       : World Space Canvas (이 오브젝트에 부착)
//                  - _layerRoots   : World 레이어별 부모 (WorldLayer_XXX)
//                  - _eventCamera  : Raycast·정렬용 카메라 (씬 카메라)
// [의존 관계]      - MonoBehaviour, UIManager(활성 root 등록), CameraManager(이벤트 카메라)
// [설계]           싱글톤 아님 — 분할화면 등 멀티 도화지 가능. 씬 컨트롤러가 생성·소유하고
//                 UIManager.SetActiveWorldRoot로 "현재 활성 도화지"를 지정.
//                 씬 종속(전환 시 씬과 함께 파괴). Canvas/GraphicRaycaster는 프리팹이 소유.
// [배치]           프리팹 루트에 Canvas(World Space) + 이 컴포넌트 부착,
//                 자식으로 WorldLayer_HUD / WorldLayer_Window ... 구성(없으면 코드 생성).
//                 클릭 상호작용이 필요하면 프리팹에 GraphicRaycaster를 직접 추가.
// =================================================================
using System;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(Canvas))]
public class UIWorldRoot : MonoBehaviour
{
    [Header("World UI 루트 설정")]
    [Tooltip("이 도화지를 생성 시 UIManager의 '활성 World 루트'로 자동 등록할지 여부.\n" +
             "단일 도화지면 켜두면 편함. 분할화면 등 멀티면 끄고 컨트롤러가 직접 지정")]
    [SerializeField] private bool _registerAsActiveOnEnable = true;

    // World 레이어별 부모 (WorldLayer_XXX). EUILayer 재사용
    private readonly Dictionary<EUILayer, Transform> _layerRoots = new(8);

    private Canvas _canvas;
    private bool _layersBuilt;

    /// <summary>이 도화지의 World Space Canvas.</summary>
    public Canvas Canvas => _canvas;

    private void Awake()
    {
        _canvas = GetComponent<Canvas>();

        // World Space 강제 (프리팹에서 잘못 설정돼 있어도 보정)
        if (_canvas.renderMode != RenderMode.WorldSpace)
            _canvas.renderMode = RenderMode.WorldSpace;

        BuildLayers();
    }

    private void OnEnable()
    {
        // 이벤트 카메라 연결 (Raycast·정렬용). 씬 카메라 사용
        ConnectEventCamera();

        if (_registerAsActiveOnEnable && UIManager.HasInstance)
            UIManager.Instance.SetActiveWorldRoot(this);
    }

    private void OnDisable()
    {
        // 자신이 활성 루트였다면 해제 (다른 루트로 오염 방지)
        if (UIManager.HasInstance)
            UIManager.Instance.ClearActiveWorldRoot(this);
    }

    // ─────────────────────────────────────────────
    // 레이어 구성
    // ─────────────────────────────────────────────

    /// <summary>
    /// WorldLayer_XXX 레이어 부모 구성.
    /// 프리팹에 이미 있으면 재사용(에디터 편집 존중), 없으면 코드 생성.
    /// </summary>
    private void BuildLayers()
    {
        if (_layersBuilt) return;

        foreach (EUILayer layer in Enum.GetValues(typeof(EUILayer)))
        {
            string layerName = $"{Constants.UI.WORLD_LAYER_PREFIX}{layer}";
            var existing = transform.Find(layerName);

            if (existing != null)
            {
                _layerRoots[layer] = existing;
                continue;
            }

            var go = new GameObject(layerName);
            var rt = go.AddComponent<RectTransform>();
            rt.SetParent(transform, worldPositionStays: false);
            rt.anchorMin = Vector2.zero;
            rt.anchorMax = Vector2.one;
            rt.offsetMin = Vector2.zero;
            rt.offsetMax = Vector2.zero;
            rt.localPosition = Vector3.zero;
            rt.localScale = Vector3.one;
            _layerRoots[layer] = rt;
        }

        // 렌더 순서: enum 순서대로 sibling 정렬
        int sibling = 0;
        foreach (EUILayer layer in Enum.GetValues(typeof(EUILayer)))
            _layerRoots[layer].SetSiblingIndex(sibling++);

        _layersBuilt = true;
    }

    // ─────────────────────────────────────────────
    // 공개 API
    // ─────────────────────────────────────────────

    /// <summary>
    /// 지정 레이어의 부모 Transform 반환.
    /// World UI(UIBase) 배치 또는 풀링 HP바 Spawn 시 parent로 사용.
    /// </summary>
    public Transform GetLayer(EUILayer layer)
        => _layerRoots.TryGetValue(layer, out var root) ? root : null;

    /// <summary>
    /// 월드 좌표 → 이 Canvas의 로컬(anchored) 좌표 변환.
    /// HP바를 월드 오브젝트 머리 위에 붙일 때 매 프레임 호출해 위치 갱신.
    /// 예) bar.anchoredPosition = worldRoot.WorldToCanvasPosition(enemy.position + offset);
    /// </summary>
    public Vector2 WorldToCanvasPosition(Vector3 worldPosition)
    {
        // World Space Canvas는 자기 평면 기준 로컬 좌표로 환산하면 됨
        return transform.InverseTransformPoint(worldPosition);
    }

    /// <summary>이벤트 카메라 수동 설정 (멀티 카메라 환경 등).</summary>
    public void SetEventCamera(Camera camera)
    {
        if (_canvas != null && camera != null)
            _canvas.worldCamera = camera;
    }

    // CameraManager 우선, 없으면 Camera.main
    private void ConnectEventCamera()
    {
        Camera cam = null;
        if (CameraManager.HasInstance)
            cam = CameraManager.Instance.MainCamera;
        if (cam == null)
            cam = Camera.main;

        if (cam != null && _canvas != null)
            _canvas.worldCamera = cam;
    }
}