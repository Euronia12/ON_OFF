// =================================================================
// [스크립트 목적]  풀링 컴포넌트 베이스. 최초 1회 Init + 매 Spawn Setup 명확히 분리
// [주요 변수]      - _category     : 풀 카테고리 (Inspector 노출, 부모 Transform 결정)
//                  - _prewarmCount : 풀 자동 프리웜 시 미리 만들 개수 (Inspector)
//                  - IsInPool      : 풀 대기 상태 (PoolManager 내부 관리)
// [의존 관계]      - PoolManager가 InvokePoolCreate / OnSpawnFromPool / OnReturnToPool 호출
// =================================================================
using UnityEngine;

public abstract class PoolableMonoBehaviour : MonoBehaviour, IPoolable
{
    [Header("풀링 설정")]
    [Tooltip("이 오브젝트의 풀 카테고리. World/UI/Effect/Audio 중 선택.\n카테고리에 따라 PoolManager가 부모 Transform을 자동 배정함.")]
    [SerializeField] private EPoolCategory _category = EPoolCategory.World;

    [Tooltip("자동 프리웜 시 풀에 미리 생성해 둘 개수.\n" +
             "PoolManager.PrewarmFromTableAsync가 이 값만큼 미리 생성함.\n" +
             "0이면 미리 생성 안 함(런타임에 필요 시 생성). 예: Bullet=20, Boss=1")]
    [Min(0)]
    [SerializeField] private int _prewarmCount = 0;

    public EPoolCategory Category => _category;

    /// <summary>자동 프리웜 시 미리 만들 개수. 프리팹 Inspector에서 지정.</summary>
    public int PrewarmCount => _prewarmCount;

    /// <summary>
    /// 현재 풀에 대기 중인지 여부. PoolManager 내부 관리용. 외부 read-only.
    /// </summary>
    public bool IsInPool { get; internal set; }

    /// <summary>
    /// 최초 풀 생성 시 1회만 호출.
    /// 무거운 초기화 (Component 캐싱, 자식 참조 수집 등) 여기서 처리.
    /// Awake 대용으로 사용 권장 (풀링 환경에서 Awake는 1회만 호출되므로 동일 효과).
    /// </summary>
    protected virtual void OnPoolCreate() { }

    /// <summary>Spawn 시 매번 호출. 위치/회전/상태 Setup 용도.</summary>
    public virtual void OnSpawnFromPool() { }

    /// <summary>Despawn 시 매번 호출. 상태 초기화, 코루틴 중단, 타이머 리셋 등.</summary>
    public virtual void OnReturnToPool() { }

    /// <summary>PoolManager 내부 호출용. 외부 직접 호출 금지.</summary>
    internal void InvokePoolCreate() => OnPoolCreate();
}
