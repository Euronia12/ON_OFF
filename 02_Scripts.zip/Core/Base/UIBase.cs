﻿// =================================================================
// [스크립트 목적]  모든 UI 화면의 베이스 (UIManager가 여는 화면용)
//                 풀링 없음 — 열 때 Instantiate, 닫을 때 Destroy (UI는 빈도 낮아 충분)
// [생명주기]       Init(최초1회) → Setup(열때마다) → OnOpen → ... → OnClose
//                  언어변경 시 OnLocalize 자동 호출 (ILocalizable 등록 기반)
// [주요 변수]      - _space : 이 UI가 그려질 공간 (Screen=화면고정 / World=3D공간)
//                  - _layer : 이 UI가 속할 레이어
// [의존 관계]      - MonoBehaviour, UIManager, LocalizationManager
// [참고]           데미지폰트·토스트 등 "풀링되는 UI"는 UIBase가 아니라
//                  UIPoolableMonoBehaviour를 직접 상속해 PoolManager로 사용
// [개선]           Screen/World 공간 구분 추가 — 프리팹에서 _space로 선언하면
//                  UIManager가 알맞은 루트(영속 Screen / 씬종속 World)에 자동 배치
// =================================================================
using UnityEngine;

public abstract class UIBase : MonoBehaviour, ILocalizable
{
    [Header("UI 설정")]
    [Tooltip("이 UI가 그려질 공간.\n" +
             "Screen : 화면 고정 UI (HUD·팝업 등). 영속 UIRoot에 배치\n" +
             "World  : 3D 공간 UI (머리 위 체력바 등). 씬 종속 WorldRoot에 배치")]
    [SerializeField] private EUISpace _space = EUISpace.Screen;

    [Tooltip("이 UI가 속할 레이어 (렌더 순서). Screen/World 각 공간 안에서의 순서")]
    [SerializeField] private EUILayer _layer = EUILayer.Window;

    public EUISpace Space => _space;

    /// <summary>렌더 순서 레이어. 코드 override 금지 — Inspector _layer 가 유일 권위다.</summary>
    public EUILayer Layer => _layer;

    /// <summary>
    /// ESC 를 이 UI 가 받는지(UIManager 팝업 스택 참여 여부).
    /// true  : ESC 로 닫히고 부모 UI 로 복귀 — 노드 UI 안에서 버튼으로 연 하위 UI.
    /// false : 스택에 안 들어가 ESC 가 EscMenu 로 위임된다 — 노드 UI 자체.
    /// 되돌리면 안 되는 상태는 true 로 두되 OnBackPressed() 로 닫기를 거부한다.
    /// </summary>
    public virtual bool CloseOnEscape => false;

    public bool IsOpen { get; private set; }

    private bool _initialized;

    // ─────────────────────────────────────────────
    // UIManager가 호출하는 진입점 (내부 흐름 제어)
    // ─────────────────────────────────────────────

    /// <summary>UIManager가 UI 표시 시 호출. Init(1회)→Setup→OnOpen→Localize 등록.</summary>
    public void HandleOpen()
    {
        if (!_initialized)
        {
            Init();
            _initialized = true;
        }

        Setup();
        IsOpen = true;
        OnOpen();
        UISelectableClickAudio.BindAll(transform);

        // 언어 변경 대응 등록 (등록 즉시 OnLocalize 1회 호출됨)
        if (LocalizationManager.HasInstance)
            LocalizationManager.Instance.Register(this);
    }

    /// <summary>
    /// UIManager가 UI 닫을 때 호출. Localize 해제 → OnClose → 자기 비활성화.
    /// SetActive(false)를 외부(UIManager)가 아닌 UIBase가 책임 →
    /// OnClose의 정리 작업과 비활성화 타이밍을 한 곳에서 보장.
    /// (World UI는 비활성 직후 UIManager가 파괴 — 이미 꺼진 오브젝트라 안전)
    /// </summary>
    public void HandleClose()
    {
        if (LocalizationManager.HasInstance)
            LocalizationManager.Instance.Unregister(this);

        IsOpen = false;
        OnClose();

        // 비활성화는 UIBase 자신이 수행 (외부가 직접 끄지 않음)
        gameObject.SetActive(false);
    }

    // ─────────────────────────────────────────────
    // 생명주기 훅 (자식 override)
    // ─────────────────────────────────────────────

    /// <summary>
    /// 최초 1회만 호출 (첫 표시 시).
    /// 무거운 초기화: 컴포넌트 참조 캐싱, 버튼 리스너 등록 등.
    /// </summary>
    protected virtual void Init() { }

    /// <summary>
    /// 열 때마다 호출 (OnOpen 직전). 매번 바뀌는 데이터 바인딩.
    /// </summary>
    protected virtual void Setup() { }

    /// <summary>UI 표시 시 호출. 애니메이션 시작 등.</summary>
    public virtual void OnOpen() { }

    /// <summary>UI 닫힘 시 호출. 상태 정리.</summary>
    public virtual void OnClose() { }

    /// <summary>다른 UI가 위에 열려 다시 포커스 얻을 때 호출.</summary>
    public virtual void OnFocus() { }

    /// <summary>위에 다른 UI가 열려 포커스 잃을 때 호출.</summary>
    public virtual void OnLostFocus() { }

    /// <summary>닫기 요청 (ESC/백버튼). false 반환 시 닫힘 차단.</summary>
    public virtual bool OnBackPressed() => true;

    /// <summary>
    /// 언어 변경 시 호출 (등록된 동안). 텍스트·이미지를 새 언어로 갱신.
    /// LocalizationManager.Get(key)로 번역 텍스트 조회해 적용.
    /// </summary>
    public virtual void OnLocalize()
    {
        LocalizedFontUtility.ApplyCurrentFont(this);
    }
}
