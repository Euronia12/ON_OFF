// =================================================================
// [스크립트 목적]  Singleton<T> + IInitializable + IShutdownable 통합 매니저 베이스
// [주요 변수]      - IsInitialized : 초기화 완료 플래그
//                  - IsShutdown    : 종료 완료 플래그
//                  - IsCritical    : 필수 매니저 여부 (override 가능)
// [의존 관계]      - Singleton<T>, IInitializable, IShutdownable
//                  - BootstrapInitializer가 InitializeAsync 호출
// [개선]           예외 안전 초기화·종료. 매니저 자체 예외가 다른 매니저 영향 차단
// =================================================================
using System;
using System.Threading;
using Cysharp.Threading.Tasks;

public abstract class ManagerBase<T> : Singleton<T>, IInitializable, IShutdownable
    where T : ManagerBase<T>
{
    public abstract int InitOrder { get; }
    public bool IsInitialized { get; private set; }
    public bool IsShutdown { get; private set; }

    /// <summary>기본 false(선택적). 핵심 매니저는 override해서 true 반환.</summary>
    public virtual bool IsCritical => false;

    /// <summary>
    /// 외부 호출용. 중복 초기화 자동 방지 + 예외 안전 처리.
    /// 자식은 OnInitializeAsync만 구현.
    /// </summary>
    public async UniTask InitializeAsync(CancellationToken token)
    {
        if (IsInitialized) return;

        try
        {
            await OnInitializeAsync(token);
            IsInitialized = true;
        }
        catch (OperationCanceledException)
        {
            throw;
        }
        catch (Exception e)
        {
            GameLogger.LogError(ELogCategory.System,
                $"{GetType().Name} 초기화 예외: {e.Message}");
            throw; // ManagerRegistry가 IsCritical 보고 처리
        }
    }

    /// <summary>외부 호출용. 종료 예외는 격리 (한 매니저 실패가 전체 종료 막지 않음).</summary>
    public async UniTask OnShutdownAsync()
    {
        if (IsShutdown || !IsInitialized) return;

        try
        {
            await OnShutdownInternalAsync();
        }
        catch (Exception e)
        {
            GameLogger.LogError(ELogCategory.System,
                $"{GetType().Name} 종료 예외: {e.Message}");
        }
        finally
        {
            IsShutdown = true;
        }
    }

    /// <summary>
    /// 매니저 고유 초기화 로직. 자식 클래스 구현.
    /// 동기 초기화일 경우 마지막에 return UniTask.CompletedTask;
    /// </summary>
    protected abstract UniTask OnInitializeAsync(CancellationToken token);

    /// <summary>종료 처리. 기본은 빈 구현. 저장·플러시 필요한 매니저만 override.</summary>
    protected virtual UniTask OnShutdownInternalAsync() => UniTask.CompletedTask;

    // ─────────────────────────────────────────────
    // 단독 사용 지원 (Bootstrap 없이 씬에 직접 배치)
    // ─────────────────────────────────────────────

    /// <summary>
    /// true면 Bootstrap이 깨우지 않아도 Start에서 스스로 초기화.
    /// Bootstrap 묶음으로 쓸 땐 false 유지(중복 초기화 방지).
    /// 단독 배치 매니저만 Inspector에서 켜거나 override.
    /// </summary>
    [UnityEngine.Tooltip("Bootstrap 없이 단독 배치할 때 켜기. Bootstrap에 넣었으면 끄기(중복 방지)")]
    [UnityEngine.SerializeField] private bool _selfInitializeIfStandalone = false;

    /// <summary>
    /// 단독 배치 시 자가 초기화. Bootstrap이 이미 초기화했으면(IsInitialized) 스킵.
    /// BootstrapInitializer는 Start보다 먼저(BeforeSceneLoad) 도므로 중복 안 됨.
    /// </summary>
    protected virtual async void Start()
    {
        if (!_selfInitializeIfStandalone) return;
        if (IsInitialized) return; // Bootstrap이 이미 초기화함

        try
        {
            await InitializeAsync(System.Threading.CancellationToken.None);
            GameLogger.Log(ELogCategory.System, $"{GetType().Name} 단독 자가 초기화 완료");
        }
        catch (Exception e)
        {
            GameLogger.LogError(ELogCategory.System,
                $"{GetType().Name} 단독 초기화 실패: {e.Message}");
        }
    }
}
