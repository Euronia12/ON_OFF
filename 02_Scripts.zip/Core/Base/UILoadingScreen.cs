// =================================================================
// [스크립트 목적]  로딩 화면 UI. 진행도 바 + 퍼센트 텍스트 + 랜덤 팁
// [주요 변수]      - _progressBar  : fillAmount 기반 진행도 이미지
//                  - _tips         : 랜덤 표시할 로딩 팁 목록
// [의존 관계]      - UIBase, SceneFlowManager(SetProgress 호출), DOTween
// [에디터 설정]    Layer를 Top으로 설정. _loadingScreenKey와 키 일치 필요
// =================================================================
using DG.Tweening;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class UILoadingScreen : UIBase
{
    [Header("로딩 화면 요소")]
    [Tooltip("진행도 바 (Image Type: Filled)")]
    [SerializeField] private Image _progressBar;

    [Tooltip("진행도 퍼센트 텍스트")]
    [SerializeField] private TextMeshProUGUI _progressText;

    [Tooltip("로딩 팁 텍스트")]
    [SerializeField] private TextMeshProUGUI _tipText;

    [Tooltip("진행도 바 트윈 시간 (초). 0이면 즉시")]
    [Range(0f, 0.5f)]
    [SerializeField] private float _barTweenDuration = 0.2f;

    [Header("로딩 팁")]
    [Tooltip("랜덤 표시할 팁 목록")]
    [TextArea]
    [SerializeField] private string[] _tips;

    private float _currentProgress;

    public override void OnOpen()
    {
        base.OnOpen();
        _currentProgress = 0f;

        if (_progressBar != null) _progressBar.fillAmount = 0f;
        if (_progressText != null) _progressText.text = "0%";

        ShowRandomTip();
    }

    public override void OnClose()
    {
        // 진행도 바 트윈 정리
        if (_progressBar != null) _progressBar.DOKill();
        base.OnClose();
    }

    /// <summary>진행도 갱신 (0~1). SceneFlowManager가 호출.</summary>
    public void SetProgress(float progress)
    {
        progress = Mathf.Clamp01(progress);
        _currentProgress = progress;

        if (_progressBar != null)
        {
            if (_barTweenDuration > 0f)
                _progressBar.FillTo(progress, _barTweenDuration);
            else
                _progressBar.fillAmount = progress;
        }

        if (_progressText != null)
            _progressText.text = $"{Mathf.RoundToInt(progress * 100f)}%";
    }

    private void ShowRandomTip()
    {
        if (_tipText == null || _tips == null || _tips.Length == 0) return;
        int idx = Random.Range(0, _tips.Length);
        _tipText.text = _tips[idx];
    }
}
