// =================================================================
// [스크립트 목적]  UIBase를 상속하지 않는 UI/오브젝트가 언어 변경 대응을 쉽게 하도록
//                 OnEnable/OnDisable에서 ILocalizable 자동 등록/해제 처리
// [사용]           월드공간 체력바, 디버그 UI, HUD 일부 등 UIManager를 안 거치는 UI
// [예시]           public class WorldNameTag : LocalizedBehaviour
//                  { protected override void Localize() { _text.text = ...; } }
// [대안]           이 베이스를 못 쓰는 경우(다른 클래스 상속 중)엔 ILocalizable을
//                  직접 구현하고 OnEnable/OnDisable에서 Register/Unregister 호출
// =================================================================
using UnityEngine;

public abstract class LocalizedBehaviour : MonoBehaviour, ILocalizable
{
    protected virtual void OnEnable()
    {
        if (LocalizationManager.HasInstance)
            LocalizationManager.Instance.Register(this); // 등록 즉시 1회 갱신
        else
            Localize(); // 매니저 없으면(테스트 등) 일단 1회 갱신
    }

    protected virtual void OnDisable()
    {
        if (LocalizationManager.HasInstance)
            LocalizationManager.Instance.Unregister(this);
    }

    // ILocalizable → 내부 Localize로 위임 (자식은 Localize만 구현)
    public void OnLocalize() => Localize();

    /// <summary>언어 변경 시 텍스트·이미지 갱신. 자식 구현.</summary>
    protected abstract void Localize();
}
