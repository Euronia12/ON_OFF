// =================================================================
// [스크립트 목적]  씬 한정 싱글턴 베이스 (인게임 컨트롤러·씬 전용 시스템용)
//                 영속 매니저(ManagerBase)와 달리 씬과 함께 생성·소멸됨
// [차이점]         - ManagerBase  : 영속(DontDestroyOnLoad), Bootstrap이 관리, InitOrder 보유
//                 - SceneSingleton: 씬 한정, 씬 끝나면 소멸, 인게임 진행 로직에 적합
// [사용 예시]      public class InGameController : SceneSingleton<InGameController>
// [주의]           씬에 1개만 존재 가정. 씬 전환 시 자동 소멸(영속 아님)
// =================================================================
using UnityEngine;

public abstract class SceneSingleton<T> : MonoBehaviour where T : SceneSingleton<T>
{
    private static T _instance;

    /// <summary>현재 씬의 인스턴스. 씬 전환 시 null이 됨.</summary>
    public static T Instance => _instance;
    public static bool HasInstance => _instance != null;

    protected virtual void Awake()
    {
        if (_instance != null && _instance != this)
        {
            GameLogger.LogWarning(ELogCategory.System,
                $"{typeof(T).Name} 중복 — 새 인스턴스 파괴");
            Destroy(gameObject);
            return;
        }

        _instance = (T)this;
        // DontDestroyOnLoad 호출 안 함 → 씬과 함께 소멸 (의도된 동작)

        OnAwakeInternal();
    }

    /// <summary>Awake 추가 초기화 훅.</summary>
    protected virtual void OnAwakeInternal() { }

    protected virtual void OnDestroy()
    {
        if (_instance == this)
            _instance = null;
    }
}
