﻿// =================================================================
// [스크립트 목적]  매니저 공통 Singleton 베이스. DontDestroyOnLoad 옵션 제어
// [주요 변수]      - Instance        : 정적 인스턴스
//                  - HasInstance     : null 체크 단축 프로퍼티
//                  - _dontDestroyOnLoad : 씬 전환 시 영속 여부 (Inspector)
//                  - _detachOnPersist : 영속화 시 부모에서 분리할지 (단독 사용 대비)
// [의존 관계]      - BootstrapInitializer가 매니저 GameObject 생성 후 Awake 보장
// [개선]           Domain Reload OFF 대응 ResetInstance + 영속 옵션 명시화
// =================================================================

using Sirenix.OdinInspector;
using UnityEngine;
public abstract class Singleton<T> : SerializedMonoBehaviour where T : Singleton<T>
{
    private static T _instance;

    public static T Instance => _instance;
    public static bool HasInstance => _instance != null;

    [Header("Singleton 설정")]
    [Tooltip("씬 전환 시에도 유지할지 여부.\n" +
             "true: 영속 (매니저·전역 시스템) / false: 씬 한정 (인게임 전용 컨트롤러)\n" +
             "Bootstrap 자식으로 둘 경우 false로 둬도 부모(Bootstrap) 따라 영속됨")]
    [SerializeField] private bool _dontDestroyOnLoad = true;

    [Tooltip("영속화 시 부모에서 분리(루트로 이동)할지.\n" +
             "단독 배치인데 어쩌다 자식으로 들어간 경우 켜면 안전하게 영속됨.\n" +
             "Bootstrap 묶음으로 쓸 땐 끄기(부모 따라가야 하므로)")]
    [SerializeField] private bool _detachOnPersist = false;

    public bool IsPersistent => _dontDestroyOnLoad;

    /// <summary>
    /// Domain Reload OFF 환경에서 정적 필드 수동 리셋용.
    /// BootstrapInitializer가 호출.
    /// </summary>
    public static void ResetInstance() => _instance = null;

    /// <summary>
    /// 중복 인스턴스 방지 + DontDestroyOnLoad 옵션 적용.
    /// 자식이 Awake를 override할 경우 반드시 base.Awake() 호출.
    /// 추가 초기화는 OnAwakeInternal 훅 사용 권장.
    /// </summary>
    protected virtual void Awake()
    {
        if (_instance != null && _instance != this)
        {
            Destroy(gameObject);
            return;
        }

        _instance = (T)this;

        ApplyPersistence();

        OnAwakeInternal();
    }

    private void ApplyPersistence()
    {
        if (!_dontDestroyOnLoad) return; // 씬 한정 → 영속 처리 안 함

        // 단독 배치인데 자식으로 들어간 경우 루트로 끌어올림 (DDOL은 루트만 가능)
        if (_detachOnPersist && transform.parent != null)
            transform.SetParent(null);

        // 루트일 때만 DontDestroyOnLoad (자식이면 부모를 따라가므로 호출 불필요)
        if (transform.parent == null)
            DontDestroyOnLoad(gameObject);
    }

    /// <summary>Awake override 없이 추가 초기화가 필요할 때 사용하는 훅.</summary>
    protected virtual void OnAwakeInternal() { }

    protected virtual void OnDestroy()
    {
        if (_instance == this)
            _instance = null;
    }
}
