﻿// =================================================================
// [스크립트 목적]  전투 연출의 월드 위치(투사체 목표점) 제공 인터페이스.
//                 로직 액터(POCO)와 분리된 비주얼 계층 인터페이스.
// [의존 관계]      - PlayerView / EnemyView 가 구현
//                  - BattleVfxPresenter 가 출발/도착 좌표 획득에 사용
// [설계 노트]      - ICombatActor(로직)에 Transform 을 넣지 않기 위한 분리.
//                    POCO 액터는 순수 유지, 위치는 씬 비주얼이 제공.
// =================================================================

using UnityEngine;

/// <summary>
/// 전투 연출이 향하거나 출발할 월드 위치를 제공한다.
/// 액터의 비주얼 표현체(PlayerView/EnemyView)가 구현하며, 투사체·이펙트가 이 위치를 참조한다.
/// </summary>
public interface ICombatTarget
{
    /// <summary>연출 기준 Transform (투사체 도착점·이펙트 재생 위치).</summary>
    Transform AnchorTransform { get; }
}