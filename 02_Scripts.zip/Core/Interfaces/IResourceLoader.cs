// =================================================================
// [스크립트 목적]  리소스 로더 추상화. Addressables/Resources 두 구현체 공통 계약
// [주요 멤버]      - SupportsSyncLoad   : 동기 로드 지원 여부 (Resources만 true)
//                  - LoadAsync          : UniTask 기반 비동기 로드
//                  - LoadCoroutine      : Coroutine 기반 비동기 로드
//                  - LoadSync           : 동기 로드 (Resources 한정)
//                  - Release / ReleaseAll : 개별 / 일괄 해제
// [의존 관계]      - ResourceManager가 두 구현체 보유 후 진입점 역할
// =================================================================
using System;
using System.Collections;
using System.Threading;
using Cysharp.Threading.Tasks;

public interface IResourceLoader
{
    /// <summary>동기 로드 지원 여부. Addressables는 false.</summary>
    bool SupportsSyncLoad { get; }

    /// <summary>UniTask 기반 비동기 로드.</summary>
    UniTask<T> LoadAsync<T>(string key, CancellationToken token = default) where T : UnityEngine.Object;

    /// <summary>Coroutine 기반 비동기 로드. UniTask 미사용 환경 호환.</summary>
    IEnumerator LoadCoroutine<T>(string key, Action<T> onComplete) where T : UnityEngine.Object;

    /// <summary>동기 로드. 미지원 구현체는 NotSupportedException 발생.</summary>
    T LoadSync<T>(string key) where T : UnityEngine.Object;

    /// <summary>개별 해제. RefCount 기반 구현체는 카운트 감소.</summary>
    void Release<T>(string key) where T : UnityEngine.Object;

    /// <summary>일괄 해제. 씬 전환 시 호출.</summary>
    void ReleaseAll();
}
