// =================================================================
// [스크립트 목적]  적 턴 행동 경계 인터페이스. BattleManager 와 적 AI(Intent) 분리
// [주요 메서드]    - ExecuteTurnAsync : 적의 한 턴 행동 수행 (공격·방어·버프 등)
// [의존 관계]      - BattleManager 가 EnemyResolve 페이즈에서 호출
//                  - 구현체(적 AI·Intent 큐)는 팀원 또는 다음 단계 작업
// [설계 노트]      - Intent 시스템(의도 표시·큐)은 게임 고유라 구현체에 위임
//                  - BattleManager 는 "적 턴을 수행하라"만 알고 내용은 모름
// =================================================================

using System.Threading;
using Cysharp.Threading.Tasks;

/// <summary>
/// 적의 턴 행동 계약.
/// BattleManager 는 EnemyResolve 페이즈에서 이 메서드만 호출하고,
/// 실제 의도(Intent) 결정·공격 패턴·연출은 구현체가 담당한다.
/// </summary>
public interface IEnemyTurnHandler
{
    /// <summary>
    /// 적의 한 턴 행동을 수행한다 (공격·방어·버프 등 + 연출 대기).
    /// 플레이어를 향한 피해는 target 으로 적용한다.
    /// </summary>
    /// <param name="target">행동 대상 (보통 플레이어).</param>
    /// <param name="token">취소 토큰 (전투 종료·씬 전환).</param>
    UniTask ExecuteTurnAsync(IBattleActor target, CancellationToken token);

    /// <summary>다음 턴 의도로 전진 (의도 큐 진행). 의도 시스템 없으면 무동작.</summary>
    void AdvanceIntent();

    /// <summary>적 생존 여부 (전투 종료 판정용).</summary>
    bool IsEnemyAlive { get; }

    /// <summary>현재 실행 예정인 의도 순번(1부터 시작). 알 수 없으면 0.</summary>
    int CurrentIntentOrder { get; }
}
