﻿// =================================================================
// [스크립트 목적]  체인 실행 중 연출 경계 인터페이스 (로직/비주얼 분리)
// [주요 메서드]    - PlayActivationFeedbackAsync : 카드 ON/OFF 피드백 연출 대기
//                  - ScheduleActivationVfx       : 카드 발동 VFX 예약 재생
//                  - OnCardToggled               : 카드 1장 상태 변화 훅
//                  - OnSignalPropagated          : 방향 신호가 한 칸 뻗을 때(방향선 연출 훅)
//                  - OnInfiniteLoopDetected      : 무한루프 감지 신호
// [의존 관계]      - ChainExecutor 가 이 인터페이스로만 연출 호출
//                  - 구현체(피드백·모션·DOTween·방향선)는 비주얼 팀원이 작성
// [설계 노트]      - 화살표 '신호 전달' 연출(방향선)을 로직과 분리하기 위해
//                    OnSignalPropagated 훅을 추가. ChainExecutor 는 "어느 칸으로
//                    신호가 갔는가" 좌표만 통지하고, 선/파티클 연출은 구현체가 담당.
// =================================================================

using System.Collections.Generic;
using System.Threading;
using Cysharp.Threading.Tasks;
using UnityEngine;

/// <summary>
/// 체인 실행의 연출 계약.
/// ChainExecutor 는 전파 로직(언제 무엇을 켜는가)만 책임지고,
/// 실제 피드백 애니메이션·모션·사운드·방향선은 이 구현체(비주얼 팀)가 담당한다.
/// 연출이 필요 없는 환경(테스트·서버 시뮬레이션)에서는 NullChainPresenter 를 주입한다.
/// </summary>
public interface IChainPresenter
{
    /// <summary>
    /// 한 웨이브의 카드들이 토글된 직후 호출. 피드백 연출이 끝날 때까지 대기.
    /// 연출이 없으면 즉시 완료 반환.
    /// </summary>
    UniTask PlayActivationFeedbackAsync(IReadOnlyList<Card> wave, CancellationToken token);

    /// <summary>
    /// 한 웨이브의 카드 발동 VFX를 예약 재생한다. 투사체 도착까지 기다리지 않는다.
    /// </summary>
    void ScheduleActivationVfx(IReadOnlyList<Card> wave, CancellationToken token);

    /// <summary>현재 체인에서 카드가 사용할 개별 연출 배속을 등록한다.</summary>
    void SetCardVisualSpeed(Card card, float visualSpeedMultiplier);

    /// <summary>체인 종료 후 등록된 카드별 연출 배속을 비운다.</summary>
    void ClearCardVisualSpeeds();

    /// <summary>카드 1장의 활성화 상태가 바뀔 때 호출 (개별 연출·사운드 훅).</summary>
    void OnCardToggled(Card card, bool activated);

    /// <summary>
    /// ON 된 카드가 방향으로 신호를 전파할 때, 발신 카드 → 도달 좌표(월드) 구간을 통지.
    /// 방향선·트레일·파티클 등 '신호가 흐르는' 연출 훅. 좌표 계산은 그리드가 제공한다.
    /// 빈칸으로 뻗는 경우도 호출될 수 있어(StopOnGap 판정 전), 구현체가 선만 그릴 수 있게 한다.
    /// </summary>
    /// <param name="emitter">신호를 보내는 ON 카드.</param>
    /// <param name="from">출발 월드 좌표 (발신 카드 위치).</param>
    /// <param name="to">도달 월드 좌표 (이번에 신호가 닿은 칸).</param>
    /// <param name="reachedCard">도달 칸의 카드. 빈칸이면 null.</param>
    void OnSignalPropagated(
        Card emitter,
        Vector3 from,
        Vector3 to,
        Card reachedCard,
        float visualSpeedMultiplier);

    /// <summary>
    /// 무한루프가 감지되어 체인이 중단될 때 호출.
    /// 실제 처리(페널티·고정 데미지·연출 등)는 구현체/상위 시스템이 결정한다.
    /// ChainExecutor 는 "감지됨" 신호만 전달하고 규칙을 강제하지 않는다.
    /// </summary>
    void OnInfiniteLoopDetected(Card rootCard);
}

/// <summary>
/// 연출 없는 기본 구현. 테스트·헤드리스 환경 또는 비주얼 미연결 시 사용.
/// 모든 연출을 즉시 통과시킨다 (대기 0).
/// </summary>
public sealed class NullChainPresenter : IChainPresenter
{
    public UniTask PlayActivationFeedbackAsync(IReadOnlyList<Card> wave, CancellationToken token)
        => UniTask.CompletedTask;

    public void ScheduleActivationVfx(IReadOnlyList<Card> wave, CancellationToken token) { }

    public void SetCardVisualSpeed(Card card, float visualSpeedMultiplier) { }

    public void ClearCardVisualSpeeds() { }

    public void OnCardToggled(Card card, bool activated) { }

    public void OnSignalPropagated(
        Card emitter,
        Vector3 from,
        Vector3 to,
        Card reachedCard,
        float visualSpeedMultiplier) { }

    public void OnInfiniteLoopDetected(Card rootCard) { }
}
