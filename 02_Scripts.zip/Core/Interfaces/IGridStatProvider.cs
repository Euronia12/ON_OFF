﻿// =================================================================
// [스크립트 목적]  그리드 집계값을 스탯 계산에 주입하는 인터페이스
// [주요 메서드]    - GetGridCount : (스탯 카드, 집계 범위) → 집계 수
// [의존 관계]      - GridManager 등 그리드 시스템이 구현
//                  - CardStatCalculator 가 이 인터페이스로만 그리드에 접근
// [설계 노트]      - 스탯 계층이 GridManager 에 직접 의존하지 않도록 분리 (A-4)
// =================================================================

/// <summary>
/// 그리드 집계값 제공자. 스탯 계산 계층은 GridManager 를 직접 알지 않고
/// 이 인터페이스로만 집계 수를 받아 결합을 끊는다.
/// 그리드 시스템(예: GridManager)이 구현하여 주입한다.
/// </summary>
public interface IGridStatProvider
{
    /// <summary>
    /// 지정 카드 기준, scope 범위의 집계 수를 반환한다.
    /// 예: Row → 같은 행 카드 수, GridTurnOnCount → 그리드 전체 이번 턴 ON 횟수.
    /// 스탯에 무관한 순수 카운트만 반환하며, 가중치(× value)는 호출 측이 곱한다.
    /// </summary>
    /// <param name="card">기준이 되는 런타임 카드 (위치/소유 정보 조회용).</param>
    /// <param name="scope">집계 범위.</param>
    /// <returns>집계된 개수. 해당 없음·범위 None 이면 0.</returns>
    int GetGridCount(Card card, EGridCountScope scope);
}