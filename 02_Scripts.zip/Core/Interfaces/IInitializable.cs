// =================================================================
// [스크립트 목적]  매니저 초기화 순서 보장 인터페이스
// [주요 멤버]      - InitOrder   : 낮을수록 먼저 초기화
//                  - IsCritical  : 필수 매니저 (실패 시 게임 진행 중단)
// =================================================================
using System.Threading;
using Cysharp.Threading.Tasks;

public interface IInitializable
{
    /// <summary>초기화 우선순위. 낮을수록 먼저 호출. 동값일 경우 등록 순서.</summary>
    int InitOrder { get; }

    /// <summary>초기화 완료 플래그. true 시 InitializeAsync 호출 무시.</summary>
    bool IsInitialized { get; }

    /// <summary>필수 매니저 여부. true는 초기화 실패 시 게임 진행 중단.</summary>
    bool IsCritical { get; }

    /// <summary>비동기 초기화 진입점. 동기 매니저는 UniTask.CompletedTask 반환.</summary>
    UniTask InitializeAsync(CancellationToken token);
}
