// =================================================================
// [스크립트 목적]  풀링 대상 통일 인터페이스
//                 직접 구현보다 PoolableMonoBehaviour 상속 권장
// [의존 관계]      - PoolManager가 Spawn/Despawn 시점에 호출
// =================================================================
public interface IPoolable
{
    /// <summary>풀에서 꺼내질 때마다 호출. Setup 용도</summary>
    void OnSpawnFromPool();

    /// <summary>풀로 반환될 때마다 호출. 상태 정리 용도</summary>
    void OnReturnToPool();
}
