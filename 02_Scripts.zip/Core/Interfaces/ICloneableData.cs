// =================================================================
// [스크립트 목적]  DataManager가 Base→Runtime 복제 시 사용하는 깊은 복사 계약
//                 ScriptableObject가 다른 SO 참조를 가질 때 직접 복사 책임을 강제
// [주의]           System.ICloneable 대신 제네릭 버전 사용 (boxing 회피)
// =================================================================
public interface ICloneableData<T>
{
    /// <summary>
    /// 자신의 깊은 복사본 반환.
    /// 참조 필드(다른 SO·List 등)는 구현자가 직접 복제할 책임.
    /// </summary>
    T Clone();
}
