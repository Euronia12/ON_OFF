// =================================================================
// [스크립트 목적]  자동 매핑이 어려운 SO가 직접 행을 파싱하도록 하는 폴백 인터페이스
//                 (자동 매핑으로 충분하면 구현 불필요)
// [사용 예시]      배열/중첩 구조/커스텀 변환이 필요한 SO에 구현
// =================================================================
using System.Collections.Generic;

public interface ISheetImportable
{
    /// <summary>
    /// 헤더-값 쌍(컬럼명 → 셀 문자열)을 받아 직접 필드 채움.
    /// 자동 매핑 대신 이 메서드가 호출됨.
    /// </summary>
    void ImportFromRow(IReadOnlyDictionary<string, string> row);
}
