// =================================================================
// [스크립트 목적]  씬 생명주기 훅. 씬 컨트롤러가 구현하면 SceneFlowManager가
//                 전환 시점에 자동 호출 (정리·로드·연출을 올바른 타이밍에 끼움)
// [호출 순서]      페이드아웃 → OnSceneExit → 씬로드 → OnSceneEnter → 페이드인 → OnSceneReady
// [사용 예시]      public class TitleController : MonoBehaviour, ISceneLifecycle { ... }
// [주의]           SceneFlowManager.RegisterLifecycle로 등록해야 호출됨
//                 (씬 컨트롤러가 Awake/Start에서 자기 자신 등록)
// =================================================================
using System.Threading;
using Cysharp.Threading.Tasks;

public interface ISceneLifecycle
{
    /// <summary>
    /// 현재 씬을 떠나기 직전 (페이드 아웃 후, 다음 씬 로드 전).
    /// 화면이 가려진 상태. UI 닫기·풀 정리·이벤트 해제 등 정리 작업.
    /// </summary>
    UniTask OnSceneExit(CancellationToken token);

    /// <summary>
    /// 새 씬 로드 직후 (페이드 뒤 = 화면 가려진 상태, 페이드 인 전).
    /// 무거운 준비 작업을 여기서. 에셋 로드·풀 프리웜·데이터 세팅.
    /// 이 작업이 끝나야 페이드 인이 시작됨 (로딩 중 화면 안 보이게).
    /// </summary>
    UniTask OnSceneEnter(CancellationToken token);

    /// <summary>
    /// 페이드 인 완료 후 (화면 완전히 보이는 상태).
    /// 인트로 연출·BGM 시작·게임플레이 개시 등.
    /// </summary>
    void OnSceneReady();
}
