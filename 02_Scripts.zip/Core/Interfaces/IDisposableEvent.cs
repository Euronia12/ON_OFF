// =================================================================
// [스크립트 목적]  EventManager 구독 자동 해제용 핸들
//                 사용 예시:
//                   private IDisposableEvent _sub;
//                   void OnEnable()  => _sub = EventManager.Instance.Subscribe<XEvent>(OnX);
//                   void OnDisable() => _sub?.Dispose();
// =================================================================
using System;

public interface IDisposableEvent : IDisposable { }
