// =================================================================
// [스크립트 목적]  매니저 종료 순서 보장. InitOrder 역순으로 호출됨
// [의존 관계]      - BootstrapInitializer가 Shutdown 시 일괄 호출
// =================================================================
using Cysharp.Threading.Tasks;

public interface IShutdownable
{
    /// <summary>
    /// 종료 처리. InitOrder 역순으로 호출 (먼저 켜진 게 나중에 꺼짐).
    /// 저장 등 비동기 작업 보장 필요 시 여기서 await.
    /// </summary>
    UniTask OnShutdownAsync();
}
