// =================================================================
// [스크립트 목적]  언어 변경 시 텍스트 갱신이 필요한 객체용 인터페이스
//                 상속 계층과 무관하게 적용 (UIBase든 일반 MonoBehaviour든)
// [사용]           LocalizationManager.Register/Unregister로 등록 → 언어 변경 시 OnLocalize 호출
// [예시]           public class WorldHpBar : MonoBehaviour, ILocalizable { ... }
// =================================================================
public interface ILocalizable
{
    /// <summary>언어가 변경되었을 때 호출. 텍스트·이미지 등을 새 언어로 갱신.</summary>
    void OnLocalize();
}
