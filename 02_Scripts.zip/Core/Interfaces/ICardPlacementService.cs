using Cysharp.Threading.Tasks;
using UnityEngine;

/// <summary>손패 카드 배치 입력이 사용하는 최소 실행 계약.</summary>
public interface ICardPlacementService
{
    int CurrentEnergy { get; }
    bool CanPlaceCard(Card card, Vector2Int position);
    UniTask<bool> PlaceCardAsync(Card card, Vector2Int position);
}
