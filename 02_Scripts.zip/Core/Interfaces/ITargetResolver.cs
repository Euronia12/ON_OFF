// =================================================================
// [스크립트 목적]  ETargetType → 실제 대상 액터 목록 해결 (효과와 타겟 분리)
// [주요 변수]      - 없음 (인터페이스 + 기본 헬퍼)
// [의존 관계]      - 전투 시스템(CombatManager 등)이 구현하여 디스패처에 주입
//                  - CardPhaseDispatcher 가 효과 실행 전 호출
// =================================================================

using System.Collections.Generic;

/// <summary>
/// 효과 대상 해결 인터페이스. 효과 모듈은 "무엇을 하는가"만 알고,
/// "누구에게"는 이 리졸버가 결정한다. 전투 시스템이 구체 구현을 제공.
/// </summary>
public interface ITargetResolver
{
    /// <summary>
    /// targetType 과 시전자·선택 대상을 바탕으로 최종 대상 목록을 result 에 채운다.
    /// 반환이 아닌 out 파라미터 채우기 — 호출부가 풀링 리스트 재사용 가능하도록.
    /// </summary>
    /// <param name="targetType">효과가 요구하는 대상 분류</param>
    /// <param name="caster">시전자</param>
    /// <param name="picked">플레이어가 직접 선택한 대상 (Single 계열에서 사용, 없으면 null)</param>
    /// <param name="result">결과를 채울 리스트 (호출 전 Clear 된 상태로 전달)</param>
    void Resolve(ETargetType targetType, ICombatActor caster, ICombatActor picked, List<ICombatActor> result);
}
