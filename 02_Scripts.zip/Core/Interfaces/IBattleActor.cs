// =================================================================
// [스크립트 목적]  전투 액터(플레이어/적) 경계 인터페이스. BattleManager 와 액터 구현 분리
// [주요 멤버]      - Hp/MaxHp     : 체력
//                  - IsAlive      : 생존 여부 (ICombatActor 상속)
//                  - OnDied       : 사망 이벤트
//                  - ResetBlock   : 턴 경계 방어 정리
// [의존 관계]      - ICombatActor 확장. Player/Enemy 구현 (팀원 또는 다음 단계)
//                  - BattleManager 가 이 인터페이스로만 액터 제어
// =================================================================

using System;

/// <summary>
/// 전투에 참여하는 액터의 계약 (플레이어/적 공통).
/// ICombatActor(피해/방어/회복)에 체력·생존·턴 정리를 더한다.
/// 구체 구현(MonoBehaviour, 모션, 비주얼)은 이 인터페이스 뒤에 둔다.
/// </summary>
public interface IBattleActor : ICombatActor
{
    /// <summary>현재 체력.</summary>
    int Hp { get; }

    /// <summary>최대 체력.</summary>
    int MaxHp { get; }

    /// <summary>현재 방어막(블록)량.</summary>
    int Block { get; }

    /// <summary>사망 시 발생. 전투 종료 판정에 사용.</summary>
    event Action OnDied;

    /// <summary>전투 시작 시 초기화 (체력 채우기 등).</summary>
    void Setup(int maxHp);

    /// <summary>
    /// 전투 시작 초기화 (현재 체력 지정). maxHp 로 최대치를, currentHp 로 시작 체력을 정한다.
    /// 런 HP 유지(전투 간 이어지는 체력)에 사용. currentHp 가 0 이하거나 maxHp 초과면 maxHp 로 클램프.
    /// 적처럼 항상 풀피인 액터는 currentHp 를 무시해도 된다.
    /// </summary>
    void Setup(int maxHp, int currentHp);

    /// <summary>턴 경계에서 방어막 정리 (소모형 블록).</summary>
    void ResetBlock();

    /// <summary>현재 방어막을 지정량만큼 소비(감소)한다. 피해 흡수와 무관하게 방어도를 직접 소모하는 효과용.</summary>
    void ConsumeBlock(int amount);
}