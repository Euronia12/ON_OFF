﻿// =================================================================
// [스크립트 목적]  유저 도메인 데이터 공통 계약. UserData가 보유하는 각 도메인 단위
// [주요 멤버]      - ResetToDefault()   : 신규 유저 기본값 초기화
//                  - BindDirtyNotifier(): 변경 시 호출할 더티 콜백 주입
//                  - MarkDirty()        : 도메인 내부에서 변경 발생 시 호출 (보호)
// [의존 관계]      - UserData가 구현 클래스들을 조합 보유, UserManager가 콜백 주입
// [설계]           프레임워크는 "도메인을 보유·저장·통지"하는 메커니즘만 제공.
//                  골드·장비 같은 구체 콘텐츠는 게임 측에서 이 인터페이스를 구현한다.
//                  도메인이 자기 데이터를 직접 수정하되, MarkDirty 콜백으로 매니저에
//                  자동 통지 → UserManager가 도메인 종류를 몰라도 더티 누락이 없다.
// =================================================================
using System;

/// <summary>
/// 유저 도메인 데이터의 공통 계약.
/// 각 도메인(재화·장비 등)은 UserDataBase를 상속해 구현하고 UserData가 조합한다.
/// </summary>
public interface IUserData
{
    /// <summary>신규 유저 생성 시 기본값 초기화.</summary>
    void ResetToDefault();

    /// <summary>
    /// 변경 발생 시 호출할 더티 콜백 주입. UserManager가 로드/생성 시 1회 연결한다.
    /// 도메인은 이 콜백을 보관했다가 자기 데이터가 바뀔 때 호출 → 자동 더티 마킹.
    /// </summary>
    void BindDirtyNotifier(Action onDirty);
}