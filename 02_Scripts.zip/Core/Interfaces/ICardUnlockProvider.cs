﻿// =================================================================
// [스크립트 목적]  카드 해방 상태 조회 인터페이스. 쿼리 시 잠긴 카드 필터링에 사용.
// [의존 관계]      - CardRewardService 가 주입받아 사용 / SaveData 연동 구현(추후)
// [설계 노트]      - 해방 로직을 인터페이스로 분리 → 지금은 항상-true 폴백,
//                    나중 SaveData 연동 구현으로 교체만 하면 됨 (의존 역전).
// =================================================================

/// <summary>
/// 카드 해방(잠금 해제) 상태 조회. CardRewardService 가 UnlockedOnly 필터에 사용.
/// 구현체는 세이브 데이터·진행도에 따라 해방 여부를 판정한다.
/// </summary>
public interface ICardUnlockProvider
{
    /// <summary>해당 카드가 현재 해방(획득 가능) 상태인지.</summary>
    bool IsUnlocked(string cardId);
}