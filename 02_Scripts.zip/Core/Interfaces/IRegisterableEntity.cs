// =================================================================
// [스크립트 목적]  EntityRegistry에 등록 가능한 엔티티 계약
// [주요 멤버]      - Transform : 위치 추적용
//                  - TeamId    : 팀/팩션 (0=중립). 적아 분류
//                  - IsAlive   : 죽은 엔티티 자동 제외
// [의존 관계]      - EntityManager가 쿼리 시 활용
// =================================================================
using UnityEngine;

public interface IRegisterableEntity
{
    Transform Transform { get; }

    /// <summary>팀/팩션 ID. 0=중립, 1=플레이어, 2~=적/동맹 등. 프로젝트별 규약</summary>
    int TeamId { get; }

    /// <summary>false면 쿼리에서 자동 제외 (사망/비활성)</summary>
    bool IsAlive { get; }
}
