﻿// =================================================================
// [스크립트 목적]  전투 흐름이 쓰는 카드 영역 이동 경계 (효과용 ICardGameService 와 분리)
// [주요 메서드]    - OnCardPlayedToField : 핸드 → 필드 (핸드에서 제거)
//                  - DiscardFromField    : 필드 → 묘지
//                  - DiscardHand         : 핸드 전체 → 묘지
//                  - AddCardToDrawPileAndShuffle : 드로우 더미에 카드 추가 후 섞기
// [의존 관계]      - BattleManager 가 의존. CardZoneController 가 구현
// [설계 노트]      - ICardGameService(효과 계약)와 역할 분리:
//                    효과는 드로우만, 전투 흐름은 영역 이동 제어 → 오용 차단 (ISP)
// =================================================================

/// <summary>
/// 전투 흐름(BattleManager)이 사용하는 카드 영역 이동 계약.
/// 카드 효과가 쓰는 ICardGameService 와 분리하여, 효과가 흐름 제어를 오용하지 못하게 한다.
/// CardZoneController 가 ICardGameService 와 함께 구현한다.
/// </summary>
public interface ICardZoneService
{
    /// <summary>현재 손패(읽기 전용). 턴 종료 손패 검사(저주 카드 피해 등)에 사용.</summary>
    System.Collections.Generic.IReadOnlyList<Card> Hand { get; }

    /// <summary>핸드 → 필드 배치 성공 시 호출. 핸드에서 카드를 제거한다.</summary>
    void OnCardPlayedToField(Card card);

    /// <summary>필드 → 묘지 (그리드 회수 카드를 묘지로).</summary>
    void DiscardFromField(Card card);

    /// <summary>필드 → 손패 (회수 스킬 등으로 손패에 되돌림).</summary>
    void ReturnFieldCardToHand(Card card);

    /// <summary>필드 카드를 이번 전투의 소멸 더미로 이동.</summary>
    void ExhaustFromField(Card card);

    /// <summary>핸드 전체 → 묘지 (턴 종료 손패 정리).</summary>
    void DiscardHand();

    /// <summary>드로우 더미에 카드 1장을 추가하고 섞는다.</summary>
    void AddCardToDrawPileAndShuffle(
        Card card,
        EBattleDeckOwner owner = EBattleDeckOwner.PlayerTemporary);
}
