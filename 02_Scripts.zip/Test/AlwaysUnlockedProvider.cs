﻿// =================================================================
// [스크립트 목적]  해방 조회 폴백 구현 — 모든 카드를 해방 상태로 간주.
// [의존 관계]      - ICardUnlockProvider 구현 / CardRewardService 기본 주입
// [설계 노트]      - 잠김/해방 구조만 우선 깔고, 실제 해방 판정은 추후 SaveData 구현으로 교체.
//                    그 전까지 이 폴백이 "전부 해방"으로 동작해 흐름을 막지 않는다.
//                  - 무상태 → 정적 싱글톤 인스턴스 공유 (할당 없음).
// =================================================================

/// <summary>
/// 모든 카드를 항상 해방으로 보는 폴백 ICardUnlockProvider.
/// 잠김/해방 기능의 실제 SaveData 연동 전까지 사용한다 (구조만 선반영).
/// </summary>
public sealed class AlwaysUnlockedProvider : ICardUnlockProvider
{
    /// <summary>공유 인스턴스 (무상태 → 재사용).</summary>
    public static readonly AlwaysUnlockedProvider Instance = new AlwaysUnlockedProvider();

    private AlwaysUnlockedProvider() { }

    /// <summary>항상 true (전부 해방).</summary>
    public bool IsUnlocked(string cardId) => true;
}