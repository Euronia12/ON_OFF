// =================================================================
// [스크립트 목적]  맵 생성 파라미터 ScriptableObject. 행 수/너비/분기확률 + 노드 타입 가중치.
// [주요 변수]      - _depth            : 맵 총 행 수
//                  - _widthMin/Max     : 행당 노드 개수 범위
//                  - _forkProbability  : 대각선(분기) 연결 확률
//                  - _nodeWeights      : depth 구간별 노드 타입 등장 가중치 (A안)
//                  - _fixedWidths      : 특정 depth 의 노드 개수 고정 (보스 행=1 등)
//                  - _fixedNodes       : 특정 (depth,index)의 노드 타입 고정 (보스 배치 등)
// [의존 관계]      - MapGenerator 가 이 데이터로 MapGraph 생성
//                  - ENodeType (MapEnums)
// [설계 노트]      - 에셋 MapData 이식. 제거한 멀티/메타 흔적:
//                    map_scene·battle_scene(씬 직접 지정) → 우리는 InGameController 흐름이 담당.
//                    map_tutorial(GameObject) → 튜토리얼 시스템 별도.
//                    EventData[] 다형성 → NodeTypeWeight[] (타입+가중치+depth구간)로 단순화.
//                  - 에셋의 EventData.depth_min/max + 랜덤 선택 방식을 그대로 계승하되,
//                    가중치(Weight)를 추가해 타입별 등장 빈도를 조절(A안).
//                  - 원본 불변 철학(EnemyDataSO 와 동일): SerializeField + 읽기전용 프로퍼티.
// =================================================================

using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Serialization;

/// <summary>
/// depth 구간별 특정 노드 타입의 등장 가중치. 에셋 EventData 의 depth_min/max 를 계승하고
/// Weight 를 더해 타입별 빈도를 조절한다. 생성 시 해당 depth 에서 유효한 항목들 중
/// 가중치에 비례해 노드 타입을 추첨한다.
/// </summary>
[Serializable]
public struct NodeTypeWeight
{
    [Tooltip("이 항목이 부여하는 노드 종류")]
    public ENodeType Type;

    [Tooltip("등장 가중치 (클수록 자주). 0 이하면 사실상 미등장")]
    [Min(0)]
    public int Weight;

    [Tooltip("이 타입이 등장 가능한 최소 depth (포함)")]
    [Min(1)]
    public int DepthMin;

    [Tooltip("이 타입이 등장 가능한 최대 depth (포함)")]
    [Min(1)]
    public int DepthMax;
}

/// <summary>Live 맵에서 특수 노드 타입별 전체 최소·최대 물리 노드 수.</summary>
[Serializable]
public struct SpecialNodeCountLimit
{
    [Tooltip("개수를 제한할 특수 노드 타입(Rest/Shop/Event/Elite)")]
    public ENodeType Type;

    [Tooltip("전체 맵에 배치할 최소 개수")]
    [Min(0)]
    public int Min;

    [Tooltip("전체 맵에 배치할 최대 개수. -1이면 상한 없음, 0이면 배치 금지")]
    [Min(-1)]
    public int Max;
}

/// <summary>특정 depth 의 노드 개수를 고정 (보스 행은 1개 등). 에셋 FixedWidthData 이식.</summary>
[Serializable]
public struct FixedWidth
{
    [Tooltip("대상 depth")]
    [Min(1)]
    public int Depth;

    [Tooltip("이 depth 의 고정 노드 개수")]
    [Min(1)]
    public int Width;
}

/// <summary>
/// 특정 (depth, index 범위)의 노드 타입을 고정 (보스·시작 노드 강제 배치 등).
/// 에셋 FixedLocationData 이식. 가중치 추첨보다 우선한다.
/// </summary>
[Serializable]
public struct FixedNode
{
    [Tooltip("대상 depth")]
    [Min(1)]
    public int Depth;

    [Tooltip("고정 적용 index 최소 (포함)")]
    [Min(0)]
    public int IndexMin;

    [Tooltip("고정 적용 index 최대 (포함)")]
    [Min(0)]
    public int IndexMax;

    [Tooltip("이 위치에 강제할 노드 종류")]
    public ENodeType Type;
}

/// <summary>
/// 스테이지 1개의 생성 파라미터. 노드맵 행 수·너비·분기 확률, 전투 그리드 크기,
/// 노드 타입 가중치 테이블을 보관한다.
/// </summary>
[CreateAssetMenu(fileName = "StageData", menuName = "Game/Stage Data", order = 0)]
public sealed class StageDataSO : ScriptableObject
{
    [Header("식별")]
    [Tooltip("스테이지 식별 ID (조회·로그용)")]
    [FormerlySerializedAs("_mapId")]
    [SerializeField] private string _stageId = "stage_default";

    [Header("플레이 모드")]
    [Tooltip("Live=상용(자동 특수 층·최소 상점 보정·방어코드 적용) / Test=오직 SO 고정+가중치만 적용")]
    [SerializeField] private EMapPlayMode _playMode = EMapPlayMode.Live;

    [Header("경로 생성")]
    [Tooltip("맵 총 행 수 (플레이어가 통과할 깊이). 마지막 행이 보통 보스")]
    [Min(1)]
    [SerializeField] private int _depth = 12;

    [Tooltip("행당 노드 개수 최소")]
    [Min(1)]
    [SerializeField] private int _widthMin = 4;

    [Tooltip("행당 노드 개수 최대")]
    [Min(1)]
    [SerializeField] private int _widthMax = 6;

    [Tooltip("대각선(분기) 연결이 생길 확률 (0~1). 클수록 경로가 복잡해짐")]
    [Range(0f, 1f)]
    [SerializeField] private float _forkProbability = 0.25f;

    [Header("특수 층 자동 배치 (코드 도출)")]
    [Tooltip("[사용 안 함] 예전 중간 보물 행 위치 비율. 현재 생성 로직에서는 참조하지 않으며, 데이터 호환을 위해 필드만 남겨둠")]
    [Range(0f, 1f)]
    [SerializeField] private float _treasureFloorRatio = 0.5f;

    [Tooltip("일반 행 타입 배정 시 인접 중복(연속 Rest/Shop) 회피 재추첨 최대 횟수")]
    [Range(0, 16)]
    [SerializeField] private int _typeRerollLimit = 6;

    [Tooltip("맵에 보장할 최소 상점 수. 자연 등장이 이보다 적으면 서로 다른 층에 분산 보충한다. 0이면 보장 없음(가중치대로만 등장)")]
    [Min(0)]
    [SerializeField] private int _minShopCount = 2;

    [Tooltip("맵에 보장할 최소 이벤트 수. 자연 등장이 이보다 적으면 전투 노드를 이벤트로 전환해 분산 보충한다. 0이면 보장 없음")]
    [Min(0)]
    [SerializeField] private int _minEventCount = 2;

    [Tooltip("맵에 허용할 최대 이벤트 수. 자연 등장이 이보다 많으면 고정 노드를 제외한 이벤트 노드를 전투 노드로 전환한다. 0이면 상한 없음")]
    [Min(0)]
    [SerializeField] private int _maxEventCount = 5;

    [Tooltip("Live 맵 특수 노드별 최소·최대 개수. Max=-1은 상한 없음, Max=0은 배치 금지")]
    [SerializeField] private SpecialNodeCountLimit[] _specialNodeCountLimits = new SpecialNodeCountLimit[]
    {
        new SpecialNodeCountLimit { Type = ENodeType.Rest,  Min = 0, Max = -1 },
        new SpecialNodeCountLimit { Type = ENodeType.Shop,  Min = 2, Max = -1 },
        new SpecialNodeCountLimit { Type = ENodeType.Event, Min = 2, Max = 5 },
        new SpecialNodeCountLimit { Type = ENodeType.Elite, Min = 0, Max = -1 },
    };

    [Header("스테이지 연출")]
    [Tooltip("이 스테이지의 맵 화면에서 재생할 BGM Addressable 키")]
    [SerializeField] private string _mapBgmKey;

    [Tooltip("이 스테이지의 일반 전투에서 재생할 BGM Addressable 키")]
    [SerializeField] private string _normalBattleBgmKey;

    [Tooltip("이 스테이지의 엘리트 전투에서 재생할 BGM Addressable 키")]
    [SerializeField] private string _eliteBattleBgmKey;

    [Tooltip("이 스테이지의 보스 1페이즈에서 재생할 BGM Addressable 키")]
    [SerializeField] private string _bossBattleBgmKey;

    [Tooltip("이 스테이지의 보스 2페이즈에서 재생할 BGM Addressable 키")]
    [SerializeField] private string _bossPhase2BgmKey;

    [Tooltip("이 스테이지 전투에서 사용할 배경 프리팹 Addressable 키")]
    [SerializeField] private string _battleBackgroundKey = "BattleBg";

    [Header("전투 그리드")]
    [Tooltip("이 스테이지 전투에서 사용할 그리드 행 수")]
    [Min(1)]
    [SerializeField] private int _battleGridRows = 5;

    [Tooltip("이 스테이지 전투에서 사용할 그리드 열 수")]
    [Min(1)]
    [SerializeField] private int _battleGridColumns = 5;

    [Header("적 난이도 풀 (easy/hard)")]
    [Tooltip("맵 앞쪽 이 비율까지는 Easy 적 풀에서, 이후는 Hard 풀에서 추첨 (0~1). 슬더스의 easy/hard 풀 근사")]
    [Range(0f, 1f)]
    [SerializeField] private float _earlyDepthRatio = 0.4f;

    [Header("적 풀")]
    [Tooltip("이 스테이지의 적 풀(EnemyPoolSO). 비우면 전역 풀로 폴백(경고 로그)")]
    [SerializeField] private EnemyPoolSO _enemyPool;

    [Header("노드 타입 가중치 (depth 구간별)")]
    [Tooltip("각 노드 타입의 등장 가중치와 가능 depth 구간. 생성 시 가중치 비례 추첨")]
    [SerializeField]
    private NodeTypeWeight[] _nodeWeights = new NodeTypeWeight[]
    {
        new NodeTypeWeight { Type = ENodeType.Battle,   Weight = 60, DepthMin = 1, DepthMax = 12 },
        new NodeTypeWeight { Type = ENodeType.Event,    Weight = 22, DepthMin = 2, DepthMax = 12 },
        new NodeTypeWeight { Type = ENodeType.Elite,    Weight = 16, DepthMin = 4, DepthMax = 12 },
        new NodeTypeWeight { Type = ENodeType.Shop,     Weight = 10, DepthMin = 3, DepthMax = 12 },
        new NodeTypeWeight { Type = ENodeType.Rest,     Weight = 12, DepthMin = 3, DepthMax = 12 },
        new NodeTypeWeight { Type = ENodeType.Treasure, Weight = 8,  DepthMin = 2, DepthMax = 12 },
    };

    [Header("고정 배치")]
    [Tooltip("특정 depth 의 노드 개수 고정 (예: 보스 행=1)")]
    [SerializeField] private FixedWidth[] _fixedWidths = new FixedWidth[0];

    [Tooltip("특정 위치의 노드 타입 고정 (예: 마지막 depth=Boss, 첫 depth=Battle). 가중치보다 우선")]
    [SerializeField] private FixedNode[] _fixedNodes = new FixedNode[0];

    public string StageId => _stageId;

    /// <summary>맵 생성 플레이 모드. Test 면 방어·자동 배치를 끄고 고정+가중치만 적용.</summary>
    public EMapPlayMode PlayMode => _playMode;

    public int Depth => _depth;
    public int WidthMin => _widthMin;
    public int WidthMax => _widthMax;
    public float ForkProbability => _forkProbability;
    public bool HasFixedNodes => _fixedNodes != null && _fixedNodes.Length > 0;

    /// <summary>중간 보물 행 위치 비율 (0~1). 0 이하면 보물 행 미배치.</summary>
    public float TreasureFloorRatio => _treasureFloorRatio;

    /// <summary>일반 행 타입 배정 시 인접 중복 회피 재추첨 최대 횟수.</summary>
    public int TypeRerollLimit => _typeRerollLimit;

    /// <summary>맵에 보장할 최소 상점 수. 0이면 보장 없음.</summary>
    public int MinShopCount => _minShopCount;

    /// <summary>맵에 보장할 최소 이벤트 수. 0이면 보장 없음.</summary>
    public int MinEventCount => _minEventCount;

    /// <summary>맵에 허용할 최대 이벤트 수. 0이면 상한 없음.</summary>
    public int MaxEventCount => _maxEventCount;

    /// <summary>
    /// Live 특수 노드 개수 범위를 반환한다. 신규 배열에 항목이 없으면 기존 Shop/Event 필드로
    /// 폴백해 아직 마이그레이션되지 않은 StageData 에셋도 같은 의미로 동작한다.
    /// </summary>
    public void GetSpecialNodeCountLimit(ENodeType type, out int min, out int max)
    {
        if (_specialNodeCountLimits != null)
        {
            for (int i = 0; i < _specialNodeCountLimits.Length; i++)
            {
                SpecialNodeCountLimit limit = _specialNodeCountLimits[i];
                if (limit.Type != type) continue;

                min = Mathf.Max(0, limit.Min);
                max = Mathf.Max(-1, limit.Max);
                if (max >= 0 && min > max) min = max;
                return;
            }
        }

        switch (type)
        {
            case ENodeType.Shop:
                min = Mathf.Max(0, _minShopCount);
                max = -1;
                return;
            case ENodeType.Event:
                min = Mathf.Max(0, _minEventCount);
                max = _maxEventCount > 0 ? _maxEventCount : -1;
                if (max >= 0 && min > max) min = max;
                return;
            default:
                min = 0;
                max = -1;
                return;
        }
    }

    /// <summary>특수 노드 범위 배열의 잘못된 타입·중복·범위를 명시적으로 보고한다.</summary>
    public void ValidateSpecialNodeCountLimits()
    {
        if (_specialNodeCountLimits == null) return;

        var seen = new HashSet<ENodeType>();
        for (int i = 0; i < _specialNodeCountLimits.Length; i++)
        {
            SpecialNodeCountLimit limit = _specialNodeCountLimits[i];
            bool supported = limit.Type == ENodeType.Rest || limit.Type == ENodeType.Shop ||
                             limit.Type == ENodeType.Event || limit.Type == ENodeType.Elite;
            if (!supported)
            {
                Debug.LogError($"[StageDataSO] 특수 노드 개수 설정에서 지원하지 않는 타입입니다. stage={_stageId}, type={limit.Type}");
                continue;
            }
            if (!seen.Add(limit.Type))
                Debug.LogError($"[StageDataSO] 특수 노드 개수 설정이 중복되었습니다. 첫 항목을 사용합니다. stage={_stageId}, type={limit.Type}");
            if (limit.Min < 0 || limit.Max < -1 || (limit.Max >= 0 && limit.Min > limit.Max))
                Debug.LogError($"[StageDataSO] 특수 노드 최소·최대 범위가 잘못되었습니다. stage={_stageId}, type={limit.Type}, min={limit.Min}, max={limit.Max}");
        }
    }

    public string MapBgmKey => _mapBgmKey;
    public string NormalBattleBgmKey => _normalBattleBgmKey;
    public string EliteBattleBgmKey => _eliteBattleBgmKey;
    public string BossBattleBgmKey => _bossBattleBgmKey;
    public string BossPhase2BgmKey => _bossPhase2BgmKey;
    public string BattleBackgroundKey => _battleBackgroundKey;

    /// <summary>적 등급에 맞는 현재 스테이지 전투 BGM 키를 반환한다. Test는 일반 전투곡을 사용한다.</summary>
    public string GetBattleBgmKey(EEnemyGrade grade)
    {
        return grade switch
        {
            EEnemyGrade.Elite => _eliteBattleBgmKey,
            EEnemyGrade.Boss => _bossBattleBgmKey,
            _ => _normalBattleBgmKey,
        };
    }

    public int BattleGridRows => _battleGridRows;
    public int BattleGridColumns => _battleGridColumns;

    /// <summary>Easy 적 풀로 추첨할 맵 앞쪽 비율 (0~1). 이 깊이 이하 전투는 Easy, 초과는 Hard.</summary>
    public float EarlyDepthRatio => _earlyDepthRatio;

    /// <summary>이 스테이지의 적 풀. 비어있으면 호출부가 전역 풀로 폴백한다.</summary>
    public EnemyPoolSO EnemyPool => _enemyPool;

    /// <summary>
    /// 지정 위치의 고정 노드 타입을 조회. 고정 항목이 있으면 그 타입, 없으면 None.
    /// (None 이면 호출부가 가중치 추첨으로 결정)
    /// </summary>
    public ENodeType GetFixedNodeType(int depth, int index)
    {
        if (_fixedNodes == null) return ENodeType.None;

        foreach (FixedNode fn in _fixedNodes)
        {
            if (fn.Depth == depth && index >= fn.IndexMin && index <= fn.IndexMax)
            {
                return fn.Type;
            }
        }
        return ENodeType.None;
    }

    /// <summary>지정 depth 의 고정 너비를 조회. 없으면 0 (호출부가 랜덤 너비 사용).</summary>
    public int GetFixedWidth(int depth)
    {
        if (_fixedWidths == null) return 0;

        foreach (FixedWidth fw in _fixedWidths)
        {
            if (fw.Depth == depth) return fw.Width;
        }
        return 0;
    }

    /// <summary>지정 depth 의 FixedNode index 범위가 실제 width 밖이면 오류 로그만 남긴다.</summary>
    public void LogInvalidFixedNodesForDepth(int depth, int width)
    {
        if (_fixedNodes == null) return;

        foreach (FixedNode fn in _fixedNodes)
        {
            if (fn.Depth != depth) continue;

            if (fn.IndexMin > fn.IndexMax)
            {
                Debug.LogError($"[StageDataSO] FixedNode index 범위가 잘못되었습니다. stage={_stageId}, depth={depth}, indexMin={fn.IndexMin}, indexMax={fn.IndexMax}");
            }

            if (fn.IndexMin >= width || fn.IndexMax >= width)
            {
                Debug.LogError($"[StageDataSO] FixedNode index가 depth width 밖입니다. stage={_stageId}, depth={depth}, width={width}, indexMin={fn.IndexMin}, indexMax={fn.IndexMax}");
            }
        }
    }

    /// <summary>
    /// 지정 depth 에서 등장 가능한 가중치 항목을 수집한다(depth 구간 필터).
    /// 호출부(MapGenerator)가 이 목록으로 가중치 비례 추첨을 수행한다.
    /// 결과가 비면 호출부가 Battle 로 폴백한다.
    /// </summary>
    /// <summary>
    /// 지정 타입이 등장 가능한 최소 depth 를 반환한다(_nodeWeights 의 DepthMin 최솟값).
    /// 해당 타입 항목이 없으면 -1. 최소 상점 보충 등 후처리에서 자연 등장 규칙을 따르는 데 사용.
    /// </summary>
    public int GetTypeMinDepth(ENodeType type)
    {
        int min = int.MaxValue;
        if (_nodeWeights != null)
        {
            foreach (NodeTypeWeight nw in _nodeWeights)
            {
                if (nw.Type == type && nw.DepthMin < min) min = nw.DepthMin;
            }
        }
        return min == int.MaxValue ? -1 : min;
    }

    public void CollectValidWeights(int depth, List<NodeTypeWeight> buffer)
    {
        buffer.Clear();
        if (_nodeWeights == null) return;

        foreach (NodeTypeWeight nw in _nodeWeights)
        {
            if (nw.Weight > 0 && depth >= nw.DepthMin && depth <= nw.DepthMax)
            {
                buffer.Add(nw);
            }
        }
    }
}
