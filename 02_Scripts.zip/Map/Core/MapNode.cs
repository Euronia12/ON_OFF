// =================================================================
// [스크립트 목적]  맵 노드 1칸 데이터 (POCO). 위치(depth/index) + 종류 + 인접성 보관.
// [주요 변수]      - Depth/Index : 맵 격자 좌표 (행/행 내 위치)
//                  - NodeType    : 이 노드의 종류 (ENodeType)
//                  - Seed        : 노드별 시드 (UI 위치 흔들기 등 절차 연출용)
//                  - Adjacency   : 다음 depth 의 도달 가능한 노드 ID 목록
//                  - Explored    : 방문 완료 여부 (이동 규칙·UI 표시용)
//                  - EnemyId     : 배정된 적 ID (전투류 노드만. EncounterAssigner 가 기록)
// [의존 관계]      - MapGraph(노드 보관)·MapGenerator(생성)·UIMap(렌더, 3단계)
// [설계 노트]      - 에셋 MapLocation 이식. 멀티 흔적 제거:
//                    map_id(여러 맵 동시 보유 전제) 삭제 — 싱글은 런당 맵 1개.
//                    EventData(다형성 SO) → ENodeType enum 으로 대체.
//                  - ID 스킴은 stageIndex*1,000,000 + depth*100 + index.
//                    스테이지가 바뀌어도 런 전체에서 노드 ID가 충돌하지 않는다.
//                  - 순수 데이터 — Unity 의존 없음(테스트 용이). 직렬화는 영속성 단계에서 고려.
// =================================================================

using System;
using System.Collections.Generic;

/// <summary>
/// 맵의 노드 1칸. 격자 좌표(depth/index), 종류(ENodeType), 다음 행으로의 인접성을 보관한다.
/// 에셋의 MapLocation 을 싱글 전용으로 이식 — 여러 맵 동시 보유 전제(map_id)와
/// EventData 다형성 트리를 제거하고 ENodeType 으로 노드 종류를 단순화했다.
/// </summary>
public sealed class MapNode
{
    public const int StageStride = 1_000_000;
    public const int DepthStride = 100;

    /// <summary>런 내 스테이지 인덱스 (0-based).</summary>
    public int StageIndex { get; }

    /// <summary>행 (1-based). RunContext.CurrentFloor 와 동일하게 움직인다.</summary>
    public int Depth { get; }

    /// <summary>행 내 위치 (0-based). 같은 depth 안에서의 선택지 인덱스.</summary>
    public int Index { get; }

    /// <summary>
    /// 노드 종류. 진입 시 동작 분기의 근거.
    /// 생성 시엔 미정(None)으로 두고 MapGenerator 의 타입 배정 패스에서 확정한다.
    /// set 은 생성 파이프라인(MapGenerator) 전용 — 그 외에서는 변경하지 말 것.
    /// </summary>
    public ENodeType NodeType { get; set; }

    /// <summary>노드별 시드. UI 위치 흔들기 등 노드 단위 절차 연출에 사용(에셋 동일).</summary>
    public int Seed { get; }

    /// <summary>방문 완료 여부. 이동 규칙·UI 알파 표시에 사용.</summary>
    public bool Explored { get; set; }

    /// <summary>배정된 적 ID (EnemyDataSO.EnemyId). 전투류 노드만 채워지며 비전투는 null.</summary>
    public string EnemyId { get; set; }

    // 다음 depth 의 도달 가능 노드 ID 목록 (단방향: 항상 전진).
    private readonly List<int> _adjacency = new List<int>(4);

    /// <summary>이 노드에서 갈 수 있는 다음 노드 ID 목록 (읽기 전용).</summary>
    public IReadOnlyList<int> Adjacency => _adjacency;

    /// <summary>스테이지와 격자 좌표로부터 계산되는 런 전체 고유 ID.</summary>
    public int Id => GetId(StageIndex, Depth, Index);

    public MapNode(int seed, int stageIndex, int depth, int index, ENodeType nodeType)
    {
        Seed = seed;
        StageIndex = stageIndex;
        Depth = depth;
        Index = index;
        NodeType = nodeType;
    }

    /// <summary>인접 노드 추가 (중복 무시). null 이면 무시.</summary>
    public void AddAdjacent(MapNode node)
    {
        if (node != null && !_adjacency.Contains(node.Id))
        {
            _adjacency.Add(node.Id);
        }
    }

    /// <summary>지정 노드가 이 노드의 인접(도달 가능)인지 여부.</summary>
    public bool IsAdjacent(MapNode node)
    {
        return node != null && _adjacency.Contains(node.Id);
    }

    /// <summary>
    /// 스테이지·격자 좌표 → 런 전체 고유 노드 ID 변환.
    /// 스테이지당 local ID가 StageStride 미만이고 행당 노드가 100개 미만이어야 한다.
    /// </summary>
    public static int GetId(int stageIndex, int depth, int index)
    {
        if (stageIndex < 0) throw new ArgumentOutOfRangeException(nameof(stageIndex));
        if (depth < 1) throw new ArgumentOutOfRangeException(nameof(depth));
        if (index < 0 || index >= DepthStride) throw new ArgumentOutOfRangeException(nameof(index));

        int localId = checked(depth * DepthStride + index);
        if (localId >= StageStride)
            throw new ArgumentOutOfRangeException(nameof(depth), "스테이지 로컬 노드 ID 범위를 초과했습니다.");

        return checked(stageIndex * StageStride + localId);
    }
}
