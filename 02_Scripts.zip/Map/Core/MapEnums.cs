// =================================================================
// [스크립트 목적]  노드맵 시스템 전역 enum 정의 (노드 타입)
// [주요 변수]      - ENodeType : 맵 노드 1칸의 종류 (전투/엘리트/이벤트/상점/휴식/보물/보스/테스트)
// [의존 관계]      - MapNode(노드 데이터)·StageDataSO(가중치 테이블)·InGameController(타입 분기)
//                  - UIMap(아이콘 매핑, 3단계)
// [설계 노트]      - 에셋의 EventData 다형성 SO 트리를 enum 으로 단순화.
//                    노드 종류가 슬더스로 고정(확장 거의 없음) + 각 타입 동작을
//                    다른 시스템이 구독 처리하므로, 무거운 다형성 대신 enum 경계가 적합.
//                  - 전투 계열(Battle/Elite/Boss)만 InGameController 가 직접 전투 진입,
//                    나머지(Event/Shop/Rest/Treasure)는 이벤트 발행 → 외부 구독(타 담당자).
//                  - 직렬화 호환을 위해 명시적 정수값 유지 (CardEnums 컨벤션과 정렬).
// =================================================================

/// <summary>
/// 맵 노드 1칸의 종류. 슬더스 표준 노드 구성에 테스트 전용 노드를 더한다.
/// 전투 계열(Battle/Elite/Boss/Test)은 런 컨트롤러가 직접 전투로 진입시키고,
/// 그 외(Event/Shop/Rest/Treasure)는 노드 선택 이벤트로 외부 시스템에 위임한다.
/// </summary>
public enum ENodeType
{
    /// <summary>미지정 (폴백 / 생성 실패). 정상 맵에는 등장하지 않아야 한다.</summary>
    None = 0,

    /// <summary>일반 전투. 가장 흔한 노드.</summary>
    Battle = 1,

    /// <summary>엘리트 전투. 강한 적 + 더 좋은 보상.</summary>
    Elite = 2,

    /// <summary>이벤트(미지의 사건). 외부 이벤트 시스템이 처리.</summary>
    Event = 3,

    /// <summary>상점. 외부 상점 시스템이 처리.</summary>
    Shop = 4,

    /// <summary>휴식(모닥불). 외부 휴식 시스템이 처리.</summary>
    Rest = 5,

    /// <summary>보물. 외부 보물 시스템이 처리.</summary>
    Treasure = 6,

    /// <summary>보스 전투. 보통 맵 마지막 depth 고정.</summary>
    Boss = 7,

    /// <summary>테스트 전투. Test 등급 적만 배정된다.</summary>
    Test = 8,
}

/// <summary>
/// 맵 생성 플레이 모드. StageDataSO 에서 스테이지별로 지정한다.
/// Live 는 상용 안전 규칙(자동 특수 층·최소 상점 보정·고정 노드 하드가드)을 모두 적용하고,
/// Test 는 그 방어·자동 배치를 전부 끄고 오직 SO 의 고정 타입 + 가중치만으로 생성한다.
/// </summary>
public enum EMapPlayMode
{
    /// <summary>상용: 자동 특수 층·방어코드·최소 상점 보정 전부 적용.</summary>
    Live = 0,

    /// <summary>테스트: 오직 SO 고정 타입 + 가중치만 적용 (방어코드 미실행).</summary>
    Test = 1,
}
