// =================================================================
// [스크립트 목적]  맵 생성기 (순수 로직). StageDataSO + 시드 → MapGraph 절차 생성.
// [주요 변수]      - (메서드 지역) seedRand : 노드별 시드 발급용 (생성 로직과 분리)
//                  - (메서드 지역) genRand  : 너비/타입/분기 결정용
// [의존 관계]      - StageDataSO(파라미터)·MapGraph/MapNode(결과)·ENodeType
//                  - RunContext(호출: 자신의 Seed 를 넘겨 맵 생성)
// [설계 노트]      - 슬더스 정통 방식으로 전환: "위상(경로) 생성 → 규칙 기반 타입 배정 →
//                    경로 커버리지 보정" 3단계. 각 노드 독립 추첨에서 벗어나 경로 보장을 얻는다.
//                    1) 시드 2개 분리(seedRand/genRand) — 노드 시드와 생성 난수를 분리.
//                    2) 행별 노드 생성(타입 미정 None) + 인접성 연결(기존 로직 유지).
//                    3) 타입 배정 패스:
//                       3-a 특수 층 자동 배치(코드 depth 도출): 첫 행 전투 /
//                           보스 전 행 휴식(모든 경로 휴식 보장) / 보스 행.
//                       3-b 일반 행 가중치 추첨 + 인접 중복(Rest/Shop) 회피.
//                       3-c 이벤트 최대 수 제한 후 상점·이벤트 최소 수 보충.
//                  - static 순수 함수 — Unity 의존 없음(테스트 용이). 고정 xorshift32 난수 사용.
// =================================================================

using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// StageDataSO 와 시드로부터 MapGraph 를 절차 생성하는 순수 로직.
/// 위상(노드+간선)을 먼저 만들고 타입은 이후 패스에서 배정해, 경로 단위 규칙
/// (보스 전 휴식·상점 경로 보장·인접 중복 회피)을 슬더스식으로 적용한다.
/// </summary>
public static class MapGenerator
{
    /// <summary>
    /// 맵 생성 알고리즘 버전. 노드 배치·너비·타입 배정 등 생성 로직이 바뀌어
    /// 같은 시드라도 결과가 달라질 수 있는 변경을 하면 이 값을 반드시 증가시킨다.
    /// 저장 시 RunSaveData.mapVersion 에 기록되며, 로드 시 값이 다르면 저장 위치가
    /// 어긋날 수 있어 이어하기를 무효화하고 신규 런을 안내한다(InGameController).
    /// </summary>
    public const int AlgorithmVersion = 5;

    private static readonly ENodeType[] LiveSpecialPlacementPriority =
    {
        ENodeType.Rest,
        ENodeType.Shop,
        ENodeType.Event,
        ENodeType.Elite,
    };

    /// <summary>
    /// System.Random의 런타임별 구현 변경에 영향을 받지 않는 맵 생성 전용 xorshift32 PRNG.
    /// AlgorithmVersion이 같으면 플랫폼과 실행 순서에 무관하게 동일 수열을 낸다.
    /// </summary>
    private sealed class DeterministicRandom
    {
        private uint _state;

        public DeterministicRandom(int seed)
        {
            _state = unchecked((uint)seed) ^ 0x9E3779B9u;
            if (_state == 0u) _state = 0x6D2B79F5u;
        }

        private uint NextUInt()
        {
            uint value = _state;
            value ^= value << 13;
            value ^= value >> 17;
            value ^= value << 5;
            _state = value;
            return value;
        }

        public int Next()
        {
            return (int)(NextUInt() & 0x7fffffffu);
        }

        public int Next(int maxExclusive)
        {
            if (maxExclusive <= 0) return 0;
            return (int)(NextUInt() % (uint)maxExclusive);
        }

        public int Next(int minInclusive, int maxExclusive)
        {
            if (maxExclusive <= minInclusive) return minInclusive;
            return minInclusive + Next(maxExclusive - minInclusive);
        }

        public double NextDouble()
        {
            return NextUInt() / 4294967296.0;
        }
    }

    /// <summary>
    /// 맵 생성. 동일 (data, seed) 는 항상 동일 맵을 만든다(재현 가능).
    /// </summary>
    /// <param name="data">생성 파라미터 SO.</param>
    /// <param name="seed">런 시드 (RunContext.Seed).</param>
    /// <returns>생성된 맵 그래프. data 가 null 이면 null.</returns>
    public static MapGraph Generate(StageDataSO data, int seed, int stageIndex = 0)
    {
        if (data == null)
        {
            Debug.LogError("[MapGenerator] StageDataSO 가 null 입니다. 맵 생성 불가.");
            return null;
        }

        // 시드 2개 분리(에셋 의도 유지):
        //  - seedRand: 노드별 시드 발급. 생성 로직이 바뀌어도 이 흐름은 유지되도록 분리.
        //  - genRand : 너비/타입/분기 결정. StageId 안정 해시를 더해 두 난수가 같은 수열이 되지 않게.
        //    string.GetHashCode()는 런타임/플랫폼/버전마다 값이 달라 저장·리플레이 기준으로 부적합하므로
        //    직접 구현한 FNV-1a 안정 해시를 쓴다(같은 seed·StageId → 언제나 같은 맵).
        DeterministicRandom seedRand = new DeterministicRandom(unchecked(seed ^ 0x13579BDF));
        DeterministicRandom genRand = new DeterministicRandom(unchecked(seed + StableHash(data.StageId)));

        int widthMin = data.WidthMin;
        int widthMax = data.WidthMax;
        if (widthMin > widthMax)
        {
            Debug.LogError($"[MapGenerator] WidthMin({widthMin}) 이 WidthMax({widthMax}) 보다 큽니다. 값을 교환해 맵 생성을 계속합니다. stage={data.StageId}");
            int temp = widthMin;
            widthMin = widthMax;
            widthMax = temp;
        }

        // Test 모드: 방어·자동 배치를 전부 끄고 오직 SO 고정 타입 + 가중치만 적용(완전 raw).
        bool isTest = data.PlayMode == EMapPlayMode.Test;
        if (!isTest) data.ValidateSpecialNodeCountLimits();

        MapGraph graph = new MapGraph(seed, data.Depth, stageIndex);

        // ── 1) 행별 노드 생성 (타입 미정 None — 배정은 3단계에서) ──────────
        for (int d = 1; d <= data.Depth; d++)
        {
            int width = genRand.Next(widthMin, widthMax + 1);
            int fixedWidth = data.GetFixedWidth(d);
            if (fixedWidth > 0) width = fixedWidth;
            else if (!isTest && d == data.Depth) width = 1; // (Live) 보스 행은 기본 1개

            data.LogInvalidFixedNodesForDepth(d, width);
            graph.SetDepthWidth(d, width);

            for (int i = 0; i < width; i++)
            {
                var node = new MapNode(seedRand.Next(), stageIndex, d, i, ENodeType.None);
                graph.AddNode(node);
            }
        }

        // ── 2) 인접성 연결 (검증된 로직 그대로) ────────────
        ConnectAdjacency(data, graph, genRand);

        // ── 3) 타입 배정 패스 ────────────
        //  Live: 자동 특수 층 → 고정(가드) → 가중치 → 최대 이벤트 보정 → 최소 상점·이벤트 보정 → 검증
        //  Test: 고정(가드 없음) → 가중치  (그 외 방어·자동 배치 전부 생략)
        if (!isTest) ApplySpecialFloors(data, graph);
        ApplyFixedNodes(data, graph, enforceGuards: !isTest); // 특정 좌표 강제
        AssignWeightedWithRules(data, graph, genRand, isTest);
        if (!isTest)
        {
            EnforceSpecialNodeLimits(data, graph);
            graph = MergeEquivalentDiamonds(data, graph);
        }

#if UNITY_EDITOR || DEVELOPMENT_BUILD
        if (!isTest) ValidateInvariants(data, graph);
#endif
        return graph;
    }

#if UNITY_EDITOR || DEVELOPMENT_BUILD
    /// <summary>
    /// 생성 결과의 핵심 불변식을 개발 빌드에서만 검증해 로그로 알린다(런타임 부하 0 배포).
    ///  - 마지막 행은 전부 Boss (중간 보스 없음 → 조기 종료 방지)
    ///  - 보스 전 행은 전부 Rest (모든 경로 휴식 보장)
    ///  - 중간 depth 에 Boss 노드가 하나도 없어야 함
    /// </summary>
    private static void ValidateInvariants(StageDataSO data, MapGraph graph)
    {
        int depth = data.Depth;

        for (int i = 0; i < graph.GetDepthWidth(depth); i++)
        {
            MapNode n = graph.GetNode(depth, i);
            if (n != null && n.NodeType != ENodeType.Boss)
                Debug.LogError($"[MapGenerator] 마지막 행 노드가 Boss 가 아닙니다. stage={data.StageId}, id={n.Id}, type={n.NodeType}");
        }

        if (depth >= 3)
        {
            for (int i = 0; i < graph.GetDepthWidth(depth - 1); i++)
            {
                MapNode n = graph.GetNode(depth - 1, i);
                if (n != null && n.NodeType != ENodeType.Rest)
                    Debug.LogError($"[MapGenerator] 보스 전 행 노드가 Rest 가 아닙니다. stage={data.StageId}, id={n.Id}, type={n.NodeType}");
            }
        }

        foreach (MapNode n in graph.Nodes)
        {
            if (n.NodeType == ENodeType.Boss && n.Depth != depth)
                Debug.LogError($"[MapGenerator] 중간 depth 에 Boss 노드가 있습니다(조기 종료 위험). stage={data.StageId}, id={n.Id}, depth={n.Depth}");
        }
    }
#endif

    /// <summary>
    /// 플랫폼·런타임·버전에 무관하게 항상 같은 값을 내는 안정 문자열 해시(FNV-1a 32bit).
    /// 맵 재현(저장·리플레이·디버그)의 기준이므로 System.String.GetHashCode 대신 사용한다.
    /// </summary>
    private static int StableHash(string s)
    {
        unchecked
        {
            const uint FNV_OFFSET_BASIS = 2166136261;
            const uint FNV_PRIME = 16777619;
            uint hash = FNV_OFFSET_BASIS;
            if (s != null)
            {
                for (int i = 0; i < s.Length; i++)
                {
                    hash ^= s[i];
                    hash *= FNV_PRIME;
                }
            }
            return (int)hash;
        }
    }

    // =====================================================================
    // 3-a. 특수 층 자동 배치 (코드에서 depth 로 도출 — SO 강제 입력 불필요)
    // =====================================================================

    /// <summary>
    /// depth 기반 특수 층을 자동 배치한다.
    ///  - 첫 행: 전부 Battle (안정적 시작)
    ///  - 보스 전 행(Depth-1): 전부 Rest → 모든 경로가 반드시 통과하므로 휴식 보장
    ///  - 보스 행(Depth): 전부 Boss
    /// 이 패스 이후에도 None 인 노드는 일반 행으로, 3-b 에서 가중치 배정된다.
    /// </summary>
    private static void ApplySpecialFloors(StageDataSO data, MapGraph graph)
    {
        int depth = data.Depth;

        // 첫 행 = 전투
        SetRowType(graph, 1, ENodeType.Battle);

        // 보스 행 / 보스 전 휴식 행 (Depth 가 충분히 클 때만)
        if (depth >= 2) SetRowType(graph, depth, ENodeType.Boss);
        if (depth >= 3) SetRowType(graph, depth - 1, ENodeType.Rest);

        // 중간 보물 행은 더 이상 자동 배치하지 않는다. 보물은 _nodeWeights(가중치)로만 등장.
    }

    /// <summary>
    /// StageDataSO._fixedNodes 로 지정된 좌표의 노드 타입을 강제한다.
    /// 특수 층 자동 배치보다 뒤에 실행되어 그 위를 덮으므로, 고정 지정이 최우선이다.
    /// enforceGuards(Live)면 아래 하드가드로 마지막 행·보스 전 행·중간 보스 고정은 무시하고,
    /// false(Test)면 가드 없이 고정 타입을 그대로 적용한다(완전 raw).
    /// </summary>
    private static void ApplyFixedNodes(StageDataSO data, MapGraph graph, bool enforceGuards)
    {
        int depth = data.Depth;

        for (int d = 1; d <= depth; d++)
        {
            int width = graph.GetDepthWidth(d);
            for (int i = 0; i < width; i++)
            {
                ENodeType fixedType = data.GetFixedNodeType(d, i);
                if (fixedType == ENodeType.None) continue;

                // ── 안전 불변식 하드가드 (Live 전용) ──────────────────────────
                // 마지막 행(보스)·보스 전 행(휴식)·중간 보스 고정은 스테이지를 중간에서
                // 조기 종료시키거나 휴식 보장을 깨뜨릴 수 있어 무시한다(데이터 실수 방어).
                // 잘못된 데이터를 조용히 통과시키지 않도록 오류 로그로 반드시 알린다.
                if (enforceGuards)
                {
                    if (d == depth)
                    {
                        Debug.LogError($"[MapGenerator] 마지막 행(depth {d})은 보스 전용입니다. 고정 노드({fixedType})를 무시합니다. stage={data.StageId}");
                        continue;
                    }
                    if (d == depth - 1)
                    {
                        Debug.LogError($"[MapGenerator] 보스 전 행(depth {d})은 휴식 전용입니다. 고정 노드({fixedType})를 무시합니다. stage={data.StageId}");
                        continue;
                    }
                    if (fixedType == ENodeType.Boss)
                    {
                        Debug.LogError($"[MapGenerator] 보스는 마지막 행(depth {depth})에만 자동 배치됩니다. 중간 보스 고정(depth {d})을 무시합니다. stage={data.StageId}");
                        continue;
                    }
                }

                MapNode node = graph.GetNode(d, i);
                if (node != null) node.NodeType = fixedType;
            }
        }
    }

    /// <summary>지정 depth 행의 모든 노드 타입을 일괄 설정.</summary>
    private static void SetRowType(MapGraph graph, int depth, ENodeType type)
    {
        int width = graph.GetDepthWidth(depth);
        for (int i = 0; i < width; i++)
        {
            MapNode node = graph.GetNode(depth, i);
            if (node != null) node.NodeType = type;
        }
    }

    // =====================================================================
    // 3-b. 일반 행 가중치 배정 + 인접 중복(연속 특수) 회피
    // =====================================================================

    /// <summary>
    /// 아직 None 인 노드(일반 행)에 가중치 비례로 타입을 배정한다.
    /// 이미 타입이 정해진 이웃(부모=이전 행 + 자식=이미 배정된 특수/고정 다음 행)과
    /// 동일한 특수 타입(Rest/Shop)이 연속되지 않도록 재추첨하며, 한도 초과 시
    /// Battle 로 폴백한다. depth·index 오름차순으로 순회해 결정론을 보장한다.
    /// (자식 검사 덕분에 보스 전 '휴식 벽'·고정 '상점 벽' 앞에서 같은 타입이 겹치지 않는다.)
    /// </summary>
    private static void AssignWeightedWithRules(
        StageDataSO data, MapGraph graph, DeterministicRandom rand, bool isTest)
    {
        var weightBuffer = new List<NodeTypeWeight>(8);
        int rerollLimit = isTest
            ? Mathf.Max(0, data.TypeRerollLimit)
            : Mathf.Max(4, data.TypeRerollLimit);

        for (int d = 1; d <= data.Depth; d++)
        {
            int width = graph.GetDepthWidth(d);
            for (int i = 0; i < width; i++)
            {
                MapNode node = graph.GetNode(d, i);
                if (node == null || node.NodeType != ENodeType.None) continue; // 특수 층은 건너뜀

                ENodeType chosen = ENodeType.Battle;
                ENodeType adjacentFallback = ENodeType.None;
                for (int attempt = 0; attempt <= rerollLimit; attempt++)
                {
                    ENodeType candidate = RollWeighted(data, d, rand, weightBuffer, isTest);
                    if (!isTest && !IsAllowedLiveWeightedType(candidate))
                        candidate = ENodeType.Battle;

                    if (!isTest && WouldCreateThreeConsecutive(graph, node, candidate))
                        continue;

                    if (isTest || !IsLiveSpecial(candidate) || !HasAdjacentSameType(graph, node, candidate))
                    {
                        chosen = candidate;
                        break;
                    }

                    // 같은 특수 타입 2연속은 후순위 폴백으로만 허용한다.
                    adjacentFallback = candidate;
                }

                if (chosen == ENodeType.Battle && adjacentFallback != ENodeType.None)
                    chosen = adjacentFallback;
                node.NodeType = chosen;
            }
        }
    }

    /// <summary>가중치 비례로 타입 1개 추첨. 유효 항목이 없으면 Battle 폴백.</summary>
    private static ENodeType RollWeighted(
        StageDataSO data, int depth, DeterministicRandom rand, List<NodeTypeWeight> buffer, bool isTest)
    {
        data.CollectValidWeights(depth, buffer);
        if (buffer.Count == 0) return ENodeType.Battle;

        int total = 0;
        for (int k = 0; k < buffer.Count; k++) total += buffer[k].Weight;
        if (total <= 0) return ENodeType.Battle;

        int roll = rand.Next(0, total);
        int acc = 0;
        for (int k = 0; k < buffer.Count; k++)
        {
            acc += buffer[k].Weight;
            if (roll < acc)
            {
                ENodeType type = buffer[k].Type;
                return isTest || IsAllowedLiveWeightedType(type) ? type : ENodeType.Battle;
            }
        }
        return ENodeType.Battle;
    }

    private static bool IsAllowedLiveWeightedType(ENodeType type)
    {
        return type == ENodeType.Battle || IsLiveSpecial(type);
    }

    private static bool IsLiveSpecial(ENodeType type)
    {
        return type == ENodeType.Rest || type == ENodeType.Shop ||
               type == ENodeType.Event || type == ENodeType.Elite;
    }

    private static bool HasAdjacentSameType(MapGraph graph, MapNode node, ENodeType type)
    {
        if (!IsLiveSpecial(type)) return false;

        int prevDepth = node.Depth - 1;
        if (prevDepth >= 1)
        {
            int prevWidth = graph.GetDepthWidth(prevDepth);
            for (int i = 0; i < prevWidth; i++)
            {
                MapNode parent = graph.GetNode(prevDepth, i);
                if (parent != null && parent.NodeType == type && parent.IsAdjacent(node))
                    return true;
            }
        }

        for (int i = 0; i < node.Adjacency.Count; i++)
        {
            MapNode child = graph.GetNode(node.Adjacency[i]);
            if (child != null && child.NodeType == type) return true;
        }
        return false;
    }

    /// <summary>후보 배치로 같은 특수 타입이 경로상 3회 연속되는지 검사한다.</summary>
    private static bool WouldCreateThreeConsecutive(MapGraph graph, MapNode node, ENodeType type)
    {
        if (!IsLiveSpecial(type)) return false;

        var parents = new List<MapNode>(4);
        CollectParents(graph, node, parents);

        // grandparent -> parent -> node
        for (int i = 0; i < parents.Count; i++)
        {
            MapNode parent = parents[i];
            if (parent.NodeType != type) continue;

            var grandparents = new List<MapNode>(4);
            CollectParents(graph, parent, grandparents);
            for (int j = 0; j < grandparents.Count; j++)
                if (grandparents[j].NodeType == type) return true;
        }

        // parent -> node -> child
        for (int i = 0; i < parents.Count; i++)
        {
            if (parents[i].NodeType != type) continue;
            for (int j = 0; j < node.Adjacency.Count; j++)
            {
                MapNode child = graph.GetNode(node.Adjacency[j]);
                if (child != null && child.NodeType == type) return true;
            }
        }

        // node -> child -> grandchild
        for (int i = 0; i < node.Adjacency.Count; i++)
        {
            MapNode child = graph.GetNode(node.Adjacency[i]);
            if (child == null || child.NodeType != type) continue;
            for (int j = 0; j < child.Adjacency.Count; j++)
            {
                MapNode grandchild = graph.GetNode(child.Adjacency[j]);
                if (grandchild != null && grandchild.NodeType == type) return true;
            }
        }

        return false;
    }

    private static void CollectParents(MapGraph graph, MapNode node, List<MapNode> buffer)
    {
        buffer.Clear();
        int depth = node.Depth - 1;
        if (depth < 1) return;

        int width = graph.GetDepthWidth(depth);
        for (int i = 0; i < width; i++)
        {
            MapNode parent = graph.GetNode(depth, i);
            if (parent != null && parent.IsAdjacent(node)) buffer.Add(parent);
        }
    }

    // =====================================================================
    // Live 특수 노드 개수/분산 보정 (Rest -> Shop -> Event -> Elite)
    // =====================================================================

    private static void EnforceSpecialNodeLimits(StageDataSO data, MapGraph graph)
    {
        var targets = new Dictionary<ENodeType, int>();
        for (int i = 0; i < LiveSpecialPlacementPriority.Length; i++)
        {
            ENodeType type = LiveSpecialPlacementPriority[i];
            data.GetSpecialNodeCountLimit(type, out int min, out int max);
            int original = CountType(graph, type);
            int target = Mathf.Max(min, original);
            if (max >= 0) target = Mathf.Min(target, max);

            int protectedCount = CountProtectedType(data, graph, type);
            if (max >= 0 && protectedCount > max)
            {
                Debug.LogError(
                    $"[MapGenerator] 고정/구조 노드 때문에 {type} 최대 {max}개를 지킬 수 없습니다. " +
                    $"protected={protectedCount}, stage={data.StageId}");
            }
            targets[type] = Mathf.Max(target, protectedCount);
        }

        // 가중 추첨은 타입별 목표 개수만 결정한다. 위치는 아래 우선순위/커버리지 패스가
        // 전부 다시 정해 자연 추첨 노드까지 특정 시작 루트에 몰리지 않게 한다.
        for (int depth = 1; depth <= graph.Depth; depth++)
        {
            int width = graph.GetDepthWidth(depth);
            for (int index = 0; index < width; index++)
            {
                MapNode node = graph.GetNode(depth, index);
                if (node != null && IsLiveSpecial(node.NodeType) &&
                    !IsProtectedLiveNode(data, graph, node))
                    node.NodeType = ENodeType.Battle;
            }
        }

        for (int i = 0; i < LiveSpecialPlacementPriority.Length; i++)
        {
            ENodeType type = LiveSpecialPlacementPriority[i];
            EnsureMinNodeCountDistributed(data, graph, type, targets[type]);
        }
    }

    private static void EnsureMinNodeCountDistributed(
        StageDataSO data, MapGraph graph, ENodeType type, int target)
    {
        int count = CountType(graph, type);
        if (target <= count) return;

        Dictionary<int, ulong> origins = BuildStartOriginMasks(graph);
        ulong covered = 0UL;
        for (int depth = 1; depth <= graph.Depth; depth++)
        {
            int width = graph.GetDepthWidth(depth);
            for (int index = 0; index < width; index++)
            {
                MapNode node = graph.GetNode(depth, index);
                if (node != null && node.NodeType == type && origins.TryGetValue(node.Id, out ulong mask))
                    covered |= mask;
            }
        }

        int minDepth = data.GetTypeMinDepth(type);
        int lo = Mathf.Max(2, minDepth > 0 ? minDepth : 2);
        int hi = graph.Depth - 2;

        while (count < target)
        {
            MapNode best = FindBestPlacementCandidate(
                data, graph, type, lo, hi, origins, covered, requireNoAdjacent: true);
            if (best == null)
            {
                // 2연속은 허용하되 3연속은 FindBestPlacementCandidate에서 계속 금지한다.
                best = FindBestPlacementCandidate(
                    data, graph, type, lo, hi, origins, covered, requireNoAdjacent: false);
            }
            if (best == null) break;

            best.NodeType = type;
            if (origins.TryGetValue(best.Id, out ulong bestMask)) covered |= bestMask;
            count++;
        }

        if (count < target)
        {
            // target 은 "SO 최소값"과 "가중 추첨이 굴린 개수" 중 큰 값이라 시드마다 흔들린다.
            // 데이터 오류는 SO 최소값 미달뿐이고, 추첨분 미달은 배치 범위 한계일 뿐이므로
            // 오류로 올리지 않는다(추첨 결과를 요구사항으로 승격시키지 않는다).
            data.GetSpecialNodeCountLimit(type, out int configuredMin, out _);
            if (count < configuredMin)
            {
                Debug.LogError(
                    $"[MapGenerator] 3연속 금지/배치 범위 때문에 {type} 최소 {configuredMin}개를 채우지 못했습니다. " +
                    $"actual={count}, stage={data.StageId}");
            }
#if UNITY_EDITOR || DEVELOPMENT_BUILD
            else
            {
                Debug.Log(
                    $"[MapGenerator] {type} 추첨 목표 {target}개 중 {count}개만 배치했습니다(배치 범위 한계). " +
                    $"min={configuredMin}, stage={data.StageId}");
            }
#endif
        }
    }

    private static MapNode FindBestPlacementCandidate(
        StageDataSO data,
        MapGraph graph,
        ENodeType type,
        int lo,
        int hi,
        Dictionary<int, ulong> origins,
        ulong covered,
        bool requireNoAdjacent)
    {
        MapNode best = null;
        int bestNewCoverage = -1;
        int bestDepthLoad = int.MaxValue;
        int bestTie = int.MaxValue;

        for (int depth = lo; depth <= hi; depth++)
        {
            int depthLoad = CountTypeInRow(graph, depth, type);
            int width = graph.GetDepthWidth(depth);
            for (int index = 0; index < width; index++)
            {
                MapNode node = graph.GetNode(depth, index);
                if (node == null || node.NodeType != ENodeType.Battle) continue;
                if (data.GetFixedNodeType(depth, index) != ENodeType.None) continue;
                if (WouldCreateThreeConsecutive(graph, node, type)) continue;
                if (requireNoAdjacent && HasAdjacentSameType(graph, node, type)) continue;

                ulong mask = origins.TryGetValue(node.Id, out ulong value) ? value : 0UL;
                int newCoverage = BitCount(mask & ~covered);
                int tie = StableCandidateKey(graph.Seed, type, node.Id);
                if (newCoverage > bestNewCoverage ||
                    (newCoverage == bestNewCoverage && depthLoad < bestDepthLoad) ||
                    (newCoverage == bestNewCoverage && depthLoad == bestDepthLoad && tie < bestTie))
                {
                    best = node;
                    bestNewCoverage = newCoverage;
                    bestDepthLoad = depthLoad;
                    bestTie = tie;
                }
            }
        }
        return best;
    }

    private static Dictionary<int, ulong> BuildStartOriginMasks(MapGraph graph)
    {
        var result = new Dictionary<int, ulong>(graph.NodeCount);
        int startWidth = graph.GetDepthWidth(1);
        for (int index = 0; index < startWidth; index++)
        {
            MapNode start = graph.GetNode(1, index);
            if (start == null) continue;
            result[start.Id] = index < 64 ? 1UL << index : ulong.MaxValue;
        }

        for (int depth = 1; depth < graph.Depth; depth++)
        {
            int width = graph.GetDepthWidth(depth);
            for (int index = 0; index < width; index++)
            {
                MapNode node = graph.GetNode(depth, index);
                if (node == null || !result.TryGetValue(node.Id, out ulong mask)) continue;
                for (int childIndex = 0; childIndex < node.Adjacency.Count; childIndex++)
                {
                    int childId = node.Adjacency[childIndex];
                    result.TryGetValue(childId, out ulong current);
                    result[childId] = current | mask;
                }
            }
        }
        return result;
    }

    private static int BitCount(ulong value)
    {
        int count = 0;
        while (value != 0)
        {
            value &= value - 1;
            count++;
        }
        return count;
    }

    private static int StableCandidateKey(int seed, ENodeType type, int nodeId)
    {
        unchecked
        {
            uint value = (uint)seed;
            value ^= (uint)nodeId * 2246822519u;
            value ^= (uint)type * 3266489917u;
            value ^= value >> 16;
            value *= 2654435761u;
            return (int)(value & 0x7fffffff);
        }
    }

    private static int CountType(MapGraph graph, ENodeType type)
    {
        int count = 0;
        for (int depth = 1; depth <= graph.Depth; depth++)
            count += CountTypeInRow(graph, depth, type);
        return count;
    }

    private static int CountTypeInRow(MapGraph graph, int depth, ENodeType type)
    {
        int count = 0;
        int width = graph.GetDepthWidth(depth);
        for (int index = 0; index < width; index++)
        {
            MapNode node = graph.GetNode(depth, index);
            if (node != null && node.NodeType == type) count++;
        }
        return count;
    }

    private static int CountProtectedType(
        StageDataSO data, MapGraph graph, ENodeType type)
    {
        int count = 0;
        for (int depth = 1; depth <= graph.Depth; depth++)
        {
            int width = graph.GetDepthWidth(depth);
            for (int index = 0; index < width; index++)
            {
                MapNode node = graph.GetNode(depth, index);
                if (node != null && node.NodeType == type && IsProtectedLiveNode(data, graph, node))
                    count++;
            }
        }
        return count;
    }

    private static bool IsProtectedLiveNode(StageDataSO data, MapGraph graph, MapNode node)
    {
        if (data.GetFixedNodeType(node.Depth, node.Index) != ENodeType.None) return true;
        return node.Depth == 1 || node.Depth == graph.Depth ||
               (graph.Depth >= 3 && node.Depth == graph.Depth - 1);
    }

    // =====================================================================
    // 동일한 단일/연쇄 다이아몬드 경로 병합
    // =====================================================================

    private static MapGraph MergeEquivalentDiamonds(StageDataSO data, MapGraph source)
    {
        if (data.HasFixedNodes)
        {
            Debug.LogWarning(
                $"[MapGenerator] Live 고정 좌표의 의미를 보존하기 위해 동일 경로 병합을 생략합니다. stage={data.StageId}");
            return source;
        }

        var canonical = new Dictionary<int, int>(source.NodeCount);
        foreach (MapNode node in source.Nodes) canonical[node.Id] = node.Id;

        var counts = new Dictionary<ENodeType, int>();
        for (int i = 0; i < LiveSpecialPlacementPriority.Length; i++)
        {
            ENodeType type = LiveSpecialPlacementPriority[i];
            counts[type] = CountType(source, type);
        }

        bool mergedAny = false;
        for (int depth = source.Depth - 1; depth >= 2; depth--)
        {
            int activeCount = source.GetDepthWidth(depth);
            for (int left = 0; left < source.GetDepthWidth(depth) && activeCount > 2; left++)
            {
                MapNode a = source.GetNode(depth, left);
                if (a == null || ResolveCanonical(canonical, a.Id) != a.Id) continue;
                if (data.GetFixedNodeType(depth, left) != ENodeType.None) continue;

                for (int right = left + 1; right < source.GetDepthWidth(depth) && activeCount > 2; right++)
                {
                    MapNode b = source.GetNode(depth, right);
                    if (b == null || ResolveCanonical(canonical, b.Id) != b.Id) continue;
                    if (data.GetFixedNodeType(depth, right) != ENodeType.None) continue;
                    if (a.NodeType != b.NodeType) continue;
                    if (!HaveSameCanonicalChildren(a, b, canonical)) continue;

                    if (IsLiveSpecial(b.NodeType))
                    {
                        data.GetSpecialNodeCountLimit(b.NodeType, out int min, out _);
                        if (counts[b.NodeType] - 1 < min) continue;
                        counts[b.NodeType]--;
                    }

                    canonical[b.Id] = a.Id;
                    activeCount--;
                    mergedAny = true;
                }
            }
        }

        if (!mergedAny) return source;
        return RebuildMergedGraph(source, canonical);
    }

    private static bool HaveSameCanonicalChildren(
        MapNode a, MapNode b, Dictionary<int, int> canonical)
    {
        var left = new List<int>(a.Adjacency.Count);
        var right = new List<int>(b.Adjacency.Count);
        for (int i = 0; i < a.Adjacency.Count; i++)
        {
            int id = ResolveCanonical(canonical, a.Adjacency[i]);
            if (!left.Contains(id)) left.Add(id);
        }
        for (int i = 0; i < b.Adjacency.Count; i++)
        {
            int id = ResolveCanonical(canonical, b.Adjacency[i]);
            if (!right.Contains(id)) right.Add(id);
        }
        left.Sort();
        right.Sort();
        if (left.Count != right.Count) return false;
        for (int i = 0; i < left.Count; i++) if (left[i] != right[i]) return false;
        return left.Count > 0;
    }

    private static int ResolveCanonical(Dictionary<int, int> canonical, int id)
    {
        int current = id;
        while (canonical.TryGetValue(current, out int next) && next != current) current = next;
        return current;
    }

    private static MapGraph RebuildMergedGraph(
        MapGraph source, Dictionary<int, int> canonical)
    {
        var result = new MapGraph(source.Seed, source.Depth, source.StageIndex);
        var representativeToNew = new Dictionary<int, MapNode>();

        for (int depth = 1; depth <= source.Depth; depth++)
        {
            int newIndex = 0;
            int width = source.GetDepthWidth(depth);
            for (int index = 0; index < width; index++)
            {
                MapNode oldNode = source.GetNode(depth, index);
                if (oldNode == null || ResolveCanonical(canonical, oldNode.Id) != oldNode.Id) continue;

                var newNode = new MapNode(
                    oldNode.Seed, source.StageIndex, depth, newIndex++, oldNode.NodeType);
                newNode.EnemyId = oldNode.EnemyId;
                newNode.Explored = oldNode.Explored;
                result.AddNode(newNode);
                representativeToNew[oldNode.Id] = newNode;
            }
            result.SetDepthWidth(depth, newIndex);
        }

        for (int depth = 1; depth < source.Depth; depth++)
        {
            int width = source.GetDepthWidth(depth);
            for (int index = 0; index < width; index++)
            {
                MapNode oldNode = source.GetNode(depth, index);
                if (oldNode == null || ResolveCanonical(canonical, oldNode.Id) != oldNode.Id) continue;
                if (!representativeToNew.TryGetValue(oldNode.Id, out MapNode newNode)) continue;

                for (int childIndex = 0; childIndex < oldNode.Adjacency.Count; childIndex++)
                {
                    int representativeId = ResolveCanonical(canonical, oldNode.Adjacency[childIndex]);
                    if (representativeToNew.TryGetValue(representativeId, out MapNode child))
                        newNode.AddAdjacent(child);
                }
            }
        }

        return result;
    }

    // =====================================================================
    // 위상(인접성) 연결 — 기존 검증 로직 그대로 유지
    // =====================================================================

    /// <summary>
    /// 인접성 연결. 에셋 Map.GenerateMap 의 연결 로직을 그대로 이식.
    /// 두 행의 너비 차로 offset 을 잡고, 직선 연결 + 좌/우 대각(forkProbability) 연결을
    /// 만들되 prev_diag 플래그로 대각선이 겹치지 않게 한다.
    /// </summary>
    private static void ConnectAdjacency(StageDataSO data, MapGraph graph, DeterministicRandom genRand)
    {
        double forkProb = data.ForkProbability;

        for (int d = 1; d <= data.Depth - 1; d++)
        {
            int depthCur = d;
            int depthNext = d + 1;
            int widthCur = graph.GetDepthWidth(depthCur);
            int widthNext = graph.GetDepthWidth(depthNext);
            int span = Mathf.Max(widthCur, widthNext);   // 두 행 중 더 넓은 쪽 기준 순회
            int offset = (widthNext - widthCur) / 2;       // 현재행→다음행 index 정렬 보정
            int start = -Mathf.Abs(offset);                 // offset 있으면 음수에서 시작

            bool prevDiag = false; // 직전 칸이 대각선을 그었는지 (겹침 방지)

            for (int i = start; i < span; i++)
            {
                int ci = Mathf.Clamp(i, 0, widthCur - 1);
                MapNode cur = graph.GetNode(depthCur, ci);

                int niVal = i + offset;
                int ni = Mathf.Clamp(niVal, 0, widthNext - 1);
                if (ni != niVal) prevDiag = true; // 클램프로 밀렸으면 대각선 그은 것으로 간주

                MapNode straight = graph.GetNode(depthNext, ni);
                if (cur == null || straight == null) continue;

                // 직선 연결 (이미 연결돼 있으면 이 칸 전체 스킵 — 에셋 동작 유지).
                if (cur.IsAdjacent(straight)) continue;
                cur.AddAdjacent(straight);

                // 왼쪽 대각 (직전 칸이 대각선을 안 그었고, 확률 충족 시).
                if (!prevDiag && ni > 0 && genRand.NextDouble() < forkProb)
                {
                    MapNode left = graph.GetNode(depthNext, ni - 1);
                    cur.AddAdjacent(left);
                }

                // 오른쪽 대각 (확률 충족 시). 그었으면 prevDiag 세워 다음 칸 왼쪽대각 억제.
                prevDiag = false;
                if (i <= niVal && ni < widthNext - 1 && genRand.NextDouble() < forkProb)
                {
                    MapNode right = graph.GetNode(depthNext, ni + 1);
                    cur.AddAdjacent(right);
                    prevDiag = true;
                }
            }
        }
    }
}
