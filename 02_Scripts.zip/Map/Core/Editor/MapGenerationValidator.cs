// =================================================================
// [스크립트 목적]  맵 생성 불변식을 에디터 메뉴에서 검증하는 도구 (구 EditMode 테스트 대체).
//                 asmdef 해체로 Test Runner 를 못 쓰므로, 동일 검증을 [MenuItem] 으로 제공.
// [사용법]         메뉴 Tools ▸ Map ▸ Validate Generation 실행 → 콘솔에 통과/실패 로그.
// [검증 항목]      시드 0~99 전체에서: 완전 결정성 / 도달성 / 특수 노드 범위 /
//                  동일 특수 3연속 금지 / 내부 분기 하한 / 동일 다이아몬드 병합.
// [의존 관계]      MapGenerator / MapGraph / MapNode / StageDataSO / ENodeType (Assembly-CSharp)
// =================================================================

using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEditor;
using UnityEngine;

/// <summary>
/// 맵 생성 결과의 핵심 불변식을 에디터에서 일괄 검증하는 도구.
/// 메인 StageData 에셋 각각에 시드 0~99를 적용해 규칙 위반을 콘솔에 보고한다.
/// </summary>
public static class MapGenerationValidator
{
    private const int SeedCount = 100;

    [MenuItem("Tools/Map/Validate Generation")]
    public static void Validate()
    {
        int failures = 0;
        string[] guids = AssetDatabase.FindAssets(
            "t:StageDataSO", new[] { "Assets/00_Addressable/Data/SO/Map/Main" });
        var stages = new List<StageDataSO>();
        for (int i = 0; i < guids.Length; i++)
        {
            StageDataSO stage = AssetDatabase.LoadAssetAtPath<StageDataSO>(
                AssetDatabase.GUIDToAssetPath(guids[i]));
            if (stage != null && stage.PlayMode == EMapPlayMode.Live) stages.Add(stage);
        }

        StageDataSO fallback = null;
        if (stages.Count == 0)
        {
            fallback = ScriptableObject.CreateInstance<StageDataSO>();
            stages.Add(fallback);
        }

        stages.Sort((a, b) => string.CompareOrdinal(a.StageId, b.StageId));
        for (int stageIndex = 0; stageIndex < stages.Count; stageIndex++)
            failures += ValidateStage(stages[stageIndex], stageIndex);

        if (fallback != null) Object.DestroyImmediate(fallback);

        if (failures == 0)
            Debug.Log($"[MapGenerationValidator] ✅ 통과 — Live 스테이지 {stages.Count}개, 시드 0~{SeedCount - 1} 전체 불변식 만족.");
        else
            Debug.LogError($"[MapGenerationValidator] ❌ 실패 {failures}건 — 위 로그 참조.");
    }

    private static int ValidateStage(StageDataSO data, int stageIndex)
    {
        int failures = 0;
        var distinctSnapshots = new HashSet<string>();

        for (int seed = 0; seed < SeedCount; seed++)
        {
            MapGraph a = MapGenerator.Generate(data, seed, stageIndex);
            MapGraph b = MapGenerator.Generate(data, seed, stageIndex);
            MapGraph c = MapGenerator.Generate(data, seed, stageIndex);
            string snapshot = CreateCanonicalSnapshot(a);
            distinctSnapshots.Add(snapshot);

            // 1) 같은 입력의 반복 생성은 ID/시드/간선 순서까지 완전히 동일해야 한다.
            if (!GraphsEqual(a, b) || !GraphsEqual(a, c) ||
                snapshot != CreateCanonicalSnapshot(b) || snapshot != CreateCanonicalSnapshot(c))
                failures += Fail(data, seed, "결정성: 같은 StageData/시드/stageIndex가 다른 맵 생성");

            // 2) 휴식 경로 보장 (모든 루트가 Rest 통과)
            if (!AllRoutesContain(a, ENodeType.Rest))
                failures += Fail(data, seed, "휴식: 일부 경로가 Rest 를 지나지 않음");

            // 3) 타입별 최소·최대
            ENodeType[] specials = { ENodeType.Rest, ENodeType.Shop, ENodeType.Event, ENodeType.Elite };
            foreach (ENodeType type in specials)
            {
                data.GetSpecialNodeCountLimit(type, out int min, out int max);
                int actual = CountType(a, type);
                if (actual < min) failures += Fail(data, seed, $"{type}: 최소 {min}개 미만(실제 {actual})");
                int mandatory = type == ENodeType.Rest && a.Depth >= 3
                    ? a.GetDepthWidth(a.Depth - 1)
                    : 0;
                if (max >= 0 && actual > Mathf.Max(max, mandatory))
                    failures += Fail(data, seed, $"{type}: 최대 {max}개 초과(실제 {actual}, 구조필수 {mandatory})");
            }

            // 5) 보스/보스전 행
            if (!RowAll(a, a.Depth, ENodeType.Boss)) failures += Fail(data, seed, "마지막 행이 전부 Boss 아님");
            if (a.Depth >= 3 && !RowAll(a, a.Depth - 1, ENodeType.Rest)) failures += Fail(data, seed, "보스 전 행이 전부 Rest 아님");
            if (!RowAll(a, 1, ENodeType.Battle)) failures += Fail(data, seed, "첫 행이 전부 Battle 아님");

            // 6) 3연속 금지 / Live 제외 타입
            foreach (ENodeType type in specials)
                if (HasThreeConsecutive(a, type)) failures += Fail(data, seed, $"{type} 3연속 발견");
            if (CountType(a, ENodeType.Treasure) > 0 || CountType(a, ENodeType.Test) > 0)
                failures += Fail(data, seed, "Live 맵에 Treasure/Test 노드 발견");

            // 7) 내부 분기 하한과 도달성
            for (int depth = 1; depth < a.Depth; depth++)
                if (a.GetDepthWidth(depth) < 2) failures += Fail(data, seed, $"depth {depth} 노드가 2개 미만");
            if (!AllNodesReachableFromStart(a)) failures += Fail(data, seed, "시작점에서 도달할 수 없는 고아 노드 발견");
            if (!EveryStartReachesBoss(a)) failures += Fail(data, seed, "Boss에 도달하지 못하는 시작점 발견");

            // 8) 병합 가능한 동일 단일 다이아몬드가 남지 않아야 한다.
            if (HasMergeableDiamond(data, a)) failures += Fail(data, seed, "병합 가능한 동일 다이아몬드가 남아 있음");
        }

        if (distinctSnapshots.Count <= 1)
            failures += Fail(data, -1, "시드 0~99가 모두 같은 맵을 생성함");
        return failures;
    }

    private static int Fail(StageDataSO data, int seed, string msg)
    {
        Debug.LogError($"[MapGenerationValidator] [stage {data.StageId}] [seed {seed}] {msg}");
        return 1;
    }

    private static int CountType(MapGraph g, ENodeType type)
    {
        int c = 0;
        foreach (MapNode n in g.Nodes) if (n.NodeType == type) c++;
        return c;
    }

    private static bool RowAll(MapGraph g, int depth, ENodeType type)
    {
        int width = g.GetDepthWidth(depth);
        for (int i = 0; i < width; i++)
        {
            MapNode n = g.GetNode(depth, i);
            if (n == null || n.NodeType != type) return false;
        }
        return width > 0;
    }

    private static bool HasThreeConsecutive(MapGraph g, ENodeType type)
    {
        foreach (MapNode n in g.Nodes)
        {
            if (n.NodeType != type) continue;
            foreach (int childId in n.Adjacency)
            {
                MapNode child = g.GetNode(childId);
                if (child == null || child.NodeType != type) continue;
                foreach (int grandchildId in child.Adjacency)
                {
                    MapNode grandchild = g.GetNode(grandchildId);
                    if (grandchild != null && grandchild.NodeType == type) return true;
                }
            }
        }
        return false;
    }

    /// <summary>모든 시작(depth 1)→보스 경로가 지정 타입 노드를 하나 이상 지나는지 DP 로 판정.</summary>
    private static bool AllRoutesContain(MapGraph g, ENodeType type)
    {
        var covered = new Dictionary<int, bool>(g.NodeCount);
        for (int d = g.Depth; d >= 1; d--)
        {
            int width = g.GetDepthWidth(d);
            for (int i = 0; i < width; i++)
            {
                MapNode node = g.GetNode(d, i);
                if (node == null) continue;

                bool result;
                if (node.NodeType == type) result = true;
                else if (node.Adjacency.Count == 0) result = false;
                else
                {
                    result = true;
                    foreach (int childId in node.Adjacency)
                    {
                        if (!covered.TryGetValue(childId, out bool c) || !c) { result = false; break; }
                    }
                }
                covered[node.Id] = result;
            }
        }

        int startWidth = g.GetDepthWidth(1);
        for (int i = 0; i < startWidth; i++)
        {
            MapNode start = g.GetNode(1, i);
            if (start != null && !covered[start.Id]) return false;
        }
        return true;
    }

    private static bool GraphsEqual(MapGraph a, MapGraph b)
    {
        if (a.NodeCount != b.NodeCount || a.Depth != b.Depth ||
            a.Seed != b.Seed || a.StageIndex != b.StageIndex) return false;
        for (int depth = 1; depth <= a.Depth; depth++)
        {
            int width = a.GetDepthWidth(depth);
            if (width != b.GetDepthWidth(depth)) return false;
            for (int index = 0; index < width; index++)
            {
                MapNode na = a.GetNode(depth, index);
                MapNode nb = b.GetNode(depth, index);
                if (na == null || nb == null || na.Id != nb.Id || na.Depth != nb.Depth ||
                    na.Index != nb.Index || na.NodeType != nb.NodeType || na.Seed != nb.Seed)
                    return false;
                if (na.Adjacency.Count != nb.Adjacency.Count) return false;
                for (int i = 0; i < na.Adjacency.Count; i++)
                    if (na.Adjacency[i] != nb.Adjacency[i]) return false;
            }
        }
        return true;
    }

    private static string CreateCanonicalSnapshot(MapGraph graph)
    {
        var sb = new StringBuilder(graph.NodeCount * 32);
        sb.Append(graph.Seed).Append('|').Append(graph.StageIndex).Append('|').Append(graph.Depth);
        for (int depth = 1; depth <= graph.Depth; depth++)
        {
            int width = graph.GetDepthWidth(depth);
            sb.Append(";w").Append(depth).Append('=').Append(width);
            for (int index = 0; index < width; index++)
            {
                MapNode node = graph.GetNode(depth, index);
                sb.Append(';').Append(node.Id).Append(',').Append((int)node.NodeType)
                  .Append(',').Append(node.Seed).Append('>');
                for (int i = 0; i < node.Adjacency.Count; i++)
                    sb.Append(node.Adjacency[i]).Append(',');
            }
        }
        return sb.ToString();
    }

    private static bool AllNodesReachableFromStart(MapGraph graph)
    {
        var reached = new HashSet<int>();
        var queue = new Queue<MapNode>();
        int startWidth = graph.GetDepthWidth(1);
        for (int i = 0; i < startWidth; i++)
        {
            MapNode start = graph.GetNode(1, i);
            if (start != null && reached.Add(start.Id)) queue.Enqueue(start);
        }
        while (queue.Count > 0)
        {
            MapNode node = queue.Dequeue();
            foreach (int childId in node.Adjacency)
            {
                MapNode child = graph.GetNode(childId);
                if (child != null && reached.Add(child.Id)) queue.Enqueue(child);
            }
        }
        return reached.Count == graph.NodeCount;
    }

    private static bool EveryStartReachesBoss(MapGraph graph)
    {
        var reachesBoss = new Dictionary<int, bool>();
        for (int depth = graph.Depth; depth >= 1; depth--)
        {
            int width = graph.GetDepthWidth(depth);
            for (int index = 0; index < width; index++)
            {
                MapNode node = graph.GetNode(depth, index);
                bool reaches = node.NodeType == ENodeType.Boss;
                foreach (int childId in node.Adjacency)
                    reaches |= reachesBoss.TryGetValue(childId, out bool childReaches) && childReaches;
                reachesBoss[node.Id] = reaches;
            }
        }
        int startWidth = graph.GetDepthWidth(1);
        for (int i = 0; i < startWidth; i++)
        {
            MapNode start = graph.GetNode(1, i);
            if (start == null || !reachesBoss[start.Id]) return false;
        }
        return true;
    }

    private static bool HasMergeableDiamond(StageDataSO data, MapGraph graph)
    {
        for (int depth = 2; depth < graph.Depth; depth++)
        {
            int width = graph.GetDepthWidth(depth);
            if (width <= 2) continue;
            for (int aIndex = 0; aIndex < width; aIndex++)
            {
                MapNode a = graph.GetNode(depth, aIndex);
                if (data.GetFixedNodeType(depth, aIndex) != ENodeType.None) continue;
                for (int bIndex = aIndex + 1; bIndex < width; bIndex++)
                {
                    MapNode b = graph.GetNode(depth, bIndex);
                    if (data.GetFixedNodeType(depth, bIndex) != ENodeType.None || a.NodeType != b.NodeType)
                        continue;
                    if (!SameChildren(a, b)) continue;
                    if (a.NodeType == ENodeType.Rest || a.NodeType == ENodeType.Shop ||
                        a.NodeType == ENodeType.Event || a.NodeType == ENodeType.Elite)
                    {
                        data.GetSpecialNodeCountLimit(a.NodeType, out int min, out _);
                        if (CountType(graph, a.NodeType) - 1 < min) continue;
                    }
                    return true;
                }
            }
        }
        return false;
    }

    private static bool SameChildren(MapNode a, MapNode b)
    {
        if (a.Adjacency.Count != b.Adjacency.Count || a.Adjacency.Count == 0) return false;
        return a.Adjacency.OrderBy(id => id).SequenceEqual(b.Adjacency.OrderBy(id => id));
    }
}
