// =================================================================
// [스크립트 목적]  생성된 맵 그래프 데이터 (POCO). 노드 집합 + 행별 너비를 보관·조회.
// [주요 변수]      - Seed         : 이 맵 생성에 쓰인 시드 (재현)
//                  - _nodes       : 노드 ID → MapNode 사전
//                  - _depthWidth  : depth → 그 행의 노드 개수
//                  - Depth        : 맵 총 행 수
// [의존 관계]      - MapGenerator(채워넣음)·RunContext(보유)·UIMap(렌더, 3단계)
//                  - InGameController(현재 노드의 인접 조회 → 이동 후보)
// [설계 노트]      - 에셋 Map 에서 "데이터 보관/조회"만 분리 이식.
//                    GenerateMap(생성 알고리즘)은 MapGenerator 로 떼어 단일 책임화.
//                    (에셋은 Map 이 데이터+생성+World참조까지 겸해 결합도가 높았음)
//                  - 멀티 흔적 제거: World 파라미터·map_id 다중 보유 전제 삭제.
//                  - 순수 데이터 — Unity 의존 없음(테스트 용이).
// =================================================================

using System.Collections.Generic;

/// <summary>
/// 한 번 생성된 맵의 그래프 데이터. 노드들과 행별 너비를 보관하고 조회 API 를 제공한다.
/// 생성 로직은 MapGenerator 가 담당하고, 이 클래스는 결과 보관·조회만 책임진다(단일 책임).
/// </summary>
public sealed class MapGraph
{
    /// <summary>이 맵 생성에 쓰인 시드 (재현·디버그용).</summary>
    public int Seed { get; }

    /// <summary>맵 총 행(depth) 수.</summary>
    public int Depth { get; }

    // 런 전체 고유 노드 ID → 노드.
    private readonly Dictionary<int, MapNode> _nodes = new Dictionary<int, MapNode>();

    // depth → 그 행의 노드 개수.
    private readonly Dictionary<int, int> _depthWidth = new Dictionary<int, int>();

    /// <summary>전체 노드 (읽기 전용 열거). 순서는 보장하지 않음.</summary>
    public IEnumerable<MapNode> Nodes => _nodes.Values;

    /// <summary>전체 노드 수.</summary>
    public int NodeCount => _nodes.Count;

    /// <summary>런 내 스테이지 인덱스 (0-based).</summary>
    public int StageIndex { get; }

    public MapGraph(int seed, int depth, int stageIndex)
    {
        Seed = seed;
        Depth = depth;
        StageIndex = stageIndex;
    }

    /// <summary>노드 추가 (MapGenerator 가 생성 중 호출). 같은 ID 중복 시 무시.</summary>
    public void AddNode(MapNode node)
    {
        if (node == null) return;
        _nodes.TryAdd(node.Id, node);
    }

    /// <summary>특정 depth 의 노드 개수 설정 (MapGenerator 가 생성 중 호출).</summary>
    public void SetDepthWidth(int depth, int width)
    {
        _depthWidth[depth] = width;
    }

    /// <summary>특정 depth 의 노드 개수. 없으면 0.</summary>
    public int GetDepthWidth(int depth)
    {
        return _depthWidth.TryGetValue(depth, out int w) ? w : 0;
    }

    /// <summary>ID 로 노드 조회. 없으면 null.</summary>
    public MapNode GetNode(int nodeId)
    {
        return _nodes.TryGetValue(nodeId, out MapNode node) ? node : null;
    }

    /// <summary>격자 좌표로 노드 조회. 없으면 null.</summary>
    public MapNode GetNode(int depth, int index)
    {
        return GetNode(MapNode.GetId(StageIndex, depth, index));
    }

    /// <summary>지정 노드의 인접(도달 가능) 노드 목록. 이동 후보 계산에 사용.</summary>
    public List<MapNode> GetReachableNodes(int nodeId)
    {
        var result = new List<MapNode>(4);
        MapNode node = GetNode(nodeId);
        if (node == null) return result;

        foreach (int adjId in node.Adjacency)
        {
            MapNode adj = GetNode(adjId);
            if (adj != null) result.Add(adj);
        }
        return result;
    }
}
