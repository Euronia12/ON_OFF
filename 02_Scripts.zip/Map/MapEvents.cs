// =================================================================
// [스크립트 목적]  노드맵 관련 EventManager 이벤트 struct 정의
// [사용 예시]      EventManager.Instance.Publish(new OnMapNodeEntered { NodeType = type, NodeId = id });
// [의존 관계]      InGameController(발행) / 상점·이벤트·휴식 시스템(구독, 타 담당자)
// [설계 노트]      - 전투 계열(Battle/Elite/Boss)은 InGameController 가 직접 전투로 진입시키므로
//                    이 이벤트로 나가지 않는다. 비전투 노드만 발행된다(협업 경계).
//                  - 외부 시스템은 OnMapNodeEntered 를 구독해 NodeType 에 맞는 UI/로직을 띄우고,
//                    처리가 끝나면 InGameController.NotifyNodeResolved() 를 호출해 맵 복귀를 알린다.
// =================================================================

/// <summary>
/// 비전투 노드(이벤트/상점/휴식/보물)에 진입했을 때 발행.
/// 외부 시스템이 NodeType 을 보고 해당 UI/로직을 처리한다.
/// </summary>
public struct OnMapNodeEntered
{
    /// <summary>진입한 노드의 종류 (Event/Shop/Rest/Treasure 중 하나).</summary>
    public ENodeType NodeType;

    /// <summary>진입한 노드 ID. 처리 측이 필요 시 맵에서 노드를 역참조.</summary>
    public int NodeId;
}

/// <summary>
/// 맵이 (재)표시되어 플레이어가 다음 노드를 선택할 수 있게 됐을 때 발행.
/// 맵 UI 가 구독해 도달 가능 노드를 갱신/하이라이트한다(3단계 UI 연결).
/// </summary>
public struct OnMapPresented
{
    /// <summary>현재 위치한 노드 ID (-1 이면 아직 진입 전, 첫 행이 선택지).</summary>
    public int CurrentNodeId;
}

/// <summary>
/// 스테이지 안내(Notice)가 걷히고 진입 연출(보스→시작 지점 훑기)까지 끝나
/// 맵이 실제로 플레이어 눈에 보일 때 발행. OnMapPresented(안내 뒤에서 준비 완료)와
/// 달리 "보이는 시점" 통지다 — 튜토리얼 등 표시 타이밍이 중요한 관전자 시스템
/// 구독용이며, 게임 로직은 이 이벤트에 의존하지 않는다. UIMap 이 발행한다.
/// </summary>
public struct OnMapRevealed
{
}

/// <summary>
/// 전투 노드(Battle/Elite/Boss/Test) 진입이 완료됐을 때(전투 화면 표시 후) 발행.
/// 전투 진입 자체는 InGameController 가 직접 처리하므로 이 이벤트는 통지 전용이다
/// (튜토리얼 안내·분석 등 관전자 시스템 구독용 — 전투 로직은 이 이벤트에 의존하지 않는다).
/// </summary>
public struct OnBattleNodeEntered
{
    /// <summary>진입한 전투 노드의 종류 (Battle/Elite/Boss/Test).</summary>
    public ENodeType NodeType;

    /// <summary>진입한 노드 ID.</summary>
    public int NodeId;
}