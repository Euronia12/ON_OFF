// =================================================================
// [스크립트 목적]  한 게임 진행에서 순서대로 사용할 StageDataSO 목록.
// [주요 변수]      - _sequenceId : 로그/식별용 ID
//                  - _stages     : 0-based 스테이지 인덱스에 대응하는 StageDataSO 목록
// [의존 관계]      - InGameController / DataManager(GameData 라벨)
// =================================================================

using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Serialization;

[System.Serializable]
public sealed class SkillCooldownAdjustment
{
    [Tooltip("추가 쿨타임을 적용할 스킬")]
    [SerializeField] private SkillDataSO _skill;

    [Tooltip("기본 쿨타임에 추가할 턴 수")]
    [Min(0)]
    [SerializeField] private int _additionalTurns = 1;

    public SkillDataSO Skill => _skill;
    public int AdditionalTurns => Mathf.Max(0, _additionalTurns);
}

[CreateAssetMenu(fileName = "StageSequence", menuName = "Game/Stage Sequence", order = 1)]
public sealed class StageSequenceSO : ScriptableObject
{
    [Header("식별")]
    [Tooltip("스테이지 시퀀스 식별 ID")]
    [SerializeField] private string _sequenceId = "stage_sequence_default";

    [Tooltip("이 시퀀스를 사용하는 런 난이도")]
    [SerializeField] private ERunDifficulty _difficulty = ERunDifficulty.Normal;

    [Header("난이도 규칙")]
    [Tooltip("획득 골드 배율(%). 시작 골드·디버그 지급·환불에는 적용하지 않습니다.")]
    [Min(0)]
    [SerializeField] private int _goldGainPercent = 100;

    [Tooltip("전투 보상, 상점, 무작위 카드 지급 이벤트의 등급별 등장 가중치")]
    [SerializeField] private CardRarityWeights _cardRewardRarityWeights = CardRarityWeights.Default;

    [Tooltip("전투가 끝나도 스킬의 남은 쿨타임을 다음 전투와 저장 데이터에 유지합니다.")]
    [SerializeField] private bool _preserveSkillCooldownBetweenBattles;

    [Tooltip("스킬별 기본 쿨타임에 더할 턴 수")]
    [SerializeField] private List<SkillCooldownAdjustment> _skillCooldownAdjustments =
        new List<SkillCooldownAdjustment>();

    [Tooltip("일반 전투 카드 보상의 화살표 수 제한. 0이면 제한하지 않습니다.")]
    [Min(0)]
    [SerializeField] private int _normalBattleRewardArrowLimit;

    [Tooltip("스테이지 클리어 시 '잃은 체력' 중 회복할 비율(%). 100이면 완전 회복, 0이면 회복하지 않습니다.")]
    [Range(0, 100)]
    [SerializeField] private int _stageClearHealPercent = 100;

    [Header("스테이지")]
    [Tooltip("0-based 스테이지 인덱스 순서대로 사용할 StageDataSO 목록")]
    [FormerlySerializedAs("_floorMaps")]
    [SerializeField] private List<StageDataSO> _stages = new List<StageDataSO>();

    public string SequenceId => _sequenceId;
    public ERunDifficulty Difficulty => RunDifficultyUtility.Normalize(_difficulty);
    public int GoldGainPercent => Mathf.Max(0, _goldGainPercent);
    public CardRarityWeights CardRewardRarityWeights => _cardRewardRarityWeights.IsValid
        ? _cardRewardRarityWeights
        : CardRarityWeights.Default;
    public bool PreserveSkillCooldownBetweenBattles => _preserveSkillCooldownBetweenBattles;
    public int NormalBattleRewardArrowLimit => Mathf.Max(0, _normalBattleRewardArrowLimit);

    /// <summary>스테이지 클리어 시 잃은 체력 중 회복할 비율(%). 100이면 완전 회복.</summary>
    public int StageClearHealPercent => Mathf.Clamp(_stageClearHealPercent, 0, 100);

    public IReadOnlyList<StageDataSO> Stages => _stages;

    public StageDataSO GetStageAt(int stageIndex)
    {
        if (stageIndex < 0 || stageIndex >= _stages.Count) return null;
        return _stages[stageIndex];
    }

    public int GetAdditionalSkillCooldown(SkillDataSO skill)
    {
        if (skill == null) return 0;

        // 참조 비교 금지: 비-Addressable 씬(Main.unity)이 캐릭터 SO 를 직접 참조하면
        // 빌드에서 에셋이 씬 번들로 복제돼 Addressables 사본과 인스턴스가 갈린다.
        // 그 경우 참조 비교는 항상 실패하므로 고유 키(SkillId)로 매칭한다.
        string skillId = skill.SkillId;
        if (string.IsNullOrEmpty(skillId)) return 0;

        for (int i = 0; i < _skillCooldownAdjustments.Count; i++)
        {
            SkillCooldownAdjustment adjustment = _skillCooldownAdjustments[i];
            SkillDataSO target = adjustment != null ? adjustment.Skill : null;
            if (target == null) continue;

            if (target.SkillId == skillId)
                return adjustment.AdditionalTurns;
        }

        return 0;
    }

    public bool HasValidStage
    {
        get
        {
            for (int i = 0; i < _stages.Count; i++)
            {
                if (_stages[i] != null) return true;
            }

            return false;
        }
    }
}
