// =================================================================
// [스크립트 목적]  맵 생성 직후 전투류 노드(Battle/Elite/Boss/Test)에 적을 배정하는 패스 (POCO).
//                 (런 시드 + 노드 ID) 해시 → 노드 타입에 맞는 등급 풀에서 가중치 결정론 추첨.
// [주요 메서드]    - Assign(EnemyPoolSO) : 스테이지 풀(등급 분리 + 적별 가중치)로 배정
//                  - Assign(IReadOnlyList<EnemyDataSO>) : 전역 풀 폴백(가중치 1 균등)
// [의존 관계]      - MapGraph / MapNode(EnemyId) / EnemyDataSO(Grade·EncounterTier) / ENodeType
//                  - EnemyPoolSO(WeightedEnemy) / InGameController(호출)
// [설계 노트]      - 노드에는 SO 참조가 아닌 EnemyId(string) 만 기록 (SO 격리 원칙).
//                  - 해시는 상태 없는 정수 믹싱 → 경로·진행과 무관하게 같은 시드의 같은 노드는 항상 같은 적.
//                  - 일반/엘리트 전투는 노드 depth 로 Easy/Hard 풀 분리 (맵 앞=Easy, 뒤=Hard).
//                    경계는 earlyDepthRatio. 티어는 각 EnemyDataSO.EncounterTier 로 판정.
//                  - Elite 티어 풀이 비면 미배정. Boss 풀이 비면 일반 풀 폴백.
//                  - 위상 생성(MapGenerator)과 내용 배정 분리. 가중치 추첨으로 적별 등장 빈도 조절.
// =================================================================

using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// 전투류 노드에 적을 배정하는 맵 후처리 패스.
/// 노드 타입(Battle/Elite/Boss/Test)에 대응하는 등급 풀에서 (시드 + 노드 ID) 해시로
/// 가중치 비례 결정론 추첨해 MapNode.EnemyId 에 기록한다.
/// </summary>
public static class EncounterAssigner
{
    /// <summary>
    /// 스테이지 적 풀(EnemyPoolSO)로 배정. 일반/엘리트 적은 EncounterTier 로 Easy/Hard 분리,
    /// 등급별 풀은 적별 가중치로 추첨한다. 같은 (seed, 맵)은 항상 같은 결과.
    /// </summary>
    public static void Assign(MapGraph map, EnemyPoolSO pool, int seed, float earlyDepthRatio = 0.4f)
    {
        if (map == null)
        {
            Debug.LogError("[EncounterAssigner] map 이 null 입니다. 배정 불가.");
            return;
        }
        if (pool == null)
        {
            Debug.LogError("[EncounterAssigner] EnemyPoolSO 가 null 입니다. 배정 불가.");
            return;
        }

        // 등급별 가중치 버킷 구성. 일반/엘리트는 각 적의 EncounterTier 로 Easy/Hard 분리.
        var buckets = new Buckets();
        FillByTier(pool.Normal, buckets.NormalEasy, buckets.NormalHard);
        FillByTier(pool.Elite, buckets.EliteEasy, buckets.EliteHard);
        FillValid(pool.Boss, buckets.Boss);
        FillValid(pool.Test, buckets.Test);

        AssignInternal(map, buckets, seed, earlyDepthRatio, poolLabel: pool.name);
    }

    /// <summary>
    /// 전역 풀(IReadOnlyList&lt;EnemyDataSO&gt;) 폴백 배정. 스테이지 풀 미지정 시 사용.
    /// 가중치는 모두 1(균등)로 간주하고, 등급·EncounterTier 로 버킷 분리한다.
    /// </summary>
    public static void Assign(MapGraph map, IReadOnlyList<EnemyDataSO> enemyPool, int seed,
        float earlyDepthRatio = 0.4f)
    {
        if (map == null)
        {
            Debug.LogError("[EncounterAssigner] map 이 null 입니다. 배정 불가.");
            return;
        }

        // 등급별 버킷 구성 (가중치 1). 일반/엘리트는 EncounterTier 로 Easy/Hard 분리.
        var buckets = new Buckets();
        if (enemyPool != null)
        {
            for (int i = 0; i < enemyPool.Count; i++)
            {
                EnemyDataSO so = enemyPool[i];
                if (so == null) continue;

                var w = new WeightedEnemy { Enemy = so, Weight = 1 };
                switch (so.Grade)
                {
                    case EEnemyGrade.Elite:
                        if (so.EncounterTier == EEncounterTier.Hard) buckets.EliteHard.Add(w);
                        else buckets.EliteEasy.Add(w);
                        break;
                    case EEnemyGrade.Boss: buckets.Boss.Add(w); break;
                    case EEnemyGrade.Test: buckets.Test.Add(w); break;
                    default:
                        if (so.EncounterTier == EEncounterTier.Hard) buckets.NormalHard.Add(w);
                        else buckets.NormalEasy.Add(w);
                        break;
                }
            }
        }

        AssignInternal(map, buckets, seed, earlyDepthRatio, poolLabel: "(전역 폴백)");
    }

    // ─────────────────────────────────────────────
    // 공통 배정 로직
    // ─────────────────────────────────────────────

    /// <summary>등급별 가중치 버킷 묶음.</summary>
    private sealed class Buckets
    {
        public readonly List<WeightedEnemy> NormalEasy = new List<WeightedEnemy>();
        public readonly List<WeightedEnemy> NormalHard = new List<WeightedEnemy>();
        public readonly List<WeightedEnemy> EliteEasy = new List<WeightedEnemy>();
        public readonly List<WeightedEnemy> EliteHard = new List<WeightedEnemy>();
        public readonly List<WeightedEnemy> Boss = new List<WeightedEnemy>();
        public readonly List<WeightedEnemy> Test = new List<WeightedEnemy>();
    }

    private static void AssignInternal(MapGraph map, Buckets b, int seed, float earlyDepthRatio,
        string poolLabel)
    {
        bool hasAny = b.NormalEasy.Count > 0 || b.NormalHard.Count > 0
            || b.EliteEasy.Count > 0 || b.EliteHard.Count > 0
            || b.Boss.Count > 0 || b.Test.Count > 0;
        if (!hasAny)
        {
            Debug.LogWarning($"[EncounterAssigner] 적 풀이 비어 있습니다({poolLabel}). 전 노드 미배정 (폴백 적 사용).");
            return;
        }

        // Easy/Hard 경계 depth: 맵 앞쪽 earlyDepthRatio 까지는 Easy. 최소 1행 Easy 보장.
        int easyThreshold = Mathf.Clamp(
            Mathf.CeilToInt(map.Depth * Mathf.Clamp01(earlyDepthRatio)), 1, map.Depth);

        int assigned = 0;
        foreach (MapNode node in map.Nodes)
        {
            List<WeightedEnemy> pool = SelectPool(node, easyThreshold, b);
            if (pool == null) continue;     // 비전투 노드.
            if (pool.Count == 0)
            {
                Debug.LogWarning($"[EncounterAssigner] {node.NodeType} 등급 풀이 비어 미배정: 노드 {node.Id}");
                continue;
            }

            int hash = Hash(seed, node.Id);
            EnemyDataSO picked = PickWeighted(pool, hash);
            if (picked == null) continue;

            node.EnemyId = picked.EnemyId;
            assigned++;
        }

#if UNITY_EDITOR || DEVELOPMENT_BUILD
        Debug.Log($"[EncounterAssigner] 적 배정 완료({poolLabel}) — {assigned}개 노드 " +
                  $"(풀: 일반Easy {b.NormalEasy.Count}/일반Hard {b.NormalHard.Count}/" +
                  $"엘리트Easy {b.EliteEasy.Count}/엘리트Hard {b.EliteHard.Count}/" +
                  $"보스 {b.Boss.Count}/테스트 {b.Test.Count}, easy경계 depth≤{easyThreshold})");
#endif
    }

    /// <summary>노드 → 추첨 풀 선택. 비전투 노드는 null. Boss 풀이 비면 일반 폴백.</summary>
    private static List<WeightedEnemy> SelectPool(MapNode node, int easyThreshold, Buckets b)
    {
        switch (node.NodeType)
        {
            case ENodeType.Battle:
                {
                    bool isEarly = node.Depth <= easyThreshold;
                    List<WeightedEnemy> primary = isEarly ? b.NormalEasy : b.NormalHard;
                    if (primary.Count > 0) return primary;
                    return isEarly ? b.NormalHard : b.NormalEasy; // 반대편 폴백
                }
            case ENodeType.Elite:
                return node.Depth <= easyThreshold ? b.EliteEasy : b.EliteHard;
            case ENodeType.Boss:
                return b.Boss.Count > 0 ? b.Boss : NormalFallback(b);
            case ENodeType.Test:
                return b.Test;
            default:
                return null; // 비전투 노드.
        }
    }

    /// <summary>일반 풀 폴백 — Easy 우선, 비면 Hard. (Boss 데이터 미비 시 사용)</summary>
    private static List<WeightedEnemy> NormalFallback(Buckets b)
    {
        return b.NormalEasy.Count > 0 ? b.NormalEasy : b.NormalHard;
    }

    /// <summary>적을 EncounterTier 로 Easy/Hard 버킷에 분류(null·null-적 제외).</summary>
    private static void FillByTier(IReadOnlyList<WeightedEnemy> source,
        List<WeightedEnemy> easy, List<WeightedEnemy> hard)
    {
        if (source == null) return;
        for (int i = 0; i < source.Count; i++)
        {
            WeightedEnemy w = source[i];
            if (w.Enemy == null) continue;
            if (w.Enemy.EncounterTier == EEncounterTier.Hard) hard.Add(w);
            else easy.Add(w);
        }
    }

    /// <summary>유효(적 non-null) 항목만 버킷에 복사.</summary>
    private static void FillValid(IReadOnlyList<WeightedEnemy> source, List<WeightedEnemy> dest)
    {
        if (source == null) return;
        for (int i = 0; i < source.Count; i++)
        {
            if (source[i].Enemy != null) dest.Add(source[i]);
        }
    }

    /// <summary>가중치 비례 결정론 추첨. Weight 는 최소 1 로 보정. 빈 풀이면 null.</summary>
    private static EnemyDataSO PickWeighted(List<WeightedEnemy> pool, int hash)
    {
        int total = 0;
        for (int i = 0; i < pool.Count; i++) total += Mathf.Max(1, pool[i].Weight);
        if (total <= 0) return null;

        int roll = (hash & 0x7FFFFFFF) % total;
        int acc = 0;
        for (int i = 0; i < pool.Count; i++)
        {
            acc += Mathf.Max(1, pool[i].Weight);
            if (roll < acc) return pool[i].Enemy;
        }
        return pool[pool.Count - 1].Enemy; // 부동 안전망.
    }

    /// <summary>
    /// (시드, 노드 ID) → 결정론적 정수 해시. 같은 입력은 항상 같은 출력 (런 재현성).
    /// splitmix 계열 믹싱. 힙 할당 없음.
    /// </summary>
    private static int Hash(int seed, int nodeId)
    {
        unchecked
        {
            uint x = (uint)seed * 2654435761u + (uint)nodeId * 2246822519u;
            x ^= x >> 15;
            x *= 2246822519u;
            x ^= x >> 13;
            return (int)x;
        }
    }
}
