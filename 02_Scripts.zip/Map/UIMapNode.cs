// =================================================================
// [스크립트 목적]  맵 노드 1칸의 UGUI 표현. 버튼 + 상태(현재/도달가능/방문) 시각화.
// [주요 변수]      - _button       : 노드 클릭 버튼
//                  - _iconImage    : 노드 타입 아이콘
//                  - _currentMark  : 현재 위치 강조
//                  - _reachableMark: 이동 가능 강조
// [의존 관계]      - UICard 류와 동급의 단순 뷰 컴포넌트(UIBase 아님 — 자식 요소)
//                  - UIMap 이 생성·배치·상태 갱신, 클릭은 콜백으로 UIMap 에 전달
//                  - UIButton(같은 오브젝트): 호버/누름 스케일 피드백. 클리어 펄스 중엔 잠시 끔
// [설계 노트]      - 에셋 MapLocationDot 을 UGUI 로 이식. Update 폴링 대신
//                    UIMap 이 상태 변경 시점에 SetState 를 호출(이벤트 주도 → GC·연산 절감).
//                  - 노드 타입별 아이콘은 UIMap 이 매핑해 주입(이 컴포넌트는 표시만).
//                  - 풀링 미사용: 맵은 런당 1회 생성이라 빈도 낮음(UIBase 주석의 판단과 일관).
//                  - 알파는 놓친 노드(지나쳐서 못 가는)만 0.7 로 디밍. 나머지는 밝게 유지.
//                  - 도달 가능 마크는 숨쉬듯 스케일 펄스. 노드 본체가 아닌 마크만
//                    흔들어 UIButton 호버 스케일과의 트윈 충돌을 피한다.
// =================================================================

using System;
using System.Threading;
using Cysharp.Threading.Tasks;
using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// 맵의 노드 1칸 UI. 타입 아이콘과 상태(현재/도달가능 마크, 놓침 디밍)를 표시하고,
/// 클릭 시 자신의 노드 ID 를 콜백으로 알린다. 상태는 UIMap 이 갱신 시점에 주입한다.
/// </summary>
public sealed class UIMapNode : MonoBehaviour
{
    [Header("표시")]
    [Tooltip("노드 클릭 버튼")]
    [SerializeField] private Button _button;

    [Tooltip("노드 타입 아이콘 이미지")]
    [SerializeField] private Image _iconImage;

    [Tooltip("노드 배경/원형 이미지 (알파 조절 대상)")]
    [SerializeField] private Image _circleImage;

    [Header("상태 강조")]
    [Tooltip("현재 위치한 노드 표시 (선택)")]
    [SerializeField] private GameObject _currentMark;

    [Tooltip("지금 이동 가능한 노드 표시 (선택)")]
    [SerializeField] private GameObject _reachableMark;

    /// <summary>이 노드의 런 전체 고유 ID (stageIndex*1,000,000 + depth*100 + index).</summary>
    public int NodeId { get; private set; }

    // 클릭 통지 (UIMap 이 구독). 인자는 노드 ID.
    private Action<int> _onClicked;
    private Vector3 _initialScale = Vector3.one;

    // 같은 오브젝트의 호버/누름 스케일 피드백. 클리어 펄스가 스케일을 직접 제어하는
    // 동안에는 꺼서 트윈 충돌을 막는다(둘 다 같은 Transform 을 만짐).
    private UIButton _hoverFeedback;

    // 도달 가능 마크 펄스 루프 제어. null 이면 정지 상태.
    private CancellationTokenSource _pulseCts;
    private Vector3 _reachableMarkBaseScale = Vector3.one;

    /// <summary>
    /// 노드 1칸 초기화 (UIMap 이 생성 직후 1회 호출).
    /// </summary>
    /// <param name="nodeId">노드 ID.</param>
    /// <param name="icon">타입 아이콘 (없으면 null → 아이콘 숨김).</param>
    /// <param name="onClicked">클릭 콜백 (노드 ID 전달).</param>
    public void Setup(int nodeId, Sprite icon, Action<int> onClicked)
    {
        NodeId = nodeId;
        _onClicked = onClicked;
        _initialScale = transform.localScale;
        _hoverFeedback = GetComponent<UIButton>();

        if (_reachableMark != null)
            _reachableMarkBaseScale = _reachableMark.transform.localScale;

        if (_iconImage != null)
        {
            _iconImage.sprite = icon;
            _iconImage.enabled = icon != null;
        }

        if (_button != null)
        {
            _button.onClick.RemoveAllListeners();
            _button.onClick.AddListener(HandleClick);
        }

        SetState(isCurrent: false, isReachable: false, isMissed: false);
    }

    public async UniTask PlayClearPulseAsync(CancellationToken token)
    {
        if (_button != null)
            _button.interactable = false;

        // 펄스 동안 호버 피드백 비활성 (UIButton.OnDisable 이 트윈 정리·스케일 복귀까지 처리).
        if (_hoverFeedback != null)
            _hoverFeedback.enabled = false;

        try
        {
            const float pulseDuration = 0.5f;
            const float holdDuration = 0.5f;
            const float scaleAmount = 1.18f;
            float elapsed = 0f;
            Vector3 from = _initialScale;
            Vector3 peak = _initialScale * scaleAmount;

            while (elapsed < pulseDuration)
            {
                elapsed += Time.unscaledDeltaTime;
                float t = Mathf.Clamp01(elapsed / pulseDuration);
                float pulse = Mathf.Sin(t * Mathf.PI);
                transform.localScale = Vector3.Lerp(from, peak, pulse);

                if (_circleImage != null)
                {
                    Color color = _circleImage.color;
                    color.a = Mathf.Lerp(1f, 0.35f, pulse);
                    _circleImage.color = color;
                }

                await UniTask.Yield(token);
            }

            transform.localScale = _initialScale;
            // 펄스가 끝나도 이 노드는 아직 '현재 위치'이므로 밝기 유지 (알파 규칙과 일치).
            if (_circleImage != null)
            {
                Color color = _circleImage.color;
                color.a = 1f;
                _circleImage.color = color;
            }

            // 완료 상태를 잠시 보여준 뒤 다음 화면 페이드 아웃으로 넘어간다.
            await UniTask.Delay(
                TimeSpan.FromSeconds(holdDuration),
                DelayType.UnscaledDeltaTime,
                cancellationToken: token);
        }
        finally
        {
            if (_hoverFeedback != null)
                _hoverFeedback.enabled = true;
        }
    }

    /// <summary>
    /// 노드 상태 갱신 (UIMap 이 맵 표시/이동마다 호출).
    /// 현재/도달가능 강조를 켜고, 놓친 노드만 흐리게 한다.
    /// </summary>
    /// <param name="isMissed">지나쳐서 이번 런에 영영 갈 수 없게 된 노드.</param>
    public void SetState(bool isCurrent, bool isReachable, bool isMissed)
    {
        if (_currentMark != null && _currentMark.activeSelf != isCurrent)
            _currentMark.SetActive(isCurrent);

        if (_reachableMark != null && _reachableMark.activeSelf != isReachable)
            _reachableMark.SetActive(isReachable);

        SetReachablePulse(isReachable);

        // 이동 가능한 노드만 누를 수 있게.
        if (_button != null)
            _button.interactable = isReachable;

        // 놓친 노드만 흐리게, 나머지는 전부 밝게.
        float alpha = isMissed ? 0.7f : 1f;
        ApplyAlpha(_circleImage, alpha);
        ApplyAlpha(_iconImage, alpha);
    }

    private static void ApplyAlpha(Image image, float alpha)
    {
        if (image == null) return;
        Color c = image.color;
        if (!Mathf.Approximately(c.a, alpha))
            image.color = new Color(c.r, c.g, c.b, alpha);
    }

    // ── 도달 가능 펄스 ──────────────────────────────────────

    /// <summary>도달 가능 마크의 숨쉬기 펄스를 켜거나 끈다 (상태 변화 시에만 시작/정지).</summary>
    private void SetReachablePulse(bool on)
    {
        if (_reachableMark == null) return;

        bool running = _pulseCts != null;
        if (on == running) return;

        if (on)
        {
            _pulseCts = new CancellationTokenSource();
            PulseReachableMarkAsync(_pulseCts.Token).Forget();
        }
        else
        {
            StopReachablePulse();
        }
    }

    private void StopReachablePulse()
    {
        if (_pulseCts == null) return;
        _pulseCts.Cancel();
        _pulseCts.Dispose();
        _pulseCts = null;

        if (_reachableMark != null)
            _reachableMark.transform.localScale = _reachableMarkBaseScale;
    }

    /// <summary>
    /// 도달 가능 마크를 사인 곡선으로 키웠다 줄였다 반복한다.
    /// 움직임은 주변시로도 인지되므로 "누를 수 있는 노드"가 즉시 눈에 띈다.
    /// </summary>
    private async UniTaskVoid PulseReachableMarkAsync(CancellationToken token)
    {
        const float period = 1.2f;      // 한 번 숨쉬는 데 걸리는 시간(초)
        const float amount = 0.15f;     // 최대 확대 비율

        float elapsed = 0f;
        while (!token.IsCancellationRequested)
        {
            elapsed += Time.unscaledDeltaTime;
            float wave = 0.5f + 0.5f * Mathf.Sin(elapsed / period * Mathf.PI * 2f);
            _reachableMark.transform.localScale = _reachableMarkBaseScale * (1f + amount * wave);

            await UniTask.Yield(token);
        }
    }

    private void HandleClick()
    {
        _onClicked?.Invoke(NodeId);
    }

    private void OnDisable()
    {
        // 화면이 닫혀도 PlayerLoop 기반 UniTask 는 계속 돌므로 여기서 정지.
        // 다시 열리면 UIMap 의 RefreshStates → SetState 가 재시작한다.
        StopReachablePulse();
    }

    private void OnDestroy()
    {
        if (_pulseCts != null)
        {
            _pulseCts.Cancel();
            _pulseCts.Dispose();
            _pulseCts = null;
        }
        if (_button != null) _button.onClick.RemoveAllListeners();
        _onClicked = null;
    }
}
