// =================================================================
// [스크립트 목적]  노드맵 화면(UIBase). 생성된 맵을 세로(아래→위)로 그리고,
//                 노드 클릭을 InGameController.SelectNode 로 연결한다.
// [주요 변수]      - _nodePrefab/_linePrefab : 노드·경로 자식 프리팹
//                  - _contentRoot            : 노드/경로가 배치될 ScrollRect content
//                  - _mapBg                  : content 자식인 두루마리 배경(스크롤 추종)
//                  - _typeIcons              : 노드 타입별 아이콘/표시 이름 매핑
//                  - _legend                 : 범례 패널 (UIMapLegend, _typeIcons 를 넘겨 표시)
//                  - _rowSpacing/_indexSpacing: 레이아웃 간격
// [의존 관계]      - UIBase / UIManager(열기) / EventManager(OnMapPresented 구독)
//                  - InGameController(SelectNode) / RunContext(맵·현재 노드 조회)
//                  - UIMapNode(노드 1칸) / MapGraph·MapNode
// [배치]           UIManager 로 여는 Screen UI. Addressable 키 = "UIMap"(타입명)
// [설계 노트]      - 에셋 MapViewer 의 레이아웃 수식을 UGUI 세로 배치로 이식:
//                    depth(행)는 Y축(아래=depth1 → 위=보스), index 는 X축으로 분산.
//                    노드별 시드로 위치를 살짝 흔들어 기계적 격자 느낌을 줄인다(에셋 동일).
//                  - 에셋의 카메라·드래그 스크롤은 제외 — ScrollRect 세로 스크롤로 충분.
//                    단, 스테이지 첫 진입 시에는 보스(맨 위)→시작 지점(맨 아래)으로
//                    훑어내리는 진입 연출을 1회 재생한다 (클릭/터치로 건너뛰기 가능).
//                  - 상태 갱신은 OnMapPresented 시점에 1회(폴링 없음). 현재/도달 가능/
//                    놓침(지나쳐서 못 가는 노드)을 RunContext 기준으로 계산해 UIMapNode 에 주입.
//                  - 노드/경로는 스테이지당 1회 생성. 같은 맵 재표시는 상태만 갱신하고,
//                    스테이지 전환으로 맵 그래프가 바뀌면 재빌드한다(EnsureMapBuilt).
//                  - IsPeek(읽기 전용 미리보기): 상단 바 지도 버튼으로 전투·상점 등
//                    도중에 열람할 때 노드 클릭을 무시한다 (슬더스식 지도 열람).
// =================================================================

using System.Collections.Generic;
using System.Threading;
using Cysharp.Threading.Tasks;
using TMPro;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.UI;

/// <summary>
/// 노드맵 화면. 생성된 맵을 세로로 렌더하고 노드 클릭을 런 컨트롤러로 연결한다.
/// 맵이 표시될 때마다(OnMapPresented) 현재/도달가능/방문 상태를 갱신한다.
/// </summary>
public sealed class UIMap : UIBase
{
    [Header("프리팹")]
    [Tooltip("노드 1칸 프리팹 (UIMapNode 부착)")]
    [SerializeField] private UIMapNode _nodePrefab;

    [Tooltip("경로(선) 프리팹 (UI Image. 두 노드를 잇는 막대)")]
    [SerializeField] private RectTransform _linePrefab;

    [Header("배치 루트")]
    [Tooltip("노드/경로가 놓일 ScrollRect")]
    [SerializeField] private ScrollRect _scrollRect;

    [Tooltip("노드/경로가 놓일 ScrollRect 의 content RectTransform")]
    [SerializeField] private RectTransform _contentRoot;

    [Tooltip("content 자식인 두루마리 배경. 스크롤을 따라 움직이며, 맵 재빌드 시 삭제에서 제외")]
    [SerializeField] private RectTransform _mapBg;

    [Tooltip("현재 노드를 뷰포트 하단에서 얼마나 띄울지(뷰포트 높이 대비 비율). 0=완전 바닥")]
    [SerializeField] private float _currentNodeBottomMargin = 0.15f;

    [Header("레이아웃")]
    [Tooltip("행(depth) 사이 세로 간격(px)")]
    [SerializeField] private float _rowSpacing = 200f;

    [Tooltip("같은 행 내 노드 사이 가로 간격(px)")]
    [SerializeField] private float _indexSpacing = 160f;

    [Tooltip("아래 여백(첫 행 Y 시작 오프셋, px). 두루마리 말린 봉 렌더 크기(border/PPU배율, 현재 약 260px)보다 크게")]
    [SerializeField] private float _bottomPadding = 350f;

    [Header("스테이지 진입 연출")]
    [Tooltip("스테이지 첫 진입 시 보스(맨 위)부터 시작 지점(맨 아래)까지 훑어내리는 연출 사용 여부")]
    [SerializeField] private bool _playIntroSweep = true;

    [Tooltip("연출 시작 시 보스 위치에서 잠시 머무는 시간(초)")]
    [SerializeField] private float _introHoldDuration = 0.6f;

    [Tooltip("맨 위에서 맨 아래까지 내려오는 데 걸리는 시간(초)")]
    [SerializeField] private float _introScrollDuration = 1.8f;

    [Header("노드 타입 아이콘")]
    [Tooltip("노드 타입별 아이콘/표시 이름. 아이콘 없으면 미표시, 이름 없으면 범례 제외")]
    [SerializeField] private NodeTypeIcon[] _typeIcons;

    [Header("범례")]
    [Tooltip("노드 타입 범례 패널 (선택). _typeIcons 목록을 넘겨 행을 생성한다")]
    [SerializeField] private UIMapLegend _legend;

    [Header("미리보기")]
    [Tooltip("상단 정보 바에서 연 읽기 전용 지도일 때만 표시하는 닫기 버튼")]
    [SerializeField] private Button _closeButton;

    [Tooltip("닫기 버튼 라벨 텍스트. 비워두면 _closeButton 자식에서 자동으로 찾는다")]
    [SerializeField] private TMP_Text _closeButtonText;

    // 생성된 노드 UI (노드 ID → UI). 상태 갱신·재생성 방지용.
    private readonly Dictionary<int, UIMapNode> _nodeViews = new Dictionary<int, UIMapNode>();

    // 타입 → 아이콘 빠른 조회 (Setup 시 1회 구축).
    private readonly Dictionary<ENodeType, Sprite> _iconLookup = new Dictionary<ENodeType, Sprite>();

    private IDisposableEvent _presentedSub;
    private bool _built;

    // 스테이지 첫 진입 연출 대기 여부. 맵 (재)빌드 시 세우고, 첫 표시에서 1회 소비한다.
    private bool _introPending;
    private Coroutine _introRoutine;

    /// <summary>
    /// 읽기 전용 미리보기로 열렸는지 (상단 바 지도 버튼 — 전투·상점 등 도중 열람).
    /// true 면 노드 클릭을 무시한다. 노드 선택용 오픈(PresentMap)이 false 로 되돌린다.
    /// </summary>
    public bool IsPeek { get; private set; }

    // BuildMap 당시의 맵 참조. 새 런(다른 MapGraph)이면 재빌드 판단용.
    private MapGraph _builtMap;

    /// <summary>타입별 아이콘/표시 이름 매핑 (인스펙터 노출용). 범례와 노드 아이콘의 단일 출처.</summary>
    [System.Serializable]
    public struct NodeTypeIcon
    {
        public ENodeType Type;
        public Sprite Icon;

        [Tooltip("범례에 표시할 이름. 비우면 범례에서 제외")]
        public string Label;
    }

    // ── 생명주기 ────────────────────────────────────────────

    protected override void Init()
    {
        if (_closeButton != null)
            _closeButton.onClick.AddListener(HandleCloseClicked);

        // 인스펙터 미할당 시 버튼 자식에서 라벨 1회 탐색 (프리팹 재연결 없이 동작)
        if (_closeButtonText == null && _closeButton != null)
            _closeButtonText = _closeButton.GetComponentInChildren<TMP_Text>(includeInactive: true);

        RefreshCloseButton();

        // 타입→아이콘 조회 테이블 1회 구축.
        _iconLookup.Clear();
        if (_typeIcons != null)
        {
            foreach (NodeTypeIcon ti in _typeIcons)
            {
                if (ti.Icon != null) _iconLookup[ti.Type] = ti.Icon;
            }
        }

        BuildLegend();
    }

    /// <summary>
    /// _typeIcons 를 타입 enum 값 순으로 정렬해 범례에 넘긴다 (1회).
    /// 아이콘/이름 데이터는 인스펙터 _typeIcons 가 단일 출처.
    /// </summary>
    private void BuildLegend()
    {
        if (_legend == null || _typeIcons == null) return;

        var sorted = new List<NodeTypeIcon>(_typeIcons);
        sorted.Sort((a, b) => a.Type.CompareTo(b.Type));

        var entries = new List<UIMapLegend.Entry>(sorted.Count);
        foreach (NodeTypeIcon ti in sorted)
            entries.Add(new UIMapLegend.Entry(ti.Icon, ti.Label));

        _legend.Build(entries);
    }

    protected override void Setup()
    {
        // 맵 표시 이벤트 구독 (열릴 때마다, 중복 방지).
        _presentedSub?.Dispose();
        if (EventManager.HasInstance)
        {
            _presentedSub = EventManager.Instance.Subscribe<OnMapPresented>(OnMapPresented);
        }

        // 최초 1회, 또는 맵이 바뀐 경우(새 런) 노드/경로 생성.
        EnsureMapBuilt();

        // 현재 상태로 즉시 1회 갱신 (이벤트보다 먼저 열릴 수 있으므로).
        RefreshStates();
    }

    /// <summary>
    /// 다른 UI(게임오버 팝업 등)가 닫혀 다시 포커스 얻을 때 호출.
    /// 재시작으로 맵이 닫히지 않고 재사용되는 경우 Setup 이 안 불리므로,
    /// 여기서도 맵 교체를 검사해 재빌드·갱신한다(갱신 누락 방지).
    /// </summary>
    public override void OnFocus()
    {
        if (EnsureMapBuilt())
            RefreshStates();
    }

    public override void OnLocalize()
    {
        base.OnLocalize();
        _legend?.OnLocalize();

        if (_closeButtonText != null)
            _closeButtonText.text = Localize(LocalizationKeys.Common.Back);
    }

    private static string Localize(string key)
    {
        return LocalizationManager.HasInstance
            ? LocalizationManager.Instance.Get(key)
            : key;
    }

    /// <summary>
    /// 최초 1회, 또는 맵이 바뀐 경우(새 런) 노드/경로를 생성한다.
    /// UIMap 은 Screen UI라 죽어도 캐시·재사용되므로, 맵 교체 시 재빌드 필요.
    /// </summary>
    /// <returns>이번에 (재)빌드했으면 true.</returns>
    private bool EnsureMapBuilt()
    {
        RunContext run = GetRun();
        bool mapChanged = run != null && run.Map != _builtMap;
        if (!_built || mapChanged)
        {
            if (mapChanged) ClearMap();
            BuildMap();
            return true;
        }
        return false;
    }

    public override void OnClose()
    {
        CancelIntro();
        _presentedSub?.Dispose();
        _presentedSub = null;
        IsPeek = false;
        RefreshCloseButton();
    }

    /// <summary>열린 직후 호출해 미리보기(읽기 전용) 여부를 지정한다.</summary>
    public void SetPeekMode(bool peek)
    {
        IsPeek = peek;
        RefreshCloseButton();
    }

    private void HandleCloseClicked()
    {
        // 노드 선택용 지도에는 닫기 버튼 자체가 비활성이다. 미리보기만 상단 바 상태까지 함께 정리한다.
        if (IsPeek && InGameController.HasInstance)
            InGameController.Instance.CloseMapPeek();
    }

    private void RefreshCloseButton()
    {
        if (_closeButton != null)
            _closeButton.gameObject.SetActive(IsPeek);
    }

    private void OnDestroy()
    {
        if (_closeButton != null)
            _closeButton.onClick.RemoveListener(HandleCloseClicked);
        _presentedSub?.Dispose();
    }

    // ── 맵 생성 ─────────────────────────────────────────────

    /// <summary>
    /// 런 컨텍스트의 맵 그래프를 읽어 노드와 경로를 생성·배치한다(최초 1회).
    /// depth 를 Y(아래→위), index 를 X(중앙 정렬 분산)로 배치한다.
    /// </summary>
    private void BuildMap()
    {
        RunContext run = GetRun();
        if (run == null || run.Map == null)
        {
            Debug.LogError("[UIMap] 런/맵이 없습니다. 맵을 그릴 수 없습니다.");
            return;
        }
        if (_nodePrefab == null || _contentRoot == null)
        {
            Debug.LogError("[UIMap] 노드 프리팹 또는 content 루트가 비어 있습니다.");
            return;
        }

        MapGraph map = run.Map;

        // content 높이 확보 (전체 depth 가 스크롤되도록).
        float contentHeight = _bottomPadding * 2f + (map.Depth - 1) * _rowSpacing;
        _contentRoot.sizeDelta = new Vector2(_contentRoot.sizeDelta.x, contentHeight);

        // 두루마리 배경을 content 세로 길이에 맞춤 (90도 회전 상태라 sizeDelta.x 가 세로 길이).
        if (_mapBg != null)
            _mapBg.sizeDelta = new Vector2(contentHeight, _mapBg.sizeDelta.y);

        // 1) 경로(선) 먼저 생성 → 노드 뒤에 깔리도록.
        if (_linePrefab != null)
        {
            foreach (MapNode node in map.Nodes)
            {
                Vector2 from = GetNodePosition(map, node);
                foreach (int adjId in node.Adjacency)
                {
                    MapNode adj = map.GetNode(adjId);
                    if (adj == null) continue;
                    CreateLine(from, GetNodePosition(map, adj));
                }
            }
        }

        // 2) 노드 생성.
        foreach (MapNode node in map.Nodes)
        {
            UIMapNode view = Instantiate(_nodePrefab, _contentRoot);
            view.GetComponent<RectTransform>().anchoredPosition = GetNodePosition(map, node);

            Sprite icon = _iconLookup.TryGetValue(node.NodeType, out Sprite s) ? s : null;
            view.Setup(node.Id, icon, OnNodeClicked);

            _nodeViews[node.Id] = view;
        }

        _built = true;
        _builtMap = map;
        _introPending = true; // 새 스테이지 맵 — 첫 표시에서 진입 연출 재생
    }

    /// <summary>생성된 노드·경로 자식을 모두 제거하고 빌드 상태를 초기화한다(맵 교체 시).</summary>
    private void ClearMap()
    {
        CancelIntro(); // 연출 중 재빌드되면 잠긴 ScrollRect 가 남지 않게
        if (_contentRoot != null)
        {
            for (int i = _contentRoot.childCount - 1; i >= 0; i--)
            {
                Transform child = _contentRoot.GetChild(i);
                if (_mapBg != null && child == _mapBg) continue; // 두루마리 배경은 유지
                Destroy(child.gameObject);
            }
        }
        _nodeViews.Clear();
        _built = false;
        _builtMap = null;
    }

    /// <summary>
    /// 노드의 화면 좌표 계산. depth → Y(아래에서 위로), index → X(행 중앙 기준 분산).
    /// 노드 시드로 위치를 소폭 흔들어 격자 느낌을 줄인다(에셋 MapViewer 동일 아이디어).
    /// </summary>
    private Vector2 GetNodePosition(MapGraph map, MapNode node)
    {
        int width = map.GetDepthWidth(node.Depth);

        // X: 행 노드들을 0 중심으로 대칭 배치.
        float xOffset = (width - 1) * 0.5f;
        float x = (node.Index - xOffset) * _indexSpacing;

        // Y: depth 1 이 맨 아래(_bottomPadding), 위로 갈수록 증가.
        float y = _bottomPadding + (node.Depth - 1) * _rowSpacing;

        // 노드 시드로 약간의 흔들기 (결정론적 — 같은 맵은 같은 위치).
        var rand = new System.Random(node.Seed);
        float jitterX = (float)(rand.NextDouble() - 0.5) * _indexSpacing * 0.25f;
        float jitterY = (float)(rand.NextDouble() - 0.5) * _rowSpacing * 0.15f;

        return new Vector2(x + jitterX, y + jitterY);
    }

    /// <summary>두 점을 잇는 경로 막대 1개 생성 (회전·길이 계산).</summary>
    private void CreateLine(Vector2 from, Vector2 to)
    {
        RectTransform line = Instantiate(_linePrefab, _contentRoot);
        Vector2 delta = to - from;
        float length = delta.magnitude;
        float angle = Mathf.Atan2(delta.y, delta.x) * Mathf.Rad2Deg;

        line.anchoredPosition = from + delta * 0.5f; // 중점에 배치
        line.sizeDelta = new Vector2(length, line.sizeDelta.y); // 길이만 늘림(두께 유지)
        line.localRotation = Quaternion.Euler(0f, 0f, angle);
    }

    // ── 상태 갱신 ───────────────────────────────────────────

    private void OnMapPresented(OnMapPresented evt)
    {
        // 스테이지 전환으로 맵 그래프가 교체됐으면 재빌드(멀티 스테이지 대응).
        // 이미 열려 있는 UIMap은 Setup/OnFocus가 확실히 불리지 않으므로 여기서 교체를 감지한다.
        EnsureMapBuilt();
        RefreshStates();
    }

    /// <summary>
    /// 모든 노드의 현재/도달가능/놓침 상태를 런 컨텍스트 기준으로 갱신한다.
    /// </summary>
    private void RefreshStates()
    {
        RunContext run = GetRun();
        if (run == null || run.Map == null) return;

        // 도달 가능 노드 ID 집합 (이번에 누를 수 있는 후보).
        var reachable = new HashSet<int>();
        foreach (MapNode n in run.GetReachableNodes())
            reachable.Add(n.Id);

        int currentId = run.CurrentNodeId;

        // 비활성 판정 기준 depth. 현재 depth 이하에서 현재/도달 가능이 아닌 노드는
        // 이미 지나간 노드까지 포함해 더 이상 선택할 수 없으므로 디밍한다.
        MapNode currentNode = run.Map.GetNode(currentId);
        int currentDepth = currentNode != null ? currentNode.Depth : 0;

        foreach (KeyValuePair<int, UIMapNode> pair in _nodeViews)
        {
            int id = pair.Key;
            MapNode node = run.Map.GetNode(id);
            bool isCurrent = id == currentId;
            bool isReachable = reachable.Contains(id);
            bool isInactivePast = !isCurrent
                                  && !isReachable
                                  && node != null
                                  && node.Depth <= currentDepth;

            pair.Value.SetState(isCurrent, isReachable, isInactivePast);
        }

        // 현재 노드가 뷰포트 하단쯤에 보이도록 스크롤 (맵 열릴 때마다).
        ScrollToCurrent(currentId);
    }

    /// <summary>
    /// 현재 노드를 뷰포트 하단(완전 바닥은 아님)에 오도록 세로 스크롤한다.
    /// 레이아웃 직후일 수 있어 한 프레임 뒤에 적용한다.
    /// </summary>
    private void ScrollToCurrent(int currentId)
    {
        if (_scrollRect == null || _contentRoot == null) return;
        if (_introRoutine != null) return; // 진입 연출 중 — 다른 스크롤 지시가 연출을 끊지 않게

        // 현재 노드가 없으면(미진입 = 새 스테이지 직후) 시작 지점인 맨 아래부터 보이게.
        // 이전 스테이지에서 올라간 스크롤 위치가 남는 문제 방지.
        if (!_nodeViews.TryGetValue(currentId, out UIMapNode view) || view == null)
        {
            // 진입 연출 대기 중이면 보스(맨 위)에 멈춰만 둔다 — 맵은 스테이지 안내(Notice)
            // 뒤에서 미리 표시되므로 여기서 연출을 시작하면 안내에 가려 보이지 않는다.
            // 실제 재생은 안내가 걷힌 뒤 컨트롤러가 PlayIntroIfPending 으로 트리거한다.
            if (_introPending && _playIntroSweep)
            {
                StartCoroutine(SnapToTopNextFrame());
                return;
            }
            _introPending = false;
            StartCoroutine(ScrollToBottomNextFrame());
            return;
        }

        _introPending = false; // 이미 진입한 맵 — 연출 없이 소비
        StartCoroutine(ScrollToCurrentNextFrame(view.GetComponent<RectTransform>()));
    }

    private System.Collections.IEnumerator ScrollToBottomNextFrame()
    {
        yield return null; // 레이아웃 확정 대기
        if (_scrollRect != null)
            _scrollRect.verticalNormalizedPosition = 0f; // 0 = 바닥
    }

    private System.Collections.IEnumerator SnapToTopNextFrame()
    {
        yield return null; // 레이아웃 확정 대기
        if (_scrollRect != null)
            _scrollRect.verticalNormalizedPosition = 1f; // 1 = 맨 위(보스)
    }

    /// <summary>
    /// 스테이지 첫 진입 연출이 대기 중이면 재생한다(보스→시작 지점 훑어내리기).
    /// 스테이지 안내(Notice)가 걷혀 맵이 실제로 보이는 시점에 컨트롤러가 호출한다.
    /// 연출 여부와 무관하게, 이 호출 흐름이 끝나면 OnMapRevealed 를 발행해
    /// 맵이 눈에 보이게 됐음을 통지한다(튜토리얼 등 관전자용).
    /// </summary>
    public void PlayIntroIfPending()
    {
        if (_introRoutine != null) return; // 이미 재생 중 — 종료 시점에 공개 통지됨

        if (_introPending && _playIntroSweep && isActiveAndEnabled)
        {
            _introPending = false;
            _introRoutine = StartCoroutine(PlayIntroSweep()); // 공개 통지는 연출 종료 시
            return;
        }

        // 연출 없이 표시되는 경우(연출 꺼짐 등)도 공개 통지는 보장한다.
        _introPending = false;
        PublishMapRevealed();
    }

    /// <summary>맵이 실제로 플레이어에게 보이게 됐음을 통지 (튜토리얼 등 관전자용).</summary>
    private static void PublishMapRevealed()
    {
        if (EventManager.HasInstance)
            EventManager.Instance.Publish(new OnMapRevealed());
    }

    /// <summary>
    /// 스테이지 첫 진입 연출: 보스(맨 위)에서 잠시 머문 뒤 시작 지점(맨 아래)까지
    /// 부드럽게 스크롤한다. 연출 중 드래그 충돌 방지를 위해 ScrollRect 를 잠그고,
    /// 화면을 누르면 즉시 맨 아래로 건너뛴다.
    /// </summary>
    private System.Collections.IEnumerator PlayIntroSweep()
    {
        yield return null; // 레이아웃 확정 대기

        // 스크롤할 거리가 없으면(전체가 한 화면에 보임) 연출 생략.
        float scrollable = _contentRoot.rect.height - _scrollRect.viewport.rect.height;
        if (scrollable <= 0f)
        {
            _scrollRect.verticalNormalizedPosition = 0f;
            _introRoutine = null;
            PublishMapRevealed();
            yield break;
        }

        _scrollRect.enabled = false;
        _scrollRect.verticalNormalizedPosition = 1f; // 1 = 맨 위(보스)

        bool skip = false;

        // 보스 확인 시간.
        float timer = 0f;
        while (timer < _introHoldDuration && !skip)
        {
            timer += Time.unscaledDeltaTime;
            skip = IsIntroSkipPressed();
            yield return null;
        }

        // 위→아래 스크롤 (smoothstep 이징).
        timer = 0f;
        while (timer < _introScrollDuration && !skip)
        {
            timer += Time.unscaledDeltaTime;
            float p = Mathf.Clamp01(timer / _introScrollDuration);
            p = p * p * (3f - 2f * p);
            _scrollRect.verticalNormalizedPosition = 1f - p;
            skip = IsIntroSkipPressed();
            yield return null;
        }

        _scrollRect.verticalNormalizedPosition = 0f;
        _scrollRect.enabled = true;
        _introRoutine = null;
        PublishMapRevealed();
    }

    /// <summary>연출 건너뛰기 입력(클릭/터치) 감지.</summary>
    private static bool IsIntroSkipPressed()
    {
        if (Mouse.current != null && Mouse.current.leftButton.wasPressedThisFrame) return true;
        if (Touchscreen.current != null && Touchscreen.current.primaryTouch.press.wasPressedThisFrame) return true;
        return false;
    }

    /// <summary>진입 연출 중단 + ScrollRect 잠금 해제 (닫기/재빌드/비활성 시 안전장치).</summary>
    private void CancelIntro()
    {
        if (_introRoutine != null)
        {
            StopCoroutine(_introRoutine);
            _introRoutine = null;
        }
        if (_scrollRect != null) _scrollRect.enabled = true;
    }

    private void OnDisable()
    {
        // 비활성화되면 코루틴이 강제 종료되므로 ScrollRect 잠금이 남지 않게 정리.
        CancelIntro();
    }

    public async UniTask PlayCurrentNodeClearAsync(CancellationToken token)
    {
        RefreshStates();

        RunContext run = GetRun();
        if (run == null) return;
        if (!_nodeViews.TryGetValue(run.CurrentNodeId, out UIMapNode view) || view == null) return;

        ScrollToCurrent(run.CurrentNodeId);
        await UniTask.DelayFrame(1, cancellationToken: token);
        await view.PlayClearPulseAsync(token);
    }

    private System.Collections.IEnumerator ScrollToCurrentNextFrame(RectTransform target)
    {
        yield return null; // 레이아웃 확정 대기

        float viewportHeight = _scrollRect.viewport.rect.height;
        float contentHeight = _contentRoot.rect.height;
        float scrollable = contentHeight - viewportHeight;
        if (scrollable <= 0f)
        {
            _scrollRect.verticalNormalizedPosition = 0f; // 스크롤 불필요(전체가 보임)
            yield break;
        }

        // content 하단 기준 노드 Y(양수=위). 노드를 뷰포트 하단에서 margin 만큼 띄운 위치에.
        float nodeY = target.anchoredPosition.y;
        float desiredBottom = nodeY - _currentNodeBottomMargin * viewportHeight;

        // 뷰포트 하단이 content 의 desiredBottom 에 오도록 정규화 위치 계산(0=바닥,1=상단).
        float normalized = desiredBottom / scrollable;
        _scrollRect.verticalNormalizedPosition = Mathf.Clamp01(normalized);
    }

    // ── 입력 ────────────────────────────────────────────────

    /// <summary>노드 클릭 → 런 컨트롤러에 선택 위임. 닫는 시점은 전환 흐름이 결정한다.</summary>
    private void OnNodeClicked(int nodeId)
    {
        // 읽기 전용 미리보기 — 열람만 허용, 노드 선택(이동) 불가.
        if (IsPeek) return;

        if (!InGameController.HasInstance)
        {
            Debug.LogError("[UIMap] InGameController 가 없습니다. 노드 선택 불가.");
            return;
        }

        // 선택 위임 — 전투/이벤트 진입과 맵 비활성화 시점은 컨트롤러가 처리.
        InGameController.Instance.SelectNode(nodeId);
    }

    // ── 내부 ────────────────────────────────────────────────

    private RunContext GetRun()
    {
        return InGameController.HasInstance ? InGameController.Instance.CurrentRun : null;
    }
}
