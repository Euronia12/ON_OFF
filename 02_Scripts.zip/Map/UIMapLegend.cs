﻿// =================================================================
// [스크립트 목적]  맵 화면 범례 패널. 노드 타입 아이콘 + 이름 행을 나열해
//                 각 노드가 무엇을 뜻하는지 알려준다.
// [주요 변수]      - _rowsRoot    : 행이 쌓일 부모 (VerticalLayoutGroup)
//                  - _rowTemplate : 행 1개 템플릿 (아이콘 Image + 이름 TMP, 비활성)
// [의존 관계]      - UIMapNode 와 동급의 단순 뷰 컴포넌트 (UIBase 아님 — UIMap 자식 요소)
//                  - UIMap 이 Init 시 타입 아이콘/이름 목록을 Entry 로 넘겨 Build 호출
// [배치]           UIMap 프리팹의 자식. 프리팹 = 03_Prefabs/UIMapLegend
// [설계 노트]      - 항목 데이터(아이콘/이름)는 UIMap 의 _typeIcons 가 단일 출처 —
//                    여기서 중복 보관하지 않는다 (아이콘 교체 시 한 곳만 수정).
//                  - 행은 템플릿 복제로 1회 생성. 갱신 개념 없음 — 범례는 정적.
// =================================================================

using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// 맵 범례 패널. 아이콘+이름 행을 템플릿 복제로 나열한다 (1회, 정적).
/// 항목 데이터는 UIMap 이 소유하고, 이 컴포넌트는 표시만 담당한다.
/// </summary>
public sealed class UIMapLegend : MonoBehaviour
{
    private const string TitleKey = "UI_MAP_LEGEND_TITLE";

    /// <summary>범례 한 행의 표시 데이터 (아이콘 + 이름).</summary>
    public readonly struct Entry
    {
        public readonly Sprite Icon;
        public readonly string LabelKey;

        public Entry(Sprite icon, string labelKey)
        {
            Icon = icon;
            LabelKey = labelKey;
        }
    }

    private sealed class RowBinding
    {
        public readonly TMP_Text Text;
        public readonly string Key;

        public RowBinding(TMP_Text text, string key)
        {
            Text = text;
            Key = key;
        }
    }

    [Tooltip("행이 쌓일 부모 (VerticalLayoutGroup)")]
    [SerializeField] private RectTransform _rowsRoot;

    [Tooltip("행 템플릿. 자식에 아이콘 Image 와 이름 TMP 텍스트 필요 (비활성 상태로 배치)")]
    [SerializeField] private GameObject _rowTemplate;

    [Tooltip("범례 제목 텍스트")]
    [SerializeField] private TMP_Text _titleText;

    private readonly List<RowBinding> _rowBindings = new List<RowBinding>();
    private bool _built;

    /// <summary>
    /// 범례 행 생성 (1회). 아이콘이나 이름이 빈 항목은 건너뛴다.
    /// </summary>
    public void Build(IReadOnlyList<Entry> entries)
    {
        if (_built || entries == null) return;
        if (_rowsRoot == null || _rowTemplate == null)
        {
            Debug.LogError("[UIMapLegend] 행 부모 또는 템플릿이 비어 있습니다.");
            return;
        }

        foreach (Entry entry in entries)
        {
            if (entry.Icon == null || string.IsNullOrEmpty(entry.LabelKey)) continue;

            GameObject row = Instantiate(_rowTemplate, _rowsRoot);
            row.SetActive(true);

            Image icon = row.GetComponentInChildren<Image>(includeInactive: true);
            if (icon != null) icon.sprite = entry.Icon;

            TMP_Text label = row.GetComponentInChildren<TMP_Text>(includeInactive: true);
            if (label != null)
            {
                LocalizedFontUtility.ApplyCurrentFont(label);
                _rowBindings.Add(new RowBinding(label, entry.LabelKey));
                label.text = Localize(entry.LabelKey);
            }
        }

        _built = true;
        OnLocalize();
    }

    public void OnLocalize()
    {
        if (_titleText != null)
        {
            LocalizedFontUtility.ApplyCurrentFont(_titleText);
            _titleText.text = Localize(TitleKey);
        }

        for (int i = 0; i < _rowBindings.Count; i++)
        {
            RowBinding binding = _rowBindings[i];
            if (binding.Text != null)
            {
                LocalizedFontUtility.ApplyCurrentFont(binding.Text);
                binding.Text.text = Localize(binding.Key);
            }
        }
    }

    private static string Localize(string key)
    {
        return LocalizationManager.HasInstance
            ? LocalizationManager.Instance.Get(key)
            : key;
    }
}
