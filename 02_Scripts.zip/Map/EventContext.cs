// =================================================================
// [스크립트 목적]  Event 프리팹이 한 Event 실행에 필요한 런타임 참조를 받는 계약이다.
// =================================================================

using System.Threading;
using Cysharp.Threading.Tasks;

public interface IEventView
{
    UniTask PlayAsync(EventContext context, CancellationToken token);
}

public readonly struct EventContext
{
    public RunContext Run { get; }
    public int NodeId { get; }
    public InGameController InGame { get; }
    public GridManager Grid { get; }
    public string EventId { get; }
    public bool UseSeededRandom { get; }
    public int ChoiceIndex { get; }
    public int EffectIndex { get; }

    public EventContext(
        RunContext run, int nodeId, InGameController inGame, GridManager grid,
        string eventId = null, bool useSeededRandom = true,
        int choiceIndex = -1, int effectIndex = -1)
    {
        Run = run;
        NodeId = nodeId;
        InGame = inGame;
        Grid = grid;
        EventId = eventId ?? string.Empty;
        UseSeededRandom = useSeededRandom;
        ChoiceIndex = choiceIndex;
        EffectIndex = effectIndex;
    }

    public EventContext WithExecution(int choiceIndex, int effectIndex)
        => new EventContext(
            Run, NodeId, InGame, Grid, EventId, UseSeededRandom, choiceIndex, effectIndex);
}
