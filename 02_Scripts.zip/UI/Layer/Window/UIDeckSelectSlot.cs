﻿// =================================================================
// [스크립트 목적]  UIWindowDeckSelect 의 덱 직접 선택 슬롯.
//                  덱 이름/아이콘/선택 상태를 표시하고 클릭 콜백을 전달한다.
// [의존 관계]      - Button / Image / TMP_Text
// =================================================================

using System;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public sealed class UIDeckSelectSlot : MonoBehaviour
{
    [SerializeField] private Button _button;
    [SerializeField] private Image _iconImage;
    [SerializeField] private GameObject _selectedMark;

    private Action _onClicked;

    private void Awake()
    {
        if (_button != null)
            _button.onClick.AddListener(HandleClick);
    }

    public void Bind(Sprite icon, Action onClicked)
    {
        _onClicked = onClicked;

        if (_iconImage != null)
        {
            _iconImage.sprite = icon;
            _iconImage.enabled = icon != null;
        }

        SetSelected(false);
    }

    public void SetSelected(bool selected)
    {
        if (_selectedMark != null)
            _selectedMark.SetActive(selected);

        if (_button != null)
            _button.interactable = !selected;
    }

    private void HandleClick()
    {
        _onClicked?.Invoke();
    }

    private void OnDestroy()
    {
        if (_button != null)
            _button.onClick.RemoveListener(HandleClick);

        _onClicked = null;
    }
}
