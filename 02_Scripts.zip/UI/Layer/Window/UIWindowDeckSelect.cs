﻿// =================================================================
// [스크립트 목적]  런 시작 전 캐릭터 선택 창. 좌/우 순환과 직접 선택 버튼으로 캐릭터를 고르고,
//                  시작 버튼 클릭 시 선택된 CharacterSO 를 호출부(MainController)에 전달한다.
//                  캐릭터는 덱 타입(EStartingDeck) + 전용 스킬(SkillDataSO) 을 보유한다.
// [의존 관계]      - UIBase / CharacterSO / DataManager
// [배치]           Addressable UI 프리팹. 키 = "UIWindowDeckSelect".
// =================================================================

using System;
using System.Collections.Generic;
using System.Threading;
using TMPro;
using Cysharp.Threading.Tasks;
using UnityEngine;
using UnityEngine.UI;

public sealed class UIWindowDeckSelect : UIBase
{
    private const string NoCharacterNameKey = "UI_DECK_SELECT_NO_CHARACTER";
    private const string NoCharacterDescKey = "UI_DECK_SELECT_NO_CHARACTER_DESC";

    [Header("전환")]
    [SerializeField] private Button _previousButton;
    [SerializeField] private Button _nextButton;
    [SerializeField] private Button _startButton;

    [Header("표시")]
    [SerializeField] private TMP_Text _deckNameText;
    [SerializeField] private TMP_Text _deckDescriptionText;
    [SerializeField] private TMP_Text _deckIndexText;

    [Header("직접 선택")]
    [SerializeField] private Transform _selectorRoot;
    [SerializeField] private UIDeckSelectSlot _selectorSlotPrefab;
    [SerializeField] private List<UIDeckSelectSlot> _selectorSlots = new List<UIDeckSelectSlot>();

    [Header("이미지")]
    [Tooltip("캐릭터 PortraitKey 가 비어있을 때 사용할 폴백 접두사. 최종 키 = Prefix + DeckType")]
    [SerializeField] private string _deckImageKeyPrefix = "DeckSelect_";

    private readonly List<CharacterSO> _characters = new List<CharacterSO>(8);
    private readonly List<UIDeckSelectSlot> _spawnedSelectorSlots = new List<UIDeckSelectSlot>(8);
    private int _selectedIndex;
    private bool _started;
    private CancellationTokenSource _loadCts;
    private UniTaskCompletionSource _readySource;

    public event Action<CharacterSO> OnStartRequested;

    protected override void Init()
    {
        if (_previousButton != null) _previousButton.onClick.AddListener(SelectPrevious);
        if (_nextButton != null) _nextButton.onClick.AddListener(SelectNext);
        if (_startButton != null) _startButton.onClick.AddListener(HandleStartClicked);
    }

    protected override void Setup()
    {
        _started = false;
        RebuildCharacterList();
        _selectedIndex = Mathf.Clamp(_selectedIndex, 0, Mathf.Max(0, _characters.Count - 1));
        _readySource = new UniTaskCompletionSource();
        RunRebuildSelectorsAsync().Forget();
        RefreshSelection();
    }

    public override void OnClose()
    {
        CancelLoads();
        ClearSpawnedSelectors();
        OnStartRequested = null;
        base.OnClose();
    }

    public async UniTask WaitUntilReadyAsync(CancellationToken token)
    {
        if (_readySource != null)
            await _readySource.Task.AttachExternalCancellation(token);

        Canvas.ForceUpdateCanvases();
        await UniTask.Yield(PlayerLoopTiming.LastPostLateUpdate, token);
    }

    private void RebuildCharacterList()
    {
        _characters.Clear();
        if (!DataManager.HasInstance || !DataManager.Instance.IsLoaded)
        {
            return;
        }

        List<CharacterSO> all = DataManager.Instance.GetAllData<CharacterSO>();
        if (all == null) return;

        for (int i = 0; i < all.Count; i++)
        {
            CharacterSO character = all[i];
            if (character == null) continue;
            if (!IsSelectable(character.DeckType)) continue;
            _characters.Add(character);
        }

        // Index 오름차순 정렬(작을수록 좌측). 동일 Index 는 DeckType 으로 보조 정렬.
        _characters.Sort((a, b) =>
        {
            int compare = a.Index.CompareTo(b.Index);
            return compare != 0 ? compare : a.DeckType.CompareTo(b.DeckType);
        });
    }

    private static bool IsSelectable(EStartingDeck deckType)
    {
        if (deckType == EStartingDeck.None || deckType == EStartingDeck.Common)
        {
            return false;
        }

#if UNITY_EDITOR || DEVELOPMENT_BUILD
        return true;
#else
        return deckType != EStartingDeck.Test;
#endif
    }

    private async UniTaskVoid RunRebuildSelectorsAsync()
    {
        try
        {
            await RebuildSelectorsAsync();
            _readySource?.TrySetResult();
        }
        catch (OperationCanceledException)
        {
            _readySource?.TrySetCanceled();
        }
        catch (Exception e)
        {
            Debug.LogException(e);
            _readySource?.TrySetException(e);
        }
    }

    private async UniTask RebuildSelectorsAsync()
    {
        CancelLoads();
        _loadCts = new CancellationTokenSource();
        CancellationToken token = _loadCts.Token;

        ClearSpawnedSelectors();

        if (_selectorSlotPrefab != null && _selectorRoot != null)
        {
            for (int i = 0; i < _characters.Count; i++)
            {
                int captured = i;
                UIDeckSelectSlot slot = Instantiate(_selectorSlotPrefab, _selectorRoot);
                _spawnedSelectorSlots.Add(slot);
                Sprite icon = await LoadCharacterSpriteAsync(_characters[i], token);
                if (token.IsCancellationRequested || slot == null) return;
                slot.Bind(icon, () => SelectIndex(captured));
            }
            RefreshSelectorInteractable();
            return;
        }

        int count = Mathf.Min(_selectorSlots.Count, _characters.Count);
        for (int i = 0; i < _selectorSlots.Count; i++)
        {
            UIDeckSelectSlot slot = _selectorSlots[i];
            if (slot == null) continue;

            bool active = i < count;
            slot.gameObject.SetActive(active);
            if (!active) continue;

            int captured = i;
            Sprite icon = await LoadCharacterSpriteAsync(_characters[i], token);
            if (token.IsCancellationRequested || slot == null) return;
            slot.Bind(icon, () => SelectIndex(captured));
        }

        RefreshSelectorInteractable();
    }

    private void RefreshSelection()
    {
        bool hasCharacter = _characters.Count > 0;
        if (_startButton != null) _startButton.interactable = hasCharacter && !_started;
        if (_previousButton != null) _previousButton.interactable = hasCharacter && _characters.Count > 1;
        if (_nextButton != null) _nextButton.interactable = hasCharacter && _characters.Count > 1;

        if (!hasCharacter)
        {
            if (_deckNameText != null) _deckNameText.text = ResolveLocalized(NoCharacterNameKey);
            if (_deckDescriptionText != null) _deckDescriptionText.text = ResolveLocalized(NoCharacterDescKey);
            if (_deckIndexText != null) _deckIndexText.text = "0 / 0";
            return;
        }

        CharacterSO character = _characters[_selectedIndex];
        if (_deckNameText != null) _deckNameText.text = GetCharacterDisplayName(character);
        if (_deckDescriptionText != null) _deckDescriptionText.text = GetCharacterDescription(character);
        if (_deckIndexText != null) _deckIndexText.text = $"{_selectedIndex + 1} / {_characters.Count}";

        RefreshSelectorInteractable();
    }

    private void RefreshSelectorInteractable()
    {
        for (int i = 0; i < _selectorSlots.Count; i++)
        {
            if (_selectorSlots[i] != null && _selectorSlots[i].gameObject.activeSelf)
            {
                _selectorSlots[i].SetSelected(i == _selectedIndex);
            }
        }

        for (int i = 0; i < _spawnedSelectorSlots.Count; i++)
        {
            if (_spawnedSelectorSlots[i] != null)
            {
                _spawnedSelectorSlots[i].SetSelected(i == _selectedIndex);
            }
        }
    }

    private void ClearSpawnedSelectors()
    {
        for (int i = 0; i < _spawnedSelectorSlots.Count; i++)
        {
            if (_spawnedSelectorSlots[i] != null)
            {
                Destroy(_spawnedSelectorSlots[i].gameObject);
            }
        }
        _spawnedSelectorSlots.Clear();
    }

    private void SelectPrevious()
    {
        if (_characters.Count == 0) return;
        SelectIndex((_selectedIndex - 1 + _characters.Count) % _characters.Count);
    }

    private void SelectNext()
    {
        if (_characters.Count == 0) return;
        SelectIndex((_selectedIndex + 1) % _characters.Count);
    }

    private void SelectIndex(int index)
    {
        if (index < 0 || index >= _characters.Count) return;
        if (_selectedIndex == index) return;

        _selectedIndex = index;
        RefreshSelection();
    }

    private void HandleStartClicked()
    {
        if (_started || _characters.Count == 0) return;

        _started = true;
        if (_startButton != null) _startButton.interactable = false;
        OnStartRequested?.Invoke(_characters[_selectedIndex]);
    }

    private static string GetCharacterDisplayName(CharacterSO character)
    {
        if (character == null) return string.Empty;
        string key = character.DisplayNameKey;
        if (string.IsNullOrEmpty(key))
            return character.DeckType.ToString();
        return ResolveLocalized(key);
    }

    private static string GetCharacterDescription(CharacterSO character)
    {
        if (character == null) return string.Empty;
        string key = character.DescKey;
        return string.IsNullOrEmpty(key) ? string.Empty : ResolveLocalized(key);
    }

    private static string ResolveLocalized(string key)
    {
        if (string.IsNullOrEmpty(key)) return string.Empty;
        return LocalizationManager.HasInstance
            ? LocalizationManager.Instance.Get(key)
            : key;
    }

    private async UniTask<Sprite> LoadCharacterSpriteAsync(CharacterSO character, CancellationToken token)
    {
        if (!ResourceManager.HasInstance || character == null)
            return null;

        // 초상화 키가 있으면 사용, 없으면 덱 타입 기반 폴백 키로 로드.
        string key = !string.IsNullOrWhiteSpace(character.PortraitKey)
            ? character.PortraitKey
            : (!string.IsNullOrWhiteSpace(_deckImageKeyPrefix) ? $"{_deckImageKeyPrefix}{character.DeckType}" : null);
        if (string.IsNullOrWhiteSpace(key))
            return null;

        try
        {
            return await ResourceManager.Instance.LoadSpriteAsync(key, token);
        }
        catch (OperationCanceledException)
        {
            throw;
        }
        catch (Exception e)
        {
            Debug.LogWarning($"[UIWindowDeckSelect] 캐릭터 이미지 로드 실패: {key} ({e.Message})");
            return null;
        }
    }

    private void CancelLoads()
    {
        if (_loadCts == null) return;
        _loadCts.Cancel();
        _loadCts.Dispose();
        _loadCts = null;
    }

    private void OnDestroy()
    {
        CancelLoads();
        if (_previousButton != null) _previousButton.onClick.RemoveListener(SelectPrevious);
        if (_nextButton != null) _nextButton.onClick.RemoveListener(SelectNext);
        if (_startButton != null) _startButton.onClick.RemoveListener(HandleStartClicked);
        OnStartRequested = null;
    }
}
