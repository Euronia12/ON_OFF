using System;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

/// <summary>F7 다음 이벤트 예약 프리팹용 UI.</summary>
public sealed class UIDebugEvent : UIDebugPopupBase
{
    [SerializeField] private TMP_InputField _searchInput;
    [SerializeField] private TMP_Dropdown _eventDropdown;
    [SerializeField] private Button _applyButton;
    private readonly List<EventDataSO> _events = new();
    public event Action<EventDataSO> OnApplyRequested;

    protected override void Init()
    {
        base.Init();
        _applyButton?.onClick.AddListener(HandleApply);
        _searchInput?.onValueChanged.AddListener(RefreshOptions);
    }

    public void Bind(IReadOnlyList<EventDataSO> events)
    {
        _events.Clear();
        if (events != null) _events.AddRange(events);
        RefreshOptions(_searchInput != null ? _searchInput.text : string.Empty);
    }

    private void RefreshOptions(string search)
    {
        if (_eventDropdown == null) return;
        _eventDropdown.ClearOptions();
        var options = new List<TMP_Dropdown.OptionData>();
        for (int i = 0; i < _events.Count; i++)
        {
            EventDataSO item = _events[i];
            if (item == null || !Matches(item.EventId, item.TitleKey, search)) continue;
            options.Add(new TMP_Dropdown.OptionData($"{item.EventId} | {item.TitleKey}"));
        }
        _eventDropdown.AddOptions(options);
        _eventDropdown.RefreshShownValue();
    }

    private void HandleApply()
    {
        EventDataSO selected = GetSelected();
        if (selected != null) OnApplyRequested?.Invoke(selected);
    }

    private EventDataSO GetSelected()
    {
        if (_eventDropdown == null || _eventDropdown.options.Count == 0) return null;
        string label = _eventDropdown.options[_eventDropdown.value].text;
        for (int i = 0; i < _events.Count; i++)
            if (_events[i] != null && label.StartsWith(_events[i].EventId + " |", StringComparison.Ordinal)) return _events[i];
        return null;
    }

    private static bool Matches(string id, string name, string search)
        => string.IsNullOrWhiteSpace(search) ||
           (id?.IndexOf(search, StringComparison.OrdinalIgnoreCase) ?? -1) >= 0 ||
           (name?.IndexOf(search, StringComparison.OrdinalIgnoreCase) ?? -1) >= 0;
}
