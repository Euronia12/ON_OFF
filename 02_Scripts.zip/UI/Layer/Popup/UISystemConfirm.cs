﻿using System;
using System.Threading;
using Cysharp.Threading.Tasks;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public enum ESystemConfirmResult
{
    None,
    Confirm,
    Cancel
}

/// <summary>공용 확인 팝업. 호출자가 문구와 버튼명을 주입하고 버튼 결과를 비동기로 받는다.</summary>
public sealed class UISystemConfirm : UIBase
{
    [Header("Text")]
    [SerializeField] private TMP_Text _titleText;
    [SerializeField] private TMP_Text _descText;
    [SerializeField] private TMP_Text _confirmButtonText;
    [SerializeField] private TMP_Text _cancelButtonText;

    [Header("Buttons")]
    [SerializeField] private Button _confirmButton;
    [SerializeField] private Button _cancelButton;

    private UniTaskCompletionSource<ESystemConfirmResult> _resultSource;
    private bool _completed;

    public bool IsWaiting => _resultSource != null && !_completed;

    protected override void Init()
    {
        _confirmButton?.onClick.AddListener(HandleConfirm);
        _cancelButton?.onClick.AddListener(HandleCancel);
    }

    public async UniTask<ESystemConfirmResult> ShowAsync(
        string title,
        string desc,
        string confirmText,
        string cancelText,
        CancellationToken token = default)
    {
        SetText(title, desc, confirmText, cancelText);

        _completed = false;
        _resultSource = new UniTaskCompletionSource<ESystemConfirmResult>();

        try
        {
            return await _resultSource.Task.AttachExternalCancellation(token);
        }
        catch (OperationCanceledException)
        {
            Complete(ESystemConfirmResult.Cancel);
            throw;
        }
    }

    public void SetDescription(string desc)
    {
        if (_descText != null) _descText.text = desc ?? string.Empty;
    }

    public void Complete(ESystemConfirmResult result)
    {
        if (_completed) return;

        _completed = true;
        _resultSource?.TrySetResult(result);

        if (UIManager.HasInstance && IsOpen)
            UIManager.Instance.Close(this);
    }

    public override bool OnBackPressed()
    {
        Complete(ESystemConfirmResult.Cancel);
        return false;
    }

    public override void OnClose()
    {
        if (!_completed)
        {
            _completed = true;
            _resultSource?.TrySetResult(ESystemConfirmResult.Cancel);
        }

        base.OnClose();
    }

    private void SetText(string title, string desc, string confirmText, string cancelText)
    {
        if (_titleText != null) _titleText.text = title ?? string.Empty;
        if (_descText != null) _descText.text = desc ?? string.Empty;
        if (_confirmButtonText != null) _confirmButtonText.text = confirmText ?? string.Empty;
        if (_cancelButtonText != null) _cancelButtonText.text = cancelText ?? string.Empty;
    }

    private void HandleConfirm()
    {
        Complete(ESystemConfirmResult.Confirm);
    }

    private void HandleCancel()
    {
        Complete(ESystemConfirmResult.Cancel);
    }

    private void OnDestroy()
    {
        _confirmButton?.onClick.RemoveListener(HandleConfirm);
        _cancelButton?.onClick.RemoveListener(HandleCancel);

        if (!_completed)
            _resultSource?.TrySetResult(ESystemConfirmResult.Cancel);
    }
}
