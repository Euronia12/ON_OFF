/// <summary>QA 전용 팝업 공통 베이스. 닫기·딤 처리는 UIPopupBase를 그대로 사용한다.</summary>
public abstract class UIDebugPopupBase : UIPopupBase
{
    /// <summary>디버그 팝업은 ESC 로 즉시 닫고 원래 화면으로 돌아간다.</summary>
    public override bool CloseOnEscape => true;
}
