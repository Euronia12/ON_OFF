// =================================================================
// [스크립트 목적]  Choice Event 선택지 하나를 렌더하는 슬롯. 슬롯 프리팹에 부착.
// [주요 변수]      - _button/_labelText/_descText/_lockOverlay : 슬롯 UI 요소
// [의존 관계]      - EventChoiceData(데이터) / EventContext(조건 평가) / LocalizationManager
// [설계 노트]      - UIChoiceEvent 가 데이터마다 재사용/생성해 Bind. 라벨·설명은 토큰 치환.
//                    조건 미충족 시 버튼 비활성 + 잠김 오버레이.
// =================================================================

using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public sealed class UIChoiceSlot : MonoBehaviour
{
    [SerializeField] private Button _button;
    [SerializeField] private TMP_Text _labelText;
    [Tooltip("버튼 라벨과 별개로 표시할 설명 텍스트(선택)")]
    [SerializeField] private TMP_Text _descText;
    [Tooltip("잠김 상태일 때 켜지는 오버레이(자물쇠 등, 선택)")]
    [SerializeField] private GameObject _lockOverlay;

    private EventChoiceData _data;
    private int _index;
    private Action<int> _onChosen;

    public EventChoiceData Data => _data;

    private void Awake()
    {
        if (_button != null) _button.onClick.AddListener(HandleClick);
    }

    private void OnDestroy()
    {
        if (_button != null) _button.onClick.RemoveListener(HandleClick);
    }

    /// <summary>선택지 데이터 바인딩 + 로컬라이즈. 잠김은 ApplyLock 으로 갱신.</summary>
    public void Bind(int index, EventChoiceData data, Action<int> onChosen)
    {
        _index = index;
        _data = data;
        _onChosen = onChosen;
        gameObject.SetActive(true);
        Localize();
    }

    /// <summary>라벨·설명 로컬라이즈 + 효과 수치 토큰 치환.</summary>
    public void Localize()
    {
        if (_data == null) return;
        if (_labelText != null)
            _labelText.text = FormatWithTokens(L(_data.TextKey), _data.Effects, _data.Costs);
        if (_descText != null)
            _descText.text = FormatWithTokens(L(_data.DescKey), _data.Effects, _data.Costs);
    }

    /// <summary>조건 평가 → 미충족 시 버튼 비활성 + 잠김 오버레이 노출.</summary>
    public void ApplyLock(EventContext context)
    {
        bool unlocked = IsUnlocked(context);
        if (_button != null) _button.interactable = unlocked;
        if (_lockOverlay != null) _lockOverlay.SetActive(!unlocked);
    }

    /// <summary>
    /// 해금 여부: 모든 요구량 지불 가능 + 덱 크기 게이트 충족 + 모든 효과가 적용 가능.
    /// 효과 게이트는 "대상 카드가 없다", "이미 하한이다" 같은 무의미한 선택을 막는다.
    /// </summary>
    public bool IsUnlocked(EventContext context)
    {
        if (_data == null) return false;
        IReadOnlyList<EventCost> costs = _data.Costs;
        for (int i = 0; i < costs.Count; i++)
            if (costs[i] != null && !costs[i].CanAfford(context)) return false;
        if (!_data.IsDeckSizeAllowed(context.Run)) return false;

        IReadOnlyList<ChoiceEventEffectBase> effects = _data.Effects;
        for (int i = 0; i < effects.Count; i++)
            if (effects[i] != null && !effects[i].CanApply(context)) return false;
        return true;
    }

    /// <summary>처리 중 전체 잠금용(조건 잠김과 별개). 버튼만 토글.</summary>
    public void SetInteractable(bool interactable)
    {
        if (_button != null) _button.interactable = interactable;
    }

    /// <summary>슬롯 재사용 반납(초과분 비활성).</summary>
    public void Release()
    {
        _onChosen = null;
        _data = null;
        gameObject.SetActive(false);
    }

    private void HandleClick() => _onChosen?.Invoke(_index);

    private static string L(string key)
    {
        if (string.IsNullOrEmpty(key)) return string.Empty;
        return LocalizationManager.HasInstance ? LocalizationManager.Instance.Get(key) : key;
    }

    private static readonly Regex TokenRegex =
        new Regex(@"\{(\w+)\}", RegexOptions.Compiled);

    // 라벨/설명용(선택 전): 효과의 예정 수치(DescAmount)로 {amount} 치환.
    public static string FormatWithTokens(string template,
        IReadOnlyList<ChoiceEventEffectBase> effects, IReadOnlyList<EventCost> costs)
    {
        List<int?> amounts = null;
        if (effects != null)
        {
            amounts = new List<int?>(effects.Count);
            for (int i = 0; i < effects.Count; i++) amounts.Add(effects[i]?.DescAmount);
        }
        return FormatWithAmounts(template, amounts, costs, effects);
    }

    // 결과용(선택 후): ApplyAsync 가 반환한 실제 적용값 목록으로 {amount} 치환.
    //  {amount}/{amountN} = 수치, {cost}/{costN} = 요구량 수치. (첫 항목은 인덱스 생략형)
    //  effects 를 넘기면 효과가 등록한 문자열 토큰({skill} 등)도 함께 치환한다.
    public static string FormatWithAmounts(string template,
        IReadOnlyList<int?> amounts, IReadOnlyList<EventCost> costs,
        IReadOnlyList<ChoiceEventEffectBase> effects = null,
        bool useResultTokens = false)
    {
        if (string.IsNullOrEmpty(template) || template.IndexOf('{') < 0)
            return template ?? string.Empty;

        var tokens = new Dictionary<string, string>(12, StringComparer.OrdinalIgnoreCase);

        int amountIndex = 0;
        if (amounts != null)
            for (int i = 0; i < amounts.Count; i++)
            {
                if (amounts[i] == null) continue;
                string text = amounts[i].Value.ToString();
                tokens["amount" + amountIndex] = text;
                if (amountIndex == 0) tokens["amount"] = text;
                amountIndex++;
            }

        int costIndex = 0;
        if (costs != null)
            for (int i = 0; i < costs.Count; i++)
            {
                if (costs[i] == null) continue;
                string text = costs[i].Amount.ToString();
                tokens["cost" + costIndex] = text;
                if (costIndex == 0) tokens["cost"] = text;
                costIndex++;
            }

        // 문자열 토큰은 수치 토큰이 하나도 없는 선택지에서도 쓰이므로 조기 반환보다 먼저 모은다.
        if (effects != null)
            for (int i = 0; i < effects.Count; i++)
            {
                if (useResultTokens)
                    effects[i]?.CollectResultTextTokens(tokens);
                else
                    effects[i]?.CollectTextTokens(tokens);
            }

        if (tokens.Count == 0) return template;

        return TokenRegex.Replace(template,
            m => tokens.TryGetValue(m.Groups[1].Value, out string v) ? v : m.Value);
    }
}
