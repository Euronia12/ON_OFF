﻿using System;
using System.Threading;
using Cysharp.Threading.Tasks;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

/// <summary>최초 게임 시작 전에 개인정보 수집 동의를 명시적으로 확인받는 팝업.</summary>
public sealed class UIPrivacyConsentPopup : UIBase
{
    [Header("Text")]
    [SerializeField] private TMP_Text _titleText;
    [SerializeField] private Toggle _privacyConsentToggle;
    [SerializeField] private TMP_Text _privacyConsentText;
    [SerializeField] private TMP_Text _privacyDetailText;
    [SerializeField] private TMP_Text _confirmButtonText;

    [Header("Buttons")]
    [SerializeField] private Button _privacyPolicyButton;
    [SerializeField] private Button _confirmButton;

    private UniTaskCompletionSource<bool> _resultSource;
    private bool _completed;

    public override bool CloseOnEscape => true;

    protected override void Init()
    {
        _privacyPolicyButton?.onClick.AddListener(OpenPrivacyPolicy);
        _confirmButton?.onClick.AddListener(HandleConfirm);
    }

    protected override void Setup()
    {
        _completed = false;
        _resultSource = new UniTaskCompletionSource<bool>();
    }

    public async UniTask<bool> ShowAsync(bool initialConsent, CancellationToken token = default)
    {
        _privacyConsentToggle?.SetIsOnWithoutNotify(initialConsent);
        try
        {
            return await _resultSource.Task.AttachExternalCancellation(token);
        }
        catch (OperationCanceledException)
        {
            if (UIManager.HasInstance && IsOpen)
                UIManager.Instance.Close(this);
            throw;
        }
    }

    public override void OnLocalize()
    {
        base.OnLocalize();
        SetLocalizedText(_titleText, LocalizationKeys.Common.PrivacyPolicy);
        SetLocalizedText(_privacyConsentText, LocalizationKeys.Common.PrivacyConsentToggle);
        SetLocalizedText(_privacyDetailText, LocalizationKeys.Common.PrivacyPolicyDetails);
        SetLocalizedText(_confirmButtonText, LocalizationKeys.Common.Confirm);
    }

    public override bool OnBackPressed() => false;

    public override void OnClose()
    {
        if (!_completed)
            _resultSource?.TrySetException(new OperationCanceledException());

        base.OnClose();
    }

    private void HandleConfirm()
    {
        if (_completed) return;

        _completed = true;
        _resultSource?.TrySetResult(_privacyConsentToggle != null && _privacyConsentToggle.isOn);
        if (UIManager.HasInstance && IsOpen)
            UIManager.Instance.Close(this);
    }

    private static void SetLocalizedText(TMP_Text target, string key)
    {
        if (target == null) return;

        LocalizedFontUtility.ApplyCurrentFont(target);
        target.text = LocalizationManager.HasInstance
            ? LocalizationManager.Instance.Get(key)
            : key;
    }

    private static void OpenPrivacyPolicy()
    {
        string url = Constants.ExternalLinks.PRIVACY_POLICY;
        if (Uri.TryCreate(url, UriKind.Absolute, out Uri uri) && uri.Scheme == Uri.UriSchemeHttps)
        {
            Application.OpenURL(url);
            return;
        }

        ShowInvalidPrivacyPolicyUrlAsync().Forget();
    }

    private static async UniTask ShowInvalidPrivacyPolicyUrlAsync()
    {
        if (!UIManager.HasInstance) return;

        UISystemNavi systemNavi = await UIManager.Instance.OpenAsync<UISystemNavi>();
        systemNavi?.Show(LocalizationKeys.Common.PrivacyPolicyInvalidUrl);
    }

    private void OnDestroy()
    {
        _privacyPolicyButton?.onClick.RemoveListener(OpenPrivacyPolicy);
        _confirmButton?.onClick.RemoveListener(HandleConfirm);

        if (!_completed)
            _resultSource?.TrySetException(new OperationCanceledException());
    }
}
