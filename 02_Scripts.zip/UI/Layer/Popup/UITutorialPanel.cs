// =================================================================
// [스크립트 목적]  튜토리얼 안내 패널. 제목 + 본문(여러 페이지) + 좌우 화살표 페이지 버튼.
//                 표시 완료를 비동기(UniTask)로 알린다 (UISystemConfirm 과 동일 패턴).
// [주요 변수]      - _pages/_pageIndex : 현재 스텝의 본문 페이지 진행 상태
//                  - _completion       : 스텝 표시 완료 신호 (마지막 페이지 확인 시)
// [의존 관계]      - UIBase / UIManager(열기·닫기) / TutorialDirector(호출자)
// [배치]           Canvas UI 프리팹에 부착, Addressable "UITutorialPanel" 등록
// [설계 노트]      - 레이어는 프리팹 Inspector의 UIBase 설정을 사용한다.
// =================================================================

using System;
using System.Collections.Generic;
using System.Threading;
using Cysharp.Threading.Tasks;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.InputSystem;
using UnityEngine.UI;

/// <summary>
/// 튜토리얼 안내 패널. TutorialDirector 가 스텝 내용을 주입해 열고,
/// 플레이어가 마지막 페이지까지 확인하면 완료가 반환된다.
/// 삽화 페이지가 있는 스텝은 파생 타입(UITutorialIllustPanel) 프리팹으로 열린다.
/// </summary>
public class UITutorialPanel : UIBase, IPointerClickHandler
{
    private const string OwlAnchorId = "Owl";
    private const float OwlPanelGap = 20f;

    [Header("Panel")]
    [Tooltip("배치 프리셋으로 움직일 안내 창 본체 (Dim 이 아닌 Panel). 비우면 위치 고정")]
    [SerializeField] private RectTransform _panelRoot;

    [Header("등장 연출")]
    [Tooltip("페이드 인에 사용할 CanvasGroup (프리팹 루트 권장). 비우면 연출 없이 즉시 표시")]
    [SerializeField] private CanvasGroup _canvasGroup;

    [Tooltip("페이드 인 시간(초)")]
    [Min(0f)]
    [SerializeField] private float _fadeInDuration = 0.2f;

    [Tooltip("화면 가장자리 배치(Top/Bottom/Left/Right) 시 가장자리로부터의 여백(px)")]
    [Min(0f)]
    [SerializeField] private float _edgeMargin = 60f;

    [Header("Text")]
    [SerializeField] private TMP_Text _titleText;
    [SerializeField] private TMP_Text _bodyText;

    [Tooltip("페이지 표시 (예: 1/3). 페이지가 1장이면 자동으로 숨김")]
    [SerializeField] private TMP_Text _pageText;

    [Header("삽화 (삽화 패널 프리팹 전용 — 텍스트 패널은 비워둠)")]
    [Tooltip("페이지 삽화를 표시할 Image. 이미지 없는 페이지에선 자동으로 숨김")]
    [SerializeField] private Image _pageImage;

    [Header("Button")]
    [Tooltip("다음 페이지 화살표. 마지막 페이지에선 확인(닫기) 역할")]
    [SerializeField] private Button _nextButton;

    [Tooltip("이전 페이지 화살표 (선택). 첫 페이지에선 자동 숨김")]
    [SerializeField] private Button _prevButton;

    [Header("고정 텍스트 로컬라이즈")]
    [Tooltip("강조 프록시처럼 패널에 복제된 고정 텍스트와 StringChart 키")]
    [SerializeField] private LocalizedTMPBinding[] _localizedTexts;

    private IReadOnlyList<TutorialPageContent> _pages = Array.Empty<TutorialPageContent>();
    private string _titleKey;
    private int _pageIndex;
    private UniTaskCompletionSource _completion;
    private bool _completed;
    private bool _allowReplayAfterClose;
    private bool _preserveExistingReplay;
    private bool _isReplayPresentation;
    private bool _isOwlPinnedToPanelLeft;
    private string _owlAboveAnchorId;
    private RectTransform _owlAboveAnchorVisualRect;
    private readonly Vector3[] _panelWorldCorners = new Vector3[4];
    private readonly Vector3[] _anchorWorldCorners = new Vector3[4];
    private readonly Vector3[] _owlWorldCorners = new Vector3[4];

    // 프록시 강조 (딤 위 사본 아이콘). 자식에서 자동 수집, 스텝별 요청 ID 와 매칭.
    private TutorialHighlightProxy[] _proxies = Array.Empty<TutorialHighlightProxy>();
    private IReadOnlyList<string> _requestedAnchorIds = Array.Empty<string>();
#if UNITY_EDITOR || DEVELOPMENT_BUILD
    private readonly HashSet<string> _warnedMissingProxies = new HashSet<string>();
#endif

    protected override void Init()
    {
        _nextButton?.onClick.AddListener(HandleNext);
        _prevButton?.onClick.AddListener(HandlePrev);

        _proxies = GetComponentsInChildren<TutorialHighlightProxy>(true);

        TutorialHighlightProxy owlProxy = FindProxy(OwlAnchorId);
        if (owlProxy != null && owlProxy.Rect != null)
        {
            owlProxy.Rect.SetParent(transform, true);
            owlProxy.Rect.SetAsLastSibling();
        }

        // 프리팹에서 프록시가 켜진 채 저장돼 있어도 무해하도록 기준 상태(전부 꺼짐)로 정리.
        DeactivateAllProxies();
    }

    /// <summary>
    /// 스텝 내용을 표시하고 플레이어가 마지막 페이지를 확인할 때까지 기다린다.
    /// 완료 시 패널은 스스로 닫힌다.
    /// </summary>
    /// <param name="titleKey">제목 StringChart 키.</param>
    /// <param name="pages">본문 키 + 삽화 + 배치 + 강조 대상 목록.</param>
    public async UniTask ShowStepAsync(
        string titleKey,
        IReadOnlyList<TutorialPageContent> pages,
        CancellationToken token = default,
        bool allowReplayAfterClose = false,
        bool preserveExistingReplay = false,
        bool isReplayPresentation = false)
    {
        _pages = pages ?? Array.Empty<TutorialPageContent>();
        _titleKey = titleKey;
        _pageIndex = 0;
        _completed = false;
        _allowReplayAfterClose = allowReplayAfterClose;
        _preserveExistingReplay = preserveExistingReplay;
        _isReplayPresentation = isReplayPresentation;
        _completion = new UniTaskCompletionSource();

        if (!_isReplayPresentation && TutorialDirector.Active != null)
            TutorialDirector.Active.NotifyTutorialPanelOpened(_preserveExistingReplay);

        RefreshPage(); // 배치·프록시 강조는 페이지 단위 — RefreshPage 가 페이지 값으로 적용.

        try
        {
            await _completion.Task.AttachExternalCancellation(token);
        }
        catch (OperationCanceledException)
        {
            Complete(registerReplay: false);
            throw;
        }
    }

    /// <summary>요청된 Owl 프록시를 현재 안내 패널의 왼쪽에 고정한다.</summary>
    public void SetOwlPinnedToPanelLeft(bool pinned)
    {
        _isOwlPinnedToPanelLeft = pinned;
        if (pinned)
        {
            _owlAboveAnchorId = null;
            _owlAboveAnchorVisualRect = null;
        }
        if (IsOpen)
            SyncProxies();
    }

    /// <summary>요청된 Owl 프록시를 대상 화살표 위에 두고 안내 패널을 오른쪽에 배치한다.</summary>
    public void SetOwlAboveAnchorWithPanelOnRight(string anchorId)
    {
        _isOwlPinnedToPanelLeft = false;
        _owlAboveAnchorId = anchorId;
        _owlAboveAnchorVisualRect = null;

        TutorialHighlightProxy anchorProxy = FindProxy(anchorId);
        if (anchorProxy != null)
        {
            Graphic graphic = anchorProxy.GetComponentInChildren<Graphic>(true);
            _owlAboveAnchorVisualRect = graphic != null
                ? graphic.rectTransform
                : anchorProxy.Rect;
        }

        if (IsOpen)
            SyncProxies();
    }

    public override void OnOpen()
    {
        base.OnOpen();

        if (_canvasGroup != null && _fadeInDuration > 0f)
            FadeInAsync().Forget();
    }

    public override void OnLocalize()
    {
        base.OnLocalize();
        OptionLocalizationUtility.Apply(_localizedTexts);
        RefreshLocalizedText();
    }

    /// <summary>열릴 때 부드럽게 페이드 인 (일시정지와 무관하게 unscaled 시간 사용).</summary>
    private async UniTaskVoid FadeInAsync()
    {
        _canvasGroup.alpha = 0f;

        float elapsed = 0f;
        while (elapsed < _fadeInDuration)
        {
            await UniTask.Yield();
            if (this == null || _canvasGroup == null || !IsOpen) return;

            elapsed += Time.unscaledDeltaTime;
            _canvasGroup.alpha = Mathf.Clamp01(elapsed / _fadeInDuration);
        }

        _canvasGroup.alpha = 1f;
    }

    public override void OnClose()
    {
        bool shouldRestoreReplay = !_completed
                                   && _preserveExistingReplay
                                   && !_isReplayPresentation;

        // 외부 요인으로 닫혀도 호출자가 영원히 대기하지 않도록 완료 신호를 보장.
        if (!_completed)
        {
            _completed = true;
            _completion?.TrySetResult();
        }

        // 프록시 강조 정리 (다음 스텝이 이전 강조를 물려받지 않도록).
        _requestedAnchorIds = Array.Empty<string>();
        _isOwlPinnedToPanelLeft = false;
        _owlAboveAnchorId = null;
        _owlAboveAnchorVisualRect = null;
        DeactivateAllProxies();

        base.OnClose();

        if (shouldRestoreReplay && TutorialDirector.Active != null)
            TutorialDirector.Active.NotifyTutorialPanelClosed();
    }

    /// <summary>
    /// 표시 중 매 프레임 프록시를 실물 앵커와 동기화한다.
    /// 늦게 열리는 UI(상점 등)의 앵커도 등장하는 즉시 따라잡고, 실물이 움직이면 추적한다.
    /// </summary>
    private void LateUpdate()
    {
        if (!IsOpen || _requestedAnchorIds.Count == 0) return;
        SyncProxies();
    }

    private void Update()
    {
        if (!IsOpen || !TutorialDirector.IsActive) return;

        Mouse mouse = Mouse.current;
        if (mouse != null && mouse.rightButton.wasPressedThisFrame)
            HandlePrev();
    }

    public void OnPointerClick(PointerEventData eventData)
    {
        if (!IsOpen
            || !TutorialDirector.IsActive
            || eventData.button != PointerEventData.InputButton.Left)
        {
            return;
        }

        HandleNext();
    }

    /// <summary>요청된 앵커 ID 마다 프록시를 찾아 실물 위치로 활성화. 실물이 없으면 숨김.</summary>
    private void SyncProxies()
    {
        for (int i = 0; i < _requestedAnchorIds.Count; i++)
        {
            string id = _requestedAnchorIds[i];
            TutorialHighlightProxy proxy = FindProxy(id);
            if (proxy == null)
            {
#if UNITY_EDITOR || DEVELOPMENT_BUILD
                if (_warnedMissingProxies.Add(id))
                    Debug.LogWarning($"[UITutorialPanel] '{id}' 프록시가 프리팹에 없습니다. 강조를 생략합니다.");
#endif
                continue;
            }

            if (!string.IsNullOrEmpty(_owlAboveAnchorId) && id == OwlAnchorId)
            {
                continue;
            }
            else if (id == OwlAnchorId && (_isOwlPinnedToPanelLeft || proxy.ShowWithoutAnchor))
            {
                SyncOwlToPanelTopLeft(proxy);
                if (!proxy.gameObject.activeSelf) proxy.gameObject.SetActive(true);
            }
            else if (TutorialAnchor.TryGet(id, out TutorialAnchor anchor) && anchor.Rect != null)
            {
                SyncProxyToAnchor(proxy, anchor);
                if (!proxy.gameObject.activeSelf) proxy.gameObject.SetActive(true);
            }
            else if (proxy.ShowWithoutAnchor)
            {
                // 앵커 불요 프록시 — 프리팹에 배치한 위치 그대로 표시 (고정 화살표 등).
                if (!proxy.gameObject.activeSelf) proxy.gameObject.SetActive(true);
            }
            else if (proxy.gameObject.activeSelf)
            {
                // 실물이 아직/더 이상 없음 (늦게 열리는 UI 등) — 등장하면 다음 프레임에 켜진다.
                proxy.gameObject.SetActive(false);
            }
        }

        if (!string.IsNullOrEmpty(_owlAboveAnchorId))
            SyncOwlAboveAnchorWithPanelOnRight();
    }

    private void SyncOwlToPanelTopLeft(TutorialHighlightProxy proxy)
    {
        RectTransform proxyRect = proxy.Rect;
        if (_panelRoot == null || proxyRect == null) return;

        Graphic owlGraphic = proxy.GetComponentInChildren<Graphic>(true);
        RectTransform owlVisualRect = owlGraphic != null ? owlGraphic.rectTransform : proxyRect;
        _panelRoot.GetWorldCorners(_panelWorldCorners);
        Vector3 panelTopLeft = _panelWorldCorners[1];
        Vector3 panelRightDirection = (_panelWorldCorners[2] - _panelWorldCorners[1]).normalized;
        Vector3 panelUpDirection = (_panelWorldCorners[1] - _panelWorldCorners[0]).normalized;
        float halfWidth = owlVisualRect.rect.width * Mathf.Abs(owlVisualRect.lossyScale.x) * 0.5f;
        float halfHeight = owlVisualRect.rect.height * Mathf.Abs(owlVisualRect.lossyScale.y) * 0.5f;
        proxyRect.position = panelTopLeft
                             + panelRightDirection * halfWidth
                             + panelUpDirection * halfHeight;

        RectTransform rootRect = transform as RectTransform;
        if (rootRect == null) return;

        rootRect.GetWorldCorners(_anchorWorldCorners);
        owlVisualRect.GetWorldCorners(_owlWorldCorners);
        Vector3 correction = Vector3.zero;
        if (_owlWorldCorners[1].y > _anchorWorldCorners[1].y)
            correction.y = _anchorWorldCorners[1].y - _owlWorldCorners[1].y;
        else if (_owlWorldCorners[0].y < _anchorWorldCorners[0].y)
            correction.y = _anchorWorldCorners[0].y - _owlWorldCorners[0].y;

        if (_owlWorldCorners[0].x < _anchorWorldCorners[0].x)
            correction.x = _anchorWorldCorners[0].x - _owlWorldCorners[0].x;
        else if (_owlWorldCorners[3].x > _anchorWorldCorners[3].x)
            correction.x = _anchorWorldCorners[3].x - _owlWorldCorners[3].x;

        proxyRect.position += correction;
    }

    private void SyncOwlAboveAnchorWithPanelOnRight()
    {
        TutorialHighlightProxy owlProxy = FindProxy(OwlAnchorId);
        TutorialHighlightProxy anchorProxy = FindProxy(_owlAboveAnchorId);
        RectTransform owlRect = owlProxy != null ? owlProxy.Rect : null;
        RectTransform anchorVisualRect = _owlAboveAnchorVisualRect != null
            ? _owlAboveAnchorVisualRect
            : anchorProxy != null ? anchorProxy.Rect : null;
        if (_panelRoot == null || owlRect == null || anchorVisualRect == null)
            return;

        anchorVisualRect.GetWorldCorners(_anchorWorldCorners);
        Vector3 anchorTopCenter = (_anchorWorldCorners[1] + _anchorWorldCorners[2]) * 0.5f;
        float owlHeight = owlRect.rect.height * Mathf.Abs(owlRect.lossyScale.y);
        float verticalGap = OwlPanelGap * Mathf.Abs(owlRect.lossyScale.y);
        owlRect.position = anchorTopCenter + Vector3.up * (owlHeight * 0.5f + verticalGap);

        owlRect.GetWorldCorners(_owlWorldCorners);
        _panelRoot.GetWorldCorners(_panelWorldCorners);
        float horizontalGap = OwlPanelGap * Mathf.Abs(owlRect.lossyScale.x);
        Vector3 desiredPanelBottomLeft = _owlWorldCorners[3] + Vector3.right * horizontalGap;
        _panelRoot.position += desiredPanelBottomLeft - _panelWorldCorners[0];

        if (!owlProxy.gameObject.activeSelf)
            owlProxy.gameObject.SetActive(true);
    }

    /// <summary>
    /// 프록시를 실물 앵커의 월드 위치(+선택 시 크기)로 맞춘다.
    /// 피벗 설정이 서로 달라도 어긋나지 않도록 렉트 "중심점" 기준으로 정렬한다.
    /// </summary>
    private static void SyncProxyToAnchor(TutorialHighlightProxy proxy, TutorialAnchor anchor)
    {
        RectTransform proxyRect = proxy.Rect;
        RectTransform anchorRect = anchor.Rect;
        if (proxyRect == null || anchorRect == null) return;

        // 실물 렉트의 월드 중심 → 프록시 피벗-중심 오프셋을 보정해 중심끼리 일치시킨다.
        Vector3 anchorCenter = anchorRect.TransformPoint(anchorRect.rect.center);
        Vector2 pivotToCenter = new Vector2(
            (proxyRect.pivot.x - 0.5f) * proxyRect.rect.width,
            (proxyRect.pivot.y - 0.5f) * proxyRect.rect.height);
        proxyRect.position = anchorCenter + proxyRect.TransformVector(pivotToCenter);

        if (proxy.MatchAnchorSize)
        {
            // 서로 다른 부모/스케일을 감안해 월드 크기 기준으로 환산 복사.
            Vector3 anchorScale = anchorRect.lossyScale;
            Vector3 proxyScale = proxyRect.lossyScale;
            float width = anchorRect.rect.width * SafeRatio(anchorScale.x, proxyScale.x);
            float height = anchorRect.rect.height * SafeRatio(anchorScale.y, proxyScale.y);
            proxyRect.SetSizeWithCurrentAnchors(RectTransform.Axis.Horizontal, width);
            proxyRect.SetSizeWithCurrentAnchors(RectTransform.Axis.Vertical, height);
        }
    }

    private static float SafeRatio(float a, float b)
        => Mathf.Approximately(b, 0f) ? 1f : a / b;

    private TutorialHighlightProxy FindProxy(string anchorId)
    {
        for (int i = 0; i < _proxies.Length; i++)
        {
            TutorialHighlightProxy p = _proxies[i];
            if (p != null && p.AnchorId == anchorId) return p;
        }
        return null;
    }

    private void DeactivateAllProxies()
    {
        for (int i = 0; i < _proxies.Length; i++)
        {
            TutorialHighlightProxy p = _proxies[i];
            if (p != null && p.gameObject.activeSelf) p.gameObject.SetActive(false);
        }
    }

    private void HandleNext()
    {
        if (_pageIndex < _pages.Count - 1)
        {
            _pageIndex++;
            RefreshPage();
            return;
        }

        Complete();
    }

    /// <summary>이전 페이지로 (현재 패널 안에서만. 첫 페이지에선 버튼이 숨겨져 호출되지 않는다).</summary>
    private void HandlePrev()
    {
        if (_pageIndex <= 0) return;

        _pageIndex--;
        RefreshPage();
    }

    private void Complete(bool registerReplay = true)
    {
        if (_completed) return;

        _completed = true;
        UniTaskCompletionSource completion = _completion;
        bool shouldRegisterReplay = registerReplay
                                    && _allowReplayAfterClose
                                    && !_isReplayPresentation;
        bool shouldRestoreReplay = _preserveExistingReplay && !_isReplayPresentation;
        Vector3 replayButtonWorldPosition = GetOwlWorldPosition();

        if (UIManager.HasInstance && IsOpen)
            UIManager.Instance.Close(this);

        if (TutorialDirector.Active != null)
        {
            if (shouldRegisterReplay)
            {
                TutorialDirector.Active.RegisterReplayGuide(
                    _titleKey,
                    _pages,
                    replayButtonWorldPosition);
            }
            else if (shouldRestoreReplay)
            {
                TutorialDirector.Active.NotifyTutorialPanelClosed();
            }
        }

        completion?.TrySetResult();
    }

    private Vector3 GetOwlWorldPosition()
    {
        TutorialHighlightProxy owlProxy = FindProxy(OwlAnchorId);
        RectTransform owlRect = owlProxy != null ? owlProxy.Rect : null;
        return owlRect != null ? owlRect.TransformPoint(owlRect.rect.center) : Vector3.zero;
    }

    /// <summary>배치 프리셋에 따라 패널 앵커·피벗·위치를 설정한다 (크기는 프리팹 고정값 유지).</summary>
    private void ApplyPlacement(EPanelPlacement placement)
    {
        if (_panelRoot == null) return;

        Vector2 anchor;
        Vector2 offset;
        switch (placement)
        {
            case EPanelPlacement.Bottom:
                anchor = new Vector2(0.5f, 0f);
                offset = new Vector2(0f, _edgeMargin);
                break;
            case EPanelPlacement.Top:
                anchor = new Vector2(0.5f, 1f);
                offset = new Vector2(0f, -_edgeMargin);
                break;
            case EPanelPlacement.Left:
                anchor = new Vector2(0f, 0.5f);
                offset = new Vector2(_edgeMargin, 0f);
                break;
            case EPanelPlacement.Right:
                anchor = new Vector2(1f, 0.5f);
                offset = new Vector2(-_edgeMargin, 0f);
                break;
            default:
                anchor = new Vector2(0.5f, 0.5f);
                offset = Vector2.zero;
                break;
        }

        _panelRoot.anchorMin = anchor;
        _panelRoot.anchorMax = anchor;
        _panelRoot.pivot = anchor;
        _panelRoot.anchoredPosition = offset;
    }

    private void RefreshPage()
    {
        TutorialPageContent page = _pages.Count > 0 ? _pages[_pageIndex] : default;

        // 배치·프록시 강조는 페이지 단위 값을 따른다 (페이지 넘김마다 갱신).
        ApplyPlacement(page.Placement);
        DeactivateAllProxies();
        _requestedAnchorIds = page.AnchorIds ?? Array.Empty<string>();
        SyncProxies();

        if (_pageImage != null)
        {
            bool hasImage = page.Image != null;
            _pageImage.gameObject.SetActive(hasImage);
            if (hasImage) _pageImage.sprite = page.Image;
        }

        if (_pageText != null)
        {
            bool multiPage = _pages.Count > 1;
            _pageText.gameObject.SetActive(multiPage);
            if (multiPage)
                _pageText.text = $"{_pageIndex + 1}/{_pages.Count}";
        }

        // 이전 화살표: 이 패널 안에 되돌아갈 앞 페이지가 있을 때만 표시.
        if (_prevButton != null)
            _prevButton.gameObject.SetActive(_pageIndex > 0);

        RefreshLocalizedText();
    }

    private void RefreshLocalizedText()
    {
        TutorialPageContent page = _pages.Count > 0 ? _pages[_pageIndex] : default;

        if (_titleText != null) _titleText.text = Localize(_titleKey);
        if (_bodyText != null)
        {
            _bodyText.text = page.FormatArgs != null && LocalizationManager.HasInstance
                ? LocalizationManager.Instance.Get(page.BodyKey, page.FormatArgs)
                : Localize(page.BodyKey);
        }
    }

    private static string Localize(string key)
        => LocalizationManager.HasInstance ? LocalizationManager.Instance.Get(key) : key ?? string.Empty;

    private void OnDestroy()
    {
        _nextButton?.onClick.RemoveListener(HandleNext);
        _prevButton?.onClick.RemoveListener(HandlePrev);

        if (!_completed)
            _completion?.TrySetResult();
    }
}
