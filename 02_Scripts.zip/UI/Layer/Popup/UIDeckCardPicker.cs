// =================================================================
// [스크립트 목적]  런 덱에서 카드 1장을 고르고 확인받는 범용 선택 팝업.
//                 선택 결과는 cardId 가 아니라 RunDeckEntry.EntryId 로 통지한다.
// [주요 변수]      - _tileRoot/_tilePrefab : 타일 부모(그리드) / 타일 프리팹
//                  - _titleText/_cancelButton : 제목 / 취소 버튼
//                  - s_pending* : 열기 직전 주입되는 런 덱 엔트리·제목·확인문구
// [의존 관계]      - UIPopupBase / UIManager / UIDeckCardTile / UISystemConfirm / RunDeckEntry
// [배치]           UIManager 로 여는 Popup. 키 = 타입 이름(UIDeckCardPicker).
// [설계 노트]      - 표시용 카드는 SO 에서 만들되 RunDeckEntry.ArrowDirection 을 복원한다.
//                  - 실제 제거/강화 성공 여부는 호출부가 결정한다. 피커는 성공 전 자동으로 닫지 않는다.
//                  - viewOnly=true 로 열면 "전체 덱 열람" 용도(상단 바 덱 버튼) — 선택 불가.
// =================================================================

using System;
using System.Collections.Generic;
using Cysharp.Threading.Tasks;
using UnityEngine;
using TMPro;
using UnityEngine.UI;

/// <summary>
/// 런 덱에서 카드 1장을 고르는 범용 선택 팝업. 선택 확정 시 OnEntryConfirmed(entryId), 취소 시 OnCancelled.
/// </summary>
public sealed class UIDeckCardPicker : UIPopupBase
{
    [Header("타일")]
    [Tooltip("카드 타일이 들어갈 부모 (Grid Layout Group 권장)")]
    [SerializeField] private Transform _tileRoot;

    [Tooltip("카드 타일 프리팹 (UIDeckCardTile)")]
    [SerializeField] private UIDeckCardTile _tilePrefab;

    [Tooltip("카드 호버 시 키워드 설명을 띄우는 공유 패널. 비우면 표시 생략")]
    [SerializeField] private UIKeywordPanel _keywordPanel;

    [Header("공통")]
    [SerializeField] private TMP_Text _titleText;
    [SerializeField] private TMP_Text _messageText;
    [Tooltip("남은 제거 횟수 등 진행 표시(선택). 이벤트 다중 제거에서만 주입되어 켜진다.")]
    [SerializeField] private TMP_Text _progressText;

    [Tooltip("돌아가기 버튼")]
    [SerializeField] private Button _cancelButton;

    [Tooltip("돌아가기 버튼 텍스트")]
    [SerializeField] private TMP_Text _cancelButtonText;

    private readonly List<UIDeckCardTile> _tiles = new List<UIDeckCardTile>(32);
    private readonly List<RunDeckEntry> _entries = new List<RunDeckEntry>(32);
    private bool _resolved;
    private bool _confirmInProgress;
    private bool _closing;
    private int _messageVersion;
    private UISystemConfirm _confirmPopup;

    // 열기 직전 주입 (OpenAsync 인자 제약 우회).
    private static IReadOnlyList<RunDeckEntry> s_pendingEntries;
    private static string s_pendingTitle;
    private static string s_pendingConfirmMessage;
    private static bool s_pendingCancelable = true;
    private static bool s_pendingRequireConfirmation = true;
    private static bool s_pendingViewOnly;
    private static string s_pendingProgress;

    /// <summary>읽기 전용(열람) 모드인지. true 면 타일 클릭을 무시하고 돌아가기만 가능하다.</summary>
    public bool IsViewOnly { get; private set; }

    /// <summary>취소 가능한지. false 면(이벤트 강제 선택 등) 취소 버튼도 ESC 도 막힌다.</summary>
    private bool _cancelable = true;

    /// <summary>상점·강화·이벤트 등에서 버튼으로 연 하위 UI — ESC 로 닫고 부모로 돌아간다.</summary>
    public override bool CloseOnEscape => true;

    /// <summary>강제 선택(cancelable:false)은 ESC 로 빠져나갈 수 없다.</summary>
    public override bool OnBackPressed() => _cancelable;

    /// <summary>카드 선택 확정 — 선택한 RunDeckEntry.EntryId 통지. 호출부가 제거/강화 등 처리.</summary>
    public event Action<int> OnEntryConfirmed;

    /// <summary>선택 취소됨 (취소 버튼/딤). 호출부가 원상 흐름 처리.</summary>
    public event Action OnCancelled;

    /// <summary>
    /// 열기 직전 주입. entries=표시할 런 덱, title=제목, confirmMessage=확인 문구.
    /// viewOnly=true 면 선택 불가(열람 전용) — 타일 클릭 무시, 돌아가기만 가능.
    /// </summary>
    public static void Show(
        IReadOnlyList<RunDeckEntry> entries,
        string title = null,
        string confirmMessage = null,
        bool cancelable = true,
        bool requireConfirmation = true,
        bool viewOnly = false,
        string progressText = null)
    {
        s_pendingEntries = entries;
        s_pendingTitle = title;
        s_pendingConfirmMessage = confirmMessage;
        s_pendingCancelable = cancelable;
        s_pendingRequireConfirmation = requireConfirmation;
        s_pendingViewOnly = viewOnly;
        s_pendingProgress = progressText;
    }

    protected override void Init()
    {
        if (_keywordPanel == null)
            _keywordPanel = GetComponentInChildren<UIKeywordPanel>(true);

        RefreshLocalizedTexts();
        if (_cancelButton != null) _cancelButton.onClick.AddListener(HandleCancel);
    }

    protected override void Setup()
    {
        _resolved = false;
        _confirmInProgress = false;
        _closing = false;
        _messageVersion++;
        IsViewOnly = s_pendingViewOnly;
        _cancelable = s_pendingCancelable;

        SetTitle(s_pendingTitle);
        SetMessage(null);
        SetProgress(s_pendingProgress);
        RefreshLocalizedTexts();
        if (_cancelButton != null) _cancelButton.gameObject.SetActive(s_pendingCancelable);

        Rebuild(s_pendingEntries);
    }

    public override void OnLocalize()
    {
        base.OnLocalize();
        RefreshLocalizedTexts();
    }

    public override void OnClose()
    {
        _closing = true;

        // 타일 클릭으로 닫히면 포인터가 타일 위에 있어 OnPointerExit 이 오지 않는다.
        // 키워드 패널은 alpha 토글 방식이라 여기서 내리지 않으면 재오픈 시 그대로 떠 있는다.
        if (_keywordPanel != null) _keywordPanel.Hide();

        _messageVersion++;
        SetMessage(null);
        SetProgress(null);
        _confirmPopup?.Complete(ESystemConfirmResult.Cancel);
        _confirmPopup = null;

        if (!_resolved)
        {
            _resolved = true;
            OnCancelled?.Invoke();
        }

        Clear();
        _entries.Clear();
        s_pendingEntries = null;
        s_pendingTitle = null;
        s_pendingConfirmMessage = null;
        s_pendingCancelable = true;
        s_pendingRequireConfirmation = true;
        s_pendingViewOnly = false;
        s_pendingProgress = null;
        IsViewOnly = false;
        _cancelable = true;
        OnEntryConfirmed = null;
        OnCancelled = null;
        base.OnClose();
    }

    public void ShowMessageAndReturnToList(string message)
    {
        _resolved = false;
        _confirmInProgress = false;
        SetTitle(s_pendingTitle);
        int version = ++_messageVersion;
        SetMessage(message);
        Rebuild(s_pendingEntries);
        HideMessageAfterDelayAsync(version).Forget();
    }

    // ─────────────────────────────────────────────
    // 타일 구성
    // ─────────────────────────────────────────────

    private void Rebuild(IReadOnlyList<RunDeckEntry> entries)
    {
        Clear();
        _entries.Clear();

        if (_tilePrefab == null || _tileRoot == null || entries == null) return;
        if (!DataManager.HasInstance || !DataManager.Instance.IsLoaded) return;

        for (int i = 0; i < entries.Count; i++)
        {
            RunDeckEntry entry = entries[i];
            if (entry == null || string.IsNullOrEmpty(entry.CardId)) continue;

            CardDataSO so = DataManager.Instance.GetData<CardDataSO>(entry.CardId);
            if (so == null) continue;

            if (entry.RuntimeData == null)
                entry.SetRuntimeData(CardFactory.FromSO(so));
            if (!entry.HasArrowDirection)
                entry.EnsureArrowResolved();

            Card card = CardFactory.CreateFromSO(so, upgraded: false);
            if (card == null) continue;
            card.Arrow?.Restore(entry.ArrowDirection);
            // 미리보기도 각인된 코스트를 그대로 보여줘야 전투와 표기가 어긋나지 않는다.
            RunContext previewRun = InGameController.HasInstance
                ? InGameController.Instance.CurrentRun
                : null;
            if (previewRun != null)
            {
                int costDelta = previewRun.GetCardCostDelta(entry.EntryId);
                if (costDelta != 0) card.ApplyPermanentCostDelta(costDelta);
            }

            int captured = _entries.Count;
            _entries.Add(entry);

            // 풀에서 재사용(부족하면 생성). captured 는 _entries 내 인덱스이자 풀 슬롯 인덱스.
            UIDeckCardTile tile = GetOrCreateTile(captured);
            tile.gameObject.SetActive(true);
            tile.Bind(card, () => HandleTileClicked(captured));
            tile.SetClickable(!IsViewOnly);    // 열람 모드는 클릭 차단(hover는 유지)
            tile.SetKeywordPanel(_keywordPanel);
        }
    }

    // 표시 중인 타일을 모두 끈다(파괴하지 않고 풀로 반환 — 다음 Rebuild/오픈에서 재사용).
    private void Clear()
    {
        for (int i = 0; i < _tiles.Count; i++)
        {
            if (_tiles[i] != null) _tiles[i].gameObject.SetActive(false);
        }
    }

    // 풀 슬롯을 slot 까지 확보한다. 부족분만 새로 생성하고, 이미 있으면 재사용한다.
    private UIDeckCardTile GetOrCreateTile(int slot)
    {
        while (_tiles.Count <= slot)
            _tiles.Add(Instantiate(_tilePrefab, _tileRoot));

        // 외부 파괴 등으로 비어 있으면 해당 슬롯만 재생성.
        if (_tiles[slot] == null)
            _tiles[slot] = Instantiate(_tilePrefab, _tileRoot);

        return _tiles[slot];
    }

    // ─────────────────────────────────────────────
    // 선택 / 취소
    // ─────────────────────────────────────────────

    private void HandleTileClicked(int index)
    {
        if (IsViewOnly) return; // 열람 전용 — 선택 없음
        if (_resolved || _confirmInProgress) return;
        if (index < 0 || index >= _entries.Count) return;

        if (!s_pendingRequireConfirmation)
        {
            ResolveSelection(index);
            return;
        }

        ConfirmSelectionAsync(index).Forget();
    }

    private void HandleCancel()
    {
        if (_resolved) return;
        _resolved = true;
        OnCancelled?.Invoke();
        RequestClose();
    }

    private async UniTaskVoid ConfirmSelectionAsync(int index)
    {
        _confirmInProgress = true;

        try
        {
            if (!UIManager.HasInstance) return;

            _confirmPopup = await UIManager.Instance.OpenAsync<UISystemConfirm>();
            if (_confirmPopup == null) return;

            ESystemConfirmResult result = await _confirmPopup.ShowAsync(
                Localize(LocalizationKeys.Common.Confirm),
                string.IsNullOrEmpty(s_pendingConfirmMessage) ? Localize(LocalizationKeys.DeckPicker.DefaultConfirm) : s_pendingConfirmMessage,
                Localize(LocalizationKeys.Common.Yes),
                Localize(LocalizationKeys.Common.No));

            _confirmPopup = null;
            if (_closing) return;

            if (result != ESystemConfirmResult.Confirm)
            {
                SetTitle(s_pendingTitle);
                Rebuild(s_pendingEntries);
                return;
            }

            ResolveSelection(index);
        }
        finally
        {
            _confirmInProgress = false;
        }
    }

    private void ResolveSelection(int index)
    {
        if (index < 0 || index >= _entries.Count) return;
        RunDeckEntry entry = _entries[index];
        if (entry == null) return;

        _resolved = true;
#if UNITY_EDITOR || DEVELOPMENT_BUILD
        Debug.Log($"[UIDeckCardPicker] 카드 선택 확정 — entry={entry.EntryId}, card={entry.CardId}");
#endif
        OnEntryConfirmed?.Invoke(entry.EntryId);
    }

    private void SetTitle(string text)
    {
        if (_titleText != null && !string.IsNullOrEmpty(text))
            _titleText.text = text;
    }

    private void SetMessage(string text)
    {
        if (_messageText == null) return;
        bool visible = !string.IsNullOrEmpty(text);
        _messageText.text = visible ? text : string.Empty;
        _messageText.gameObject.SetActive(visible);
    }

    // 진행 표시(남은 제거 횟수 등). 주입된 경우에만 켜진다 → 이벤트 다중 제거 전용.
    private void SetProgress(string text)
    {
        if (_progressText == null) return;
        bool visible = !string.IsNullOrEmpty(text);
        _progressText.text = visible ? text : string.Empty;
        _progressText.gameObject.SetActive(visible);
    }

    private void RefreshLocalizedTexts()
    {
        if (_cancelButtonText != null)
            _cancelButtonText.text = Localize(LocalizationKeys.Common.Back);
    }

    private static string Localize(string key)
    {
        return LocalizationManager.HasInstance
            ? LocalizationManager.Instance.Get(key)
            : key;
    }

    private async UniTaskVoid HideMessageAfterDelayAsync(int version)
    {
        bool cancelled = await UniTask.Delay(
            TimeSpan.FromSeconds(2),
            cancellationToken: this.GetCancellationTokenOnDestroy()).SuppressCancellationThrow();
        if (!cancelled && version == _messageVersion)
            SetMessage(null);
    }

    private void OnDestroy()
    {
        if (_cancelButton != null) _cancelButton.onClick.RemoveListener(HandleCancel);
        OnEntryConfirmed = null;
        OnCancelled = null;
    }
}
