// =================================================================
// [스크립트 목적]  삽화형 튜토리얼 안내 패널. 로직은 UITutorialPanel 을 그대로 상속하고,
//                 타입만 분리한다 (UIManager 가 UI 를 타입 기준으로 캐시·재사용하므로
//                 같은 클래스로 프리팹 2개를 만들면 캐시가 섞인다 — 이를 방지).
// [의존 관계]      - UITutorialPanel(전체 로직) / TutorialDirector(삽화 스텝에서 선택)
// [배치]           삽화 중심 레이아웃(이미지 크게 + 텍스트) 프리팹에 부착,
//                  Addressable "UITutorialIllustPanel" 등록. _pageImage 연결 필수.
// =================================================================

/// <summary>
/// 삽화형 안내 패널. 페이지에 이미지가 있는 스텝에서 TutorialDirector 가 선택한다.
/// 동작은 UITutorialPanel 과 동일하며 프리팹(레이아웃)만 다르다.
/// </summary>
public sealed class UITutorialIllustPanel : UITutorialPanel
{
}
