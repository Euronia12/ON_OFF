// =================================================================
// [스크립트 목적]  전투 승리 통합 보상창("전리품!"). 골드·카드 등 보상 항목을 리스트로
//                 미리 보여주고, "계속" 버튼 일괄 수령 + 행 클릭 개별 수령을 지원한다.
// [주요 변수]      - _rowRoot/_rowPrefab : 보상 행이 들어갈 부모 / 행 프리팹 (표시+클릭 통지)
//                  - _continueButton     : 전부 수령 + 다음 진행(맵 복귀/다음 전투) 버튼
//                  - _reward             : 현재 열려있는 보상 묶음
//                  - _rows               : 생성된 행 목록 (정리·진행 표시 갱신용)
//                  - s_pending           : 열기 직전 주입되는 보상 묶음 (OpenAsync 인자 제약 우회)
// [의존 관계]      - UIPopupBase / UIManager / UIRewardRow / UICardSelectPopup
//                  - BattleReward / BattleRewardItem / EBattleRewardKind
//                  - InGameController 가 Show 로 보상 주입 + 콜백 구독
// [배치]           UIManager 로 여는 Popup. 키 = 타입 이름(UIRewardPopup).
//                  씬 상주 금지 — 프리팹 등록, 열 때 Instantiate.
// [이름 정리]      - UIRewardPopup     = "전리품 리스트 창" (이 클래스)
//                  - UICardSelectPopup = "카드 1택 선택 창" (계속 처리 중 카드 항목이 있으면 자동으로 띄움)
//                  - UIGameOverPopup   = "패배 화면" (재시작/타이틀)
// [설계 노트]      - 수령 흐름 두 가지 공존: "계속" 일괄 수령 + 행 클릭 개별 수령.
//                    (일괄만 있던 시기를 거쳐, 원하는 항목만 골라 받는 흐름을 다시 추가.
//                    개별 수령 후에도 "계속"은 남은 미수령 항목만 처리하고 진행한다.)
//                  - 수령한 행은 즉시 제거하고, 전 항목 수령 시 자동으로 다음 진행(닫기).
//                  - 수령 처리 공용 규칙(ResolveItemAsync): 골드 등 선택지 없는 항목은
//                    즉시 수령 처리하고, 카드처럼 선택이 필요한 항목은 UICardSelectPopup 을
//                    열어 선택/스킵을 받는다. "계속"은 전 항목 순회 후 다음 흐름 요청 + 닫기.
//                  - 개별 수령 진행 중(_resolving)에는 다른 행 클릭/"계속"을 막는다.
// =================================================================

using System;
using System.Collections.Generic;
using System.Threading;
using Cysharp.Threading.Tasks;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// 전투 승리 보상을 리스트로 미리 보여주는 팝업. "계속" 버튼 일괄 수령과
/// 행 클릭 개별 수령이 공존한다. 골드는 즉시 수령, 카드는 1택 팝업을 자동으로 띄운다.
/// 보상 생성·적용(덱/골드 반영)은 컨트롤러가 콜백으로 처리하고, 이 창은 표시·진행 중계만 한다.
/// </summary>
public sealed class UIRewardPopup : UIPopupBase
{
    [Header("보상 리스트")]
    [Tooltip("보상 행이 들어갈 부모 (세로 레이아웃 권장)")]
    [SerializeField] private Transform _rowRoot;

    [Tooltip("보상 행 프리팹 (UIRewardRow, 표시 전용)")]
    [SerializeField] private UIRewardRow _rowPrefab;

    [Header("진행")]
    [Tooltip("전부 수령 + 다음 진행(맵 복귀/다음 전투) 버튼")]
    [SerializeField] private Button _continueButton;

    [Header("고정 텍스트")]
    [Tooltip("팝업 타이틀 텍스트")]
    [SerializeField] private TMP_Text _titleText;

    [Tooltip("모두 받기 버튼 텍스트")]
    [SerializeField] private TMP_Text _claimAllButtonText;

    private readonly List<UIRewardRow> _rows = new List<UIRewardRow>(8);

    private BattleReward _reward;
    private bool _resolving;
    private bool _keepCardSelectionOpen;
    private CancellationTokenSource _openLifetimeCts;
    private UICardSelectPopup _activeCardPopup;

    // OpenAsync 가 인자를 못 받으므로, 열기 직전에 보상 묶음을 정적으로 예약.
    private static BattleReward s_pending;

    /// <summary>골드 항목 자동 수령 (컨트롤러가 적립·발행 후 해당 항목 Claimed 처리).</summary>
    public event Action<BattleRewardItem> OnGoldClaimRequested;

    /// <summary>카드 1택 완료 → 선택 카드 ID 통지 (스킵이면 null). 컨트롤러가 덱 반영.</summary>
    public event Action<string> OnCardChosen;
    public event Action<string, ECardDirection> OnCardChosenWithDirection;
    public event Action<BattleRewardItem, string, ECardDirection> OnCardItemChosen;

    /// <summary>모든 보상 수령 완료 → 다음 진행(계속) 요청. 컨트롤러가 맵 복귀/다음 전투 처리.</summary>
    public event Action OnContinueRequested;

    /// <summary>열기 직전 보상 묶음 주입 (InGameController 가 OpenAsync 직전 호출).</summary>
    public static void Show(BattleReward reward) => s_pending = reward;

    protected override void Init()
    {
        RefreshLocalizedTexts();
        if (_continueButton != null) _continueButton.onClick.AddListener(HandleContinueClicked);
    }

    public override void OnLocalize()
    {
        base.OnLocalize();
        RefreshLocalizedTexts();
    }

    private void RefreshLocalizedTexts()
    {
        if (_titleText != null)
            _titleText.text = Localize(LocalizationKeys.Reward.PopupTitle);
        if (_claimAllButtonText != null)
            _claimAllButtonText.text = Localize(LocalizationKeys.Reward.ClaimAll);

        // 행 라벨은 Bind 시점에 조립되므로 언어가 바뀌면 여기서 다시 갱신해 준다.
        // (행은 표시 전용 — 생성/파괴와 갱신 주체를 모두 이 팝업이 쥔다)
        for (int i = 0; i < _rows.Count; i++)
            if (_rows[i] != null) _rows[i].Refresh();
    }

    private static string Localize(string key)
    {
        return LocalizationManager.HasInstance
            ? LocalizationManager.Instance.Get(key)
            : key;
    }

    /// <summary>열 때마다 예약된 보상 묶음으로 행을 재구성.</summary>
    protected override void Setup()
    {
        EndOpenLifetime();
        _openLifetimeCts = CancellationTokenSource.CreateLinkedTokenSource(
            this.GetCancellationTokenOnDestroy());
        _reward = s_pending;
        _resolving = false;
        _keepCardSelectionOpen = false;
        Rebuild(_reward);
        if (_continueButton != null) _continueButton.interactable = true;
    }

    public override void OnClose()
    {
        EndOpenLifetime();
        CloseActiveCardPopupSilently();
        Clear();
        _reward = null;
        _resolving = false;
        _keepCardSelectionOpen = false;
        s_pending = null;

        // 캐시되는 Screen UI 라 씬 전환에도 파괴되지 않는다(OnDestroy 미호출).
        // 닫힐 때 구독을 비워, 씬 종속 컨트롤러(SceneSingleton)가 교체될 때
        // 죽은 이전 컨트롤러의 구독이 남아 다음 열림에서 항목을 가로채는 것을 막는다.
        // (컨트롤러는 열 때마다 재구독하므로 여기서 비워도 안전하다.)
        OnGoldClaimRequested = null;
        OnCardChosen = null;
        OnCardChosenWithDirection = null;
        OnCardItemChosen = null;
        OnContinueRequested = null;

        base.OnClose();
    }

    private CancellationToken OpenLifetimeToken =>
        _openLifetimeCts?.Token ?? this.GetCancellationTokenOnDestroy();

    private void EndOpenLifetime()
    {
        if (_openLifetimeCts == null) return;
        _openLifetimeCts.Cancel();
        _openLifetimeCts.Dispose();
        _openLifetimeCts = null;
    }

    private void CloseActiveCardPopupSilently()
    {
        UICardSelectPopup popup = _activeCardPopup;
        _activeCardPopup = null;
        if (popup == null || !popup.IsOpen || !UIManager.HasInstance) return;
        popup.SuppressResolutionOnClose();
        UIManager.Instance.Close(popup);
    }

    private void RestoreInteractionAfterFailure()
    {
        if (!IsOpen) return;
        _resolving = false;
        if (_continueButton != null) _continueButton.interactable = true;
    }

    // ─────────────────────────────────────────────
    // 행 구성 (표시 전용)
    // ─────────────────────────────────────────────

    private void Rebuild(BattleReward reward)
    {
        Clear();

        if (_rowPrefab == null || _rowRoot == null || reward == null) return;

        IReadOnlyList<BattleRewardItem> items = reward.Items;
        for (int i = 0; i < items.Count; i++)
        {
            BattleRewardItem item = items[i];
            if (item == null) continue;

            UIRewardRow row = Instantiate(_rowPrefab, _rowRoot);
            row.Bind(item);
            row.OnClaimRequested += HandleRowClaimRequested;
            _rows.Add(row);
        }
    }

    public void RefreshDebugReward(BattleReward reward)
    {
        if (_resolving) return;
        if (reward == null) return;
        _reward = reward;
        Rebuild(_reward);
    }

    private void Clear()
    {
        for (int i = 0; i < _rows.Count; i++)
        {
            if (_rows[i] == null) continue;
            _rows[i].OnClaimRequested -= HandleRowClaimRequested;
            _rows[i].gameObject.SetActive(false);
            Destroy(_rows[i].gameObject);
        }
        _rows.Clear();
    }

    // ─────────────────────────────────────────────
    // "계속" — 전부 일괄 수령 후 다음 진행
    // ─────────────────────────────────────────────

    private void HandleContinueClicked()
    {
        if (_resolving) return;
        ResolveAllAndContinueAsync().Forget();
    }

    /// <summary>보상 항목을 순서대로 일괄 수령한다. 골드는 즉시, 카드는 1택 팝업을 거친다.</summary>
    private async UniTaskVoid ResolveAllAndContinueAsync()
    {
        _resolving = true;
        _keepCardSelectionOpen = true;
        if (_continueButton != null) _continueButton.interactable = false;
        CancellationToken token = OpenLifetimeToken;
        bool completedAll = false;

        try
        {
            if (_reward != null)
            {
                IReadOnlyList<BattleRewardItem> items = _reward.Items;
                for (int i = 0; i < items.Count; i++)
                {
                    BattleRewardItem item = items[i];
                    if (item == null || item.Claimed) continue;

                    await ResolveItemAsync(item, token);
                    RemoveClaimedRows();
                }
            }
            if (!AllClaimed())
                throw new InvalidOperationException(
                    "[UIRewardPopup] 모두 받기 완료 후 미처리 보상 항목이 남았습니다.");
            completedAll = true;
        }
        catch (OperationCanceledException)
        {
            return;
        }
        catch (Exception e)
        {
            Debug.LogException(e);
            RestoreInteractionAfterFailure();
            return;
        }
        finally
        {
            _keepCardSelectionOpen = false;
            CloseActiveCardPopupSilently();
        }

        if (!completedAll || token.IsCancellationRequested) return;
        try
        {
            OnContinueRequested?.Invoke();
        }
        catch (Exception e)
        {
            Debug.LogException(e);
        }
        RequestClose();
    }

    // ─────────────────────────────────────────────
    // 행 클릭 — 해당 항목만 개별 수령
    // ─────────────────────────────────────────────

    /// <summary>행 클릭 통지 (UIRewardRow 가 미수령 항목만 올림).</summary>
    private void HandleRowClaimRequested(UIRewardRow row)
    {
        if (_resolving || row == null) return;
        ResolveSingleAsync(row.Item).Forget();
    }

    /// <summary>항목 1개만 수령한다. 처리 중에는 다른 클릭/계속 버튼을 막는다.</summary>
    private async UniTaskVoid ResolveSingleAsync(BattleRewardItem item)
    {
        if (item == null || item.Claimed) return;

        _resolving = true;
        if (_continueButton != null) _continueButton.interactable = false;
        CancellationToken token = OpenLifetimeToken;

        try
        {
            await ResolveItemAsync(item, token);
            RemoveClaimedRows();
        }
        catch (OperationCanceledException)
        {
            return;
        }
        catch (Exception e)
        {
            Debug.LogException(e);
            CloseActiveCardPopupSilently();
            RestoreInteractionAfterFailure();
            return;
        }

        // 모든 보상을 받았으면 "계속" 클릭 없이 자동으로 다음 진행.
        if (AllClaimed())
        {
            try
            {
                OnContinueRequested?.Invoke();
            }
            catch (Exception e)
            {
                Debug.LogException(e);
            }
            RequestClose();
            return; // _resolving 유지 — 닫히는 동안 추가 입력 차단
        }

        _resolving = false;
        if (_continueButton != null) _continueButton.interactable = true;
    }

    /// <summary>수령 완료된 행을 즉시 제거해 남은 보상만 보이게 한다.</summary>
    private void RemoveClaimedRows()
    {
        for (int i = _rows.Count - 1; i >= 0; i--)
        {
            UIRewardRow row = _rows[i];
            if (row != null && row.Item != null && !row.Item.Claimed) continue;

            if (row != null) Destroy(row.gameObject);
            _rows.RemoveAt(i);
        }
    }

    /// <summary>모든 항목 수령 완료 여부.</summary>
    private bool AllClaimed()
    {
        if (_reward == null) return true;

        IReadOnlyList<BattleRewardItem> items = _reward.Items;
        for (int i = 0; i < items.Count; i++)
        {
            BattleRewardItem item = items[i];
            if (item != null && !item.Claimed) return false;
        }
        return true;
    }

    /// <summary>항목 1개 수령 처리 — 골드는 즉시, 카드는 1택 팝업. (일괄/개별 공용)</summary>
    private async UniTask ResolveItemAsync(BattleRewardItem item, CancellationToken token)
    {
        switch (item.Kind)
        {
            case EBattleRewardKind.Gold:
                // 컨트롤러가 실제 적립·이벤트 발행 + item.MarkClaimed 처리.
                OnGoldClaimRequested?.Invoke(item);
                break;

            case EBattleRewardKind.Card:
                await ResolveCardAsync(item, token);
                break;

            case EBattleRewardKind.GridExpansion:
                await ShowGridExpansionNoticeAsync(token);
                item.MarkClaimed();
                break;

            default:
                // 미지원 종류는 일단 수령 완료 처리만 (확장 시 분기 추가).
                item.MarkClaimed();
                break;
        }
    }

    /// <summary>그리드 확장 안내 항목 수령 시 시스템 내비 메시지를 표시한다.</summary>
    private async UniTask ShowGridExpansionNoticeAsync(CancellationToken token)
    {
        if (!UIManager.HasInstance) return;

        UISystemNavi systemNavi = await UIManager.Instance.OpenAsync<UISystemNavi>(
            token);
        if (systemNavi != null)
            await systemNavi.ShowAsync(
                LocalizationKeys.Reward.GridExpansionNotice,
                token);
    }

    /// <summary>카드 항목 — 1택 팝업(UICardSelectPopup)을 열고 결과를 받아 통지한다.</summary>
    private async UniTask ResolveCardAsync(BattleRewardItem item, CancellationToken token)
    {
        IReadOnlyList<CardDataSO> candidates = item.CardCandidates;
        if (candidates == null || candidates.Count == 0 || !UIManager.HasInstance)
        {
            // 후보 없음(또는 UI 불가) — 빈 카드 항목. 스킵 처리.
            item.MarkClaimedCard(null);
            return;
        }

        UICardSelectPopup popup = await OpenCardSelectAsync(
            candidates, item.CardCandidateDirections, token);
        if (popup == null)
        {
            item.MarkClaimedCard(null);
            return;
        }

        UniTaskCompletionSource<(string CardId, ECardDirection Direction)> tcs =
            new UniTaskCompletionSource<(string, ECardDirection)>();

        void OnResolved(string acquiredId, ECardDirection direction)
        {
            popup.OnCardResolved -= OnResolved;
            tcs.TrySetResult((acquiredId, direction));
        }

        popup.OnCardResolved += OnResolved;
        try
        {
            await TutorialShowcaseSequence.ShowCardSelectGuideIfPendingAsync(token);

            // 선택/스킵까지 대기. 모두 받기에서는 같은 팝업을 유지하고 후보만 교체한다.
            (string chosen, ECardDirection direction) =
                await tcs.Task.AttachExternalCancellation(token);

            // 실제 덱 반영·저장이 성공한 뒤에만 UI 보상 항목을 확정한다.
            OnCardItemChosen?.Invoke(item, chosen, direction);
            if (OnCardChosenWithDirection != null)
                OnCardChosenWithDirection.Invoke(chosen, direction);
            else
                OnCardChosen?.Invoke(chosen);
            item.MarkClaimedCard(chosen);

            // 현재 슬롯은 위에서 즉시 반영·저장한다. 다음 프레임에 모두 받기는 같은 팝업의
            // 후보를 갱신하고, 개별 받기는 닫힌 캐시 팝업을 안전하게 다시 열 수 있다.
            await UniTask.Yield(PlayerLoopTiming.Update, token);
        }
        finally
        {
            popup.OnCardResolved -= OnResolved;
            if (_activeCardPopup == popup && !popup.IsOpen)
                _activeCardPopup = null;
        }
    }

    /// <summary>후보를 예약(Show)한 뒤 카드 선택 팝업을 연다. (예약→OpenAsync 순서 중요)</summary>
    private async UniTask<UICardSelectPopup> OpenCardSelectAsync(
        IReadOnlyList<CardDataSO> candidates,
        IReadOnlyList<ECardDirection> directions,
        CancellationToken token)
    {
        // 이벤트 보상은 체크포인트에 확정 저장된 방향을 전달한다. 저장 방향이 없는
        // 일반 전투 보상에만 난이도별(Dev) 방향 생성 규칙을 적용해 두 흐름을 섞지 않는다.
        IReadOnlyList<ECardDirection> resolvedDirections = directions;
        if ((resolvedDirections == null || resolvedDirections.Count == 0) &&
            InGameController.HasInstance)
        {
            resolvedDirections =
                InGameController.Instance.CreateRewardArrowDirections(candidates);
        }

        UICardSelectPopup open = _keepCardSelectionOpen && UIManager.HasInstance
            ? UIManager.Instance.Get<UICardSelectPopup>()
            : null;
        if (open != null && open.IsOpen)
        {
            await open.WaitForResolvePresentationAsync(token);
            open.RefreshCandidates(candidates, resolvedDirections, keepOpenAfterResolve: true);
            _activeCardPopup = open;
            return open;
        }

        UICardSelectPopup.Show(
            candidates, resolvedDirections, keepOpenAfterResolve: _keepCardSelectionOpen);
        UICardSelectPopup popup = await UIManager.Instance.OpenAsync<UICardSelectPopup>(token);
        _activeCardPopup = popup;
        return popup;
    }

    private void OnDestroy()
    {
        EndOpenLifetime();
        CloseActiveCardPopupSilently();
        if (_continueButton != null) _continueButton.onClick.RemoveListener(HandleContinueClicked);
        OnGoldClaimRequested = null;
        OnCardChosen = null;
        OnCardChosenWithDirection = null;
        OnCardItemChosen = null;
        OnContinueRequested = null;
    }
}
