using System;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

/// <summary>F2 카드 지급 프리팹용 UI. 카드 목록과 수량·방향 입력을 표시하고 요청만 발행한다.</summary>
public sealed class UIDebugCard : UIDebugPopupBase
{
    [SerializeField] private TMP_InputField _searchInput;
    [SerializeField] private TMP_Dropdown _cardDropdown;
    [SerializeField] private Toggle _useDefaultDirectionToggle;
    [SerializeField] private Toggle _upToggle;
    [SerializeField] private Toggle _downToggle;
    [SerializeField] private Toggle _leftToggle;
    [SerializeField] private Toggle _rightToggle;
    [SerializeField] private TMP_InputField _countInput;
    [SerializeField] private Button _addButton;
    [SerializeField] private TMP_Text _messageText;

    private readonly List<CardDataSO> _cards = new();
    public event Action<CardDataSO, int, ECardDirection?> OnAddRequested;

    protected override void Init()
    {
        base.Init();
        _addButton?.onClick.AddListener(HandleAdd);
        _searchInput?.onValueChanged.AddListener(RefreshOptions);
    }

    public void Bind(IReadOnlyList<CardDataSO> cards)
    {
        _cards.Clear();
        if (cards != null) _cards.AddRange(cards);
        RefreshOptions(_searchInput != null ? _searchInput.text : string.Empty);
    }

    public void SetMessage(string message)
    {
        if (_messageText != null) _messageText.text = message ?? string.Empty;
    }

    private void RefreshOptions(string search)
    {
        if (_cardDropdown == null) return;
        _cardDropdown.ClearOptions();
        var options = new List<TMP_Dropdown.OptionData>();
        for (int i = 0; i < _cards.Count; i++)
        {
            CardDataSO card = _cards[i];
            if (card == null || !Matches(card, search)) continue;
            options.Add(new TMP_Dropdown.OptionData($"{card.CardId} | {card.DisplayNameKey}"));
        }
        _cardDropdown.AddOptions(options);
        _cardDropdown.RefreshShownValue();
    }

    private void HandleAdd()
    {
        CardDataSO selected = GetSelectedCard();
        if (selected == null || !int.TryParse(_countInput?.text, out int count) || count < 1 || count > 99)
        {
            SetMessage("카드와 1~99 수량을 확인하세요.");
            return;
        }

        ECardDirection direction = ECardDirection.None;
        if (_upToggle != null && _upToggle.isOn) direction |= ECardDirection.Up;
        if (_downToggle != null && _downToggle.isOn) direction |= ECardDirection.Down;
        if (_leftToggle != null && _leftToggle.isOn) direction |= ECardDirection.Left;
        if (_rightToggle != null && _rightToggle.isOn) direction |= ECardDirection.Right;
        bool useDefault = _useDefaultDirectionToggle == null || _useDefaultDirectionToggle.isOn;
        if (!useDefault && direction == ECardDirection.None)
        {
            SetMessage("수동 방향을 하나 이상 선택하세요.");
            return;
        }
        OnAddRequested?.Invoke(selected, count, useDefault ? null : direction);
    }

    private CardDataSO GetSelectedCard()
    {
        if (_cardDropdown == null) return null;
        string label = _cardDropdown.options.Count > _cardDropdown.value
            ? _cardDropdown.options[_cardDropdown.value].text : string.Empty;
        for (int i = 0; i < _cards.Count; i++)
            if (_cards[i] != null && label.StartsWith(_cards[i].CardId + " |", StringComparison.Ordinal)) return _cards[i];
        return null;
    }

    private static bool Matches(CardDataSO card, string search)
        => string.IsNullOrWhiteSpace(search) ||
           card.CardId.IndexOf(search, StringComparison.OrdinalIgnoreCase) >= 0 ||
           (card.DisplayNameKey?.IndexOf(search, StringComparison.OrdinalIgnoreCase) ?? -1) >= 0;
}
