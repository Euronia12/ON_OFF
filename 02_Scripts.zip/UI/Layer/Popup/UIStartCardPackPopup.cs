using System;
using System.Collections;
using System.Collections.Generic;
using Cysharp.Threading.Tasks;
using DG.Tweening;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

/// <summary>확정된 시작 카드팩 획득 결과 1장 (카드 데이터 + 확정 시점에 굴려 고정한 화살표 방향).</summary>
public readonly struct StartCardPackResult
{
    public readonly CardDataSO CardData;
    public readonly ECardDirection Direction;

    public StartCardPackResult(CardDataSO cardData, ECardDirection direction)
    {
        CardData = cardData;
        Direction = direction;
    }

    public string CardId => CardData != null ? CardData.CardId : string.Empty;
}

/// <summary>Start 카드팩을 하나 고른 뒤 확정하는 팝업.</summary>
public sealed class UIStartCardPackPopup : UIPopupBase
{
    private const int RequiredSelectionCount = 1;
    private const int PreviewCardLimit = 3;
    private const float PackScale = 2f;
    private const float DetachedTargetY = 800f;
    private const float CardRevealY = 350f;
    private const float CardExitY = -700f;
    private const float PackExitY = 800f;
    private const float TooltipGap = 16f;

    [Header("카드팩")]
    [SerializeField] private UIStartCardPackItem _itemPrefab;
    [SerializeField] private RectTransform _contentRoot;

    [Header("안내")]
    [SerializeField] private TMP_Text _pickupDescriptionText;
    [SerializeField] private TMP_Text _selectionCountText;

    [Header("설명 툴팁")]
    [SerializeField] private RectTransform _tooltipRoot;
    [SerializeField] private TMP_Text _descriptionText;

    [Serializable]
    private sealed class CardContentsSlot
    {
        [SerializeField] private GameObject _root;
        [SerializeField] private Image _icon;
        [SerializeField] private TMP_Text _nameText;
        [SerializeField] private UIHoverIntentSource _hoverSource;

        public GameObject Root => _root;
        public Image Icon => _icon;
        public TMP_Text NameText => _nameText;
        public UIHoverIntentSource HoverSource => _hoverSource;
        public CardDataSO BoundCard { get; set; }
        public Card PreviewCard { get; set; }
    }

    [Header("카드 구성 툴팁")]
    [SerializeField] private RectTransform _cardContentsRoot;
    [SerializeField] private UIHoverIntentTooltip _cardContentsTooltip;
    [SerializeField] private TMP_Text _cardContentsTitleText;
    [SerializeField] private CardContentsSlot[] _cardContentsSlots;
    [SerializeField] private GameObject _cardContentsEtcRoot;
    [SerializeField] private UIHoverIntentSource _cardContentsEtcSource;
    [SerializeField] private RectTransform _cardContentsExtraRoot;
    [SerializeField] private UIHoverIntentTooltip _cardContentsExtraTooltip;
    [SerializeField] private ScrollRect _cardContentsExtraScroll;
    [SerializeField] private TMP_Text _cardContentsExtraNamesText;
    [SerializeField] private RectTransform _cardContentsPreviewRoot;
    [SerializeField] private UIHoverIntentTooltip _cardContentsPreviewTooltip;
    [SerializeField] private UICardDetailView _cardContentsPreviewView;

    [Header("확정")]
    [SerializeField] private Button _confirmButton;
    [SerializeField] private TMP_Text _confirmButtonText;
    [SerializeField] private Toggle _skipOpeningAnimationToggle;
    [SerializeField] private TMP_Text _skipOpeningAnimationText;

    [Header("개봉 연출")]
    [SerializeField] private RectTransform _openingRoot;
    [SerializeField] private UICard _cardVisualPrefab;
    [SerializeField] private bool _skipOpeningAnimation;
    [SerializeField, Min(0f)] private float _centerMoveDuration = 0.5f;
    [SerializeField, Min(0f)] private float _cutDuration = 2f;
    [SerializeField, Min(0f)] private float _detachedMoveDuration = 0.5f;
    [SerializeField, Min(0f)] private float _cardMoveDuration = 0.5f;
    [SerializeField, Min(0f)] private float _cardExitDuration = 0.5f;
    [SerializeField, Min(0f)] private float _packExitDuration = 0.5f;

    private static IReadOnlyList<StartCardPackSO> s_pendingPacks;
    private static int s_pendingRunSeed;

    private readonly List<UIStartCardPackItem> _items = new List<UIStartCardPackItem>();
    private readonly List<StartCardPackSO> _selected = new List<StartCardPackSO>(RequiredSelectionCount);
    private readonly List<UICard> _openingCards = new List<UICard>();
    private readonly List<CardDataSO> _cardContentsCandidates = new List<CardDataSO>();

    // 확정 시점에 고정한 카드·방향 결과. 연출 비주얼과 실제 덱 추가가 이 값을 공유한다.
    private readonly Dictionary<StartCardPackSO, List<StartCardPackResult>> _resolvedResultsByPack =
        new Dictionary<StartCardPackSO, List<StartCardPackResult>>(RequiredSelectionCount);
    // OnConfirmed 로 넘길 평탄화된 획득 결과.
    private readonly List<StartCardPackResult> _confirmedResults = new List<StartCardPackResult>();

    private UIStartCardPackItem _hoveredItem;
    private UIStartCardPackItem _hoveredContentsItem;
    private int _cardContentsLoadVersion;
    private Coroutine _openingRoutine;
    private Tween _openingTween;
    private bool _resolved;
    private bool _suppressContentsFallback;

    public event Action<IReadOnlyList<StartCardPackResult>> OnConfirmed;

    // 확정 시점에 고정되는 선택 팩 ID 스냅샷 (분석용).
    private readonly List<string> _selectedPackIds = new List<string>(RequiredSelectionCount);

    /// <summary>선택 확정된 카드팩 ID 목록. 확정 전에는 비어 있다.</summary>
    public IReadOnlyList<string> SelectedPackIds => _selectedPackIds;

    public static void Show(IReadOnlyList<StartCardPackSO> packs, int runSeed)
    {
        s_pendingPacks = packs;
        s_pendingRunSeed = runSeed;
    }

    protected override void Init()
    {
        _confirmButton?.onClick.AddListener(HandleConfirm);
        _skipOpeningAnimationToggle?.onValueChanged.AddListener(HandleSkipOpeningAnimationChanged);
        _cardContentsEtcSource?.Bind(
            _cardContentsExtraTooltip,
            ShowExtraCardNamesTooltip);

        if (_cardContentsSlots == null) return;
        for (int i = 0; i < _cardContentsSlots.Length; i++)
        {
            CardContentsSlot slot = _cardContentsSlots[i];
            if (slot?.HoverSource == null) continue;
            slot.HoverSource.Bind(
                _cardContentsPreviewTooltip,
                () => ShowCardPreviewTooltip(slot));
        }
    }

    protected override void Setup()
    {
        ClearItems();
        _selected.Clear();
        _hoveredItem = null;
        _hoveredContentsItem = null;
        _resolved = false;
        CleanupOpeningAnimation();
        if (SettingsManager.HasInstance && SettingsManager.Instance.Current != null)
            _skipOpeningAnimation = SettingsManager.Instance.Current.SkipStartCardPackOpeningAnimation;
        _skipOpeningAnimationToggle?.SetIsOnWithoutNotify(_skipOpeningAnimation);
        SetSelectionUiVisible(true);
        SetTooltipVisible(false);
        CloseCardContentsTooltipBranch();
        ResetCardContentsTooltip();

        if (s_pendingPacks != null && _itemPrefab != null && _contentRoot != null)
        {
            for (int i = 0; i < s_pendingPacks.Count; i++)
            {
                StartCardPackSO pack = s_pendingPacks[i];
                if (pack == null) continue;

                UIStartCardPackItem item = Instantiate(_itemPrefab, _contentRoot, false);
                item.Bind(pack, ToggleSelection, ShowTooltip, HideTooltip, _cardContentsTooltip,
                    ShowCardContentsTooltip, HideCardContentsTooltip);
                _items.Add(item);
            }
        }

        RefreshSelectionState();
    }

    public override void OnLocalize()
    {
        base.OnLocalize();
        if (_pickupDescriptionText != null)
            _pickupDescriptionText.text = Localize(LocalizationKeys.StartCardPack.PickupDescription);

        if (_confirmButtonText != null)
            _confirmButtonText.text = Localize(LocalizationKeys.Common.Confirm);

        if (_skipOpeningAnimationText != null)
            _skipOpeningAnimationText.text = Localize(LocalizationKeys.StartCardPack.SkipOpeningAnimation);

        SetLocalizedText(_cardContentsTitleText, LocalizationKeys.StartCardPack.ContentsTitle);

        if (_hoveredItem != null)
            SetDescription(_hoveredItem.Data);
        if (_hoveredContentsItem != null)
            RefreshCardContentsTexts();
    }

    private static void SetLocalizedText(TMP_Text text, string key)
    {
        if (text != null)
            text.text = LocalizationManager.HasInstance ? LocalizationManager.Instance.Get(key) : key;
    }

    public override void OnClose()
    {
        CleanupOpeningAnimation();
        ClearItems();
        _selected.Clear();
        _resolvedResultsByPack.Clear();
        _confirmedResults.Clear();
        _hoveredItem = null;
        _hoveredContentsItem = null;
        CloseCardContentsTooltipBranch();
        ResetCardContentsTooltip();
        _resolved = false;
        s_pendingPacks = null;
        s_pendingRunSeed = 0;
        OnConfirmed = null;
        base.OnClose();
    }

    private void ToggleSelection(UIStartCardPackItem item)
    {
        if (_resolved || item?.Data == null || !item.Data.IsUnlocked) return;

        int index = _selected.IndexOf(item.Data);
        if (index >= 0)
            _selected.RemoveAt(index);
        else
        {
            _selected.Clear();
            _selected.Add(item.Data);
        }

        RefreshSelectionState();
    }

    private void RefreshSelectionState()
    {
        for (int i = 0; i < _items.Count; i++)
        {
            UIStartCardPackItem item = _items[i];
            if (item != null)
                item.SetSelected(item.Data != null && _selected.Contains(item.Data));
        }

        if (_confirmButton != null)
            _confirmButton.interactable = !_resolved && _selected.Count == RequiredSelectionCount;

        if (_selectionCountText != null)
            _selectionCountText.text = $"{_selected.Count}/{RequiredSelectionCount}";
    }

    private void ShowTooltip(UIStartCardPackItem item)
    {
        if (item?.Data == null || _tooltipRoot == null) return;

        CloseCardContentsTooltipBranch();
        _hoveredItem = item;
        SetDescription(item.Data);
        SetTooltipVisible(true);
        MovePanelNextTo(_tooltipRoot, item.RectTransform);
    }

    private void HideTooltip(UIStartCardPackItem item)
    {
        if (_hoveredItem != item) return;
        _hoveredItem = null;
        SetTooltipVisible(false);
    }

    private void ShowCardContentsTooltip(UIStartCardPackItem item)
    {
        if (item?.Data == null || _cardContentsRoot == null) return;

        _hoveredItem = null;
        SetTooltipVisible(false);
        ResetCardContentsTooltip();
        _hoveredContentsItem = item;

        IReadOnlyList<CardDataSO> cards = item.Data.Cards;
        if (cards != null)
        {
            for (int i = 0; i < cards.Count; i++)
            {
                CardDataSO card = cards[i];
                if (card != null && !string.IsNullOrEmpty(card.CardId))
                    _cardContentsCandidates.Add(card);
            }
        }

        int version = _cardContentsLoadVersion;
        int slotCount = _cardContentsSlots != null ? _cardContentsSlots.Length : 0;
        int previewCount = Mathf.Min(PreviewCardLimit, _cardContentsCandidates.Count, slotCount);
        for (int i = 0; i < previewCount; i++)
        {
            CardContentsSlot slot = _cardContentsSlots[i];
            if (slot == null) continue;

            CardDataSO card = _cardContentsCandidates[i];
            slot.BoundCard = card;
            slot.PreviewCard = CardFactory.CreatePreviewFromSO(card);
            slot.Root?.SetActive(true);
            if (slot.Icon != null)
                slot.Icon.sprite = null;
            LoadCardContentsIconAsync(slot, card, version).Forget();
        }

        RefreshCardContentsTexts();
        if (_cardContentsTooltip == null)
            _cardContentsRoot.gameObject.SetActive(true);
        MovePanelNextTo(_cardContentsRoot, item.RectTransform);

#if UNITY_EDITOR || DEVELOPMENT_BUILD
        Debug.Assert(previewCount <= PreviewCardLimit,
            "[UIStartCardPackPopup] 카드 구성 미리보기 이미지 수가 상한을 초과했습니다.");
#endif
    }

    private void HideCardContentsTooltip(UIStartCardPackItem item, bool pointerStillInside)
    {
        if (_hoveredContentsItem != item) return;
        ResetCardContentsTooltip();
        if (!_suppressContentsFallback && pointerStillInside)
            ShowTooltip(item);
    }

    private void ShowExtraCardNamesTooltip()
    {
        if (_cardContentsExtraRoot == null || _cardContentsEtcRoot == null) return;

        _cardContentsPreviewTooltip?.ForceCloseBranch();
        MovePanelNextTo(
            _cardContentsExtraRoot,
            _cardContentsEtcSource != null ? _cardContentsEtcSource.RectTransform : null);
        Canvas.ForceUpdateCanvases();
        if (_cardContentsExtraScroll != null)
            _cardContentsExtraScroll.verticalNormalizedPosition = 1f;
    }

    private void ShowCardPreviewTooltip(CardContentsSlot slot)
    {
        if (slot?.PreviewCard == null || _cardContentsPreviewRoot == null ||
            _cardContentsPreviewView == null || _cardContentsRoot == null)
        {
            return;
        }

        _cardContentsExtraTooltip?.ForceCloseBranch();
        _cardContentsPreviewView.Setup(slot.PreviewCard);
        MovePanelNextTo(_cardContentsPreviewRoot, _cardContentsRoot);
    }

    private void RefreshCardContentsTexts()
    {
        SetLocalizedText(_cardContentsTitleText, LocalizationKeys.StartCardPack.ContentsTitle);

        int slotCount = _cardContentsSlots != null ? _cardContentsSlots.Length : 0;
        int previewCount = Mathf.Min(PreviewCardLimit, _cardContentsCandidates.Count, slotCount);
        for (int i = 0; i < slotCount; i++)
        {
            CardContentsSlot slot = _cardContentsSlots[i];
            if (slot == null) continue;
            bool visible = i < previewCount;
            slot.Root?.SetActive(visible);
            if (visible && slot.NameText != null)
                slot.NameText.text = GetCardDisplayName(_cardContentsCandidates[i]);
        }

        int extraCount = Mathf.Max(0, _cardContentsCandidates.Count - PreviewCardLimit);
        if (_cardContentsEtcRoot != null)
            _cardContentsEtcRoot.SetActive(extraCount > 0);
        if (_cardContentsExtraNamesText != null)
        {
            if (extraCount == 0)
            {
                _cardContentsExtraNamesText.text = string.Empty;
            }
            else
            {
                List<string> names = new List<string>(extraCount);
                for (int i = PreviewCardLimit; i < _cardContentsCandidates.Count; i++)
                    names.Add(GetCardDisplayName(_cardContentsCandidates[i]));
                _cardContentsExtraNamesText.text = string.Join(", ", names);
            }
        }
    }

    private async UniTaskVoid LoadCardContentsIconAsync(
        CardContentsSlot slot, CardDataSO card, int version)
    {
        if (slot?.Icon == null || card == null || !ResourceManager.HasInstance)
            return;

        try
        {
            Sprite sprite = await ResourceManager.Instance.LoadAtlasSpriteAsync(
                EAtlasType.CardIcon, card.IconKey, this.GetCancellationTokenOnDestroy());
            if (version == _cardContentsLoadVersion && slot.BoundCard == card && slot.Icon != null)
                slot.Icon.sprite = sprite;
        }
        catch (OperationCanceledException)
        {
        }
    }

    private static string GetCardDisplayName(CardDataSO card)
    {
        if (card == null) return string.Empty;
        return LocalizationManager.HasInstance && !string.IsNullOrEmpty(card.DisplayNameKey)
            ? LocalizationManager.Instance.Get(card.DisplayNameKey)
            : card.CardId;
    }

    private void ResetCardContentsTooltip()
    {
        _cardContentsPreviewTooltip?.ForceCloseBranch();
        _cardContentsLoadVersion++;
        _hoveredContentsItem = null;
        _cardContentsCandidates.Clear();
        if (_cardContentsTooltip == null && _cardContentsRoot != null)
            _cardContentsRoot.gameObject.SetActive(false);
        if (_cardContentsExtraTooltip == null && _cardContentsExtraRoot != null)
            _cardContentsExtraRoot.gameObject.SetActive(false);
        if (_cardContentsEtcRoot != null)
            _cardContentsEtcRoot.SetActive(false);
        if (_cardContentsExtraNamesText != null)
            _cardContentsExtraNamesText.text = string.Empty;

        if (_cardContentsSlots == null) return;
        for (int i = 0; i < _cardContentsSlots.Length; i++)
        {
            CardContentsSlot slot = _cardContentsSlots[i];
            if (slot == null) continue;
            slot.BoundCard = null;
            slot.PreviewCard = null;
            slot.Root?.SetActive(false);
            if (slot.Icon != null)
                slot.Icon.sprite = null;
            if (slot.NameText != null)
                slot.NameText.text = string.Empty;
        }
    }

    private void CloseCardContentsTooltipBranch()
    {
        bool previous = _suppressContentsFallback;
        _suppressContentsFallback = true;
        _cardContentsTooltip?.ForceCloseBranch();
        _suppressContentsFallback = previous;
    }

    private void SetDescription(StartCardPackSO pack)
    {
        if (_descriptionText == null) return;

        string key = pack != null
            ? pack.IsUnlocked ? pack.DescriptionKey : pack.UnlockDescriptionKey
            : null;
        _descriptionText.text = LocalizationManager.HasInstance && !string.IsNullOrEmpty(key)
            ? Localize(key)
            : key ?? string.Empty;
    }

    private static string Localize(string key)
    {
        return LocalizationManager.HasInstance
            ? LocalizationManager.Instance.Get(key)
            : key;
    }

    private void MovePanelNextTo(RectTransform panelRoot, RectTransform itemRect)
    {
        Canvas.ForceUpdateCanvases();
        UIHoverIntentTooltip.PlaceNextTo(panelRoot, itemRect, TooltipGap);
    }

    private void SetTooltipVisible(bool visible)
    {
        if (_tooltipRoot != null)
            _tooltipRoot.gameObject.SetActive(visible);
    }

    private void HandleConfirm()
    {
        if (_resolved || _selected.Count != RequiredSelectionCount) return;

        _resolved = true;
        _hoveredItem = null;
        SetTooltipVisible(false);
        CloseCardContentsTooltipBranch();
        ResetCardContentsTooltip();
        RefreshSelectionState();
        List<StartCardPackSO> selected = new List<StartCardPackSO>(_selected);

        // 선택한 팩 ID 스냅샷 (분석용). 이후 _selected 가 정리돼도 조회 가능해야 한다.
        _selectedPackIds.Clear();
        for (int i = 0; i < selected.Count; i++)
        {
            if (selected[i] != null)
                _selectedPackIds.Add(selected[i].PackId);
        }

        // 카드와 방향을 확정 시점에 1회 굴려 고정 → 연출·덱 추가가 동일 값을 사용한다.
        ResolveSelectedResults(selected);

        if (_skipOpeningAnimation)
        {
            CompleteConfirmation();
            return;
        }

        SetSelectionUiVisible(false);
        for (int i = 0; i < _items.Count; i++)
        {
            if (_items[i] != null)
                _items[i].gameObject.SetActive(false);
        }
        _openingRoutine = StartCoroutine(PlayOpeningSequence(selected));
    }

    private void HandleSkipOpeningAnimationChanged(bool skip)
    {
        _skipOpeningAnimation = skip;
        if (SettingsManager.HasInstance)
            SettingsManager.Instance.SetSkipStartCardPackOpeningAnimation(skip);
    }

    private IEnumerator PlayOpeningSequence(List<StartCardPackSO> selected)
    {
        for (int i = 0; i < selected.Count; i++)
        {
            StartCardPackSO pack = selected[i];
            if (pack == null ||
                !_resolvedResultsByPack.TryGetValue(pack, out List<StartCardPackResult> results) ||
                results.Count == 0)
                continue;

            UIStartCardPackItem item = FindItem(pack);
            if (item == null || _openingRoot == null ||
                !item.TryGetOpeningTargets(out RectTransform packVisual,
                    out RectTransform detachedSide,
                    out RedPaperSeparationCutter cutter))
            {
                Debug.LogError($"[UIStartCardPackPopup] 카드팩 개봉 연출 대상을 찾지 못했습니다: {pack.name}", this);
                continue;
            }

            item.SetSelected(false);
            item.transform.SetParent(_openingRoot, true);
            item.transform.SetAsLastSibling();
            item.SetInfoCircleVisible(false);
            item.gameObject.SetActive(true);

            RectTransform itemRect = item.RectTransform;
            itemRect.DOKill();
            packVisual.DOKill();
            detachedSide.DOKill();

            Sequence centerSequence = DOTween.Sequence()
                .Join(itemRect.DOMove(_openingRoot.position, _centerMoveDuration).SetEase(Ease.OutCubic))
                .Join(packVisual.DOScale(PackScale, _centerMoveDuration).SetEase(Ease.OutCubic))
                .SetUpdate(true);
            yield return WaitForTween(centerSequence);

            CreateOpeningCards(pack, item);

            float cutProgress = 0f;
            cutter.SetCutProgress(0f);
            Tween cutTween = DOTween.To(
                    () => cutProgress,
                    value =>
                    {
                        cutProgress = value;
                        cutter.SetCutProgress(value);
                    },
                    1f,
                    _cutDuration)
                .SetEase(Ease.Linear)
                .SetUpdate(true);
            yield return WaitForTween(cutTween);

            // 컷 연출이 끝나는 실제 개봉 지점에서만 재생한다. 스킵 경로는 이 루틴을 타지 않는다.
            if (AudioManager.HasInstance)
                AudioManager.Instance.PlayUiAsync(AudioKeys.Ui.CARD_PACK_OPEN).Forget();

            yield return WaitForTween(detachedSide
                .DOAnchorPosY(DetachedTargetY, _detachedMoveDuration)
                .SetEase(Ease.InCubic)
                .SetUpdate(true));

            if (_openingCards.Count > 0)
            {
                List<Vector2> cardStartPositions = new List<Vector2>(_openingCards.Count);
                Sequence cardRevealSequence = DOTween.Sequence().SetUpdate(true);
                for (int cardIndex = 0; cardIndex < _openingCards.Count; cardIndex++)
                {
                    RectTransform cardRect = _openingCards[cardIndex]?.GetRectTransform();
                    if (cardRect != null)
                    {
                        cardStartPositions.Add(cardRect.anchoredPosition);
                        cardRevealSequence.Join(cardRect.DOAnchorPosY(CardRevealY, _cardMoveDuration));
                    }
                    else
                    {
                        cardStartPositions.Add(Vector2.zero);
                    }
                }
                yield return WaitForTween(cardRevealSequence);

                for (int cardIndex = 0; cardIndex < _openingCards.Count; cardIndex++)
                    _openingCards[cardIndex]?.transform.SetAsLastSibling();

                Sequence cardReturnSequence = DOTween.Sequence().SetUpdate(true);
                for (int cardIndex = 0; cardIndex < _openingCards.Count; cardIndex++)
                {
                    RectTransform cardRect = _openingCards[cardIndex]?.GetRectTransform();
                    if (cardRect != null)
                        cardReturnSequence.Join(cardRect.DOAnchorPos(cardStartPositions[cardIndex], _cardMoveDuration));
                }
                yield return WaitForTween(cardReturnSequence);

                yield return WaitForTween(packVisual
                    .DOAnchorPosY(PackExitY, _packExitDuration)
                    .SetEase(Ease.InCubic)
                    .SetUpdate(true));

                Sequence cardExitSequence = DOTween.Sequence().SetUpdate(true);
                for (int cardIndex = _openingCards.Count - 1; cardIndex >= 0; cardIndex--)
                {
                    RectTransform cardRect = _openingCards[cardIndex]?.GetRectTransform();
                    if (cardRect != null)
                        cardExitSequence.Append(cardRect.DOAnchorPosY(CardExitY, _cardExitDuration));
                }
                yield return WaitForTween(cardExitSequence);
                ReleaseOpeningCards();
            }
            else
            {
                yield return WaitForTween(packVisual
                    .DOAnchorPosY(PackExitY, _packExitDuration)
                    .SetEase(Ease.InCubic)
                    .SetUpdate(true));
            }

            item.gameObject.SetActive(false);
            Destroy(item.gameObject);
        }

        _openingRoutine = null;
        CompleteConfirmation();
    }

    /// <summary>
    /// 선택된 카드팩의 지급 카드와 화살표 방향을 확정 시점에 1회 굴려 고정한다.
    /// 이 값을 개봉 연출 비주얼과 실제 덱 추가 양쪽에 동일하게 사용해
    /// "보여준 화살표 = 획득한 화살표"를 보장한다 (상점·보상 경로와 동일 규칙).
    /// </summary>
    private void ResolveSelectedResults(List<StartCardPackSO> selected)
    {
        _resolvedResultsByPack.Clear();
        _confirmedResults.Clear();

        for (int i = 0; i < selected.Count; i++)
        {
            StartCardPackSO pack = selected[i];
            if (pack == null) continue;

            List<CardDataSO> cards = SelectRewardCards(pack);
            List<StartCardPackResult> results = new List<StartCardPackResult>(cards.Count);
            for (int j = 0; j < cards.Count; j++)
            {
                CardDataSO cardData = cards[j];

                // Random/Weighted 모드는 여기서 굴린 결과가 카드의 평생 방향이 된다.
                ECardDirection direction = ECardDirection.None;
                Card card = CardFactory.CreateFromSO(cardData);
                if (card != null && card.Arrow != null)
                    direction = card.Arrow.Current;

                StartCardPackResult result = new StartCardPackResult(cardData, direction);
                results.Add(result);
                _confirmedResults.Add(result);
            }

            _resolvedResultsByPack[pack] = results;
        }
    }

    private static List<CardDataSO> SelectRewardCards(StartCardPackSO pack)
    {
        IReadOnlyList<CardDataSO> source = pack.Cards;
        List<CardDataSO> candidates = new List<CardDataSO>(source != null ? source.Count : 0);
        if (source != null)
        {
            for (int i = 0; i < source.Count; i++)
            {
                CardDataSO cardData = source[i];
                if (cardData != null && !string.IsNullOrEmpty(cardData.CardId))
                    candidates.Add(cardData);
            }
        }

        int candidateCount = candidates.Count;
        int randomPickCount = pack.RandomPickCount;
        if (randomPickCount <= 0 || candidates.Count == 0)
        {
#if UNITY_EDITOR || DEVELOPMENT_BUILD
            AssertSelectedCards(candidates, candidateCount, randomPickCount);
#endif
            return candidates;
        }

        int take = Mathf.Min(randomPickCount, candidates.Count);
        System.Random random = new System.Random(StablePackSelectionSeed(s_pendingRunSeed, pack.PackId));
        if (pack.UseRarityWeights)
        {
            float totalWeight = GetTotalRarityWeight(pack);
            if (totalWeight > 0f)
            {
                List<CardDataSO> selected = SelectRarityWeightedCards(candidates, take, random, pack, totalWeight);
#if UNITY_EDITOR || DEVELOPMENT_BUILD
                AssertSelectedCards(selected, candidateCount, randomPickCount);
#endif
                return selected;
            }

            Debug.LogWarning($"[UIStartCardPackPopup] 등급 가중치 합계가 0이므로 균등 추첨합니다: {pack.PackId}");
        }

        for (int i = 0; i < take; i++)
        {
            int swapIndex = random.Next(i, candidates.Count);
            (candidates[i], candidates[swapIndex]) = (candidates[swapIndex], candidates[i]);
        }

        if (take < candidates.Count)
            candidates.RemoveRange(take, candidates.Count - take);

#if UNITY_EDITOR || DEVELOPMENT_BUILD
        AssertSelectedCards(candidates, candidateCount, randomPickCount);
#endif

        return candidates;
    }

    private static List<CardDataSO> SelectRarityWeightedCards(
        List<CardDataSO> candidates,
        int take,
        System.Random random,
        StartCardPackSO pack,
        float totalWeight)
    {
        List<CardDataSO> selected = new List<CardDataSO>(take);
        for (int i = 0; i < take; i++)
        {
            ECardRarity rarity = RollRarity(pack, totalWeight, random);
            int selectedIndex = PickRarityIndex(candidates, rarity, random);
            if (selectedIndex < 0) break;

            selected.Add(candidates[selectedIndex]);
            candidates.RemoveAt(selectedIndex);
        }

        return selected;
    }

    private static float GetTotalRarityWeight(StartCardPackSO pack)
    {
        return Mathf.Max(0f, pack.GetRarityWeight(ECardRarity.Common)) +
               Mathf.Max(0f, pack.GetRarityWeight(ECardRarity.Rare)) +
               Mathf.Max(0f, pack.GetRarityWeight(ECardRarity.Unique)) +
               Mathf.Max(0f, pack.GetRarityWeight(ECardRarity.Legendary));
    }

    private static ECardRarity RollRarity(StartCardPackSO pack, float totalWeight, System.Random random)
    {
        double roll = random.NextDouble() * totalWeight;
        float accumulated = 0f;
        for (int i = 0; i <= (int)ECardRarity.Legendary; i++)
        {
            ECardRarity rarity = (ECardRarity)i;
            accumulated += Mathf.Max(0f, pack.GetRarityWeight(rarity));
            if (roll < accumulated)
                return rarity;
        }

        return ECardRarity.Legendary;
    }

    private static int PickRarityIndex(
        List<CardDataSO> candidates,
        ECardRarity rarity,
        System.Random random)
    {
        int selectedIndex = PickUniformIndexByRarity(candidates, rarity, random);
        if (selectedIndex >= 0) return selectedIndex;

        for (int i = (int)rarity - 1; i >= (int)ECardRarity.Common; i--)
        {
            selectedIndex = PickUniformIndexByRarity(candidates, (ECardRarity)i, random);
            if (selectedIndex >= 0) return selectedIndex;
        }

        for (int i = (int)rarity + 1; i <= (int)ECardRarity.Legendary; i++)
        {
            selectedIndex = PickUniformIndexByRarity(candidates, (ECardRarity)i, random);
            if (selectedIndex >= 0) return selectedIndex;
        }

        return -1;
    }

    private static int PickUniformIndexByRarity(
        List<CardDataSO> candidates,
        ECardRarity rarity,
        System.Random random)
    {
        int count = 0;
        for (int i = 0; i < candidates.Count; i++)
        {
            if (candidates[i].Rarity == rarity)
                count++;
        }

        if (count == 0) return -1;

        int target = random.Next(0, count);
        for (int i = 0; i < candidates.Count; i++)
        {
            if (candidates[i].Rarity != rarity) continue;
            if (target-- == 0) return i;
        }

        return -1;
    }

#if UNITY_EDITOR || DEVELOPMENT_BUILD
    private static void AssertSelectedCards(List<CardDataSO> selected, int candidateCount, int randomPickCount)
    {
        int maxCount = randomPickCount > 0 ? Mathf.Min(randomPickCount, candidateCount) : candidateCount;
        Debug.Assert(selected.Count <= maxCount, "[UIStartCardPackPopup] 카드팩 지급 수가 추첨 상한을 초과했습니다.");
        for (int i = 0; i < selected.Count; i++)
            Debug.Assert(selected[i] != null && !string.IsNullOrEmpty(selected[i].CardId), "[UIStartCardPackPopup] 유효하지 않은 카드가 확정 결과에 포함되었습니다.");
    }
#endif

    private static int StablePackSelectionSeed(int runSeed, string packId)
    {
        unchecked
        {
            uint hash = 2166136261u;
            hash = (hash ^ (uint)runSeed) * 16777619u;
            string stablePackId = packId ?? string.Empty;
            for (int i = 0; i < stablePackId.Length; i++)
                hash = (hash ^ stablePackId[i]) * 16777619u;
            hash = (hash ^ 0x5041434Bu) * 16777619u; // "PACK"
            return (int)(hash & 0x7fffffff);
        }
    }

    private void CreateOpeningCards(StartCardPackSO pack, UIStartCardPackItem item)
    {
        ReleaseOpeningCards();
        if (_cardVisualPrefab == null || _openingRoot == null || !PoolManager.HasInstance)
        {
            Debug.LogWarning("[UIStartCardPackPopup] 카드 개봉 비주얼을 생성할 수 없습니다.", this);
            return;
        }

        if (!_resolvedResultsByPack.TryGetValue(pack, out List<StartCardPackResult> results))
            return;

        for (int i = 0; i < results.Count; i++)
        {
            StartCardPackResult result = results[i];
            CardDataSO cardData = result.CardData;
            if (cardData == null) continue;

            CardRuntimeData runtime = CardFactory.FromSO(cardData);
            if (runtime == null) continue;

            // 확정 방향을 그대로 복원해 생성 → 연출과 실제 획득 카드의 화살표가 일치.
            Card card = CardFactory.Create(runtime, result.Direction);
            if (card == null) continue;

            UICard visual = PoolManager.Instance.Spawn(_cardVisualPrefab, _openingRoot);
            if (visual == null) continue;

            visual.Bind(card);
            RectTransform rect = visual.GetRectTransform();
            rect.anchorMin = rect.anchorMax = new Vector2(0.5f, 0.5f);
            rect.anchoredPosition = Vector2.zero;
            rect.localRotation = Quaternion.identity;
            rect.localScale = Vector3.one;
            visual.transform.SetSiblingIndex(_openingCards.Count);
            _openingCards.Add(visual);
        }

        item.transform.SetAsLastSibling();
    }

    private IEnumerator WaitForTween(Tween tween)
    {
        _openingTween = tween;
        yield return tween.WaitForCompletion();
        if (_openingTween == tween)
            _openingTween = null;
    }

    private UIStartCardPackItem FindItem(StartCardPackSO pack)
    {
        for (int i = 0; i < _items.Count; i++)
        {
            if (_items[i] != null && _items[i].Data == pack)
                return _items[i];
        }
        return null;
    }

    private void SetSelectionUiVisible(bool visible)
    {
        if (_pickupDescriptionText != null) _pickupDescriptionText.gameObject.SetActive(visible);
        if (_selectionCountText != null) _selectionCountText.gameObject.SetActive(visible);
        if (_confirmButton != null) _confirmButton.gameObject.SetActive(visible);
        if (_skipOpeningAnimationToggle != null) _skipOpeningAnimationToggle.gameObject.SetActive(visible);
        if (_skipOpeningAnimationText != null) _skipOpeningAnimationText.gameObject.SetActive(visible);
        if (!visible)
        {
            _hoveredItem = null;
            SetTooltipVisible(false);
            CloseCardContentsTooltipBranch();
            ResetCardContentsTooltip();
        }
    }

    private void CompleteConfirmation()
    {
        // 팝업 Close 시 _confirmedResults 가 비워지므로, 소비 측에 복사본을 넘긴다.
        OnConfirmed?.Invoke(new List<StartCardPackResult>(_confirmedResults));
    }

    private void CleanupOpeningAnimation()
    {
        if (_openingRoutine != null)
        {
            StopCoroutine(_openingRoutine);
            _openingRoutine = null;
        }
        _openingTween?.Kill();
        _openingTween = null;
        ReleaseOpeningCards();
    }

    private void ReleaseOpeningCards()
    {
        for (int i = 0; i < _openingCards.Count; i++)
        {
            UICard card = _openingCards[i];
            if (card == null) continue;
            card.GetRectTransform()?.DOKill();
            if (PoolManager.HasInstance)
                PoolManager.Instance.Despawn(card);
            else
                Destroy(card.gameObject);
        }
        _openingCards.Clear();
    }

    private void ClearItems()
    {
        for (int i = 0; i < _items.Count; i++)
        {
            if (_items[i] != null)
                Destroy(_items[i].gameObject);
        }
        _items.Clear();
    }

    private void OnDestroy()
    {
        CleanupOpeningAnimation();
        _cardContentsEtcSource?.Unbind();
        _confirmButton?.onClick.RemoveListener(HandleConfirm);
        _skipOpeningAnimationToggle?.onValueChanged.RemoveListener(HandleSkipOpeningAnimationChanged);
        OnConfirmed = null;
    }
}
