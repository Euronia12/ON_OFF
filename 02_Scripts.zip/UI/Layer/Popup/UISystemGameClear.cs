// =================================================================
// [스크립트 목적]  최종 보스 엔딩 뒤 게임클리어 Reveal과 타이틀 복귀를 제공한다.
// [주요 변수]      - _gameClearText : 게임클리어 로컬라이징 텍스트
//                  - _reveals : StageNotice와 같은 원형 Reveal 대상
//                  - _statisticsRoot/_statisticsSlotPrefab : 4x2 결과 통계
// [의존 관계]      - UIBase / UIManager / UICircleReveal / InGameController
// [배치]           UIManager 로 여는 System UI. 키 = 타입 이름(UISystemGameClear).
// =================================================================

using System;
using System.Collections.Generic;
using System.Threading;
using Cysharp.Threading.Tasks;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public sealed class UISystemGameClear : UIBase
{
    [Header("결과 표시")]
    [Tooltip("게임클리어 제목 텍스트")]
    [SerializeField] private TMP_Text _gameClearText;

    [Tooltip("클리어 당시 난이도 텍스트")]
    [SerializeField] private TMP_Text _difficultyText;

    [Tooltip("StageNotice 방식으로 공개할 장식 이미지")]
    [SerializeField] private UICircleReveal[] _reveals;

    [Tooltip("4열 x 2행 결과 통계 콘텐츠 루트")]
    [SerializeField] private RectTransform _statisticsRoot;

    [Tooltip("StatisticsRoot에 생성할 공용 통계 슬롯 프리팹")]
    [SerializeField] private UIStatisticsSlot _statisticsSlotPrefab;

    [Header("등장 연출")]
    [Tooltip("게임클리어 원형 Reveal 재생 시간(초)")]
    [Min(0f)]
    [SerializeField] private float _revealDuration = 1.2f;

    [Header("타이틀 복귀")]
    [Tooltip("타이틀 화면으로 돌아가는 버튼")]
    [SerializeField] private Button _titleButton;

    [Tooltip("타이틀 복귀 버튼 텍스트")]
    [SerializeField] private TMP_Text _titleButtonText;

    private bool _titleRequested;
    private RunStatisticsSnapshot _statistics;
    private readonly List<UIStatisticsSlot> _spawnedStatistics = new List<UIStatisticsSlot>(8);

    public override bool CloseOnEscape => true;
    public RectTransform StatisticsRoot => _statisticsRoot;

    public event Action OnTitleRequested;

    protected override void Init()
    {
        if (_titleButton != null)
            _titleButton.onClick.AddListener(HandleTitle);
    }

    protected override void Setup()
    {
        _titleRequested = false;
        SetRevealProgress(0f);
        if (_titleButton != null)
            _titleButton.interactable = false;
        RebuildStatistics();
    }

    public override void OnLocalize()
    {
        base.OnLocalize();
        if (_gameClearText != null)
            _gameClearText.text = Localize(LocalizationKeys.GameClear.Title);
        RefreshDifficultyText();
        if (_titleButtonText != null)
            _titleButtonText.text = Localize(LocalizationKeys.EscMenu.TitleScreen);
        RebuildStatistics();
    }

    public override void OnClose()
    {
        RunStatisticsUIBuilder.Clear(_spawnedStatistics);
        _statistics = null;
        base.OnClose();
    }

    public void BindStatistics(RunStatisticsSnapshot statistics)
    {
        _statistics = statistics;
        RefreshDifficultyText();
        RebuildStatistics();
    }

    private void RefreshDifficultyText()
    {
        if (_difficultyText == null) return;

        _difficultyText.text = _statistics != null
            ? Localize(ResolveDifficultyKey(_statistics.Difficulty))
            : string.Empty;
    }

    private static string ResolveDifficultyKey(ERunDifficulty difficulty)
    {
        switch (RunDifficultyUtility.Normalize(difficulty))
        {
            case ERunDifficulty.Hard: return LocalizationKeys.Run.DifficultyHard;
            case ERunDifficulty.Hell: return LocalizationKeys.Run.DifficultyHell;
            default: return LocalizationKeys.Run.DifficultyNormal;
        }
    }

    private void RebuildStatistics()
        => RunStatisticsUIBuilder.Rebuild(
            _statisticsRoot,
            _statisticsSlotPrefab,
            _statistics,
            _spawnedStatistics);

    /// <summary>게임클리어 장식을 공개한 뒤 결과 화면을 열린 상태로 유지한다.</summary>
    public async UniTask PlayRevealAsync(CancellationToken token)
    {
        SetRevealProgress(0f);
        Canvas.ForceUpdateCanvases();
        await UniTask.Yield(PlayerLoopTiming.LastPostLateUpdate, token);

        if (_revealDuration <= 0f)
        {
            SetRevealProgress(1f);
        }
        else
        {
            float elapsed = 0f;
            while (elapsed < _revealDuration)
            {
                token.ThrowIfCancellationRequested();
                elapsed += Mathf.Min(Time.unscaledDeltaTime, 1f / 30f);
                SetRevealProgress(Mathf.Clamp01(elapsed / _revealDuration));
                await UniTask.Yield(PlayerLoopTiming.Update, token);
            }
            SetRevealProgress(1f);
        }

        if (_titleButton != null)
            _titleButton.interactable = true;
    }

    /// <summary>결과 화면은 ESC로 닫히거나 런 메뉴로 돌아가지 않는다.</summary>
    public override bool OnBackPressed() => false;

    private void SetRevealProgress(float progress)
    {
        if (_reveals == null) return;
        for (int i = 0; i < _reveals.Length; i++)
        {
            if (_reveals[i] != null)
                _reveals[i].SetProgress(progress);
        }
    }

    private void HandleTitle()
    {
        if (_titleRequested) return;
        _titleRequested = true;
        if (_titleButton != null)
            _titleButton.interactable = false;
        OnTitleRequested?.Invoke();
    }

    private static string Localize(string key)
    {
        if (!LocalizationManager.HasInstance || !LocalizationManager.Instance.HasKey(key))
            return key ?? string.Empty;
        return LocalizationManager.Instance.Get(key);
    }

    private void OnDestroy()
    {
        RunStatisticsUIBuilder.Clear(_spawnedStatistics);
        if (_titleButton != null)
            _titleButton.onClick.RemoveListener(HandleTitle);
        OnTitleRequested = null;
    }
}
