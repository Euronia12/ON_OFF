using System;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

/// <summary>백틱 시드 설정·조회 프리팹용 UI. TITLE에서는 설정, Main에서는 읽기 전용으로 사용한다.</summary>
public sealed class UIDebugSeed : UIDebugPopupBase
{
    [SerializeField] private GameObject _titleRoot;
    [SerializeField] private GameObject _mainRoot;
    [SerializeField] private TMP_InputField _seedInput;
    [SerializeField] private Toggle _sessionToggle;
    [SerializeField] private TMP_Text _currentSeedText;
    [SerializeField] private TMP_Text _messageText;
    [SerializeField] private Button _applyButton;

    public event Action<int, bool> OnApplyRequested;

    protected override void Init()
    {
        base.Init();
        _applyButton?.onClick.AddListener(HandleApply);
    }

    public void BindTitle()
    {
        if (_titleRoot != null) _titleRoot.SetActive(true);
        if (_mainRoot != null) _mainRoot.SetActive(false);
        SetMessage(string.Empty);
    }

    public void BindMain(int? currentSeed)
    {
        if (_titleRoot != null) _titleRoot.SetActive(false);
        if (_mainRoot != null) _mainRoot.SetActive(true);
        if (_currentSeedText != null)
            _currentSeedText.text = currentSeed.HasValue ? currentSeed.Value.ToString() : "런 시작 전";
    }

    public void SetMessage(string message)
    {
        if (_messageText != null) _messageText.text = message ?? string.Empty;
    }

    private void HandleApply()
    {
        if (!int.TryParse(_seedInput?.text?.Trim(), out int seed))
        {
            SetMessage("int 범위의 시드를 입력하세요.");
            return;
        }
        OnApplyRequested?.Invoke(seed, _sessionToggle != null && _sessionToggle.isOn);
    }
}
