// =================================================================
// [스크립트 목적]  모든 Choice Event 가 공유하는 단일 데이터 구동 UI.
//                 EventDataSO 에서 만든 EventViewData 로 타이틀/설명/선택지를 갱신한다.
// [주요 변수]      - _slotRoot/_slotPrefab : 선택지 슬롯 부모 / 슬롯 프리팹
//                  - s_pending : 열기 직전 주입되는 뷰 데이터(OpenAsync 인자 제약 우회)
// [의존 관계]      - UIPopupBase / UIManager / UIChoiceSlot / EventContext / EventController
// [설계 노트]      - UIDeckCardPicker 패턴: 단일 캐시 팝업 + 슬롯 재사용/부족 시 생성.
//                    SO 는 직접 참조하지 않고 EventViewData(POCO)만 소비(SO 격리).
// =================================================================

using System;
using System.Collections.Generic;
using System.Threading;
using Cysharp.Threading.Tasks;
using DG.Tweening;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public sealed class UIChoiceEvent : UIPopupBase, IEventView
{
    [Header("표시")]
    [SerializeField] private Image _image;
    [SerializeField] private TMP_Text _titleText;
    [SerializeField] private TMP_Text _descText;

    [Header("선택지")]
    [Tooltip("선택지 슬롯이 들어갈 부모(Layout Group 권장)")]
    [SerializeField] private Transform _slotRoot;
    [Tooltip("선택지 슬롯 프리팹(UIChoiceSlot)")]
    [SerializeField] private UIChoiceSlot _slotPrefab;
    [Tooltip("선택 후 숨길 버튼 영역 루트(선택). 비우면 슬롯을 개별 숨김.")]
    [SerializeField] private GameObject _choiceRoot;
    [Tooltip("선택지 개수와 무관하게 슬롯 높이를 계산할 기준 개수. 4면 항상 선택지 4개일 때의 버튼 높이를 사용한다.")]
    [Min(1)] [SerializeField] private int _choiceSlotSizeReferenceCount = 4;

    [Header("결과(선택 후)")]
    [Tooltip("선택 후 통째로 켜지는 결과 영역 루트(선택). 결과 텍스트·떠나기 버튼을 담는다.")]
    [SerializeField] private GameObject _resultRoot;
    [Tooltip("선택 확정 후 표시할 결과 텍스트(선택)")]
    [SerializeField] private TMP_Text _resultText;
    [Tooltip("결과 화면의 떠나기 버튼(선택). 비우면 선택 즉시 이벤트 종료.")]
    [SerializeField] private Button _leaveButton;
    [SerializeField] private TMP_Text _leaveButtonText;
    [SerializeField] private string _leaveButtonKey = "UI_CHOICE_LEAVE";

    [Header("결과 카드")]
    [Tooltip("원본(변경 전) 카드가 배치될 부모. 비우면 결과 카드만 표시한다")]
    [SerializeField] private Transform _sourceCardRoot;
    [Tooltip("결과(변경 후) 카드가 배치될 부모. 화살표 추가 결과도 여기에 뜬다")]
    [SerializeField] private Transform _resultCardRoot;
    [Tooltip("원본·결과 양쪽에 공용으로 쓰는 카드 타일 프리팹")]
    [SerializeField] private UIDeckCardTile _resultCardPrefab;
    [Tooltip("카드 한 장의 등장 연출 시간(초). 결과 카드는 이 값의 절반만큼 늦게 뜬다")]
    [SerializeField, Min(0f)] private float _resultCardTransitionDuration = 0.18f;

    [Header("카드 변환 결과")]
    [Tooltip("변환 대상 카드를 한 화면에 배치하는 영역")]
    [SerializeField] private RectTransform _transformCardRoot;
    [Tooltip("원본 크기 기준 변환 카드 사이의 간격(px)")]
    [SerializeField, Min(0f)] private float _transformCardSpacing = 18f;
    [Tooltip("흰색 발광이 나타나고 사라지는 각 구간 시간(초)")]
    [SerializeField, Min(0f)] private float _transformFlashDuration = 1.4f;
    [Tooltip("발광 정점에서 카드가 확대되는 배율")]
    [SerializeField, Range(1f, 1.2f)] private float _transformPulseScale = 1.05f;
    [Tooltip("카드 본체와 좌상단 코스트 영역을 함께 채우는 발광 이미지")]
    [SerializeField] private Sprite _cardChangeFlashSprite;

    // 열기 직전 주입 (OpenAsync 인자 제약 우회).
    private static EventViewData s_pending;
    private static readonly Vector2 CardChangeSize = new Vector2(192f, 288f);
    private static readonly Vector2 CardChangeVisualSize = new Vector2(213f, 311f);
    private static readonly Vector2 CardChangeVisualOffset = new Vector2(-10.5f, 11.5f);

    private readonly List<UIChoiceSlot> _slots = new List<UIChoiceSlot>(4);
    private EventViewData _data;
    private EventContext _context;
    private CancellationToken _token;
    private UniTaskCompletionSource _completion;
    private bool _resolved;
    private UIDeckCardTile _resultCard;
    private Vector3 _resultCardBaseScale = Vector3.one;
    private Tween _resultCardTween;
    private Tween _resultArrowTween;
    private UIDeckCardTile _sourceCard;
    private Vector3 _sourceCardBaseScale = Vector3.one;
    private Tween _sourceCardTween;
    private readonly List<CardChangePresentation> _cardChangeCards =
        new List<CardChangePresentation>(12);
    private Sequence _cardChangeSequence;
    private bool _showingCardChangeBatch;
    private VerticalLayoutGroup _choiceLayout;

    // 결과 텍스트 재구성용 상태. 언어 변경 시 원본 키에서 다시 포맷해야 하므로 보관한다.
    private EventChoiceData _resultChoice;
    private readonly List<int?> _resultAmounts = new List<int?>(4);
    private readonly List<ResultCardPresentation> _resultCardQueue =
        new List<ResultCardPresentation>(8);
    private int _resultCardIndex;

    private enum EResultCardPresentationKind
    {
        Transform,
        CostChange,
    }

    private readonly struct ResultCardPresentation
    {
        public EResultCardPresentationKind Kind { get; }
        public ChoiceEventCardTransformResult Transform { get; }
        public ChoiceEventCardCostResult CostChange { get; }

        private ResultCardPresentation(
            EResultCardPresentationKind kind,
            ChoiceEventCardTransformResult transform,
            ChoiceEventCardCostResult costChange)
        {
            Kind = kind;
            Transform = transform;
            CostChange = costChange;
        }

        public static ResultCardPresentation FromTransform(ChoiceEventCardTransformResult value)
            => new ResultCardPresentation(EResultCardPresentationKind.Transform, value, default);

        public static ResultCardPresentation FromCostChange(ChoiceEventCardCostResult value)
            => new ResultCardPresentation(EResultCardPresentationKind.CostChange, default, value);
    }

    private sealed class CardChangePresentation
    {
        public UIDeckCardTile Tile { get; }
        public Image Flash { get; }
        public Card ResultCard { get; set; }
        public Vector3 BaseScale { get; set; }

        public CardChangePresentation(UIDeckCardTile tile, Image flash)
        {
            Tile = tile;
            Flash = flash;
        }
    }

    /// <summary>열기 직전 뷰 데이터 주입. EventController 가 EventDataSO 에서 만들어 전달.</summary>
    public static void Show(EventViewData data) => s_pending = data;

    protected override void Init()
    {
        if (_leaveButton != null) _leaveButton.onClick.AddListener(OnLeaveClicked);

        if (_slotRoot != null)
        {
            _choiceLayout = _slotRoot.GetComponent<VerticalLayoutGroup>();
            if (_choiceLayout != null)
            {
                _choiceLayout.childControlHeight = false;
                _choiceLayout.childForceExpandHeight = false;
            }
        }
    }

    protected override void Setup()
    {
        _data = s_pending;
        s_pending = null;
        _completion = new UniTaskCompletionSource();
        _resolved = false;
        ResetResultCardPresentation();
        ClearResultText();

        // 결과 화면 초기화 — 선택지 영역 표시, 결과 영역 숨김.
        if (_descText != null) _descText.gameObject.SetActive(true);
        if (_choiceRoot != null) _choiceRoot.SetActive(true);
        if (_resultRoot != null) _resultRoot.SetActive(false);
        else
        {
            if (_resultText != null) _resultText.gameObject.SetActive(false);
            if (_leaveButton != null) _leaveButton.gameObject.SetActive(false);
        }

        BuildSlots();
        OnLocalize();
    }

    public async UniTask PlayAsync(EventContext context, CancellationToken token)
    {
        _context = context;
        _token = token;
        ApplyLocks(); // 컨텍스트 확정 후 조건 평가 → 미충족 선택지 잠김 처리

        RunSavePendingEventProgress progress = context.Run?.PendingEventProgress;
        if (progress != null && progress.nodeId == context.NodeId &&
            string.Equals(progress.eventId, _data?.EventId, StringComparison.Ordinal) &&
            progress.choiceIndex >= 0 && progress.choiceIndex < (_data?.Choices.Count ?? 0))
        {
            RunChoiceAsync(progress.choiceIndex, resume: true).Forget();
        }

        using (token.RegisterWithoutCaptureExecutionContext(() => _completion?.TrySetCanceled(token)))
            await _completion.Task;
    }

    public override void OnLocalize()
    {
        base.OnLocalize();
        if (_data == null) return;
        if (_titleText != null) _titleText.text = L(_data.TitleKey);
        if (_descText != null) _descText.text = L(_data.DescKey);
        RefreshResultText(); // 결과 화면 표시 중이면 결과 문구도 새 언어로 재구성
        RefreshLeaveButtonText();
        for (int i = 0; i < _slots.Count; i++)
            if (_slots[i] != null && _slots[i].gameObject.activeSelf) _slots[i].Localize();
    }

    public override void OnClose()
    {
        ResetResultCardPresentation();
        ClearResultText();
        _completion?.TrySetCanceled();
        _completion = null;
        _data = null;
        base.OnClose();
    }

    /// <summary>선택 확정 후에는 결과를 순서대로 확인해야 하므로 외부 닫기를 막는다.</summary>
    public override bool OnBackPressed() => !_resolved;

    // 이미지 + 선택지 슬롯 재사용/부족 시 생성. 초과분은 비활성.
    private void BuildSlots()
    {
        int count = _data?.Choices.Count ?? 0;
        float fixedSlotHeight = CalculateFixedChoiceSlotHeight();

        if (_image != null)
        {
            _image.sprite = _data?.Image;
            _image.gameObject.SetActive(_image.sprite != null);
        }

        for (int i = 0; i < count; i++)
        {
            UIChoiceSlot slot = GetOrCreateSlot(i);
            if (slot == null) continue;

            ApplyFixedChoiceSlotHeight(slot, fixedSlotHeight);
            slot.Bind(i, _data.Choices[i], OnChoiceChosen);
        }
        for (int i = count; i < _slots.Count; i++)
            if (_slots[i] != null) _slots[i].Release();

        if (_slotRoot is RectTransform slotRootRect)
            LayoutRebuilder.MarkLayoutForRebuild(slotRootRect);
    }

    private float CalculateFixedChoiceSlotHeight()
    {
        if (_choiceLayout == null || _slotRoot is not RectTransform slotRootRect)
            return -1f;

        int referenceCount = Mathf.Max(1, _choiceSlotSizeReferenceCount);
        float spacing = _choiceLayout.spacing * Mathf.Max(0, referenceCount - 1);
        float availableHeight = slotRootRect.rect.height - _choiceLayout.padding.vertical - spacing;
        return Mathf.Max(0f, availableHeight / referenceCount);
    }

    private static void ApplyFixedChoiceSlotHeight(UIChoiceSlot slot, float height)
    {
        if (slot == null || height < 0f || slot.transform is not RectTransform slotRect)
            return;

        slotRect.SetSizeWithCurrentAnchors(RectTransform.Axis.Vertical, height);
    }

    private UIChoiceSlot GetOrCreateSlot(int index)
    {
        if (index < _slots.Count) return _slots[index];
        if (_slotPrefab == null || _slotRoot == null) return null;
        UIChoiceSlot slot = Instantiate(_slotPrefab, _slotRoot);
        _slots.Add(slot);
        return slot;
    }

    private void ApplyLocks()
    {
        int count = _data?.Choices.Count ?? 0;
        for (int i = 0; i < count && i < _slots.Count; i++)
            if (_slots[i] != null) _slots[i].ApplyLock(_context);
    }

    private void OnChoiceChosen(int index) => RunChoiceAsync(index, resume: false).Forget();

    private async UniTaskVoid RunChoiceAsync(int index, bool resume)
    {
        if (_resolved || _data == null || index < 0 || index >= _data.Choices.Count) return;
        EventChoiceData choice = _data.Choices[index];
        if (choice == null) return;
        if (!resume && (index >= _slots.Count || !_slots[index].IsUnlocked(_context))) return;

        _resolved = true;
        SetAllInteractable(false);
        try
        {
            if (_context.InGame == null ||
                !_context.InGame.BeginPendingEventEffectApplication(_context.NodeId))
            {
                _completion?.TrySetCanceled();
                return;
            }

            RunContext run = _context.Run;
            IReadOnlyList<ChoiceEventEffectBase> effects = choice.Effects;
            RunSavePendingEventProgress progress = run?.BeginEventChoiceProgress(
                _context.NodeId, _data.EventId, index);
            if (progress == null)
                throw new InvalidOperationException("[UIChoiceEvent] 이벤트 진행 체크포인트를 만들 수 없습니다.");
            EnsureEffectFingerprint(progress, effects);

            // 선택 사실을 먼저 저장한다. 이 저장에는 아직 비용이 반영되지 않아 중간 종료돼도 안전하다.
            SaveCheckpointOrThrow();

            if (!progress.costsApplied)
            {
                run.RecordEventChoice(_data.EventId, index);
                IReadOnlyList<EventCost> costs = choice.Costs;
                for (int i = 0; i < costs.Count; i++)
                    costs[i]?.Pay(_context);
                progress.costsApplied = true;
                SaveCheckpointOrThrow();
            }

            var applied = new List<ChoiceEventEffectResult>(effects.Count);
            for (int i = 0; i < effects.Count; i++)
                applied.Add(RestoreEventEffectResult(run, i));

            int startEffect = Mathf.Clamp(progress.nextEffectIndex, 0, effects.Count);
            for (int i = startEffect; i < effects.Count; i++)
            {
                _token.ThrowIfCancellationRequested();
                EventContext effectContext = _context.WithExecution(index, i);
                ChoiceEventEffectResult result = effects[i] != null
                    ? await effects[i].ApplyAsync(effectContext, _token)
                    : default;
                applied[i] = result;
                run.SetEventEffectResult(i, result);
                progress.nextEffectIndex = i + 1;
                SaveCheckpointOrThrow();
            }

            // 비용·효과 적용 완료를 결과 화면보다 먼저 저장해 종료 후 중복 적용을 막는다.
            _context.InGame?.CompletePendingEvent(_context.NodeId);

            // 결과 영역/떠나기 버튼이 있으면 결과 화면으로 전환 후 종료 대기, 없으면 즉시 종료.
            if (_resultRoot != null || _leaveButton != null)
                ShowResult(choice, applied);
            else
                _completion?.TrySetResult();
        }
        catch (OperationCanceledException)
        {
            _context.InGame?.CancelPendingEventEffectApplication(_context.NodeId);
            _completion?.TrySetCanceled(_token);
        }
        catch (Exception e)
        {
            Debug.LogException(e);
            _context.InGame?.CancelPendingEventEffectApplication(
                _context.NodeId, rollbackToInitial: true);
            _completion?.TrySetCanceled();
        }
    }

    private void SaveCheckpointOrThrow()
    {
        if (_context.InGame == null ||
            !_context.InGame.SavePendingEventCheckpoint(_context.NodeId))
        {
            throw new InvalidOperationException("[UIChoiceEvent] 이벤트 체크포인트 저장에 실패했습니다.");
        }
    }

    private static ChoiceEventEffectResult RestoreEventEffectResult(RunContext run, int effectIndex)
    {
        RunSaveEventEffectResult saved = run?.GetEventEffectResult(effectIndex);
        if (saved == null) return ChoiceEventEffectResult.FromAmount(null);

        if (saved.cardTransforms != null && saved.cardTransforms.Count > 0)
        {
            var transforms = new List<ChoiceEventCardTransformResult>(saved.cardTransforms.Count);
            for (int i = 0; i < saved.cardTransforms.Count; i++)
            {
                RunSaveEventCardTransformResult transform = saved.cardTransforms[i];
                if (transform == null) continue;
                transforms.Add(new ChoiceEventCardTransformResult(
                    transform.sourceCardId,
                    (ECardDirection)transform.sourceDirection,
                    transform.resultCardId,
                    (ECardDirection)transform.resultDirection));
            }
            if (transforms.Count > 0)
                return ChoiceEventEffectResult.CardsTransformed(transforms);
        }

        if (saved.hasCardCostChange && !string.IsNullOrEmpty(saved.costCardId))
        {
            return ChoiceEventEffectResult.CardCostChanged(new ChoiceEventCardCostResult(
                saved.costCardId,
                (ECardDirection)saved.costCardDirection,
                saved.costBefore,
                saved.costAfter));
        }

        if (saved.hasArrowAddition && !string.IsNullOrEmpty(saved.arrowTargetCardId))
        {
            RunDeckEntry target = FindDeckEntry(run, saved.arrowTargetEntryId) ??
                                  CreateSavedResultEntry(saved);
            if (target != null)
                return ChoiceEventEffectResult.ArrowAdded(
                    target, (ECardDirection)saved.addedArrowDirection);
        }

        return ChoiceEventEffectResult.FromAmount(
            saved.hasAmount ? saved.amount : (int?)null);
    }

    private static RunDeckEntry FindDeckEntry(RunContext run, int entryId)
    {
        IReadOnlyList<RunDeckEntry> entries = run?.DeckEntries;
        if (entries == null) return null;
        for (int i = 0; i < entries.Count; i++)
            if (entries[i]?.EntryId == entryId) return entries[i];
        return null;
    }

    private static RunDeckEntry CreateSavedResultEntry(RunSaveEventEffectResult saved)
    {
        CardDataSO cardData = ResolveCardData(saved.arrowTargetCardId);
        CardRuntimeData runtime = cardData != null ? CardFactory.FromSO(cardData) : null;
        if (runtime == null) return null;

        var entry = new RunDeckEntry(saved.arrowTargetEntryId, saved.arrowTargetCardId);
        entry.SetRuntimeData(runtime);
        if (saved.arrowTargetHasDirection)
            entry.SetInitialArrowDirection((ECardDirection)saved.arrowTargetDirection);
        return entry;
    }

    private static void EnsureEffectFingerprint(
        RunSavePendingEventProgress progress,
        IReadOnlyList<ChoiceEventEffectBase> effects)
    {
        progress.effectTypeIds ??= new List<string>();
        int count = effects?.Count ?? 0;
        if (progress.effectTypeIds.Count == 0)
        {
            for (int i = 0; i < count; i++)
                progress.effectTypeIds.Add(effects[i]?.GetType().FullName ?? "<null>");
            return;
        }

        if (progress.effectTypeIds.Count != count)
            throw new InvalidOperationException("[UIChoiceEvent] 저장된 이벤트 효과 구성이 변경되었습니다.");

        for (int i = 0; i < count; i++)
        {
            string current = effects[i]?.GetType().FullName ?? "<null>";
            if (!string.Equals(progress.effectTypeIds[i], current, StringComparison.Ordinal))
                throw new InvalidOperationException("[UIChoiceEvent] 저장된 이벤트 효과 순서가 변경되었습니다.");
        }
    }

    // 선택 확정 후: 선택지 영역 숨김 + 결과 영역 표시. 결과 텍스트는 실제 적용값으로 토큰 치환.
    private void ShowResult(
        EventChoiceData choice,
        IReadOnlyList<ChoiceEventEffectResult> appliedResults)
    {
        if (AudioManager.HasInstance)
            AudioManager.Instance.PlayUiAsync(AudioKeys.Event.RESULT).Forget();

        if (_choiceRoot != null) _choiceRoot.SetActive(false);
        else HideAllSlots();
        if (_descText != null) _descText.gameObject.SetActive(false);

        if (_resultRoot != null) _resultRoot.SetActive(true);
        else
        {
            // 결과 루트가 없으면 개별 요소로 폴백 표시.
            if (_resultText != null) _resultText.gameObject.SetActive(true);
            if (_leaveButton != null) _leaveButton.gameObject.SetActive(true);
        }

        _resultChoice = choice;
        _resultAmounts.Clear();
        for (int i = 0; i < appliedResults.Count; i++)
            _resultAmounts.Add(appliedResults[i].Amount);
        BuildResultCardQueue(appliedResults);
        _resultCardIndex = 0;

        if (_resultText != null)
        {
            // 적용값은 언어와 무관하므로 1회만 수집하고, 문구 조립은 RefreshResultText 가 담당한다.
            RefreshResultText();
        }

        if (HasOnlyResultsOfKind(EResultCardPresentationKind.Transform) ||
            HasOnlyResultsOfKind(EResultCardPresentationKind.CostChange))
            ShowCardChangeBatch();
        else if (_resultCardQueue.Count > 0)
            ShowCurrentQueuedResultCard();
        else
            ShowArrowResultCard(appliedResults);
        RefreshLeaveButtonText();
    }

    // 보관된 선택지·적용값으로 결과 문구를 현재 언어 기준으로 다시 조립한다.
    // (표시 시점 1회 + 언어 변경 시마다 호출 — 결과 화면이 아니면 아무것도 하지 않는다)
    private void RefreshResultText()
    {
        if (_resultText == null || _resultChoice == null) return;

        // 결과 문구가 아직 저작되지 않은 이벤트도 빈 화면이 되지 않도록
        // 선택지 설명을 폴백으로 사용하되, 실제 적용값으로 토큰을 다시 치환한다.
        string result = L(_resultChoice.ResultKey);
        if (string.IsNullOrWhiteSpace(result)) result = L(_resultChoice.DescKey);
        string formatted = UIChoiceSlot.FormatWithAmounts(
            result,
            _resultAmounts,
            _resultChoice.Costs,
            _resultChoice.Effects,
            useResultTokens: true);

        if (!_showingCardChangeBatch &&
            _resultCardIndex >= 0 && _resultCardIndex < _resultCardQueue.Count)
        {
            ResultCardPresentation item = _resultCardQueue[_resultCardIndex];
            if (item.Kind == EResultCardPresentationKind.Transform)
            {
                string sourceName = ResolveCardName(item.Transform.SourceCardId);
                string resultName = ResolveCardName(item.Transform.ResultCardId);
                formatted = $"{formatted}\n{sourceName} → {resultName} " +
                            $"({_resultCardIndex + 1}/{_resultCardQueue.Count})";
            }
            else
            {
                ChoiceEventCardCostResult change = item.CostChange;
                formatted = $"{formatted}\n{ResolveCardName(change.CardId)}: " +
                            $"{change.BeforeCost} → {change.AfterCost} " +
                            $"({_resultCardIndex + 1}/{_resultCardQueue.Count})";
            }
        }

        _resultText.text = formatted;
    }

    private void ClearResultText()
    {
        _resultChoice = null;
        _resultAmounts.Clear();
        _resultCardQueue.Clear();
        _resultCardIndex = 0;
    }

    private void BuildResultCardQueue(IReadOnlyList<ChoiceEventEffectResult> appliedResults)
    {
        _resultCardQueue.Clear();
        if (appliedResults == null) return;

        for (int i = 0; i < appliedResults.Count; i++)
        {
            if (appliedResults[i].HasCardTransforms)
            {
                IReadOnlyList<ChoiceEventCardTransformResult> transforms = appliedResults[i].CardTransforms;
                for (int j = 0; j < transforms.Count; j++)
                    _resultCardQueue.Add(ResultCardPresentation.FromTransform(transforms[j]));
            }

            if (appliedResults[i].HasCardCostChange)
                _resultCardQueue.Add(
                    ResultCardPresentation.FromCostChange(appliedResults[i].CardCostChange));
        }
    }

    // 원본(변경 전)과 결과(변경 후)를 한 화면에 나란히 띄운다.
    private bool HasOnlyResultsOfKind(EResultCardPresentationKind kind)
    {
        if (_resultCardQueue.Count == 0 || _transformCardRoot == null ||
            _resultCardPrefab == null)
            return false;

        for (int i = 0; i < _resultCardQueue.Count; i++)
            if (_resultCardQueue[i].Kind != kind)
                return false;
        return true;
    }

    private void ShowCardChangeBatch()
    {
        var sourceCards = new List<Card>(_resultCardQueue.Count);
        var resultCards = new List<Card>(_resultCardQueue.Count);
        for (int i = 0; i < _resultCardQueue.Count; i++)
        {
            ResultCardPresentation item = _resultCardQueue[i];
            Card source;
            Card result;
            if (item.Kind == EResultCardPresentationKind.Transform)
            {
                source = CreatePreviewCard(
                    item.Transform.SourceCardId, item.Transform.SourceDirection);
                result = CreatePreviewCard(
                    item.Transform.ResultCardId, item.Transform.ResultDirection);
            }
            else
            {
                source = CreatePreviewCard(
                    item.CostChange.CardId,
                    item.CostChange.Direction,
                    item.CostChange.BeforeCost);
                result = CreatePreviewCard(
                    item.CostChange.CardId,
                    item.CostChange.Direction,
                    item.CostChange.AfterCost);
            }
            if (source == null || result == null)
            {
                ShowCurrentQueuedResultCard();
                return;
            }
            sourceCards.Add(source);
            resultCards.Add(result);
        }

        ResetResultCardPresentation();
        _showingCardChangeBatch = true;
        _transformCardRoot.gameObject.SetActive(true);

        Vector2 areaSize = _transformCardRoot.rect.size;
        if (areaSize.x <= 0f || areaSize.y <= 0f)
            areaSize = _transformCardRoot.sizeDelta;

        int columns;
        int rows;
        float scale = CalculateCardChangeGrid(
            sourceCards.Count, areaSize, _transformCardSpacing, out columns, out rows);
        float cardWidth = CardChangeVisualSize.x * scale;
        float cardHeight = CardChangeVisualSize.y * scale;
        float spacing = _transformCardSpacing * scale;
        float totalHeight = rows * cardHeight + Mathf.Max(0, rows - 1) * spacing;

        for (int i = 0; i < sourceCards.Count; i++)
        {
            CardChangePresentation presentation = GetOrCreateCardChangeCard(i);
            int row = i / columns;
            int column = i % columns;
            int rowCount = Mathf.Min(columns, sourceCards.Count - row * columns);
            float rowWidth =
                rowCount * cardWidth + Mathf.Max(0, rowCount - 1) * spacing;

            RectTransform rect = (RectTransform)presentation.Tile.transform;
            rect.anchoredPosition = new Vector2(
                -rowWidth * 0.5f + cardWidth * 0.5f +
                column * (cardWidth + spacing) -
                CardChangeVisualOffset.x * scale,
                totalHeight * 0.5f - cardHeight * 0.5f -
                row * (cardHeight + spacing) -
                CardChangeVisualOffset.y * scale);

            presentation.BaseScale = Vector3.one * scale;
            presentation.ResultCard = resultCards[i];
            presentation.Tile.gameObject.SetActive(true);
            presentation.Tile.transform.localScale = presentation.BaseScale;
            presentation.Tile.Bind(sourceCards[i], null);
            presentation.Tile.SetInteractable(false);
            SetFlashAlpha(presentation.Flash, 0f);
        }

        for (int i = sourceCards.Count; i < _cardChangeCards.Count; i++)
            _cardChangeCards[i].Tile.gameObject.SetActive(false);

        RefreshResultText();
        if (_leaveButton != null) _leaveButton.interactable = false;

        if (_transformFlashDuration <= 0f)
        {
            BindCardChangeResults();
            if (_leaveButton != null) _leaveButton.interactable = true;
            return;
        }

        _cardChangeSequence = DOTween.Sequence().SetUpdate(true);
        for (int i = 0; i < sourceCards.Count; i++)
        {
            CardChangePresentation presentation = _cardChangeCards[i];
            Tween pulse = presentation.Tile.transform
                .DOScale(presentation.BaseScale * _transformPulseScale, _transformFlashDuration)
                .SetEase(Ease.OutQuad);
            Tween flash = presentation.Flash
                .DOFade(1f, _transformFlashDuration)
                .SetEase(Ease.InQuad);
            if (i == 0) _cardChangeSequence.Append(pulse);
            else _cardChangeSequence.Join(pulse);
            _cardChangeSequence.Join(flash);
        }

        _cardChangeSequence.AppendCallback(BindCardChangeResults);
        for (int i = 0; i < sourceCards.Count; i++)
        {
            CardChangePresentation presentation = _cardChangeCards[i];
            Tween restore = presentation.Tile.transform
                .DOScale(presentation.BaseScale, _transformFlashDuration)
                .SetEase(Ease.InOutQuad);
            Tween flash = presentation.Flash
                .DOFade(0f, _transformFlashDuration)
                .SetEase(Ease.OutQuad);
            if (i == 0) _cardChangeSequence.Append(restore);
            else _cardChangeSequence.Join(restore);
            _cardChangeSequence.Join(flash);
        }

        _cardChangeSequence.OnComplete(() =>
        {
            _cardChangeSequence = null;
            if (_leaveButton != null) _leaveButton.interactable = true;
        });
    }

    private CardChangePresentation GetOrCreateCardChangeCard(int index)
    {
        if (index < _cardChangeCards.Count) return _cardChangeCards[index];

        UIDeckCardTile tile = CreateCardTile(_transformCardRoot);
        RectTransform tileRect = (RectTransform)tile.transform;
        tileRect.sizeDelta = CardChangeSize;
        tile.SetInteractable(false);

        var flashObject = new GameObject(
            "CardChangeFlash", typeof(RectTransform), typeof(CanvasRenderer), typeof(Image));
        RectTransform flashRect = (RectTransform)flashObject.transform;
        flashRect.SetParent(tile.transform, false);
        flashRect.anchorMin = new Vector2(0.5f, 0.5f);
        flashRect.anchorMax = new Vector2(0.5f, 0.5f);
        flashRect.sizeDelta =
            _cardChangeFlashSprite != null ? CardChangeVisualSize : CardChangeSize;
        flashRect.anchoredPosition =
            _cardChangeFlashSprite != null ? CardChangeVisualOffset : Vector2.zero;
        flashRect.SetAsLastSibling();

        Image flash = flashObject.GetComponent<Image>();
        flash.sprite = _cardChangeFlashSprite;
        flash.color = new Color(1f, 1f, 1f, 0f);
        flash.raycastTarget = false;

        var presentation = new CardChangePresentation(tile, flash);
        _cardChangeCards.Add(presentation);
        return presentation;
    }

    private void BindCardChangeResults()
    {
        for (int i = 0; i < _cardChangeCards.Count; i++)
        {
            CardChangePresentation presentation = _cardChangeCards[i];
            if (!presentation.Tile.gameObject.activeSelf || presentation.ResultCard == null)
                continue;
            presentation.Tile.Bind(presentation.ResultCard, null);
            presentation.Tile.SetInteractable(false);
        }
    }

    private static float CalculateCardChangeGrid(
        int count, Vector2 areaSize, float spacing, out int columns, out int rows)
    {
        columns = 0;
        rows = 0;
        if (count <= 0 || areaSize.x <= 0f || areaSize.y <= 0f)
            return 0f;

        float bestScale = 0f;
        for (int candidateColumns = 1; candidateColumns <= count; candidateColumns++)
        {
            int candidateRows = Mathf.CeilToInt(count / (float)candidateColumns);
            float scale = Mathf.Min(
                areaSize.x /
                (candidateColumns * CardChangeVisualSize.x +
                 Mathf.Max(0, candidateColumns - 1) * spacing),
                areaSize.y /
                (candidateRows * CardChangeVisualSize.y +
                 Mathf.Max(0, candidateRows - 1) * spacing),
                1f);
            if (scale <= bestScale) continue;

            bestScale = scale;
            columns = candidateColumns;
            rows = candidateRows;
        }
        return Mathf.Max(0f, bestScale);
    }

    private static void SetFlashAlpha(Image flash, float alpha)
    {
        if (flash == null) return;
        Color color = flash.color;
        color.a = alpha;
        flash.color = color;
    }

    private void ShowCurrentQueuedResultCard()
    {
        if (_resultCardIndex < 0 || _resultCardIndex >= _resultCardQueue.Count)
            return;

        ResultCardPresentation item = _resultCardQueue[_resultCardIndex];
        Card sourceCard;
        Card resultCard;
        if (item.Kind == EResultCardPresentationKind.Transform)
        {
            sourceCard = CreatePreviewCard(
                item.Transform.SourceCardId, item.Transform.SourceDirection);
            resultCard = CreatePreviewCard(
                item.Transform.ResultCardId, item.Transform.ResultDirection);
        }
        else
        {
            // 코스트 변경은 같은 카드라 방향도 같고, 표시 코스트만 전/후로 갈린다.
            ChoiceEventCardCostResult change = item.CostChange;
            sourceCard = CreatePreviewCard(change.CardId, change.Direction, change.BeforeCost);
            resultCard = CreatePreviewCard(change.CardId, change.Direction, change.AfterCost);
        }

        PresentResultCards(sourceCard, resultCard);
    }

    /// <summary>
    /// 표시 전용 카드 생성. overrideCost 를 주면 영구 보정으로 그 값이 보이도록 맞춘다.
    /// </summary>
    private static Card CreatePreviewCard(
        string cardId, ECardDirection direction, int? overrideCost = null)
    {
        CardDataSO cardData = ResolveCardData(cardId);
        CardRuntimeData runtime = cardData != null ? CardFactory.FromSO(cardData) : null;
        if (runtime == null) return null;

        Card card = CardFactory.Create(runtime, direction);
        if (card != null && overrideCost.HasValue)
        {
            int previewDelta = overrideCost.Value - runtime.Cost;
            if (previewDelta != 0) card.ApplyPermanentCostDelta(previewDelta);
        }
        return card;
    }

    private static CardDataSO ResolveCardData(string cardId)
        => !string.IsNullOrEmpty(cardId) && DataManager.HasInstance && DataManager.Instance.IsLoaded
            ? DataManager.Instance.GetData<CardDataSO>(cardId)
            : null;

    private static string ResolveCardName(string cardId)
    {
        CardDataSO data = ResolveCardData(cardId);
        if (data == null) return cardId ?? string.Empty;
        string localized = L(data.DisplayNameKey);
        return string.IsNullOrWhiteSpace(localized) ? data.CardId : localized;
    }

    private void RefreshLeaveButtonText()
    {
        if (_leaveButtonText == null) return;
        bool hasNextResult = !_showingCardChangeBatch &&
                             _resultCardIndex + 1 < _resultCardQueue.Count;
        _leaveButtonText.text = L(hasNextResult
            ? LocalizationKeys.Common.Next
            : _leaveButtonKey);
    }

    private void ShowArrowResultCard(IReadOnlyList<ChoiceEventEffectResult> appliedResults)
    {
        ResetResultCardPresentation();

        ChoiceEventEffectResult arrowResult = default;
        for (int i = 0; i < appliedResults.Count; i++)
        {
            if (!appliedResults[i].HasArrowAddition) continue;
            arrowResult = appliedResults[i];
            break;
        }

        RunDeckEntry entry = arrowResult.ArrowTarget;
        if (entry?.RuntimeData == null) return;

        RunContext run = InGameController.HasInstance
            ? InGameController.Instance.CurrentRun
            : null;
        Card card = CardFactory.CreateRunDeckEntryPreview(entry, run);
        if (card == null) return;

        // 화살표 추가는 대상이 한 장뿐이라 결과 칸에만 띄운다.
        PresentResultCards(null, card);
        if (_resultCard != null)
            _resultArrowTween = _resultCard.PlayArrowStamp(arrowResult.AddedArrowDirection);
    }

    /// <summary>카드 타일은 처음 한 번만 만들고 이후에는 데이터만 재바인딩해 재사용한다.</summary>
    private UIDeckCardTile CreateCardTile(Transform root)
    {
        UIDeckCardTile tile = Instantiate(_resultCardPrefab, root);
        if (tile.transform is RectTransform cardRect)
        {
            cardRect.anchorMin = new Vector2(0.5f, 0.5f);
            cardRect.anchorMax = new Vector2(0.5f, 0.5f);
            cardRect.anchoredPosition = Vector2.zero;
        }
        return tile;
    }

    /// <summary>
    /// 원본·결과 카드를 함께 표시한다. sourceCard 가 null 이거나 원본 루트가 비어 있으면
    /// 결과 카드만 띄운다(화살표 추가처럼 대상이 한 장인 결과).
    /// </summary>
    private void PresentResultCards(Card sourceCard, Card resultCard)
    {
        ResetResultCardPresentation();
        if (_resultCardPrefab == null) return;

        bool showSource = sourceCard != null && _sourceCardRoot != null;
        bool showResult = resultCard != null && _resultCardRoot != null;
        if (!showSource && !showResult) return;

        if (showSource)
        {
            if (_sourceCard == null)
            {
                _sourceCard = CreateCardTile(_sourceCardRoot);
                _sourceCardBaseScale = _sourceCard.transform.localScale;
            }
            _sourceCardRoot.gameObject.SetActive(true);
            _sourceCard.gameObject.SetActive(true);
            _sourceCard.Bind(sourceCard, null);
            _sourceCard.SetInteractable(false);
        }

        if (showResult)
        {
            if (_resultCard == null)
            {
                _resultCard = CreateCardTile(_resultCardRoot);
                _resultCardBaseScale = _resultCard.transform.localScale;
            }
            _resultCardRoot.gameObject.SetActive(true);
            _resultCard.gameObject.SetActive(true);
            _resultCard.Bind(resultCard, null);
            _resultCard.SetInteractable(false);
        }

        if (_resultCardTransitionDuration <= 0f)
        {
            if (showSource) _sourceCard.transform.localScale = _sourceCardBaseScale;
            if (showResult) _resultCard.transform.localScale = _resultCardBaseScale;
            if (_leaveButton != null) _leaveButton.interactable = true;
            return;
        }

        // 원본을 먼저, 결과를 반 박자 늦게 띄워 "원본 → 결과" 방향이 읽히게 한다.
        // 떠나기 버튼은 마지막에 뜨는 카드의 연출이 끝나야 열린다.
        if (_leaveButton != null) _leaveButton.interactable = false;

        if (showSource)
        {
            _sourceCard.transform.localScale = _sourceCardBaseScale * 0.86f;
            _sourceCardTween = _sourceCard.transform
                .DOScale(_sourceCardBaseScale, _resultCardTransitionDuration)
                .SetEase(Ease.OutBack)
                .SetUpdate(true)
                .OnComplete(() =>
                {
                    _sourceCardTween = null;
                    if (!showResult && _leaveButton != null) _leaveButton.interactable = true;
                });
        }

        if (showResult)
        {
            _resultCard.transform.localScale = _resultCardBaseScale * 0.86f;
            _resultCardTween = _resultCard.transform
                .DOScale(_resultCardBaseScale, _resultCardTransitionDuration)
                .SetEase(Ease.OutBack)
                .SetDelay(showSource ? _resultCardTransitionDuration * 0.5f : 0f)
                .SetUpdate(true)
                .OnComplete(() =>
                {
                    _resultCardTween = null;
                    if (_leaveButton != null) _leaveButton.interactable = true;
                });
        }
    }

    private void ResetResultCardPresentation()
    {
        _cardChangeSequence?.Kill();
        _cardChangeSequence = null;
        _showingCardChangeBatch = false;
        for (int i = 0; i < _cardChangeCards.Count; i++)
        {
            CardChangePresentation presentation = _cardChangeCards[i];
            presentation.Tile.transform.DOKill();
            presentation.Flash.DOKill();
            presentation.Tile.transform.localScale = presentation.BaseScale;
            presentation.ResultCard = null;
            presentation.Tile.gameObject.SetActive(false);
            SetFlashAlpha(presentation.Flash, 0f);
        }
        if (_transformCardRoot != null)
            _transformCardRoot.gameObject.SetActive(false);

        _resultCardTween?.Kill();
        _resultCardTween = null;
        _sourceCardTween?.Kill();
        _sourceCardTween = null;
        _resultArrowTween?.Kill();
        _resultArrowTween = null;
        if (_resultCard != null)
        {
            _resultCard.transform.localScale = _resultCardBaseScale;
            _resultCard.gameObject.SetActive(false);
        }
        if (_sourceCard != null)
        {
            _sourceCard.transform.localScale = _sourceCardBaseScale;
            _sourceCard.gameObject.SetActive(false);
        }
        if (_resultCardRoot != null)
            _resultCardRoot.gameObject.SetActive(false);
        if (_sourceCardRoot != null)
            _sourceCardRoot.gameObject.SetActive(false);
        if (_leaveButton != null) _leaveButton.interactable = true;
    }

    private void DestroyResultCard()
    {
        ResetResultCardPresentation();
        if (_resultCard != null)
            Destroy(_resultCard.gameObject);
        _resultCard = null;
        if (_sourceCard != null)
            Destroy(_sourceCard.gameObject);
        _sourceCard = null;
        _cardChangeCards.Clear();
    }

    private void OnLeaveClicked()
    {
        if (!_showingCardChangeBatch &&
            _resultCardIndex + 1 < _resultCardQueue.Count)
        {
            _resultCardIndex++;
            RefreshResultText();
            ShowCurrentQueuedResultCard();
            RefreshLeaveButtonText();
            return;
        }

        // 연출 중이어도 즉시 정리하고 이벤트를 종료한다.
        ResetResultCardPresentation();
        _completion?.TrySetResult();
    }

    private void HideAllSlots()
    {
        for (int i = 0; i < _slots.Count; i++)
            if (_slots[i] != null) _slots[i].gameObject.SetActive(false);
    }

    private void SetAllInteractable(bool interactable)
    {
        for (int i = 0; i < _slots.Count; i++)
            if (_slots[i] != null && _slots[i].gameObject.activeSelf)
                _slots[i].SetInteractable(interactable);
    }

    private void OnDestroy()
    {
        DestroyResultCard();
        if (_leaveButton != null) _leaveButton.onClick.RemoveListener(OnLeaveClicked);
    }

    private static string L(string key)
        => string.IsNullOrEmpty(key) ? string.Empty
            : LocalizationManager.HasInstance ? LocalizationManager.Instance.Get(key) : key;
}
