﻿// =================================================================
// [스크립트 목적]  Rest 노드 Reinforce 메인 창. 강화 시작/무시만 선택한다.
// [의존 관계]      - UIPopupBase / ReinforceController / UIDeckCardPicker
// =================================================================

using System;
using DG.Tweening;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public sealed class UIReinforcePopup : UIPopupBase
{
    /// <summary>휴식·이벤트에서 버튼으로 연 하위 UI — ESC 로 닫고 부모로 돌아간다.</summary>
    public override bool CloseOnEscape => true;

    private const string TitleText = "UI_REST_REINFORCE_BUTTON";
    private const string StartTitleKey = "UI_REINFORCE_START";
    private const string DescriptionKey = "UI_REINFORCE_DESC";
    private const string DeckChooseKey = "UI_REINFORCE_DECKCHOOSE";
    private const string GoBackKey = "UI_REINFORCE_GOBACK";
    private const string DoneTextKey = "UI_REINFORCE_DONE";
    private const string DirectionPromptKey = "UI_REINFORCE_DIRECTION_PROMPT";
    private const string NextKey = "UI_REINFORCE_NEXT";

    [Header("표시")]
    [SerializeField] private TMP_Text _titleText;
    [SerializeField] private TMP_Text _statusText;
    [SerializeField] private GameObject _mainRoot;

    [Header("버튼")]
    [SerializeField] private Button _reinforceButton;
    [SerializeField] private TMP_Text _reinforceButtonText;
    [SerializeField] private Button _ignoreButton;
    [SerializeField] private TMP_Text _ignoreButtonText;

    [Header("강화 결과")]
    [SerializeField] private GameObject _resultRoot;
    [SerializeField] private Transform _resultCardRoot;
    [SerializeField] private UIDeckCardTile _resultCardPrefab;
    [SerializeField] private Button _animationSkipButton;
    [SerializeField] private Button _nextButton;
    [SerializeField] private TMP_Text _nextButtonText;

    [Header("방향 선택")]
    [SerializeField] private Button _directionBackButton;
    [SerializeField] private CanvasGroup _directionArrowGroup;
    [SerializeField] private Button _directionUpButton;
    [SerializeField] private Button _directionDownButton;
    [SerializeField] private Button _directionLeftButton;
    [SerializeField] private Button _directionRightButton;

    private static bool s_pendingReinforced;

    private bool _reinforced;
    private bool _resolved;
    private bool _showingResult;
    private bool _animationComplete;
    private bool _selectingDirection;
    private bool _keepViewOnDirectionBack;
    private bool _directionBackAllowed = true;
    private int _selectedEntryId;
    private string _directionTitleKey;
    private UIDeckCardTile _resultCard;
    private Tween _stampTween;
    private Tween _directionPulseTween;

    public event Action OnReinforceRequested;
    public event Action OnIgnoreRequested;
    public event Action OnNextRequested;
    public event Action<int, ECardDirection> OnDirectionConfirmed;
    public event Action OnDirectionBackRequested;

    public static void Show(bool reinforced)
    {
        s_pendingReinforced = reinforced;
    }

    protected override void Init()
    {
        _reinforceButton?.onClick.AddListener(HandleReinforce);
        _ignoreButton?.onClick.AddListener(HandleIgnore);
        _animationSkipButton?.onClick.AddListener(HandleSkipAnimation);
        _nextButton?.onClick.AddListener(HandleNext);
        _directionBackButton?.onClick.AddListener(HandleDirectionBack);
        _directionUpButton?.onClick.AddListener(HandleDirectionUp);
        _directionDownButton?.onClick.AddListener(HandleDirectionDown);
        _directionLeftButton?.onClick.AddListener(HandleDirectionLeft);
        _directionRightButton?.onClick.AddListener(HandleDirectionRight);
    }

    protected override void Setup()
    {
        _resolved = false;
        _reinforced = s_pendingReinforced;
        _showingResult = false;
        _animationComplete = false;
        _selectingDirection = false;
        _keepViewOnDirectionBack = false;
        _directionBackAllowed = true;
        _selectedEntryId = 0;
        _directionTitleKey = null;
        StopDirectionPulse();
        ClearResultCard();
        if (_nextButtonText != null) _nextButtonText.text = Localize(NextKey);
        if (_resultRoot != null) _resultRoot.SetActive(false);
        ShowMain(_reinforced ? Localize(DoneTextKey) : null);
    }

    public override void OnLocalize()
    {
        base.OnLocalize();

        if (_nextButtonText != null) _nextButtonText.text = Localize(NextKey);

        if (_selectingDirection)
        {
            if (!string.IsNullOrEmpty(_directionTitleKey))
                SetTitle(Localize(_directionTitleKey));
            return;
        }

        if (_showingResult)
        {
            SetTitle(Localize(TitleText));
            return;
        }

        SetTitle(Localize(StartTitleKey));
        if (_reinforceButtonText != null) _reinforceButtonText.text = Localize(DeckChooseKey);
        if (_ignoreButtonText != null) _ignoreButtonText.text = Localize(GoBackKey);
        SetStatus(Localize(_reinforced ? DoneTextKey : DescriptionKey));
    }

    public void MarkReinforced()
    {
        _reinforced = true;
        ShowMain(Localize(DoneTextKey));
    }

    public void ShowReinforceResult(RunDeckEntry entry, ECardDirection addedDirection)
    {
        _reinforced = true;
        _selectingDirection = false;
        _showingResult = true;
        _animationComplete = false;
        StopDirectionPulse();
        ClearResultCard();

        SetTitle(Localize(TitleText));
        SetStatus(null);
        if (_mainRoot != null) _mainRoot.SetActive(false);
        if (_resultRoot != null) _resultRoot.SetActive(true);
        if (_directionBackButton != null) _directionBackButton.gameObject.SetActive(false);
        if (_directionArrowGroup != null) _directionArrowGroup.gameObject.SetActive(false);
        if (_animationSkipButton != null) _animationSkipButton.gameObject.SetActive(true);
        if (_nextButton != null) _nextButton.gameObject.SetActive(false);

        if (entry?.RuntimeData == null || _resultCardPrefab == null || _resultCardRoot == null)
        {
            CompleteAnimation();
            return;
        }

        Card card = CreateRunDeckEntryPreview(entry);
        if (card == null)
        {
            CompleteAnimation();
            return;
        }

        _resultCard = Instantiate(_resultCardPrefab, _resultCardRoot);
        if (_resultCard.transform is RectTransform cardRect)
        {
            cardRect.anchorMin = new Vector2(0.5f, 0.5f);
            cardRect.anchorMax = new Vector2(0.5f, 0.5f);
            cardRect.anchoredPosition = Vector2.zero;
        }
        _resultCard.Bind(card, null);
        _resultCard.SetInteractable(false);

        _stampTween = _resultCard.PlayArrowStamp(addedDirection);
        if (_stampTween == null)
            CompleteAnimation();
        else
            _stampTween.OnComplete(CompleteAnimation);
    }

    public void ShowDirectionSelection(RunDeckEntry entry)
    {
        ECardDirection allowed = ECardDirection.None;
        if (entry != null)
        {
            if (entry.CanAddArrow(ECardDirection.Up)) allowed |= ECardDirection.Up;
            if (entry.CanAddArrow(ECardDirection.Down)) allowed |= ECardDirection.Down;
            if (entry.CanAddArrow(ECardDirection.Left)) allowed |= ECardDirection.Left;
            if (entry.CanAddArrow(ECardDirection.Right)) allowed |= ECardDirection.Right;
        }
        ShowDirectionSelection(entry, allowed, null, true);
    }

    public void ShowDirectionSelection(
        RunDeckEntry entry,
        ECardDirection allowedDirections,
        string title,
        bool allowBack)
    {
        if (entry == null || entry.RuntimeData == null) return;

        _selectedEntryId = entry.EntryId;
        _selectingDirection = true;
        _showingResult = false;
        _animationComplete = false;
        ClearResultCard();

        _directionBackAllowed = allowBack;
        _directionTitleKey = string.IsNullOrEmpty(title) ? DirectionPromptKey : null;
        SetTitle(_directionTitleKey != null ? Localize(_directionTitleKey) : title);
        SetStatus(null);
        if (_mainRoot != null) _mainRoot.SetActive(false);
        if (_resultRoot != null) _resultRoot.SetActive(true);
        if (_directionBackButton != null) _directionBackButton.gameObject.SetActive(allowBack);
        if (_directionArrowGroup != null) _directionArrowGroup.gameObject.SetActive(true);
        if (_animationSkipButton != null) _animationSkipButton.gameObject.SetActive(false);
        if (_nextButton != null) _nextButton.gameObject.SetActive(false);

        Card card = CreateRunDeckEntryPreview(entry);
        if (card != null && _resultCardPrefab != null && _resultCardRoot != null)
        {
            _resultCard = Instantiate(_resultCardPrefab, _resultCardRoot);
            if (_resultCard.transform is RectTransform cardRect)
            {
                cardRect.anchorMin = new Vector2(0.5f, 0.5f);
                cardRect.anchorMax = new Vector2(0.5f, 0.5f);
                cardRect.anchoredPosition = Vector2.zero;
            }
            _resultCard.Bind(card, null);
            _resultCard.SetInteractable(false);
        }

        SetDirectionAvailable(_directionUpButton, (allowedDirections & ECardDirection.Up) != 0);
        SetDirectionAvailable(_directionDownButton, (allowedDirections & ECardDirection.Down) != 0);
        SetDirectionAvailable(_directionLeftButton, (allowedDirections & ECardDirection.Left) != 0);
        SetDirectionAvailable(_directionRightButton, (allowedDirections & ECardDirection.Right) != 0);
        StartDirectionPulse();
    }

    public override bool OnBackPressed()
    {
        if (_selectingDirection)
        {
            if (!_directionBackAllowed) return false;
            HandleDirectionBack();
            return false;
        }
        // 화살표로 강화를 마쳤으면 클리어 처리 → ESC 로 되돌아갈 수 없다.
        if (_showingResult || _reinforced) return false;
        MarkResolvedAndNotifyIgnore();
        return true;
    }

    public override void OnClose()
    {
        _stampTween?.Kill();
        _stampTween = null;
        StopDirectionPulse();
        ClearResultCard();

        if (!_resolved)
            OnIgnoreRequested?.Invoke();

        OnReinforceRequested = null;
        OnIgnoreRequested = null;
        OnNextRequested = null;
        OnDirectionConfirmed = null;
        OnDirectionBackRequested = null;
        base.OnClose();
    }

    private void ShowMain(string status = null)
    {
        SetTitle(Localize(StartTitleKey));
        if (_reinforceButtonText != null) _reinforceButtonText.text = Localize(DeckChooseKey);
        if (_ignoreButtonText != null) _ignoreButtonText.text = Localize(GoBackKey);
        if (_mainRoot != null)
            _mainRoot.SetActive(true);
        if (_resultRoot != null)
            _resultRoot.SetActive(false);
        SetStatus(string.IsNullOrEmpty(status) ? Localize(DescriptionKey) : status);

        if (_reinforceButton != null)
            _reinforceButton.interactable = !_reinforced;
    }

    private void HandleSkipAnimation()
    {
        if (!_showingResult || _animationComplete) return;
        if (_stampTween != null && _stampTween.IsActive())
            _stampTween.Complete(true);
        else
            CompleteAnimation();
    }

    private void CompleteAnimation()
    {
        if (_animationComplete) return;
        _animationComplete = true;
        _stampTween = null;
        if (_animationSkipButton != null) _animationSkipButton.gameObject.SetActive(false);
        if (_nextButton != null) _nextButton.gameObject.SetActive(true);
    }

    private void HandleNext()
    {
        if (!_showingResult || !_animationComplete || _resolved) return;
        _resolved = true;
        _showingResult = false;
        OnNextRequested?.Invoke();
        RequestClose();
    }

    private void HandleReinforce()
    {
        if (_reinforced) return;
        OnReinforceRequested?.Invoke();
    }

    private void HandleDirectionUp() => ConfirmDirection(ECardDirection.Up);
    private void HandleDirectionDown() => ConfirmDirection(ECardDirection.Down);
    private void HandleDirectionLeft() => ConfirmDirection(ECardDirection.Left);
    private void HandleDirectionRight() => ConfirmDirection(ECardDirection.Right);

    private void ConfirmDirection(ECardDirection direction)
    {
        if (!_selectingDirection) return;

        _selectingDirection = false;
        StopDirectionPulse();
        OnDirectionConfirmed?.Invoke(_selectedEntryId, direction);
    }

    /// <summary>휴식 흐름 전용 — 방향 선택 뒤로가기 시 메인 화면으로 전환하지 않고
    /// 현재 화면을 유지한다 (호출부가 피커를 띄운 뒤 이 팝업을 닫는 동안 화면 깜빡임 방지).</summary>
    public void SetKeepViewOnDirectionBack(bool keep)
    {
        _keepViewOnDirectionBack = keep;
    }

    private void HandleDirectionBack()
    {
        if (!_selectingDirection || !_directionBackAllowed) return;

        _selectingDirection = false;
        StopDirectionPulse();
        if (!_keepViewOnDirectionBack)
        {
            ClearResultCard();
            ShowMain();
        }
        OnDirectionBackRequested?.Invoke();
    }

    private void HandleIgnore()
    {
        MarkResolvedAndNotifyIgnore();
        RequestClose();
    }

    private void MarkResolvedAndNotifyIgnore()
    {
        if (_resolved) return;
        _resolved = true;
        OnIgnoreRequested?.Invoke();
    }

    private static Card CreateRunDeckEntryPreview(RunDeckEntry entry)
    {
        RunContext run = InGameController.HasInstance
            ? InGameController.Instance.CurrentRun
            : null;
        return CardFactory.CreateRunDeckEntryPreview(entry, run);
    }

    private void SetStatus(string text)
    {
        if (_statusText != null)
            _statusText.text = string.IsNullOrEmpty(text) ? string.Empty : text;
    }

    private void SetTitle(string text)
    {
        if (_titleText != null)
            _titleText.text = text ?? string.Empty;
    }

    private static void SetDirectionAvailable(Button button, bool available)
    {
        if (button == null) return;
        button.gameObject.SetActive(available);
        button.interactable = available;
    }

    private void StartDirectionPulse()
    {
        StopDirectionPulse();
        if (_directionArrowGroup == null) return;

        _directionArrowGroup.alpha = 1f;
        _directionPulseTween = _directionArrowGroup.DOFade(0.35f, 0.55f)
            .SetLoops(-1, LoopType.Yoyo)
            .SetUpdate(true);
    }

    private void StopDirectionPulse()
    {
        _directionPulseTween?.Kill();
        _directionPulseTween = null;
        if (_directionArrowGroup != null)
            _directionArrowGroup.alpha = 1f;
    }

    private void ClearResultCard()
    {
        if (_resultCard != null) Destroy(_resultCard.gameObject);
        _resultCard = null;
    }

    private static string Localize(string key)
    {
        return LocalizationManager.HasInstance
            ? LocalizationManager.Instance.Get(key)
            : key;
    }

    private void OnDestroy()
    {
        _reinforceButton?.onClick.RemoveListener(HandleReinforce);
        _ignoreButton?.onClick.RemoveListener(HandleIgnore);
        _animationSkipButton?.onClick.RemoveListener(HandleSkipAnimation);
        _nextButton?.onClick.RemoveListener(HandleNext);
        _directionBackButton?.onClick.RemoveListener(HandleDirectionBack);
        _directionUpButton?.onClick.RemoveListener(HandleDirectionUp);
        _directionDownButton?.onClick.RemoveListener(HandleDirectionDown);
        _directionLeftButton?.onClick.RemoveListener(HandleDirectionLeft);
        _directionRightButton?.onClick.RemoveListener(HandleDirectionRight);
    }
}
