// =================================================================
// [스크립트 목적]  런 패배 통계를 보여주고 타이틀 복귀를 제공한다.
//                 (전투 패배 = 런 종료. 승리 흐름의 UIRewardPopup 과 분리)
// [주요 변수]      - _titleText/_titleButtonText : 로컬라이징 텍스트
//                  - _statisticsRoot/_statisticsSlotPrefab : 4x2 결과 통계
//                  - _titleButton : 타이틀 복귀
//                  - s_pendingStatistics : 열기 직전 주입되는 런 결과 스냅샷
// [의존 관계]      - UIPopupBase / UIManager
//                  - InGameController 가 Show 로 통계 주입 + 콜백 구독
// [배치]           UIManager 로 여는 Popup. 키 = 타입 이름(UIGameOverPopup).
//                  씬 상주 금지 — 프리팹 등록, 열 때 Instantiate.
// [이름 정리]      - UIRewardPopup     = "전리품 리스트 창" (승리)
//                  - UICardSelectPopup = "카드 1택 선택 창"
//                  - UIGameOverPopup   = "패배 화면" (이 클래스)
// [설계 노트]      - 패배는 보상이 없으므로 결과 표시 + 진행 버튼만 둔다.
//                  - 닫기(ESC/딤)는 막는다 — 타이틀 복귀 버튼으로만 진행하도록.
//                    (UIPopupBase 의 _closeOnDim 을 끄고 OnBackPressed 를 false 로)
// =================================================================

using System;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// 런 패배 통계를 표시하고 타이틀 복귀를 받는다.
/// 선택 결과는 OnTitleRequested 로 통지하고, 실제 흐름은 컨트롤러가 처리한다.
/// </summary>
public sealed class UIGameOverPopup : UIPopupBase
{
    [Header("텍스트")]
    [SerializeField] private TMP_Text _titleText;
    [SerializeField] private TMP_Text _titleButtonText;

    [Header("통계")]
    [SerializeField] private RectTransform _statisticsRoot;
    [SerializeField] private UIStatisticsSlot _statisticsSlotPrefab;

    [Header("버튼")]
    [Tooltip("타이틀 복귀")]
    [SerializeField] private Button _titleButton;

    private static RunStatisticsSnapshot s_pendingStatistics;
    private bool _titleRequested;
    private RunStatisticsSnapshot _statistics;
    private readonly List<UIStatisticsSlot> _spawnedStatistics = new List<UIStatisticsSlot>(8);

    /// <summary>타이틀 복귀 요청.</summary>
    public event Action OnTitleRequested;

    public static void Show(RunStatisticsSnapshot statistics) => s_pendingStatistics = statistics;

    protected override void Init()
    {
        if (_titleButton != null) _titleButton.onClick.AddListener(HandleTitle);
    }

    protected override void Setup()
    {
        _titleRequested = false;
        if (_titleButton != null)
            _titleButton.interactable = true;
        _statistics = s_pendingStatistics;
        RebuildStatistics();
    }

    public override void OnLocalize()
    {
        base.OnLocalize();
        if (_titleText != null) _titleText.text = Localize(LocalizationKeys.GameOver.Title);
        if (_titleButtonText != null) _titleButtonText.text = Localize(LocalizationKeys.EscMenu.TitleScreen);
        RebuildStatistics();
    }

    public override void OnClose()
    {
        RunStatisticsUIBuilder.Clear(_spawnedStatistics);
        _statistics = null;
        s_pendingStatistics = null;
        base.OnClose();
    }

    /// <summary>패배 화면은 닫기를 막는다 — 타이틀 복귀 버튼으로만 진행.</summary>
    public override bool OnBackPressed() => false;

    private void HandleTitle()
    {
        if (_titleRequested) return;

        _titleRequested = true;
        if (_titleButton != null)
            _titleButton.interactable = false;
        OnTitleRequested?.Invoke();
    }

    private void RebuildStatistics()
        => RunStatisticsUIBuilder.Rebuild(
            _statisticsRoot,
            _statisticsSlotPrefab,
            _statistics,
            _spawnedStatistics);

    private static string Localize(string key)
        => LocalizationManager.HasInstance && LocalizationManager.Instance.HasKey(key)
            ? LocalizationManager.Instance.Get(key)
            : key ?? string.Empty;

    private void OnDestroy()
    {
        RunStatisticsUIBuilder.Clear(_spawnedStatistics);
        if (_titleButton != null) _titleButton.onClick.RemoveListener(HandleTitle);
        OnTitleRequested = null;
    }
}
