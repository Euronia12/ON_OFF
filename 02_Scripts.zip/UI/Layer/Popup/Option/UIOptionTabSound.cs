// =================================================================
// [스크립트 목적]  사운드 옵션 탭. 볼륨 4채널 + 채널별/전체/백그라운드 음소거
// [의존 관계]      - MonoBehaviour, SettingsManager, UGUI, UIExtensions
// [원칙]           위젯 변경 → SettingsManager.SetXxx (즉시 미리듣기). 확정은 UIOptions.Commit.
// =================================================================
using System;
using UnityEngine;
using UnityEngine.UI;
using Cysharp.Threading.Tasks;

public class UIOptionTabSound : MonoBehaviour
{
    [Header("로컬라이징")]
    [SerializeField] private LocalizedTMPBinding[] _localizedTexts;

    [Header("볼륨 슬라이더")]
    [Tooltip("마스터 볼륨 (0~1)")]
    [SerializeField] private Slider _masterSlider;
    [SerializeField] private Slider _bgmSlider;
    [SerializeField] private Slider _sfxSlider;
    [SerializeField] private Slider _uiSlider;

    [Header("미리듣기")]
    [Tooltip("BGM 볼륨 조절 시 반복 재생할 BGM Addressable 키")]
    [SerializeField] private string _bgmPreviewKey = AudioKeys.Bgm.TITLE;
    [Tooltip("SFX 볼륨 조절 시 SFX 채널로 재생할 Addressable 키")]
    [SerializeField] private string _sfxPreviewKey = AudioKeys.Battle.CHAIN_LASER;
    [Tooltip("UI·마스터 볼륨 조절 시 UI 채널로 재생할 Addressable 키")]
    [SerializeField] private string _uiPreviewKey = AudioKeys.Ui.BUTTON;

    [Header("음소거 토글")]
    [Tooltip("전체 음소거 (마스터). 켜면 전 채널 무음")]
    [SerializeField] private Toggle _masterMuteToggle;
    [SerializeField] private Toggle _bgmMuteToggle;
    [SerializeField] private Toggle _sfxMuteToggle;
    [SerializeField] private Toggle _uiMuteToggle;
    [Tooltip("앱이 백그라운드로 가면 자동 음소거")]
    [SerializeField] private Toggle _bgMuteToggle;

    // Sync 중 onValueChanged 역호출 차단
    private bool _isSyncing;
    private int _sfxPreviewGeneration;
    private int _uiPreviewGeneration;
    private bool Guard() => !_isSyncing && SettingsManager.HasInstance;

    public void SyncFromSettings()
    {
        if (!SettingsManager.HasInstance) return;
        var s = SettingsManager.Instance.Current;

        _isSyncing = true;
        _masterSlider.SetValueSafe(s.MasterVolume);
        _bgmSlider.SetValueSafe(s.BgmVolume);
        _sfxSlider.SetValueSafe(s.SfxVolume);
        _uiSlider.SetValueSafe(s.UiVolume);
        _masterMuteToggle.SetIsOnSafe(s.IsMuted);
        _bgmMuteToggle.SetIsOnSafe(s.BgmMuted);
        _sfxMuteToggle.SetIsOnSafe(s.SfxMuted);
        _uiMuteToggle.SetIsOnSafe(s.UiMuted);
        _bgMuteToggle.SetIsOnSafe(s.MuteOnBackground);
        _isSyncing = false;
    }

    public void RefreshLocalization()
    {
        OptionLocalizationUtility.Apply(_localizedTexts);
    }

    public void RegisterListeners()
    {
        _masterSlider?.onValueChanged.AddListener(OnMasterVolume);
        _bgmSlider?.onValueChanged.AddListener(OnBgmVolume);
        _sfxSlider?.onValueChanged.AddListener(OnSfxVolume);
        _uiSlider?.onValueChanged.AddListener(OnUiVolume);
        _masterMuteToggle?.onValueChanged.AddListener(OnMasterMute);
        _bgmMuteToggle?.onValueChanged.AddListener(OnBgmMute);
        _sfxMuteToggle?.onValueChanged.AddListener(OnSfxMute);
        _uiMuteToggle?.onValueChanged.AddListener(OnUiMute);
        _bgMuteToggle?.onValueChanged.AddListener(OnBackgroundMute);
    }

    public void UnregisterListeners()
    {
        _masterSlider?.onValueChanged.RemoveListener(OnMasterVolume);
        _bgmSlider?.onValueChanged.RemoveListener(OnBgmVolume);
        _sfxSlider?.onValueChanged.RemoveListener(OnSfxVolume);
        _uiSlider?.onValueChanged.RemoveListener(OnUiVolume);
        _masterMuteToggle?.onValueChanged.RemoveListener(OnMasterMute);
        _bgmMuteToggle?.onValueChanged.RemoveListener(OnBgmMute);
        _sfxMuteToggle?.onValueChanged.RemoveListener(OnSfxMute);
        _uiMuteToggle?.onValueChanged.RemoveListener(OnUiMute);
        _bgMuteToggle?.onValueChanged.RemoveListener(OnBackgroundMute);
        _sfxPreviewGeneration++;
        _uiPreviewGeneration++;
        StopBgmPreview();
    }

    private void OnMasterVolume(float v)
    {
        if (!Guard()) return;
        SettingsManager.Instance.SetMasterVolume(v);
        PlayUiPreview();
    }
    private void OnBgmVolume(float v)
    {
        if (!Guard()) return;
        SettingsManager.Instance.SetBgmVolume(v);
        PlayBgmPreview();
    }
    private void OnSfxVolume(float v)
    {
        if (!Guard()) return;
        SettingsManager.Instance.SetSfxVolume(v);
        PlaySfxPreviewAfterInputSettlesAsync(++_sfxPreviewGeneration).Forget();
    }
    private void OnUiVolume(float v)
    {
        if (!Guard()) return;
        SettingsManager.Instance.SetUiVolume(v);
        PlayUiPreviewAfterInputSettlesAsync(++_uiPreviewGeneration).Forget();
    }
    private void OnMasterMute(bool on) { if (Guard()) SettingsManager.Instance.SetMuted(on); }
    private void OnBgmMute(bool on) { if (Guard()) SettingsManager.Instance.SetBgmMuted(on); }
    private void OnSfxMute(bool on) { if (Guard()) SettingsManager.Instance.SetSfxMuted(on); }
    private void OnUiMute(bool on) { if (Guard()) SettingsManager.Instance.SetUiMuted(on); }
    private void OnBackgroundMute(bool on) { if (Guard()) SettingsManager.Instance.SetMuteOnBackground(on); }

    /// <summary>UIOptions가 BGM 슬라이더 밖을 클릭했을 때 호출한다.</summary>
    public void StopBgmPreview()
    {
        if (AudioManager.HasInstance)
            AudioManager.Instance.StopBgmPreview();
    }

    /// <summary>클릭 대상이 BGM 슬라이더 또는 그 자식인지 확인한다.</summary>
    public bool IsBgmSliderTarget(GameObject target)
    {
        if (_bgmSlider == null || target == null) return false;
        return target == _bgmSlider.gameObject || target.transform.IsChildOf(_bgmSlider.transform);
    }

    /// <summary>포인터·키보드·게임패드 입력 모두에서 값 변경이 멈춘 뒤 SFX를 한 번 재생한다.</summary>
    private async UniTaskVoid PlaySfxPreviewAfterInputSettlesAsync(int generation)
    {
        await UniTask.Delay(TimeSpan.FromMilliseconds(150), DelayType.UnscaledDeltaTime);
        if (generation != _sfxPreviewGeneration || !Guard()) return;
        PlaySfxPreview();
    }

    /// <summary>포인터·키보드·게임패드 입력 모두에서 값 변경이 멈춘 뒤 UI음을 한 번 재생한다.</summary>
    private async UniTaskVoid PlayUiPreviewAfterInputSettlesAsync(int generation)
    {
        await UniTask.Delay(TimeSpan.FromMilliseconds(150), DelayType.UnscaledDeltaTime);
        if (generation != _uiPreviewGeneration || !Guard()) return;
        PlayUiPreview();
    }

    private void PlayBgmPreview()
    {
        if (!AudioManager.HasInstance || string.IsNullOrWhiteSpace(_bgmPreviewKey)) return;
        AudioManager.Instance.PlayBgmPreviewAsync(_bgmPreviewKey).Forget();
    }

    private void PlaySfxPreview()
    {
        if (!AudioManager.HasInstance || string.IsNullOrWhiteSpace(_sfxPreviewKey)) return;
        AudioManager.Instance.PlaySfxAsync(_sfxPreviewKey).Forget();
    }

    private void PlayUiPreview()
    {
        if (!AudioManager.HasInstance || string.IsNullOrWhiteSpace(_uiPreviewKey)) return;
        AudioManager.Instance.PlayUiAsync(_uiPreviewKey).Forget();
    }
}
