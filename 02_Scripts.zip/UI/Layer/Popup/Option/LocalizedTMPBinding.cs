using System;
using TMPro;

[Serializable]
public sealed class LocalizedTMPBinding
{
    public TMP_Text Text;
    public string Key;
}

public static class OptionLocalizationUtility
{
    public static void Apply(LocalizedTMPBinding[] bindings)
    {
        if (bindings == null) return;

        TMP_FontAsset font = LocalizedFontUtility.CurrentFont;
        for (int i = 0; i < bindings.Length; i++)
        {
            var binding = bindings[i];
            if (binding?.Text == null) continue;

            LocalizedFontUtility.ApplyFont(binding.Text, font);
            binding.Text.text = LocalizationManager.HasInstance
                ? LocalizationManager.Instance.Get(binding.Key)
                : binding.Key;
        }
    }

    public static string Get(string key)
    {
        return LocalizationManager.HasInstance
            ? LocalizationManager.Instance.Get(key)
            : key;
    }

    public static TMP_FontAsset GetCurrentFont()
    {
        return LocalizedFontUtility.CurrentFont;
    }

    public static void ApplyFont(TMP_Text text)
    {
        LocalizedFontUtility.ApplyCurrentFont(text);
    }

    public static void ApplyFont(TMP_Text text, TMP_FontAsset font)
    {
        LocalizedFontUtility.ApplyFont(text, font);
    }

    public static void ApplyFont(TMP_Dropdown dropdown)
    {
        LocalizedFontUtility.ApplyCurrentFont(dropdown);
    }
}
