﻿// =================================================================
// [스크립트 목적]  그래픽+화면 옵션 탭. 품질·프레임·VSync·밝기(즉시) + 해상도·화면모드(적용확인)
// [의존 관계]      - MonoBehaviour, SettingsManager, UGUI, UIExtensions
// [원칙]           안전 항목은 즉시 미리보기. 화면(해상도/모드)은 값만 담고 ApplyScreenChange로 적용
//                  + 15초 자동 원복 확인 흐름. OnScreenConfirmTick 구독해 카운트다운 표시.
// =================================================================
using System.Collections.Generic;
using System.Threading;
using Cysharp.Threading.Tasks;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class UIOptionTabGraphics : MonoBehaviour
{
    private const float ENABLED_TEXT_ALPHA = 1f;
    private const float DISABLED_TEXT_ALPHA = 0.5f;

    private static readonly EFrameRateOption[] FrameRateOptions =
    {
        EFrameRateOption.Fps30,
        EFrameRateOption.Fps60,
        EFrameRateOption.Fps120
    };

    private static readonly EScreenMode[] ScreenModeOptions =
    {
        EScreenMode.FullScreen,
        EScreenMode.FullScreenWindow,
        EScreenMode.Windowed
    };

    [Header("로컬라이징")]
    [SerializeField] private LocalizedTMPBinding[] _localizedTexts;

    [Header("그래픽 (즉시 적용)")]
    [Tooltip("품질 프리셋 스테퍼. 항목 = QualitySettings 레벨")]
    [SerializeField] private UIStepper _qualityStepper;
    [Tooltip("프레임 제한 스테퍼 (30/60/120/무제한)")]
    [SerializeField] private UIStepper _frameRateStepper;
    [Tooltip("프레임 제한 항목 제목 텍스트")]
    [SerializeField] private TMP_Text _frameRateText;
    [Tooltip("프레임 제한 스테퍼의 현재 선택값 텍스트")]
    [SerializeField] private TMP_Text _frameRateValueText;
    [SerializeField] private Toggle _vsyncToggle;
    [Tooltip("밝기 슬라이더 (0.5~1.5 권장)")]
    [SerializeField] private Slider _brightnessSlider;

    [Header("화면 (적용 버튼 필요)")]
    [Tooltip("해상도 드롭다운. 항목 多·가변이라 드롭다운")]
    [SerializeField] private TMP_Dropdown _resolutionDropdown;
    [Tooltip("화면 모드 스테퍼 (전체/테두리없는창/창)")]
    [SerializeField] private UIStepper _screenModeStepper;
    [Tooltip("화면 설정 실제 적용 버튼 (15초 자동 원복 시작)")]
    [SerializeField] private Button _applyScreenButton;

    private string[] _qualityLabels = System.Array.Empty<string>();
    private bool _built;
    private UISystemConfirm _screenConfirm;
    private bool _openingScreenConfirm;
    private int _lastScreenConfirmRemaining;

    // 현재 모니터가 지원하는 해상도만 추린 목록. 드롭다운 인덱스는 이 목록 기준이다.
    private readonly List<EResolutionOption> _availableResolutions =
        new List<EResolutionOption>(SettingsManager.SupportedResolutions.Length);

    // 목록을 만들 때 기준이 된 디스플레이 해상도. 모니터가 바뀌면 재구성 판단에 쓴다.
    private int _builtForNativeWidth;
    private int _builtForNativeHeight;

    private bool _isSyncing;
    private bool Guard() => !_isSyncing && SettingsManager.HasInstance;

    private void Awake()
    {
        if (_qualityStepper != null)
            _qualityStepper.gameObject.SetActive(false);
    }

    public void SyncFromSettings()
    {
        // 디스플레이가 바뀌었으면(모니터 교체·듀얼 전환) 해상도 목록을 다시 만든다
        bool displayChanged = _builtForNativeWidth != Screen.currentResolution.width
            || _builtForNativeHeight != Screen.currentResolution.height;

        if (!_built || displayChanged) BuildStatic(force: displayChanged);
        if (!SettingsManager.HasInstance) return;
        var s = SettingsManager.Instance.Current;

        _isSyncing = true;
        _frameRateStepper.SetIndexSafe(FrameRateToIndex(SettingsManager.ToFrameRateOption(s.TargetFrameRate)));
        _vsyncToggle.SetIsOnSafe(s.VSyncCount > 0);
        UpdateFrameRateInteractability(s.VSyncCount > 0);
        _brightnessSlider.SetValueSafe(s.Brightness);
        _resolutionDropdown.SetValueSafe(ResolutionToIndex(SettingsManager.ToResolutionOption(s.ScreenWidth, s.ScreenHeight)));
        _screenModeStepper.SetIndexSafe(ScreenModeToIndex(s.ScreenMode));
        _isSyncing = false;
    }

    public void RefreshLocalization()
    {
        OptionLocalizationUtility.Apply(_localizedTexts);
        BuildStatic(force: true);
        SyncFromSettings();
    }

    public void RegisterListeners()
    {
        _frameRateStepper?.OnChanged.AddListener(OnFrameRate);
        _vsyncToggle?.onValueChanged.AddListener(OnVsync);
        _brightnessSlider?.onValueChanged.AddListener(OnBrightness);

        _resolutionDropdown?.onValueChanged.AddListener(OnResolution);
        _screenModeStepper?.OnChanged.AddListener(OnScreenMode);
        _applyScreenButton?.onClick.AddListener(OnApplyScreen);

        if (SettingsManager.HasInstance)
        {
            SettingsManager.Instance.OnScreenConfirmTick += OnScreenConfirmTick;
            SettingsManager.Instance.OnScreenSettingsApplied += OnScreenSettingsApplied;
        }
    }

    public void UnregisterListeners()
    {
        _frameRateStepper?.OnChanged.RemoveListener(OnFrameRate);
        _vsyncToggle?.onValueChanged.RemoveListener(OnVsync);
        _brightnessSlider?.onValueChanged.RemoveListener(OnBrightness);

        _resolutionDropdown?.onValueChanged.RemoveListener(OnResolution);
        _screenModeStepper?.OnChanged.RemoveListener(OnScreenMode);
        _applyScreenButton?.onClick.RemoveListener(OnApplyScreen);

        if (SettingsManager.HasInstance)
        {
            SettingsManager.Instance.OnScreenConfirmTick -= OnScreenConfirmTick;
            SettingsManager.Instance.OnScreenSettingsApplied -= OnScreenSettingsApplied;
        }

        CloseScreenConfirm();
    }

    // ─────────────────────────────────────────────
    // 정적 구성 (최초 1회)
    // ─────────────────────────────────────────────
    private void BuildStatic(bool force = false)
    {
        if (_built && !force) return;

        TMP_FontAsset font = OptionLocalizationUtility.GetCurrentFont();
        _frameRateStepper?.ApplyFont(font);
        _screenModeStepper?.ApplyFont(font);
        OptionLocalizationUtility.ApplyFont(_resolutionDropdown);

        _frameRateStepper?.SetOptions(BuildFrameRateLabels());
        _screenModeStepper?.SetOptions(BuildScreenModeLabels());
        BuildResolutionDropdown();
        _built = true;
    }

    private void BuildResolutionDropdown()
    {
        if (_resolutionDropdown == null) return;

        BuildAvailableResolutions();

        OptionLocalizationUtility.ApplyFont(_resolutionDropdown);
        _resolutionDropdown.ClearOptions();
        var labels = new List<string>(_availableResolutions.Count);
        for (int i = 0; i < _availableResolutions.Count; i++)
            labels.Add(GetResolutionLabel(_availableResolutions[i]));
        _resolutionDropdown.AddOptions(labels);
    }

    /// <summary>
    /// 게임 지원 목록 중 현재 모니터가 표시할 수 있는 해상도만 추린다.
    /// 모니터가 지원하지 않는 값은 선택해도 실제로 적용되지 않아 "적용했는데 안 바뀐다"는 혼란만 준다.
    /// </summary>
    private void BuildAvailableResolutions()
    {
        _availableResolutions.Clear();

        Resolution[] supported = Screen.resolutions;
        int nativeWidth = Screen.currentResolution.width;
        int nativeHeight = Screen.currentResolution.height;

        _builtForNativeWidth = nativeWidth;
        _builtForNativeHeight = nativeHeight;

        // 현재 설정값은 모니터 지원 여부와 무관하게 남긴다.
        // 다른 모니터에서 저장한 값이 이월된 경우 목록에서 빠지면 표시가 실제 설정과 어긋난다.
        EResolutionOption current = SettingsManager.HasInstance
            ? SettingsManager.ToResolutionOption(
                SettingsManager.Instance.Current.ScreenWidth,
                SettingsManager.Instance.Current.ScreenHeight)
            : SettingsManager.ToResolutionOption(nativeWidth, nativeHeight);

        for (int i = 0; i < SettingsManager.SupportedResolutions.Length; i++)
        {
            EResolutionOption option = SettingsManager.SupportedResolutions[i];
            if (option == current)
            {
                _availableResolutions.Add(option);
                continue;
            }

            SettingsManager.ToResolution(option, out int width, out int height);
            if (width > nativeWidth || height > nativeHeight) continue;
            if (!IsSupportedByDisplay(supported, width, height)) continue;

            _availableResolutions.Add(option);
        }

        // 드라이버가 목록을 주지 않는 등으로 전부 걸러진 경우 최소 1개는 남긴다(빈 드롭다운 방지)
        if (_availableResolutions.Count == 0)
            _availableResolutions.Add(current);
    }

    /// <summary>디스플레이 지원 해상도 목록에 포함되는지. 목록 조회가 실패하면 필터하지 않는다.</summary>
    private static bool IsSupportedByDisplay(Resolution[] supported, int width, int height)
    {
        if (supported == null || supported.Length == 0) return true;

        for (int i = 0; i < supported.Length; i++)
        {
            if (supported[i].width == width && supported[i].height == height) return true;
        }
        return false;
    }

    // ─────────────────────────────────────────────
    // 그래픽 핸들러 (즉시)
    // ─────────────────────────────────────────────
    private void OnFrameRate(int idx) { if (Guard()) SettingsManager.Instance.SetTargetFrameRate(IndexToFrameRate(idx)); }
    private void OnVsync(bool on)
    {
        if (!Guard()) return;

        SettingsManager.Instance.SetVSync(on ? 1 : 0);
        UpdateFrameRateInteractability(on);
    }
    private void OnBrightness(float v) { if (Guard()) SettingsManager.Instance.SetBrightness(v); }

    /// <summary>VSync 사용 중에는 별도 목표 프레임 선택을 막고, 해제하면 다시 허용한다.</summary>
    private void UpdateFrameRateInteractability(bool isVSyncEnabled)
    {
        if (_frameRateStepper != null)
            _frameRateStepper.SetInteractable(!isVSyncEnabled);

        float textAlpha = isVSyncEnabled ? DISABLED_TEXT_ALPHA : ENABLED_TEXT_ALPHA;
        SetTextAlpha(_frameRateText, textAlpha);
        SetTextAlpha(_frameRateValueText, textAlpha);
    }

    private static void SetTextAlpha(TMP_Text text, float alpha)
    {
        if (text == null) return;

        Color color = text.color;
        color.a = alpha;
        text.color = color;
    }

    // ─────────────────────────────────────────────
    // 화면 핸들러 (값만 기록 → 적용 버튼)
    // ─────────────────────────────────────────────
    private void OnResolution(int idx)
    {
        if (!Guard()) return;
        if (idx < 0 || idx >= _availableResolutions.Count) return;
        SettingsManager.ToResolution(_availableResolutions[idx], out int width, out int height);
        SettingsManager.Instance.SetResolution(width, height);
    }
    private void OnScreenMode(int idx)
    {
        if (Guard() && idx >= 0 && idx < ScreenModeOptions.Length)
            SettingsManager.Instance.SetScreenMode(ScreenModeOptions[idx]);
    }

    private void OnApplyScreen()
    {
        if (!SettingsManager.HasInstance) return;

        SettingsManager.Instance.ApplyScreenChange();
        if (SettingsManager.Instance.IsAwaitingScreenConfirm)
            OpenScreenConfirmAsync(this.GetCancellationTokenOnDestroy()).Forget();
    }

    // 옵션 창이 열린 상태에서 Alt+Enter로 화면 설정이 바뀐 경우 표시를 현재 값에 맞춘다
    private void OnScreenSettingsApplied()
    {
        SyncFromSettings();
    }

    private void OnScreenConfirmTick(float remaining)
    {
        _lastScreenConfirmRemaining = Mathf.Max(0, Mathf.CeilToInt(remaining));

        if (remaining > 0f)
        {
            _screenConfirm?.SetDescription(BuildScreenConfirmDesc());
            return;
        }

        if (_screenConfirm != null && _screenConfirm.IsWaiting)
            _screenConfirm.Complete(ESystemConfirmResult.Cancel);
    }

    private async UniTaskVoid OpenScreenConfirmAsync(CancellationToken token)
    {
        if (_openingScreenConfirm || _screenConfirm != null) return;
        if (!UIManager.HasInstance || !SettingsManager.HasInstance) return;

        _openingScreenConfirm = true;
        try
        {
            UISystemConfirm popup = await UIManager.Instance.OpenAsync<UISystemConfirm>(token);
            if (popup == null) return;

            _screenConfirm = popup;
            var result = await popup.ShowAsync(
                OptionLocalizationUtility.Get(LocalizationKeys.Option.ScreenConfirmTitle),
                BuildScreenConfirmDesc(),
                OptionLocalizationUtility.Get(LocalizationKeys.Option.ScreenConfirmApply),
                OptionLocalizationUtility.Get(LocalizationKeys.Option.Cancel),
                token);

            if (_screenConfirm == popup)
                _screenConfirm = null;

            if (!SettingsManager.HasInstance) return;

            if (result == ESystemConfirmResult.Confirm && SettingsManager.Instance.IsAwaitingScreenConfirm)
            {
                SettingsManager.Instance.ConfirmScreenChange();
                return;
            }

            if (SettingsManager.Instance.IsAwaitingScreenConfirm)
            {
                SettingsManager.Instance.RevertScreenChange();
                SyncFromSettings();
                return;
            }

            SyncFromSettings();
        }
        catch (System.OperationCanceledException) { }
        finally
        {
            _openingScreenConfirm = false;
        }
    }

    private string BuildScreenConfirmDesc()
    {
        return _lastScreenConfirmRemaining > 0
            ? string.Format(OptionLocalizationUtility.Get(LocalizationKeys.Option.ScreenConfirmDescWithSeconds), _lastScreenConfirmRemaining)
            : OptionLocalizationUtility.Get(LocalizationKeys.Option.ScreenConfirmDesc);
    }

    private void CloseScreenConfirm()
    {
        if (_screenConfirm == null) return;

        _screenConfirm.Complete(ESystemConfirmResult.Cancel);
        _screenConfirm = null;
    }

    // ─────────────────────────────────────────────
    // 인덱스 변환
    // ─────────────────────────────────────────────
    private static string[] BuildFrameRateLabels()
    {
        string[] labels = new string[FrameRateOptions.Length];
        for (int i = 0; i < FrameRateOptions.Length; i++)
            labels[i] = OptionLocalizationUtility.Get(GetFrameRateKey(FrameRateOptions[i]));
        return labels;
    }

    private static string[] BuildScreenModeLabels()
    {
        string[] labels = new string[ScreenModeOptions.Length];
        for (int i = 0; i < ScreenModeOptions.Length; i++)
            labels[i] = OptionLocalizationUtility.Get(GetScreenModeKey(ScreenModeOptions[i]));
        return labels;
    }

    private static string GetFrameRateKey(EFrameRateOption option)
    {
        return option switch
        {
            EFrameRateOption.Fps30 => LocalizationKeys.Option.Frame30,
            EFrameRateOption.Fps120 => LocalizationKeys.Option.Frame120,
            _ => LocalizationKeys.Option.Frame60
        };
    }

    private static string GetResolutionLabel(EResolutionOption option)
    {
        SettingsManager.ToResolution(option, out int width, out int height);
        return $"{width}x{height}";
    }

    private static string GetScreenModeKey(EScreenMode mode)
    {
        return mode switch
        {
            EScreenMode.FullScreen => LocalizationKeys.Option.ScreenModeFullscreen,
            EScreenMode.Windowed => LocalizationKeys.Option.ScreenModeWindowed,
            _ => LocalizationKeys.Option.ScreenModeFullscreenWindow
        };
    }

    private int FrameRateToIndex(EFrameRateOption option)
    {
        for (int i = 0; i < FrameRateOptions.Length; i++)
            if (FrameRateOptions[i] == option) return i;
        return 1;
    }
    private int IndexToFrameRate(int idx)
        => (idx >= 0 && idx < FrameRateOptions.Length) ? SettingsManager.ToFrameRate(FrameRateOptions[idx]) : 60;

    private int ResolutionToIndex(EResolutionOption option)
    {
        for (int i = 0; i < _availableResolutions.Count; i++)
            if (_availableResolutions[i] == option) return i;
        return 0;
    }

    private int ScreenModeToIndex(EScreenMode mode)
    {
        for (int i = 0; i < ScreenModeOptions.Length; i++)
            if (ScreenModeOptions[i] == mode) return i;
        return 1;
    }
}
