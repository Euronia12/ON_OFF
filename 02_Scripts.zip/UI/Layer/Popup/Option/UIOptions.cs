﻿// =================================================================
// [스크립트 목적]  환경설정 총괄 UI. 탭 Panel 전환 + 확인/취소/기본값. 개별 설정은 각 탭이 담당
// [주요 변수]      - _soundTab/_graphicsTab/_gameplayTab/_inputTab : 카테고리 탭 (명시적 참조)
// [의존 관계]      - UIPopupBase(→UIBase), SettingsManager, UITabGroup, 각 UIOptionTab
// [원칙]           UIOptions는 4개 탭을 직접 알고 직접 호출(조율자). 확인=Commit / 취소=Cancel.
//                  닫기 시 미확정이면 자동 취소. 탭 추가는 흔치 않으므로 명시 필드가 더 명확·안전.
// [배치]           Canvas 하위, Addressable "UIOptions". 각 탭 패널에 UIOptionTabXxx 부착.
// =================================================================
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using UnityEngine.InputSystem;
using Cysharp.Threading.Tasks;

public class UIOptions : UIBase
{
    [Header("로컬라이징")]
    [SerializeField] private LocalizedTMPBinding[] _localizedTexts;

    [Header("탭 전환")]
    [Tooltip("카테고리 탭 그룹 (그래픽+화면 / 사운드 / 게임플레이 / 조작). Panel 활성 전환 담당")]
    [SerializeField] private UITabGroup _tabGroup;

    [Header("탭 컴포넌트 (각 패널에 부착된 것 연결)")]
    [SerializeField] private UIOptionTabGraphics _graphicsTab;
    [SerializeField] private UIOptionTabGameplay _gameplayTab;
    [SerializeField] private UIOptionTabSound _soundTab;
    //[SerializeField] private UIOptionTabInput _inputTab;

    [Header("공통 버튼")]
    [SerializeField] private Button _closeButton;
    [SerializeField] private Button _confirmButton;
    [SerializeField] private Button _cancelButton;
    [SerializeField] private Button _resetAllButton;
    private bool _confirmDialogOpen;
    private bool _resumeBgmOnClose;

    // 마지막으로 보던 탭. -1 = 아직 연 적 없음(첫 열림은 첫 탭부터).
    // UIOptions 는 캐시되는 Screen UI 라 창을 닫아도 이 값이 유지된다.
    private int _lastTabIndex = -1;
    private readonly List<RaycastResult> _pointerRaycastResults = new List<RaycastResult>();

    /// <summary>옵션 창이 완전히 닫힌 뒤 호출. 호출자는 열기 전 상태를 복원하는 데 사용한다.</summary>
    public event System.Action OnClosed;

    /// <summary>ESC 로 닫는다(팝업 스택 참여). 미확정 변경이 있으면 OnBackPressed 가 저장 여부를 먼저 묻는다.</summary>
    public override bool CloseOnEscape => true;

    /// <summary>
    /// ESC 닫기 요청. 닫기 버튼과 완전히 같은 경로(CloseAsync)를 태워 동작을 일원화한다.
    /// 닫기는 CloseAsync 가 직접 수행하므로 여기서는 항상 false(UIManager 의 자동 닫기 보류).
    /// </summary>
    public override bool OnBackPressed()
    {
        // 확인 다이얼로그가 떠 있는 동안의 ESC 는 무시 (다이얼로그가 우선 처리)
        if (_confirmDialogOpen) return false;

        CloseAsync().Forget();
        return false;
    }

    // ─────────────────────────────────────────────
    // 모든 탭 일괄 처리 (공통 베이스 없이 명시 호출 — 탭 4개 고정)
    // ─────────────────────────────────────────────
    private void SyncAllTabs()
    {
        _soundTab?.SyncFromSettings();
        _graphicsTab?.SyncFromSettings();
        _gameplayTab?.SyncFromSettings();
        //_inputTab?.SyncFromSettings();
    }

    private void RegisterAllTabs()
    {
        _soundTab?.RegisterListeners();
        _graphicsTab?.RegisterListeners();
        _gameplayTab?.RegisterListeners();
        //_inputTab?.RegisterListeners();
    }

    private void UnregisterAllTabs()
    {
        _soundTab?.UnregisterListeners();
        _graphicsTab?.UnregisterListeners();
        _gameplayTab?.UnregisterListeners();
        //_inputTab?.UnregisterListeners();
    }

    // ─────────────────────────────────────────────
    // 생명주기
    // ─────────────────────────────────────────────

    protected override void Setup()
    {
        SyncAllTabs();
    }

    public override void OnOpen()
    {
        base.OnOpen();

        // 옵션이 열려 있는 동안에는 현재 씬 BGM을 멈추고, 이 창이 직접 멈춘 경우에만 닫을 때 재개한다.
        _resumeBgmOnClose = AudioManager.HasInstance && AudioManager.Instance.IsBgmPlaying;
        if (_resumeBgmOnClose)
            AudioManager.Instance.PauseBgm();

        RegisterAllTabs();
        RegisterCommonButtons();
        if (_gameplayTab != null)
            _gameplayTab.OnLanguageOptionChanged += RefreshLocalization;

        if (SettingsManager.HasInstance)
        {
            SettingsManager.Instance.OnDirtyChanged += OnDirtyChanged;
            OnDirtyChanged(SettingsManager.Instance.IsDirty);
        }

        // 첫 열림은 첫 탭, 이후 재오픈은 닫을 때 보던 탭으로 복원한다.
        // (UITabGroup 은 OnEnable 에서 기본 탭으로 리셋하므로 여기서 덮어써야 한다)
        if (_tabGroup != null)
            _tabGroup.SelectTab(_lastTabIndex >= 0 ? _lastTabIndex : 0);
    }

    public override void OnClose()
    {
        // 다음 열림에서 복원할 탭 기억 (탭 그룹이 리셋되기 전에 먼저 읽는다)
        if (_tabGroup != null) _lastTabIndex = _tabGroup.CurrentIndex;

        UnregisterAllTabs();
        UnregisterCommonButtons();
        if (_gameplayTab != null)
            _gameplayTab.OnLanguageOptionChanged -= RefreshLocalization;

        if (SettingsManager.HasInstance)
        {
            SettingsManager.Instance.OnDirtyChanged -= OnDirtyChanged;

            // 닫기가 확정된 경우 미확정 변경은 취소한다.
            if (SettingsManager.Instance.IsDirty)
                SettingsManager.Instance.Cancel();
        }

        if (_resumeBgmOnClose && AudioManager.HasInstance)
            AudioManager.Instance.ResumeBgm();
        _resumeBgmOnClose = false;

        base.OnClose();
        OnClosed?.Invoke();
    }

    private void Update()
    {
        if (_soundTab == null || EventSystem.current == null || Pointer.current == null ||
            !Pointer.current.press.wasPressedThisFrame)
        {
            return;
        }

        _pointerRaycastResults.Clear();
        var eventData = new PointerEventData(EventSystem.current)
        {
            position = Pointer.current.position.ReadValue()
        };
        EventSystem.current.RaycastAll(eventData, _pointerRaycastResults);

        if (_pointerRaycastResults.Count == 0 ||
            _soundTab.IsBgmSliderTarget(_pointerRaycastResults[0].gameObject))
        {
            return;
        }

        // BGM 미리듣기는 BGM 슬라이더 바깥의 UI를 클릭할 때 한 곳에서만 정리한다.
        _soundTab.StopBgmPreview();
    }

    public override void OnLocalize()
    {
        base.OnLocalize();
        RefreshLocalization();
        // 언어 변경 시 키 라벨 갱신
        //_inputTab?.RefreshKeyLabels();
    }

    public void RefreshLocalization()
    {
        OptionLocalizationUtility.Apply(_localizedTexts);
        _graphicsTab?.RefreshLocalization();
        _gameplayTab?.RefreshLocalization();
        _soundTab?.RefreshLocalization();
    }

    // ─────────────────────────────────────────────
    // 공통 버튼
    // ─────────────────────────────────────────────

    private void RegisterCommonButtons()
    {
        _closeButton?.onClick.AddListener(OnCloseButton);
        _confirmButton?.onClick.AddListener(OnConfirm);
        _cancelButton?.onClick.AddListener(OnCancel);
        _resetAllButton?.onClick.AddListener(OnResetAll);
        //_resetSoundButton?.onClick.AddListener(OnResetSound);
        //_resetGraphicsButton?.onClick.AddListener(OnResetGraphics);
        //_resetGameplayButton?.onClick.AddListener(OnResetGameplay);
    }

    private void UnregisterCommonButtons()
    {
        _closeButton?.onClick.RemoveListener(OnCloseButton);
        _confirmButton?.onClick.RemoveListener(OnConfirm);
        _cancelButton?.onClick.RemoveListener(OnCancel);
        _resetAllButton?.onClick.RemoveListener(OnResetAll);
        //_resetSoundButton?.onClick.RemoveListener(OnResetSound);
        //_resetGraphicsButton?.onClick.RemoveListener(OnResetGraphics);
        //_resetGameplayButton?.onClick.RemoveListener(OnResetGameplay);
    }

    private void OnConfirm()
    {
        ConfirmChangesAsync().Forget();
    }

    private void OnCloseButton()
    {
        CloseAsync().Forget();
    }

    private void OnCancel()
    {
        if (!SettingsManager.HasInstance) return;
        SettingsManager.Instance.Cancel();
        SyncAllTabs();
    }

    private void OnResetAll()
    {
        ResetAllAsync().Forget();
    }

    private void OnResetSound()
    {
        ResetCategory(ESettingsCategory.Sound);
        _soundTab?.SyncFromSettings();
    }

    private void OnResetGameplay()
    {
        ResetCategory(ESettingsCategory.Gameplay);
        _gameplayTab?.SyncFromSettings();
    }

    private void OnResetGraphics()
    {
        if (!SettingsManager.HasInstance) return;
        // 그래픽 탭 = Graphics + Screen 함께 초기화
        SettingsManager.Instance.ResetCategory(ESettingsCategory.Graphics);
        SettingsManager.Instance.ResetCategory(ESettingsCategory.Screen);
        _graphicsTab?.SyncFromSettings();
    }

    private void ResetCategory(ESettingsCategory category)
    {
        if (!SettingsManager.HasInstance) return;
        SettingsManager.Instance.ResetCategory(category);
    }

    // ─────────────────────────────────────────────
    // Dirty (확인/취소 버튼 활성화)
    // ─────────────────────────────────────────────

    private void OnDirtyChanged(bool isDirty)
    {
        if (_confirmButton != null) _confirmButton.interactable = isDirty;
        if (_cancelButton != null) _cancelButton.interactable = isDirty;
    }

    private async UniTaskVoid ConfirmChangesAsync()
    {
        if (_confirmDialogOpen || !SettingsManager.HasInstance || !SettingsManager.Instance.IsDirty)
            return;

        var result = await OpenConfirmAsync(
            LocalizationKeys.Option.SaveConfirmTitle,
            LocalizationKeys.Option.SaveConfirmDesc,
            LocalizationKeys.Option.Save,
            LocalizationKeys.Option.Cancel);

        if (result == ESystemConfirmResult.Confirm && SettingsManager.HasInstance)
        {
            SettingsManager.Instance.Commit();
            if (LocalizationManager.HasInstance)
                LocalizationManager.Instance.RefreshAll();
        }
    }

    private async UniTaskVoid ResetAllAsync()
    {
        if (_confirmDialogOpen || !SettingsManager.HasInstance)
            return;

        var result = await OpenConfirmAsync(
            LocalizationKeys.Option.ResetConfirmTitle,
            LocalizationKeys.Option.ResetConfirmDesc,
            LocalizationKeys.Option.Reset,
            LocalizationKeys.Option.Cancel);

        if (result != ESystemConfirmResult.Confirm || !SettingsManager.HasInstance)
            return;

        SettingsManager.Instance.ResetToDefault();
        SyncAllTabs();
    }

    private async UniTaskVoid CloseAsync()
    {
        if (_confirmDialogOpen)
            return;

        if (!SettingsManager.HasInstance || !SettingsManager.Instance.IsDirty)
        {
            CloseSelf();
            return;
        }

        var result = await OpenConfirmAsync(
            LocalizationKeys.Option.CloseDiscardTitle,
            LocalizationKeys.Option.CloseDiscardDesc,
            LocalizationKeys.Option.Confirm,
            LocalizationKeys.Option.Cancel);

        if (result != ESystemConfirmResult.Confirm)
            return;

        if (SettingsManager.HasInstance)
            SettingsManager.Instance.Cancel();

        CloseSelf();
    }

    private void CloseSelf()
    {
        if (UIManager.HasInstance && IsOpen)
            UIManager.Instance.Close(this);
    }

    private async UniTask<ESystemConfirmResult> OpenConfirmAsync(
        string titleKey,
        string descKey,
        string confirmKey,
        string cancelKey)
    {
        if (!UIManager.HasInstance)
            return ESystemConfirmResult.Cancel;

        _confirmDialogOpen = true;
        try
        {
            UISystemConfirm popup = await UIManager.Instance.OpenAsync<UISystemConfirm>(
                this.GetCancellationTokenOnDestroy());
            if (popup == null)
                return ESystemConfirmResult.Cancel;

            return await popup.ShowAsync(
                Localize(titleKey),
                Localize(descKey),
                Localize(confirmKey),
                Localize(cancelKey),
                this.GetCancellationTokenOnDestroy());
        }
        catch (System.OperationCanceledException)
        {
            return ESystemConfirmResult.Cancel;
        }
        finally
        {
            _confirmDialogOpen = false;
        }
    }

    private static string Localize(string key)
        => !string.IsNullOrEmpty(key) && LocalizationManager.HasInstance && LocalizationManager.Instance.HasKey(key)
            ? LocalizationManager.Instance.Get(key)
            : key ?? string.Empty;
}
