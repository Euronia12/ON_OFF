// =================================================================
// [스크립트 목적]  게임플레이 옵션 탭. 화면흔들림·고속모드·텍스트효과·진동 + 언어 + 개인정보 수집 동의
// [의존 관계]      - MonoBehaviour, SettingsManager, LocalizationManager, UGUI, UIExtensions
// [원칙]           토글류는 Draft 경유(확정 필요). 언어만 즉시 확정(Draft 미경유).
// =================================================================
using System.Collections.Generic;
using System;
using Cysharp.Threading.Tasks;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class UIOptionTabGameplay : MonoBehaviour
{
    private static readonly EGameLanguage[] LanguageOptions =
    {
        EGameLanguage.Korean,
        EGameLanguage.English,
        EGameLanguage.ChineseSimplified,
        EGameLanguage.ChineseTraditional,
        EGameLanguage.Japanese,
        EGameLanguage.German
    };

    [Header("로컬라이징")]
    [SerializeField] private LocalizedTMPBinding[] _localizedTexts;

    [Header("게임플레이")]
    [Tooltip("화면 흔들림 (접근성: 멀미 완화)")]
    [SerializeField] private Toggle _screenShakeToggle;
    [Tooltip("고속모드 (게임 로직에서 참조)")]
    [SerializeField] private Toggle _fastModeToggle;
    [Tooltip("텍스트 타이핑 연출")]
    [SerializeField] private Toggle _textEffectToggle;
    [Tooltip("모바일 진동 (햅틱)")]
    [SerializeField] private Toggle _vibrationToggle;

    [Header("개인정보")]
    [Tooltip("플레이 통계 수집 동의. 변경 후 확인을 누르면 GA/UGS에 반영되고, 취소하면 기존 값으로 돌아간다.")]
    [SerializeField] private Toggle _analyticsConsentToggle;

    [Tooltip("Steam에 게시한 개인정보 처리방침을 외부 브라우저로 여는 버튼")]
    [SerializeField] private Button _privacyPolicyButton;

    [Header("언어")]
    [Tooltip("언어 드롭다운. SupportedLanguages로 채움")]
    [SerializeField] private TMP_Dropdown _languageDropdown;

    private readonly TMP_FontAsset[] _languageFonts = new TMP_FontAsset[LanguageOptions.Length];
    private bool _languageBuilt;
    public event Action OnLanguageOptionChanged;

    private bool _isSyncing;
    private bool Guard() => !_isSyncing && SettingsManager.HasInstance;

    private void Awake()
    {
        if (_vibrationToggle != null)
            _vibrationToggle.transform.parent.gameObject.SetActive(false);

        RegisterLanguageDropdownOpenEvents();
    }

    public void SyncFromSettings()
    {
        if (!_languageBuilt) BuildLanguageDropdown();
        if (!SettingsManager.HasInstance) return;
        var s = SettingsManager.Instance.Current;

        _isSyncing = true;
        _screenShakeToggle.SetIsOnSafe(s.ScreenShakeEnabled);
        _fastModeToggle.SetIsOnSafe(s.FastModeEnabled);
        _textEffectToggle.SetIsOnSafe(s.TextEffectEnabled);
        _analyticsConsentToggle.SetIsOnSafe(s.AnalyticsConsent);
        _languageDropdown.SetValueSafe(LanguageToIndex(SettingsManager.HasInstance
            ? SettingsManager.Instance.Current.Language
            : EGameLanguage.Korean));
        ApplyLanguageCaptionFont(_languageDropdown.value);
        _isSyncing = false;
    }

    public void RefreshLocalization()
    {
        OptionLocalizationUtility.Apply(_localizedTexts);
        SyncFromSettings();
    }

    public void RegisterListeners()
    {
        _screenShakeToggle?.onValueChanged.AddListener(OnScreenShake);
        _fastModeToggle?.onValueChanged.AddListener(OnFastMode);
        _textEffectToggle?.onValueChanged.AddListener(OnTextEffect);
        _analyticsConsentToggle?.onValueChanged.AddListener(OnAnalyticsConsent);
        _privacyPolicyButton?.onClick.AddListener(OpenPrivacyPolicy);
        _languageDropdown?.onValueChanged.AddListener(OnLanguageChanged);
    }

    public void UnregisterListeners()
    {
        _screenShakeToggle?.onValueChanged.RemoveListener(OnScreenShake);
        _fastModeToggle?.onValueChanged.RemoveListener(OnFastMode);
        _textEffectToggle?.onValueChanged.RemoveListener(OnTextEffect);
        _analyticsConsentToggle?.onValueChanged.RemoveListener(OnAnalyticsConsent);
        _privacyPolicyButton?.onClick.RemoveListener(OpenPrivacyPolicy);
        _languageDropdown?.onValueChanged.RemoveListener(OnLanguageChanged);
    }

    private void OnScreenShake(bool on) { if (Guard()) SettingsManager.Instance.SetScreenShake(on); }
    private void OnFastMode(bool on) { if (Guard()) SettingsManager.Instance.SetFastMode(on); }
    private void OnTextEffect(bool on) { if (Guard()) SettingsManager.Instance.SetTextEffect(on); }

    // 개인정보 수집 동의도 다른 토글과 동일하게 Draft에 기록한다.
    // 확인 시에만 SettingsManager가 확정 이벤트를 발행하고, 취소 시 저장값으로 복원한다.
    private void OnAnalyticsConsent(bool on) { if (Guard()) SettingsManager.Instance.SetAnalyticsConsentDraft(on); }

    private static void OpenPrivacyPolicy()
    {
        string url = Constants.ExternalLinks.PRIVACY_POLICY;
        if (!Uri.TryCreate(url, UriKind.Absolute, out Uri uri)
            || uri.Scheme != Uri.UriSchemeHttps)
        {
            ShowInvalidPrivacyPolicyUrlAsync().Forget();
            return;
        }

        Application.OpenURL(url);
    }

    private static async UniTask ShowInvalidPrivacyPolicyUrlAsync()
    {
        if (!UIManager.HasInstance) return;

        UISystemNavi systemNavi = await UIManager.Instance.OpenAsync<UISystemNavi>();
        systemNavi?.Show(LocalizationKeys.Common.PrivacyPolicyInvalidUrl);
    }

    // ─────────────────────────────────────────────
    // 언어 (즉시 확정 — Draft 미경유)
    // ─────────────────────────────────────────────
    private void BuildLanguageDropdown()
    {
        if (_languageBuilt) return;
        if (_languageDropdown == null) { _languageBuilt = true; return; }

        _languageDropdown.ClearOptions();
        var labels = new List<string>();
        for (int i = 0; i < LanguageOptions.Length; i++)
        {
            EGameLanguage language = LanguageOptions[i];
            labels.Add(OptionLocalizationUtility.Get(GetLanguageKey(language)));
            _languageFonts[i] = GetLanguageFont(language);
        }
        _languageDropdown.AddOptions(labels);
        _languageBuilt = true;
    }

    private void RegisterLanguageDropdownOpenEvents()
    {
        if (_languageDropdown == null) return;

        EventTrigger trigger = _languageDropdown.GetComponent<EventTrigger>();
        if (trigger == null)
            trigger = _languageDropdown.gameObject.AddComponent<EventTrigger>();

        AddDropdownOpenEvent(trigger, EventTriggerType.PointerClick);
        AddDropdownOpenEvent(trigger, EventTriggerType.Submit);
    }

    private void AddDropdownOpenEvent(EventTrigger trigger, EventTriggerType eventType)
    {
        var entry = new EventTrigger.Entry { eventID = eventType };
        entry.callback.AddListener(ApplyLanguageItemFonts);
        trigger.triggers.Add(entry);
    }

    private void ApplyLanguageItemFonts(BaseEventData _)
    {
        if (_languageDropdown == null || _languageDropdown.template == null) return;

        Transform dropdownList = _languageDropdown.template.parent.Find("Dropdown List");
        if (dropdownList == null) return;

        TMP_Text[] itemTexts = dropdownList.GetComponentsInChildren<TMP_Text>();
        int count = Mathf.Min(itemTexts.Length, _languageFonts.Length);
        for (int i = 0; i < count; i++)
            LocalizedFontUtility.ApplyFont(itemTexts[i], _languageFonts[i]);
    }

    private void ApplyLanguageCaptionFont(int index)
    {
        if (_languageDropdown == null || index < 0 || index >= _languageFonts.Length) return;
        LocalizedFontUtility.ApplyFont(_languageDropdown.captionText, _languageFonts[index]);
    }

    private static TMP_FontAsset GetLanguageFont(EGameLanguage language)
    {
        if (!LocalizationManager.HasInstance) return null;

        return LocalizationManager.Instance.GetFont(SettingsManager.ToSystemLanguage(language));
    }

    private void OnLanguageChanged(int idx)
    {
        if (_isSyncing || !SettingsManager.HasInstance) return;
        if (idx < 0 || idx >= LanguageOptions.Length) return;
        ApplyLanguageCaptionFont(idx);
        SettingsManager.Instance.SelectLanguage(LanguageOptions[idx]);
        OnLanguageOptionChanged?.Invoke();
    }

    private int LanguageToIndex(EGameLanguage lang)
    {
        for (int i = 0; i < LanguageOptions.Length; i++)
            if (LanguageOptions[i] == lang) return i;
        return 0;
    }

    private static string GetLanguageKey(EGameLanguage lang)
    {
        return lang switch
        {
            EGameLanguage.English => LocalizationKeys.Option.LanguageEnglish,
            EGameLanguage.ChineseSimplified => LocalizationKeys.Option.LanguageChineseSimplified,
            EGameLanguage.ChineseTraditional => LocalizationKeys.Option.LanguageChineseTraditional,
            EGameLanguage.Japanese => LocalizationKeys.Option.LanguageJapanese,
            EGameLanguage.German => LocalizationKeys.Option.LanguageGerman,
            _ => LocalizationKeys.Option.LanguageKorean
        };
    }
}
