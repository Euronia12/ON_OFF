﻿// =================================================================
// [스크립트 목적]  조작 옵션 탭. 키 리바인딩(행 목록) 전용
// [의존 관계]      - MonoBehaviour, SettingsManager, InputManager, UGUI
// [원칙]           키는 즉시 확정(Draft 미경유). 리바인딩은 콜백으로 완료/취소/충돌 처리.
// =================================================================
using System;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class UIOptionTabInput : MonoBehaviour
{
    [Header("키 변경")]
    [SerializeField] private List<RebindRow> _rebindRows = new();
    [SerializeField] private Button _resetAllKeysButton;
    [Tooltip("키 입력 대기 안내 오버레이 (리바인딩 중 표시)")]
    [SerializeField] private GameObject _rebindWaitOverlay;

    /// <summary>리바인딩 한 행 (액션 + 위젯).</summary>
    [Serializable]
    public class RebindRow
    {
        [Tooltip("대상 액션 맵")]
        public EActionMap Map = EActionMap.Gameplay;
        [Tooltip("대상 액션명 (InputActionNames 상수와 일치)")]
        public string ActionName;
        [Tooltip("이 키를 변경하는 버튼")]
        public Button RebindButton;
        [Tooltip("현재 키 표시 텍스트")]
        public TMP_Text KeyLabel;
        [Tooltip("이 키만 초기화 (선택)")]
        public Button ResetButton;

        [NonSerialized] public UnityEngine.Events.UnityAction RebindHandler;
        [NonSerialized] public UnityEngine.Events.UnityAction ResetHandler;
    }

    public void SyncFromSettings()
    {
        RefreshAllKeyLabels();
        if (_rebindWaitOverlay != null) _rebindWaitOverlay.SetActive(false);
    }

    public void RegisterListeners()
    {
        foreach (var row in _rebindRows)
        {
            if (row == null) continue;
            var captured = row;
            captured.RebindHandler = () => HandleRebind(captured);
            captured.ResetHandler = () => HandleResetKey(captured);
            captured.RebindButton?.onClick.AddListener(captured.RebindHandler);
            captured.ResetButton?.onClick.AddListener(captured.ResetHandler);
        }
        _resetAllKeysButton?.onClick.AddListener(OnResetAllKeys);
    }

    public void UnregisterListeners()
    {
        foreach (var row in _rebindRows)
        {
            if (row == null) continue;
            if (row.RebindHandler != null) row.RebindButton?.onClick.RemoveListener(row.RebindHandler);
            if (row.ResetHandler != null) row.ResetButton?.onClick.RemoveListener(row.ResetHandler);
            row.RebindHandler = null;
            row.ResetHandler = null;
        }
        _resetAllKeysButton?.onClick.RemoveListener(OnResetAllKeys);
    }

    // ─────────────────────────────────────────────
    // 키 리바인딩
    // ─────────────────────────────────────────────
    private void HandleRebind(RebindRow row)
    {
        if (!SettingsManager.HasInstance || row == null) return;
        if (string.IsNullOrEmpty(row.ActionName)) return;

        if (_rebindWaitOverlay != null) _rebindWaitOverlay.SetActive(true);

        SettingsManager.Instance.StartRebind(
            row.Map, row.ActionName,
            onComplete: display =>
            {
                if (_rebindWaitOverlay != null) _rebindWaitOverlay.SetActive(false);
                if (row.KeyLabel != null) row.KeyLabel.text = display;
            },
            onCancel: () =>
            {
                if (_rebindWaitOverlay != null) _rebindWaitOverlay.SetActive(false);
            },
            onConflict: other =>
            {
                if (_rebindWaitOverlay != null) _rebindWaitOverlay.SetActive(false);
                ShowRebindConflict(row, other);
            });
    }

    private void HandleResetKey(RebindRow row)
    {
        if (!SettingsManager.HasInstance || row == null) return;
        SettingsManager.Instance.ResetBinding(row.Map, row.ActionName);
        RefreshKeyLabel(row);
    }

    private void OnResetAllKeys()
    {
        if (!SettingsManager.HasInstance) return;
        SettingsManager.Instance.ResetAllBindings();
        RefreshAllKeyLabels();
    }

    private void RefreshAllKeyLabels()
    {
        foreach (var row in _rebindRows)
            RefreshKeyLabel(row);
    }

    private void RefreshKeyLabel(RebindRow row)
    {
        if (row == null || row.KeyLabel == null || !SettingsManager.HasInstance) return;
        if (string.IsNullOrEmpty(row.ActionName)) return;
        row.KeyLabel.text = SettingsManager.Instance.GetBindingDisplay(row.Map, row.ActionName);
    }

    private void ShowRebindConflict(RebindRow row, string conflictAction)
    {
#if UNITY_EDITOR || DEVELOPMENT_BUILD
        Debug.LogWarning($"[UIOptionTabInput] 키 충돌: {row.ActionName} ↔ {conflictAction}");
#endif
        // TODO: 프로젝트 토스트 UI 연결
    }

    /// <summary>리바인딩 진행 중 여부 (UIOptions의 ESC 차단 판단용).</summary>
    public bool IsRebinding => InputManager.HasInstance && InputManager.Instance.IsRebinding;

    /// <summary>언어 변경 등으로 키 라벨 갱신 필요 시 외부(UIOptions.OnLocalize)에서 호출.</summary>
    public void RefreshKeyLabels() => RefreshAllKeyLabels();
}
