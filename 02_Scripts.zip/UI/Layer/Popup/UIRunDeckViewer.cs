using System.Collections.Generic;
using System.Threading;
using Cysharp.Threading.Tasks;

/// <summary>종료 스냅샷을 기존 읽기 전용 덱 피커로 여는 전용 진입점.</summary>
public static class UIRunDeckViewer
{
    public static async UniTask OpenAsync(
        IReadOnlyList<RunDeckSnapshotEntry> snapshotEntries,
        CancellationToken token = default)
    {
        if (!UIManager.HasInstance || snapshotEntries == null) return;

        var entries = new List<RunDeckEntry>(snapshotEntries.Count);
        for (int i = 0; i < snapshotEntries.Count; i++)
        {
            RunDeckSnapshotEntry entry = snapshotEntries[i];
            if (entry != null)
                entries.Add(entry.ToRunDeckEntry());
        }

        string title = Localize(LocalizationKeys.GameClear.DeckViewerTitle);
        UIDeckCardPicker.Show(
            entries,
            title: title,
            cancelable: true,
            requireConfirmation: false,
            viewOnly: true);
        UIDeckCardPicker viewer = await UIManager.Instance.OpenAsync<UIDeckCardPicker>(token);
        if (viewer != null)
        {
            // 결과 화면(System) 위에 보여야 하므로, 기존 Popup 프리팹을 연 뒤 System의 마지막 형제로 올린다.
            UnityEngine.Transform systemRoot = UIManager.Instance.GetLayerRoot(EUILayer.System);
            if (systemRoot != null)
            {
                viewer.OnCancelled += () => RestorePopupLayer(viewer);
                viewer.transform.SetParent(systemRoot, false);
                viewer.transform.SetAsLastSibling();
            }
        }
    }

    private static void RestorePopupLayer(UIDeckCardPicker viewer)
    {
        if (viewer == null || !UIManager.HasInstance) return;

        UnityEngine.Transform popupRoot = UIManager.Instance.GetLayerRoot(EUILayer.Popup);
        if (popupRoot != null)
            viewer.transform.SetParent(popupRoot, false);
    }

    private static string Localize(string key)
        => LocalizationManager.HasInstance && LocalizationManager.Instance.HasKey(key)
            ? LocalizationManager.Instance.Get(key)
            : key ?? string.Empty;
}
