﻿// =================================================================
// [스크립트 목적]  카드 보상 1택 선택 팝업. 전리품 창(UIRewardPopup)에서 "카드 추가" 항목을
//                 눌렀을 때 떠서, 후보 N장 중 1장을 고르거나 스킵하게 한다.
// [주요 변수]      - _slots     : 카드 슬롯 컴포넌트 배열 (UIRewardCardSlot)
//                  - _skip      : 스킵 버튼 (카드 클릭 = 즉시 선택이라 확정 버튼 없음)
//                  - _candidates: 제시된 후보 SO (슬롯 인덱스 대응)
//                  - s_pending  : 열기 직전 주입되는 후보 (OpenAsync 인자 제약 우회)
// [의존 관계]      - UIPopupBase / UIRewardCardSlot / CardDataSO / CardFactory
//                  - UIRewardPopup(전리품 창)이 Show 로 후보 주입 + OnCardResolved 구독
// [설계 노트]      - 이름: "카드 보상 = 여러 후보 중 1택"이라는 역할을 직관적으로 드러낸다.
//                    (전리품 리스트 창은 UIRewardPopup, 카드 선택 창은 이 클래스로 분리)
//                  - 후보 주입은 다른 팝업과 동일하게 static Show 예약 → OpenAsync → Setup 에서 구성.
//                  - 카드 "생성·추첨"은 CardRewardService 가, 이 UI 는 "표시·선택"만 담당.
// =================================================================

using System;
using System.Collections;
using System.Collections.Generic;
using System.Threading;
using Cysharp.Threading.Tasks;
using TMPro;
using DG.Tweening;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.UI;

/// <summary>
/// 카드 보상 1택 선택 팝업. 후보 카드들을 슬롯에 표시하고 1택 또는 스킵을 받는다.
/// 선택 결과(획득 카드 ID 또는 null=스킵)를 OnCardResolved 로 통지하며,
/// 덱 반영·후속 흐름은 구독자(전리품 창/컨트롤러)가 처리한다 (UI/로직 분리).
/// </summary>
public sealed class UICardSelectPopup : UIPopupBase
{
    [Header("카드 슬롯")]
    [Tooltip("카드 슬롯 컴포넌트 묶음. 슬롯 수 = 최대 후보 수")]
    [SerializeField] private UIRewardCardSlot[] _slots = new UIRewardCardSlot[3];

    [Header("버튼")]
    [Tooltip("선택 스킵 버튼 (카드 클릭 = 즉시 선택이므로 확정 버튼 없음)")]
    [SerializeField] private Button _skipButton;

    [Header("고정 텍스트")]
    [Tooltip("팝업 타이틀 텍스트")]
    [SerializeField] private TMP_Text _titleText;

    [Tooltip("넘기기 버튼 텍스트")]
    [SerializeField] private TMP_Text _skipButtonText;

    [Header("키워드 패널")]
    [Tooltip("카드 호버 시 키워드 설명을 띄우는 공유 패널. 비우면 표시 생략")]
    [SerializeField] private UIKeywordPanel _keywordPanel;

    [Header("카드 등장 연출")]
    [Tooltip("카드가 등장 직전에 가지는 시작 배율")]
    [SerializeField, Range(0.1f, 1f)] private float _revealStartScale = 0.78f;

    [Tooltip("카드 한 장의 팝업 시간(초)")]
    [SerializeField, Min(0f)] private float _revealDuration = 0.18f;

    [Tooltip("다음 카드가 등장하기까지의 간격(초)")]
    [SerializeField, Min(0f)] private float _revealInterval = 0.24f;

    [Tooltip("등장 연출 스킵 후 카드 선택을 막는 시간(초)")]
    [SerializeField, Min(0f)] private float _postSkipInputDelay = 0.2f;

    [Tooltip("선택 후 다음 후보로 교체하기 전 선택/비선택 카드 피드백 시간(초)")]
    [SerializeField, Min(0f)] private float _resolveTransitionDuration = 0.18f;

    private readonly List<CardDataSO> _candidates = new List<CardDataSO>(3);
    private readonly List<ECardDirection> _resolvedDirections = new List<ECardDirection>(3);
    private readonly List<Card> _previewCards = new List<Card>(3);
    private bool _resolved; // 중복 선택/스킵 방지 (즉시 선택 → 닫힘)
    private bool _isRevealing;
    private CanvasGroup _canvasGroup;
    private Coroutine _revealRoutine;
    private Coroutine _resolvePresentationRoutine;
    private UniTaskCompletionSource _resolvePresentationCompletion;

    // OpenAsync 가 인자를 못 받으므로, 열기 직전에 후보를 정적으로 예약.
    private static IReadOnlyList<CardDataSO> s_pending;
    private static IReadOnlyList<ECardDirection> s_pendingDirections;
    private static bool s_pendingKeepOpen;
    private bool _keepOpenAfterResolve;

    /// <summary>
    /// 선택 완료 통지. acquiredCardId 가 null/empty 면 스킵.
    /// 구독자가 덱 반영(RunContext.AddCardToDeck)과 다음 흐름을 수행한다.
    /// </summary>
    public event Action<string, ECardDirection> OnCardResolved;

    /// <summary>열기 직전 후보 주입 (전리품 창이 OpenAsync 직전 호출).</summary>
    public static void Show(
        IReadOnlyList<CardDataSO> candidates,
        IReadOnlyList<ECardDirection> directions = null,
        bool keepOpenAfterResolve = false)
    {
        s_pending = candidates;
        s_pendingDirections = directions;
        s_pendingKeepOpen = keepOpenAfterResolve;
    }

    protected override void Init()
    {
        if (_keywordPanel == null)
            _keywordPanel = GetComponentInChildren<UIKeywordPanel>(true);

        RefreshLocalizedTexts();
        _canvasGroup = GetComponent<CanvasGroup>();

        // 슬롯별 클릭 콜백 연결 (인덱스 캡처). 슬롯이 자기 버튼 리스너를 관리한다.
        for (int i = 0; i < _slots.Length; i++)
        {
            if (_slots[i] == null) continue;
            int captured = i;
            _slots[i].Bind(() => HandleCardClicked(captured));
            _slots[i].SetKeywordPanel(_keywordPanel);
        }

        if (_skipButton != null) _skipButton.onClick.AddListener(HandleSkip);
    }

    private void Update()
    {
        Mouse mouse = Mouse.current;
        if (!_isRevealing || mouse == null || !mouse.leftButton.wasPressedThisFrame) return;

        SkipRevealSequence();
    }

    public override void OnLocalize()
    {
        base.OnLocalize();
        RefreshLocalizedTexts();
    }

    private void RefreshLocalizedTexts()
    {
        if (_titleText != null)
            _titleText.text = Localize(LocalizationKeys.CardSelect.Title);
        if (_skipButtonText != null)
            _skipButtonText.text = Localize(LocalizationKeys.CardSelect.Skip);
    }

    private static string Localize(string key)
    {
        return LocalizationManager.HasInstance
            ? LocalizationManager.Instance.Get(key)
            : key;
    }

    /// <summary>열 때마다 예약된 후보로 슬롯을 재구성하고 선택 상태를 초기화.</summary>
    protected override void Setup()
    {
        _keepOpenAfterResolve = s_pendingKeepOpen;
        ApplyCandidates(s_pending, s_pendingDirections);
        StartRevealSequence();
    }

    /// <summary>모두 받기에서 팝업을 닫지 않고 다음 보상 후보로 교체한다.</summary>
    public void RefreshCandidates(
        IReadOnlyList<CardDataSO> candidates,
        IReadOnlyList<ECardDirection> directions,
        bool keepOpenAfterResolve)
    {
        _keepOpenAfterResolve = keepOpenAfterResolve;
        ApplyCandidates(candidates, directions);
        StartRevealSequence();
    }

    /// <summary>현재 선택 피드백이 끝나고 다음 후보를 표시해도 되는 시점까지 기다린다.</summary>
    public UniTask WaitForResolvePresentationAsync(CancellationToken token)
    {
        UniTaskCompletionSource completion = _resolvePresentationCompletion;
        return completion == null
            ? UniTask.CompletedTask
            : completion.Task.AttachExternalCancellation(token);
    }

    /// <summary>부모 UI 강제 종료 시 현재 선택을 스킵으로 통지하지 않도록 닫힘을 준비한다.</summary>
    public void SuppressResolutionOnClose()
    {
        _resolved = true;
        CompleteResolvePresentation(hideSlots: false);
    }

    /// <summary>
    /// 후보를 슬롯에 표시하고 선택 상태를 초기화한다.
    /// 후보 수가 슬롯보다 적으면 남는 슬롯은 숨기고, 많으면 슬롯 수만큼만 표시한다.
    /// </summary>
    private void ApplyCandidates(
        IReadOnlyList<CardDataSO> candidates,
        IReadOnlyList<ECardDirection> directions)
    {
        _candidates.Clear();
        _previewCards.Clear();
        _resolvedDirections.Clear();
        _resolved = false;

        if (candidates != null)
        {
            for (int i = 0; i < candidates.Count; i++)
            {
                if (candidates[i] == null) continue;
                _candidates.Add(candidates[i]);
                bool hasFixedDirection = directions != null && i < directions.Count;
                ECardDirection fixedDirection = hasFixedDirection
                    ? directions[i]
                    : ECardDirection.None;
                Card preview = hasFixedDirection
                    ? CardFactory.Create(CardFactory.FromSO(candidates[i]), fixedDirection)
                    : CardFactory.CreateFromSO(candidates[i], upgraded: false);
                _previewCards.Add(preview);
                _resolvedDirections.Add(
                    preview?.Arrow != null ? preview.Arrow.Current : ECardDirection.None);
            }
        }

        for (int i = 0; i < _slots.Length; i++)
        {
            UIRewardCardSlot slot = _slots[i];
            if (slot == null) continue;

            bool hasCard = i < _candidates.Count && _candidates[i] != null;
            slot.SetVisible(hasCard);

            if (hasCard)
            {
                // 표시용 임시 Card 생성 (기본형). 덱 반영은 ID 로 별도 처리.
                Card preview = i < _previewCards.Count ? _previewCards[i] : null;
                if (preview != null)
                {
                    slot.Show(preview);
                    slot.PrepareReveal();
                }
            }
        }
    }

    private void StartRevealSequence()
    {
        StopRevealSequence();
        SetInputEnabled(false);

        int revealCount = Mathf.Min(_candidates.Count, _slots.Length);
        if (revealCount == 0)
        {
            SetInputEnabled(true);
            return;
        }

        _isRevealing = true;
        _revealRoutine = StartCoroutine(PlayRevealSequence(revealCount));
    }

    private IEnumerator PlayRevealSequence(int revealCount)
    {
        for (int i = 0; i < revealCount; i++)
        {
            UIRewardCardSlot slot = _slots[i];
            CardDataSO candidate = _candidates[i];
            if (slot == null || candidate == null) continue;

            bool playSheen = candidate.Rarity == ECardRarity.Unique ||
                             candidate.Rarity == ECardRarity.Legendary;
            slot.PlayReveal(_revealStartScale, _revealDuration, playSheen);

            float wait = i == revealCount - 1 ? _revealDuration : _revealInterval;
            if (wait > 0f)
                yield return new WaitForSecondsRealtime(wait);
        }

        _isRevealing = false;
        _revealRoutine = null;
        SetInputEnabled(true);
    }

    private void SkipRevealSequence()
    {
        StopRevealSequence();

        int revealCount = Mathf.Min(_candidates.Count, _slots.Length);
        for (int i = 0; i < revealCount; i++)
            _slots[i]?.SetVisible(true);

        SetInputEnabled(false);
        _revealRoutine = StartCoroutine(EnableInputAfterSkipDelay());
    }

    private IEnumerator EnableInputAfterSkipDelay()
    {
        if (_postSkipInputDelay > 0f)
            yield return new WaitForSecondsRealtime(_postSkipInputDelay);

        _revealRoutine = null;
        SetInputEnabled(true);
    }

    private void StopRevealSequence()
    {
        _isRevealing = false;

        if (_revealRoutine != null)
        {
            StopCoroutine(_revealRoutine);
            _revealRoutine = null;
        }

        for (int i = 0; i < _slots.Length; i++)
            _slots[i]?.ResetPresentation();
    }

    private void SetInputEnabled(bool enabled)
    {
        if (_canvasGroup != null)
        {
            _canvasGroup.interactable = enabled;
            _canvasGroup.blocksRaycasts = true;
        }

        if (_skipButton != null)
            _skipButton.interactable = enabled;

        for (int i = 0; i < _slots.Length; i++)
            _slots[i]?.SetInteractable(enabled);
    }

    /// <summary>카드 클릭 = 즉시 선택(슬더스식). 확정 버튼 없이 바로 수령 처리하고 닫는다.</summary>
    private void HandleCardClicked(int index)
    {
        if (_resolved) return; // 이미 선택/스킵됨
        if (index < 0 || index >= _candidates.Count || _candidates[index] == null) return;

        CardDataSO picked = _candidates[index];
        string cardId = picked != null ? picked.CardId : null;

#if UNITY_EDITOR || DEVELOPMENT_BUILD
        Debug.Log($"[UICardSelectPopup] 카드 선택 — {cardId}");
#endif
        ECardDirection direction = index < _resolvedDirections.Count
            ? _resolvedDirections[index]
            : ECardDirection.None;
        Resolve(cardId, direction, index);
    }

    private void HandleSkip()
    {
        if (_resolved) return;
#if UNITY_EDITOR || DEVELOPMENT_BUILD
        Debug.Log("[UICardSelectPopup] 카드 선택 스킵");
#endif
        Resolve(null, ECardDirection.None, -1);
    }

    private void Resolve(string acquiredCardId, ECardDirection direction, int selectedIndex)
    {
        _resolved = true;
        if (_keepOpenAfterResolve)
        {
            StopRevealSequence();
            SetInputEnabled(false);
            _keywordPanel?.Hide();
            BeginResolvePresentation(selectedIndex);
        }
        OnCardResolved?.Invoke(acquiredCardId, direction);
        if (!_keepOpenAfterResolve) RequestClose();
    }

    private void BeginResolvePresentation(int selectedIndex)
    {
        CompleteResolvePresentation(hideSlots: false);
        _resolvePresentationCompletion = new UniTaskCompletionSource();

        int count = Mathf.Min(_candidates.Count, _slots.Length);
        for (int i = 0; i < count; i++)
            _slots[i]?.PlayResolveFeedback(i == selectedIndex, _resolveTransitionDuration);

        if (_resolveTransitionDuration <= 0f)
        {
            CompleteResolvePresentation(hideSlots: true);
            return;
        }

        _resolvePresentationRoutine = StartCoroutine(CompleteResolvePresentationAfterDelay());
    }

    private IEnumerator CompleteResolvePresentationAfterDelay()
    {
        yield return new WaitForSecondsRealtime(_resolveTransitionDuration);
        _resolvePresentationRoutine = null;
        CompleteResolvePresentation(hideSlots: true);
    }

    private void CompleteResolvePresentation(bool hideSlots)
    {
        if (_resolvePresentationRoutine != null)
        {
            StopCoroutine(_resolvePresentationRoutine);
            _resolvePresentationRoutine = null;
        }

        if (hideSlots)
            for (int i = 0; i < _slots.Length; i++)
                _slots[i]?.SetVisible(false);

        UniTaskCompletionSource completion = _resolvePresentationCompletion;
        _resolvePresentationCompletion = null;
        completion?.TrySetResult();
    }

    /// <summary>
    /// 카드 보상은 반드시 카드 선택 또는 명시적인 스킵으로만 끝낸다.
    /// ESC 스택에는 등록하지 않으며, 선택 완료 후 Resolve가 호출하는 정상 닫기만 허용한다.
    /// 일괄 수령 중에는 선택 완료 뒤에도 같은 팝업을 재사용하므로 계속 닫기를 막는다.
    /// </summary>
    public override bool OnBackPressed() => _resolved && !_keepOpenAfterResolve;

    public override void OnClose()
    {
        StopRevealSequence();
        CompleteResolvePresentation(hideSlots: false);

        // 카드 클릭으로 닫히면 포인터가 슬롯 위에 있는 채 팝업이 비활성돼 OnPointerExit 이 오지 않는다.
        // 키워드 패널은 alpha 로만 표시를 토글하므로, 여기서 내리지 않으면 캐시된 팝업을
        // 다시 열 때 이전 키워드가 그대로 떠 있는다. (SetActive(false) 전이라 항목 풀 반환도 안전)
        if (_keywordPanel != null) _keywordPanel.Hide();

        // 선택/스킵을 거치지 않고 닫힌 경우(외부 Close·취소·씬 전환) 대기 중인 호출자를
        // 스킵으로 깨운다. 이 통지가 없으면 OnCardResolved 를 await 하던 흐름
        // (전리품 카드 수령·이벤트 카드 제시)이 영원히 재개되지 않는다.
        if (!_resolved)
        {
            _resolved = true; // Invoke 도중 재진입 방지
            OnCardResolved?.Invoke(null, ECardDirection.None);
        }

        SetInputEnabled(true);
        _candidates.Clear();
        _previewCards.Clear();
        _resolvedDirections.Clear();
        _resolved = false;
        _keepOpenAfterResolve = false;
        s_pending = null;
        s_pendingDirections = null;
        s_pendingKeepOpen = false;
        // 캐시 팝업이라 OnDestroy 는 씬 전환까지 오지 않는다. 여기서 비우지 않으면
        // 이전 사용자의 구독이 남아 다음에 연 쪽의 선택까지 받아버린다.
        OnCardResolved = null;
        base.OnClose();
    }

    private void OnDestroy()
    {
        StopRevealSequence();
        if (_skipButton != null) _skipButton.onClick.RemoveListener(HandleSkip);
        OnCardResolved = null;
    }
}
