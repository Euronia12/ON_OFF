// =================================================================
// [스크립트 목적]  휴식(모닥불) 노드 창. 현재 체력과 회복 예정량을 보여주고
//                 회복/강화 중 하나를 확정한 뒤 나가기를 받는다.
// [주요 변수]      - _hpText/_healInfoText : 현재 HP / 회복 예정량 표시
//                  - _restButton/_leaveButton : 휴식(회복)/나가기
//                  - s_pending* : 열기 직전 주입되는 현재HP·최대HP·회복량
// [의존 관계]      - UIPopupBase / UIManager / RestController(Show 로 주입 + 콜백 구독)
// [배치]           UIManager 로 여는 Popup. 키 = 타입 이름(UIRestPopup).
// [설계 노트]      - 상점/보상창과 동일하게 static Show 예약 → OpenAsync → Setup 구성.
//                  - 회복 실제 적용(RunContext.HealHp)은 RestController. 이 창은 표시·중계만.
//                  - 풀피라 회복할 게 없으면 회복 버튼 비활성(나가기만 가능).
//                  - [horizon] 강화 옵션: _upgradeButton 자리만 두고 다음 단계에서 연결.
// =================================================================

using System;
using UnityEngine;
using TMPro;
using UnityEngine.UI;

/// <summary>
/// 휴식 창. 현재 체력·회복 예정량을 표시하고 회복/강화/나가기를 받는다.
/// 실제 회복과 강화 흐름은 RestController 가 처리한다.
/// </summary>
public sealed class UIRestPopup : UIPopupBase
{
    [Header("표시")]
    [Tooltip("타이틀 텍스트")]
    [SerializeField] private TMP_Text _titleText;

    [Tooltip("선택 안내 텍스트")]
    [SerializeField] private TMP_Text _selectText;

    [Tooltip("현재 체력 라벨")]
    [SerializeField] private TMP_Text _hpLabelText;

    [Tooltip("현재 체력 표시 (예: \"32 / 50\")")]
    [SerializeField] private TMP_Text _hpText;

    [Tooltip("예상 회복 라벨")]
    [SerializeField] private TMP_Text _healLabelText;

    [Tooltip("회복 예정량 표시 (예: \"+15 회복\")")]
    [SerializeField] private TMP_Text _healInfoText;

    [SerializeField] private string _hpFormat = "{0} / {1}";
    [SerializeField] private string _healFormatKey = LocalizationKeys.Rest.HealFormat;
    [SerializeField] private string _damagedHpColor = "#FF402E";

    [Header("버튼")]
    [Tooltip("휴식(회복) 버튼")]
    [SerializeField] private Button _restButton;

    [Tooltip("강화 버튼")]
    [SerializeField] private Button _reinforceButton;

    [Tooltip("나가기 버튼 (회복 없이 떠남)")]
    [SerializeField] private Button _leaveButton;

    [Header("버튼 텍스트")]
    [Tooltip("회복 버튼 텍스트")]
    [SerializeField] private TMP_Text _restButtonText;

    [Tooltip("강화 버튼 텍스트")]
    [SerializeField] private TMP_Text _reinforceButtonText;

    [Tooltip("나가기 버튼 텍스트")]
    [SerializeField] private TMP_Text _leaveButtonText;

    // 열기 직전 주입 (OpenAsync 인자 제약 우회).
    private static int s_pendingCurrentHp;
    private static int s_pendingMaxHp;
    private static int s_pendingHealAmount;

    private bool _choiceConfirmed;
    private bool _canRest;
    private bool _leaveRequested;
    private int _currentHp;
    private int _maxHp;
    private int _healAmount;

    /// <summary>휴식(회복) 요청. RestController 가 HP 회복 후 맵 복귀.</summary>
    public event Action OnRestRequested;

    /// <summary>강화 요청. RestController 가 강화 흐름을 연다.</summary>
    public event Action OnReinforceRequested;

    /// <summary>나가기 요청 (회복 없이). RestController 가 맵 복귀.</summary>
    public event Action OnLeaveRequested;

    /// <summary>열기 직전 현재HP·최대HP·회복예정량 주입 (RestController 가 OpenAsync 직전 호출).</summary>
    public static void Show(int currentHp, int maxHp, int healAmount)
    {
        s_pendingCurrentHp = currentHp;
        s_pendingMaxHp = maxHp;
        s_pendingHealAmount = healAmount;
    }

    protected override void Init()
    {
        RefreshLocalizedTexts();

        if (_restButton != null) _restButton.onClick.AddListener(HandleRest);
        if (_reinforceButton != null) _reinforceButton.onClick.AddListener(HandleReinforce);
        if (_leaveButton != null) _leaveButton.onClick.AddListener(HandleLeave);
    }

    protected override void Setup()
    {
        _currentHp = s_pendingCurrentHp;
        _maxHp = s_pendingMaxHp;
        _healAmount = s_pendingHealAmount;
        RefreshLocalizedTexts();

        _choiceConfirmed = false;
        _leaveRequested = false;
        _canRest = s_pendingHealAmount > 0 && s_pendingCurrentHp < s_pendingMaxHp;
        RefreshChoiceButtons();
    }

    public override void OnLocalize()
    {
        base.OnLocalize();
        RefreshLocalizedTexts();
    }

    public void SetChoiceConfirmed()
    {
        _choiceConfirmed = true;
        RefreshChoiceButtons();
    }

    /// <summary>회복 적용 후 갱신된 체력을 표시한다 (자동 나가기 전 잠깐 보여주는 용도).</summary>
    public void ShowHealResult(int currentHp, int maxHp)
    {
        _currentHp = currentHp;
        _maxHp = maxHp;
        RefreshDynamicTexts();
    }

    private void HandleRest()
    {
        if (_choiceConfirmed || !_canRest) return;
        OnRestRequested?.Invoke();
    }

    private void HandleReinforce()
    {
        if (_choiceConfirmed) return;
        OnReinforceRequested?.Invoke();
    }

    private void HandleLeave()
    {
        _leaveRequested = true;
        // 컨트롤러가 페이드로 화면을 가린 뒤 닫는다.
        OnLeaveRequested?.Invoke();
    }

    private void RefreshChoiceButtons()
    {
        if (_restButton != null) _restButton.interactable = !_choiceConfirmed && _canRest;
        if (_reinforceButton != null) _reinforceButton.interactable = !_choiceConfirmed;
    }

    private void RefreshLocalizedTexts()
    {
        if (_titleText != null) _titleText.text = Localize(LocalizationKeys.Rest.Title);
        if (_selectText != null) _selectText.text = Localize(LocalizationKeys.Rest.SelectPrompt);
        if (_hpLabelText != null) _hpLabelText.text = Localize(LocalizationKeys.Rest.HpLabel);
        if (_healLabelText != null) _healLabelText.text = Localize(LocalizationKeys.Rest.HealLabel);
        if (_restButtonText != null) _restButtonText.text = Localize(LocalizationKeys.Rest.RestButton);
        if (_reinforceButtonText != null) _reinforceButtonText.text = Localize(LocalizationKeys.Rest.ReinforceButton);
        if (_leaveButtonText != null) _leaveButtonText.text = Localize(LocalizationKeys.Rest.LeaveButton);

        RefreshDynamicTexts();
    }

    private void RefreshDynamicTexts()
    {
        if (_hpText != null)
            _hpText.text = FormatHpText(_currentHp, _maxHp);
        if (_healInfoText != null)
            _healInfoText.text = string.Format(Localize(_healFormatKey), _healAmount);
    }

    private static string Localize(string key)
    {
        return LocalizationManager.HasInstance
            ? LocalizationManager.Instance.Get(key)
            : key;
    }

    private string FormatHpText(int currentHp, int maxHp)
    {
        string currentText = currentHp < maxHp
            ? $"<color={_damagedHpColor}>{currentHp}</color>"
            : currentHp.ToString();

        return string.Format(_hpFormat, currentText, maxHp);
    }

    private void OnDestroy()
    {
        if (_restButton != null) _restButton.onClick.RemoveListener(HandleRest);
        if (_reinforceButton != null) _reinforceButton.onClick.RemoveListener(HandleReinforce);
        if (_leaveButton != null) _leaveButton.onClick.RemoveListener(HandleLeave);
        OnRestRequested = null;
        OnReinforceRequested = null;
        OnLeaveRequested = null;
    }
}
