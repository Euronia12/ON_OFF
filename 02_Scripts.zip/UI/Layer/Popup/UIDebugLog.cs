using System;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

/// <summary>F6 다음 노드 타입 예약 프리팹용 UI.</summary>
public sealed class UIDebugLog : UIDebugPopupBase
{
    [SerializeField] private TMP_Dropdown _nodeTypeDropdown;
    [SerializeField] private Button _applyButton;
    public event Action<ENodeType> OnApplyRequested;

    protected override void Init()
    {
        base.Init();
        _applyButton?.onClick.AddListener(HandleApply);
        if (_nodeTypeDropdown == null) return;
        _nodeTypeDropdown.ClearOptions();
        var options = new List<TMP_Dropdown.OptionData>();
        foreach (ENodeType type in Enum.GetValues(typeof(ENodeType)))
            if (type != ENodeType.None) options.Add(new TMP_Dropdown.OptionData(type.ToString()));
        _nodeTypeDropdown.AddOptions(options);
    }

    private void HandleApply()
    {
        if (_nodeTypeDropdown == null || !Enum.TryParse(_nodeTypeDropdown.options[_nodeTypeDropdown.value].text, out ENodeType type)) return;
        OnApplyRequested?.Invoke(type);
    }
}
