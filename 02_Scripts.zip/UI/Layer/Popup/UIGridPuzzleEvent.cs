using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using Cysharp.Threading.Tasks;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

[Serializable]
public sealed class GridPuzzleHandCard
{
    [SerializeField] private CardDataSO _card;
    [SerializeField] private ECardDirection _forcedDirection;
    public CardDataSO Card => _card;
    public ECardDirection ForcedDirection => _forcedDirection;
}

[Serializable]
public sealed class GridPuzzleFixedCard
{
    [SerializeField] private CardDataSO _card;
    [SerializeField] private Vector2Int _position;
    [SerializeField] private ECardDirection _forcedDirection;
    [SerializeField] private bool _startsOn;
    public CardDataSO Card => _card;
    public Vector2Int Position => _position;
    public ECardDirection ForcedDirection => _forcedDirection;
    public bool StartsOn => _startsOn;
}

[Serializable]
public sealed class GridPuzzleRewardTier
{
    [Min(0)] [SerializeField] private int _minOnCount;
    [SerializeReference] private List<GridPuzzleRewardBase> _rewards = new();
    public int MinOnCount => _minOnCount;
    public IReadOnlyList<GridPuzzleRewardBase> Rewards => _rewards;
}

[Serializable]
public abstract class GridPuzzleRewardBase
{
    public abstract void Apply(EventContext context);
    public abstract string Describe();

    protected static string L(string key, params object[] args)
    {
        return LocalizationManager.HasInstance ? LocalizationManager.Instance.Get(key, args) : key;
    }
}

[Serializable]
public sealed class GridPuzzleGoldReward : GridPuzzleRewardBase
{
    [Min(0)] [SerializeField] private int _amount;
    public override void Apply(EventContext context) => context.InGame?.GrantGold(_amount);

    // 난이도별 골드 획득 배율을 반영한 실제 지급 예정 수치로 표기한다.
    public override string Describe() => L("UI_GRID_PUZZLE_REWARD_GOLD",
        InGameController.HasInstance ? InGameController.Instance.PreviewGrantGold(_amount) : _amount);
}

[Serializable]
public sealed class GridPuzzleHealReward : GridPuzzleRewardBase
{
    [Min(0)] [SerializeField] private int _amount;
    public override void Apply(EventContext context) => context.Run?.HealHp(_amount);
    public override string Describe() => L("UI_GRID_PUZZLE_REWARD_HEAL", _amount);
}

[Serializable]
public sealed class GridPuzzleAddCardReward : GridPuzzleRewardBase
{
    [SerializeField] private CardDataSO _card;
    public override void Apply(EventContext context)
    {
        if (_card != null) context.InGame?.AddCardToRunDeck(_card.CardId);
    }
    public override string Describe()
    {
        string name = _card != null && LocalizationManager.HasInstance
            ? LocalizationManager.Instance.Get(_card.DisplayNameKey)
            : _card != null ? _card.CardId : string.Empty;
        return L("UI_GRID_PUZZLE_REWARD_CARD", name);
    }
}

/// <summary>전투 그리드와 손패 입력만 재사용하는 묘수풀이 Event.</summary>
public sealed class UIGridPuzzleEvent : UIPopupBase, IEventView
{
    [Header("문구 키")]
    [SerializeField] private string _introTitleKey = "UI_GRID_PUZZLE_TITLE";
    [SerializeField] private string _introDescKey = "UI_GRID_PUZZLE_DESC";
    [SerializeField] private string _startKey = "UI_GRID_PUZZLE_START";
    [SerializeField] private string _endKey = "UI_GRID_PUZZLE_END";
    [SerializeField] private string _resultTitleKey = "UI_GRID_PUZZLE_RESULT_TITLE";
    [SerializeField] private string _resultCountKey = "UI_GRID_PUZZLE_RESULT_COUNT";
    [SerializeField] private string _noRewardKey = "UI_GRID_PUZZLE_NO_REWARD";
    [SerializeField] private string _continueKey = "UI_GRID_PUZZLE_CONTINUE";

    [Header("퍼즐")]
    [Min(1)] [SerializeField] private int _gridSize = 3;
    [SerializeField] private List<GridPuzzleHandCard> _handCards = new();
    [SerializeField] private List<GridPuzzleFixedCard> _fixedCards = new();
    [SerializeField] private List<GridPuzzleRewardTier> _rewardTiers = new();

    [Header("전투 UI 재사용")]
    [SerializeField] private UICardHand _cardHand;
    [SerializeField] private CardPlacementInput _placement;
    [SerializeField] private Button _endButton;
    [SerializeField] private TMP_Text _endButtonText;
    [SerializeField] private List<GameObject> _hiddenBattleObjects = new();

    private readonly List<Card> _runtimeCards = new();
    private EventContext _context;
    private CancellationToken _token;
    private UniTaskCompletionSource _finished;
    private PuzzlePlacementService _service;
    private GameObject _overlay;
    private TMP_Text _overlayTitle;
    private TMP_Text _overlayDesc;
    private TMP_Text _overlayButtonText;
    private Button _overlayButton;
    private int _oldRows;
    private int _oldColumns;
    private bool _evaluating;

    protected override void Init()
    {
        ResolveBattleUi();
        BuildOverlay();
        _endButton?.onClick.AddListener(HandleEndClicked);
        GridCardHoverProbe[] probes = GetComponentsInChildren<GridCardHoverProbe>(true);
        for (int i = 0; i < probes.Length; i++) probes[i].enabled = false;
    }

    private void ResolveBattleUi()
    {
        if (_cardHand == null) _cardHand = GetComponentInChildren<UICardHand>(true);
        if (_placement == null) _placement = GetComponentInChildren<CardPlacementInput>(true);
        if (_endButton == null)
        {
            Button[] buttons = GetComponentsInChildren<Button>(true);
            for (int i = 0; i < buttons.Length; i++)
                if (buttons[i].name == "EndTurnButton") { _endButton = buttons[i]; break; }
        }
        if (_endButtonText == null && _endButton != null)
            _endButtonText = _endButton.GetComponentInChildren<TMP_Text>(true);

        UIBattle battle = GetComponentInChildren<UIBattle>(true);
        if (battle != null) battle.enabled = false;
        PreserveSelectInput preserve = GetComponentInChildren<PreserveSelectInput>(true);
        if (preserve != null) preserve.enabled = false;
        SkillCastInput skillInput = GetComponentInChildren<SkillCastInput>(true);
        if (skillInput != null) skillInput.enabled = false;

        string[] hiddenNames = { "UIBattleSkillPanel", "SkillPanel", "PlayerStatus", "EnemyStatus", "EnemyIntent", "DrawPile", "DiscardPile", "Preserve" };
        Transform[] children = GetComponentsInChildren<Transform>(true);
        for (int i = 0; i < children.Length; i++)
        {
            for (int j = 0; j < hiddenNames.Length; j++)
            {
                if (children[i].name.IndexOf(hiddenNames[j], StringComparison.OrdinalIgnoreCase) < 0) continue;
                if (children[i] != transform) children[i].gameObject.SetActive(false);
                break;
            }
        }
    }

    public async UniTask PlayAsync(EventContext context, CancellationToken token)
    {
        if (context.Grid == null) throw new InvalidOperationException("Event 그리드를 찾을 수 없습니다.");

        _context = context;
        _token = token;
        _finished = new UniTaskCompletionSource();
        try
        {
            SetPuzzleVisible(false);
            await ShowOverlayAsync(_introTitleKey, _introDescKey, _startKey);
            token.ThrowIfCancellationRequested();
            StartPuzzle();
            await _finished.Task.AttachExternalCancellation(token);
        }
        finally
        {
            CleanupPuzzle();
        }
    }

    public override void OnClose()
    {
        CleanupPuzzle();
        base.OnClose();
    }

    private void StartPuzzle()
    {
        GridManager grid = _context.Grid;
        _oldRows = grid.Rows;
        _oldColumns = grid.Columns;
        grid.SetGridSize(_gridSize, _gridSize);

        _runtimeCards.Clear();
        for (int i = 0; i < _fixedCards.Count; i++)
        {
            GridPuzzleFixedCard entry = _fixedCards[i];
            if (entry?.Card == null) continue;
            Card card = CardFactory.Create(CardFactory.FromSO(entry.Card), entry.ForcedDirection);
            if (!grid.TryPlaceCard(card, entry.Position)) continue;
            card.GridState.SetActivated(entry.StartsOn);
            grid.SetCardActivatedImmediate(card, entry.StartsOn);
            _runtimeCards.Add(card);
        }

        _service = new PuzzlePlacementService(grid, _token, HandleProcessingChanged, HandleAllCardsUsed);
        _placement.SetPlacementService(_service);
        _cardHand.Open();
        for (int i = 0; i < _handCards.Count; i++)
        {
            GridPuzzleHandCard entry = _handCards[i];
            if (entry?.Card == null) continue;
            Card card = CardFactory.Create(CardFactory.FromSO(entry.Card), entry.ForcedDirection);
            card.ApplyRecallCostOverride();
            UICard uiCard = _cardHand.AddCard();
            if (uiCard == null) continue;
            _runtimeCards.Add(card);
            _service.Register(card);
            uiCard.Bind(card);
            _placement.RegisterCard(uiCard);
        }

        SetPuzzleVisible(true);
        if (_endButtonText != null)
        {
            LocalizedFontUtility.ApplyCurrentFont(_endButtonText);
            _endButtonText.text = L(_endKey);
        }
    }

    private void HandleEndClicked()
    {
        if (_service == null || _service.IsProcessing) return;
        EvaluateAsync().Forget();
    }

    private void HandleAllCardsUsed() => EvaluateAsync().Forget();

    private void HandleProcessingChanged(bool processing)
    {
        if (_endButton != null) _endButton.interactable = !processing;
    }

    private async UniTaskVoid EvaluateAsync()
    {
        if (_evaluating) return;
        _evaluating = true;
        SetPuzzleVisible(false);

        int onCount = 0;
        foreach (KeyValuePair<Vector2Int, GridSlot> pair in _context.Grid.Slots)
        {
            Card card = pair.Value?.OccupiedCard;
            if (card?.GridState != null && card.GridState.IsActivated) onCount++;
        }

        GridPuzzleRewardTier selected = null;
        for (int i = 0; i < _rewardTiers.Count; i++)
        {
            GridPuzzleRewardTier tier = _rewardTiers[i];
            if (tier != null && tier.MinOnCount <= onCount &&
                (selected == null || tier.MinOnCount > selected.MinOnCount)) selected = tier;
        }

        var desc = new StringBuilder(L(_resultCountKey, onCount));
        IReadOnlyList<GridPuzzleRewardBase> rewards = selected?.Rewards;
        if (rewards == null || rewards.Count == 0)
        {
            desc.AppendLine().Append(L(_noRewardKey));
        }
        else
        {
            for (int i = 0; i < rewards.Count; i++)
            {
                GridPuzzleRewardBase reward = rewards[i];
                if (reward == null) continue;
                reward.Apply(_context);
                desc.AppendLine().Append(reward.Describe());
            }
        }

        // 보상 적용 완료를 결과 오버레이보다 먼저 저장해 종료 후 중복 지급을 막는다.
        _context.InGame?.CompletePendingEvent(_context.NodeId);

        await ShowOverlayAsync(_resultTitleKey, desc.ToString(), _continueKey, false);
        _finished?.TrySetResult();
    }

    private async UniTask ShowOverlayAsync(string titleKey, string descKey, string buttonKey, bool localizeDesc = true)
    {
        LocalizedFontUtility.ApplyCurrentFont(_overlayTitle);
        LocalizedFontUtility.ApplyCurrentFont(_overlayDesc);
        LocalizedFontUtility.ApplyCurrentFont(_overlayButtonText);
        _overlayTitle.text = L(titleKey);
        _overlayDesc.text = localizeDesc ? L(descKey) : descKey;
        _overlayButtonText.text = L(buttonKey);
        _overlay.SetActive(true);
        var source = new UniTaskCompletionSource();
        void Complete() => source.TrySetResult();
        _overlayButton.onClick.AddListener(Complete);
        try { await source.Task.AttachExternalCancellation(_token); }
        finally { _overlayButton.onClick.RemoveListener(Complete); _overlay.SetActive(false); }
    }

    private void SetPuzzleVisible(bool visible)
    {
        if (_cardHand != null) _cardHand.gameObject.SetActive(visible);
        if (_endButton != null) _endButton.gameObject.SetActive(visible);
        for (int i = 0; i < _hiddenBattleObjects.Count; i++)
            if (_hiddenBattleObjects[i] != null) _hiddenBattleObjects[i].SetActive(false);
    }

    private void CleanupPuzzle()
    {
        if (_placement != null) _placement.SetPlacementService(null);
        if (_cardHand != null) _cardHand.Close();
        if (_context.Grid != null && _oldRows > 0 && _oldColumns > 0)
        {
            _context.Grid.ClearAllCards();
            _context.Grid.SetGridSize(_oldRows, _oldColumns);
        }
        _runtimeCards.Clear();
        _service = null;
    }

    private void BuildOverlay()
    {
        _overlay = new GameObject("PuzzleOverlay", typeof(RectTransform), typeof(Image));
        RectTransform root = (RectTransform)_overlay.transform;
        root.SetParent(transform, false);
        root.anchorMin = Vector2.zero; root.anchorMax = Vector2.one;
        root.offsetMin = root.offsetMax = Vector2.zero;
        _overlay.GetComponent<Image>().color = new Color(0.04f, 0.04f, 0.06f, 0.94f);
        _overlayTitle = CreateText(root, new Vector2(0.15f, 0.68f), new Vector2(0.85f, 0.85f), 42);
        _overlayDesc = CreateText(root, new Vector2(0.15f, 0.32f), new Vector2(0.85f, 0.68f), 28);
        GameObject buttonGo = new GameObject("ContinueButton", typeof(RectTransform), typeof(Image), typeof(Button));
        RectTransform buttonRect = (RectTransform)buttonGo.transform;
        buttonRect.SetParent(root, false); buttonRect.anchorMin = new Vector2(.38f, .15f); buttonRect.anchorMax = new Vector2(.62f, .25f);
        buttonRect.offsetMin = buttonRect.offsetMax = Vector2.zero;
        buttonGo.GetComponent<Image>().color = new Color(.22f, .42f, .75f, 1f);
        _overlayButton = buttonGo.GetComponent<Button>();
        _overlayButtonText = CreateText(buttonRect, Vector2.zero, Vector2.one, 26);
        _overlay.SetActive(false);
    }

    private static TMP_Text CreateText(Transform parent, Vector2 min, Vector2 max, float size)
    {
        GameObject go = new GameObject("Text", typeof(RectTransform), typeof(TextMeshProUGUI));
        RectTransform rect = (RectTransform)go.transform;
        rect.SetParent(parent, false); rect.anchorMin = min; rect.anchorMax = max;
        rect.offsetMin = rect.offsetMax = Vector2.zero;
        TMP_Text text = go.GetComponent<TMP_Text>();
        LocalizedFontUtility.ApplyCurrentFont(text);
        text.alignment = TextAlignmentOptions.Center; text.fontSize = size; text.color = Color.white;
        return text;
    }

    private string L(string key, params object[] args) =>
        LocalizationManager.HasInstance ? LocalizationManager.Instance.Get(key, args) : key;

    private sealed class PuzzlePlacementService : ICardPlacementService
    {
        private readonly GridManager _grid;
        private readonly ChainExecutor _chain;
        private readonly HashSet<Card> _available = new();
        private readonly CancellationToken _token;
        private readonly Action<bool> _processingChanged;
        private readonly Action _allUsed;
        public int CurrentEnergy => int.MaxValue;
        public bool IsProcessing { get; private set; }

        public PuzzlePlacementService(
            GridManager grid,
            CancellationToken token,
            Action<bool> processingChanged,
            Action allUsed)
        {
            _grid = grid;
            _chain = new ChainExecutor(grid, null, new NullChainPresenter(), null);
            _token = token;
            _processingChanged = processingChanged;
            _allUsed = allUsed;
        }

        public void Register(Card card) { if (card != null) _available.Add(card); }

        public bool CanPlaceCard(Card card, Vector2Int position)
        {
            GridSlot slot = _grid?.GetSlot(position);
            return !IsProcessing && card != null && _available.Contains(card) &&
                   slot != null && slot.IsUsable && slot.IsEmpty;
        }

        public async UniTask<bool> PlaceCardAsync(Card card, Vector2Int position)
        {
            if (!CanPlaceCard(card, position) || !_grid.TryPlaceCard(card, position)) return false;
            _available.Remove(card);
            IsProcessing = true;
            _processingChanged?.Invoke(true);
            _chain.ResetChainActivatedCount();
            try { await _chain.ExecuteFromAsync(card, _token); }
            finally
            {
                IsProcessing = false;
                _processingChanged?.Invoke(false);
            }
            if (_available.Count == 0)
            {
                await UniTask.Yield(PlayerLoopTiming.LastPostLateUpdate, _token);
                _allUsed?.Invoke();
            }
            return true;
        }
    }
}
