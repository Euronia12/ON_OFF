using System;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

/// <summary>F8 다음 전투 적 예약 프리팹용 UI.</summary>
public sealed class UIDebugEnemy : UIDebugPopupBase
{
    [SerializeField] private TMP_InputField _searchInput;
    [SerializeField] private TMP_Dropdown _enemyDropdown;
    [SerializeField] private Button _applyButton;
    private readonly List<EnemyDataSO> _enemies = new();
    public event Action<EnemyDataSO> OnApplyRequested;

    protected override void Init()
    {
        base.Init();
        _applyButton?.onClick.AddListener(HandleApply);
        _searchInput?.onValueChanged.AddListener(RefreshOptions);
    }

    public void Bind(IReadOnlyList<EnemyDataSO> enemies)
    {
        _enemies.Clear();
        if (enemies != null) _enemies.AddRange(enemies);
        RefreshOptions(_searchInput != null ? _searchInput.text : string.Empty);
    }

    private void RefreshOptions(string search)
    {
        if (_enemyDropdown == null) return;
        _enemyDropdown.ClearOptions();
        var options = new List<TMP_Dropdown.OptionData>();
        for (int i = 0; i < _enemies.Count; i++)
        {
            EnemyDataSO item = _enemies[i];
            if (item == null || !Matches(item.EnemyId, item.DisplayNameKey, search)) continue;
            options.Add(new TMP_Dropdown.OptionData($"{item.EnemyId} | {item.DisplayNameKey} | {item.Grade}"));
        }
        _enemyDropdown.AddOptions(options);
        _enemyDropdown.RefreshShownValue();
    }

    private void HandleApply()
    {
        EnemyDataSO selected = GetSelected();
        if (selected != null) OnApplyRequested?.Invoke(selected);
    }

    private EnemyDataSO GetSelected()
    {
        if (_enemyDropdown == null || _enemyDropdown.options.Count == 0) return null;
        string label = _enemyDropdown.options[_enemyDropdown.value].text;
        for (int i = 0; i < _enemies.Count; i++)
            if (_enemies[i] != null && label.StartsWith(_enemies[i].EnemyId + " |", StringComparison.Ordinal)) return _enemies[i];
        return null;
    }

    private static bool Matches(string id, string name, string search)
        => string.IsNullOrWhiteSpace(search) ||
           (id?.IndexOf(search, StringComparison.OrdinalIgnoreCase) ?? -1) >= 0 ||
           (name?.IndexOf(search, StringComparison.OrdinalIgnoreCase) ?? -1) >= 0;
}
