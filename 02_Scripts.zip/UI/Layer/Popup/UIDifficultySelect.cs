using System;
using System.Threading;
using Cysharp.Threading.Tasks;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

/// <summary>UITitle 내부에서 메인 메뉴와 교대 표시되는 난이도 선택 메뉴.</summary>
public sealed class UIDifficultySelect : MonoBehaviour, ILocalizable
{
    [Header("버튼")]
    [SerializeField] private Button _normalButton;
    [SerializeField] private Button _hardButton;
    [SerializeField] private Button _hellButton;
    [SerializeField] private Button _cancelButton;

    [Header("버튼 텍스트")]
    [SerializeField] private TMP_Text _normalText;
    [SerializeField] private TMP_Text _hardText;
    [SerializeField] private TMP_Text _hellText;
    [SerializeField] private TMP_Text _cancelText;

    [Header("난이도 설명")]
    [SerializeField] private UIHoverIntentSource _normalHoverSource;
    [SerializeField] private UIHoverIntentSource _hardHoverSource;
    [SerializeField] private UIHoverIntentSource _hellHoverSource;
    [SerializeField] private UIHoverIntentTooltip _descriptionPanel;
    [SerializeField] private TMP_Text _descriptionText;

    private UniTaskCompletionSource<ERunDifficulty?> _resultSource;
    private string _activeDescriptionKey;
    private bool _completed;
    private bool _initialized;

    public bool IsSelecting => !_completed && _resultSource != null;

    public void Initialize()
    {
        if (_initialized)
            return;

        if (_normalButton == null || _hardButton == null || _hellButton == null ||
            _cancelButton == null || _normalText == null || _hardText == null ||
            _hellText == null || _cancelText == null || _normalHoverSource == null ||
            _hardHoverSource == null || _hellHoverSource == null ||
            _descriptionPanel == null || _descriptionText == null)
        {
            Debug.LogError("[UIDifficultySelect] DifficultySelectRoot의 직렬화 참조가 누락되었습니다.", this);
            return;
        }

        _normalButton?.onClick.AddListener(HandleNormal);
        _hardButton?.onClick.AddListener(HandleHard);
        _hellButton?.onClick.AddListener(HandleHell);
        _cancelButton?.onClick.AddListener(HandleCancel);
        _normalHoverSource.Bind(
            _descriptionPanel,
            () => ShowDescription(LocalizationKeys.Run.DifficultyNormalDescription),
            ClearDescription);
        _hardHoverSource.Bind(
            _descriptionPanel,
            () => ShowDescription(LocalizationKeys.Run.DifficultyHardDescription),
            ClearDescription);
        _hellHoverSource.Bind(
            _descriptionPanel,
            () => ShowDescription(LocalizationKeys.Run.DifficultyHellDescription),
            ClearDescription);
        _initialized = true;
        RefreshTexts();
    }

    public async UniTask<ERunDifficulty?> ShowAsync(CancellationToken token = default)
    {
        if (!_initialized)
        {
            Debug.LogError("[UIDifficultySelect] UITitle 내부 난이도 메뉴가 초기화되지 않았습니다.");
            return null;
        }

        if (IsSelecting)
            return null;

        _completed = false;
        _resultSource = new UniTaskCompletionSource<ERunDifficulty?>();
        _descriptionPanel.ForceCloseBranch();
        ClearDescription();
        gameObject.SetActive(true);
        RefreshTexts();

        if (_normalButton != null && EventSystem.current != null)
            _normalButton.Select();

        try
        {
            return await _resultSource.Task.AttachExternalCancellation(token);
        }
        catch (OperationCanceledException)
        {
            Complete(null);
            throw;
        }
    }

    public bool CancelSelection()
    {
        if (!IsSelecting)
            return false;

        Complete(null);
        return true;
    }

    private void Complete(ERunDifficulty? difficulty)
    {
        if (_completed) return;
        _completed = true;
        UniTaskCompletionSource<ERunDifficulty?> source = _resultSource;
        _resultSource = null;
        _descriptionPanel.ForceCloseBranch();
        ClearDescription();
        gameObject.SetActive(false);
        source?.TrySetResult(difficulty);
    }

    public void OnLocalize()
    {
        LocalizedFontUtility.ApplyCurrentFont(this);
        RefreshTexts();
    }

    private void RefreshTexts()
    {
        if (_normalText != null)
            _normalText.text = Localize(LocalizationKeys.Run.DifficultyNormal);
        if (_hardText != null)
            _hardText.text = Localize(LocalizationKeys.Run.DifficultyHard);
        if (_hellText != null)
            _hellText.text = Localize(LocalizationKeys.Run.DifficultyHell);
        if (_cancelText != null)
            _cancelText.text = Localize(LocalizationKeys.Common.Cancel);
        if (_descriptionText != null && !string.IsNullOrEmpty(_activeDescriptionKey))
            _descriptionText.text = Localize(_activeDescriptionKey);
    }

    private static string Localize(string key)
        => LocalizationManager.HasInstance ? LocalizationManager.Instance.Get(key) : key;

    private void ShowDescription(string key)
    {
        _activeDescriptionKey = key;
        _descriptionText.text = Localize(key);
    }

    private void ClearDescription()
    {
        _activeDescriptionKey = null;
        if (_descriptionText != null)
            _descriptionText.text = string.Empty;
    }

    private void HandleNormal() => Complete(ERunDifficulty.Normal);
    private void HandleHard() => Complete(ERunDifficulty.Hard);
    private void HandleHell() => Complete(ERunDifficulty.Hell);
    private void HandleCancel() => Complete(null);

    private void OnDestroy()
    {
        _normalButton?.onClick.RemoveListener(HandleNormal);
        _hardButton?.onClick.RemoveListener(HandleHard);
        _hellButton?.onClick.RemoveListener(HandleHell);
        _cancelButton?.onClick.RemoveListener(HandleCancel);
        if (_normalHoverSource != null)
            _normalHoverSource.Unbind();
        if (_hardHoverSource != null)
            _hardHoverSource.Unbind();
        if (_hellHoverSource != null)
            _hellHoverSource.Unbind();
        if (!_completed)
            _resultSource?.TrySetResult(null);
        _resultSource = null;
    }
}
