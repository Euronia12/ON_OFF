﻿// =================================================================
// [스크립트 목적]  플레이어/적 공용 전투 상태 표시 위젯. 액터 이벤트 구독으로 HP·방어막·
//                 에너지를 갱신. UIBattle 이 플레이어/적에 각각 Bind 해 재사용.
// [주요 변수]      - _hpSlider/_hpText  : 체력 슬라이더(보간)·수치
//                  - _blockIcon/_blockText : 방어막 방패 아이콘·수치 (0이면 숨김)
//                  - _hpBlockFrame : 방어막 있을 때 체력바를 감싸는 보호 프레임 (0이면 숨김)
//                  - _blockedHpColor : 방어막 있을 때 체력바 채움 틴트색 (해제 시 원래 색 복귀)
//                  - _energyIcon/_energyText : 에너지 아이콘·수치 (플레이어 전용, 적은 숨김)
// [의존 관계]      - IBattleActor / PlayerActor / EnemyActor (이벤트 구독)
// [배치]           UIBattle 프리팹 자식 위젯. UIBase 아님 (조립은 UIBattle 책임)
// [설계 노트]      - 같은 위젯을 플레이어/적에 재사용. 에너지는 옵션(없으면 숨김)
//                  - 적 의도는 UIEnemyIntentView 로 분리 (다중 의도·확장 대응)
//                  - 단일 적 기준 고정 위젯 (풀링 불필요). 다수 적은 horizon 에서 리스트풀 전환
//                  - 수치만 표시, 실제 비주얼/연출 디자인은 팀원이 프리팹·확장으로
// =================================================================

using System;
using System.Threading;
using Cysharp.Threading.Tasks;
using DG.Tweening;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// 한 액터(플레이어 또는 적)의 전투 상태를 표시하는 재사용 위젯.
/// Bind 로 액터를 연결하면 HP·방어막·에너지 변동 이벤트를 구독해 자동 갱신한다.
/// 플레이어는 에너지를 추가로 표시하며, 적은 에너지를 숨긴다. (의도는 UIEnemyIntentView 담당)
/// </summary>
public sealed class UIActorStatus : MonoBehaviour
{
    [Header("체력")]
    [Tooltip("HP 슬라이더 (표시 전용, value 0~1). interactable=false 권장")]
    [SerializeField] private Image _hpImg;

    [Tooltip("HP 변동 보간 시간(초). 0이면 즉시 스냅")]
    [Min(0f)]
    [SerializeField] private float _hpTweenDuration = 0.3f;

    [Tooltip("HP 수치 텍스트 (예: 45/50)")]
    [SerializeField] private TMP_Text _hpText;

    [Header("방어막")]
    [Tooltip("방패 아이콘 (블록 있을 때만 표시). 이 오브젝트를 켜고 끔. Sprite는 프리팹에 박아둠")]
    [SerializeField] private Image _blockIcon;

    [Tooltip("방어막 수치 텍스트 (방패 아이콘 자식)")]
    [SerializeField] private TMP_Text _blockText;

    [Tooltip("방어막이 있을 때 체력바를 감싸는 보호 프레임 (선택). 이 오브젝트를 켜고 끔")]
    [SerializeField] private GameObject _hpBlockFrame;

    [Tooltip("방어막이 있을 때 체력바 채움에 입힐 보호색 (슬더스식). 방어막 0이면 원래 색 복귀")]
    [SerializeField] private Color _blockedHpColor = new Color(0.47f, 0.56f, 0.63f);

    [Header("에너지 (플레이어 전용)")]
    [Tooltip("에너지 아이콘 (플레이어만 표시, 적은 숨김). 이 오브젝트를 켜고 끔. Sprite는 프리팹에 박아둠")]
    [SerializeField] private Image _energyIcon;

    [Tooltip("에너지 수치 텍스트 (에너지 아이콘 자식, 예: 3/3)")]
    [SerializeField] private TMP_Text _energyText;

    [Tooltip("현재 에너지가 0일 때 현재값 부분에 적용할 색상")]
    [SerializeField] private Color _emptyEnergyColor = Color.red;

    // 현재 바인딩된 액터 (구독 해제용 참조).
    private PlayerActor _player;
    private EnemyActor _enemy;

    // 직전 블록 값 (변동 감지해 연출 트리거용).
    private int _prevBlock;
    private Vector3 _blockIconBaseScale = Vector3.one;
    private bool _blockIconBaseScaleCaptured;

    // 체력바 원래 색 (방어막 해제 시 복귀용). Awake 에서 1회 캡처.
    private Color _hpBaseColor = Color.white;
    private bool _hpBaseColorCaptured;
    private Tween _hpTween;

    // ── 바인딩 ──────────────────────────────────────────────

    private void Awake()
    {
        CaptureBlockIconBaseScale();
        CaptureHpBaseColor();
    }

    /// <summary>플레이어 액터 바인딩 — HP·방어막·에너지 구독. (의도는 UIEnemyIntentView 담당)</summary>
    public void BindPlayer(PlayerActor player)
    {
        Unbind();
        _player = player;
        if (player == null) return;

        player.OnHpChanged += HandleHpChanged;
        player.OnBlockChanged += HandleBlockChanged;
        player.OnEnergyChanged += HandleEnergyChanged;

        // 에너지는 플레이어만 표시.
        SetActive(_energyIcon != null ? _energyIcon.gameObject : null, true);

        // 현재값 즉시 반영. (HP는 전투 시작 슬금 차오름 방지 위해 스냅)
        HandleHpChanged(player.Hp, player.MaxHp, animate: false);
        HandleBlockChanged(player.Block, animate: false);
        HandleEnergyChanged(player.Energy, player.MaxEnergy);
    }

    /// <summary>적 액터 바인딩 — HP·방어막 구독. 에너지는 숨김. (의도는 UIEnemyIntentView 담당)</summary>
    public void BindEnemy(EnemyActor enemy)
    {
        Unbind();
        _enemy = enemy;
        if (enemy == null) return;

        enemy.OnHpChanged += HandleHpChanged;
        enemy.OnBlockChanged += HandleBlockChanged;

        // 에너지는 적에게 없음.
        SetActive(_energyIcon != null ? _energyIcon.gameObject : null, false);

#if UNITY_EDITOR || DEVELOPMENT_BUILD
        Debug.Log($"[UIActorStatus] '{name}' 적 바인딩 완료 — HP {enemy.Hp}/{enemy.MaxHp} 구독 시작");
#endif

        // 현재값 즉시 반영. (HP는 스냅)
        HandleHpChanged(enemy.Hp, enemy.MaxHp, animate: false);
        HandleBlockChanged(enemy.Block, animate: false);
    }

    /// <summary>구독 해제 (재바인딩·파괴 시). 중복 호출 안전.</summary>
    public void Unbind()
    {
        // 진행 중인 HP 슬라이더 트윈 정리 (재바인딩·파괴 시 좀비 트윈 방지).
        StopHpTween();
        ResetBlockIconScale();

        // 체력바 보호색 틴트 원복 (재바인딩 시 이전 액터의 방어막 색이 남지 않게).
        if (_hpImg != null && _hpBaseColorCaptured) _hpImg.color = _hpBaseColor;

        if (_player != null)
        {
            _player.OnHpChanged -= HandleHpChanged;
            _player.OnBlockChanged -= HandleBlockChanged;
            _player.OnEnergyChanged -= HandleEnergyChanged;
            _player = null;
        }
        if (_enemy != null)
        {
            _enemy.OnHpChanged -= HandleHpChanged;
            _enemy.OnBlockChanged -= HandleBlockChanged;
            _enemy = null;
        }
    }

    private void OnDestroy() => Unbind();

    // ── 이벤트 핸들러 ───────────────────────────────────────

    // 이벤트 구독 시그니처(int, int)용 진입점 — 변동은 보간.
    private void HandleHpChanged(int current, int max) => HandleHpChanged(current, max, animate: true);

    private void HandleHpChanged(int current, int max, bool animate)
    {
        if (_hpImg != null)
        {
            float target = max > 0 ? (float)current / max : 0f;
            // 진행 중인 HP 트윈 정리 후 갱신 (연속 피격 시 트윈 누적 방지).
            _hpTween?.Kill();
            if (animate && _hpTweenDuration > 0f && _hpImg.gameObject.activeInHierarchy)
            {
                _hpTween = _hpImg.DOFillAmount(target, _hpTweenDuration)
                                 .SetUpdate(true)
                                 .SetLink(gameObject)
                                 .OnKill(() => _hpTween = null);
            }
            else
            {
                _hpTween = null;
                _hpImg.fillAmount = target;
            }
        }

        if (_hpText != null)
        {
            _hpText.text = $"{current}/{max}";
        }

#if UNITY_EDITOR || DEVELOPMENT_BUILD
        // 진단: HP 변경이 위젯까지 도달했는지 + UI 필드 연결 상태.
        if (_hpImg == null && _hpText == null)
        {
            Debug.LogWarning($"[UIActorStatus] '{name}' HP 변경({current}/{max}) 수신했으나 " +
                "_hpSlider·_hpText 둘 다 미연결입니다. Inspector 에서 HP 슬라이더/텍스트를 연결하세요.");
        }
        else
        {
            Debug.Log($"[UIActorStatus] '{name}' HP 갱신 → {current}/{max}");
        }
#endif
    }

    internal async UniTask WaitForHpTweenAsync(CancellationToken token)
    {
        Tween tween = _hpTween;
        if (tween == null || !tween.IsActive()) return;

        try
        {
            await tween.AsUniTask(token);
        }
        catch (OperationCanceledException)
        {
            // UI 해제·씬 이탈로 보간이 중단되면 대기만 끝낸다.
        }
    }

    // 이벤트 구독 시그니처(int)용 진입점 — 변동은 연출.
    private void HandleBlockChanged(int block) => HandleBlockChanged(block, animate: true);

    private void HandleBlockChanged(int block, bool animate)
    {
        bool show = block > 0;

        // 방어막 0이면 방패 아이콘 숨김 (슬더슬식 — 블록 있을 때만 노출).
        if (_blockIcon != null)
        {
            CaptureBlockIconBaseScale();
            if (!show || !animate) ResetBlockIconScale();
            SetActive(_blockIcon.gameObject, show);
        }

        // 방어막이 있는 동안 체력바 보호 프레임 표시 (감싸여 보호받는 느낌).
        SetActive(_hpBlockFrame, show);

        // 체력바 채움도 보호색으로 틴트 (슬더스식 — 방어막 해제 시 원래 색 복귀).
        if (_hpImg != null)
        {
            CaptureHpBaseColor();
            _hpImg.color = show ? _blockedHpColor : _hpBaseColor;
        }

        if (show && _blockText != null)
        {
            _blockText.text = block.ToString();
        }

        // 블록 값이 실제로 변했고 표시 중이면 방패 튀어오름 연출.
        if (animate && show && block != _prevBlock && _blockIcon != null)
        {
            ResetBlockIconScale();
            _blockIcon.transform.PunchScale();
        }

        _prevBlock = block;
    }

    private void HandleEnergyChanged(int current, int max)
    {
        if (_energyText != null)
        {
            string currentText = current == 0
                ? $"<color=#{ColorUtility.ToHtmlStringRGBA(_emptyEnergyColor)}>0</color>"
                : current.ToString();
            _energyText.text = $"{currentText}/{max}";
        }
    }

    // ── 내부 ───────────────────────────────────────────────

    private static void SetActive(GameObject go, bool active)
    {
        if (go != null && go.activeSelf != active)
        {
            go.SetActive(active);
        }
    }

    private void StopHpTween()
    {
        _hpTween?.Kill();
        _hpTween = null;
    }

    private void CaptureBlockIconBaseScale()
    {
        if (_blockIcon == null || _blockIconBaseScaleCaptured) return;

        _blockIconBaseScale = _blockIcon.transform.localScale;
        _blockIconBaseScaleCaptured = true;
    }

    private void CaptureHpBaseColor()
    {
        if (_hpImg == null || _hpBaseColorCaptured) return;

        _hpBaseColor = _hpImg.color;
        _hpBaseColorCaptured = true;
    }

    private void ResetBlockIconScale()
    {
        if (_blockIcon == null) return;

        Transform iconTransform = _blockIcon.transform;
        DOTween.Kill(iconTransform);
        iconTransform.localScale = _blockIconBaseScale;
    }
}
