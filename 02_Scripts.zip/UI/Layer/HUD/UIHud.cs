﻿// =================================================================
// [스크립트 목적]  인게임 HUD UI 템플릿 (체력바·점수·미니맵 등 상시 표시 UI)
// [의존 관계]      - UIBase
// [배치]           Canvas 하위 구성 후 부착, Addressable "UIHud" 등록, Layer = HUD
// [원칙]           HUD는 게임 상태를 "표시"만. 데이터 변경은 이벤트 구독으로 갱신
// =================================================================
using UnityEngine;
using UnityEngine.UI;

public class UIHud : UIBase
{
    //[Header("HUD 요소")]
    //[SerializeField] private Slider _hpBar;
    //[SerializeField] private Text _scoreText;

    // 이벤트 구독 핸들 (OnDisable에서 해제)
    private IDisposableEvent _scoreSub;

    public override void OnOpen()
    {
        base.OnOpen();

        // 점수 변경 이벤트 구독 (예시 — 실제 이벤트 타입에 맞게 교체)
        // _scoreSub = EventManager.Instance.Subscribe<ScoreChangedEvent>(OnScoreChanged);
    }

    public override void OnClose()
    {
        // 구독 해제 (필수)
        //_scoreSub?.Dispose();
        //_scoreSub = null;

        base.OnClose();
    }

    // ─────────────────────────────────────────────
    // 표시 갱신 (컨트롤러/이벤트가 호출)
    // ─────────────────────────────────────────────

    //public void SetHp(float current, float max)
    //{
    //    if (_hpBar != null)
    //        _hpBar.value = max > 0f ? current / max : 0f;
    //}

    //public void SetScore(int score)
    //{
    //    if (_scoreText != null)
    //        _scoreText.text = score.ToString("N0");
    //}

    // 이벤트 핸들러 예시
    // private void OnScoreChanged(ScoreChangedEvent evt) => SetScore(evt.NewScore);
}
