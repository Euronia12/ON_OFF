// =================================================================
// [스크립트 목적]  런 클리어 패럴랙스 루프의 버튼·ESC 스킵 요청을 전달한다.
// [주요 변수]      - _skipButton : 화면 스킵 버튼
//                  - _skipButtonText : 로컬라이징 대상 버튼 텍스트
// [의존 관계]      - UIBase / UIManager / InGameController
// [배치]           UIManager 로 여는 System UI. 키 = 타입 이름(UIRunClearSkip).
// =================================================================

using System;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public sealed class UIRunClearSkip : UIBase
{
    [Header("스킵 UI")]
    [Tooltip("런 클리어 루프를 종료하는 화면 버튼")]
    [SerializeField] private Button _skipButton;

    [Tooltip("스킵 버튼 로컬라이징 텍스트")]
    [SerializeField] private TMP_Text _skipButtonText;

    private bool _skipRequested;
    private bool _inputEnabled;

    public override bool CloseOnEscape => true;

    public event Action OnSkipRequested;

    protected override void Init()
    {
        Debug.Assert(_skipButton != null, "UIRunClearSkip 프리팹에 스킵 버튼이 필요합니다.", this);
        Debug.Assert(_skipButtonText != null, "UIRunClearSkip 프리팹에 스킵 버튼 텍스트가 필요합니다.", this);
        if (_skipButton != null)
            _skipButton.onClick.AddListener(RequestSkip);
    }

    protected override void Setup()
    {
        _skipRequested = false;
        SetInputEnabled(false);
    }

    /// <summary>흰 전환 중에는 입력을 막고 패럴랙스 루프가 시작될 때만 활성화한다.</summary>
    public void SetInputEnabled(bool enabled)
    {
        _inputEnabled = enabled;
        if (_skipButton != null)
            _skipButton.interactable = enabled && !_skipRequested;
    }

    public override void OnLocalize()
    {
        base.OnLocalize();
        if (_skipButtonText != null)
            _skipButtonText.text = Localize(LocalizationKeys.GameClear.SkipLoop);
    }

    /// <summary>ESC는 UI를 직접 닫지 않고 컨트롤러의 스킵 흐름으로 전달한다.</summary>
    public override bool OnBackPressed()
    {
        RequestSkip();
        return false;
    }

    private void RequestSkip()
    {
        if (!_inputEnabled || _skipRequested) return;
        _skipRequested = true;
        _inputEnabled = false;

        if (_skipButton != null)
            _skipButton.interactable = false;

        OnSkipRequested?.Invoke();
    }

    private static string Localize(string key)
    {
        if (!LocalizationManager.HasInstance || !LocalizationManager.Instance.HasKey(key))
            return key ?? string.Empty;
        return LocalizationManager.Instance.Get(key);
    }

    private void OnDestroy()
    {
        if (_skipButton != null)
            _skipButton.onClick.RemoveListener(RequestSkip);
        OnSkipRequested = null;
    }
}
