﻿// =================================================================
// [스크립트 목적]  런 진행 중 ESC/백버튼으로 여는 일시정지 메뉴.
//                 타이틀 복귀 / 계속하기(닫기) / 옵션 / 도감 열람을 제공한다.
//                 (패배 화면 UIGameOverPopup 과 같은 "UI는 통지, 컨트롤러가 흐름 처리" 패턴)
// [주요 변수]      - _titleButton   : 타이틀 복귀 (즉시 OnTitleRequested)
//                  - _continueButton: 계속하기 (즉시 닫기)
//                  - _collectionButton: 전체 카드 도감 열람 (ESC 메뉴는 유지)
// [의존 관계]      - UIBase / UIManager
//                  - InGameController 가 OnTitleRequested 를 구독해 흐름 처리.
// [배치]           Addressable UI 프리팹. 키 = "UIWindowEscMenu". Layer = System (옵션과 동급).
// [설계 노트]      - 닫기(계속하기)는 허용 — OnBackPressed=true 라 ESC 로도 닫힌다.
//                  - 타이틀은 버튼 클릭 즉시 실행한다.
// =================================================================

using System;
using Cysharp.Threading.Tasks;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// 런 일시정지 메뉴. 선택 결과는 OnTitleRequested 로 통지하고,
/// 실제 런 정리·씬 전환은 컨트롤러(InGameController)가 처리한다.
/// </summary>
public sealed class UISystemEscMenu : UIBase
{
    [Header("텍스트")]
    [SerializeField] private TMP_Text _titleText;
    [SerializeField] private TMP_Text _continueButtonText;
    [SerializeField] private TMP_Text _titleButtonText;
    [SerializeField] private TMP_Text _optionsButtonText;
    [SerializeField] private TMP_Text _collectionButtonText;

    [Header("버튼")]
    [Tooltip("타이틀 복귀. 런 종료 후 타이틀 씬으로")]
    [SerializeField] private Button _titleButton;

    [Tooltip("계속하기 — 메뉴를 닫고 게임으로 복귀")]
    [SerializeField] private Button _continueButton;

    [Tooltip("설정 — ESC 메뉴 위에 UIOptions 를 연다 (메뉴는 유지)")]
    [SerializeField] private Button _optionsButton;

    [Tooltip("도감 — ESC 메뉴 위에 읽기 전용 전체 카드 도감을 연다 (메뉴는 유지)")]
    [SerializeField] private Button _collectionButton;

    /// <summary>타이틀 복귀 요청.</summary>
    public event Action OnTitleRequested;

    /// <summary>계속하기 요청.</summary>
    public event Action OnContinueRequested;

    /// <summary>ESC 메뉴 전용 도감 열기 요청.</summary>
    public event Action OnCollectionRequested;

    protected override void Init()
    {
        if (_titleButton != null) _titleButton.onClick.AddListener(HandleTitleClicked);
        if (_continueButton != null) _continueButton.onClick.AddListener(HandleContinueClicked);
        if (_optionsButton != null) _optionsButton.onClick.AddListener(HandleOptionsClicked);
        if (_collectionButton != null) _collectionButton.onClick.AddListener(HandleCollectionClicked);
    }

    /// <summary>계속하기와 동일하게 ESC 로 닫기를 허용한다.</summary>
    public override bool OnBackPressed() => true;

    public override void OnLocalize()
    {
        base.OnLocalize();
        if (_titleText != null) _titleText.text = Localize(LocalizationKeys.EscMenu.Title);
        if (_continueButtonText != null) _continueButtonText.text = Localize(LocalizationKeys.EscMenu.Continue);
        if (_titleButtonText != null) _titleButtonText.text = Localize(LocalizationKeys.EscMenu.TitleScreen);
        if (_optionsButtonText != null) _optionsButtonText.text = Localize(LocalizationKeys.EscMenu.Options);
        if (_collectionButtonText != null) _collectionButtonText.text = Localize(LocalizationKeys.EscMenu.Collection);
    }

    private void HandleContinueClicked()
    {
        OnContinueRequested?.Invoke();
    }

    /// <summary>설정 버튼 — ESC 메뉴는 닫지 않고 UIOptions 를 위에 띄운다.</summary>
    private void HandleOptionsClicked()
    {
        OpenOptionsAsync().Forget();
    }

    private async UniTaskVoid OpenOptionsAsync()
    {
        if (!UIManager.HasInstance) return;
        // UIOptions 는 Popup 레이어라 팝업 스택에 쌓이고, ESC/닫기로 닫으면 이 메뉴가 남는다.
        await UIManager.Instance.OpenAsync<UIOptions>(this.GetCancellationTokenOnDestroy());
    }

    /// <summary>ESC 메뉴 출처의 읽기 전용 전체 카드 도감 열기를 요청한다.</summary>
    private void HandleCollectionClicked()
    {
        OnCollectionRequested?.Invoke();
    }

    private void HandleTitleClicked()
    {
        OnTitleRequested?.Invoke();
        CloseSelf();
    }

    private void CloseSelf()
    {
        if (UIManager.HasInstance) UIManager.Instance.Close(this);
    }

    private static string Localize(string key)
    {
        return LocalizationManager.HasInstance
            ? LocalizationManager.Instance.Get(key)
            : key;
    }

    private void OnDestroy()
    {
        if (_titleButton != null) _titleButton.onClick.RemoveListener(HandleTitleClicked);
        if (_continueButton != null) _continueButton.onClick.RemoveListener(HandleContinueClicked);
        if (_optionsButton != null) _optionsButton.onClick.RemoveListener(HandleOptionsClicked);
        if (_collectionButton != null) _collectionButton.onClick.RemoveListener(HandleCollectionClicked);
        OnTitleRequested = null;
        OnContinueRequested = null;
        OnCollectionRequested = null;
    }
}
