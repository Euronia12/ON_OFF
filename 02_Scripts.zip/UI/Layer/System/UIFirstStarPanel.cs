// =================================================================
// [스크립트 목적]  최초 자동 튜토리얼 진입에서 시작 입력과 캐릭터 횡단 연출을 처리한다.
// [주요 변수]      - _startInputRoot : 아무 키/화면 클릭을 기다리는 시작 화면
//                  - UIManager.FadeGroup : 워크인 연출과 Stage Notice 사이의 전역 검은 화면
// [의존 관계]      - UIBase / UIManager / UIPrivacyConsentPopup / FirstLaunchStore
//                  - FirstLaunchWalkSequence / SettingsManager
// [배치]           Addressable UI 프리팹. 키 = "UIFirstStarPanel", Layer = System.
// [비고]           시작 입력 후 개인정보 동의 팝업의 확인을 받아야 게임 시작을 확정한다.
//                  확인 전까지 실제 저장값과 Analytics는 false를 유지한다.
//                  시작 전에 종료하면 저장되지 않고 다음 실행에서 다시 묻는다.
// =================================================================

using System;
using System.Threading;
using Cysharp.Threading.Tasks;
using DG.Tweening;
using TMPro;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.UI;

public sealed class UIFirstStarPanel : UIBase
{
    [Header("시작 UI")]
    [Tooltip("최초 튜토리얼 시작 입력을 기다리는 동안 표시할 화면")]
    [SerializeField] private GameObject _startInputRoot;

    [Tooltip("현재 언어의 시작 문구를 표시할 TMP 텍스트")]
    [SerializeField] private TMP_Text _startButtonText;

    [Tooltip("워크인 연출이 시작되면 숨길 최초 패널 배경")]
    [SerializeField] private Graphic _startBackground;

    [Tooltip("시작 문구가 최소 알파까지 어두워지는 데 걸리는 시간(초)")]
    [Min(0.05f)]
    [SerializeField] private float _startTextBlinkDuration = 0.55f;

    [Tooltip("시작 문구 깜빡임에서 가장 어두워졌을 때의 알파")]
    [Range(0f, 1f)]
    [SerializeField] private float _startTextBlinkMinAlpha = 0.2f;

    [Header("워크인 입력·페이드")]
    [Tooltip("캐릭터 이동 중 클릭 스킵을 받는 투명 전체 화면 버튼")]
    [SerializeField] private Button _skipButton;

    [Tooltip("생성할 워크인 연출 Addressable 키")]
    [SerializeField] private string _walkSequenceKey = "FirstLaunchWalkSequence";

    [Tooltip("시작 입력 후 최초 암전 시간(초)")]
    [Min(0f)]
    [SerializeField] private float _initialFadeOutDuration = 0.5f;

    [Tooltip("캐릭터가 좌측 화면 밖에서 우측 화면 밖까지 일정한 속도로 이동하는 전체 시간(초)")]
    [Min(0f)]
    [SerializeField] private float _walkDuration = 4f;

    [Tooltip("이동 중 화면 클릭 시 현재 위치부터 우측 화면 밖까지 이동·암전하는 시간(초)")]
    [Min(0f)]
    [SerializeField] private float _skipFadeOutDuration = 0.3f;

    [Tooltip("전체 이동거리 0~1 중 화면 페이드인이 완료되는 지점")]
    [Range(0f, 1f)]
    [SerializeField] private float _fadeInCompleteRatio = 0.2f;

    [Tooltip("전체 이동거리 0~1 중 화면 페이드아웃이 시작되는 지점")]
    [Range(0f, 1f)]
    [SerializeField] private float _fadeOutStartRatio = 0.8f;

    private Tween _startTextBlinkTween;
    private UniTaskCompletionSource<bool> _startInputSource;
    private CancellationTokenSource _closeCts;
    private FirstLaunchWalkSequence _walkSequence;
    private bool _startRequested;
    private bool _skipRequested;
    private bool _isWalking;
    private bool _controlsSharedFade;

    public override bool CloseOnEscape => true;

    protected override void Init()
    {
        Debug.Assert(_startInputRoot != null, "UIFirstStarPanel 프리팹에 시작 화면이 필요합니다.", this);
        Debug.Assert(_startButtonText != null, "UIFirstStarPanel 프리팹에 시작 버튼 텍스트가 필요합니다.", this);
        Debug.Assert(_skipButton != null, "UIFirstStarPanel 프리팹에 스킵 입력 버튼이 필요합니다.", this);
        if (_skipButton != null)
            _skipButton.onClick.AddListener(HandleSkipClicked);
    }

    protected override void Setup()
    {
        DisposeCloseCts();
        _closeCts = new CancellationTokenSource();
        _startInputSource = new UniTaskCompletionSource<bool>();
        _startRequested = false;
        _skipRequested = false;
        _isWalking = false;
        _controlsSharedFade = false;
        ReleaseWalkSequence();

        if (_startInputRoot != null)
            _startInputRoot.SetActive(true);

        if (_startBackground != null)
            _startBackground.enabled = true;

        if (_skipButton != null)
        {
            _skipButton.interactable = false;
            _skipButton.gameObject.SetActive(false);
        }

        StartTextBlink();
    }

    public override void OnLocalize()
    {
        base.OnLocalize();
        if (_startButtonText != null)
        {
            LocalizedFontUtility.ApplyCurrentFont(_startButtonText);
            _startButtonText.text = LocalizationManager.HasInstance
                ? LocalizationManager.Instance.Get(LocalizationKeys.Title.FirstStarStartButton)
                : LocalizationKeys.Title.FirstStarStartButton;
        }

    }

    /// <summary>
    /// 아무 키 또는 화면 클릭부터 워크인 최종 암전까지 기다린다.
    /// 정상 완료면 true, 패널 외부 닫힘이면 false를 반환한다.
    /// </summary>
    public async UniTask<bool> WaitForStartAsync(CancellationToken token = default)
    {
        if (_startInputSource == null || _closeCts == null)
            return false;

        using var linkedCts = CancellationTokenSource.CreateLinkedTokenSource(token, _closeCts.Token);
        try
        {
            bool started = await _startInputSource.Task.AttachExternalCancellation(linkedCts.Token);
            if (!started)
                return false;

            return await PlayWalkTransitionAsync(linkedCts.Token);
        }
        catch (OperationCanceledException) when (!token.IsCancellationRequested)
        {
            return false;
        }
        catch (OperationCanceledException)
        {
            CloseSelf();
            throw;
        }
    }

    /// <summary>
    /// Stage Notice가 자체 검은 배경을 준비한 뒤 패널과 월드 연출을 해제한다.
    /// </summary>
    public void ReleaseForStageNotice()
    {
        ReleaseSharedFade();
        ReleaseWalkSequence();
        CloseSelf();
    }

    /// <summary>강제 선택 UI이므로 ESC를 소비하되 닫거나 진행하지 않는다.</summary>
    public override bool OnBackPressed() => false;

    public override void OnClose()
    {
        _isWalking = false;
        _skipRequested = false;
        _closeCts?.Cancel();
        _startInputSource?.TrySetResult(false);
        StopTextBlink();
        ReleaseSharedFade();
        ReleaseWalkSequence();
        base.OnClose();
    }

    /// <summary>시작 문구를 알파 요요 루프로 깜빡인다. 시작 입력 화면이 떠 있는 동안만 유지한다.</summary>
    private void StartTextBlink()
    {
        StopTextBlink();
        if (_startButtonText == null) return;

        _startButtonText.alpha = 1f;
        _startTextBlinkTween = _startButtonText.DOFade(_startTextBlinkMinAlpha, _startTextBlinkDuration)
            .SetLoops(-1, LoopType.Yoyo)
            .SetUpdate(true);
    }

    private void StopTextBlink()
    {
        _startTextBlinkTween?.Kill();
        _startTextBlinkTween = null;
        if (_startButtonText != null)
            _startButtonText.alpha = 1f;
    }

    private void Update()
    {
        if (_startRequested || !IsOpen || !HasStartInputThisFrame())
            return;

        HandleStartInputAsync().Forget();
    }

    /// <summary>
    /// 기존 아무 키/화면 클릭 시작 입력을 유지한다.
    /// </summary>
    private bool HasStartInputThisFrame()
    {
        Keyboard keyboard = Keyboard.current;
        bool keyboardPressed = keyboard != null
                               && keyboard.anyKey.wasPressedThisFrame
                               && !keyboard.escapeKey.wasPressedThisFrame;
        Pointer pointer = Pointer.current;
        bool pointerPressed = pointer != null && pointer.press.wasPressedThisFrame;
        return keyboardPressed || pointerPressed;
    }

    private async UniTaskVoid HandleStartInputAsync()
    {
        if (_startRequested || !IsOpen) return;

        _startRequested = true;
        StopTextBlink();

        try
        {
            UIPrivacyConsentPopup popup = UIManager.HasInstance
                ? await UIManager.Instance.OpenAsync<UIPrivacyConsentPopup>(_closeCts.Token)
                : null;
            if (popup == null)
            {
                Debug.LogError("[UIFirstStarPanel] 개인정보 수집 동의 팝업을 열지 못했습니다.", this);
                ResetStartRequest();
                return;
            }

            bool granted = await popup.ShowAsync(ReadInitialConsent(), _closeCts.Token);
            if (!await SavePrivacyConsentAsync(granted))
            {
                ResetStartRequest();
                return;
            }
        }
        catch (OperationCanceledException)
        {
            return;
        }

        FirstLaunchStore.MarkTutorialEntered();
        _startInputSource?.TrySetResult(true);
    }

    private void ResetStartRequest()
    {
        _startRequested = false;
        StartTextBlink();
    }

    /// <summary>
    /// 토글 초기값. 아직 선택을 확정하지 않은 신규 사용자에게만 표시상 true를 제안한다.
    /// 실제 저장값과 Analytics 활성 상태는 시작 입력 전까지 false로 유지한다.
    /// SettingsManager가 없으면(테스트 씬 등) 표시상 기본값만 켜 두고 실제 저장은 하지 않는다.
    /// </summary>
    private static bool ReadInitialConsent()
    {
        if (!SettingsManager.HasInstance) return true;

        GameSettings settings = SettingsManager.Instance.Current;
        if (settings == null) return true;

        return !settings.HasAnalyticsConsentBeenAsked || settings.AnalyticsConsent;
    }

    /// <summary>
    /// 토글 값을 설정 데이터에 확정 저장한다.
    /// 토글 미연결·SettingsManager 부재처럼 값을 신뢰할 수 없는 상황에서는 "비동의"로 처리한다 —
    /// 동의 기록 없이 수집을 시작하는 쪽이 훨씬 위험하기 때문이다.
    /// </summary>
    private async UniTask<bool> SavePrivacyConsentAsync(bool granted)
    {
        if (!SettingsManager.HasInstance)
        {
            Debug.LogError("[UIFirstStarPanel] SettingsManager가 없어 개인정보 수집 동의를 저장하지 못했습니다.", this);
            return false;
        }

        try
        {
            await SettingsManager.Instance.SetAnalyticsConsentAndSaveAsync(granted, _closeCts.Token);
            return true;
        }
        catch (OperationCanceledException)
        {
            throw;
        }
        catch (Exception e)
        {
            Debug.LogError($"[UIFirstStarPanel] 개인정보 수집 동의 저장 실패: {e.Message}", this);
            return false;
        }
    }

    private void HandleSkipClicked()
    {
        if (!_isWalking || _skipRequested) return;

        _skipRequested = true;
        if (_skipButton != null)
            _skipButton.interactable = false;
    }

    private async UniTask<bool> PlayWalkTransitionAsync(CancellationToken token)
    {
        try
        {
            if (!TryBeginSharedFadeControl())
            {
                Debug.LogError("[UIFirstStarPanel] UIManager 전역 Fade를 사용할 수 없어 워크인 연출을 생략합니다.");
                return true;
            }

            await FadeScreenAsync(1f, _initialFadeOutDuration, token);

            StopTextBlink();
            if (_startInputRoot != null)
                _startInputRoot.SetActive(false);
            if (_startBackground != null)
                _startBackground.enabled = false;

            if (_skipButton != null)
            {
                _skipButton.gameObject.SetActive(true);
                _skipButton.interactable = true;
            }

            if (!await CreateWalkSequenceAsync(token))
            {
                SetFadeAlpha(1f);
                return true;
            }

            Camera camera = CameraManager.HasInstance ? CameraManager.Instance.MainCamera : null;
            if (camera == null)
                camera = Camera.main;
            _walkSequence.Prepare(camera);
            _walkSequence.BeginWalk();
            _isWalking = true;

            float fadeInRatio = Mathf.Clamp01(_fadeInCompleteRatio);
            float fadeOutRatio = Mathf.Clamp(_fadeOutStartRatio, fadeInRatio, 1f);

            if (!await PlayWalkAsync(fadeInRatio, fadeOutRatio, token))
            {
                await PlaySkipAsync(token);
                return true;
            }

            _walkSequence.ForceComplete();
            _isWalking = false;
            SetFadeAlpha(1f);
            return true;
        }
        catch (OperationCanceledException)
        {
            throw;
        }
        catch (Exception e)
        {
            Debug.LogError($"[UIFirstStarPanel] 최초 튜토리얼 워크인 연출 실패 — Stage Notice로 폴백합니다: {e}");
            _isWalking = false;
            ReleaseWalkSequence();
            SetFadeAlpha(1f);
            return true;
        }
    }

    private async UniTask<bool> CreateWalkSequenceAsync(CancellationToken token)
    {
        if (!ResourceManager.HasInstance || string.IsNullOrWhiteSpace(_walkSequenceKey))
        {
            Debug.LogError("[UIFirstStarPanel] 워크인 연출을 생성할 ResourceManager/키가 없습니다.");
            return false;
        }

        _walkSequence = await ResourceManager.Instance
            .InstantiateAsync<FirstLaunchWalkSequence>(_walkSequenceKey, token: token);
        if (_walkSequence == null)
        {
            Debug.LogError($"[UIFirstStarPanel] 워크인 연출 프리팹 로드 실패: {_walkSequenceKey}");
            return false;
        }

        return true;
    }

    private async UniTask<bool> PlayWalkAsync(
        float fadeInRatio,
        float fadeOutRatio,
        CancellationToken token)
    {
        if (_walkSequence == null)
            return true;

        float duration = Mathf.Max(0f, _walkDuration);
        _walkSequence.SetNormalizedProgress(0f);
        SetFadeAlpha(1f);

        if (duration <= 0f)
        {
            if (_skipRequested)
                return false;

            _walkSequence.ForceComplete();
            SetFadeAlpha(1f);
            return true;
        }

        float elapsed = 0f;
        while (elapsed < duration)
        {
            token.ThrowIfCancellationRequested();
            if (_skipRequested)
                return false;

            elapsed += Time.unscaledDeltaTime;
            float progress = Mathf.Clamp01(elapsed / duration);
            _walkSequence.SetNormalizedProgress(progress);
            SetFadeAlpha(CalculateWalkFadeAlpha(progress, fadeInRatio, fadeOutRatio));
            await UniTask.Yield(PlayerLoopTiming.Update, token);
        }

        _walkSequence.SetNormalizedProgress(1f);
        SetFadeAlpha(1f);
        return true;
    }

    private static float CalculateWalkFadeAlpha(
        float progress,
        float fadeInRatio,
        float fadeOutRatio)
    {
        if (progress <= fadeInRatio)
            return fadeInRatio <= 0f ? 0f : 1f - progress / fadeInRatio;

        if (progress < fadeOutRatio)
            return 0f;

        float fadeOutDistance = 1f - fadeOutRatio;
        return fadeOutDistance <= 0f
            ? 1f
            : (progress - fadeOutRatio) / fadeOutDistance;
    }

    private async UniTask PlaySkipAsync(CancellationToken token)
    {
        if (_walkSequence == null)
        {
            SetFadeAlpha(1f);
            _isWalking = false;
            return;
        }

        float fromProgress = _walkSequence.Progress;
        float fromFadeAlpha = GetFadeAlpha();
        float duration = Mathf.Max(0f, _skipFadeOutDuration);

        if (duration <= 0f)
        {
            _walkSequence.ForceComplete();
            SetFadeAlpha(1f);
            _isWalking = false;
            return;
        }

        float elapsed = 0f;
        while (elapsed < duration)
        {
            token.ThrowIfCancellationRequested();
            elapsed += Time.unscaledDeltaTime;
            float progress = Mathf.Clamp01(elapsed / duration);
            _walkSequence.SetNormalizedProgress(Mathf.Lerp(fromProgress, 1f, progress));
            SetFadeAlpha(Mathf.Lerp(fromFadeAlpha, 1f, progress));

            if (progress < 1f)
                await UniTask.Yield(PlayerLoopTiming.Update, token);
        }

        _walkSequence.ForceComplete();
        SetFadeAlpha(1f);
        _isWalking = false;
    }

    private async UniTask FadeScreenAsync(float targetAlpha, float duration, CancellationToken token)
    {
        float safeDuration = Mathf.Max(0f, duration);
        float fromAlpha = GetFadeAlpha();
        if (safeDuration <= 0f)
        {
            SetFadeAlpha(targetAlpha);
            return;
        }

        float elapsed = 0f;
        while (elapsed < safeDuration)
        {
            token.ThrowIfCancellationRequested();
            elapsed += Time.unscaledDeltaTime;
            SetFadeAlpha(Mathf.Lerp(fromAlpha, targetAlpha, Mathf.Clamp01(elapsed / safeDuration)));
            await UniTask.Yield(PlayerLoopTiming.Update, token);
        }

        SetFadeAlpha(targetAlpha);
    }

    private void SetFadeAlpha(float alpha)
    {
        CanvasGroup fadeGroup = GetSharedFadeGroup();
        if (fadeGroup == null) return;

        fadeGroup.alpha = Mathf.Clamp01(alpha);
        fadeGroup.interactable = false;
        // 입력은 아래 System 레이어의 시작/스킵 UI가 받으므로 전역 Fade는 시각 처리만 담당한다.
        fadeGroup.blocksRaycasts = false;
    }

    private bool TryBeginSharedFadeControl()
    {
        if (_controlsSharedFade)
            return GetSharedFadeGroup() != null;

        if (!UIManager.HasInstance || UIManager.Instance.FadeGroup == null)
            return false;

        // InGameController가 씬 진입 페이드 완료 후 순차 호출하므로 이 시점부터 전역 Fade를 넘겨받는다.
        _controlsSharedFade = true;
        SetFadeAlpha(0f);
        return true;
    }

    private float GetFadeAlpha()
    {
        CanvasGroup fadeGroup = GetSharedFadeGroup();
        return fadeGroup != null ? fadeGroup.alpha : 1f;
    }

    private static CanvasGroup GetSharedFadeGroup()
        => UIManager.HasInstance ? UIManager.Instance.FadeGroup : null;

    private void ReleaseSharedFade()
    {
        if (!_controlsSharedFade) return;

        CanvasGroup fadeGroup = GetSharedFadeGroup();
        if (fadeGroup != null)
        {
            fadeGroup.alpha = 0f;
            fadeGroup.interactable = false;
            fadeGroup.blocksRaycasts = false;
        }

        _controlsSharedFade = false;
    }

    private void ReleaseWalkSequence()
    {
        if (_walkSequence == null) return;

        GameObject instance = _walkSequence.gameObject;
        _walkSequence = null;
        if (ResourceManager.HasInstance)
            ResourceManager.Instance.ReleaseInstance(instance);
        else
            Destroy(instance);
    }

    private void CloseSelf()
    {
        if (UIManager.HasInstance && IsOpen)
            UIManager.Instance.Close(this);
    }

    private void DisposeCloseCts()
    {
        if (_closeCts == null) return;

        _closeCts.Dispose();
        _closeCts = null;
    }

    private void OnDestroy()
    {
        if (_skipButton != null)
            _skipButton.onClick.RemoveListener(HandleSkipClicked);

        _closeCts?.Cancel();
        DisposeCloseCts();
        _startInputSource?.TrySetResult(false);
        StopTextBlink();
        ReleaseSharedFade();
        ReleaseWalkSequence();
    }
}
