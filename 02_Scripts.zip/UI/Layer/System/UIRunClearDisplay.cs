// =================================================================
// [스크립트 목적]  마지막 보스 격파 후 클리어 이미지를 순서대로 누적 표시한다.
// [주요 변수]      - _frames : 이미지와 표시 시간을 묶은 컷씬 프레임
// [의존 관계]      - UIBase / UIManager / UniTask
// [배치]           UIManager 로 여는 System UI. 키 = 타입 이름(UIRunClearDisplay).
// =================================================================

using System;
using System.Threading;
using Cysharp.Threading.Tasks;
using UnityEngine;
using UnityEngine.UI;

/// <summary>런 클리어 이미지 컷씬만 담당하는 화면 고정 UI.</summary>
public sealed class UIRunClearDisplay : UIBase
{
    [Serializable]
    private sealed class Frame
    {
        [Tooltip("이 프레임에 표시할 이미지")]
        [SerializeField] private Image _image;

        [Tooltip("다음 프레임으로 넘어가기 전 표시 시간(초)")]
        [Min(0f)]
        [SerializeField] private float _duration = 1f;

        public Image Image => _image;
        public float Duration => _duration;
    }

    [Header("이미지 컷씬")]
    [Tooltip("재생 순서대로 등록할 이미지 컷씬 프레임")]
    [SerializeField] private Frame[] _frames;

    public override bool CloseOnEscape => true;

    protected override void Setup()
    {
        SetImagesVisible(false);
    }

    /// <summary>등록된 프레임을 이전 이미지 위에 한 장씩 추가하며 1회 재생한다.</summary>
    public async UniTask PlayAsync(CancellationToken token)
    {
        if (_frames == null) return;

        for (int i = 0; i < _frames.Length; i++)
        {
            token.ThrowIfCancellationRequested();

            Frame frame = _frames[i];
            Image image = frame?.Image;
            if (image == null) continue;

            if (image.sprite == null)
            {
                Debug.LogWarning($"[UIRunClearDisplay] 클리어 이미지가 비어 있어 건너뜁니다: index={i}");
                continue;
            }

            image.gameObject.SetActive(true);
            if (frame.Duration <= 0f) continue;

            await UniTask.Delay(
                TimeSpan.FromSeconds(frame.Duration),
                DelayType.UnscaledDeltaTime,
                cancellationToken: token);
        }
    }

    /// <summary>이미지 컷씬 구간은 ESC를 소비하되 재생을 건너뛰지 않는다.</summary>
    public override bool OnBackPressed() => false;

    private void SetImagesVisible(bool visible)
    {
        if (_frames == null) return;

        for (int i = 0; i < _frames.Length; i++)
        {
            Image image = _frames[i]?.Image;
            if (image != null)
                image.gameObject.SetActive(visible);
        }
    }
}
