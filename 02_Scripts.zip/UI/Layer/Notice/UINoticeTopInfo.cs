// =================================================================
// [스크립트 목적]  런 진행 중 화면 상단에 상시 표시되는 정보 바.
//                 현재 체력 / 현재 보유 골드 / 현재 스테이지 / 지도·전체 덱·설정 버튼을 포함한다.
// [주요 변수]      - _hpText       : 현재/최대 체력 표시
//                  - _goldText     : 현재 보유 골드 표시
//                  - _stageText    : 현재 스테이지 표시
//                  - _settingsButton : 클릭 시 UISystemEscMenu 토글
//                  - _mapButton    : 지도 미리보기(읽기 전용) 토글 — 슬더스식 상시 열람
//                  - _deckButton   : 전체 덱 열람(읽기 전용) 토글
// [의존 관계]      - UIBase / UIManager
//                  - EventManager(OnPlayerHpChanged / OnGoldChanged / OnMapPresented 구독) — 실시간 갱신
//                  - InGameController(CurrentRun 으로 체력·골드·층 조회, ToggleEscMenu 로 설정 열기)
// [배치]           Addressable UI 프리팹. 키 = 타입명("UINoticeTopInfo"). Layer는 프리팹 Inspector에서 설정.
// [설계 노트]      - 골드/층은 RunContext 가 보유하지만 "변동 통지"는 EventManager 로 흘러온다
//                    (HUD 는 런마다 생성·폐기되는 RunContext 를 직접 참조하지 않는다).
//                  - 열릴 때 현재 값으로 1회 동기화한 뒤, 이후 이벤트로만 갱신한다.
//                  - 체력은 소유자가 둘(전투 밖 = RunContext / 전투 중 = PlayerActor)이지만,
//                    양쪽 모두 OnPlayerHpChanged 하나로 합류하므로 여기서는 이벤트만 구독하면 된다.
// =================================================================

using System;
using System.Collections;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// 런 상단 정보 바(골드·스테이지·설정). 값은 EventManager 통지로 실시간 갱신하고,
/// 설정 버튼은 InGameController 에 ESC 메뉴 토글을 위임한다.
/// </summary>
public sealed class UINoticeTopInfo : UIBase
{
    [Header("캐싱된 UI")]
    [Tooltip("현재/최대 체력을 표시할 텍스트")]
    [SerializeField] private TMP_Text _hpText;

    [Tooltip("현재 보유 골드를 표시할 텍스트")]
    [SerializeField] private TMP_Text _goldText;

    [Tooltip("현재 스테이지를 표시할 텍스트")]
    [SerializeField] private TMP_Text _stageText;

    [Tooltip("클릭 시 설정(UISystemEscMenu)을 여는 버튼")]
    [SerializeField] private Button _settingsButton;

    [Tooltip("클릭 시 지도 미리보기(읽기 전용)를 토글하는 버튼")]
    [SerializeField] private Button _mapButton;

    [Tooltip("클릭 시 전체 덱 열람(읽기 전용)을 토글하는 버튼")]
    [SerializeField] private Button _deckButton;

    [Tooltip("튜토리얼의 지정된 실습 안내를 다시 여는 부엉이 버튼. 위치는 마지막 안내의 부엉이 위치를 따른다.")]
    [SerializeField] private Button _tutorialReplayButton;

    [Header("표시 형식")]
    [Tooltip("체력 표시 형식. {0} = 현재 체력, {1} = 최대 체력")]
    [SerializeField] private string _hpFormat = "{0}/{1}";

    [Tooltip("골드 표시 형식. {0} = 보유 골드")]
    [SerializeField] private string _goldFormat = "{0}";

    [Header("체력 색상")]
    [Tooltip("체력이 가득 찼을 때(현재 == 최대) 색상")]
    [SerializeField] private Color _hpFullColor = Color.white;

    [Tooltip("체력이 막 줄어들기 시작했을 때(비율 100% 직전) 현재 체력 색상. 밝은 붉은 계열")]
    [SerializeField] private Color _hpHighColor = new Color(1f, 0.45f, 0.38f);       // #FF7361

    [Tooltip("체력이 위험 비율 이하일 때 현재 체력 색상. 가장 어두운 붉은 계열")]
    [SerializeField] private Color _hpLowColor = new Color(0.55f, 0.07f, 0.05f);     // #8C120D

    [Tooltip("가장 어두운 붉은색에 도달하는 체력 비율. 이 비율 이하는 전부 최저 색상")]
    [Range(0f, 1f)]
    [SerializeField] private float _hpLowThreshold = 0.25f;

    [Header("최대 체력 감소 연출")]
    [Tooltip("최대 체력이 줄어드는 동안 최대 체력 텍스트에 잠시 입히는 색상")]
    [SerializeField] private Color _maxHpDecreaseColor = new Color(0.9f, 0.15f, 0.1f); // #E6261A

    [Tooltip("최대 체력 감소 연출의 총 소요 시간(초). 이 시간에 걸쳐 1씩 나눠 감소한다")]
    [Min(0f)]
    [SerializeField] private float _maxHpDecreaseDuration = 0.5f;

    private IDisposableEvent _hpSub;
    private IDisposableEvent _goldSub;
    private IDisposableEvent _mapSub;
    private BattleManager _battle;
    private TutorialDirector _tutorialDirector;

    // 화면에 현재 표시 중인 값. 최대 체력 감소는 연출 때문에 실제 값보다 늦게 따라간다.
    private int _displayedCurrentHp;
    private int _displayedMaxHp;
    private Coroutine _maxHpDecreaseRoutine;
    private bool _isMaxHpDecreasing;
    private bool _isBattleInputLocked;
    private bool _isMapPeekOpen;

    // 색상 → 리치텍스트 hex 캐싱 (매 갱신마다 ToHtmlStringRGB 호출을 피한다).
    private string _hpFullHex;
    private string _maxHpDecreaseHex;

    protected override void Init()
    {
        // 리치텍스트 hex 캐싱 — 고정 색상은 1회만 변환한다(비율 색상은 매번 보간되므로 그때 변환).
        _hpFullHex = ColorUtility.ToHtmlStringRGB(_hpFullColor);
        _maxHpDecreaseHex = ColorUtility.ToHtmlStringRGB(_maxHpDecreaseColor);

        if (_settingsButton != null)
            _settingsButton.onClick.AddListener(HandleSettingsClicked);
        if (_mapButton != null)
            _mapButton.onClick.AddListener(HandleMapClicked);
        if (_deckButton != null)
            _deckButton.onClick.AddListener(HandleDeckClicked);
        if (_tutorialReplayButton != null)
            _tutorialReplayButton.onClick.AddListener(HandleTutorialReplayClicked);
    }

    protected override void Setup()
    {
        // 체력·골드·맵(층) 변동 구독 — 열려 있는 동안 실시간 갱신.
        _hpSub?.Dispose();
        _goldSub?.Dispose();
        _mapSub?.Dispose();
        if (EventManager.HasInstance)
        {
            _hpSub = EventManager.Instance.Subscribe<OnPlayerHpChanged>(OnPlayerHpChangedHandler);
            _goldSub = EventManager.Instance.Subscribe<OnGoldChanged>(OnGoldChangedHandler);
            _mapSub = EventManager.Instance.Subscribe<OnMapPresented>(OnMapPresentedHandler);
        }

        BindBattleInputLock();
        BindTutorialReplay();

        // 현재 런 값으로 1회 동기화.
        RefreshHp();
        RefreshGold();
        RefreshStage();
        SyncMapPeekState();
    }

    public override void OnClose()
    {
        StopMaxHpDecrease();
        _hpSub?.Dispose();
        _hpSub = null;
        _goldSub?.Dispose();
        _goldSub = null;
        _mapSub?.Dispose();
        _mapSub = null;
        UnbindBattleInputLock();
        UnbindTutorialReplay();
        base.OnClose();
    }

    public override void OnLocalize()
    {
        base.OnLocalize();
        RefreshStage();
    }

    private void OnPlayerHpChangedHandler(OnPlayerHpChanged evt)
    {
        ApplyHp(evt.Current, evt.Max);
    }

    private void OnGoldChangedHandler(OnGoldChanged evt)
    {
        if (_goldText != null)
            _goldText.text = string.Format(_goldFormat, evt.Current);
    }

    private void OnMapPresentedHandler(OnMapPresented evt)
    {
        RefreshStage();
        RefreshTutorialReplayButton();
    }

    /// <summary>
    /// 현재 체력으로 1회 동기화 (열릴 때). 전투 중이라면 RunContext 값은 전투 시작 시점의 값이라
    /// 실시간 HP 와 어긋나므로, 전투가 진행 중일 때는 BattleController 의 값을 우선한다.
    /// HP 시스템 미사용(HasHp=false)이면 0/0 으로 표시한다.
    /// </summary>
    private void RefreshHp()
    {
        if (BattleController.HasInstance && BattleController.Instance.IsBattleRunning)
        {
            ApplyHp(BattleController.Instance.PlayerCurrentHp, BattleController.Instance.PlayerMaxHp, instant: true);
            return;
        }

        RunContext run = CurrentRun();
        if (run == null || !run.HasHp)
        {
            ApplyHp(0, 0, instant: true);
            return;
        }

        ApplyHp(run.CurrentHp, run.MaxHp, instant: true);
    }

    /// <summary>
    /// 체력 표시 갱신. 현재 체력은 즉시 반영하고, 최대 체력이 "줄어든" 경우에만
    /// _maxHpDecreaseDuration 동안 1씩 깎이는 연출을 태운다(그 외 변화는 즉시 반영).
    /// </summary>
    /// <param name="instant">true 면 연출 없이 즉시 값 동기화 (창이 열릴 때의 초기 동기화용).</param>
    private void ApplyHp(int current, int max, bool instant = false)
    {
        if (_hpText == null) return;

        _displayedCurrentHp = current;

        bool canAnimate = !instant
                          && isActiveAndEnabled
                          && _maxHpDecreaseDuration > 0f
                          && _displayedMaxHp > max;

        if (!canAnimate)
        {
            StopMaxHpDecrease();
            _displayedMaxHp = max;
            RenderHp();
            return;
        }

        // 감소 연출 중 또 감소하면 현재 표시값에서 이어서 새 목표까지 내려간다.
        StopMaxHpDecrease();
        _maxHpDecreaseRoutine = StartCoroutine(MaxHpDecreaseRoutine(max));
    }

    /// <summary>최대 체력을 목표치까지 1씩 감소시키는 연출. 감소 중에는 최대 체력 텍스트가 붉게 강조된다.</summary>
    private IEnumerator MaxHpDecreaseRoutine(int targetMax)
    {
        _isMaxHpDecreasing = true;

        int steps = _displayedMaxHp - targetMax;
        // 총 소요 시간을 감소량으로 나눠 1 감소당 간격을 정한다 (감소량과 무관하게 총 시간 고정).
        float interval = _maxHpDecreaseDuration / steps;

        while (_displayedMaxHp > targetMax)
        {
            yield return new WaitForSeconds(interval);

            _displayedMaxHp--;
            // 최대 체력이 현재 체력 아래로 내려가면 현재 체력도 함께 끌어내린다(RunContext 클램프와 동일).
            if (_displayedCurrentHp > _displayedMaxHp)
                _displayedCurrentHp = _displayedMaxHp;

            RenderHp();
        }

        _isMaxHpDecreasing = false;
        _maxHpDecreaseRoutine = null;
        RenderHp(); // 강조 색상 해제
    }

    private void StopMaxHpDecrease()
    {
        if (_maxHpDecreaseRoutine != null)
        {
            StopCoroutine(_maxHpDecreaseRoutine);
            _maxHpDecreaseRoutine = null;
        }
        _isMaxHpDecreasing = false;
    }

    /// <summary>
    /// 현재 표시값(_displayedCurrentHp / _displayedMaxHp)을 리치텍스트로 그린다.
    /// - 현재 == 최대 : 전체 흰색
    /// - 그 외        : 현재 체력만 비율에 따라 붉은 계열(비율이 낮을수록 어두움, _hpLowThreshold 이하는 최저색)
    /// - 최대 감소 중 : 최대 체력도 붉게 강조
    /// </summary>
    private void RenderHp()
    {
        if (_hpText == null) return;

        bool isFull = _displayedMaxHp > 0 && _displayedCurrentHp >= _displayedMaxHp;
        string currentHex = isFull ? _hpFullHex : ColorUtility.ToHtmlStringRGB(GetCurrentHpColor());
        string maxHex = _isMaxHpDecreasing ? _maxHpDecreaseHex : _hpFullHex;

        string currentPart = $"<color=#{currentHex}>{_displayedCurrentHp}</color>";
        string maxPart = $"<color=#{maxHex}>{_displayedMaxHp}</color>";
        _hpText.text = string.Format(_hpFormat, currentPart, maxPart);
    }

    /// <summary>
    /// 현재 체력 비율에 대응하는 색상. 비율 1(직전)에서 _hpHighColor, _hpLowThreshold 이하에서 _hpLowColor.
    /// </summary>
    private Color GetCurrentHpColor()
    {
        if (_displayedMaxHp <= 0) return _hpLowColor;

        float ratio = Mathf.Clamp01((float)_displayedCurrentHp / _displayedMaxHp);
        // 임계 비율 이하는 전부 최저 색상. 임계~1 구간을 밝은 붉은색 → 어두운 붉은색으로 보간.
        float t = _hpLowThreshold >= 1f
            ? 0f
            : Mathf.Clamp01(Mathf.InverseLerp(_hpLowThreshold, 1f, ratio));

        return Color.Lerp(_hpLowColor, _hpHighColor, t);
    }

    private void RefreshGold()
    {
        if (_goldText == null) return;
        RunContext run = CurrentRun();
        int gold = run != null ? run.Gold : 0;
        _goldText.text = string.Format(_goldFormat, gold);
    }

    private void RefreshStage()
    {
        if (_stageText == null) return;

        LocalizedFontUtility.ApplyCurrentFont(_stageText);

        // 튜토리얼은 막 대신 '튜토리얼' 문구를 표시한다(진입 Notice와 동일 규칙).
        if (TutorialDirector.IsActive)
        {
            _stageText.text = LocalizationManager.HasInstance
                ? LocalizationManager.Instance.Get(LocalizationKeys.StageNotice.TutorialTitle)
                : LocalizationKeys.StageNotice.TutorialTitle;
            return;
        }

        // 스테이지 진입 Notice와 같은 키/인자 규칙을 사용한다. {0} = 1-based 스테이지 번호.
        int stage = InGameController.HasInstance ? InGameController.Instance.CurrentStageNumber : 1;
        string format = LocalizationManager.HasInstance
            ? LocalizationManager.Instance.Get(LocalizationKeys.StageNotice.CurrentStageFormat)
            : "{0}막";
        _stageText.text = string.Format(format, stage);
    }

    private void HandleSettingsClicked()
    {
        if (IsBattleInputLocked()) return;
        if (InGameController.HasInstance)
            InGameController.Instance.ToggleEscMenu();
    }

    private void HandleMapClicked()
    {
        if (IsBattleInputLocked()) return;
        if (InGameController.HasInstance)
            InGameController.Instance.ToggleMapPeek();
    }

    private void HandleDeckClicked()
    {
        if (IsBattleInputLocked()) return;
        if (InGameController.HasInstance)
            InGameController.Instance.ToggleDeckView();
    }

    private void HandleTutorialReplayClicked()
    {
        if (IsBattleInputLocked()) return;
        if (_tutorialDirector != null)
            _tutorialDirector.ReplayLatestGuide();
    }

    private void BindTutorialReplay()
    {
        UnbindTutorialReplay();
        _tutorialDirector = TutorialDirector.Active;
        if (_tutorialDirector != null)
            _tutorialDirector.ReplayGuideStateChanged += RefreshTutorialReplayButton;
        RefreshTutorialReplayButton();
    }

    private void UnbindTutorialReplay()
    {
        if (_tutorialDirector != null)
            _tutorialDirector.ReplayGuideStateChanged -= RefreshTutorialReplayButton;
        _tutorialDirector = null;
    }

    private void RefreshTutorialReplayButton()
    {
        if (_tutorialReplayButton == null) return;

        bool isMapOpen = UIManager.HasInstance && UIManager.Instance.IsOpen<UIMap>();
        bool visible = _tutorialDirector != null
                       && _tutorialDirector.CanReplayGuide
                       && !_isMapPeekOpen
                       && !isMapOpen;
        _tutorialReplayButton.gameObject.SetActive(visible);
        if (!visible) return;

        if (_tutorialDirector.TryGetReplayButtonWorldPosition(out Vector3 worldPosition)
            && _tutorialReplayButton.transform is RectTransform buttonRect)
        {
            buttonRect.position = worldPosition;
        }

        _tutorialReplayButton.interactable = !_isBattleInputLocked;
    }

    /// <summary>상단 정보 바에서 연 지도 미리보기의 열림 상태를 반영한다.</summary>
    public void SetMapPeekOpen(bool isOpen)
    {
        _isMapPeekOpen = isOpen;
        RefreshTopButtonsInteractable();
        RefreshTutorialReplayButton();
    }

    /// <summary>체인/해결 중에는 상단 정보 바의 모든 버튼 입력을 차단한다.</summary>
    private void BindBattleInputLock()
    {
        UnbindBattleInputLock();
        if (!BattleManager.HasInstance) return;

        _battle = BattleManager.Instance;
        _battle.OnProcessingChanged += HandleBattleProcessingChanged;
        SetTopButtonsInteractable(!_battle.IsProcessing);
    }

    private void UnbindBattleInputLock()
    {
        if (_battle != null)
            _battle.OnProcessingChanged -= HandleBattleProcessingChanged;
        _battle = null;
        _isBattleInputLocked = false;
    }

    private void HandleBattleProcessingChanged(bool isProcessing)
    {
        SetTopButtonsInteractable(!isProcessing);
    }

    private bool IsBattleInputLocked()
    {
        return _battle != null && _battle.IsProcessing;
    }

    private void SetTopButtonsInteractable(bool interactable)
    {
        _isBattleInputLocked = !interactable;
        RefreshTopButtonsInteractable();
    }

    private void SyncMapPeekState()
    {
        UIMap map = UIManager.HasInstance ? UIManager.Instance.Get<UIMap>() : null;
        _isMapPeekOpen = map != null && map.IsPeek;
        RefreshTopButtonsInteractable();
        RefreshTutorialReplayButton();
    }

    private void RefreshTopButtonsInteractable()
    {
        bool interactable = !_isBattleInputLocked;
        if (_settingsButton != null) _settingsButton.interactable = interactable;
        if (_mapButton != null) _mapButton.interactable = interactable && !_isMapPeekOpen;
        if (_deckButton != null) _deckButton.interactable = interactable;
        if (_tutorialReplayButton != null) _tutorialReplayButton.interactable = interactable;
    }

    private static RunContext CurrentRun()
    {
        return InGameController.HasInstance ? InGameController.Instance.CurrentRun : null;
    }

    private void OnDestroy()
    {
        if (_settingsButton != null)
            _settingsButton.onClick.RemoveListener(HandleSettingsClicked);
        if (_mapButton != null)
            _mapButton.onClick.RemoveListener(HandleMapClicked);
        if (_deckButton != null)
            _deckButton.onClick.RemoveListener(HandleDeckClicked);
        if (_tutorialReplayButton != null)
            _tutorialReplayButton.onClick.RemoveListener(HandleTutorialReplayClicked);
        _hpSub?.Dispose();
        _goldSub?.Dispose();
        _mapSub?.Dispose();
        UnbindTutorialReplay();
        UnbindBattleInputLock();
    }
}
