using System.Threading;
using Cysharp.Threading.Tasks;
using TMPro;
using UnityEngine;

/// <summary>로컬라이즈 키를 받아 잠시 표시한 뒤 서서히 사라지는 시스템 알림.</summary>
public sealed class UISystemNavi : UIBase
{
    [Header("캐싱된 UI")]
    [SerializeField] private TMP_Text _text;
    [SerializeField] private CanvasGroup _canvasGroup;

    private CancellationTokenSource _fadeCts;

    protected override void Init()
    {
        _canvasGroup.alpha = 0f;
        _canvasGroup.blocksRaycasts = false;
    }

    public void Show(string stringKey)
        => ShowAsync(stringKey).Forget();

    /// <summary>알림의 유지·페이드 아웃이 모두 끝날 때까지 기다린다.</summary>
    public async UniTask ShowAsync(string stringKey, CancellationToken token = default)
    {
        if (string.IsNullOrEmpty(stringKey)) return;

        _fadeCts?.Cancel();
        _fadeCts?.Dispose();
        _fadeCts = CancellationTokenSource.CreateLinkedTokenSource(
            this.GetCancellationTokenOnDestroy(), token);

        _text.text = LocalizationManager.HasInstance
            ? LocalizationManager.Instance.Get(stringKey)
            : stringKey;
        _canvasGroup.alpha = 1f;
        gameObject.SetActive(true);
        await FadeOutAsync(_fadeCts.Token);
    }

    private async UniTask FadeOutAsync(CancellationToken token)
    {
        try
        {
            await UniTask.Delay(
                System.TimeSpan.FromSeconds(0.8f),
                DelayType.UnscaledDeltaTime,
                cancellationToken: token);

            const float duration = 0.8f;
            float elapsed = 0f;
            while (elapsed < duration)
            {
                elapsed += Time.unscaledDeltaTime;
                _canvasGroup.alpha = 1f - Mathf.Clamp01(elapsed / duration);
                await UniTask.Yield(PlayerLoopTiming.Update, token);
            }

            _canvasGroup.alpha = 0f;
            gameObject.SetActive(false);
        }
        catch (System.OperationCanceledException)
        {
            // 중복 알림은 기존 페이드를 취소하고 처음부터 다시 표시한다.
        }
    }

    public override void OnClose()
    {
        _fadeCts?.Cancel();
        _fadeCts?.Dispose();
        _fadeCts = null;
        _canvasGroup.alpha = 0f;
    }
}
