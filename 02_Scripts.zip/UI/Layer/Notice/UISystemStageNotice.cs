﻿using System;
using System.Threading;
using Cysharp.Threading.Tasks;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;

/// <summary>스테이지 진입/클리어 전환용 Notice UI.</summary>
public sealed class UISystemStageNotice : UIBase, IPointerClickHandler
{
    [Header("캐싱된 UI")]
    [SerializeField] private CanvasGroup _backgroundGroup;
    [SerializeField] private CanvasGroup _enterIconGroup;
    [SerializeField] private TMP_Text _stageText;
    [SerializeField] private UICircleReveal[] _enterReveals;

    [Header("진입 연출")]
    [SerializeField, Min(0f)] private float _enterLeadInDuration = 0.3f;
    [SerializeField, Min(0f)] private float _enterIconFadeInDuration = 2f;
    [SerializeField, Min(0f)] private float _enterIconHoldDuration = 1.2f;
    [SerializeField, Min(0f)] private float _enterIconFadeOutDuration = 0.75f;

    [Header("스테이지 전환")]
    [SerializeField, Min(0f)] private float _transitionFadeOutDuration = 0.8f;

    [Header("연출 스킵")]
    [Tooltip("스킵 시 배경을 걷어내는 짧은 페이드 시간. 0이면 즉시 사라진다")]
    [SerializeField, Min(0f)] private float _skipFadeOutDuration = 0.2f;

    // 연출 중 클릭/터치가 감지되면 켜지고, 남은 연출 전체를 빠르게 끝낸다.
    private bool _skipRequested;

    private int _stageNumber = 1;
    // null이면 막 번호(_stageNumber)를 표시하고, 값이 있으면 해당 로컬라이즈 키를 그대로 표시한다.
    private string _overrideTitleKey;
    private readonly Vector3[] _worldCorners = new Vector3[4];

    protected override void Init()
    {
        ResetImmediate();
    }

    /// <summary>
    /// 화면 전체를 덮는 배경 이미지(raycastTarget)가 안 보이는 스킵 버튼을 겸한다.
    /// 클릭은 자식 이미지에 레이캐스트된 뒤 부모인 이 컴포넌트로 전달된다.
    /// 배경/아이콘이 비활성인 평상시에는 레이캐스트가 맞지 않아 호출되지 않는다.
    /// </summary>
    public void OnPointerClick(PointerEventData eventData)
    {
        _skipRequested = true;
    }

    public override void OnOpen()
    {
        SetActiveState(true);
        RefreshStageText();
    }

    public override void OnClose()
    {
        ResetImmediate();
    }

    public override void OnLocalize()
    {
        base.OnLocalize();
        RefreshStageText();
    }

    /// <summary>Notice에 표시할 1-based 막 번호를 설정한다.</summary>
    public void SetStageNumber(int stageNumber)
    {
        _stageNumber = Mathf.Max(1, stageNumber);
        _overrideTitleKey = null;
        RefreshStageText();
    }

    /// <summary>막 번호 대신 지정한 로컬라이즈 키의 문구를 표시한다(튜토리얼 등).</summary>
    public void SetTitleKey(string localizationKey)
    {
        _overrideTitleKey = localizationKey;
        RefreshStageText();
    }

    /// <summary>스테이지 진입 아이콘만 표시했다가 숨긴다.</summary>
    public UniTask PlayStageEnterAsync(CancellationToken token)
        => PlayStageEnterAsync(null, token);

    /// <summary>
    /// 진입 Notice 로 화면을 덮은 뒤(페이드인 없이 즉시 불투명), 뒤에서 맵을 표시/교체하고
    /// 진입 아이콘을 연출한 다음 Notice 를 걷어 맵을 드러낸다.
    /// </summary>
    /// <param name="presentBehindNotice">배경이 화면을 덮은 상태에서 실행할 맵 표시 작업. null 이면 생략.</param>
    public async UniTask PlayStageEnterAsync(
        Func<CancellationToken, UniTask> presentBehindNotice,
        CancellationToken token)
    {
        try
        {
            SetActiveState(true);
            _skipRequested = false;

            // 배경을 즉시 불투명하게 덮어 페이드인 없이 화면을 가린다(맵 빌드가 보이지 않도록).
            SetAlpha(_backgroundGroup, 1f);
            SetAlpha(_enterIconGroup, 0f);
            SetRevealProgress(_enterReveals, 0f);

            // 화면을 덮은 상태에서 뒤에서 맵을 표시한다.
            if (presentBehindNotice != null)
                await presentBehindNotice(token);

            await PlayEnterFromCoveredAsync(token);
        }
        finally
        {
            CleanupAfterPlayback();
        }
    }

    /// <summary>
    /// 현재 화면을 페이드 아웃한 뒤 암전 상태에서 다음 스테이지를 준비하고 진입 연출로 이어간다.
    /// 클리어 아이콘·문구는 표시하지 않는다.
    /// </summary>
    public async UniTask<bool> PlayStageTransitionAsync(
        Func<CancellationToken, UniTask<bool>> prepareNextStage,
        CancellationToken token)
    {
        try
        {
            SetActiveState(true);
            _skipRequested = false;
            SetAlpha(_backgroundGroup, 0f);
            SetAlpha(_enterIconGroup, 0f);
            SetRevealProgress(_enterReveals, 0f);

            await FadeBackgroundAsync(1f, _transitionFadeOutDuration, token);

            if (prepareNextStage != null && !await prepareNextStage(token))
                return false;

            await PlayEnterFromCoveredAsync(token);
            return true;
        }
        finally
        {
            CleanupAfterPlayback();
        }
    }

    public void ResetImmediate()
    {
        SetAlpha(_backgroundGroup, 0f);
        SetAlpha(_enterIconGroup, 0f);
        SetRevealProgress(_enterReveals, 0f);
        SetActiveState(false);
    }

    private async UniTask FadeBackgroundAsync(float targetAlpha, float duration, CancellationToken token)
    {
        if (_backgroundGroup == null) return;

        if (duration <= 0f)
        {
            SetAlpha(_backgroundGroup, targetAlpha);
            return;
        }

        float from = _backgroundGroup.alpha;
        float elapsed = 0f;
        while (elapsed < duration && !_skipRequested)
        {
            token.ThrowIfCancellationRequested();
            elapsed += Time.unscaledDeltaTime;
            SetAlpha(_backgroundGroup, Mathf.Lerp(from, targetAlpha, Mathf.Clamp01(elapsed / duration)));
            await UniTask.Yield(PlayerLoopTiming.Update, token);
        }

        SetAlpha(_backgroundGroup, targetAlpha);
    }

    private async UniTask PlayEnterFromCoveredAsync(CancellationToken token)
    {
        ConfigureSharedRevealGeometry(_enterIconGroup, _enterReveals);
        await PrepareEnterRevealAsync(token);
        SetAlpha(_enterIconGroup, 1f);
        await PlayEnterRevealAsync(token);
        await SkippableDelayAsync(_enterIconHoldDuration, token);
        await FadeBackgroundAndEnterOutAsync(_enterIconFadeOutDuration, token);
    }

    /// <summary>
    /// 진입 장식과 화면 덮개를 함께 걷어 뒤의 맵/HUD를 자연스럽게 공개한다.
    /// 스킵 요청 시에는 남은 구간을 _skipFadeOutDuration 속도로 가속해 뚝 끊기지 않게 마무리한다.
    /// </summary>
    private async UniTask FadeBackgroundAndEnterOutAsync(float duration, CancellationToken token)
    {
        float alpha = 1f;
        while (alpha > 0f)
        {
            token.ThrowIfCancellationRequested();

            float currentDuration = _skipRequested ? Mathf.Min(_skipFadeOutDuration, duration) : duration;
            alpha = currentDuration <= 0f
                ? 0f
                : Mathf.Max(0f, alpha - Time.unscaledDeltaTime / currentDuration);

            SetAlpha(_backgroundGroup, alpha);
            SetAlpha(_enterIconGroup, alpha);

            if (alpha > 0f)
                await UniTask.Yield(PlayerLoopTiming.Update, token);
        }

        SetAlpha(_backgroundGroup, 0f);
        SetAlpha(_enterIconGroup, 0f);
    }

    /// <summary>스킵 요청이 들어오면 남은 시간을 기다리지 않고 즉시 반환하는 지연.</summary>
    private async UniTask SkippableDelayAsync(float seconds, CancellationToken token)
    {
        float elapsed = 0f;
        while (elapsed < seconds && !_skipRequested)
        {
            token.ThrowIfCancellationRequested();
            elapsed += Time.unscaledDeltaTime;
            await UniTask.Yield(PlayerLoopTiming.Update, token);
        }
    }

    private void SetActiveState(bool active)
    {
        if (_backgroundGroup != null)
            _backgroundGroup.gameObject.SetActive(active);
        if (_enterIconGroup != null)
            _enterIconGroup.gameObject.SetActive(active);
    }

    private void RefreshStageText()
    {
        // 막 번호 대신 지정 문구(튜토리얼 등)를 표시하는 경우.
        if (_overrideTitleKey != null)
        {
            ApplyStageText(_stageText, _overrideTitleKey, _stageNumber);
            return;
        }

        ApplyStageText(_stageText, LocalizationKeys.StageNotice.CurrentStageFormat, _stageNumber);
    }

    private static void ApplyStageText(TMP_Text text, string localizationKey, int stageNumber)
    {
        if (text == null) return;

        LocalizedFontUtility.ApplyCurrentFont(text);
        text.text = LocalizationManager.HasInstance && LocalizationManager.Instance.HasKey(localizationKey)
            ? LocalizationManager.Instance.Get(localizationKey, stageNumber)
            : localizationKey ?? string.Empty;
    }

    /// <summary>
    /// 두 장식 Image를 하나의 진행값으로 동기화한다.
    /// Image별 DOTween을 따로 재생하면 프레임/완료 시점이 분리되어 두 번 나타나는 것처럼 보일 수 있다.
    /// </summary>
    private UniTask PlayEnterRevealAsync(CancellationToken token)
        => PlayRevealAsync(_enterReveals, _enterIconFadeInDuration, token);

    /// <summary>같은 그룹의 두 장식에 동일 진행도를 적용해 하나의 파동처럼 공개한다.</summary>
    private async UniTask PlayRevealAsync(
        UICircleReveal[] reveals,
        float duration,
        CancellationToken token)
    {
        if (reveals == null || reveals.Length == 0) return;

        if (duration <= 0f)
        {
            SetRevealProgress(reveals, 1f);
            return;
        }

        float elapsed = 0f;
        while (elapsed < duration && !_skipRequested)
        {
            token.ThrowIfCancellationRequested();
            // 최초 Addressables/셰이더 준비 프레임이 길어도 Reveal 초반 구간을 건너뛰지 않는다.
            elapsed += Mathf.Min(Time.unscaledDeltaTime, 1f / 30f);

            // 공개 반경이 중앙부터 끝까지 일정한 속도로 증가하도록 선형 진행값을 사용한다.
            float progress = Mathf.Clamp01(elapsed / duration);
            SetRevealProgress(reveals, progress);
            await UniTask.Yield(PlayerLoopTiming.Update, token);
        }

        SetRevealProgress(reveals, 1f);
    }

    /// <summary>첫 렌더를 투명 상태에서 완료해 실제 Reveal 중 셰이더 준비로 끊기지 않게 한다.</summary>
    private async UniTask PrepareEnterRevealAsync(CancellationToken token)
    {
        SetAlpha(_enterIconGroup, 0f);
        SetRevealProgress(_enterReveals, 0f);
        Canvas.ForceUpdateCanvases();
        await UniTask.Yield(PlayerLoopTiming.LastPostLateUpdate, token);
        await SkippableDelayAsync(_enterLeadInDuration, token);
    }

    private static void SetRevealProgress(UICircleReveal[] reveals, float progress)
    {
        if (reveals == null) return;

        for (int i = 0; i < reveals.Length; i++)
        {
            if (reveals[i] != null)
                reveals[i].SetProgress(progress);
        }
    }

    /// <summary>
    /// 각 Image의 로컬 UV가 아닌 EnterGroup 중앙을 공통 원점으로 사용한다.
    /// 두 장식이 별개로 나타나는 대신, 하나의 원형 파동이 양쪽 끝까지 확장된다.
    /// </summary>
    private void ConfigureSharedRevealGeometry(CanvasGroup group, UICircleReveal[] reveals)
    {
        if (group == null || reveals == null || reveals.Length == 0) return;

        RectTransform groupRect = group.transform as RectTransform;
        if (groupRect == null) return;

        Vector3 groupCenterWorld = groupRect.TransformPoint(Vector3.zero);
        float maxHorizontalRadiusPixels = 0f;

        for (int i = 0; i < reveals.Length; i++)
        {
            UICircleReveal reveal = reveals[i];
            if (reveal == null) continue;

            RectTransform imageRect = reveal.transform as RectTransform;
            if (imageRect == null) continue;

            imageRect.GetWorldCorners(_worldCorners);

            for (int cornerIndex = 0; cornerIndex < _worldCorners.Length; cornerIndex++)
            {
                Vector3 groupLocal = groupRect.InverseTransformPoint(_worldCorners[cornerIndex]);
                maxHorizontalRadiusPixels = Mathf.Max(maxHorizontalRadiusPixels, Mathf.Abs(groupLocal.x));
            }
        }

        for (int i = 0; i < reveals.Length; i++)
        {
            UICircleReveal reveal = reveals[i];
            if (reveal == null) continue;

            RectTransform imageRect = reveal.transform as RectTransform;
            if (imageRect == null) continue;

            Rect rect = imageRect.rect;
            if (Mathf.Abs(rect.width) <= Mathf.Epsilon || Mathf.Abs(rect.height) <= Mathf.Epsilon) continue;

            Vector3 imageLocalCenter = imageRect.InverseTransformPoint(groupCenterWorld);
            Vector2 centerUv = new Vector2(
                (imageLocalCenter.x - rect.xMin) / rect.width,
                (imageLocalCenter.y - rect.yMin) / rect.height);
            reveal.SetSharedRevealGeometry(centerUv, maxHorizontalRadiusPixels / Mathf.Abs(rect.height));
        }
    }

    private static void SetAlpha(CanvasGroup group, float alpha)
    {
        if (group != null)
            group.alpha = alpha;
    }

    /// <summary>
    /// 씬 종료/매니저 셧다운 중 캐시가 먼저 파괴될 수 있으므로 Unity fake-null을 확인한 뒤 정리한다.
    /// </summary>
    private void CleanupAfterPlayback()
    {
        if (this == null) return;

        ResetImmediate();
        if (IsOpen)
            CloseSelf();
    }

    private void CloseSelf()
    {
        if (UIManager.HasInstance)
            UIManager.Instance.Close(this);
        else
            gameObject.SetActive(false);
    }
}
