// =================================================================
// [스크립트 목적]  탭 전환 위젯. 탭 버튼 클릭 시 해당 패널만 표시 + 선택 탭 하이라이트
// [주요 변수]      - _tabs        : 탭 버튼·패널·하이라이트 묶음 목록
//                  - _currentIndex: 현재 선택 탭 인덱스
// [의존 관계]      - MonoBehaviour, UGUI(Button)
// [원칙]           옵션·상점 등 카테고리 분할 화면에서 재사용. 버튼 리스너는 코드 등록.
// [사용]           Inspector에 탭 N개 구성 → SelectTab(0)으로 초기 탭 지정
// =================================================================
using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

public class UITabGroup : MonoBehaviour
{
    /// <summary>탭 한 칸 구성 (버튼 + 패널 + 선택 표시).</summary>
    [Serializable]
    public class Tab
    {
        [Tooltip("이 탭을 선택하는 버튼")]
        public Button TabButton;
        [Tooltip("이 탭이 선택됐을 때 표시할 콘텐츠 패널")]
        public GameObject Panel;
        [Tooltip("선택 시 켜질 하이라이트 오브젝트 (선택, 밑줄·강조 배경 등)")]
        public GameObject Highlight;

        // 명명 핸들러 보관 (개별 RemoveListener용)
        [NonSerialized] public UnityAction Handler;
    }

    [Header("탭 구성")]
    [Tooltip("탭 목록. 버튼·패널이 인덱스로 1:1 대응")]
    [SerializeField] private List<Tab> _tabs = new();

    [Tooltip("시작 시 선택할 탭 인덱스")]
    [SerializeField] private int _defaultIndex = 0;

    private int _currentIndex = -1;

    /// <summary>현재 선택된 탭 인덱스.</summary>
    public int CurrentIndex => _currentIndex;

    /// <summary>탭 변경 시 발행 (인자: 새 탭 인덱스).</summary>
    public UnityEvent<int> OnTabChanged = new();

    private void Awake()
    {
        // 버튼 리스너는 코드에서만 등록 (Inspector OnClick 금지)
        for (int i = 0; i < _tabs.Count; i++)
        {
            var tab = _tabs[i];
            if (tab?.TabButton == null) continue;

            int idx = i; // 클로저 캡처 안전
            tab.Handler = () => SelectTab(idx);
            tab.TabButton.onClick.AddListener(tab.Handler);
        }
    }

    private void OnEnable()
    {
        // 활성화될 때마다 기본 탭으로 리셋 (창 재오픈 시 첫 탭부터)
        SelectTab(_defaultIndex);
    }

    private void OnDestroy()
    {
        foreach (var tab in _tabs)
        {
            if (tab?.TabButton != null && tab.Handler != null)
                tab.TabButton.onClick.RemoveListener(tab.Handler);
            if (tab != null) tab.Handler = null;
        }
    }

    /// <summary>탭 선택. 해당 패널만 표시하고 나머지는 숨김.</summary>
    public void SelectTab(int index)
    {
        if (_tabs.Count == 0) return;
        index = Mathf.Clamp(index, 0, _tabs.Count - 1);

        // 같은 탭 재선택은 무시 (불필요한 SetActive·이벤트 방지)
        if (index == _currentIndex) return;

        _currentIndex = index;

        for (int i = 0; i < _tabs.Count; i++)
        {
            var tab = _tabs[i];
            if (tab == null) continue;

            bool selected = (i == index);
            if (tab.Panel != null) tab.Panel.SetActive(selected);
            if (tab.Highlight != null) tab.Highlight.SetActive(selected);
            if (tab.TabButton != null) tab.TabButton.interactable = !selected; // 선택된 탭은 비활성(중복 클릭 방지)
        }

        OnTabChanged?.Invoke(index);
    }
}
