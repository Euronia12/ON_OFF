using Cysharp.Threading.Tasks;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

[DisallowMultipleComponent]
public sealed class UISelectableClickAudio : MonoBehaviour, IPointerDownHandler, ISubmitHandler
{
    private Selectable _selectable;

    public static void BindAll(Transform root)
    {
        if (root == null) return;

        Button[] buttons = root.GetComponentsInChildren<Button>(true);
        for (int i = 0; i < buttons.Length; i++)
            Ensure(buttons[i]);

        Toggle[] toggles = root.GetComponentsInChildren<Toggle>(true);
        for (int i = 0; i < toggles.Length; i++)
            Ensure(toggles[i]);
    }

    private static void Ensure(Selectable selectable)
    {
        if (selectable == null || selectable.TryGetComponent(out UISelectableClickAudio _)) return;
        selectable.gameObject.AddComponent<UISelectableClickAudio>();
    }

    private void Awake()
    {
        _selectable = GetComponent<Selectable>();
    }

    public void OnPointerDown(PointerEventData eventData)
    {
        if (eventData.button == PointerEventData.InputButton.Left)
            Play();
    }

    public void OnSubmit(BaseEventData eventData)
    {
        Play();
    }

    private void Play()
    {
        if (_selectable == null || !_selectable.IsInteractable() || !AudioManager.HasInstance) return;
        AudioManager.Instance.PlayUiAsync(AudioKeys.Ui.BUTTON).Forget();
    }
}
