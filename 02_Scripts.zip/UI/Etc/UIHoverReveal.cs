// =================================================================
// [스크립트 목적]  호버 중에만 보여야 하는 장식 그래픽(타이틀 메뉴 버튼의 Left/RightArrow 등)의
//                 표시를 담당. 평소엔 알파 0으로 숨기고, 포인터가 올라오면 페이드 인한다.
//                 클릭 로직은 Button, 스케일 연출은 UIButton 이 담당 — 이 컴포넌트는 "표시"만.
// [주요 변수]      - _targets       : 호버 중에만 보일 Graphic 목록
//                  - _selectable    : interactable 판정용(없으면 항상 활성 취급)
//                  - _visibleAlpha  : 보일 때 알파 / _fadeDuration : 페이드 시간(0이면 즉시)
// [의존 관계]      - DG.Tweening / UnityEngine.UI.Graphic / EventSystems 핸들러
// [배치]           버튼 루트(Button 과 같은 오브젝트)에 부착하고 자식 화살표 Image 를 _targets 에 등록.
// [설계 노트]      - 대상은 SetActive 가 아니라 알파로 껐다 켠다. 프리팹에서는 화살표가 계속 보여야
//                    배치를 확인하기 쉽고, 레이아웃도 흔들리지 않는다.
//                  - UIButton 과 같은 이유로 Tween 참조를 들고 있지 않고 대상 기준 DOKill() 로 정리한다.
//                    (TweenManager 가 트윈 인스턴스를 재활용하므로 참조 기반 Kill 은 위험)
// =================================================================

using System.Collections.Generic;
using DG.Tweening;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

/// <summary>
/// 포인터가 올라와 있는 동안에만 지정한 Graphic 들을 보여 주는 컴포넌트.
/// 타이틀 메뉴 버튼의 좌우 화살표처럼 "선택 중임"을 알리는 장식에 사용한다.
/// </summary>
[DisallowMultipleComponent]
public sealed class UIHoverReveal : MonoBehaviour,
    IPointerEnterHandler, IPointerExitHandler
{
    [Header("대상")]
    [Tooltip("호버 중에만 보일 Graphic 목록. 보통 버튼 좌우의 화살표 Image.")]
    [SerializeField] private List<Graphic> _targets = new();

    [Tooltip("interactable 판정에 쓸 Selectable(보통 Button). 비우면 같은 오브젝트에서 자동 탐색.")]
    [SerializeField] private Selectable _selectable;

    [Header("연출")]
    [Tooltip("보일 때의 알파 값.")]
    [Range(0f, 1f)]
    [SerializeField] private float _visibleAlpha = 1f;

    [Tooltip("나타나고 사라지는 페이드 시간(초). 0이면 즉시 전환.")]
    [Min(0f)]
    [SerializeField] private float _fadeDuration = 0.12f;

    private bool Interactable => _selectable == null || _selectable.interactable;

    private void Awake()
    {
        if (_selectable == null) _selectable = GetComponent<Selectable>();
    }

    private void OnEnable()
    {
        // 비활성→재활성 사이에 호버 종료 이벤트가 오지 않을 수 있으므로 항상 숨김에서 시작.
        Apply(false, true);
    }

    private void OnDisable()
    {
        Apply(false, true);
    }

    public void OnPointerEnter(PointerEventData eventData)
    {
        if (!Interactable) return;
        Apply(true, false);
    }

    public void OnPointerExit(PointerEventData eventData)
    {
        Apply(false, false);
    }

    /// <summary>대상들의 알파를 목표 값으로 맞춘다. immediate 면 트윈 없이 즉시 적용.</summary>
    private void Apply(bool visible, bool immediate)
    {
        float alpha = visible ? _visibleAlpha : 0f;
        float duration = immediate ? 0f : _fadeDuration;

        for (int i = 0; i < _targets.Count; i++)
        {
            Graphic target = _targets[i];
            if (target == null) continue;

            target.DOKill();

            if (duration <= 0f)
            {
                Color color = target.color;
                color.a = alpha;
                target.color = color;
                continue;
            }

            target.DOFade(alpha, duration).SetEase(Ease.OutQuad);
        }
    }

    private void OnDestroy()
    {
        for (int i = 0; i < _targets.Count; i++)
        {
            if (_targets[i] != null) _targets[i].DOKill();
        }
    }
}
