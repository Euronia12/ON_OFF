﻿// =================================================================
// [스크립트 목적]  ◀ 라벨 ▶ 스테퍼 위젯. 고정 항목 선택용 (품질·화면모드·프레임 등)
// [주요 변수]      - _options   : 표시할 항목 라벨 배열
//                  - _index     : 현재 선택 인덱스
//                  - _wrap      : 양끝에서 순환할지 여부
// [의존 관계]      - MonoBehaviour, UGUI(Button/Text)
// [원칙]           드롭다운 대비 게임패드 좌우키 친화 + 공간 절약. 항목 추가는 SetOptions만.
// [사용]           SetOptions(labels) → OnChanged 구독 → SetIndexWithoutNotify로 초기값
// =================================================================
using System;
using TMPro;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

public class UIStepper : MonoBehaviour
{
    [Header("스테퍼 구성")]
    [Tooltip("이전 항목(◀) 버튼")]
    [SerializeField] private Button _prevButton;
    [Tooltip("다음 항목(▶) 버튼")]
    [SerializeField] private Button _nextButton;
    [Tooltip("현재 항목 라벨 텍스트")]
    [SerializeField] private TMP_Text _label;

    [Tooltip("양끝에서 순환할지 여부 (true: 마지막→처음 / false: 끝에서 버튼 비활성)")]
    [SerializeField] private bool _wrap = false;

    private string[] _options = Array.Empty<string>();
    private int _index;
    private bool _isInteractable = true;

    /// <summary>현재 선택 인덱스.</summary>
    public int Index => _index;

    /// <summary>항목 개수.</summary>
    public int Count => _options.Length;

    /// <summary>인덱스 변경 시 발행 (인자: 새 인덱스). 사용자 조작 시에만 호출.</summary>
    public UnityEvent<int> OnChanged = new();

    private void Awake()
    {
        // 버튼 리스너는 코드에서만 등록 (Inspector OnClick 금지)
        _prevButton?.onClick.AddListener(Prev);
        _nextButton?.onClick.AddListener(Next);
    }

    private void OnDestroy()
    {
        _prevButton?.onClick.RemoveListener(Prev);
        _nextButton?.onClick.RemoveListener(Next);
    }

    /// <summary>항목 라벨 설정. 인덱스는 0으로 초기화, 알림 없음.</summary>
    public void SetOptions(string[] options)
    {
        _options = options ?? Array.Empty<string>();
        _index = 0;
        UpdateView();
    }

    public void ApplyFont(TMP_FontAsset font)
    {
        if (_label == null || font == null || _label.font == font) return;
        _label.font = font;
    }

    /// <summary>스테퍼의 이전/다음 선택 가능 여부를 설정한다.</summary>
    public void SetInteractable(bool interactable)
    {
        _isInteractable = interactable;
        UpdateView();
    }

    /// <summary>인덱스 설정 (이벤트 발행 안 함). 초기값 세팅용.</summary>
    public void SetIndexWithoutNotify(int idx)
    {
        if (_options.Length == 0) { _index = 0; UpdateView(); return; }
        _index = Mathf.Clamp(idx, 0, _options.Length - 1);
        UpdateView();
    }

    private void Prev()
    {
        if (!_isInteractable || _options.Length == 0) return;

        int next = _index - 1;
        if (next < 0)
        {
            if (!_wrap) return;
            next = _options.Length - 1;
        }
        _index = next;
        UpdateView();
        OnChanged?.Invoke(_index);
    }

    private void Next()
    {
        if (!_isInteractable || _options.Length == 0) return;

        int next = _index + 1;
        if (next >= _options.Length)
        {
            if (!_wrap) return;
            next = 0;
        }
        _index = next;
        UpdateView();
        OnChanged?.Invoke(_index);
    }

    // 라벨 텍스트 + 끝단 버튼 활성 상태 갱신
    private void UpdateView()
    {
        if (_label != null)
            _label.text = (_index >= 0 && _index < _options.Length) ? _options[_index] : string.Empty;

        bool canStep = _isInteractable && _options.Length > 1;
        if (_prevButton != null)
            _prevButton.interactable = canStep && (_wrap || _index > 0);
        if (_nextButton != null)
            _nextButton.interactable = canStep && (_wrap || _index < _options.Length - 1);
    }
}
