// =================================================================
// [스크립트 목적]  버튼 공용 인터랙션 피드백. 호버 시 확대, 누를 때 축소,
//                 떼면 복귀하는 스케일 연출을 한 컴포넌트로 묶어 어떤 버튼에도 붙인다.
//                 클릭 로직은 기존 Button.onClick 이 그대로 담당 — 이 컴포넌트는 "연출"만.
// [주요 변수]      - _target       : 스케일 대상 Transform (미지정 시 자기 자신)
//                  - _hoverScale   : 호버 배율 / _pressScale : 누름 배율
//                  - _selectable   : interactable 판정용(없으면 항상 활성 취급)
// [의존 관계]      - DG.Tweening / UnityEngine.UI.Selectable / EventSystems 핸들러
// [배치]           버튼(또는 클릭 가능한 Image) 루트에 부착. Button 과 같은 오브젝트에 둬도 무방.
// [설계 노트]      - 클릭 처리는 Button 책임 → 중복 안 함(연출/로직 경계).
//                  - Selectable.interactable == false 면 호버·누름 반응 차단(UIShopCardSlot 와 동일 정책).
//                  - 누름이 호버보다 우선. 상태 전환마다 Target.DOKill() 로 "타겟 기준" 정리 후 재시작.
//                    ★ TweenManager가 recycleAllByDefault=true 로 초기화하므로, 자연 완료된 Tween
//                    인스턴스는 풀로 반환되어 다른 트윈에 재사용될 수 있다. Tween 참조(_scaleTween)를
//                    들고 있다가 나중에 그 참조로 Kill()하면, 이미 다른 대상에 재사용된 트윈을
//                    잘못 죽여 DOTween 내부 활성 리스트가 어긋나 IndexOutOfRangeException이 난다.
//                    그래서 참조 대신 Target.DOKill()(타겟 기준 조회)로 죽인다 — 재사용 안전.
// =================================================================

using DG.Tweening;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

/// <summary>
/// 버튼 호버/누름 스케일 피드백 컴포넌트. 클릭 동작은 기존 Button 에 맡기고
/// 시각적 반응(확대/축소)만 담당한다. 어떤 버튼에든 부착해 일관된 반응을 준다.
/// </summary>
[DisallowMultipleComponent]
public sealed class UIButton : MonoBehaviour,
    IPointerEnterHandler, IPointerExitHandler,
    IPointerDownHandler, IPointerUpHandler
{
    [Header("대상")]
    [Tooltip("스케일을 적용할 Transform. 비우면 이 오브젝트 자신을 사용.")]
    [SerializeField] private Transform _target;

    [Tooltip("interactable 판정에 쓸 Selectable(보통 Button). 비우면 같은 오브젝트에서 자동 탐색.")]
    [SerializeField] private Selectable _selectable;

    [Header("호버")]
    [Tooltip("마우스를 올렸을 때 배율.")]
    [SerializeField] private float _hoverScale = 1.08f;

    [Tooltip("호버 스케일 트윈 시간(초).")]
    [SerializeField] private float _hoverDuration = 0.12f;

    [Header("누름")]
    [Tooltip("누르고 있는 동안 배율(보통 1보다 작게).")]
    [SerializeField] private float _pressScale = 0.94f;

    [Tooltip("누름/복귀 스케일 트윈 시간(초).")]
    [SerializeField] private float _pressDuration = 0.08f;

    private Transform Target => _target != null ? _target : transform;
    private bool Interactable => _selectable == null || _selectable.interactable;

    private Vector3 _baseScale = Vector3.one;
    private bool _isHovering;
    private bool _isPressing;

    private void Awake()
    {
        _baseScale = Target.localScale;
        if (_selectable == null) _selectable = GetComponent<Selectable>();
    }

    private void OnEnable()
    {
        // 비활성→재활성 사이 상태가 남지 않도록 기본 스케일로 정렬.
        ResetState();
    }

    private void OnDisable()
    {
        // 떠 있는 트윈 정리 + 즉시 기본 스케일 복귀(비활성 중 호버 종료 이벤트가 안 와도 안전).
        Target.DOKill();
        if (Target != null) Target.localScale = _baseScale;
        _isHovering = false;
        _isPressing = false;
    }

    public void OnPointerEnter(PointerEventData eventData)
    {
        if (!Interactable) return;
        _isHovering = true;
        ApplyState();
    }

    public void OnPointerExit(PointerEventData eventData)
    {
        _isHovering = false;
        ApplyState();
    }

    public void OnPointerDown(PointerEventData eventData)
    {
        if (!Interactable) return;
        _isPressing = true;
        ApplyState();
    }

    public void OnPointerUp(PointerEventData eventData)
    {
        _isPressing = false;
        ApplyState();
    }

    /// <summary>현재 호버/누름 상태에 맞는 목표 배율로 스케일 트윈을 건다. 누름이 호버보다 우선.</summary>
    private void ApplyState()
    {
        float multiplier;
        float duration;

        if (_isPressing)
        {
            multiplier = _pressScale;
            duration = _pressDuration;
        }
        else if (_isHovering)
        {
            multiplier = _hoverScale;
            duration = _hoverDuration;
        }
        else
        {
            multiplier = 1f;
            duration = _hoverDuration;
        }

        Target.DOKill();
        Target.DOScale(_baseScale * multiplier, duration).SetEase(Ease.OutQuad);
    }

    /// <summary>호버/누름 상태를 끄고 기본 스케일로 즉시 정렬(활성화·초기화용).</summary>
    private void ResetState()
    {
        Target.DOKill();
        _isHovering = false;
        _isPressing = false;
        if (Target != null) Target.localScale = _baseScale;
    }

    private void OnDestroy()
    {
        if (Target != null) Target.DOKill();
    }
}
