using UnityEngine;
using UnityEngine.UI;

public sealed class RedPaperSeparationCutter : MonoBehaviour
{
    private static readonly int CutProgressId = Shader.PropertyToID("_CutProgress");
    private static readonly int DetachedId = Shader.PropertyToID("_Detached");

    [SerializeField] private Image _attachedImage;
    [SerializeField] private Image _detachedImage;
    [SerializeField, Min(0f)] private float _separationDistance = 7f;
    [SerializeField, Range(0f, 1f), Tooltip("Play Mode에서 값을 바꿔 절단 상태를 확인합니다.")]
    private float _cutProgress;

    private Material _attachedMaterial;
    private Material _detachedMaterial;
    private Vector2 _detachedStartPosition;
    private bool _initialized;

    private void Awake()
    {
        if (_attachedImage == null || _detachedImage == null ||
            _attachedImage.material == null || _detachedImage.material == null)
        {
            Debug.LogError("RedPaperSeparationCutter의 Image와 Material 참조가 필요합니다.", this);
            enabled = false;
            return;
        }

        _detachedStartPosition = _detachedImage.rectTransform.anchoredPosition;

        _attachedMaterial = Instantiate(_attachedImage.material);
        _detachedMaterial = Instantiate(_detachedImage.material);
        _attachedMaterial.name = $"{_attachedImage.material.name} (Attached Instance)";
        _detachedMaterial.name = $"{_detachedImage.material.name} (Detached Instance)";

        // 동일한 Sprite를 서로 반대인 절단 영역으로 나눠 표시한다.
        _attachedMaterial.SetFloat(DetachedId, 0f);
        _detachedMaterial.SetFloat(DetachedId, 1f);

        _attachedImage.material = _attachedMaterial;
        _detachedImage.material = _detachedMaterial;
        _initialized = true;
        SetCutProgress(_cutProgress);
    }

    public void SetCutProgress(float progress)
    {
        progress = Mathf.Clamp01(progress);
        _cutProgress = progress;

        _attachedMaterial?.SetFloat(CutProgressId, progress);
        _detachedMaterial?.SetFloat(CutProgressId, progress);

        if (_detachedImage != null)
            _detachedImage.rectTransform.anchoredPosition =
                _detachedStartPosition + Vector2.up * (_separationDistance * progress);
    }

    private void OnValidate()
    {
        if (Application.isPlaying && _initialized)
            SetCutProgress(_cutProgress);
    }

    private void OnDestroy()
    {
        _initialized = false;

        if (_attachedMaterial != null)
            Destroy(_attachedMaterial);
        if (_detachedMaterial != null)
            Destroy(_detachedMaterial);
    }
}
