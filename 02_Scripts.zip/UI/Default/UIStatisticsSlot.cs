using System;
using System.Collections.Generic;
using Cysharp.Threading.Tasks;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

/// <summary>결과 화면의 통계 이름·값과 선택적 액션을 표시하는 공용 슬롯.</summary>
public sealed class UIStatisticsSlot : MonoBehaviour
{
    [SerializeField] private TMP_Text _labelText;
    [SerializeField] private TMP_Text _valueText;
    [SerializeField] private Button _actionButton;
    [SerializeField] private TMP_Text _actionButtonText;

    private Action _action;

    private void Awake()
    {
        Debug.Assert(_labelText != null, "UIStatisticsSlot 프리팹에 Label 텍스트가 필요합니다.", this);
        Debug.Assert(_valueText != null, "UIStatisticsSlot 프리팹에 Value 텍스트가 필요합니다.", this);
        Debug.Assert(_actionButton != null, "UIStatisticsSlot 프리팹에 ActionButton이 필요합니다.", this);
        Debug.Assert(_actionButtonText != null, "UIStatisticsSlot 프리팹에 ActionButton Text가 필요합니다.", this);

        if (_actionButton != null)
            _actionButton.onClick.AddListener(HandleAction);
    }

    public void Bind(string label, string value, string actionText = null, Action action = null)
    {
        if (_labelText != null) _labelText.text = label ?? string.Empty;
        if (_valueText != null) _valueText.text = value ?? string.Empty;

        _action = action;
        bool hasAction = action != null;
        if (_actionButton != null)
            _actionButton.gameObject.SetActive(hasAction);
        if (_actionButtonText != null)
            _actionButtonText.text = hasAction ? actionText ?? string.Empty : string.Empty;

        LocalizedFontUtility.ApplyCurrentFont(_labelText);
        LocalizedFontUtility.ApplyCurrentFont(_valueText);
        LocalizedFontUtility.ApplyCurrentFont(_actionButtonText);
    }

    private void HandleAction() => _action?.Invoke();

    private void OnDestroy()
    {
        if (_actionButton != null)
            _actionButton.onClick.RemoveListener(HandleAction);
        _action = null;
    }
}

public static class RunStatisticsUIBuilder
{
    public static void Rebuild(
        RectTransform root,
        UIStatisticsSlot prefab,
        RunStatisticsSnapshot snapshot,
        List<UIStatisticsSlot> spawned)
    {
        Clear(spawned);
        if (root == null || prefab == null || snapshot == null) return;

        Add(root, prefab, spawned, LocalizationKeys.GameClear.StatsPlayTime,
            FormatRunPlayTime(snapshot.ActiveRunSeconds));
        Add(root, prefab, spawned, LocalizationKeys.GameClear.StatsBattleRecord,
            Format(LocalizationKeys.GameClear.StatsBattleRecordFormat,
                snapshot.BattlesWon, snapshot.NoDamageWins));
        Add(root, prefab, spawned, LocalizationKeys.GameClear.StatsBattleEfficiency,
            Format(LocalizationKeys.GameClear.StatsBattleEfficiencyFormat,
                snapshot.AverageTurnsPerBattle, snapshot.MaxBattleTurns));
        Add(root, prefab, spawned, LocalizationKeys.GameClear.StatsDamageTaken, snapshot.TotalDamageTaken.ToString());
        Add(root, prefab, spawned, LocalizationKeys.GameClear.StatsCardUsage,
            Format(LocalizationKeys.GameClear.StatsCardUsageFormat,
                snapshot.CardPlacementCount, snapshot.AverageCardPlacementsPerTurn));
        Add(root, prefab, spawned, LocalizationKeys.GameClear.StatsMaxChainLoops,
            Format(LocalizationKeys.GameClear.StatsMaxChainLoopsFormat,
                snapshot.MaxChainCount, snapshot.InfiniteLoopCount));
        Add(root, prefab, spawned, LocalizationKeys.GameClear.StatsFinalDeck,
            Format(LocalizationKeys.GameClear.StatsFinalDeckFormat, snapshot.FinalDeckCount, snapshot.ReinforcementCount),
            Localize(LocalizationKeys.GameClear.DeckViewButton),
            () => UIRunDeckViewer.OpenAsync(snapshot.FinalDeck).Forget());
        Add(root, prefab, spawned, LocalizationKeys.GameClear.StatsTopCard, ResolveTopCard(snapshot));
    }

    public static void Clear(List<UIStatisticsSlot> spawned)
    {
        if (spawned == null) return;
        for (int i = 0; i < spawned.Count; i++)
        {
            if (spawned[i] != null)
            {
                spawned[i].gameObject.SetActive(false);
                UnityEngine.Object.Destroy(spawned[i].gameObject);
            }
        }
        spawned.Clear();
    }

    private static void Add(
        RectTransform root,
        UIStatisticsSlot prefab,
        List<UIStatisticsSlot> spawned,
        string labelKey,
        string value,
        string actionText = null,
        Action action = null)
    {
        UIStatisticsSlot slot = UnityEngine.Object.Instantiate(prefab, root);
        slot.Bind(Localize(labelKey), value, actionText, action);
        spawned.Add(slot);
    }

    private static string ResolveTopCard(RunStatisticsSnapshot snapshot)
    {
        if (string.IsNullOrEmpty(snapshot.TopCardId) || snapshot.TopCardCount <= 0)
            return "-";

        string name = snapshot.TopCardId;
        if (DataManager.HasInstance && DataManager.Instance.IsLoaded)
        {
            CardDataSO card = DataManager.Instance.GetData<CardDataSO>(snapshot.TopCardId);
            if (card != null)
                name = Localize(card.DisplayNameKey);
        }
        return $"{name} ×{snapshot.TopCardCount}";
    }

    private static string FormatTime(float seconds)
    {
        int total = Mathf.Max(0, Mathf.FloorToInt(seconds));
        int hours = total / 3600;
        int minutes = total % 3600 / 60;
        int secs = total % 60;
        return $"{hours:00}:{minutes:00}:{secs:00}";
    }

    private static string FormatRunPlayTime(float activeRunSeconds)
    {
        string value = Format(
            LocalizationKeys.GameClear.StatsPlayTimeFormat,
            FormatTime(activeRunSeconds),
            string.Empty);
        int sessionSeparator = value.IndexOf(" / ", StringComparison.Ordinal);
        return sessionSeparator >= 0 ? value.Substring(0, sessionSeparator) : value;
    }

    private static string Localize(string key)
        => LocalizationManager.HasInstance && LocalizationManager.Instance.HasKey(key)
            ? LocalizationManager.Instance.Get(key)
            : key ?? string.Empty;

    private static string Format(string key, params object[] args)
    {
        if (LocalizationManager.HasInstance && LocalizationManager.Instance.HasKey(key))
            return LocalizationManager.Instance.Get(key, args);
        return key ?? string.Empty;
    }
}
