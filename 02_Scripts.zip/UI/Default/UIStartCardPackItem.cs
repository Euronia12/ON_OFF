using System;
using System.Collections;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

/// <summary>Start 카드팩 하나의 표시, 선택 체크, 호버 피드백을 담당한다.</summary>
public sealed class UIStartCardPackItem : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler
{
    private const string SheenEffectName = "SheenEffect";
    private const string SheenStateName = "sheen";
    private const float LockedAlpha = 0.45f;

    [Header("구성")]
    [SerializeField] private Button _selectButton;
    [SerializeField] private RectTransform _visualRoot;
    [SerializeField] private GameObject _selectionMark;

    private Action<UIStartCardPackItem> _onClicked;
    private Action<UIStartCardPackItem> _onHovered;
    private Action<UIStartCardPackItem> _onHoverExited;
    private Action<UIStartCardPackItem> _onInfoHovered;
    private Action<UIStartCardPackItem, bool> _onInfoHoverClosed;
    private GameObject _visualInstance;
    private UIHoverIntentSource _infoHover;
    private GameObject _selectionHighlight;
    private GameObject _sheenEffect;
    private Animator _sheenAnimator;
    private Coroutine _sheenRoutine;
    private float _sheenDuration;
    private bool _pointerInside;

    public StartCardPackSO Data { get; private set; }
    public RectTransform RectTransform => transform as RectTransform;

    public bool TryGetOpeningTargets(
        out RectTransform packVisual,
        out RectTransform detachedSide,
        out RedPaperSeparationCutter cutter)
    {
        packVisual = _visualInstance != null
            ? _visualInstance.transform.Find("TestTeaseCard") as RectTransform
            : null;
        detachedSide = packVisual != null
            ? packVisual.Find("RightSide (1)") as RectTransform
            : null;
        cutter = packVisual != null ? packVisual.GetComponent<RedPaperSeparationCutter>() : null;
        return packVisual != null && detachedSide != null && cutter != null;
    }

    private void Awake()
    {
        _selectButton?.onClick.AddListener(HandleClick);
    }

    public void Bind(
        StartCardPackSO data,
        Action<UIStartCardPackItem> onClicked,
        Action<UIStartCardPackItem> onHovered,
        Action<UIStartCardPackItem> onHoverExited,
        UIHoverIntentTooltip infoTooltip,
        Action<UIStartCardPackItem> onInfoHovered,
        Action<UIStartCardPackItem, bool> onInfoHoverClosed)
    {
        Data = data;
        _onClicked = onClicked;
        _onHovered = onHovered;
        _onHoverExited = onHoverExited;
        _onInfoHovered = onInfoHovered;
        _onInfoHoverClosed = onInfoHoverClosed;
        if (_selectButton != null)
            _selectButton.interactable = data != null && data.IsUnlocked;

        StopSheenEffect();
        if (_visualInstance != null)
            Destroy(_visualInstance);

        _selectionHighlight = null;
        _infoHover = null;
        _sheenEffect = null;
        _sheenAnimator = null;
        _sheenDuration = 0f;
        if (data != null && data.VisualPrefab != null && _visualRoot != null)
        {
            _visualInstance = Instantiate(data.VisualPrefab, _visualRoot, false);
            CanvasGroup visualGroup = _visualInstance.GetComponent<CanvasGroup>();
            if (visualGroup == null)
                visualGroup = _visualInstance.AddComponent<CanvasGroup>();
            visualGroup.alpha = data.IsUnlocked ? 1f : LockedAlpha;

            _selectionHighlight = _visualInstance.transform.Find("Highlight")?.gameObject;
            _infoHover = _visualInstance.GetComponentInChildren<UIHoverIntentSource>(true);
            _infoHover?.Bind(
                infoTooltip,
                () =>
                {
                    PlaySheenEffect();
                    _onInfoHovered?.Invoke(this);
                },
                () =>
                {
                    if (!_pointerInside)
                        StopSheenEffect();
                    _onInfoHoverClosed?.Invoke(this, _pointerInside);
                });

            Transform sheenTransform = _visualInstance.transform.Find(SheenEffectName);
            if (sheenTransform != null)
            {
                _sheenEffect = sheenTransform.gameObject;
                _sheenAnimator = _sheenEffect.GetComponent<Animator>();
                RuntimeAnimatorController controller = _sheenAnimator != null
                    ? _sheenAnimator.runtimeAnimatorController
                    : null;
                if (controller != null)
                {
                    AnimationClip clip = Array.Find(controller.animationClips, item => item.name == SheenStateName);
                    if (clip != null)
                        _sheenDuration = clip.length;
                }

                _sheenEffect.SetActive(false);
            }
        }

        SetSelected(false);
    }

    public void SetSelected(bool selected)
    {
        selected = selected && Data != null && Data.IsUnlocked;

        if (_selectionMark != null)
            _selectionMark.SetActive(selected);

        if (_selectionHighlight != null)
            _selectionHighlight.SetActive(selected);
    }

    public void OnPointerEnter(PointerEventData eventData)
    {
        _pointerInside = true;
        if (eventData?.pointerEnter != null &&
            eventData.pointerEnter.GetComponentInParent<UIHoverIntentSource>() != null)
            return;

        PlaySheenEffect();
        _onHovered?.Invoke(this);
    }

    public void OnPointerExit(PointerEventData eventData)
    {
        _pointerInside = false;
        StopSheenEffect();
        _onHoverExited?.Invoke(this);
    }

    public void SetInfoCircleVisible(bool visible)
    {
        if (_infoHover != null)
            _infoHover.gameObject.SetActive(visible);
    }

    private void HandleClick()
    {
        if (Data != null && Data.IsUnlocked)
            _onClicked?.Invoke(this);
    }

    private void OnDisable()
    {
        _pointerInside = false;
        StopSheenEffect();
    }

    private void PlaySheenEffect()
    {
        if (Data == null || !Data.IsUnlocked) return;
        if (_sheenEffect == null || _sheenAnimator == null || _sheenDuration <= 0f) return;

        StopSheenEffect();
        _sheenEffect.SetActive(true);
        _sheenAnimator.Play(SheenStateName, 0, 0f);
        _sheenRoutine = StartCoroutine(HideSheenAfterPlayback());
    }

    private IEnumerator HideSheenAfterPlayback()
    {
        yield return new WaitForSeconds(_sheenDuration);
        _sheenRoutine = null;
        if (_sheenEffect != null)
            _sheenEffect.SetActive(false);
    }

    private void StopSheenEffect()
    {
        if (_sheenRoutine != null)
        {
            StopCoroutine(_sheenRoutine);
            _sheenRoutine = null;
        }

        if (_sheenEffect != null)
            _sheenEffect.SetActive(false);
    }

    private void OnDestroy()
    {
        StopSheenEffect();
        _infoHover?.Unbind();
        _selectButton?.onClick.RemoveListener(HandleClick);
        _onClicked = null;
        _onHovered = null;
        _onHoverExited = null;
        _onInfoHovered = null;
        _onInfoHoverClosed = null;
    }
}
