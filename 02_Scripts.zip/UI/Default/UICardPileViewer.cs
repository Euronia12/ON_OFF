// =================================================================
// [스크립트 목적]  전투 카드 더미 또는 전체 카드 도감을 보기 전용 팝업으로 표시
// [주요 변수]      - _contentRoot   : 카드 타일이 들어갈 부모
//                  - _cardViewPrefab: 보기 전용 카드 앞면+설명 타일
// [의존 관계]      - UIPopupBase / BattleController / UICardDetailView
// [배치]           UIManager 로 여는 Popup. 키 = 타입 이름(UICardPileViewer).
//                  씬에 상주시키지 말고 프리팹으로 등록 (열 때 Instantiate).
// [원칙]           열기는 UIBattle 이 OpenAsync 로 수행하며, 직전에 Show 로
//                  대상 더미를 지정. 닫기는 UIPopupBase 가 ESC/딤/X 로 일원화.
// =================================================================

using System;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// 전투 카드 더미와 타이틀 카드 도감을 동일한 읽기 전용 UI로 표시한다.
/// </summary>
public sealed class UICardPileViewer : UIPopupBase
{
    /// <summary>전투 중 열람 전용 뷰어 — ESC 로 닫고 전투 화면으로 돌아간다.</summary>
    public override bool CloseOnEscape => true;


    private enum EPileView
    {
        Draw,
        Discard,
        Exhaust,
        Collection,
    }

    [Header("카드 표시")]
    [Tooltip("카드 타일이 들어갈 부모")]
    [SerializeField] private Transform _contentRoot;

    [Tooltip("보기 전용 카드 앞면+설명 타일 프리팹")]
    [SerializeField] private UICardDetailView _cardViewPrefab;

    [Tooltip("카드 호버 시 키워드 설명을 띄우는 공유 패널. 비우면 표시 생략")]
    [SerializeField] private UIKeywordPanel _keywordPanel;

    [Header("고정 텍스트")]
    [Tooltip("돌아가기 버튼 텍스트")]
    [SerializeField] private TMP_Text _backButtonText;

    [Header("도감")]
    [Tooltip("도감 모드에서만 표시하는 제목/정렬 영역")]
    [SerializeField] private GameObject _collectionToolbar;

    [SerializeField] private TMP_Text _collectionTitleText;
    [SerializeField] private Button _reverseButton;
    [SerializeField] private TMP_Text _reverseButtonText;
    [SerializeField] private ScrollRect _scrollRect;

    private readonly List<UICardDetailView> _spawnedViews = new List<UICardDetailView>(32);
    private bool _reverseCollectionOrder;

    // OpenAsync 가 인자를 받지 못하므로, 열기 직전에 대상 더미를 정적으로 전달.
    private static EPileView s_pendingView;

    /// <summary>드로우 더미 목록으로 열도록 예약 (UIBattle 이 OpenAsync 직전 호출).</summary>
    public static void ShowDrawPile() => s_pendingView = EPileView.Draw;

    /// <summary>디스카드 더미 목록으로 열도록 예약 (UIBattle 이 OpenAsync 직전 호출).</summary>
    public static void ShowDiscardPile() => s_pendingView = EPileView.Discard;
    public static void ShowExhaustPile() => s_pendingView = EPileView.Exhaust;
    public static void ShowCollection() => s_pendingView = EPileView.Collection;

    public event Action OnClosed;

    protected override void Init()
    {
        RefreshLocalizedTexts();
        _reverseButton?.onClick.AddListener(HandleReverseClicked);
    }

    public override void OnLocalize()
    {
        base.OnLocalize();
        RefreshLocalizedTexts();
    }

    private void RefreshLocalizedTexts()
    {
        if (_backButtonText != null)
            _backButtonText.text = Localize(LocalizationKeys.Common.Back);
        if (_collectionTitleText != null)
            _collectionTitleText.text = Localize(LocalizationKeys.Collection.Title);
        if (_reverseButtonText != null)
            _reverseButtonText.text = Localize(LocalizationKeys.Collection.ReverseSort);
    }

    private static string Localize(string key)
    {
        return LocalizationManager.HasInstance
            ? LocalizationManager.Instance.Get(key)
            : key;
    }

    /// <summary>열 때마다 예약된 더미의 현재 카드 목록을 다시 구성.</summary>
    protected override void Setup()
    {
        _reverseCollectionOrder = false;
        bool collectionMode = s_pendingView == EPileView.Collection;
        if (_collectionToolbar != null)
            _collectionToolbar.SetActive(collectionMode);

        if (collectionMode)
            RebuildCollection();
        else
            Rebuild(GetCards(s_pendingView));

        ResetScrollPosition();
    }

    public override void OnClose()
    {
        // 카드 위에서 닫히면 OnPointerExit 이 오지 않아 키워드 패널(alpha 토글)이 남는다.
        if (_keywordPanel != null) _keywordPanel.Hide();

        Clear();
        base.OnClose();
        OnClosed?.Invoke();
    }

    private IReadOnlyList<Card> GetCards(EPileView view)
    {
        if (!BattleController.HasInstance)
        {
            return System.Array.Empty<Card>();
        }

        BattleController battle = BattleController.Instance;
        switch (view)
        {
            case EPileView.Draw:
                return battle.GetDrawPileCards();
            case EPileView.Exhaust:
                return battle.GetExhaustPileCards();
            default:
                return battle.GetDiscardPileCards();
        }
    }

    private void Rebuild(IReadOnlyList<Card> cards)
    {
        Clear();

        if (_cardViewPrefab == null || _contentRoot == null || cards == null)
        {
            return;
        }

        for (int i = 0; i < cards.Count; i++)
        {
            Card card = cards[i];
            if (card == null) continue;

            UICardDetailView view = Instantiate(_cardViewPrefab, _contentRoot);
            view.Setup(card);

            AttachKeywordHover(view, card);
            _spawnedViews.Add(view);
        }
    }

    private void RebuildCollection()
    {
        Clear();
        if (_cardViewPrefab == null || _contentRoot == null ||
            !DataManager.HasInstance || !DataManager.Instance.IsLoaded)
            return;

        List<CardDataSO> entries = DataManager.Instance.GetAllData<CardDataSO>();
        entries.RemoveAll(data => data == null || data.DeckType == EStartingDeck.None);
        int direction = _reverseCollectionOrder ? -1 : 1;
        entries.Sort((left, right) =>
        {
            int rarity = left.Rarity.CompareTo(right.Rarity);
            if (rarity != 0)
                return rarity * direction;
            return StringComparer.Ordinal.Compare(left.CardId, right.CardId) * direction;
        });

        for (int i = 0; i < entries.Count; i++)
        {
            Card card = CardFactory.CreatePreviewFromSO(entries[i]);
            if (card == null)
                continue;

            UICardDetailView view = Instantiate(_cardViewPrefab, _contentRoot);
            view.Setup(card);
            AttachKeywordHover(view, card);
            _spawnedViews.Add(view);
        }
    }

    private void AttachKeywordHover(UICardDetailView view, Card card)
    {
        if (_keywordPanel == null)
            return;

        UICardKeywordHover hover = view.GetComponent<UICardKeywordHover>();
        if (hover == null)
            hover = view.gameObject.AddComponent<UICardKeywordHover>();
        hover.Set(_keywordPanel, card);
    }

    private void HandleReverseClicked()
    {
        if (s_pendingView != EPileView.Collection)
            return;

        _reverseCollectionOrder = !_reverseCollectionOrder;
        RebuildCollection();
        ResetScrollPosition();
    }

    private void ResetScrollPosition()
    {
        if (_scrollRect != null)
            _scrollRect.verticalNormalizedPosition = 1f;
    }

    private void Clear()
    {
        for (int i = 0; i < _spawnedViews.Count; i++)
        {
            UICardDetailView view = _spawnedViews[i];
            if (view == null) continue;

            Destroy(view.gameObject);
        }

        _spawnedViews.Clear();
    }

    private void OnDestroy()
    {
        _reverseButton?.onClick.RemoveListener(HandleReverseClicked);
        OnClosed = null;
    }
}
