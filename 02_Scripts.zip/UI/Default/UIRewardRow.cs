// =================================================================
// [스크립트 목적]  통합 보상창("전리품!")의 리스트 한 줄(Row). 보상 항목 1개를
//                 아이콘 + 라벨로 보여주는 순수 표시용 행.
// [주요 변수]      - _icon/_label : 항목 표시 요소
//                  - _kindIcons   : 종류별 아이콘 (Gold/Card …) — 인스펙터 배정
// [의존 관계]      - BattleRewardItem / EBattleRewardKind / UIRewardPopup(부모가 항목 수만큼 생성)
// [배치]           보상 행 프리팹에 부착. UIRewardPopup 이 항목 수만큼 Instantiate.
//                  ※ 클릭 감지는 자식 Bg(Image, RaycastTarget)가 받아 이 컴포넌트로 버블링.
// [설계 노트]      - 수령 흐름 두 가지 공존: "계속" 버튼 일괄 수령 + 행 클릭 개별 수령.
//                    행은 표시 + 클릭 통지만 담당하고, 실제 수령 로직(골드 적립/카드 1택)은
//                    UIRewardPopup 이 처리한다. 수령 완료 행은 클릭을 무시한다.
// =================================================================

using System;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

/// <summary>
/// 전리품 리스트의 한 줄. BattleRewardItem 을 받아 종류에 맞게 표시하고,
/// 미수령 상태에서 클릭되면 부모(UIRewardPopup)에 개별 수령을 요청한다.
/// </summary>
public sealed class UIRewardRow : MonoBehaviour, IPointerClickHandler
{
    [Header("표시 요소")]
    [Tooltip("종류 아이콘 (Gold/Card …)")]
    [SerializeField] private Image _icon;

    [Tooltip("항목 이름/설명 라벨")]
    [SerializeField] private TMP_Text _label;

    [Header("종류별 아이콘 (인덱스 = EBattleRewardKind)")]
    [Tooltip("Gold/Card/GridExpansion 순서로 배정. 누락 시 아이콘 비활성")]
    [SerializeField] private Sprite[] _kindIcons;

    [Header("라벨 텍스트 (로컬라이즈 키로 교체 가능)")]
    [Tooltip("골드 라벨 로컬라이징 키. \"{0}\" 가 있으면 수량이 들어감")]
    [SerializeField] private string _goldLabelKey = "UI_COMMON_GOLD_AMOUNT_FORMAT";
    [SerializeField] private string _cardLabelKey = "UI_REWARD_CARD_ADD";
    [SerializeField] private string _gridExpansionLabelKey = "UI_REWARD_GRID_EXPANSION";

    private BattleRewardItem _item;

    /// <summary>이 행이 현재 표현 중인 보상 항목.</summary>
    public BattleRewardItem Item => _item;

    /// <summary>미수령 행 좌클릭 → 개별 수령 요청. 부모(UIRewardPopup)가 구독.</summary>
    public event Action<UIRewardRow> OnClaimRequested;

    /// <summary>행 클릭 — 미수령 항목만 부모에 수령 요청을 올린다.</summary>
    public void OnPointerClick(PointerEventData eventData)
    {
        if (eventData.button != PointerEventData.InputButton.Left) return;
        if (_item == null || _item.Claimed) return;

        OnClaimRequested?.Invoke(this);
    }

    /// <summary>항목 바인딩. 부모(UIRewardPopup)가 행 생성 직후 1회 호출.</summary>
    public void Bind(BattleRewardItem item)
    {
        _item = item;
        Refresh();
    }

    /// <summary>표시 갱신 (종류별 아이콘/라벨). 언어 변경 시 부모(UIRewardPopup)가 다시 호출.</summary>
    public void Refresh()
    {
        if (_item == null) return;

        ApplyIcon(_item.Kind);
        ApplyText(_item);
    }

    private void ApplyIcon(EBattleRewardKind kind)
    {
        if (_icon == null) return;

        int idx = (int)kind;
        Sprite sprite = (_kindIcons != null && idx >= 0 && idx < _kindIcons.Length)
            ? _kindIcons[idx]
            : null;

        _icon.sprite = sprite;
        _icon.enabled = sprite != null;
    }

    private void ApplyText(BattleRewardItem item)
    {
        switch (item.Kind)
        {
            case EBattleRewardKind.Gold:
                // 슬더스식 — "37 골드" 처럼 수량+라벨을 한 덩어리로 표시.
                SetLabel(FormatGold(item.GoldAmount));
                break;

            case EBattleRewardKind.Card:
                SetLabel(Localize(_cardLabelKey));
                break;

            case EBattleRewardKind.GridExpansion:
                SetLabel(Localize(_gridExpansionLabelKey));
                break;

            default:
                SetLabel(item.Kind.ToString());
                break;
        }
    }

    /// <summary>"{0} 골드" 포맷에 수량을 끼워 "37 골드" 형태로 만든다.</summary>
    private string FormatGold(int amount)
    {
        string goldLabel = Localize(_goldLabelKey);

        // _goldLabel 에 "{0}" 가 있으면 수량을 끼우고, 없으면 "수량 라벨" 로 결합.
        if (!string.IsNullOrEmpty(goldLabel) && goldLabel.Contains("{0}"))
        {
            return string.Format(goldLabel, amount);
        }
        return $"{amount} {goldLabel}";
    }

    private static string Localize(string key)
    {
        return LocalizationManager.HasInstance
            ? LocalizationManager.Instance.Get(key)
            : key;
    }

    private void SetLabel(string text)
    {
        if (_label != null) _label.text = text;
    }

    private void OnDestroy()
    {
        _item = null;
        OnClaimRequested = null;
    }
}
