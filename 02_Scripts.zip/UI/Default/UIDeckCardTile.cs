// =================================================================
// [스크립트 목적]  덱 카드 선택 타일 1칸. 카드를 표시하고 클릭하면 콜백으로 알린다(+hover 확대).
//                 카드 제거/강화/이벤트 등 "덱에서 1장 고르기" UI(UIDeckCardPicker)의 셀.
// [주요 변수]      - _detailView : 카드 앞면+설명 표시 뷰(재사용)
//                  - _clickButton: 타일 클릭 버튼
// [의존 관계]      - UICardDetailView / Card / UIDeckCardPicker(부모가 콜백 구독) / DG.Tweening
// [배치]           덱 카드 타일 프리팹에 부착. UIDeckCardPicker 가 덱 장수만큼 Instantiate.
// [설계 노트]      - UICardDetailView 는 표시 전용(클릭 없음)이라, 클릭/hover 를 이 타일이 얹는다.
//                  - 타일은 "표시·클릭 통지"만. 실제 처리(제거 등)는 피커→호출부(상점 등).
//                  - 어떤 카드인지는 인덱스로 식별 — 피커가 클릭 콜백에 인덱스를 실어 구독한다.
// =================================================================

using System;
using DG.Tweening;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

/// <summary>
/// 덱 카드 선택 타일. 카드를 표시하고 클릭 시 콜백으로 부모(UIDeckCardPicker)에 알린다.
/// </summary>
public sealed class UIDeckCardTile : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler
{
    [Header("구성")]
    [Tooltip("카드 앞면+설명을 표시하는 뷰")]
    [SerializeField] private UICardDetailView _detailView;
    [SerializeField] private Button _clickButton;

    [Header("Hover")]
    [SerializeField] private float _hoverScale = 1.06f;
    [SerializeField] private float _hoverDuration = 0.12f;
    [SerializeField] private Transform _hoverTarget;

    private Action _onClicked;
    private bool _bound;

    private Transform Target => _hoverTarget != null ? _hoverTarget : transform;
    private Vector3 _baseScale = Vector3.one;
    private Tween _hoverTween;
    private bool _interactable = true;
    private bool _clickable = true;    // 클릭 전용 허용 플래그. 열람 모드는 false (hover는 유지)

    private UIKeywordPanel _keywordPanel;     // 부모(UIDeckCardPicker)가 주입
    private Card _card;

    private void Awake()
    {
        _baseScale = Target.localScale;
    }

    /// <summary>카드 표시 + 클릭 콜백 연결 (피커가 타일 생성 직후 1회 호출).</summary>
    public void Bind(Card card, Action onClicked)
    {
        _onClicked = onClicked;

        if (!_bound && _clickButton != null)
        {
            _clickButton.onClick.AddListener(HandleClick);
            _bound = true;
        }

        if (_detailView != null && card != null) _detailView.Setup(card);
        _card = card;

        _interactable = true;
        _clickable = true;
        ResetHover();
    }

    /// <summary>부모(UIDeckCardPicker)가 공유 키워드 패널을 주입.</summary>
    public void SetKeywordPanel(UIKeywordPanel panel) => _keywordPanel = panel;

    /// <summary>부모(UIDeckCardPicker)가 클릭 허용 여부 주입. 열람 모드는 false (hover는 유지).</summary>
    public void SetClickable(bool clickable) => _clickable = clickable;

    public void SetInteractable(bool interactable)
    {
        _interactable = interactable;
        if (_clickButton != null) _clickButton.interactable = interactable;
        if (!interactable)
        {
            ResetHover();
            _keywordPanel?.Hide();
        }
    }

    public Tween PlayArrowStamp(ECardDirection direction)
    {
        UICardFrontView front = _detailView != null
            ? _detailView.GetComponentInChildren<UICardFrontView>(true)
            : null;
        return front?.PlayArrowStamp(direction);
    }

    // ── Hover ──
    public void OnPointerEnter(PointerEventData eventData)
    {
        if (!_interactable) return;
        AnimateScale(_baseScale * _hoverScale);

        if (_keywordPanel != null)
        {
            _keywordPanel.MoveTo(transform as RectTransform);
            _keywordPanel.Show(_card);
        }
    }

    public void OnPointerExit(PointerEventData eventData)
    {
        AnimateScale(_baseScale);
        if (_keywordPanel != null) _keywordPanel.Hide();
    }

    private void AnimateScale(Vector3 target)
    {
        _hoverTween?.Kill();
        _hoverTween = Target.DOScale(target, _hoverDuration).SetEase(Ease.OutQuad);
    }

    private void ResetHover()
    {
        _hoverTween?.Kill();
        _hoverTween = null;
        Target.localScale = _baseScale;
    }

    private void HandleClick()
    {
        if (!_clickable) return;    // 열람 모드 — 클릭 무시(hover는 유지)
        if (!_interactable) return;
        _interactable = false; // 연속 클릭 방지 (선택 즉시 피커가 닫음)
        Target.DOKill();
        Target.localScale = _baseScale;
        _onClicked?.Invoke();
    }

    private void OnDestroy()
    {
        _hoverTween?.Kill();
        if (Target != null) Target.DOKill();
        if (_clickButton != null) _clickButton.onClick.RemoveListener(HandleClick);
        _onClicked = null;
    }
}
