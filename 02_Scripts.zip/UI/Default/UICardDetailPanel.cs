// =================================================================
// [스크립트 목적]  카드 호버 시 화면 고정 위치(예: 좌상단)에 카드 상세를 크게 보여주는
//                 확대본 패널. 손패/그리드 공용. 카드 내용 그리기는 UICardDetailView 에 위임하고,
//                 이 클래스는 표시/숨김(CanvasGroup) 만 담당한다.
// [주요 변수]      - _detailView   : 카드 앞면+설명을 그리는 재사용 뷰
//                  - _keywordPanel : 키워드 설명을 그리는 공유 패널(UIKeywordPanel) — 위임
//                  - _canvasGroup  : 표시 토글 + 레이캐스트 차단(깜빡임 방지)
// [의존 관계]      - UICardDetailView / UIKeywordPanel(재사용) / Card
//                  - GridCardHoverProbe(그리드)가 ShowAt/Hide 호출 (손패는 더 이상 안 띄움)
// [배치]           Screen Space Canvas 자식. 평소 숨김(alpha 0), 그리드 카드 호버 시 표시.
// [설계 노트]      - ShowAt: 호버한 그리드 카드의 스크린 위치 + 오프셋(오른쪽 상단)에 패널을 둔다.
//                  - 표시 토글은 CanvasGroup.alpha 로 (SetActive 토글 시 비용·타이밍 회피).
//                    blocksRaycasts=false 로 호버 깜빡임도 원천 차단(마우스 통과).
//                  - 앞면/설명은 UICardDetailView, 키워드는 UIKeywordPanel 에 위임 — 중복 제거.
//                    (키워드 표시 로직을 손패/상점 등과 한 프리팹으로 통일)
// =================================================================

using UnityEngine;

/// <summary>
/// 카드 호버 시 고정 위치에 뜨는 큰 상세 확대본.
/// 내용은 UICardDetailView 가 그리고, 이 클래스는 표시/숨김만 담당한다.
/// </summary>
public sealed class UICardDetailPanel : MonoBehaviour
{
    [Header("표시")]
    [Tooltip("표시 토글 + 레이캐스트 차단용. 비우면 자동 추가")]
    [SerializeField] private CanvasGroup _canvasGroup;

    [Header("카드 상세")]
    [Tooltip("카드 앞면+설명+키워드를 그리는 재사용 뷰")]
    [SerializeField] private UICardDetailView _detailView;

    [Header("키워드")]
    [Tooltip("키워드 설명을 그리는 공유 패널(UIKeywordPanel). 디테일 카드 아래 자식으로 두고 위임. " +
             "비우면 키워드 표시 생략. 키워드 없으면 패널이 알아서 숨는다")]
    [SerializeField] private UIKeywordPanel _keywordPanel;

    [Header("그리드 호버 위치")]
    [Tooltip("그리드 카드 호버 시(ShowAt) 카드에서 띄우는 간격(px). X는 항상 오른쪽. " +
             "Y는 카드가 화면 아래쪽이면 위로, 위쪽이면 아래로 자동 반전. 코너 피벗 기준이라 " +
             "값이 크면 카드에서 멀어진다 — 작은 간격(20~40) 권장.")]
    [SerializeField] private Vector2 _gridHoverOffset = new Vector2(24f, 24f);

    private RectTransform _rectTransform;
    private RectTransform _parentRect;
    private Canvas _canvas;

    // 현재 피벗이 화면 아래쪽 기준(우상단 펼침)인지. null = 미설정 → 첫 배치 시 강제 대입.
    private bool? _isPivotBelow;

    // ── 갱신 가드 ──────────────────────────────────────────
    // 호버 프로브가 매 프레임 ShowAt 을 부르므로, 내용이 그대로면 재구성을 건너뛴다.
    // (Populate 는 설명 문자열 재생성 + TMP 메시 재빌드를 유발 — 매 프레임 돌 이유가 없다)
    // 무효화 신호:
    //   - 카드 교체            : _boundCard 비교
    //   - 그리드 상태 변화     : GridManager.ActivationVersion (배치·회수·ON/OFF 토글)
    //   - 스탯 버프/디버프     : card.Stats.OnChanged → _isDirty (버전이 오르지 않는 경로)
    private Card _boundCard;
    private int _boundActivationVersion = -1;
    private bool _isDirty;

    private void Awake()
    {
        if (_canvasGroup == null)
        {
            _canvasGroup = GetComponent<CanvasGroup>();
            if (_canvasGroup == null) _canvasGroup = gameObject.AddComponent<CanvasGroup>();
        }

        _rectTransform = transform as RectTransform;
        _parentRect = _rectTransform != null ? _rectTransform.parent as RectTransform : null;
        _canvas = GetComponentInParent<Canvas>();

        Hide();
    }

    /// <summary>카드 데이터로 채우고, 주어진 스크린 위치 기준(오프셋 적용)으로 표시한다. (그리드 카드 호버용)</summary>
    public void ShowAt(Card card, CardStatCalculator calculator, Vector2 screenPosition)
    {
        if (!Populate(card, calculator)) return;

        PositionAtScreen(screenPosition);
        Reveal();
    }

    /// <summary>
    /// 카드 앞면·설명·키워드를 채운다. card 가 null 이면 숨기고 false 반환.
    /// 같은 카드 + 같은 그리드 버전 + 스탯 변화 없음이면 재구성을 건너뛴다(매 프레임 호출 대비).
    /// </summary>
    private bool Populate(Card card, CardStatCalculator calculator)
    {
        if (card == null)
        {
            Unbind();
            Hide();
            return false;
        }

        int version = GridManager.HasInstance ? GridManager.Instance.ActivationVersion : 0;
        if (!_isDirty && card == _boundCard && version == _boundActivationVersion)
        {
            return true; // 표시 내용 동일 — 위치 갱신만 하고 끝낸다.
        }

        Bind(card);
        _boundActivationVersion = version;
        _isDirty = false;

        if (_detailView != null)
        {
            _detailView.Setup(card, calculator);
        }

        // 키워드 표시는 공유 패널에 위임 (없으면 패널이 스스로 숨음).
        if (_keywordPanel != null) _keywordPanel.Show(card);
        return true;
    }

    /// <summary>표시 중인 카드의 스탯 변화를 구독한다 (버프로 수치가 바뀌면 다시 그려야 하므로).</summary>
    private void Bind(Card card)
    {
        if (_boundCard == card) return;

        Unbind();
        _boundCard = card;
        if (_boundCard?.Stats != null)
        {
            _boundCard.Stats.OnChanged += HandleBoundCardStatsChanged;
        }
    }

    /// <summary>스탯 구독 해제. 카드 교체·숨김·파괴 시 반드시 호출 (죽은 카드 참조 방지).</summary>
    private void Unbind()
    {
        if (_boundCard?.Stats != null)
        {
            _boundCard.Stats.OnChanged -= HandleBoundCardStatsChanged;
        }

        _boundCard = null;
        _boundActivationVersion = -1;
        _isDirty = false;
    }

    /// <summary>버프·디버프로 수치가 바뀜 — 다음 ShowAt 에서 한 번만 다시 그린다.</summary>
    private void HandleBoundCardStatsChanged()
    {
        _isDirty = true;
    }

    private void OnDisable()
    {
        Unbind();
    }

    private void OnDestroy()
    {
        Unbind();
    }

    private void Reveal()
    {
        _canvasGroup.alpha = 1f;
        _canvasGroup.blocksRaycasts = false; // 마우스가 통과해 카드 호버 유지 (깜빡임 방지).
    }

    /// <summary>
    /// 스크린 좌표를 부모 로컬 좌표로 변환해 패널을 그 위치(+오프셋)에 둔다.
    /// 화면 세로 중앙 기준: 마우스가 아래쪽이면 우상단, 위쪽이면 좌하단으로 펼치도록
    /// 피벗과 오프셋을 반대편으로 잡아 패널이 화면 안쪽으로 자라게 한다.
    /// </summary>
    private void PositionAtScreen(Vector2 screenPosition)
    {
        if (_rectTransform == null || _parentRect == null) return;

        Camera uiCamera = (_canvas != null && _canvas.renderMode != RenderMode.ScreenSpaceOverlay)
            ? _canvas.worldCamera
            : null;

        if (!RectTransformUtility.ScreenPointToLocalPointInRectangle(
                _parentRect, screenPosition, uiCamera, out Vector2 localPoint))
        {
            return;
        }

        // 화면 세로 중앙 기준. 둘 다 오른쪽으로 펼치고 세로 방향만 뒤집는다.
        // 아래쪽: 피벗 좌하단(0,0) → 패널이 마우스 우상단으로. 오프셋 Y = 위로(+).
        // 위쪽:   피벗 좌상단(0,1) → 패널이 마우스 우하단으로. 오프셋 Y = 아래로(-).
        bool isBelowCenter = screenPosition.y < Screen.height * 0.5f;

        // 피벗은 위/아래가 바뀔 때만 대입 (매 프레임 setter 호출 + 내부 dirty 방지).
        if (_isPivotBelow != isBelowCenter)
        {
            _isPivotBelow = isBelowCenter;
            _rectTransform.pivot = isBelowCenter ? new Vector2(0f, 0f) : new Vector2(0f, 1f);
        }

        // X는 항상 오른쪽(+). Y는 아래쪽이면 위로(+), 위쪽이면 아래로(-).
        Vector2 offset = new Vector2(
            _gridHoverOffset.x,
            isBelowCenter ? _gridHoverOffset.y : -_gridHoverOffset.y);
        _rectTransform.anchoredPosition = localPoint + offset;
    }

    /// <summary>확대본 숨기기.</summary>
    public void Hide()
    {
        // 숨기는 동안 카드가 그리드를 떠날 수 있다 — 구독을 남기지 않는다(죽은 카드 참조 방지).
        // 다시 호버하면 그때 한 번 재구성된다.
        Unbind();

        if (_keywordPanel != null) _keywordPanel.Hide();
        if (_canvasGroup != null)
        {
            _canvasGroup.alpha = 0f;
            _canvasGroup.blocksRaycasts = false;
        }
    }
}
