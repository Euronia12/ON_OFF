// =================================================================
// [스크립트 목적]  보상 카드 슬롯 1칸 (MonoBehaviour). 카드 뷰·클릭 버튼을 한 컴포넌트로 묶고,
//                 마우스 hover 시 살짝 확대되는 효과를 준다. (클릭 = 즉시 선택이라 선택 강조 없음)
// [주요 변수]      - _detailView   : 카드 앞면+설명 표시 뷰(재사용)
//                  - _selectButton : 선택 버튼 (카드 클릭 = 즉시 선택)
//                  - _hoverScale/_hoverDuration : hover 확대 배율·시간
// [의존 관계]      - UICardDetailView / Card / UICardSelectPopup(부모가 인덱스로 구독)
//                  - DG.Tweening(DOTween) — 프로젝트 트윈 공통 사용
// [배치]           보상 슬롯 프리팹에 부착. UICardSelectPopup 이 슬롯 배열로 보유.
// [설계 노트]      - 즉시 선택 방식이라 "선택 강조(_selectMark)"는 제거. 대신 hover 확대만 둔다.
//                  - hover 는 IPointerEnter/Exit 로 감지 (UI 위 포인터). 터치 환경에선
//                    hover 이벤트가 없으므로 효과가 안 보일 뿐, 클릭 동작에는 영향 없음.
//                  - 클릭 통지는 콜백(Action)으로 부모에 전달 — 슬롯은 표시·hover 만 책임.
// =================================================================

using System;
using DG.Tweening;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

/// <summary>
/// 보상 카드 슬롯 컴포넌트. 카드 뷰·클릭 버튼을 자기 자식으로 들고, hover 시 확대 효과를 준다.
/// 클릭 시 등록된 콜백으로 부모(UICardSelectPopup)에 알린다. 선택은 클릭 즉시 확정된다.
/// </summary>
public sealed class UIRewardCardSlot : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler
{
    [Header("슬롯 구성 (자식)")]
    [Tooltip("카드 앞면+설명 표시 뷰")]
    [SerializeField] private UICardDetailView _detailView;

    [Tooltip("선택 버튼 (카드 클릭 = 즉시 선택)")]
    [SerializeField] private Button _selectButton;

    [Header("Hover 효과")]
    [Tooltip("hover 시 확대 배율 (1 = 효과 없음)")]
    [SerializeField] private float _hoverScale = 1.08f;

    [Tooltip("확대/복귀 트윈 시간(초)")]
    [SerializeField] private float _hoverDuration = 0.12f;

    [Tooltip("hover 확대의 기준이 될 트랜스폼 (비우면 이 슬롯). 보통 카드 뷰 루트를 권장")]
    [SerializeField] private Transform _hoverTarget;

    [Header("등장 연출")]
    [Tooltip("카드 등장 순간의 흰 섬광")]
    [SerializeField] private CanvasGroup _revealFlash;

    [Tooltip("유니크·전설 카드 등장 후 재생할 광택 Animator")]
    [SerializeField] private Animator _sheenAnimator;

    // 클릭 통지 콜백 (부모가 Bind 로 주입).
    private Action _onClicked;
    private bool _bound;

    private Transform Target => _hoverTarget != null ? _hoverTarget : transform;
    private Vector3 _baseScale = Vector3.one;
    private Tween _hoverTween;
    private Tween _revealTween;
    private Tween _resolveTween;
    private Tween _sheenHideTween;
    private bool _interactable = true;

    private UIKeywordPanel _keywordPanel;     // 부모(UICardSelectPopup)가 주입
    private Card _card;

    private void Awake()
    {
        _baseScale = Target.localScale;
    }

    /// <summary>클릭 콜백 연결 (부모가 1회 호출). 버튼 리스너를 건다.</summary>
    public void Bind(Action onClicked)
    {
        _onClicked = onClicked;

        if (!_bound && _selectButton != null)
        {
            _selectButton.onClick.AddListener(HandleClick);
            _bound = true;
        }
    }

    /// <summary>슬롯 표시/숨김 + hover 상태 초기화.</summary>
    public void SetVisible(bool visible)
    {
        ResetPresentation();
        gameObject.SetActive(visible);
        if (visible)
            SetCardVisualVisible(true);
    }

    /// <summary>카드 데이터 표시.</summary>
    public void Show(Card card)
    {
        if (_detailView != null) _detailView.Setup(card);
        _card = card;
    }

    /// <summary>부모(UICardSelectPopup)가 공유 키워드 패널을 주입.</summary>
    public void SetKeywordPanel(UIKeywordPanel panel) => _keywordPanel = panel;

    /// <summary>등장 연출 중 카드 선택과 hover 입력을 함께 막는다.</summary>
    public void SetInteractable(bool interactable)
    {
        _interactable = interactable;
        if (_selectButton != null)
            _selectButton.interactable = interactable;

        if (!interactable)
        {
            _hoverTween?.Kill();
            Target.localScale = _baseScale;
        }
    }

    /// <summary>레이아웃 슬롯을 유지한 채 카드 본문만 숨겨 등장 연출을 준비한다.</summary>
    public void PrepareReveal()
    {
        ResetPresentation();
        SetCardVisualVisible(false);
    }

    /// <summary>목표 위치에서 카드 팝업과 흰 섬광을 재생한다.</summary>
    public void PlayReveal(float startScale, float duration, bool playSheen)
    {
        ResetPresentation();
        SetCardVisualVisible(true);

        Target.localScale = _baseScale * startScale;
        if (_revealFlash != null)
        {
            _revealFlash.gameObject.SetActive(true);
            _revealFlash.alpha = 1f;
        }

        Sequence sequence = DOTween.Sequence()
            .Append(Target.DOScale(_baseScale, duration).SetEase(Ease.OutBack))
            .SetUpdate(true);

        if (_revealFlash != null)
            sequence.Join(_revealFlash.DOFade(0f, Mathf.Min(duration, 0.12f)).SetEase(Ease.OutQuad));

        _revealTween = sequence.OnComplete(() =>
        {
            if (_revealFlash != null)
                _revealFlash.gameObject.SetActive(false);
            if (playSheen)
                PlaySheen();
        });
    }

    /// <summary>선택 확정 후 입력을 잠그고 선택/미선택 카드에 서로 다른 짧은 피드백을 준다.</summary>
    public void PlayResolveFeedback(bool selected, float duration)
    {
        SetInteractable(false);
        _resolveTween?.Kill();
        _resolveTween = null;
        Target.localScale = _baseScale;

        if (duration <= 0f) return;

        if (selected)
        {
            _resolveTween = DOTween.Sequence()
                .Append(Target.DOScale(_baseScale * 1.08f, duration * 0.45f).SetEase(Ease.OutQuad))
                .Append(Target.DOScale(_baseScale, duration * 0.55f).SetEase(Ease.InQuad))
                .SetUpdate(true);
        }
        else
        {
            _resolveTween = Target.DOScale(_baseScale * 0.92f, duration)
                .SetEase(Ease.InQuad)
                .SetUpdate(true);
        }
    }

    /// <summary>풀 재사용·팝업 닫힘 시 연출 상태를 기본값으로 되돌린다.</summary>
    public void ResetPresentation()
    {
        _revealTween?.Kill();
        _revealTween = null;
        _resolveTween?.Kill();
        _resolveTween = null;
        ResetHover();

        if (_revealFlash != null)
        {
            _revealFlash.alpha = 0f;
            _revealFlash.gameObject.SetActive(false);
        }

        StopSheen();
    }

    private void PlaySheen()
    {
        if (_sheenAnimator == null) return;

        StopSheen();
        _sheenAnimator.gameObject.SetActive(true);
        _sheenAnimator.Play("sheen", 0, 0f);

        RuntimeAnimatorController controller = _sheenAnimator.runtimeAnimatorController;
        if (controller == null) return;

        float duration = 0f;
        AnimationClip[] clips = controller.animationClips;
        for (int i = 0; i < clips.Length; i++)
        {
            if (clips[i] == null || clips[i].name != "sheen") continue;
            duration = clips[i].length;
            break;
        }

        if (duration > 0f)
        {
            _sheenHideTween = DOVirtual.DelayedCall(duration, StopSheen).SetUpdate(true);
        }
    }

    private void StopSheen()
    {
        _sheenHideTween?.Kill();
        _sheenHideTween = null;
        if (_sheenAnimator != null)
            _sheenAnimator.gameObject.SetActive(false);
    }

    private void SetCardVisualVisible(bool visible)
    {
        if (_detailView != null)
            _detailView.gameObject.SetActive(visible);
    }

    // ─────────────────────────────────────────────
    // Hover (IPointerEnter/Exit)
    // ─────────────────────────────────────────────

    public void OnPointerEnter(PointerEventData eventData)
    {
        if (!_interactable) return;
        AnimateScale(_baseScale * _hoverScale);

        if (_keywordPanel != null)
        {
            _keywordPanel.MoveTo(transform as RectTransform);
            _keywordPanel.Show(_card);
        }
    }

    public void OnPointerExit(PointerEventData eventData)
    {
        AnimateScale(_baseScale);
        if (_keywordPanel != null) _keywordPanel.Hide();
    }

    private void AnimateScale(Vector3 target)
    {
        _hoverTween?.Kill();
        _hoverTween = Target.DOScale(target, _hoverDuration).SetEase(Ease.OutQuad);
    }

    /// <summary>hover 트윈을 끄고 기본 크기로 즉시 복귀 (슬롯 재사용·숨김 시).</summary>
    private void ResetHover()
    {
        _hoverTween?.Kill();
        _hoverTween = null;
        Target.localScale = _baseScale;
        _interactable = true;
    }

    private void HandleClick()
    {
        if (!_interactable) return;

        // 즉시 선택 — 연속 클릭/닫히는 중 재입력 방지. 살짝 눌리는 피드백.
        _interactable = false;
        Target.DOKill();
        Target.localScale = _baseScale;

        _onClicked?.Invoke();
    }

    private void OnDestroy()
    {
        ResetPresentation();
        if (Target != null) Target.DOKill();
        if (_selectButton != null) _selectButton.onClick.RemoveListener(HandleClick);
        _onClicked = null;
    }
}
