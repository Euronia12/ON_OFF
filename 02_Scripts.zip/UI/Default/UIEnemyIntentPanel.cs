// =================================================================
// [스크립트 목적]  호버된 적 의도의 설명을 모아 보여주는 패널(슬더스식).
//                 의도 묶음(IReadOnlyList<EnemyIntent>)을 받아, 의도마다 항목을
//                 풀에서 스폰해 세로로 나열하고 표시/숨김(CanvasGroup)만 담당.
// [주요 변수]      - _canvasGroup : 표시 토글 + 레이캐스트 차단(호버 깜빡임 방지)
//                  - _entryPrefab : 항목 프리팹(UIEnemyIntentEntry)
//                  - _entryRoot   : 항목들이 붙는 컨테이너(VerticalLayoutGroup 권장)
// [의존 관계]      - UIEnemyIntentEntry / EnemyIntentInfo / PoolManager / EnemyIntent
//                  - UIEnemyIntentView 가 Show/Hide/MoveTo 호출 (호버된 의도 전달)
// [배치]           Screen Space Canvas 자식. 위치는 MoveTo(앵커)로 호버 칸에 맞춤.
// [설계 노트]      - UIKeywordPanel 과 동일 구조. 항목은 풀 스폰 → Hide 시 전량 회수.
//                  - 의도 없으면 표시하지 않는다(빈 패널 방지).
// =================================================================

using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

/// <summary>호버된 적 의도의 설명을 나열하는 패널. 내용은 항목이 그리고, 이 클래스는 구성·표시만.</summary>
public sealed class UIEnemyIntentPanel : MonoBehaviour
{
    [Header("표시")]
    [Tooltip("표시 토글 + 레이캐스트 차단용. 비우면 자동 추가")]
    [SerializeField] private CanvasGroup _canvasGroup;

    [Header("항목")]
    [Tooltip("의도 항목 프리팹(UIEnemyIntentEntry)")]
    [SerializeField] private UIEnemyIntentEntry _entryPrefab;

    [Tooltip("항목이 붙는 컨테이너. VerticalLayoutGroup 으로 세로 나열 권장. 비우면 이 오브젝트 사용")]
    [SerializeField] private RectTransform _entryRoot;

    [Header("위치")]
    [Tooltip("영역 왼쪽 변 중점 기준 픽셀 오프셋. X 음수=더 왼쪽, Y 양수=더 위. 인스펙터에서 미세조정")]
    [SerializeField] private Vector2 _offset = Vector2.zero;

    private readonly List<UIEnemyIntentEntry> _activeEntries = new();

    private void Awake()
    {
        if (_canvasGroup == null)
        {
            _canvasGroup = GetComponent<CanvasGroup>();
            if (_canvasGroup == null) _canvasGroup = gameObject.AddComponent<CanvasGroup>();
        }
        Hide();
    }

    /// <summary>의도 묶음으로 패널을 채우고 표시. 의도 없으면 숨긴 채 둔다.</summary>
    public void Show(IReadOnlyList<EnemyIntent> intents)
    {
        ClearEntries();

        int count = intents != null ? intents.Count : 0;
        if (count == 0 || _entryPrefab == null)
        {
            Hide();
            return;
        }

        Transform parent = EntryParent;
        bool anySpawned = false;
        for (int i = 0; i < count; i++)
        {
            UIEnemyIntentEntry entry = SpawnEntry(parent);
            if (entry == null) continue;

            entry.Setup(intents[i], resolveBeneficialAsSharedEffect: true);
            _activeEntries.Add(entry);
            anySpawned = true;
        }

        if (!anySpawned)
        {
            Hide();
            return;
        }

        _canvasGroup.alpha = 1f;
        _canvasGroup.blocksRaycasts = false; // 마우스 통과 → 의도 호버 유지(깜빡임 방지).
    }

    /// <summary>단일 의도의 설명을 표시.</summary>
    public void Show(
        in EnemyIntent intent,
        string nameKeyOverride = null,
        string descriptionKeyOverride = null)
    {
        ClearEntries();
        if (_entryPrefab == null)
        {
            Hide();
            return;
        }

        UIEnemyIntentEntry entry = SpawnEntry(EntryParent);
        if (entry == null)
        {
            Hide();
            return;
        }

        entry.Setup(
            intent,
            nameKeyOverride: nameKeyOverride,
            descriptionKeyOverride: descriptionKeyOverride);
        _activeEntries.Add(entry);
        _canvasGroup.alpha = 1f;
        _canvasGroup.blocksRaycasts = false;
    }

    /// <summary>패널 숨김 + 항목 전량 회수.</summary>
    public void Hide()
    {
        ClearEntries();
        if (_canvasGroup != null)
        {
            _canvasGroup.alpha = 0f;
            _canvasGroup.blocksRaycasts = false;
        }
    }

    /// <summary>대상 영역(의도 박스)의 왼쪽-가운데 가장자리 + 오프셋 위치에 패널을 붙인다.
    /// 패널 pivot 을 (1, 0.5)=오른쪽-가운데로 두면 패널이 그 점에서 왼쪽으로 펼쳐진다.
    /// _offset 은 부모 로컬(픽셀) 단위 — 캔버스 모드와 무관하게 X=픽셀로 미세조정.</summary>
    public void MoveTo(RectTransform area)
    {
        if (area == null) return;

        // 방금 Show 로 스폰된 항목들의 레이아웃을 즉시 확정한다.
        // 이를 생략하면 첫 호버 때 패널 크기가 아직 0/이전값이라 pivot 기준 위치가 틀어진다.
        var rt = (RectTransform)transform;
        LayoutRebuilder.ForceRebuildLayoutImmediate(rt);

        // 영역의 월드 4모서리: [0]=좌하 [1]=좌상 [2]=우상 [3]=우하.
        Vector3[] corners = new Vector3[4];
        area.GetWorldCorners(corners);

        // 왼쪽 변의 중점(월드) → 패널 위치로. pivot 이 우측이면 여기서 왼쪽으로 펼쳐짐.
        Vector3 leftEdgeCenter = (corners[0] + corners[1]) * 0.5f;
        transform.position = leftEdgeCenter;

        // 오프셋은 부모 로컬 평면에서 픽셀 단위로 더한다(ScreenSpaceCamera 등 대응).
        rt.anchoredPosition += _offset;
    }

    public void MoveBelow(RectTransform area, Vector2 offset)
    {
        if (area == null) return;

        RectTransform panelRect = (RectTransform)transform;
        RectTransform contentRect = _entryRoot != null ? _entryRoot : panelRect;
        Canvas.ForceUpdateCanvases();
        LayoutRebuilder.ForceRebuildLayoutImmediate(contentRect);

        Vector3[] areaCorners = new Vector3[4];
        Vector3[] contentCorners = new Vector3[4];
        area.GetWorldCorners(areaCorners);
        contentRect.GetWorldCorners(contentCorners);

        Vector3 areaBottomCenter = (areaCorners[0] + areaCorners[3]) * 0.5f;
        Vector3 contentTopCenter = (contentCorners[1] + contentCorners[2]) * 0.5f;
        transform.position += areaBottomCenter - contentTopCenter;
        panelRect.anchoredPosition += offset;
    }

    // ── 내부 ───────────────────────────────────────────────

    private Transform EntryParent => _entryRoot != null ? _entryRoot : transform;

    private UIEnemyIntentEntry SpawnEntry(Transform parent)
    {
        if (PoolManager.HasInstance)
        {
            return PoolManager.Instance.Spawn(_entryPrefab, parent);
        }
        return Instantiate(_entryPrefab, parent);
    }

    /// <summary>
    /// 항목 전량 회수. 반드시 패널이 활성인 동안에만 호출한다(Show/Hide 경로).
    /// 풀 반환은 항목을 풀 루트로 리페어런팅하는데, Unity는 부모가 비활성화되는 도중의
    /// SetParent 를 금지하므로 OnDisable 에서 호출하면 안 된다.
    /// </summary>
    private void ClearEntries()
    {
        for (int i = 0; i < _activeEntries.Count; i++)
        {
            var entry = _activeEntries[i];
            if (entry == null) continue;

            if (PoolManager.HasInstance && PoolManager.Instance.IsPooledInstance(entry.gameObject))
            {
                PoolManager.Instance.Despawn(entry);
            }
            else
            {
                Destroy(entry.gameObject);
            }
        }
        _activeEntries.Clear();
    }
}
