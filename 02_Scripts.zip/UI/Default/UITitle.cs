﻿// =================================================================
// [스크립트 목적]  타이틀 카드 메뉴의 UI 생명주기 연결
// [의존 관계]      - UIBase
// [원칙]           메뉴 선택과 기능 실행은 TitleCardMenu / TitleController가 담당
// [버튼형 전환]     현재 메뉴 표시는 TitleMainMenu가 담당하고 기존 액션 전달 계약을 유지
// [배치]           Canvas 하위에 UI 구성 후 이 컴포넌트 부착, Addressable "UITitle" 등록
// =================================================================
using System;
using System.Threading;
using Cysharp.Threading.Tasks;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class UITitle : UIBase
{
    [Header("카드 메뉴")]
    [Tooltip("타이틀 카드 메뉴 위젯")]
    [SerializeField] private TitleMainMenu _cardMenu;
    [SerializeField] private TitleLogoIntro _logoIntro;
    [Tooltip("UITitle 내부에서 메인 메뉴와 교대 표시되는 난이도 선택 메뉴")]
    [SerializeField] private UIDifficultySelect _difficultySelect;

    [Header("배경")]
    [Tooltip("클리어 전/후 스프라이트를 교체할 배경 Image. 카드 메뉴·로고 뒤쪽에 배치")]
    [SerializeField] private Image _backgroundImage;
    [Tooltip("기본 배경(A). 오늘 클리어 기록이 없을 때 표시")]
    [SerializeField] private Sprite _titleBefore;
    [Tooltip("클리어 배경(B). 현지시간 기준 오늘 최종 클리어 기록이 있을 때 표시")]
    [SerializeField] private Sprite _titleAfter;

    [Header("버전")]
    [Tooltip("Player Settings의 애플리케이션 버전을 표시할 텍스트")]
    [SerializeField] private TMP_Text _versionText;

    public TitleMainMenu CardMenu => _cardMenu;
    public event Action OnOpened;

    public override void OnOpen()
    {
        base.OnOpen();
        RefreshVersion();
        _difficultySelect?.Initialize();
        _cardMenu?.RefreshLocalization();
        _logoIntro?.Play();
        OnOpened?.Invoke();
    }

    public override void OnLocalize()
    {
        base.OnLocalize();
        _cardMenu?.RefreshLocalization();
        _difficultySelect?.OnLocalize();
    }

    public void SetCardMenuActive(bool active)
    {
        if (_cardMenu != null)
            _cardMenu.gameObject.SetActive(active);
    }

    public UniTask<ERunDifficulty?> ShowDifficultySelectAsync(CancellationToken token = default)
    {
        if (_difficultySelect == null)
        {
            Debug.LogError("[UITitle] 난이도 선택 메뉴가 연결되지 않았습니다.");
            return UniTask.FromResult<ERunDifficulty?>(null);
        }

        return ShowDifficultySelectInternalAsync(token);
    }

    private async UniTask<ERunDifficulty?> ShowDifficultySelectInternalAsync(CancellationToken token)
    {
        SetCardMenuActive(false);
        try
        {
            return await _difficultySelect.ShowAsync(token);
        }
        finally
        {
            SetCardMenuActive(true);
            _cardMenu?.ResetInteractionState();
        }
    }

    public bool CancelDifficultySelection()
        => _difficultySelect != null && _difficultySelect.CancelSelection();

    private void RefreshVersion()
    {
        if (_versionText == null) return;

        string version = Application.version;
        _versionText.text = string.IsNullOrWhiteSpace(version)
            ? string.Empty
            : $"v{version}";
    }

    /// <summary>
    /// 오늘 클리어 여부에 따라 배경 스프라이트 교체. 판정은 외부(TitleController)가 수행하고
    /// 여기서는 bool 시맨틱만 받는다. 배경 Image 미할당 시 무시.
    /// </summary>
    public void SetClearBackground(bool clearedToday)
    {
        if (_backgroundImage == null)
            return;

        _backgroundImage.sprite = clearedToday ? _titleAfter : _titleBefore;
    }

}
