// =================================================================
// [스크립트 목적]  적 의도 툴팁 항목 1개. 이름 + 설명 텍스트를 그린다.
//                 UIEnemyIntentPanel 이 호버된 의도 묶음만큼 풀에서 스폰해 채운다.
// [주요 변수]      - _nameText / _descriptionText : 의도 이름·설명 표시
// [의존 관계]      - UIPoolableMonoBehaviour(풀링) / LocalizationManager / TMP / EnemyIntentInfo
// [설계 노트]      - UIKeywordEntry 와 동일 철학: 표현만 담당, 내용은 패널이 결정해 넘긴다.
//                  - 원본 의도를 보관해 언어 변경 시 이름·설명을 다시 계산한다.
// =================================================================

using TMPro;
using UnityEngine;

/// <summary>의도 툴팁의 항목 한 개. Setup(의도)으로 채운다.</summary>
public sealed class UIEnemyIntentEntry : UIPoolableMonoBehaviour, ILocalizable
{
    [Header("텍스트")]
    [Tooltip("의도 이름 표시. 비우면 생략")]
    [SerializeField] private TMP_Text _nameText;

    [Tooltip("의도 설명 표시. 비우면 생략")]
    [SerializeField] private TMP_Text _descriptionText;

    private EnemyIntent _intent;
    private bool _resolveBeneficialAsSharedEffect;
    private string _nameKeyOverride;
    private string _descriptionKeyOverride;
    private bool _hasIntent;

    /// <summary>원본 의도를 보관하고 현재 언어의 이름·설명으로 채운다.</summary>
    public void Setup(
        in EnemyIntent intent,
        bool resolveBeneficialAsSharedEffect = false,
        string nameKeyOverride = null,
        string descriptionKeyOverride = null)
    {
        _intent = intent;
        _resolveBeneficialAsSharedEffect = resolveBeneficialAsSharedEffect;
        _nameKeyOverride = nameKeyOverride;
        _descriptionKeyOverride = descriptionKeyOverride;
        _hasIntent = true;
        RefreshLocalization();
    }

    public void OnLocalize()
    {
        RefreshLocalization();
    }

    public override void OnSpawnFromPool()
    {
        base.OnSpawnFromPool();
        if (LocalizationManager.HasInstance)
            LocalizationManager.Instance.Register(this);
        else
            ApplyLocalizedFonts();
    }

    public override void OnReturnToPool()
    {
        if (LocalizationManager.HasInstance)
            LocalizationManager.Instance.Unregister(this);

        _intent = default;
        _resolveBeneficialAsSharedEffect = false;
        _nameKeyOverride = null;
        _descriptionKeyOverride = null;
        _hasIntent = false;
        base.OnReturnToPool();
    }

    private void OnDestroy()
    {
        if (LocalizationManager.HasInstance)
            LocalizationManager.Instance.Unregister(this);
    }

    private void RefreshLocalization()
    {
        ApplyLocalizedFonts();
        if (!_hasIntent) return;

        IntentDisplayText text = _resolveBeneficialAsSharedEffect
            ? EnemyIntentInfo.ResolveForIntent(_intent)
            : EnemyIntentInfo.Resolve(_intent);
        string displayName = string.IsNullOrEmpty(_nameKeyOverride)
            ? text.Name
            : LocalizationManager.HasInstance
                ? LocalizationManager.Instance.Get(_nameKeyOverride)
                : _nameKeyOverride;
        string description = string.IsNullOrEmpty(_descriptionKeyOverride)
            ? text.Description
            : LocalizationManager.HasInstance
                ? LocalizationManager.Instance.Get(_descriptionKeyOverride)
                : _descriptionKeyOverride;

        if (_nameText != null) _nameText.text = displayName;
        if (_descriptionText != null) _descriptionText.text = description;
    }

    private void ApplyLocalizedFonts()
    {
        TMP_FontAsset font = LocalizedFontUtility.CurrentFont;
        LocalizedFontUtility.ApplyFont(_nameText, font);
        LocalizedFontUtility.ApplyFont(_descriptionText, font);
    }
}
