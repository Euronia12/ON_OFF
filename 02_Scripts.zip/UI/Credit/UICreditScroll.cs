// =================================================================
// [스크립트 목적]  크레딧 엔딩롤. CSV(POCO)를 행으로 펼쳐 세로 자동 스크롤 + 클릭/터치 스킵.
// [주요 변수]      - _scrollSpeed   : 스크롤 속도 (px/s)
//                  - _content       : 스크롤될 RectTransform (행들의 부모)
//                  - _rowPrefab     : 행 프리팹 (UICreditRow)
// [의존 관계]      - DataManager.GetAllData<CreditEntry>()로 데이터 조회
//                  - 행 프리팹 Instantiate로 행 생성
//                  - InputManager(스킵 입력) 또는 자체 입력 감지
// [동작]           UIManager.OpenAsync<UICreditScroll>() → 자동 스크롤 → 끝 도달/스킵 시 닫힘
// [InitOrder]      없음 (UIBase)
// =================================================================
using System;
using System.Collections.Generic;
using System.Threading;
using Cysharp.Threading.Tasks;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public enum ECreditPresentationMode
{
    Title = 0,
    Ending = 1,
}

/// <summary>
/// 세로 자동 스크롤 크레딧. UIManager로 여는 독립 팝업 UI.
/// 끝까지 스크롤되거나 사용자가 스킵하면 OnFinished 발생.
/// </summary>
public class UICreditScroll : UIPopupBase
{
    /// <summary>크레딧은 ESC 로 스킵하고 타이틀로 돌아간다.</summary>
    public override bool CloseOnEscape => true;


    [Header("스크롤 설정")]
    [Tooltip("스크롤 올라가는 속도 (px/s). 클수록 빠름")]
    [Range(20f, 400f)]
    [SerializeField] private float _scrollSpeed = 80f;

    [Tooltip("시작 전 대기 시간 (초). 첫 줄이 화면 아래에서 천천히 등장")]
    [Range(0f, 3f)]
    [SerializeField] private float _startDelay = 0.5f;

    [Tooltip("끝까지 올라간 뒤 여운 대기 시간 (초)")]
    [Range(0f, 5f)]
    [SerializeField] private float _endHoldTime = 1.5f;

    [Header("스킵 설정")]
    [Tooltip("클릭/터치로 스킵 허용 여부")]
    [SerializeField] private bool _canSkip = true;

    [Space]
    [Header("참조")]
    [Tooltip("스크롤될 콘텐츠(행들의 부모 RectTransform)")]
    [SerializeField] private RectTransform _content;

    [Tooltip("뷰포트(보이는 영역). 시작·끝 위치 계산 기준")]
    [SerializeField] private RectTransform _viewport;

    [Tooltip("행 1줄 프리팹 (UICreditRow 부착)")]
    [SerializeField] private UICreditRow _rowPrefab;

    [Tooltip("스킵 입력을 받는 전체 버튼(투명). _canSkip true일 때만 활성")]
    [SerializeField] private Button _skipButton;

    [Tooltip("스킵 버튼 안내 텍스트. 기존 UI_CARD_SELECT_SKIP 키로 로컬라이징")]
    [SerializeField] private TMP_Text _skipButtonText;

    [Tooltip("선택. 비워두면 하위 ScrollRect를 자동 탐색. 크레딧 자동 스크롤 중에는 비활성화")]
    [SerializeField] private ScrollRect _scrollRect;

    [Tooltip("기존 크레딧 전체 화면 배경. 타이틀 걷기 연출이 보일 때만 숨김")]
    [SerializeField] private Image _backdropImage;

    // 스킵 요청 플래그. 입력 감지 시 set, 스크롤 루프가 감지해 즉시 종료
    private bool _skipRequested;

    // 생성된 행 목록 (Hide 시 일괄 정리용)
    private readonly List<UICreditRow> _spawnedRows = new();

    // 비동기 스크롤 취소 토큰 (OnDisable 시 즉시 취소 → 누수·중복 방지)
    private CancellationTokenSource _cts;
    private bool _wasScrollRectEnabled;
    private bool _isRunning;
    private bool _exitNotified;
    private ECreditPresentationMode _presentationMode;
    private Action _endingExitCallback;
    private static ECreditPresentationMode s_pendingPresentationMode;
    private static Action s_pendingEndingExitCallback;

    /// <summary>스크롤 완료(끝 도달 또는 스킵) 시 1회 발생. 호출부가 화면 닫기 처리.</summary>
    public event Action OnFinished;

    /// <summary>크레딧 창이 완전히 닫힌 뒤 호출. 호출자는 열기 전 상태를 복원하는 데 사용한다.</summary>
    public event Action OnClosed;

    /// <summary>엔딩 크레딧이 닫혀 타이틀 복귀가 필요할 때 1회 호출.</summary>
    public event Action OnExitRequested;

    /// <summary>다음 UICreditScroll 열기를 엔딩 모드로 예약한다.</summary>
    public static void ShowEnding(Action onExitRequested)
    {
        s_pendingPresentationMode = ECreditPresentationMode.Ending;
        s_pendingEndingExitCallback = onExitRequested;
    }

    /// <summary>엔딩 크레딧이 열리기 전에 로드가 취소·실패한 경우 예약 상태를 제거한다.</summary>
    public static void CancelPendingEnding()
    {
        s_pendingPresentationMode = ECreditPresentationMode.Title;
        s_pendingEndingExitCallback = null;
    }

    protected override void Init()
    {
        Debug.Assert(_content != null, $"[{name}] _content 미할당");
        Debug.Assert(_viewport != null, $"[{name}] _viewport 미할당");
        Debug.Assert(_rowPrefab != null, $"[{name}] _rowPrefab 미할당");

        if (_scrollRect == null)
            _scrollRect = GetComponentInChildren<ScrollRect>(true);
    }

    protected override void Setup()
    {
        SetBackdropVisible(true);
        _presentationMode = s_pendingPresentationMode;
        _endingExitCallback = _presentationMode == ECreditPresentationMode.Ending
            ? s_pendingEndingExitCallback
            : null;
        s_pendingPresentationMode = ECreditPresentationMode.Title;
        s_pendingEndingExitCallback = null;
        _exitNotified = false;
    }

    /// <summary>언어 변경 시 스킵 버튼 텍스트 갱신. 기존 카드 선택 스킵 키를 재사용.</summary>
    public override void OnLocalize()
    {
        base.OnLocalize();

        if (_skipButtonText != null && LocalizationManager.HasInstance)
        {
            string key = _presentationMode == ECreditPresentationMode.Ending
                ? LocalizationKeys.Shop.LeaveButton
                : LocalizationKeys.CardSelect.Skip;
            _skipButtonText.text = LocalizationManager.Instance.Get(key);
        }
    }

    public override void OnOpen()
    {
        base.OnOpen();

        DisableScrollRectControl();

        if (_canSkip && _skipButton != null)
        {
            _skipButton.gameObject.SetActive(true);
            _skipButton.onClick.AddListener(RequestSkip);
        }

        Show();
    }

    public override void OnClose()
    {
        // 진행 중 스크롤 즉시 취소 (UI 꺼질 때 코루틴 잔존 방지)
        _cts?.Cancel();
        _cts?.Dispose();
        _cts = null;

        if (_skipButton != null)
            _skipButton.onClick.RemoveListener(RequestSkip);

        RestoreScrollRectControl();
        ReleaseRows();
        SetBackdropVisible(true);

        base.OnClose();
        OnClosed?.Invoke();
        if (_presentationMode == ECreditPresentationMode.Ending)
            NotifyExitRequested();
    }

    /// <summary>
    /// 크레딧 표시 시작. 데이터 조회 → 행 구성 → 자동 스크롤.
    /// 이미 표시 중이면 무시(중복 호출 방어).
    /// </summary>
    public void Show()
    {
        if (_isRunning)
            return;

        _cts?.Cancel();
        _cts?.Dispose();
        // OnClose를 거치지 않는 파괴(씬 전환 등)에서도 취소되도록 destroy 토큰과 연결
        _cts = CancellationTokenSource.CreateLinkedTokenSource(this.GetCancellationTokenOnDestroy());
        _skipRequested = false;
        _isRunning = true;
        RunCreditAsync(_cts.Token).Forget();
    }

    /// <summary>외부에서 강제 종료(예: ESC). 스킵과 동일 처리.</summary>
    public void RequestSkip()
    {
        if (!_canSkip)
            return;

        _skipRequested = true;
        if (UIManager.HasInstance && IsOpen)
            UIManager.Instance.Close(this);
    }

    /// <summary>크레딧 스크롤은 유지하면서 뒤쪽 월드 연출의 노출 여부를 전환한다.</summary>
    public void SetBackdropVisible(bool visible)
    {
        if (_backdropImage != null)
            _backdropImage.enabled = visible;
    }

    // ─────────────────────────────────────────────
    // 내부: 행 구성
    // ─────────────────────────────────────────────

    private async UniTask RunCreditAsync(CancellationToken token)
    {
        try
        {
            // UIManager.OpenInternal 이 HandleOpen 뒤에 추적/팝업 스택 등록을 완료하므로,
            // 데이터 없음으로 즉시 닫히더라도 stale UI가 재등록되지 않게 한 프레임 기다린다.
            await UniTask.Yield(PlayerLoopTiming.Update, token);

            // 데이터 조회: 원본 참조(읽기 전용으로만 사용 — 수정 안 함)
            if (!DataManager.HasInstance)
            {
                GameLogger.LogWarning(ELogCategory.UI, "DataManager 없음 — 크레딧 표시 불가");
                FinishAndClose();
                return;
            }

            var entries = DataManager.Instance.GetAllData<CreditEntry>();
            if (entries == null || entries.Count == 0)
            {
                GameLogger.LogWarning(ELogCategory.UI, "크레딧 데이터 없음(Credits.csv 확인) — 즉시 종료");
                FinishAndClose();
                return;
            }

            BuildRows(entries);

            // 레이아웃 확정 대기 (VerticalLayoutGroup 높이 계산 1프레임 필요)
            await UniTask.Yield(PlayerLoopTiming.LastPostLateUpdate, token);
            LayoutRebuilder.ForceRebuildLayoutImmediate(_content);
            await UniTask.Yield(PlayerLoopTiming.LastPostLateUpdate, token);

            await ScrollAsync(token);

            if (!token.IsCancellationRequested)
                FinishAndClose();
        }
        finally
        {
            _isRunning = false;
        }
    }

    /// <summary>POCO 목록을 행 프리팹으로 펼침.</summary>
    private void BuildRows(IReadOnlyList<CreditEntry> entries)
    {
        ReleaseRows();

        for (int i = 0; i < entries.Count; i++)
        {
            var row = Instantiate(_rowPrefab, _content);
            row.Setup(entries[i]);
            _spawnedRows.Add(row);
        }
    }

    // ─────────────────────────────────────────────
    // 내부: 스크롤 루프
    // ─────────────────────────────────────────────

    private async UniTask ScrollAsync(CancellationToken token)
    {
        float viewportHeight = _viewport.rect.height;
        float contentHeight = _content.rect.height;

        // 시작 Y: content 전체가 viewport 아래 바깥에서 시작. 끝 Y: content 전체가 viewport 위로 빠져나감.
        float startY = -viewportHeight;
        float endY = contentHeight;

        var pos = _content.anchoredPosition;
        pos.y = startY;
        _content.anchoredPosition = pos;

        // 시작 전 여운
        await DelayWithSkip(_startDelay, token);
        if (_skipRequested || token.IsCancellationRequested) return;

        float elapsed = 0f;
        float duration = _scrollSpeed > 0f ? (endY - startY) / _scrollSpeed : 0f;

        // 자동 스크롤: 단일 시작점 기준으로 위치를 계산해 ScrollRect/레이아웃 잔여값과 누적 오차를 피한다.
        while (elapsed < duration)
        {
            token.ThrowIfCancellationRequested();
            if (_skipRequested) return;

            // 파괴 직후 재개 프레임 방어 (토큰 취소보다 파괴가 먼저인 경우)
            if (_content == null) return;

            elapsed += Time.unscaledDeltaTime;
            pos.y = Mathf.Min(endY, startY + elapsed * _scrollSpeed);
            _content.anchoredPosition = pos;

            await UniTask.Yield(PlayerLoopTiming.Update, token);
        }

        if (_content == null) return;

        pos.y = endY;
        _content.anchoredPosition = pos;

        // 끝 여운
        await DelayWithSkip(_endHoldTime, token);
    }

    private void DisableScrollRectControl()
    {
        if (_scrollRect == null)
            return;

        _wasScrollRectEnabled = _scrollRect.enabled;
        _scrollRect.StopMovement();
        _scrollRect.velocity = Vector2.zero;
        _scrollRect.enabled = false;
    }

    private void RestoreScrollRectControl()
    {
        if (_scrollRect == null)
            return;

        _scrollRect.velocity = Vector2.zero;
        _scrollRect.enabled = _wasScrollRectEnabled;
    }

    private void FinishAndClose()
    {
        OnFinished?.Invoke();
        if (UIManager.HasInstance && IsOpen)
            UIManager.Instance.Close(this);
    }

    private void NotifyExitRequested()
    {
        if (_exitNotified) return;

        _exitNotified = true;
        Action callback = _endingExitCallback;
        _endingExitCallback = null;
        callback?.Invoke();
        OnExitRequested?.Invoke();
    }

    /// <summary>지정 시간 대기하되 중간에 스킵되면 즉시 반환.</summary>
    private async UniTask DelayWithSkip(float seconds, CancellationToken token)
    {
        float elapsed = 0f;
        while (elapsed < seconds)
        {
            if (_skipRequested || token.IsCancellationRequested) return;
            elapsed += Time.unscaledDeltaTime;
            await UniTask.Yield(PlayerLoopTiming.Update, token);
        }
    }

    // ─────────────────────────────────────────────
    // 내부: 정리
    // ─────────────────────────────────────────────

    /// <summary>생성된 행을 모두 제거한다.</summary>
    private void ReleaseRows()
    {
        if (_spawnedRows.Count == 0) return;

        for (int i = 0; i < _spawnedRows.Count; i++)
        {
            if (_spawnedRows[i] != null)
                Destroy(_spawnedRows[i].gameObject);
        }
        _spawnedRows.Clear();
    }

    private void OnDestroy()
    {
        OnFinished = null;
        OnClosed = null;
        OnExitRequested = null;
        _endingExitCallback = null;
    }
}
