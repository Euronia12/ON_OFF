// =================================================================
// [스크립트 목적]  크레딧 한 줄을 화면에 그리는 행 컴포넌트. 풀링으로 재사용.
// [주요 변수]      - _roleText : 역할명(로컬라이즈된 텍스트) 표시
//                  - _nameText : 이름(고정값) 표시
// [의존 관계]      - UICreditScroll이 Setup()으로 데이터 주입
//                  - LocalizationManager.Get으로 RoleKey 변환
// [InitOrder]      없음 (UIBase 아님, 순수 View 행)
// =================================================================
using TMPro;
using UnityEngine;

/// <summary>
/// 크레딧 스크롤의 한 행. 역할(로컬키→번역)과 이름(고정값)을 표시.
/// EntryType에 따라 스타일(폰트 크기·표시 여부)을 전환한다.
/// </summary>
public class UICreditRow : MonoBehaviour
{
    [Header("텍스트 참조")]
    [Tooltip("역할명 표시 (로컬라이즈 적용 대상)")]
    [SerializeField] private TextMeshProUGUI _roleText;

    [Tooltip("이름·회사명 표시 (고정값, 번역 안 함)")]
    [SerializeField] private TextMeshProUGUI _nameText;

    [Header("스타일 설정")]
    [Tooltip("섹션 헤더 폰트 크기 (pt). 일반 줄보다 크게")]
    [Range(20f, 80f)]
    [SerializeField] private float _sectionFontSize = 42f;

    [Tooltip("일반 줄 역할명 폰트 크기 (pt)")]
    [Range(14f, 50f)]
    [SerializeField] private float _normalFontSize = 28f;

    private void Awake()
    {
        // Inspector 미할당 조기 검출 (런타임 NullRef 방지)
        Debug.Assert(_roleText != null, $"[{name}] _roleText 미할당");
        Debug.Assert(_nameText != null, $"[{name}] _nameText 미할당");
    }

    /// <summary>
    /// 행 데이터 주입. 로컬라이즈는 호출 시점 1회 적용(스크롤 중 언어 변경은 미지원 — 단순화).
    /// </summary>
    public void Setup(CreditEntry entry)
    {
        var type = ParseType(entry.EntryType);

        // 역할명: 로컬키가 있으면 번역, 없으면 빈 줄
        if (string.IsNullOrEmpty(entry.RoleKey))
        {
            _roleText.gameObject.SetActive(false);
        }
        else
        {
            _roleText.gameObject.SetActive(true);
            _roleText.text = LocalizationManager.Instance.Get(entry.RoleKey);
            _roleText.fontSize = (type == ECreditEntryType.Section)
                ? _sectionFontSize
                : _normalFontSize;
        }

        // 이름: 고정값. 비면 숨김
        if (string.IsNullOrEmpty(entry.Name))
        {
            _nameText.gameObject.SetActive(false);
        }
        else
        {
            _nameText.gameObject.SetActive(true);
            _nameText.text = entry.Name;
        }

        // 현재 언어 폰트 적용 (행은 런타임 Instantiate라 UIBase.OnLocalize 대상에서 누락됨)
        TMP_FontAsset font = LocalizedFontUtility.CurrentFont;
        LocalizedFontUtility.ApplyFont(_roleText, font);
        LocalizedFontUtility.ApplyFont(_nameText, font);
    }

    /// <summary>EntryType 문자열 → enum. 미지정·오타는 Normal로 폴백.</summary>
    private static ECreditEntryType ParseType(string raw)
    {
        if (string.IsNullOrEmpty(raw)) return ECreditEntryType.Normal;

        // 대소문자 무시 파싱. 실패 시 Normal (CSV 오타 방어)
        return System.Enum.TryParse<ECreditEntryType>(raw, ignoreCase: true, out var result)
            ? result
            : ECreditEntryType.Normal;
    }
}
