// =================================================================
// [스크립트 목적]  크레딧 한 줄(행) 원본 데이터. Credits.csv → 자동 파싱 → POCO.
// [주요 변수]      - Id        : 행 고유 키 (CSV의 Id 컬럼)
//                  - RoleKey   : 역할명 로컬라이즈 키 (빈 값 가능 = 이름 단독 줄)
//                  - Name      : 사람/회사명 등 고정값 (번역 안 함, 빈 값 가능)
//                  - EntryType : 줄 종류(섹션 헤더 / 일반 / 공백) → 표시 스타일 분기
// [의존 관계]      - [GameData] 표식으로 DataManager가 자동 로드·등록
//                  - DataParser.ParseCsv가 public 필드에 컬럼 매핑
// [절대 명제]      DataManager 외부에 SO를 노출하지 않음. 이 POCO만 게임플레이가 사용
// =================================================================

/// <summary>
/// 크레딧 CSV 한 행. RoleKey는 로컬라이즈 키, Name은 고정값.
/// EntryType에 따라 UICreditRow가 폰트 크기·정렬을 다르게 표시한다.
/// </summary>
[GameData]
public class CreditEntry
{
    // DataParser는 public 필드에 CSV 컬럼을 매핑하므로 public 유지(데이터 DTO 예외).
    public string Id;           // 행 키 (정렬·디버깅용)
    public string RoleKey;      // 역할명 로컬키 (예: "Credit_Role_Programming"). 비면 역할 줄 없음
    public string Name;         // 고정값 이름 (번역 X). 비면 이름 줄 없음
    public string EntryType;    // "Section" / "Normal" / "Space" (미지정 시 Normal 취급)
}

/// <summary>크레딧 줄 종류. CSV의 EntryType 문자열을 파싱해 매핑.</summary>
public enum ECreditEntryType
{
    Normal,     // 역할 + 이름 일반 줄
    Section,    // 섹션 헤더 (예: "Programming") — 강조 스타일
    Space,      // 빈 줄 (간격 조절용)
}
