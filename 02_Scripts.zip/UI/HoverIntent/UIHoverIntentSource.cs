using System;
using UnityEngine;
using UnityEngine.EventSystems;

/// <summary>포인터 진입/이탈을 Hover Intent 툴팁에 전달하는 재사용 소스.</summary>
public sealed class UIHoverIntentSource : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler
{
    [SerializeField] private UIHoverIntentTooltip _target;

    private Action _onOpened;
    private Action _onClosed;

    public RectTransform RectTransform => transform as RectTransform;

    public void Bind(UIHoverIntentTooltip target, Action onOpened = null, Action onClosed = null)
    {
        if (_target != target)
            _target?.SourceDisabled(this);

        _target = target;
        _onOpened = onOpened;
        _onClosed = onClosed;
    }

    public void Unbind()
    {
        _target?.SourceDisabled(this);
        _target = null;
        _onOpened = null;
        _onClosed = null;
    }

    public void OnPointerEnter(PointerEventData eventData)
    {
        _target?.SourceEntered(this);
    }

    public void OnPointerExit(PointerEventData eventData)
    {
        _target?.SourceExited(this);
    }

    internal void InvokeOpened() => _onOpened?.Invoke();
    internal void InvokeClosed() => _onClosed?.Invoke();

    private void OnDisable()
    {
        _target?.SourceDisabled(this);
    }
}
