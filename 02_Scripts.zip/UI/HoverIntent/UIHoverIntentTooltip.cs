using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

/// <summary>게이지 잠금과 부모/자식 보호 영역을 처리하는 재사용 Hover Intent 툴팁.</summary>
public sealed class UIHoverIntentTooltip : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler
{
    [SerializeField] private Image _lockGauge;
    [SerializeField, Min(0f)] private float _lockDuration = 1f;
    [SerializeField, Min(0f)] private float _closeDelay = 0.15f;
    [SerializeField] private UIHoverIntentTooltip _parent;

    private readonly List<UIHoverIntentTooltip> _children = new List<UIHoverIntentTooltip>();
    private UIHoverIntentTooltip _registeredParent;
    private UIHoverIntentSource _source;
    private Coroutine _fillRoutine;
    private Coroutine _closeRoutine;
    private bool _sourceInside;
    private bool _panelInside;
    private bool _locked;
    private bool _closing;

    public RectTransform RectTransform => transform as RectTransform;
    public bool IsOpen => _source != null && gameObject.activeSelf;
    public bool IsLocked => _locked;

    private void Awake()
    {
#if UNITY_EDITOR || DEVELOPMENT_BUILD
        Debug.Assert(_lockGauge == null || _lockGauge.type != Image.Type.Filled || _lockGauge.sprite != null,
            "[UIHoverIntentTooltip] Filled 잠금 게이지에는 Sprite가 필요합니다.");
#endif
        RegisterWithParent();
        ResetGauge();
    }

    public static void PlaceNextTo(RectTransform panel, RectTransform source, float gap = 16f)
    {
        if (panel == null || source == null || panel.parent is not RectTransform parent) return;

        Vector3[] corners = new Vector3[4];
        source.GetWorldCorners(corners);
        Vector3 bottomLeft = parent.InverseTransformPoint(corners[0]);
        Vector3 topRight = parent.InverseTransformPoint(corners[2]);
        Rect sourceRect = Rect.MinMaxRect(bottomLeft.x, bottomLeft.y, topRight.x, topRight.y);
        Rect bounds = parent.rect;

        Vector2 scale = new Vector2(Mathf.Abs(panel.localScale.x), Mathf.Abs(panel.localScale.y));
        float left = panel.rect.width * panel.pivot.x * scale.x;
        float right = panel.rect.width * (1f - panel.pivot.x) * scale.x;
        float bottom = panel.rect.height * panel.pivot.y * scale.y;
        float top = panel.rect.height * (1f - panel.pivot.y) * scale.y;
        float alignedX = Mathf.Clamp(sourceRect.center.x, bounds.xMin + left, bounds.xMax - right);
        float alignedY = Mathf.Clamp(sourceRect.center.y, bounds.yMin + bottom, bounds.yMax - top);

        Vector2[] candidates =
        {
            new Vector2(sourceRect.xMax + gap + left, alignedY),
            new Vector2(sourceRect.xMin - gap - right, alignedY),
            new Vector2(alignedX, sourceRect.yMax + gap + bottom),
            new Vector2(alignedX, sourceRect.yMin - gap - top)
        };

        for (int i = 0; i < candidates.Length; i++)
        {
            Vector2 candidate = candidates[i];
            Rect panelRect = Rect.MinMaxRect(
                candidate.x - left, candidate.y - bottom,
                candidate.x + right, candidate.y + top);
            if (!Contains(bounds, panelRect) || panelRect.Overlaps(sourceRect)) continue;

            panel.localPosition = new Vector3(candidate.x, candidate.y, panel.localPosition.z);
            return;
        }

#if UNITY_EDITOR || DEVELOPMENT_BUILD
        Debug.Assert(false, "[UIHoverIntentTooltip] 소스와 겹치지 않는 툴팁 배치 공간이 없습니다.");
#endif
    }

    public void SetParent(UIHoverIntentTooltip parent)
    {
        if (_parent == parent && _registeredParent == parent) return;

        _registeredParent?.UnregisterChild(this);
        _parent = parent;
        RegisterWithParent();
    }

    public void ForceCloseBranch()
    {
        CloseNow();
    }

    internal void SourceEntered(UIHoverIntentSource source)
    {
        if (source == null) return;

        if (_source == source && IsOpen)
        {
            _sourceInside = true;
            CancelClose();
            return;
        }

        CloseNow();
        _source = source;
        _sourceInside = true;
        _panelInside = false;
        _locked = false;
        ResetGauge();
        gameObject.SetActive(true);
        _parent?.CancelClose();
        source.InvokeOpened();

        if (_lockDuration <= 0f)
        {
            CompleteLock();
            return;
        }

        _fillRoutine = StartCoroutine(FillLockGauge());
    }

    internal void SourceExited(UIHoverIntentSource source)
    {
        if (_source != source) return;

        _sourceInside = false;
        if (!_locked)
            CloseNow();
        else
            EvaluateClose();
    }

    internal void SourceDisabled(UIHoverIntentSource source)
    {
        if (_source == source)
            CloseNow();
    }

    public void OnPointerEnter(PointerEventData eventData)
    {
        if (!IsOpen || !_locked) return;
        _panelInside = true;
        CancelClose();
    }

    public void OnPointerExit(PointerEventData eventData)
    {
        if (!IsOpen) return;
        _panelInside = false;
        EvaluateClose();
    }

    private IEnumerator FillLockGauge()
    {
        float elapsed = 0f;
        while (_sourceInside && elapsed < _lockDuration)
        {
            elapsed += Time.unscaledDeltaTime;
            if (_lockGauge != null)
                _lockGauge.fillAmount = Mathf.Clamp01(elapsed / _lockDuration);
            yield return null;
        }

        _fillRoutine = null;
        if (_sourceInside && IsOpen)
            CompleteLock();
    }

    private void CompleteLock()
    {
        _locked = true;
        if (_lockGauge != null)
            _lockGauge.fillAmount = 1f;
    }

    private void EvaluateClose()
    {
        if (_closing || !IsOpen || IsProtected()) return;
        if (!_locked)
        {
            CloseNow();
            return;
        }

        if (_closeRoutine == null)
            _closeRoutine = StartCoroutine(CloseAfterDelay());
    }

    private IEnumerator CloseAfterDelay()
    {
        // 같은 프레임의 Source Exit -> Panel Enter 이벤트 순서를 흡수한다.
        yield return null;

        float elapsed = 0f;
        while (!IsProtected() && elapsed < _closeDelay)
        {
            elapsed += Time.unscaledDeltaTime;
            yield return null;
        }

        _closeRoutine = null;
        if (!IsProtected())
            CloseNow();
    }

    private bool IsProtected()
    {
        if (_sourceInside || _panelInside) return true;
        for (int i = 0; i < _children.Count; i++)
        {
            if (_children[i] != null && _children[i].IsOpen)
                return true;
        }
        return false;
    }

    private void CloseNow()
    {
        if (_closing) return;
        _closing = true;

        for (int i = _children.Count - 1; i >= 0; i--)
            _children[i]?.ForceCloseBranch();

        StopRoutine(ref _fillRoutine);
        StopRoutine(ref _closeRoutine);

        UIHoverIntentSource closedSource = _source;
        _source = null;
        _sourceInside = false;
        _panelInside = false;
        _locked = false;
        ResetGauge();
        if (gameObject.activeSelf)
            gameObject.SetActive(false);

        closedSource?.InvokeClosed();
        _closing = false;
        _parent?.EvaluateClose();
    }

    private void CancelClose()
    {
        StopRoutine(ref _closeRoutine);
    }

    private void StopRoutine(ref Coroutine routine)
    {
        if (routine == null) return;
        StopCoroutine(routine);
        routine = null;
    }

    private void ResetGauge()
    {
        if (_lockGauge != null)
            _lockGauge.fillAmount = 0f;
    }

    private void RegisterWithParent()
    {
        if (_parent == null || _registeredParent == _parent) return;
        _registeredParent = _parent;
        _registeredParent.RegisterChild(this);
    }

    private void RegisterChild(UIHoverIntentTooltip child)
    {
        if (child != null && !_children.Contains(child))
            _children.Add(child);
    }

    private void UnregisterChild(UIHoverIntentTooltip child)
    {
        _children.Remove(child);
    }

    private void OnDisable()
    {
        if (!_closing && _source != null)
            CloseNow();
    }

    private void OnDestroy()
    {
        _registeredParent?.UnregisterChild(this);
    }

    private static bool Contains(Rect outer, Rect inner)
    {
        return inner.xMin >= outer.xMin && inner.xMax <= outer.xMax &&
               inner.yMin >= outer.yMin && inner.yMax <= outer.yMax;
    }
}
