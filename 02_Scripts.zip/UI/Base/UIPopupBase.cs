// =================================================================
// [스크립트 목적]  팝업 UI 공통 베이스. 닫기버튼/배경딤 닫기 일원화
// [주요 변수]      - _closeButton  : 닫기(X) 버튼 (선택)
//                  - _dimButton    : 배경 딤 클릭 닫기용 버튼 (선택)
//                  - _closeOnDim   : 배경 클릭 시 닫을지 여부
// [의존 관계]      - UIBase, UIManager
// [원칙]           레이어(그리기 순서)와 ESC 닫기는 분리한다.
//                  레이어는 Inspector _layer, ESC 닫기는 Inspector _closeOnEscape 가 결정한다.
//                  자식은 닫기 로직을 재구현하지 않고 RequestClose()만 호출하면 됨.
// [상속]           옵션·확인창·상점 등 "닫을 수 있는 창"은 이 클래스를 상속
// =================================================================
using UnityEngine;
using UnityEngine.UI;

public abstract class UIPopupBase : UIBase
{
    [Header("팝업 공통")]
    [Tooltip("닫기(X) 버튼. 없으면 비워둬도 됨")]
    [SerializeField] private Button _closeButton;

    [Tooltip("배경 딤 영역 버튼 (전체를 덮는 투명 버튼). 바깥 클릭으로 닫기용")]
    [SerializeField] private Button _dimButton;

    [Tooltip("배경(딤) 클릭 시 닫을지 여부. 확인이 꼭 필요한 팝업은 끄기")]
    [SerializeField] private bool _closeOnDim = true;

    // ─────────────────────────────────────────────
    // 생명주기 (자식은 base 호출 필수)
    // ─────────────────────────────────────────────

    public override void OnOpen()
    {
        base.OnOpen();
        _closeButton?.onClick.AddListener(RequestClose);

        if (_closeOnDim)
            _dimButton?.onClick.AddListener(RequestClose);
    }

    public override void OnClose()
    {
        _closeButton?.onClick.RemoveListener(RequestClose);
        _dimButton?.onClick.RemoveListener(RequestClose);
        base.OnClose();
    }

    /// <summary>
    /// ESC/백버튼. 기본은 닫기 허용(true).
    /// 닫기 전 확인이 필요한 팝업은 override해서 조건부 false 반환.
    /// </summary>
    public override bool OnBackPressed() => true;

    // ─────────────────────────────────────────────
    // 닫기 요청 (버튼/딤 공통 진입점)
    // ─────────────────────────────────────────────

    /// <summary>
    /// 팝업 닫기 요청. OnBackPressed가 true일 때만 실제로 닫음
    /// (ESC와 동일한 차단 로직을 버튼 닫기에도 적용 → 일관성).
    /// </summary>
    protected void RequestClose()
    {
        if (!OnBackPressed()) return;
        if (UIManager.HasInstance)
            UIManager.Instance.Close(this);
    }
}
