using System;
using System.Collections.Generic;
using UnityEngine;

[Serializable]
public sealed class UiAudioCue
{
    [Tooltip("AudioKeys에서 UI 동작을 호출할 때 사용하는 키")]
    [SerializeField] private string _uiKey;

    [Tooltip("실제로 재생할 Addressable SFX 키")]
    [SerializeField] private string _sfxKey;

    [Range(0f, 1f)]
    [SerializeField] private float _volume = 1f;

    [Range(0.1f, 3f)]
    [SerializeField] private float _pitch = 1f;

    [Tooltip("같은 UI음이 반복될 때 AudioManager의 랜덤 피치를 적용")]
    [SerializeField] private bool _randomPitch;

    public string UiKey => _uiKey;
    public string SfxKey => _sfxKey;
    public float Volume => Mathf.Clamp01(_volume);
    public float Pitch => Mathf.Clamp(_pitch, 0.1f, 3f);
    public bool RandomPitch => _randomPitch;
    public bool IsValid => !string.IsNullOrWhiteSpace(_uiKey) && !string.IsNullOrWhiteSpace(_sfxKey);
}

[CreateAssetMenu(fileName = "UiAudioCatalog", menuName = "Audio/UI Audio Catalog")]
public sealed class UiAudioCatalog : ScriptableObject
{
    [SerializeField] private List<UiAudioCue> _entries = new List<UiAudioCue>();

    public bool TryFind(string uiKey, out UiAudioCue cue)
    {
        if (!string.IsNullOrWhiteSpace(uiKey))
        {
            for (int i = 0; i < _entries.Count; i++)
            {
                UiAudioCue candidate = _entries[i];
                if (candidate != null &&
                    candidate.IsValid &&
                    string.Equals(candidate.UiKey, uiKey, StringComparison.Ordinal))
                {
                    cue = candidate;
                    return true;
                }
            }
        }

        cue = null;
        return false;
    }
}
