// =================================================================
// [스크립트 목적]  상점 판매 카드 슬롯 1칸. 카드 뷰 + 가격 + 구매 버튼을 묶고,
//                 구매 가능 여부(잔액)·구매 완료 상태를 표시한다. hover 확대는 보상 슬롯과 동일.
// [주요 변수]      - _detailView : 카드 앞면+설명+키워드 표시 뷰(재사용)
//                  - _priceText  : 가격 텍스트
//                  - _buyButton  : 구매 버튼
// [의존 관계]      - UICardDetailView / Card / CardFactory / ShopCardEntry
//                  - UIShopPopup(부모가 콜백 구독) / DG.Tweening
// [배치]           상점 카드 슬롯 프리팹에 부착. UIShopPopup 이 슬롯 배열로 보유.
// [설계 노트]      - 슬롯은 "내 칸 표시·구매가능표시"만 책임. 구매 처리(골드·덱)는 부모→컨트롤러.
//                  - 잔액 부족이면 구매 버튼 비활성(가격은 보임).
//                  - 구매 완료면 카드·가격을 숨겨 빈 칸으로 남긴다 (슬롯 자리는 유지 → 레이아웃 안 흔들림).
// =================================================================

using System;
using Cysharp.Threading.Tasks;
using DG.Tweening;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

/// <summary>
/// 상점 판매 카드 슬롯. 카드·가격·구매 버튼을 표시하고, 잔액/품절에 따라 구매 버튼을 토글한다.
/// 구매 클릭 시 콜백으로 부모(UIShopPopup)에 알린다.
/// </summary>
public sealed class UIShopCardSlot : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler, IPointerDownHandler
{
    [Header("슬롯 구성")]
    [Tooltip("카드 앞면+설명+키워드를 함께 표시하는 뷰")]
    [SerializeField] private UICardDetailView _detailView;
    [SerializeField] private TMP_Text _priceText;
    [SerializeField] private Button _buyButton;

    [Header("Hover")]
    [SerializeField] private float _hoverScale = 1.06f;
    [SerializeField] private float _hoverDuration = 0.12f;
    [SerializeField] private Transform _hoverTarget;

    [Header("Click")]
    [SerializeField] private float _clickScale = 0.78f;
    [SerializeField] private float _clickDownDuration = 0.1f;
    [SerializeField] private float _clickReturnDuration = 0.18f;

    [Header("가격 라벨")]
    [Tooltip("\"{0}\" 자리에 가격이 들어가는 로컬라이징 키")]
    [SerializeField] private string _priceFormatKey = "UI_COMMON_GOLD_AMOUNT_FORMAT";

    private Action _onBuyClicked;
    private bool _bound;
    private ShopCardEntry _entry;
    private int _currentGold;

    private UIKeywordPanel _keywordPanel;     // 부모(UIShopPopup)가 주입
    private Card _previewCard;

    private Transform Target => _hoverTarget != null ? _hoverTarget : transform;
    private Vector3 _baseScale = Vector3.one;
    private Tween _hoverTween;
    private Sequence _clickSequence;
    private bool _isPointerInside;
    private bool _isClickAnimating;

    /// <summary>이 슬롯이 표현 중인 판매 항목.</summary>
    public ShopCardEntry Entry => _entry;

    private void Awake()
    {
        _baseScale = Target.localScale;
    }

    /// <summary>항목 바인딩 + 구매 콜백 연결 (부모가 슬롯 생성 직후 1회 호출).</summary>
    public void Bind(ShopCardEntry entry, Action onBuyClicked)
    {
        _entry = entry;
        _onBuyClicked = onBuyClicked;

        if (!_bound && _buyButton != null)
        {
            _buyButton.onClick.AddListener(HandleBuy);
            _bound = true;
        }

        // 카드 미리보기 표시 (앞면+설명+키워드).
        _previewCard = null;
        if (_detailView != null && entry != null && entry.Card != null)
        {
            CardRuntimeData runtime = CardFactory.FromSO(entry.Card, upgraded: false);
            Card preview = runtime != null
                ? CardFactory.Create(runtime, entry.ArrowDirection)
                : null;
            if (preview != null)
            {
                _detailView.Setup(preview);
                _previewCard = preview;
            }
        }

        if (_priceText != null && entry != null)
        {
            LocalizedFontUtility.ApplyCurrentFont(_priceText);
            RefreshPriceText();
        }

        ResetHover();
    }

    /// <summary>
    /// 구매 가능 여부에 따라 표시 갱신. 부모가 골드 변동/구매 후 호출.
    /// </summary>
    /// <param name="currentGold">현재 보유 골드.</param>
    public void Refresh(int currentGold)
    {
        _currentGold = currentGold;
        bool purchased = _entry != null && _entry.Purchased;

        // 구매 완료면 카드·가격을 숨겨 빈 칸으로 남긴다. 슬롯 오브젝트는 살려 레이아웃 자리를 유지.
        SetContentVisible(!purchased);

        // 잔액 부족은 클릭 경고를 띄우기 위해 버튼을 활성 상태로 둔다.
        if (_buyButton != null) _buyButton.interactable = !purchased;

        if (purchased)
        {
            ResetHover();
            if (_keywordPanel != null) _keywordPanel.Hide();
            return;
        }

        RefreshPriceText();
    }

    private void SetContentVisible(bool visible)
    {
        if (_detailView != null && _detailView.gameObject.activeSelf != visible)
        {
            _detailView.gameObject.SetActive(visible);
        }
        if (_priceText != null && _priceText.gameObject.activeSelf != visible)
        {
            _priceText.gameObject.SetActive(visible);
        }
    }

    /// <summary>부모(UIShopPopup)가 슬롯 생성 후 공유 키워드 패널을 주입.</summary>
    public void SetKeywordPanel(UIKeywordPanel panel) => _keywordPanel = panel;

    /// <summary>언어 변경 시 부모(UIShopPopup.OnLocalize)가 호출 — 폰트·가격 텍스트를 현재 언어로 갱신.</summary>
    public void RefreshLocalization()
    {
        if (_priceText == null || _entry == null) return;
        LocalizedFontUtility.ApplyCurrentFont(_priceText);
        RefreshPriceText();
    }

    // ── Hover ──
    public void OnPointerEnter(PointerEventData eventData)
    {
        if (_entry != null && _entry.Purchased) return; // 구매 완료(빈 칸)는 hover 안 함
        _isPointerInside = true;
        if (_isClickAnimating) return;

        AnimateScale(_baseScale * _hoverScale);

        if (_keywordPanel != null)
        {
            _keywordPanel.MoveTo(transform as RectTransform);
            _keywordPanel.Show(_previewCard);
        }
    }

    public void OnPointerExit(PointerEventData eventData)
    {
        _isPointerInside = false;
        if (_isClickAnimating)
        {
            if (_keywordPanel != null) _keywordPanel.Hide();
            return;
        }

        AnimateScale(_baseScale);
        if (_keywordPanel != null) _keywordPanel.Hide();
    }

    public void OnPointerDown(PointerEventData eventData)
    {
        if (eventData.button != PointerEventData.InputButton.Left) return;
        if (!CanPlayClickScaleEffect()) return;

        PlayClickScaleEffect();
    }

    private void AnimateScale(Vector3 target)
    {
        _hoverTween?.Kill();
        _hoverTween = Target.DOScale(target, _hoverDuration).SetEase(Ease.OutQuad);
    }

    private void ResetHover()
    {
        _hoverTween?.Kill();
        _hoverTween = null;
        _clickSequence?.Kill();
        _clickSequence = null;
        _isClickAnimating = false;
        _isPointerInside = false;
        Target.localScale = _baseScale;
    }

    private void HandleBuy()
    {
        if (_entry == null || _entry.Purchased) return;
        if (_currentGold < _entry.Price)
        {
            if (!_isClickAnimating)
                PlayClickScaleEffect();
            ShowNotEnoughGoldAsync().Forget();
            return;
        }

        if (!_isClickAnimating)
            PlayClickScaleEffect();
        _onBuyClicked?.Invoke();
    }

    private bool CanPlayClickScaleEffect()
    {
        return _entry != null && !_entry.Purchased;
    }

    private void PlayClickScaleEffect()
    {
        if (Target == null) return;

        _hoverTween?.Kill();
        _hoverTween = null;
        _clickSequence?.Kill();
        _clickSequence = null;

        _isClickAnimating = true;
        Vector3 startScale = Target.localScale;
        Vector3 pressedScale = startScale * _clickScale;
        Vector3 returnScale = GetIdleScaleForCurrentPointerState();

        _clickSequence = DOTween.Sequence()
            .Append(Target.DOScale(pressedScale, _clickDownDuration).SetEase(Ease.InQuad))
            .Append(Target.DOScale(returnScale, _clickReturnDuration).SetEase(Ease.OutBack))
            .OnComplete(() =>
            {
                _clickSequence = null;
                _isClickAnimating = false;
                AnimateScale(GetIdleScaleForCurrentPointerState());
            })
            .OnKill(() =>
            {
                _clickSequence = null;
                _isClickAnimating = false;
            });
    }

    private Vector3 GetIdleScaleForCurrentPointerState()
    {
        return _isPointerInside ? _baseScale * _hoverScale : _baseScale;
    }

    private void RefreshPriceText()
    {
        if (_priceText == null || _entry == null) return;

        string format = Localize(_priceFormatKey);
        _priceText.text = ShopGoldTextFormatter.Format(format, _entry.Price, _currentGold);
    }

    private static async UniTaskVoid ShowNotEnoughGoldAsync()
    {
        if (!UIManager.HasInstance) return;

        UISystemNavi systemNavi = await UIManager.Instance.OpenAsync<UISystemNavi>();
        systemNavi?.Show(LocalizationKeys.Shop.NotEnoughGold);
    }

    private static string Localize(string key)
    {
        return LocalizationManager.HasInstance
            ? LocalizationManager.Instance.Get(key)
            : key;
    }

    private void OnDestroy()
    {
        _hoverTween?.Kill();
        _clickSequence?.Kill();
        if (Target != null) Target.DOKill();
        if (_buyButton != null) _buyButton.onClick.RemoveListener(HandleBuy);
        _onBuyClicked = null;
        _entry = null;
    }
}
