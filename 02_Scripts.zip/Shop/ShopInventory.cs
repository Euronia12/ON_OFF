// =================================================================
// [스크립트 목적]  상점 1회 방문의 재고(판매 카드 목록 + 각 가격, 카드 제거 비용)를 담는 POCO.
//                 슬더스식 상점 — 카드 N장 판매 + 골드로 카드 제거 서비스.
// [주요 변수]      - Items            : 판매 카드 항목 (카드 + 가격 + 구매여부)
//                  - CardRemovalCost  : 이번 방문의 카드 제거 비용 (점증값, 컨트롤러가 산정)
// [의존 관계]      - ShopController 가 생성(카드 추첨·가격 산정)
//                  - UIShopPopup 이 Items/CardRemovalCost 를 읽어 표시
// [설계 노트]      - BattleReward 와 동일 철학: "무엇을 파는지"만 담고, 실제 적용
//                    (골드 차감·덱 추가/제거)은 구매 처리 시 컨트롤러가 수행한다 (데이터/로직 분리).
//                  - 가격·제거비 산정(희귀도별 기본가, 점증)은 상점 시스템 책임. 이 모델은 확정값 보유.
//                  - 구매된 항목은 Purchased=true 로 표시해 중복 구매·재구매를 막는다.
// =================================================================

using System.Collections.Generic;

/// <summary>상점 판매 카드 1개 (카드 데이터 + 가격 + 구매 여부).</summary>
public sealed class ShopCardEntry
{
    /// <summary>판매 카드 데이터.</summary>
    public CardDataSO Card { get; }

    /// <summary>구매 가격(골드).</summary>
    public int Price { get; }

    /// <summary>상점에 제시된 카드의 확정 화살표 방향. 구매 시 덱 카드에도 그대로 복사한다.</summary>
    public ECardDirection ArrowDirection { get; }

    /// <summary>이미 구매됐는지 여부 (구매 시 컨트롤러가 MarkPurchased).</summary>
    public bool Purchased { get; private set; }

    public ShopCardEntry(CardDataSO card, int price, ECardDirection arrowDirection)
    {
        Card = card;
        Price = price < 0 ? 0 : price;
        ArrowDirection = arrowDirection;
    }

    /// <summary>구매 완료 표시 (중복 구매 방지).</summary>
    public void MarkPurchased()
    {
        Purchased = true;
    }

    public RunSaveShopCardEntry ToSaveData()
    {
        return new RunSaveShopCardEntry
        {
            cardId = Card != null ? Card.CardId : null,
            price = Price,
            arrowDirection = (int)ArrowDirection,
            purchased = Purchased,
        };
    }
}

/// <summary>
/// 상점 1회 방문의 재고. 판매 카드 목록과 카드 제거 비용을 담는다.
/// 생성은 ShopController 가, 표시는 UIShopPopup 이 담당한다.
/// </summary>
public sealed class ShopInventory
{
    private readonly List<ShopCardEntry> _items = new List<ShopCardEntry>(8);

    /// <summary>판매 카드 항목 목록 (읽기 전용).</summary>
    public IReadOnlyList<ShopCardEntry> Items => _items;

    /// <summary>이번 방문의 카드 제거 비용(골드). 0 이하면 제거 서비스 비활성(미제공).</summary>
    public int CardRemovalCost { get; private set; }

    /// <summary>카드 제거 서비스를 이번 방문에 제공하는지.</summary>
    public bool RemovalAvailable => CardRemovalCost > 0;

    public ShopInventory(int cardRemovalCost)
    {
        CardRemovalCost = cardRemovalCost;
    }

    /// <summary>제거 후 비용 점증 반영 — 다음 제거 비용으로 갱신 (방문 중 연속 제거 대응).</summary>
    public void UpdateRemovalCost(int newCost)
    {
        CardRemovalCost = newCost;
    }

    /// <summary>판매 카드 항목 추가 (카드 유효 + 가격 0 이상).</summary>
    public void AddCard(CardDataSO card, int price, ECardDirection arrowDirection)
    {
        if (card == null) return;
        _items.Add(new ShopCardEntry(card, price, arrowDirection));
    }

    public void AddCard(CardDataSO card, int price, ECardDirection arrowDirection, bool purchased)
    {
        if (card == null) return;

        var entry = new ShopCardEntry(card, price, arrowDirection);
        if (purchased)
            entry.MarkPurchased();

        _items.Add(entry);
    }

    public RunSaveShopState ToSaveData(int nodeId)
    {
        var state = new RunSaveShopState
        {
            nodeId = nodeId,
            cardRemovalCost = CardRemovalCost,
        };

        for (int i = 0; i < _items.Count; i++)
        {
            ShopCardEntry entry = _items[i];
            if (entry == null || entry.Card == null) continue;
            state.cards.Add(entry.ToSaveData());
        }

        return state;
    }
}
