﻿// =================================================================
// [스크립트 목적]  상점 창. 판매 카드 슬롯(5)을 나열하고, 카드 제거·나가기를 제공한다.
//                 골드 변동(OnGoldChanged)을 구독해 슬롯들의 구매 가능 표시를 실시간 갱신.
// [주요 변수]      - _slotRoot/_slotPrefab : 카드 슬롯 부모 / 슬롯 프리팹
//                  - _removeButton/_removeCostText : 카드 제거 버튼 / 비용 표시
//                  - _leaveButton/_goldText : 나가기 / 현재 보유 골드 표시
//                  - s_pending : 열기 직전 주입되는 재고 (OpenAsync 인자 제약 우회)
// [의존 관계]      - UIPopupBase / UIManager / UIShopCardSlot / ShopInventory
//                  - EventManager(OnGoldChanged 구독) / InGameController(보유 골드 조회)
//                  - ShopController 가 Show 로 재고 주입 + 콜백 구독
// [배치]           UIManager 로 여는 Popup. 키 = 타입 이름(UIShopPopup).
// [설계 노트]      - 슬롯 생성은 단순 Instantiate/Destroy (상점은 가끔, 항목 적음).
//                  - 구매/제거의 실제 처리(골드·덱)는 ShopController. 이 창은 표시·중계만.
//                  - 골드가 바뀌면(구매·제거) OnGoldChanged 로 통지받아 모든 슬롯 구매가능 재평가.
//                  - 하단 넓은 영역은 향후 룬 판매 자리 — 지금은 비워둠(스케치의 "일단 여백").
//                  - 카드 제거 버튼 → UIDeckCardPicker(덱 1장 고르기)를 열고, 선택된 EntryId 로
//                    OnRemoveCardRequested 를 호출 → 컨트롤러가 제거·점증 처리.
// =================================================================

using System;
using System.Collections.Generic;
using Cysharp.Threading.Tasks;
using UnityEngine;
using UnityEngine.EventSystems;
using TMPro;
using UnityEngine.UI;

/// <summary>
/// 상점 창. 카드 판매 슬롯과 카드 제거/나가기를 표시한다.
/// 구매/제거/나가기는 콜백으로 ShopController 에 통지하고, 골드 변동을 구독해 표시를 갱신한다.
/// </summary>
public sealed class UIShopPopup : UIPopupBase, IBeginDragHandler, IDragHandler, IEndDragHandler
{
    private static readonly int MerchantHappyTriggerHash = Animator.StringToHash("Happy");
    private static readonly int MerchantHappyStateHash = Animator.StringToHash("Merchant_Happy");

    [Header("판매 카드")]
    [Tooltip("카드 슬롯이 들어갈 부모 (가로 레이아웃 권장)")]
    [SerializeField] private Transform _slotRoot;

    [Tooltip("카드 슬롯 프리팹 (UIShopCardSlot)")]
    [SerializeField] private UIShopCardSlot _slotPrefab;

    [Tooltip("카드 호버 시 키워드 설명을 띄우는 공유 패널. 비우면 표시 생략")]
    [SerializeField] private UIKeywordPanel _keywordPanel;

    [Header("텍스트")]
    [SerializeField] private TMP_Text _titleText;
    [SerializeField] private TMP_Text _leaveButtonText;

    [Header("카드 제거")]
    [SerializeField] private Button _removeButton;
    [SerializeField] private TMP_Text _removeCostText;

    [Header("공통")]
    [SerializeField] private Button _leaveButton;

    [Header("상인")]
    [SerializeField] private Button _merchantButton;
    [SerializeField] private Animator _merchantAnimator;

    [Tooltip("상인 이미지 바깥까지 쓰다듬기 판정을 확장할 UI 단위 거리")]
    [Min(0f)]
    [SerializeField] private float _merchantSwipePadding = 80f;

    [Tooltip("Happy 애니메이션을 재생하는 데 필요한 좌우 누적 이동 거리(UI 단위)")]
    [Min(1f)]
    [SerializeField] private float _merchantSwipeDistance = 600f;

    private readonly List<UIShopCardSlot> _slots = new List<UIShopCardSlot>(8);
    private ShopInventory _inventory;
    private IDisposableEvent _goldSub;
    private bool _merchantAnimationPlaying;
    private bool _isMerchantSwiping;
    private float _merchantSwipeAccumulatedDistance;
    private Vector2 _previousMerchantPointerPosition;

    // OpenAsync 가 인자를 못 받으므로, 열기 직전에 재고를 정적으로 예약.
    private static ShopInventory s_pending;

    /// <summary>카드 구매 요청 (해당 판매 항목). 컨트롤러가 골드 차감·덱 추가.</summary>
    public event Action<ShopCardEntry> OnBuyCardRequested;

    /// <summary>카드 제거 요청 (제거할 RunDeckEntry.EntryId). 컨트롤러가 골드 차감·덱 제거.</summary>
    public event Func<int, bool> OnRemoveCardRequested;

    /// <summary>상점 나가기 요청. 컨트롤러가 맵 복귀.</summary>
    public event Action OnLeaveRequested;

    /// <summary>열기 직전 재고 주입 (ShopController 가 OpenAsync 직전 호출).</summary>
    public static void Show(ShopInventory inventory) => s_pending = inventory;

    protected override void Init()
    {
        if (_removeButton != null) _removeButton.onClick.AddListener(HandleRemovePressed);
        if (_leaveButton != null) _leaveButton.onClick.AddListener(HandleLeave);
        RefreshLocalizedTexts();
    }

    protected override void Setup()
    {
        _inventory = s_pending;
        Rebuild(_inventory);
        RefreshLocalizedTexts();

        // 골드 변동 구독 — 구매/제거로 골드가 바뀌면 슬롯·버튼 표시 갱신.
        _goldSub?.Dispose();
        if (EventManager.HasInstance)
        {
            _goldSub = EventManager.Instance.Subscribe<OnGoldChanged>(OnGoldChangedHandler);
        }

        RefreshAffordance();
    }

    public override void OnClose()
    {
        // 슬롯 위에서 닫히면 OnPointerExit 이 오지 않아 키워드 패널(alpha 토글)이 남는다.
        if (_keywordPanel != null) _keywordPanel.Hide();

        ResetMerchantSwipe();
        _goldSub?.Dispose();
        _goldSub = null;
        Clear();
        _inventory = null;
        s_pending = null;
        base.OnClose();
    }

    public override void OnLocalize()
    {
        base.OnLocalize();
        RefreshLocalizedTexts();
        UpdateRemoveCostText(_inventory);

        // 슬롯은 UIBase가 아니라 OnLocalize를 못 받으므로, 부모가 순회하며 가격 텍스트를 갱신한다.
        for (int i = 0; i < _slots.Count; i++)
            _slots[i]?.RefreshLocalization();
    }

    // ─────────────────────────────────────────────
    // 슬롯 구성
    // ─────────────────────────────────────────────

    private void Rebuild(ShopInventory inv)
    {
        Clear();
        if (_slotPrefab == null || _slotRoot == null || inv == null) return;

        IReadOnlyList<ShopCardEntry> items = inv.Items;
        for (int i = 0; i < items.Count; i++)
        {
            ShopCardEntry entry = items[i];
            if (entry == null) continue;

            UIShopCardSlot slot = Instantiate(_slotPrefab, _slotRoot);
            slot.Bind(entry, () => HandleBuy(slot));
            slot.SetKeywordPanel(_keywordPanel);
            _slots.Add(slot);
        }

        UpdateRemoveCostText(inv);
    }

    public void RefreshDebugInventory(ShopInventory inventory)
    {
        _inventory = inventory;
        Rebuild(_inventory);
        RefreshAffordance();
    }

    private void Clear()
    {
        for (int i = 0; i < _slots.Count; i++)
        {
            if (_slots[i] == null) continue;
            _slots[i].gameObject.SetActive(false);
            Destroy(_slots[i].gameObject);
        }
        _slots.Clear();
    }

    private void UpdateRemoveCostText(ShopInventory inv)
    {
        if (_removeButton != null) _removeButton.gameObject.SetActive(inv != null && inv.RemovalAvailable);
        if (_removeCostText != null && inv != null)
        {
            _removeCostText.text = FormatGoldCost(
                LocalizationKeys.Shop.RemoveCostFormat,
                inv.CardRemovalCost,
                CurrentGold());
        }
    }

    // ─────────────────────────────────────────────
    // 구매 / 제거 / 나가기
    // ─────────────────────────────────────────────

    private void HandleBuy(UIShopCardSlot slot)
    {
        if (slot == null || slot.Entry == null || slot.Entry.Purchased) return;

        OnBuyCardRequested?.Invoke(slot.Entry);
        // 구매 처리 후 골드 변동이 OnGoldChanged 로 통지되어 RefreshAffordance 가 돌지만,
        // 구매 당사자 슬롯의 품절 표시는 즉시 반영되도록 한 번 더 갱신.
        RefreshAffordance();
    }

    private void HandleRemovePressed()
    {
        if (_inventory == null || !_inventory.RemovalAvailable) return;
        if (CurrentGold() < _inventory.CardRemovalCost)
        {
            ShowNotEnoughGoldAsync().Forget();
            return;
        }

        OpenRemovePickerAsync().Forget();
    }

    /// <summary>덱 카드 피커를 열어 제거할 카드를 고르게 한다. 선택 시 제거 요청.</summary>
    private async UniTaskVoid OpenRemovePickerAsync()
    {
        if (!UIManager.HasInstance) return;

        RunContext run = InGameController.HasInstance ? InGameController.Instance.CurrentRun : null;
        if (run == null || run.DeckCardIds.Count == 0)
        {
#if UNITY_EDITOR || DEVELOPMENT_BUILD
            Debug.Log("[UIShopPopup] 제거할 카드가 덱에 없음");
#endif
            return;
        }

        // 현재 덱 스냅샷을 피커에 전달 (선택 중 덱이 안 바뀌므로 그대로 사용).
        List<RunDeckEntry> deck = new List<RunDeckEntry>(run.DeckEntries);

        UIDeckCardPicker.Show(
            deck,
            title: Localize(LocalizationKeys.Shop.RemovePickerTitle),
            confirmMessage: Localize(LocalizationKeys.Shop.RemovePickerConfirm),
            cancelable: true);
        UIDeckCardPicker picker = await UIManager.Instance.OpenAsync<UIDeckCardPicker>();
        if (picker == null) return;

        void Unsubscribe()
        {
            picker.OnEntryConfirmed -= OnPicked;
            picker.OnCancelled -= OnCancelled;
        }
        void OnPicked(int entryId)
        {
            bool removed = RequestRemoveCard(entryId);
            if (!removed)
            {
                picker.ShowMessageAndReturnToList(Localize(LocalizationKeys.Shop.RemoveFailed));
                return;
            }

            Unsubscribe();
            if (UIManager.HasInstance)
                UIManager.Instance.Close(picker);
        }
        void OnCancelled()
        {
            Unsubscribe();
        }

        picker.OnEntryConfirmed += OnPicked;
        picker.OnCancelled += OnCancelled;
    }

    /// <summary>외부(카드 선택 UI)에서 제거 대상이 정해지면 호출하는 진입점.</summary>
    public bool RequestRemoveCard(int entryId)
    {
        bool removed = OnRemoveCardRequested?.Invoke(entryId) == true;
        if (removed)
            RefreshAffordance();
        return removed;
    }

    private void HandleLeave()
    {
        // 컨트롤러가 페이드로 화면을 가린 뒤 닫는다.
        OnLeaveRequested?.Invoke();
    }

    public void OnBeginDrag(PointerEventData eventData)
    {
        if (eventData == null
            || eventData.button != PointerEventData.InputButton.Left
            || _merchantAnimationPlaying
            || _merchantAnimator == null
            || !TryGetMerchantPointerPosition(eventData, out Vector2 pointerPosition)
            || !IsWithinMerchantSwipeArea(pointerPosition))
        {
            ResetMerchantSwipe();
            return;
        }

        _isMerchantSwiping = true;
        _merchantSwipeAccumulatedDistance = 0f;
        _previousMerchantPointerPosition = pointerPosition;
    }

    public void OnDrag(PointerEventData eventData)
    {
        if (!_isMerchantSwiping || eventData == null || _merchantAnimationPlaying) return;

        if (!TryGetMerchantPointerPosition(eventData, out Vector2 pointerPosition)
            || !IsWithinMerchantSwipeArea(pointerPosition))
        {
            ResetMerchantSwipe();
            return;
        }

        Vector2 delta = pointerPosition - _previousMerchantPointerPosition;
        _previousMerchantPointerPosition = pointerPosition;
        if (Mathf.Abs(delta.x) <= Mathf.Abs(delta.y)) return;

        _merchantSwipeAccumulatedDistance += Mathf.Abs(delta.x);
        if (_merchantSwipeAccumulatedDistance < _merchantSwipeDistance) return;

        ResetMerchantSwipe();
        PlayMerchantHappyAsync().Forget();
    }

    public void OnEndDrag(PointerEventData eventData)
    {
        ResetMerchantSwipe();
    }

    private bool TryGetMerchantPointerPosition(PointerEventData eventData, out Vector2 pointerPosition)
    {
        RectTransform merchantRect = _merchantButton != null
            ? _merchantButton.transform as RectTransform
            : null;
        if (merchantRect == null)
        {
            pointerPosition = default;
            return false;
        }

        return RectTransformUtility.ScreenPointToLocalPointInRectangle(
            merchantRect,
            eventData.position,
            eventData.pressEventCamera,
            out pointerPosition);
    }

    private bool IsWithinMerchantSwipeArea(Vector2 pointerPosition)
    {
        RectTransform merchantRect = _merchantButton != null
            ? _merchantButton.transform as RectTransform
            : null;
        if (merchantRect == null) return false;

        Rect swipeArea = merchantRect.rect;
        swipeArea.xMin -= _merchantSwipePadding;
        swipeArea.xMax += _merchantSwipePadding;
        swipeArea.yMin -= _merchantSwipePadding;
        swipeArea.yMax += _merchantSwipePadding;
        return swipeArea.Contains(pointerPosition);
    }

    private void ResetMerchantSwipe()
    {
        _isMerchantSwiping = false;
        _merchantSwipeAccumulatedDistance = 0f;
        _previousMerchantPointerPosition = default;
    }

    private async UniTaskVoid PlayMerchantHappyAsync()
    {
        _merchantAnimationPlaying = true;
        if (_merchantButton != null) _merchantButton.interactable = false;

        try
        {
            _merchantAnimator.ResetTrigger(MerchantHappyTriggerHash);
            _merchantAnimator.SetTrigger(MerchantHappyTriggerHash);

            // Happy 상태 진입과 Idle 복귀를 모두 확인해 전환 중 중복 클릭도 막는다.
            bool cancelled = await UniTask.WaitUntil(
                    () => _merchantAnimator != null
                          && _merchantAnimator.GetCurrentAnimatorStateInfo(0).shortNameHash
                          == MerchantHappyStateHash,
                    cancellationToken: this.GetCancellationTokenOnDestroy())
                .SuppressCancellationThrow();
            if (cancelled) return;

            await UniTask.WaitUntil(
                    () => _merchantAnimator == null
                          || (!_merchantAnimator.IsInTransition(0)
                              && _merchantAnimator.GetCurrentAnimatorStateInfo(0).shortNameHash
                              != MerchantHappyStateHash),
                    cancellationToken: this.GetCancellationTokenOnDestroy())
                .SuppressCancellationThrow();
        }
        finally
        {
            _merchantAnimationPlaying = false;
            if (_merchantButton != null) _merchantButton.interactable = true;
        }
    }

    // ─────────────────────────────────────────────
    // 골드 변동 반영
    // ─────────────────────────────────────────────

    private void OnGoldChangedHandler(OnGoldChanged evt)
    {
        RefreshAffordance();
    }

    /// <summary>현재 보유 골드로 각 슬롯·제거 버튼의 구매 가능 여부를 갱신.</summary>
    private void RefreshAffordance()
    {
        int gold = CurrentGold();

        for (int i = 0; i < _slots.Count; i++)
        {
            UIShopCardSlot slot = _slots[i];
            if (slot == null || slot.Entry == null) continue;
            slot.Refresh(gold);
        }

        // 제거 비용은 방문 중 점증할 수 있으므로 텍스트·버튼을 매번 갱신.
        if (_inventory != null && _inventory.RemovalAvailable)
        {
            if (_removeCostText != null)
            {
                _removeCostText.text = FormatGoldCost(
                    LocalizationKeys.Shop.RemoveCostFormat,
                    _inventory.CardRemovalCost,
                    gold);
            }
            if (_removeButton != null)
            {
                // 잔액 부족은 클릭 경고로 안내하기 위해 버튼은 활성 상태로 둔다.
                _removeButton.interactable = true;
            }
        }
    }

    private int CurrentGold()
    {
        RunContext run = InGameController.HasInstance ? InGameController.Instance.CurrentRun : null;
        return run != null ? run.Gold : 0;
    }

    private void RefreshLocalizedTexts()
    {
        if (_titleText != null)
            _titleText.text = Localize(LocalizationKeys.Shop.Title);
        if (_leaveButtonText != null)
            _leaveButtonText.text = Localize(LocalizationKeys.Shop.LeaveButton);
    }

    private static string Localize(string key)
    {
        return LocalizationManager.HasInstance
            ? LocalizationManager.Instance.Get(key)
            : key;
    }

    private static string FormatGoldCost(string formatKey, int amount, int currentGold)
    {
        return ShopGoldTextFormatter.Format(Localize(formatKey), amount, currentGold);
    }

    private static async UniTaskVoid ShowNotEnoughGoldAsync()
    {
        if (!UIManager.HasInstance) return;

        UISystemNavi systemNavi = await UIManager.Instance.OpenAsync<UISystemNavi>();
        systemNavi?.Show(LocalizationKeys.Shop.NotEnoughGold);
    }

    private void OnDestroy()
    {
        _goldSub?.Dispose();
        _goldSub = null;
        if (_removeButton != null) _removeButton.onClick.RemoveListener(HandleRemovePressed);
        if (_leaveButton != null) _leaveButton.onClick.RemoveListener(HandleLeave);
        OnBuyCardRequested = null;
        OnRemoveCardRequested = null;
        OnLeaveRequested = null;
    }
}

internal static class ShopGoldTextFormatter
{
    public static string Format(string localizedFormat, int amount, int currentGold)
    {
        string amountText = amount.ToString();
        if (amount > currentGold)
        {
            amountText = $"<color={EUIColor.RedLight.ToHex()}>{amountText}</color>";
        }

        if (!string.IsNullOrEmpty(localizedFormat) && localizedFormat.Contains("{0}"))
        {
            return string.Format(localizedFormat, amountText);
        }

        return $"{amountText} {localizedFormat}";
    }
}
