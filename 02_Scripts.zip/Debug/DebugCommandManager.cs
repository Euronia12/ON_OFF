using System;
using System.Collections.Generic;
using Cysharp.Threading.Tasks;
using UnityEngine;

public enum EDebugCommand
{
    AddGold, OpenCardDebug, RerollReward, KillEnemy, RerollShop,
    OpenNodeDebug, OpenEventDebug, OpenEnemyDebug, ResetSkillCooldown,
    GainMana, DrawCard, MulliganHand, FullHeal, DamagePlayer, OpenSeedDebug,
    ResetSteamAchievements
}

/// <summary>Dev/Test QA 커맨드의 유일한 실행 경계. 모든 UI는 Addressable UIPopupBase 프리팹으로 연다.</summary>
public sealed class DebugCommandManager : MonoBehaviour
{
    private static DebugCommandManager _instance;
    private static bool _hasOneShotSeed;
    private static int _oneShotSeed;
    private static bool _hasSessionSeed;
    private static int _sessionSeed;
    private static bool _hasPendingNodeType;
    private static ENodeType _pendingNodeType;
    private static string _pendingEventId;
    private static string _pendingEnemyId;

    private readonly Dictionary<EDebugCommand, int> _liveReportCounts = new();

    public static void EnsureInitialized()
    {
        if (_instance != null) return;
        var go = new GameObject("[DebugCommandManager]");
        DontDestroyOnLoad(go);
        _instance = go.AddComponent<DebugCommandManager>();
        if (InputManager.HasInstance)
            InputManager.Instance.OnTestCommandPerformed += _instance.HandleInputCommand;
    }

    public static void Shutdown()
    {
        if (_instance == null) return;
        if (InputManager.HasInstance)
            InputManager.Instance.OnTestCommandPerformed -= _instance.HandleInputCommand;
        Destroy(_instance.gameObject);
        _instance = null;
        _hasOneShotSeed = false;
        _hasSessionSeed = false;
        ClearPendingOverrides();
    }

    private void OnDestroy()
    {
        if (_instance == this) _instance = null;
    }

    private void HandleInputCommand(string actionName)
    {
        if (TryMap(actionName, out EDebugCommand command))
            TryExecute(command);
    }

    public bool TryExecute(EDebugCommand command)
    {
        if (!CanExecute(command)) return false;

        try
        {
            bool success = command switch
            {
                EDebugCommand.AddGold => InGameController.HasInstance && InGameController.Instance.TryDebugGrantGold(1000),
                EDebugCommand.OpenCardDebug => OpenCardPopup(),
                EDebugCommand.RerollReward => InGameController.HasInstance && InGameController.Instance.TryDebugRerollReward(),
                EDebugCommand.KillEnemy => BattleController.HasInstance && BattleController.Instance.TryDebugKillEnemy(),
                EDebugCommand.RerollShop => ShopController.HasInstance && ShopController.Instance.TryDebugRerollInventory(),
                EDebugCommand.OpenNodeDebug => OpenNodePopup(),
                EDebugCommand.OpenEventDebug => OpenEventPopup(),
                EDebugCommand.OpenEnemyDebug => OpenEnemyPopup(),
                EDebugCommand.ResetSkillCooldown => TryResetSkillCooldowns(),
                EDebugCommand.GainMana => BattleController.HasInstance && BattleController.Instance.TryDebugGainMana(10),
                EDebugCommand.DrawCard => BattleController.HasInstance && BattleController.Instance.TryDebugDrawCards(1),
                EDebugCommand.MulliganHand => BattleController.HasInstance && BattleController.Instance.TryDebugMulliganHand(),
                EDebugCommand.FullHeal => InGameController.HasInstance && InGameController.Instance.TryDebugFullHeal(),
                EDebugCommand.DamagePlayer => TryDamagePlayer(),
                EDebugCommand.OpenSeedDebug => OpenSeedPopup(),
                EDebugCommand.ResetSteamAchievements => TryResetSteamAchievements(),
                _ => false,
            };
            if (!success) ShowMessage($"{command}: 현재 상태에서 실행할 수 없습니다.");
            return success;
        }
        catch (Exception e)
        {
            Debug.LogError($"[DebugCommand] {command} 실행 예외: {e}");
            return false;
        }
    }

    private bool CanExecute(EDebugCommand command)
    {
        if (!GameManager.HasInstance) return false;
        if (GameManager.Instance.IsLive)
        {
            ReportLiveAttempt(command);
            return false;
        }
        if (!GameManager.Instance.CanUseTestCommands) return false;
        return true;
    }

    public static bool CanExecuteDomain(EDebugCommand command)
        => _instance != null && _instance.CanExecute(command);

    private void ReportLiveAttempt(EDebugCommand command)
    {
        _liveReportCounts.TryGetValue(command, out int count);
        if (count >= 3) return;
        _liveReportCounts[command] = count + 1;
        GameLog.DebugCommandBlocked(command.ToString());
        Debug.LogError($"[DebugCommand] Live에서 차단됨: {command}");
    }

    private bool TryDamagePlayer()
    {
        if (!BattleController.HasInstance) return false;
        bool success = BattleController.Instance.TryDebugDamagePlayer(out int amount);
        if (success) ShowMessage($"플레이어 체력 -{amount}");
        return success;
    }

    private static bool TryResetSkillCooldowns()
    {
        if (!UIManager.HasInstance) return false;
        UIBattle battleUI = UIManager.Instance.Get<UIBattle>();
        return battleUI != null && battleUI.TryResetDebugSkillCooldowns();
    }

    private static bool TryResetSteamAchievements()
    {
        return SteamAchievementManager.HasInstance &&
               SteamAchievementManager.Instance.ClearAllAchievementsForTesting();
    }

    private bool CanOpenRunPopup()
        => UIManager.HasInstance && InGameController.HasInstance && InGameController.Instance.IsRunActive;

    private bool OpenCardPopup()
    {
        if (!CanOpenRunPopup()) return false;
        OpenCardPopupAsync().Forget();
        return true;
    }

    private async UniTaskVoid OpenCardPopupAsync()
    {
        UIDebugCard popup = await UIManager.Instance.OpenAsync<UIDebugCard>();
        if (popup == null) return;
        popup.OnAddRequested -= HandleCardAddRequested;
        popup.OnAddRequested += HandleCardAddRequested;
        popup.Bind(GetCards());
    }

    private void HandleCardAddRequested(CardDataSO card, int count, ECardDirection? direction)
    {
        bool success = card != null && InGameController.HasInstance &&
                       InGameController.Instance.TryDebugAddCards(card.CardId, count, direction);
        UIDebugCard popup = UIManager.HasInstance ? UIManager.Instance.Get<UIDebugCard>() : null;
        popup?.SetMessage(success ? $"{card.CardId} {count}장 추가 완료" : "카드 추가 실패");
    }

    private bool OpenNodePopup()
    {
        if (!CanOpenRunPopup()) return false;
        OpenNodePopupAsync().Forget();
        return true;
    }

    private async UniTaskVoid OpenNodePopupAsync()
    {
        UIDebugLog popup = await UIManager.Instance.OpenAsync<UIDebugLog>();
        if (popup == null) return;
        popup.OnApplyRequested -= HandleNodeTypeRequested;
        popup.OnApplyRequested += HandleNodeTypeRequested;
    }

    private void HandleNodeTypeRequested(ENodeType type)
    {
        if (!TrySetPendingNodeType(type)) return;
        ShowMessage($"다음 노드 타입 예약: {type}");
        ClosePopup<UIDebugLog>();
    }

    private bool OpenEventPopup()
    {
        if (!CanOpenRunPopup()) return false;
        OpenEventPopupAsync().Forget();
        return true;
    }

    private async UniTaskVoid OpenEventPopupAsync()
    {
        UIDebugEvent popup = await UIManager.Instance.OpenAsync<UIDebugEvent>();
        if (popup == null) return;
        popup.OnApplyRequested -= HandleEventRequested;
        popup.OnApplyRequested += HandleEventRequested;
        popup.Bind(GetEvents());
    }

    private void HandleEventRequested(EventDataSO data)
    {
        if (data == null || !TrySetPendingEvent(data.EventId)) return;
        ShowMessage($"다음 이벤트 예약: {data.EventId}");
        ClosePopup<UIDebugEvent>();
    }

    private bool OpenEnemyPopup()
    {
        if (!CanOpenRunPopup()) return false;
        OpenEnemyPopupAsync().Forget();
        return true;
    }

    private async UniTaskVoid OpenEnemyPopupAsync()
    {
        UIDebugEnemy popup = await UIManager.Instance.OpenAsync<UIDebugEnemy>();
        if (popup == null) return;
        popup.OnApplyRequested -= HandleEnemyRequested;
        popup.OnApplyRequested += HandleEnemyRequested;
        popup.Bind(GetEnemies());
    }

    private void HandleEnemyRequested(EnemyDataSO data)
    {
        if (data == null || !TrySetPendingEnemy(data.EnemyId)) return;
        ShowMessage($"다음 전투 적 예약: {data.EnemyId}");
        ClosePopup<UIDebugEnemy>();
    }

    private bool OpenSeedPopup()
    {
        if (!UIManager.HasInstance || (GameFlowManager.HasInstance && GameFlowManager.Instance.State == EGameState.Loading))
            return false;
        OpenSeedPopupAsync().Forget();
        return true;
    }

    private async UniTaskVoid OpenSeedPopupAsync()
    {
        UIDebugSeed popup = await UIManager.Instance.OpenAsync<UIDebugSeed>();
        if (popup == null) return;
        popup.OnApplyRequested -= HandleSeedRequested;
        popup.OnApplyRequested += HandleSeedRequested;

        bool isTitle = GameFlowManager.HasInstance && GameFlowManager.Instance.State == EGameState.Title;
        if (isTitle) popup.BindTitle();
        else popup.BindMain(InGameController.HasInstance && InGameController.Instance.IsRunActive
            ? InGameController.Instance.CurrentSeed : null);
    }

    private void HandleSeedRequested(int seed, bool session)
    {
        if (!CanExecuteDomain(EDebugCommand.OpenSeedDebug)) return;
        if (session)
        {
            _sessionSeed = seed;
            _hasSessionSeed = true;
        }
        else
        {
            _oneShotSeed = seed;
            _hasOneShotSeed = true;
        }
        UIDebugSeed popup = UIManager.HasInstance ? UIManager.Instance.Get<UIDebugSeed>() : null;
        popup?.SetMessage($"시드 {seed} 설정 완료 ({(session ? "계속" : "1회")})");
    }

    private static void ClosePopup<T>() where T : UIBase
    {
        if (UIManager.HasInstance)
        {
            T popup = UIManager.Instance.Get<T>();
            if (popup != null) UIManager.Instance.Close(popup);
        }
    }

    public static int ResolveNewRunSeed(int fallback)
    {
        if (!CanMutateDebugState())
        {
            _hasOneShotSeed = false;
            _hasSessionSeed = false;
            return fallback;
        }
        if (_hasOneShotSeed)
        {
            _hasOneShotSeed = false;
            return _oneShotSeed;
        }
        return _hasSessionSeed ? _sessionSeed : fallback;
    }

    public static bool TryApplyPendingNodeOverrides(MapNode node)
    {
        if (node == null || !CanMutateDebugState()) return false;
        bool changed = false;
        if (_hasPendingNodeType)
        {
            node.NodeType = _pendingNodeType;
            _hasPendingNodeType = false;
            changed = true;
        }
        if (IsBattleNode(node.NodeType))
        {
            if (!string.IsNullOrEmpty(_pendingEnemyId))
            {
                node.EnemyId = _pendingEnemyId;
                _pendingEnemyId = null;
                changed = true;
            }
            else if (string.IsNullOrEmpty(node.EnemyId))
            {
                EnemyDataSO fallback = SelectEnemyForNode(node.NodeType);
                if (fallback != null) node.EnemyId = fallback.EnemyId;
            }
        }
        else node.EnemyId = null;
        return changed;
    }

    private static bool TrySetPendingNodeType(ENodeType type)
    {
        if (!CanExecuteDomain(EDebugCommand.OpenNodeDebug) || type == ENodeType.None) return false;
        _pendingNodeType = type;
        _hasPendingNodeType = true;
        return true;
    }

    private static bool TrySetPendingEvent(string eventId)
    {
        if (!CanExecuteDomain(EDebugCommand.OpenEventDebug) || string.IsNullOrWhiteSpace(eventId)) return false;
        _pendingEventId = eventId;
        return true;
    }

    private static bool TrySetPendingEnemy(string enemyId)
    {
        if (!CanExecuteDomain(EDebugCommand.OpenEnemyDebug) || string.IsNullOrWhiteSpace(enemyId)) return false;
        _pendingEnemyId = enemyId;
        return true;
    }

    public static bool TryGetForcedEvent(out EventDataSO data)
    {
        data = null;
        if (string.IsNullOrEmpty(_pendingEventId) || !CanMutateDebugState() || !DataManager.HasInstance)
            return false;
        data = DataManager.Instance.GetData<EventDataSO>(_pendingEventId);
        return data != null;
    }

    public static void ConsumeForcedEvent(EventDataSO data)
    {
        if (data != null && string.Equals(_pendingEventId, data.EventId, StringComparison.Ordinal))
            _pendingEventId = null;
    }

    public static void ResetRunPendingOverrides()
    {
        ClearPendingOverrides();
        ClosePopup<UIDebugCard>();
        ClosePopup<UIDebugLog>();
        ClosePopup<UIDebugEvent>();
        ClosePopup<UIDebugEnemy>();
    }

    private static bool CanMutateDebugState()
    {
        return GameManager.HasInstance && GameManager.Instance.CanUseTestCommands && !GameManager.Instance.IsLive;
    }

    private static void ClearPendingOverrides()
    {
        _hasPendingNodeType = false;
        _pendingEventId = null;
        _pendingEnemyId = null;
    }

    private static List<CardDataSO> GetCards()
    {
        var result = DataManager.HasInstance ? new List<CardDataSO>(DataManager.Instance.GetAllData<CardDataSO>()) : new List<CardDataSO>();
        result.RemoveAll(card => card == null || string.IsNullOrWhiteSpace(card.CardId));
        result.Sort((a, b) => string.CompareOrdinal(a.CardId, b.CardId));
        return result;
    }

    private static List<EventDataSO> GetEvents()
    {
        var result = DataManager.HasInstance ? new List<EventDataSO>(DataManager.Instance.GetAllData<EventDataSO>()) : new List<EventDataSO>();
        result.RemoveAll(data => data == null || !data.Enabled || string.IsNullOrWhiteSpace(data.EventId));
        result.Sort((a, b) => string.CompareOrdinal(a.EventId, b.EventId));
        return result;
    }

    private static List<EnemyDataSO> GetEnemies()
    {
        var result = DataManager.HasInstance ? new List<EnemyDataSO>(DataManager.Instance.GetAllData<EnemyDataSO>()) : new List<EnemyDataSO>();
        result.RemoveAll(data => data == null || string.IsNullOrWhiteSpace(data.EnemyId));
        result.Sort((a, b) => string.CompareOrdinal(a.EnemyId, b.EnemyId));
        return result;
    }

    private static bool IsBattleNode(ENodeType type)
        => type == ENodeType.Battle || type == ENodeType.Elite || type == ENodeType.Boss || type == ENodeType.Test;

    private static EnemyDataSO SelectEnemyForNode(ENodeType type)
    {
        if (!DataManager.HasInstance) return null;
        EEnemyGrade grade = type == ENodeType.Elite ? EEnemyGrade.Elite :
            type == ENodeType.Boss ? EEnemyGrade.Boss :
            type == ENodeType.Test ? EEnemyGrade.Test : EEnemyGrade.Normal;
        List<EnemyDataSO> all = DataManager.Instance.GetAllData<EnemyDataSO>();
        for (int i = 0; i < all.Count; i++)
            if (all[i] != null && all[i].Grade == grade) return all[i];
        return all.Count > 0 ? all[0] : null;
    }

    private static void ShowMessage(string message) => Debug.Log($"[DebugCommand] {message}");

    private static bool TryMap(string action, out EDebugCommand command)
    {
        command = action switch
        {
            InputActionNames.AddGold => EDebugCommand.AddGold,
            InputActionNames.OpenCardDebug => EDebugCommand.OpenCardDebug,
            InputActionNames.RerollReward => EDebugCommand.RerollReward,
            InputActionNames.KillEnemy => EDebugCommand.KillEnemy,
            InputActionNames.RerollShop => EDebugCommand.RerollShop,
            InputActionNames.OpenNodeDebug => EDebugCommand.OpenNodeDebug,
            InputActionNames.OpenEventDebug => EDebugCommand.OpenEventDebug,
            InputActionNames.OpenEnemyDebug => EDebugCommand.OpenEnemyDebug,
            InputActionNames.ResetSkillCooldown => EDebugCommand.ResetSkillCooldown,
            InputActionNames.GainMana => EDebugCommand.GainMana,
            InputActionNames.DrawCard => EDebugCommand.DrawCard,
            InputActionNames.MulliganHand => EDebugCommand.MulliganHand,
            InputActionNames.FullHeal => EDebugCommand.FullHeal,
            InputActionNames.DamagePlayer => EDebugCommand.DamagePlayer,
            InputActionNames.OpenSeedDebug => EDebugCommand.OpenSeedDebug,
            InputActionNames.ResetSteamAchievements => EDebugCommand.ResetSteamAchievements,
            _ => (EDebugCommand)(-1)
        };
        return (int)command >= 0;
    }
}
