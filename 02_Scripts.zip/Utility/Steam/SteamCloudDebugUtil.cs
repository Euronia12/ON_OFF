// =================================================================
// [스크립트 목적]  Steam Auto-Cloud 동기화 상태 확인용 디버그 유틸 (실제 클라우드 로직 아님)
//                 파트너사이트 Auto-Cloud 설정이 실제로 먹는지 개발 중 눈으로 확인하는 용도
// [주요 변수]      - 없음 (정적 조회 전용)
// [의존 관계]      - SteamManager(IsSteamRunning), Steamworks.NET(SteamRemoteStorage)
// [주의]           개발/에디터 빌드에서만 컴파일·동작. 출시 빌드에는 포함되지 않음
// =================================================================
using UnityEngine;
#if !DISABLESTEAMWORKS
using Steamworks;
#endif

/// <summary>
/// Steam 클라우드 상태를 콘솔로 덤프하는 개발용 유틸.
/// GameObject에 붙여 ContextMenu로 호출하거나, DumpCloudState()를 코드에서 직접 호출.
/// </summary>
public class SteamCloudDebugUtil : MonoBehaviour
{
#if UNITY_EDITOR || DEVELOPMENT_BUILD
    [ContextMenu("Dump Steam Cloud State")]
    private void DumpFromContextMenu() => DumpCloudState();

    /// <summary>
    /// Steam 클라우드 활성 여부·용량·저장 파일 목록을 콘솔에 출력.
    /// SteamManager 초기화 완료 시에만 동작.
    /// </summary>
    public static void DumpCloudState()
    {
        if (!SteamManager.HasInstance || !SteamManager.Instance.IsSteamRunning)
        {
            GameLogger.LogWarning(ELogCategory.System,
                "[SteamCloudDebug] Steam 미초기화 — 클라우드 상태 조회 불가");
            return;
        }

#if !DISABLESTEAMWORKS
        // 앱/계정 단위 클라우드 활성 여부 (둘 다 켜져야 실제 동기화됨)
        bool appEnabled = SteamRemoteStorage.IsCloudEnabledForApp();
        bool accountEnabled = SteamRemoteStorage.IsCloudEnabledForAccount();

        // 사용량/전체 용량 (바이트)
        SteamRemoteStorage.GetQuota(out ulong totalBytes, out ulong availableBytes);
        ulong usedBytes = totalBytes >= availableBytes ? totalBytes - availableBytes : 0;

        var sb = new System.Text.StringBuilder();
        sb.AppendLine("===== [Steam Cloud Debug] =====");
        sb.AppendLine($"CloudEnabledForApp     : {appEnabled}");
        sb.AppendLine($"CloudEnabledForAccount : {accountEnabled}");
        sb.AppendLine($"Quota                  : {usedBytes} / {totalBytes} bytes (avail {availableBytes})");

        // 클라우드에 올라간 파일 목록 열거
        int fileCount = SteamRemoteStorage.GetFileCount();
        sb.AppendLine($"FileCount              : {fileCount}");
        for (int i = 0; i < fileCount; i++)
        {
            string fileName = SteamRemoteStorage.GetFileNameAndSize(i, out int size);
            sb.AppendLine($"  - {fileName} ({size} bytes)");
        }

        GameLogger.Log(ELogCategory.System, sb.ToString());
#endif
    }
#endif
}
