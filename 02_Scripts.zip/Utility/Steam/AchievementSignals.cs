// =================================================================
// [스크립트 목적]  업적 판정에 필요한 "게임플레이 신호" struct 모음
//                 게임 로직은 이 신호만 EventManager로 발행하고 Steam/업적을 전혀 모른다
//                 (디커플링: SteamAchievementBridge가 구독해 업적으로 변환)
// [사용 패턴]      발행 → EventManager.Instance.Publish(new XxxSignal(...))
//                  구독 → EventManager.Instance.Subscribe<XxxSignal>(handler)
// [의존 관계]      EventManager(Publish/Subscribe), ECardDirection
// [주의]           전부 readonly struct (EventManager.Publish 제약: where T : struct, GC 없음)
// =================================================================

/// <summary>마나(Energy) 값이 변경됐을 때. 현재값 기반 "N 이상" 업적 판정용.</summary>
public readonly struct ManaChangedSignal
{
    public readonly int Current;
    public ManaChangedSignal(int current) => Current = current;
}

/// <summary>유리칼(GlassBlade) 타입의 최종 데미지가 0에 도달했을 때.</summary>
public readonly struct GlassBladeDamageZeroSignal { }

/// <summary>
/// 적이 사망한 시점의 스냅샷. 사망 순간의 판정 정보를 함께 실어 보낸다.
/// </summary>
/// <remarks>
/// AllGridCardsActive : 사망 시점 그리드에 배치된 카드가 모두 활성(ON) 상태인지.
/// </remarks>
public readonly struct EnemyDefeatedSignal
{
    public readonly bool AllGridCardsActive;

    public EnemyDefeatedSignal(bool allGridCardsActive)
        => AllGridCardsActive = allGridCardsActive;
}

/// <summary>캐스팅 카운트가 소진돼 효과가 실제로 발동됐을 때.</summary>
public readonly struct CastingResolvedSignal { }

/// <summary>동시 시전대기(pending) 캐스팅 개수가 변했을 때. "동시 N개" 업적 판정용.</summary>
public readonly struct PendingCastingCountSignal
{
    public readonly int Count;
    public PendingCastingCountSignal(int count) => Count = count;
}

/// <summary>
/// 그리드 카드에 화살표가 추가됐을 때의 문맥.
/// 발행 측은 "어떤 카드에 붙었나"라는 원시 사실만 싣고, 어떤 카드가 업적 대상인지는 구독 측이 판단한다.
/// CardId     : 화살표가 추가된 카드의 ID.
/// InfoHidden : 부여 시점에 그리드 정보 은폐(실명/EraseInfo) 상태였는지.
/// </summary>
public readonly struct ArrowAddedSignal
{
    public readonly string CardId;
    public readonly bool InfoHidden;

    public ArrowAddedSignal(string cardId, bool infoHidden)
    {
        CardId = cardId;
        InfoHidden = infoHidden;
    }
}

/// <summary>파편화살(Shotgun)에 화살표가 부여됐을 때, 부여된 최종 방향 집합.</summary>
public readonly struct ShardArrowSignal
{
    public readonly ECardDirection Directions;
    public ShardArrowSignal(ECardDirection directions) => Directions = directions;
}

/// <summary>
/// 한 번의 포식(Predate)이 완료됐을 때.
/// </summary>
/// <remarks>
/// DevouredCount      : 이번 1회 포식으로 삼킨 카드 수.
///                      포식은 방향당 인접 1칸만 삼키므로 최대 8 = 8방향 전부 포식을 의미한다.
/// TotalDevouredCount : 이 포식 카드가 지금까지 삼킨 카드의 누적 장수.
///                      카드 인스턴스 단위이며 그리드를 떠나면 초기화된다.
/// </remarks>
public readonly struct PredationSignal
{
    public readonly int DevouredCount;
    public readonly int TotalDevouredCount;

    public PredationSignal(int devouredCount, int totalDevouredCount)
    {
        DevouredCount = devouredCount;
        TotalDevouredCount = totalDevouredCount;
    }
}

/// <summary>
/// 적의 그리드 자르기(GridLineAttack)를 배치된 카드가 흡수해 막았을 때.
/// 스테이지 순서가 아니라 적 등급(보스 여부)만 싣는다 — 스테이지 구성이 바뀌어도 판정 유지.
/// </summary>
public readonly struct GridCutBlockedSignal
{
    public readonly bool IsBossBattle;
    public GridCutBlockedSignal(bool isBossBattle) => IsBossBattle = isBossBattle;
}

/// <summary>적이 설치한 방해카드가 제거되지 않고 보존됐을 때.</summary>
public readonly struct DisturbancePreservedSignal { }

/// <summary>이번 런에서 스킬이 사용됐을 때(스킬 미사용 클리어 판정용 런 플래그 표식).</summary>
public readonly struct SkillUsedSignal { }

/// <summary>그리드가 전부 채워졌을 때(빈 슬롯 0).</summary>
public readonly struct GridFilledSignal { }
