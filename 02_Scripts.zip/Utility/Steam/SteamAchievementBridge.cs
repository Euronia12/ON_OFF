// =================================================================
// [스크립트 목적]  게임플레이 이벤트를 Steam 업적으로 변환하는 얇은 리스너(디커플링 계층)
//                 게임 로직은 업적을 모르고, 이 브릿지만 이벤트를 구독해 업적을 해금한다
// [주요 변수]      - _legendaryCardIds : 레전더리 등급 카드 ID 캐시(획득 판정용, Start 1회 구축)
// [의존 관계]      - InGameController(OnBattleResult/OnStageCleared/OnRunFinished/OnRewardPicked)
//                  - BattleController(OnInfiniteLoopDetected), ShopController(OnCardPurchased)
//                  - DataManager(CardDataSO 등급 조회), SteamAchievementManager
// [배치]           InGame 씬 루트에 배치 (구독 대상 컨트롤러들과 수명 일치)
// [주의]           구독 대상은 SceneSingleton이라 로드 순서가 보장되지 않는다.
//                  Start에서 구독하고, 인스턴스가 없는 소스는 조용히 건너뛴다.
// =================================================================
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// 인게임 컨트롤러들의 이벤트를 구독해 업적으로 라우팅.
/// Start에서 구독(모든 Awake 이후 인스턴스 준비 보장), OnDestroy에서 해제.
/// </summary>
public class SteamAchievementBridge : MonoBehaviour
{
    // 스테이지 인덱스(0-based). 스테이지 클리어 업적 판정용.
    private const int STAGE_1_INDEX = 0;
    private const int STAGE_2_INDEX = 1;

    // 조건형 업적 임계값.
    private const int MANA_THRESHOLD = 10;          // 마나 N 이상
    private const int PENDING_CAST_THRESHOLD = 8;   // 동시 시전대기 N개
    private const int PREDATE_TOTAL_THRESHOLD = 7;  // 한 카드가 삼킨 누적 장수

    // 화살표 방향 집합(비트 합).
    private const ECardDirection ALL_4_DIRECTIONS =
        ECardDirection.Up | ECardDirection.Down | ECardDirection.Left | ECardDirection.Right;

    private InGameController _inGame;
    private BattleController _battle;
    private ShopController _shop;

    // 레전더리 카드 ID 집합. 카드 획득 시 등급 조회 대신 O(1) 판정 → 이벤트 핸들러 GC 없음.
    private readonly HashSet<string> _legendaryCardIds = new HashSet<string>();

    // 분신(새끼) 카드 ID 집합. SpawnOffspringEffect 의 생성 대상 ID를 데이터에서 수집(Start 1회).
    private readonly HashSet<string> _offspringCardIds = new HashSet<string>();

    // EventManager 게임플레이 신호 구독 핸들(OnDestroy에서 일괄 Dispose).
    private readonly List<IDisposableEvent> _eventSubs = new List<IDisposableEvent>(16);

    // 이번 런에서 스킬을 사용했는지(스킬 미사용 클리어 판정용). Bridge는 런 단위 씬에 존재.
    private bool _skillUsedThisRun;

    private void Start()
    {
        CacheCardIdSets();

        if (InGameController.HasInstance)
        {
            _inGame = InGameController.Instance;
            _inGame.OnBattleResult += HandleBattleResult;
            _inGame.OnStageCleared += HandleStageCleared;
            _inGame.OnRunFinished += HandleRunFinished;
            _inGame.OnRewardPicked += HandleRewardPicked;
        }
        else
        {
            GameLogger.LogWarning(ELogCategory.System,
                "[AchievementBridge] InGameController 없음 — 업적 구독 생략 (InGame 씬 루트에 배치 필요)");
        }

        if (BattleController.HasInstance)
        {
            _battle = BattleController.Instance;
            _battle.OnInfiniteLoopDetected += HandleInfiniteLoop;
        }

        if (ShopController.HasInstance)
        {
            _shop = ShopController.Instance;
            _shop.OnCardPurchased += HandleCardPurchased;
        }

        SubscribeGameplaySignals();
        EvaluateExistingShardArrows();
    }

    // EventManager(전역 PubSub)로 올라오는 게임플레이 신호 구독 → 조건 판정 후 업적 해금.
    private void SubscribeGameplaySignals()
    {
        if (!EventManager.HasInstance)
        {
            GameLogger.LogWarning(ELogCategory.System,
                "[AchievementBridge] EventManager 없음 — 게임플레이 신호 업적 구독 생략");
            return;
        }

        var events = EventManager.Instance;
        _eventSubs.Add(events.Subscribe<ManaChangedSignal>(HandleManaChanged));
        _eventSubs.Add(events.Subscribe<GlassBladeDamageZeroSignal>(HandleGlassBladeZero));
        _eventSubs.Add(events.Subscribe<EnemyDefeatedSignal>(HandleEnemyDefeated));
        _eventSubs.Add(events.Subscribe<CastingResolvedSignal>(HandleCastingResolved));
        _eventSubs.Add(events.Subscribe<PendingCastingCountSignal>(HandlePendingCastingCount));
        _eventSubs.Add(events.Subscribe<ArrowAddedSignal>(HandleArrowAdded));
        _eventSubs.Add(events.Subscribe<ShardArrowSignal>(HandleShardArrow));
        _eventSubs.Add(events.Subscribe<PredationSignal>(HandlePredation));
        _eventSubs.Add(events.Subscribe<GridCutBlockedSignal>(HandleGridCutBlocked));
        _eventSubs.Add(events.Subscribe<DisturbancePreservedSignal>(HandleDisturbancePreserved));
        _eventSubs.Add(events.Subscribe<SkillUsedSignal>(HandleSkillUsed));
        _eventSubs.Add(events.Subscribe<GridFilledSignal>(HandleGridFilled));
    }

    /// <summary>
    /// 저장 복원 신호가 Bridge.Start보다 먼저 발생했거나 이미 4방향인 카드를 보유한 경우를 보완한다.
    /// 이후 방향 변경은 ShardArrowSignal 구독으로 실시간 판정한다.
    /// </summary>
    private void EvaluateExistingShardArrows()
    {
        RunContext run = _inGame != null ? _inGame.CurrentRun : null;
        if (run == null) return;

        IReadOnlyList<RunDeckEntry> entries = run.DeckEntries;
        for (int i = 0; i < entries.Count; i++)
        {
            RunDeckEntry entry = entries[i];
            if (entry == null || !entry.HasArrowDirection) continue;

            EChainPatternType patternType;
            if (entry.RuntimeData != null)
            {
                patternType = entry.RuntimeData.PatternType;
            }
            else
            {
                CardDataSO data = DataManager.HasInstance
                    ? DataManager.Instance.GetData<CardDataSO>(entry.CardId)
                    : null;
                if (data == null) continue;
                patternType = data.PatternType;
            }

            if (patternType == EChainPatternType.ShotgunForward2)
                HandleShardArrow(new ShardArrowSignal(entry.ArrowDirection));
        }
    }

    private void OnDestroy()
    {
        if (_inGame != null)
        {
            _inGame.OnBattleResult -= HandleBattleResult;
            _inGame.OnStageCleared -= HandleStageCleared;
            _inGame.OnRunFinished -= HandleRunFinished;
            _inGame.OnRewardPicked -= HandleRewardPicked;
            _inGame = null;
        }

        if (_battle != null)
        {
            _battle.OnInfiniteLoopDetected -= HandleInfiniteLoop;
            _battle = null;
        }

        if (_shop != null)
        {
            _shop.OnCardPurchased -= HandleCardPurchased;
            _shop = null;
        }

        // EventManager 신호 구독 일괄 해제.
        for (int i = 0; i < _eventSubs.Count; i++)
            _eventSubs[i]?.Dispose();
        _eventSubs.Clear();
    }

    /// <summary>
    /// 판정용 카드 ID 집합을 데이터에서 1회 구축한다(Start 전용).
    /// - 레전더리: 카드 SO는 에셋 이름으로 등록되어 CardId 키 조회를 신뢰할 수 없으므로 전수 수집.
    /// - 분신(새끼): 새끼카드 자신에는 표식이 없고 "낳는 쪽"인 SpawnOffspringEffect 가
    ///   생성 대상 cardId 를 데이터로 들고 있으므로, 효과를 훑어 역으로 수집한다(하드코딩 없음).
    /// GetAllData 는 호출마다 List 를 새로 할당하므로 한 번만 받아 두 집합을 동시에 채운다.
    /// </summary>
    private void CacheCardIdSets()
    {
        if (!DataManager.HasInstance) return;

        List<CardDataSO> cards = DataManager.Instance.GetAllData<CardDataSO>();
        for (int i = 0; i < cards.Count; i++)
        {
            CardDataSO card = cards[i];
            if (card == null) continue;

            if (card.Rarity == ECardRarity.Legendary)
                _legendaryCardIds.Add(card.CardId);

            CollectSpawnIds(card.GetEffects(upgraded: false));
            CollectSpawnIds(card.GetEffects(upgraded: true));
        }
    }

    private void CollectSpawnIds(IReadOnlyList<CardEffectBase> effects)
    {
        if (effects == null) return;

        for (int i = 0; i < effects.Count; i++)
        {
            if (effects[i] is SpawnOffspringEffect spawn &&
                !string.IsNullOrEmpty(spawn.SpawnCardId))
            {
                _offspringCardIds.Add(spawn.SpawnCardId);
            }
        }
    }

    // 전투 결과 → 첫 승리 업적 (Unlock이 중복 해금을 자체 차단하므로 매 승리 호출해도 무해).
    private void HandleBattleResult(bool victory)
    {
        if (!victory) return;
        if (!SteamAchievementManager.HasInstance) return;

        SteamAchievementManager.Instance.Unlock(EAchievement.FirstWin);
    }

    // 스테이지 보스 격파 → 해당 스테이지 클리어 업적.
    private void HandleStageCleared(int clearedStageIndex)
    {
        if (!SteamAchievementManager.HasInstance) return;

        // 스테이지 3 클리어는 곧 게임 클리어이므로 OnRunFinished(victory)에서 처리한다.
        if (clearedStageIndex == STAGE_1_INDEX)
            SteamAchievementManager.Instance.Unlock(EAchievement.ClearStage1);
        else if (clearedStageIndex == STAGE_2_INDEX)
            SteamAchievementManager.Instance.Unlock(EAchievement.ClearStage2);
    }

    // 런 종료 → 게임 클리어 업적 + 스킬 미사용 클리어 업적.
    private void HandleRunFinished(bool victory, int reachedFloor)
    {
        if (!SteamAchievementManager.HasInstance) return;
        var achievements = SteamAchievementManager.Instance;

        if (victory)
        {
            achievements.Unlock(EAchievement.GameClear);

            if (_inGame != null && _inGame.CurrentDifficulty == ERunDifficulty.Hell)
                achievements.Unlock(EAchievement.HellClear);

            // 이번 런에서 스킬을 한 번도 쓰지 않고 클리어했으면 해금.
            if (!_skillUsedThisRun)
                achievements.Unlock(EAchievement.NoSkillClear);
        }
    }

    // 전리품 카드 획득 → 레전더리 업적.
    private void HandleRewardPicked(string acquiredCardId) => TryUnlockLegendary(acquiredCardId);

    // 상점 카드 구매 → 레전더리 업적.
    private void HandleCardPurchased(string cardId, int paidGold) => TryUnlockLegendary(cardId);

    private void TryUnlockLegendary(string cardId)
    {
        if (string.IsNullOrEmpty(cardId)) return;
        if (!_legendaryCardIds.Contains(cardId)) return;
        if (!SteamAchievementManager.HasInstance) return;

        SteamAchievementManager.Instance.Unlock(EAchievement.GetLegendary);
    }

    // 무한루프 감지(체인 안전 한도 도달) → 무한동력 업적.
    private void HandleInfiniteLoop(Card rootCard, Vector2Int position)
    {
        if (!SteamAchievementManager.HasInstance) return;

        SteamAchievementManager.Instance.Unlock(EAchievement.InfiniteLoop);
    }

    // ─────────────────────────────────────────────
    // EventManager 게임플레이 신호 → 업적 판정
    // ─────────────────────────────────────────────

    // 마나(Energy) 10 이상 도달.
    private void HandleManaChanged(ManaChangedSignal signal)
    {
        if (signal.Current < MANA_THRESHOLD) return;
        Unlock(EAchievement.ManaOver10);
    }

    // 유리칼 데미지 0 도달.
    private void HandleGlassBladeZero(GlassBladeDamageZeroSignal signal)
        => Unlock(EAchievement.GlassBladeZero);

    // 적 사망 스냅샷 → 전 카드 활성.
    private void HandleEnemyDefeated(EnemyDefeatedSignal signal)
    {
        if (signal.AllGridCardsActive)
            Unlock(EAchievement.AllCardsActiveOnKill);
    }

    // 캐스팅 카운트 소진 발동.
    private void HandleCastingResolved(CastingResolvedSignal signal)
        => Unlock(EAchievement.CastingResolved);

    // 동시 시전대기 캐스팅 8개.
    private void HandlePendingCastingCount(PendingCastingCountSignal signal)
    {
        if (signal.Count < PENDING_CAST_THRESHOLD) return;
        Unlock(EAchievement.EightPendingCasts);
    }

    // 화살표 추가 문맥 → 분신(새끼) 카드 화살표 / 보스 실명 중 화살표.
    private void HandleArrowAdded(ArrowAddedSignal signal)
    {
        // 새끼카드 자신에는 표식이 없으므로, 데이터에서 수집한 "생성 대상 ID" 집합으로 판정.
        if (_offspringCardIds.Contains(signal.CardId))
            Unlock(EAchievement.OffspringArrow);

        // 실명(정보 은폐)은 보스 고유 의도이므로, 보스전 중 실명 상태에서 화살표를 추가하면 해금.
        // 스테이지 순서에 의존하지 않는다(스테이지 추가·재배치에도 수정 불필요).
        if (signal.InfoHidden && _battle != null && _battle.IsBossBattle)
            Unlock(EAchievement.ArrowWhileBlind);
    }

    // 파편화살에 4방위 전부 부여.
    private void HandleShardArrow(ShardArrowSignal signal)
    {
        if ((signal.Directions & ALL_4_DIRECTIONS) != ALL_4_DIRECTIONS) return;
        Unlock(EAchievement.ShardAllArrows);
    }

    // 포식 결과 → 한 카드로 누적 N장 포식.
    private void HandlePredation(PredationSignal signal)
    {
        // 같은 포식 카드가 지금까지 삼킨 누적 장수.
        if (signal.TotalDevouredCount >= PREDATE_TOTAL_THRESHOLD)
            Unlock(EAchievement.Predate7InOne);
    }

    // 보스의 그리드 자르기를 카드로 막음.
    private void HandleGridCutBlocked(GridCutBlockedSignal signal)
    {
        if (!signal.IsBossBattle) return;
        Unlock(EAchievement.BlockGridCut);
    }

    // 방해카드 보존.
    private void HandleDisturbancePreserved(DisturbancePreservedSignal signal)
        => Unlock(EAchievement.PreserveDisturbance);

    // 스킬 사용 → 런 플래그 set (NoSkillClear 실격).
    private void HandleSkillUsed(SkillUsedSignal signal)
        => _skillUsedThisRun = true;

    // 그리드 전 슬롯 채움.
    private void HandleGridFilled(GridFilledSignal signal)
        => Unlock(EAchievement.GridFull);

    // 업적 해금 공통 진입점(인스턴스 가드). 튜토리얼 제외는 Manager.Unlock 내부에서 처리.
    private static void Unlock(EAchievement achievement)
    {
        if (!SteamAchievementManager.HasInstance) return;
        SteamAchievementManager.Instance.Unlock(achievement);
    }
}
