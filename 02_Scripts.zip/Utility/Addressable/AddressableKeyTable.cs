﻿// =================================================================
// [스크립트 목적]  빌드된 addressableMap.json들을 런타임에 로드해 키→엔트리 테이블 구축
//                 ResourceManager가 키 검증·프리웜 목록 조회에 사용
// [의존 관계]      - Addressables (map json들에 "addressableMap" 라벨 부여 필요), UniTask
// [주의]           map json을 Addressables Data 그룹 등에 등록 + 라벨 부여해야 로드됨.
//                  미등록 시 테이블만 비고 직접 키 로드는 정상 동작 (graceful degradation)
// =================================================================
using System.Collections.Generic;
using System.Threading;
using Cysharp.Threading.Tasks;
using UnityEngine;
using UnityEngine.AddressableAssets;

public class AddressableKeyTable
{
    // 키 → 엔트리
    private readonly Dictionary<string, AddressableMapEntry> _table = new(256);
    // 그룹 → 키 목록
    private readonly Dictionary<EAddressableGroup, List<string>> _byGroup = new(8);

    public bool IsLoaded { get; private set; }
    public int Count => _table.Count;

    /// <summary>"addressableMap" 라벨이 붙은 모든 json을 로드해 테이블 구축.</summary>
    public async UniTask LoadAsync(string mapLabel = "addressableMap", CancellationToken token = default)
    {
        // 빈 라벨 방어: 라벨에 매칭되는 location이 없으면 LoadAssetsAsync가 예외를 던짐.
        // 먼저 location을 조회해 0개면 정상 종료(테이블만 빈 상태).
        var locHandle = Addressables.LoadResourceLocationsAsync(mapLabel, typeof(TextAsset));
        var locations = await locHandle.ToUniTask(cancellationToken: token);
        bool hasAny = locations != null && locations.Count > 0;
        Addressables.Release(locHandle);

        if (!hasAny)
        {
            IsLoaded = true; // 매핑 없음 = 직접 키 로드만 사용 (정상)
            return;
        }

        var handle = Addressables.LoadAssetsAsync<TextAsset>(mapLabel, null);
        var jsonAssets = await handle.ToUniTask(cancellationToken: token);

        foreach (var json in jsonAssets)
        {
            if (json == null) continue;
            var data = JsonUtility.FromJson<AddressableMapData>(json.text);
            if (data?.Entries == null) continue;

            foreach (var entry in data.Entries)
            {
                _table[entry.Key] = entry;

                if (!_byGroup.TryGetValue(entry.Group, out var list))
                {
                    list = new List<string>();
                    _byGroup[entry.Group] = list;
                }
                list.Add(entry.Key);
            }
        }

        // map json 자체는 더 안 쓰므로 핸들 해제
        Addressables.Release(handle);
        IsLoaded = true;
    }

    public bool TryGet(string key, out AddressableMapEntry entry) => _table.TryGetValue(key, out entry);
    public bool HasKey(string key) => _table.ContainsKey(key);

    public IReadOnlyList<string> GetKeys(EAddressableGroup group)
        => _byGroup.TryGetValue(group, out var list) ? list : System.Array.Empty<string>();

    /// <summary>프리웜 대상 키 목록 (그룹 필터 옵션).</summary>
    public List<string> GetPrewarmKeys(EAddressableGroup? group = null)
    {
        var result = new List<string>();
        foreach (var kv in _table)
        {
            if (!kv.Value.Prewarm) continue;
            if (group.HasValue && kv.Value.Group != group.Value) continue;
            result.Add(kv.Key);
        }
        return result;
    }

    public void Clear()
    {
        _table.Clear();
        _byGroup.Clear();
        IsLoaded = false;
    }
}