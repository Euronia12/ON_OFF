// =================================================================
// [스크립트 목적]  Addressable 키-경로 매핑 데이터. 폴더 스캔으로 빌드 타임 생성
//                 (기존 프로젝트 Classes.cs의 AddressableMapData/AddressableMap 개선판)
// [의존 관계]      - AddressableMapBuilder(에디터 생성), AddressableKeyTable(런타임 로드)
// [개선]           prewarm 플래그 추가 (기존 PrevPrefab/PrevSound enum 분기 대체)
// =================================================================
using System;
using System.Collections.Generic;
using UnityEngine;

[Serializable]
public class AddressableMapData
{
    public List<AddressableMapEntry> Entries = new();

    public void Add(AddressableMapEntry entry) => Entries.Add(entry);
    public void AddRange(List<AddressableMapEntry> entries) => Entries.AddRange(entries);
}

[Serializable]
public class AddressableMapEntry
{
    public EAddressableGroup Group;
    public EAssetKind Kind;
    public string Key;
    public string Path;

    [Tooltip("부팅 시 프리로드 대상 여부 (기존 PrevPrefab/PrevSound 대체)")]
    public bool Prewarm;
}
