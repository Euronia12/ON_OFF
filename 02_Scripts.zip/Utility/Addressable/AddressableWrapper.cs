// =================================================================
// [스크립트 목적]  Addressable 원격 경로/버전/플랫폼 추상화 (LiveOps 빌드 파이프라인)
//                 (기존 프로젝트 AddressableWrapper 개선판)
// [의존 관계]      - GameLogger
// [주의]           URL은 실제 서버로 교체. Addressables Profile 변수와 연동해 사용
// [개선]           test/prod URL 분리, Debug.Log → GameLogger(Release 자동 제거),
//                  매 호출 로그하던 version/target 로그 제거 (스팸 방지)
// =================================================================
using UnityEngine;

public static class AddressableWrapper
{
    /// <summary>true면 테스트 서버 사용</summary>
    public static bool IsTest { get; private set; }

    /// <summary>
    /// 빌드 환경에 맞춰 원격 Addressable 서버를 선택한다.
    /// Dev/Test는 테스트 서버, Live만 운영 서버를 사용한다.
    /// </summary>
    public static void ConfigureForBuildEnvironment(EBuildEnv buildEnv)
    {
        IsTest = buildEnv != EBuildEnv.Live;
    }

    // 출시 직전 실제 URL로 교체
    private const string PROD_URL = "https://your-cdn.example.com/Addressable";
    private const string TEST_URL = "https://your-cdn-test.example.com/Addressable";

    public static string RemotePath
    {
        get
        {
            string path = IsTest ? TEST_URL : PROD_URL;
            GameLogger.Log(ELogCategory.Resource, $"원격 경로: {path}");
            return path;
        }
    }

    public static string AppVersion => Application.version;

    public static string BuildTarget
    {
        get
        {
            return Application.platform switch
            {
                RuntimePlatform.Android => "Android",
                RuntimePlatform.IPhonePlayer => "iOS",
                _ => "StandaloneWindows"
            };
        }
    }
}
