// =================================================================
// [스크립트 목적]  로그 공통 컨텍스트(익명 ID·버전·시각) 제공 범용 유틸.
//                 session_id(=run_id) / device_id / app_version / client_ts 를 한곳에서 발급.
// [주요 변수]      - DeviceId  : 기기당 익명 GUID (PlayerPrefs 영구 보관, 개인 식별 아님)
//                  - SessionId : 현재 런 ID (= InGameController.CurrentRunId)
// [의존 관계]      - InGameController(런 ID), Application.version
// [설계 노트]      - device_id 는 리텐션 분석용. 기기 리셋·재설치 시 초기화됨(수용).
//                  - session_id 는 개인 계정과 연결하지 않는다(개인정보 이슈 회피).
// =================================================================
using System;
using UnityEngine;

public static class LoggingContext
{
    // PlayerPrefs 익명 기기 ID 키
    private const string DeviceIdKey = "onoff_device_id";

    // 런 미진행 등으로 session_id 가 없을 때의 대체값
    public const string NoSession = "no_run";

    private static string s_deviceId;

    /// <summary>기기당 익명 GUID. 최초 1회 생성 후 PlayerPrefs 에 영구 보관.</summary>
    public static string DeviceId
    {
        get
        {
            if (!string.IsNullOrEmpty(s_deviceId))
                return s_deviceId;

            s_deviceId = PlayerPrefs.GetString(DeviceIdKey, string.Empty);
            if (string.IsNullOrEmpty(s_deviceId))
            {
                s_deviceId = Guid.NewGuid().ToString("N");
                PlayerPrefs.SetString(DeviceIdKey, s_deviceId);
                PlayerPrefs.Save();
            }
            return s_deviceId;
        }
    }

    /// <summary>현재 런 ID. 런 진행 중이 아니면 NoSession.</summary>
    public static string SessionId
    {
        get
        {
            if (InGameController.HasInstance && !string.IsNullOrEmpty(InGameController.Instance.CurrentRunId))
                return InGameController.Instance.CurrentRunId;
            return NoSession;
        }
    }

    /// <summary>게임 빌드 버전 (ProjectSettings bundleVersion).</summary>
    public static string AppVersion => Application.version;

    /// <summary>클라이언트 발생 시각 (ISO8601, UTC). 예: 2026-07-08T05:22:01.334Z</summary>
    public static string ClientTsUtc() => DateTime.UtcNow.ToString("o");
}
