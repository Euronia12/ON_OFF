﻿// =================================================================
// [스크립트 목적]  분석 이벤트(dict)를 JSONL(JSON Lines) 파일로 영속화하는 범용 로컬 기록기
//                 한 줄 = 한 이벤트(LogEntry). append 방식이라 빈번 호출에도 부담 적음
//                 메모리 큐 버퍼링 → 묶음 append (I/O 횟수 최소화)
// [주요 변수]      - _queue          : 아직 파일에 안 쓴 라인 대기 큐
//                  - _isDirty        : 큐에 미저장 항목 존재 여부 (자동 저장 트리거)
//                  - _currentDate    : 현재 파일 날짜 (변경 시 새 파일)
//                  - _useDataPath    : true면 설치폴더, false면 persistentDataPath
// [의존 관계]      - IAnalyticsProvider, GameLogger, UniTask
//                  - AnalyticsManager가 생성·등록·종료 관리
// [저장 위치]      - {루트}/Logs/{파일명}_{yyyy-MM-dd}.jsonl
// [포맷]           - JSONL: 각 줄이 독립 JSON(LogEntry{timestamp,eventName,parameters})
// =================================================================
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading;
using Cysharp.Threading.Tasks;
using UnityEngine;

/// <summary>
/// 단일 로그 엔트리. JSONL 한 줄로 직렬화. [Serializable] 필수.
/// 파라미터는 JsonUtility가 Dictionary/object를 못 다루므로 평탄화 문자열로 보관.
/// </summary>
[Serializable]
public class LogEntry
{
    public string timestamp;   // 기록 시각 (yyyy-MM-dd HH:mm:ss.fff)
    public string eventName;   // 이벤트 이름
    public string parameters;  // 평탄화된 파라미터 (key=value; key2=value2)
}

/// <summary>
/// 분석 이벤트를 JSONL 파일로 누적 저장하는 Provider.
/// LogEvent 호출 시 미리 직렬화한 한 줄을 큐에 쌓고 DirtyFlag만 세움(I/O 없음).
/// 실제 파일 append는 즉시 저장(Flush) 또는 자동 저장 루프에서 묶음 처리.
/// </summary>
public class JsonLogProvider : IAnalyticsProvider
{
    // 미저장 대기 큐 (직렬화된 JSONL 한 줄 문자열). 파일에 append 후 비움
    private readonly List<string> _queue = new(64);

    // 파라미터 평탄화 / 라인 빌드용 StringBuilder 재사용 (GC 절감)
    private readonly StringBuilder _paramSb = new(128);
    private readonly StringBuilder _lineSb = new(512);

    private readonly string _fileName;         // 파일명 접두사 (확장자·날짜 제외)
    private readonly bool _useDataPath;         // true면 설치폴더, false면 persistentDataPath
    private readonly object _queueLock = new(); // 큐 동시 접근 보호

    private string _logDir;                    // 로그 디렉토리 (루트/Logs)
    private string _currentDate;               // 현재 파일 날짜 (yyyy-MM-dd)
    private string _currentFilePath;           // 현재 날짜 파일 전체 경로
    private bool _isDirty;

    // 자동 저장 루프 제어
    private CancellationTokenSource _autoSaveCts;
    private float _autoSaveInterval;

    /// <summary>미저장 항목 존재 여부.</summary>
    public bool IsDirty => _isDirty;

    /// <summary>현재 큐에 대기 중인(미저장) 로그 개수.</summary>
    public int PendingCount
    {
        get { lock (_queueLock) return _queue.Count; }
    }

    /// <summary>현재 날짜 파일 전체 경로.</summary>
    public string CurrentFilePath => _currentFilePath;

    /// <summary>로그 디렉토리 경로.</summary>
    public string LogDirectory => _logDir;

    /// <param name="fileName">파일명 접두사 (확장자·날짜 제외)</param>
    /// <param name="useDataPath">true면 설치폴더(dataPath), false면 persistentDataPath</param>
    public JsonLogProvider(string fileName = "user_log", bool useDataPath = false)
    {
        _fileName = fileName;
        _useDataPath = useDataPath;
    }

    // ─────────────────────────────────────────────
    // IAnalyticsProvider 구현
    // ─────────────────────────────────────────────

    public void Initialize()
    {
        // 저장 루트 결정
        // [주의] dataPath(설치폴더)는 플랫폼에 따라 읽기 전용일 수 있음(아래 경고 참고)
        string root = _useDataPath
            ? Application.dataPath
            : Application.persistentDataPath;

        _logDir = Path.Combine(root, "Logs");

        try
        {
            if (!Directory.Exists(_logDir))
                Directory.CreateDirectory(_logDir);
        }
        catch (Exception e)
        {
            // 설치폴더가 읽기 전용이면 여기서 실패 → persistentDataPath로 폴백
            GameLogger.LogWarning(ELogCategory.Analytics,
                $"로그 디렉토리 생성 실패({_logDir}): {e.Message} → persistentDataPath로 폴백");
            _logDir = Path.Combine(Application.persistentDataPath, "Logs");
            if (!Directory.Exists(_logDir))
                Directory.CreateDirectory(_logDir);
        }

        UpdateCurrentFile();
        GameLogger.Log(ELogCategory.Analytics,
            $"JsonLogProvider 초기화. 경로: {_currentFilePath}");
    }

    /// <summary>
    /// 이벤트 1건 기록. 파일 I/O 없이 LogEntry를 직렬화한 한 줄을 큐에 추가 + DirtyFlag.
    /// 계약상 parameters는 이 호출 동안만 유효하므로 즉시 평탄화한다.
    /// </summary>
    public void LogEvent(string eventName, IReadOnlyDictionary<string, object> parameters)
    {
        var entry = new LogEntry
        {
            timestamp = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff"),
            eventName = eventName,
            parameters = FlattenParameters(parameters)
        };
        Enqueue(JsonUtility.ToJson(entry));
    }

    /// <summary>유저 속성도 동일하게 이벤트로 기록.</summary>
    public void SetUserProperty(string key, string value)
    {
        var entry = new LogEntry
        {
            timestamp = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff"),
            eventName = "user_property",
            parameters = $"{key}={value}"
        };
        Enqueue(JsonUtility.ToJson(entry));
    }

    private void Enqueue(string line)
    {
        lock (_queueLock)
        {
            _queue.Add(line);
            _isDirty = true;
        }
    }

    // ─────────────────────────────────────────────
    // 즉시 저장 (묶음 append)
    // ─────────────────────────────────────────────

    /// <summary>
    /// 비동기 즉시 저장. 큐에 쌓인 항목을 한 번에 파일 끝에 append.
    /// 날짜가 바뀌었으면 새 파일로 자동 전환.
    /// </summary>
    public async UniTask FlushAsync(CancellationToken token = default)
    {
        if (!_isDirty) return;

        // 날짜 변경 검사 (자정 넘어가면 새 파일)
        UpdateCurrentFile();

        // 큐를 스냅샷으로 복사 후 비움 (LogEvent 동시 호출 안전)
        List<string> envSnapshot;
        lock (_queueLock)
        {
            if (_queue.Count == 0) { _isDirty = false; return; }
            envSnapshot = new List<string>(_queue);
            _queue.Clear();
            _isDirty = false;
        }

        string lines = BuildLines(envSnapshot);

        try
        {
            // append: 기존 파일 끝에 이어쓰기 (전체 재직렬화 없음)
            await File.AppendAllTextAsync(_currentFilePath, lines, token);
            GameLogger.Log(ELogCategory.Analytics,
                $"로그 {envSnapshot.Count}건 append → {_currentFilePath}");
        }
        catch (OperationCanceledException)
        {
            // 취소 시 스냅샷을 큐로 되돌림 (유실 방지)
            RestoreToQueue(envSnapshot);
            throw;
        }
        catch (Exception e)
        {
            RestoreToQueue(envSnapshot);
            GameLogger.LogError(ELogCategory.Analytics, $"로그 저장 실패: {e.Message}");
        }
    }

    /// <summary>동기 즉시 저장. 앱 종료 직전 등 await 불가 상황용.</summary>
    public void FlushSync()
    {
        if (!_isDirty) return;

        UpdateCurrentFile();

        List<string> envSnapshot;
        lock (_queueLock)
        {
            if (_queue.Count == 0) { _isDirty = false; return; }
            envSnapshot = new List<string>(_queue);
            _queue.Clear();
            _isDirty = false;
        }

        try
        {
            File.AppendAllText(_currentFilePath, BuildLines(envSnapshot));
        }
        catch (Exception e)
        {
            RestoreToQueue(envSnapshot);
            GameLogger.LogError(ELogCategory.Analytics, $"로그 동기 저장 실패: {e.Message}");
        }
    }

    // ─────────────────────────────────────────────
    // 자동 저장 (DirtyFlag + 타이머)
    // ─────────────────────────────────────────────

    /// <summary>
    /// 자동 저장 루프 시작. interval초마다 Dirty 검사 후 변경점 있으면 묶음 append.
    /// 중복 호출 시 기존 루프 정리 후 재시작.
    /// </summary>
    public void StartAutoSave(float interval = 60f)
    {
        StopAutoSave();
        _autoSaveInterval = Mathf.Max(1f, interval);
        _autoSaveCts = new CancellationTokenSource();
        AutoSaveLoopAsync(_autoSaveCts.Token).Forget();
    }

    /// <summary>자동 저장 루프 중단.</summary>
    public void StopAutoSave()
    {
        _autoSaveCts?.Cancel();
        _autoSaveCts?.Dispose();
        _autoSaveCts = null;
    }

    private async UniTaskVoid AutoSaveLoopAsync(CancellationToken token)
    {
        try
        {
            while (!token.IsCancellationRequested)
            {
                await UniTask.Delay(
                    TimeSpan.FromSeconds(_autoSaveInterval),
                    DelayType.UnscaledDeltaTime,  // 일시정지(timeScale=0) 무관하게 동작
                    PlayerLoopTiming.Update,
                    token);

                if (_isDirty)
                    await FlushAsync(token);
            }
        }
        catch (OperationCanceledException)
        {
            // 정상 종료 경로
        }
    }

    // ─────────────────────────────────────────────
    // 조회 / 유틸
    // ─────────────────────────────────────────────

    /// <summary>
    /// 특정 날짜 파일의 원시 JSONL 라인 목록 반환 (게임 내 로그 뷰어 등).
    /// date 미지정 시 오늘 파일. 파일 없으면 빈 리스트. 각 줄이 LogEntry JSON.
    /// </summary>
    public List<string> ReadLines(DateTime? date = null)
    {
        var result = new List<string>();
        string path = GetFilePathForDate(date ?? DateTime.Now);

        if (!File.Exists(path)) return result;

        try
        {
            foreach (var line in File.ReadLines(path))
            {
                if (string.IsNullOrWhiteSpace(line)) continue;
                result.Add(line);
            }
        }
        catch (Exception e)
        {
            GameLogger.LogWarning(ELogCategory.Analytics, $"로그 읽기 실패: {e.Message}");
        }
        return result;
    }

    /// <summary>현재 날짜 파일 삭제.</summary>
    public void DeleteCurrentFile()
    {
        try
        {
            if (File.Exists(_currentFilePath))
                File.Delete(_currentFilePath);
        }
        catch (Exception e)
        {
            GameLogger.LogWarning(ELogCategory.Analytics, $"로그 파일 삭제 실패: {e.Message}");
        }
    }

    // ─────────────────────────────────────────────
    // 내부 헬퍼
    // ─────────────────────────────────────────────

    /// <summary>오늘 날짜로 현재 파일 경로 갱신. 날짜 바뀌면 새 파일 가리킴.</summary>
    private void UpdateCurrentFile()
    {
        string today = DateTime.Now.ToString("yyyy-MM-dd");
        if (today == _currentDate && _currentFilePath != null) return;

        _currentDate = today;
        _currentFilePath = GetFilePathForDate(DateTime.Now);
    }

    private string GetFilePathForDate(DateTime date)
    {
        string dateStr = date.ToString("yyyy-MM-dd");
        return Path.Combine(_logDir, $"{_fileName}_{dateStr}.jsonl");
    }

    /// <summary>Envelope 라인 목록을 JSONL 문자열로 변환 (각 줄 = JSON + 개행).</summary>
    private string BuildLines(List<string> envLines)
    {
        _lineSb.Clear();
        // Envelope 는 이미 직렬화된 JSONL 한 줄 문자열
        for (int i = 0; i < envLines.Count; i++)
        {
            _lineSb.Append(envLines[i]);
            _lineSb.Append('\n');
        }
        return _lineSb.ToString();
    }

    /// <summary>저장 실패·취소 시 스냅샷을 큐 앞쪽에 되돌림 (유실 방지).</summary>
    private void RestoreToQueue(List<string> envSnapshot)
    {
        lock (_queueLock)
        {
            _queue.InsertRange(0, envSnapshot);
            _isDirty = true;
        }
    }

    /// <summary>파라미터 딕셔너리를 "key=value; key2=value2" 문자열로 평탄화.</summary>
    private string FlattenParameters(IReadOnlyDictionary<string, object> parameters)
    {
        if (parameters == null || parameters.Count == 0)
            return string.Empty;

        _paramSb.Clear();
        bool first = true;
        foreach (var kv in parameters)
        {
            if (!first) _paramSb.Append("; ");
            _paramSb.Append(kv.Key).Append('=').Append(kv.Value);
            first = false;
        }
        return _paramSb.ToString();
    }
}