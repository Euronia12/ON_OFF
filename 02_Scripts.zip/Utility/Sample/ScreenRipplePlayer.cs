using System;
using System.Threading;
using Cysharp.Threading.Tasks;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.Rendering.Universal;
using UnityEngine.UI;

public sealed class ScreenRipplePlayer : MonoBehaviour, IPointerClickHandler
{
    private static readonly int RippleCenterId = Shader.PropertyToID("_RippleCenter");
    private static readonly int RippleStartTimeId = Shader.PropertyToID("_RippleStartTime");
    private static readonly int WaveCountId = Shader.PropertyToID("_WaveCount");
    private static readonly int WaveIntervalId = Shader.PropertyToID("_WaveInterval");
    private static readonly int WaveDurationId = Shader.PropertyToID("_WaveDuration");
    private static readonly int MaxRadiusId = Shader.PropertyToID("_MaxRadius");
    private static readonly int StrengthId = Shader.PropertyToID("_Strength");
    private static readonly int ThicknessId = Shader.PropertyToID("_Thickness");

    [Header("화면 충격파")]
    [Tooltip("Full Screen Pass에서 사용하는 화면 왜곡 머티리얼")]
    [SerializeField] private Material _rippleMaterial;

    [Tooltip("재생 중에만 활성화할 PC Renderer의 Full Screen Pass")]
    [SerializeField] private ScriptableRendererFeature _rendererFeature;

    [Tooltip("한 번 재생할 때 발생하는 충격파 수")]
    [SerializeField, Range(2, 3)] private int _waveCount = 3;

    [Tooltip("충격파 사이의 발생 간격(초)")]
    [SerializeField, Min(0.01f)] private float _waveInterval = 0.18f;

    [Tooltip("각 충격파가 최대 반경까지 퍼지는 시간(초)")]
    [SerializeField, Min(0.01f)] private float _waveDuration = 0.75f;

    [Tooltip("화면 높이를 1로 봤을 때 충격파의 최대 반경")]
    [SerializeField, Min(0.01f)] private float _maxRadius = 0.8f;

    [Tooltip("화면 UV를 밀어내는 왜곡 강도")]
    [SerializeField, Range(0f, 0.1f)] private float _strength = 0.02f;

    [Tooltip("충격파 띠의 두께")]
    [SerializeField, Range(0.001f, 0.2f)] private float _thickness = 0.045f;

    private Button _button;
    private CancellationTokenSource _playCts;

    private void Awake()
    {
        TryGetComponent(out _button);
    }

    private void OnEnable()
    {
        Stop();
    }

    public void OnPointerClick(PointerEventData eventData)
    {
        if (eventData.button != PointerEventData.InputButton.Left ||
            _button == null ||
            !_button.IsInteractable())
        {
            return;
        }

        float width = Mathf.Max(1f, Screen.width);
        float height = Mathf.Max(1f, Screen.height);
        Vector2 center = new Vector2(
            Mathf.Clamp01(eventData.position.x / width),
            Mathf.Clamp01(eventData.position.y / height));

        PlayAtViewportPositionAsync(
            center,
            1f,
            this.GetCancellationTokenOnDestroy()).Forget();
    }

    public async UniTask PlayAtViewportPositionAsync(
        Vector2 center,
        float speedMultiplier,
        CancellationToken token)
    {
        if (_rippleMaterial == null || _rendererFeature == null)
        {
            Debug.LogWarning("ScreenRipplePlayer의 Ripple Material과 Renderer Feature 참조가 필요합니다.", this);
            return;
        }

        Stop();

        CancellationTokenSource playCts = token.CanBeCanceled
            ? CancellationTokenSource.CreateLinkedTokenSource(token)
            : new CancellationTokenSource();
        _playCts = playCts;

        float playbackSpeed = Mathf.Max(0.01f, speedMultiplier);
        float waveInterval = Mathf.Max(0.01f, _waveInterval) / playbackSpeed;
        float waveDuration = Mathf.Max(0.01f, _waveDuration) / playbackSpeed;
        int waveCount = Mathf.Clamp(_waveCount, 2, 3);

        _rippleMaterial.SetVector(
            RippleCenterId,
            new Vector4(Mathf.Clamp01(center.x), Mathf.Clamp01(center.y), 0f, 0f));
        _rippleMaterial.SetFloat(WaveCountId, waveCount);
        _rippleMaterial.SetFloat(WaveIntervalId, waveInterval);
        _rippleMaterial.SetFloat(WaveDurationId, waveDuration);
        _rippleMaterial.SetFloat(MaxRadiusId, Mathf.Max(0.01f, _maxRadius));
        _rippleMaterial.SetFloat(StrengthId, Mathf.Clamp(_strength, 0f, 0.1f));
        _rippleMaterial.SetFloat(ThicknessId, Mathf.Clamp(_thickness, 0.001f, 0.2f));
        _rippleMaterial.SetFloat(RippleStartTimeId, Time.time);

        _rendererFeature.SetActive(true);

        try
        {
            float totalDuration = waveDuration + (waveCount - 1) * waveInterval;
            await UniTask.Delay(
                TimeSpan.FromSeconds(totalDuration),
                cancellationToken: playCts.Token);
        }
        catch (OperationCanceledException)
        {
            // 새 재생·전투 종료·씬 이탈에 의한 취소는 정상 흐름이다.
        }
        finally
        {
            if (_playCts == playCts)
            {
                _playCts = null;
                ResetRipple();
                DisableRendererFeature();
            }

            playCts.Dispose();
        }
    }

    private void OnDisable()
    {
        Stop();
    }

    public void Stop()
    {
        CancellationTokenSource playCts = _playCts;
        _playCts = null;
        playCts?.Cancel();
        ResetRipple();
        DisableRendererFeature();
    }

    private void ResetRipple()
    {
        if (_rippleMaterial != null)
            _rippleMaterial.SetFloat(RippleStartTimeId, -1000f);
    }

    private void DisableRendererFeature()
    {
        if (_rendererFeature != null)
            _rendererFeature.SetActive(false);
    }
}
