using System.Collections;
using UnityEngine;
using UnityEngine.UI;

[RequireComponent(typeof(Button))]
public sealed class RedPaperCutDemoButton : MonoBehaviour
{
    [SerializeField] private RedPaperSeparationCutter _cutter;
    [SerializeField, Min(0.01f)] private float _duration = 2f;

    private Button _button;
    private Coroutine _playRoutine;

    private void Awake()
    {
        _button = GetComponent<Button>();
        _button.onClick.AddListener(Play);
    }

    public void Play()
    {
        if (_cutter == null)
        {
            Debug.LogError("RedPaperCutDemoButton의 Cutter 참조가 필요합니다.", this);
            return;
        }

        if (_playRoutine != null)
            StopCoroutine(_playRoutine);

        _cutter.SetCutProgress(0f);
        _playRoutine = StartCoroutine(PlayCut());
    }

    private IEnumerator PlayCut()
    {
        float elapsed = 0f;
        float duration = Mathf.Max(0.01f, _duration);

        while (elapsed < duration)
        {
            elapsed += Time.unscaledDeltaTime;
            _cutter.SetCutProgress(elapsed / duration);
            yield return null;
        }

        _cutter.SetCutProgress(1f);
        _playRoutine = null;
    }

    private void OnDestroy()
    {
        if (_button != null)
            _button.onClick.RemoveListener(Play);
    }
}
