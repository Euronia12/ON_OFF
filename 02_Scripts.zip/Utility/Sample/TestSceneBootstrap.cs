﻿// =================================================================
// [스크립트 목적]  테스트 씬 단독 실행용 진입 컨트롤러.
//                 Title을 거치지 않고 특정 씬에서 바로 Play해도 매니저가 준비되도록.
// [원리]           BootstrapInitializer는 어느 씬에서 Play하든 자동 실행됨
//                 (RuntimeInitializeOnLoadMethod). 이 컨트롤러는 그 완료를 기다린 뒤
//                 테스트에 필요한 것만 선택적으로 준비함.
// [배치]           테스트 씬에 빈 GameObject 만들고 이 컴포넌트 부착 → 그 씬에서 Play
// [주의]           ISceneLifecycle 구현 — 이 테스트 씬으로 전환해 들어와도 동작
// =================================================================
using System;
using System.Threading;
using Cysharp.Threading.Tasks;
using UnityEngine;
using UnityEngine.Events;

public class TestSceneBootstrap : MonoBehaviour, ISceneLifecycle
{
    [Header("준비 작업 (Inspector 토글)")]
    [Tooltip("게임 데이터(SO) 프리로드")]
    [SerializeField] private bool _preloadData = true;

    [Tooltip("키 테이블 기반 일반 에셋 프리로드 (Preload 폴더)")]
    [SerializeField] private bool _preloadAssets = false;

    [Tooltip("키 테이블 기반 풀 프리웜")]
    [SerializeField] private bool _prewarmPools = false;

    [Tooltip("로컬라이제이션 로드 (대부분 테스트엔 불필요)")]
    [SerializeField] private bool _loadLocalization = false;

    [Header("시작 상태")]
    [Tooltip("준비 완료 후 설정할 게임 상태")]
    [SerializeField] private EGameState _startState = EGameState.InGame;

    [Tooltip("준비 완료 후 BGM 재생 (키, 비우면 안 함)")]
    [SerializeField] private string _bgmKey = "";

    [Header("테스트 환경 세팅")]
    [Tooltip("준비 완료 후 호출됨. 여기에 테스트할 것 연결 (적 스폰, UI 열기 등)\n" +
             "Inspector에서 메서드 연결하거나, 코드에서 OnTestReady 구독")]
    [SerializeField] private UnityEvent _onReady;

    /// <summary>준비 완료 후 코드에서 구독할 이벤트 (UnityEvent 대신 코드 연결 시).</summary>
    public event Action OnTestReady;

    private CancellationTokenSource _cts;
    private bool _enteredViaTransition;

    private void Awake()
    {
        _cts = new CancellationTokenSource();
        if (SceneFlowManager.HasInstance)
            SceneFlowManager.Instance.RegisterLifecycle(this);
    }

    private void Start()
    {
        // 씬 전환으로 들어온 게 아니라 직접 Play한 경우만 자체 초기화
        if (!_enteredViaTransition)
            DirectStartAsync().Forget();
    }

    private async UniTaskVoid DirectStartAsync()
    {
        // Bootstrap은 어느 씬에서 Play하든 자동 생성됨 → 완료만 대기
        await BootstrapInitializer.WaitForReadyAsync();
        await PrepareAsync(_cts.Token);
        FireReady();
    }

    // ─────────────────────────────────────────────
    // 공통 준비 로직
    // ─────────────────────────────────────────────

    private async UniTask PrepareAsync(CancellationToken token)
    {
        if (_preloadData && DataManager.HasInstance && !DataManager.Instance.IsLoaded)
            await DataManager.Instance.PreloadAllAsync(null, token);

        if (_preloadAssets && ResourceManager.HasInstance)
            await ResourceManager.Instance.PreloadFromTableAsync(token: token);

        if (_prewarmPools && PoolManager.HasInstance)
            await PoolManager.Instance.PrewarmFromTableAsync(token: token);

        if (_loadLocalization && LocalizationManager.HasInstance)
        {
            // LocalizationManager는 초기화 시 자동 로드되므로 보통 추가 작업 불필요.
            // 필요 시 여기서 SetLanguage 등 호출.
        }

        if (GameFlowManager.HasInstance)
            GameFlowManager.Instance.SetState(_startState);

        if (!string.IsNullOrEmpty(_bgmKey) && AudioManager.HasInstance)
            AudioManager.Instance.PlayBgmAsync(_bgmKey).Forget();
    }

    private void FireReady()
    {
        GameLogger.Log(ELogCategory.System, $"[TestScene] 준비 완료 → {_startState}");
        _onReady?.Invoke();
        OnTestReady?.Invoke();
    }

    // ─────────────────────────────────────────────
    // ISceneLifecycle (다른 씬에서 이 테스트 씬으로 전환해 들어온 경우)
    // ─────────────────────────────────────────────

    public async UniTask OnSceneEnter(CancellationToken token)
    {
        _enteredViaTransition = true;
        await PrepareAsync(token);
    }

    public void OnSceneReady() => FireReady();

    public async UniTask OnSceneExit(CancellationToken token)
    {
        if (UIManager.HasInstance)
            UIManager.Instance.CloseAll();
        await UniTask.CompletedTask;
    }

    private void OnDestroy()
    {
        _cts?.Cancel();
        _cts?.Dispose();
        if (SceneFlowManager.HasInstance)
            SceneFlowManager.Instance.UnregisterLifecycle(this);
    }
}