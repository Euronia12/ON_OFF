﻿// =================================================================
// [스크립트 목적]  Addressables 기반 IResourceLoader 구현
//                 RefCount 생명주기 + 동시 로드 중복 방지 + 로딩 중 Unload 예약
// [주요 변수]      - _typedCaches : 타입별 캐시 (Type → TypedCache<T>)
// [의존 관계]      - Addressables 패키지, UniTask
//                  - ResourceManager가 내부 보유
// [핵심 패턴]      RefCount / PendingUnloads / UniTaskCompletionSource 멀티 어웨이터 공유
// =================================================================
using System;
using System.Collections;
using System.Collections.Generic;
using System.Threading;
using Cysharp.Threading.Tasks;
using UnityEngine;
using UnityEngine.AddressableAssets;
using UnityEngine.ResourceManagement.AsyncOperations;

public class AddressableLoader : IResourceLoader
{
    public bool SupportsSyncLoad => false;

    // ─────────────────────────────────────────────
    // 내부 자료구조
    // ─────────────────────────────────────────────

    private interface IReleasable
    {
        void ReleaseAll();
    }

    private class HandleWrapper<T> where T : UnityEngine.Object
    {
        public readonly AsyncOperationHandle<T> Handle;
        public int RefCount;

        public HandleWrapper(AsyncOperationHandle<T> handle)
        {
            Handle = handle;
            RefCount = 1;
        }
    }

    private class TypedCache<T> : IReleasable where T : UnityEngine.Object
    {
        public readonly Dictionary<string, HandleWrapper<T>> Cache = new();
        // 멀티 어웨이터 공유용. UniTaskCompletionSource는 여러 곳에서 안전하게 await 가능
        public readonly Dictionary<string, UniTaskCompletionSource<T>> LoadingTasks = new();
        // 로딩 중 들어온 Unload 요청 예약 (path → 누적 요청 수)
        public readonly Dictionary<string, int> PendingUnloads = new();

        public void ReleaseAll()
        {
            foreach (var wrapper in Cache.Values)
            {
                if (wrapper.Handle.IsValid())
                    Addressables.Release(wrapper.Handle);
            }
            Cache.Clear();
            LoadingTasks.Clear();
            PendingUnloads.Clear();
        }
    }

    // 타입별 캐시. object엔 TypedCache<T>(참조 타입)만 담기므로 박싱 없음.
    // Dictionary<Type, TypedCache<?>>는 C#에 없어 이 패턴이 정석.
    private readonly Dictionary<Type, object> _typedCaches = new();

    private TypedCache<T> GetTypedCache<T>() where T : UnityEngine.Object
    {
        var type = typeof(T);
        if (!_typedCaches.TryGetValue(type, out var raw))
        {
            raw = new TypedCache<T>();
            _typedCaches[type] = raw;
        }
        return (TypedCache<T>)raw;
    }

    // ─────────────────────────────────────────────
    // Load (UniTask)
    // ─────────────────────────────────────────────

    public async UniTask<T> LoadAsync<T>(string key, CancellationToken token = default) where T : UnityEngine.Object
    {
        var cache = GetTypedCache<T>();

        // 무효 핸들 발견 시 기존 RefCount를 신규 핸들로 이월(외부 보유자 Release 정합 유지)
        int carriedRefCount = 0;

        // 1. 캐시 히트
        if (cache.Cache.TryGetValue(key, out var wrapper))
        {
            if (wrapper.Handle.IsValid())
            {
                wrapper.RefCount++;
                return wrapper.Handle.Result;
            }

            // 핸들이 외부 요인으로 무효화됨 → 기존 참조 수를 보존해 재로드 후 복원
            carriedRefCount = wrapper.RefCount > 0 ? wrapper.RefCount : 0;
            GameLogger.LogWarning(ELogCategory.Resource,
                $"무효 핸들 감지 — 재로드 (기존 RefCount {carriedRefCount} 이월): {key} <{typeof(T).Name}>");
            cache.Cache.Remove(key);
        }

        // 2. 로딩 중이면 동일 작업에 합류 (중복 로드 방지)
        if (cache.LoadingTasks.TryGetValue(key, out var loadingSource))
        {
            var result = await loadingSource.Task.AttachExternalCancellation(token);
            if (result != null && cache.Cache.TryGetValue(key, out var sharedWrapper))
                sharedWrapper.RefCount++;
            return result;
        }

        // 3. 신규 로드
        var source = new UniTaskCompletionSource<T>();
        cache.LoadingTasks[key] = source;

        try
        {
            // 키 존재 사전 체크: location이 없으면 LoadAssetAsync가 InvalidKeyException을 던지므로
            // 미리 확인해 경고만 남기고 null 반환 (게임 멈춤 방지)
            var locHandle = Addressables.LoadResourceLocationsAsync(key, typeof(T));
            await locHandle.ToUniTask(cancellationToken: token);
            bool exists = locHandle.Status == AsyncOperationStatus.Succeeded
                          && locHandle.Result != null && locHandle.Result.Count > 0;
            if (locHandle.IsValid())
                Addressables.Release(locHandle);

            if (!exists)
            {
                GameLogger.LogWarning(ELogCategory.Resource,
                    $"Addressable 키 없음 (스킵): {key} <{typeof(T).Name}>");
                source.TrySetResult(null);
                return null;
            }

            var handle = Addressables.LoadAssetAsync<T>(key);
            await handle.ToUniTask(cancellationToken: token);

            if (handle.Status == AsyncOperationStatus.Succeeded && handle.Result != null)
            {
                var newWrapper = new HandleWrapper<T>(handle); // RefCount=1 (이번 호출자 몫)
                newWrapper.RefCount += carriedRefCount;        // 무효화 직전 보유자 수 복원
                cache.Cache[key] = newWrapper;
                source.TrySetResult(handle.Result);
                return handle.Result;
            }

            // 실패한 handle도 반드시 Release (메모리 누수 방지)
            if (handle.IsValid())
                Addressables.Release(handle);

            GameLogger.LogWarning(ELogCategory.Resource, $"Addressable 로드 실패 (스킵): {key}");
            source.TrySetResult(null);
            return null;
        }
        catch (OperationCanceledException)
        {
            source.TrySetCanceled(token);
            throw;
        }
        catch (Exception e)
        {
            // 예외도 게임을 멈추지 않게 경고 + null (취소 제외)
            GameLogger.LogWarning(ELogCategory.Resource,
                $"Addressable 로드 예외 (스킵): {key} / {e.Message}");
            source.TrySetResult(null);
            return null;
        }
        finally
        {
            cache.LoadingTasks.Remove(key);

            // 로딩 중 들어온 Unload 예약 처리
            if (cache.PendingUnloads.TryGetValue(key, out var pendingCount))
            {
                cache.PendingUnloads.Remove(key);
                for (int i = 0; i < pendingCount; i++)
                    ReleaseFromCache(cache, key);
            }
        }
    }

    // ─────────────────────────────────────────────
    // Load (Coroutine)
    // ─────────────────────────────────────────────

    public IEnumerator LoadCoroutine<T>(string key, Action<T> onComplete) where T : UnityEngine.Object
    {
        // UniTask 경로를 Coroutine으로 브릿지 (중복 로드 방지·RefCount 일관성 유지)
        return AsyncBridge.ToCoroutine(LoadAsync<T>(key), onComplete);
    }

    // ─────────────────────────────────────────────
    // Sync (미지원)
    // ─────────────────────────────────────────────

    public T LoadSync<T>(string key) where T : UnityEngine.Object
    {
        throw new NotSupportedException(
            "[AddressableLoader] 동기 로드 미지원. LoadAsync 또는 Resources 모드 사용.");
    }

    // ─────────────────────────────────────────────
    // Release
    // ─────────────────────────────────────────────

    public void Release<T>(string key) where T : UnityEngine.Object
    {
        var cache = GetTypedCache<T>();

        // 아직 로딩 중이면 완료 후 해제되도록 예약
        if (cache.LoadingTasks.ContainsKey(key))
        {
            cache.PendingUnloads.TryGetValue(key, out var count);
            cache.PendingUnloads[key] = count + 1;
            return;
        }

        ReleaseFromCache(cache, key);
    }

    private void ReleaseFromCache<T>(TypedCache<T> cache, string key) where T : UnityEngine.Object
    {
        if (!cache.Cache.TryGetValue(key, out var wrapper))
            return;

        wrapper.RefCount--;

        // RefCount 언더플로 방어
        if (wrapper.RefCount <= 0)
        {
            if (wrapper.Handle.IsValid())
                Addressables.Release(wrapper.Handle);
            cache.Cache.Remove(key);
        }
    }

    public void ReleaseAll()
    {
        foreach (var raw in _typedCaches.Values)
        {
            if (raw is IReleasable releasable)
                releasable.ReleaseAll();
        }
        _typedCaches.Clear();
    }
}