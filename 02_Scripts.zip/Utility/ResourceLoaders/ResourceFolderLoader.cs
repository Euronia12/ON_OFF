// =================================================================
// [스크립트 목적]  Resources 폴더 기반 IResourceLoader 구현
//                 동기 로드 지원. RefCount 없이 Unity 내부 캐시에 위임
// [주요 변수]      - _cache : 로드된 에셋 캐시 (Type → (path → asset))
// [의존 관계]      - UniTask
//                  - ResourceManager가 내부 보유
// [주의]           Resources.UnloadAsset은 개별 해제. GameObject/Component 불가
// =================================================================
using System;
using System.Collections;
using System.Collections.Generic;
using System.Threading;
using Cysharp.Threading.Tasks;
using UnityEngine;

public class ResourceFolderLoader : IResourceLoader
{
    public bool SupportsSyncLoad => true;

    // 타입별 캐시 (Resources는 RefCount 불필요 — Unity가 내부적으로 동일 인스턴스 반환)
    private readonly Dictionary<Type, Dictionary<string, UnityEngine.Object>> _cache = new();

    private Dictionary<string, UnityEngine.Object> GetTypeCache(Type type)
    {
        if (!_cache.TryGetValue(type, out var typeCache))
        {
            typeCache = new Dictionary<string, UnityEngine.Object>();
            _cache[type] = typeCache;
        }
        return typeCache;
    }

    // ─────────────────────────────────────────────
    // Load (UniTask)
    // ─────────────────────────────────────────────

    public async UniTask<T> LoadAsync<T>(string key, CancellationToken token = default) where T : UnityEngine.Object
    {
        var typeCache = GetTypeCache(typeof(T));

        if (typeCache.TryGetValue(key, out var cached) && cached != null)
            return (T)cached;

        var request = Resources.LoadAsync<T>(key);
        await request.ToUniTask(cancellationToken: token);

        var result = request.asset as T;
        if (result == null)
        {
            GameLogger.LogError(ELogCategory.Resource, $"Resources 로드 실패: {key}");
            return null;
        }

        typeCache[key] = result;
        return result;
    }

    // ─────────────────────────────────────────────
    // Load (Coroutine)
    // ─────────────────────────────────────────────

    public IEnumerator LoadCoroutine<T>(string key, Action<T> onComplete) where T : UnityEngine.Object
    {
        var typeCache = GetTypeCache(typeof(T));

        if (typeCache.TryGetValue(key, out var cached) && cached != null)
        {
            onComplete?.Invoke((T)cached);
            yield break;
        }

        var request = Resources.LoadAsync<T>(key);
        yield return request;

        var result = request.asset as T;
        if (result == null)
        {
            GameLogger.LogError(ELogCategory.Resource, $"Resources 로드 실패: {key}");
            onComplete?.Invoke(null);
            yield break;
        }

        typeCache[key] = result;
        onComplete?.Invoke(result);
    }

    // ─────────────────────────────────────────────
    // Sync
    // ─────────────────────────────────────────────

    public T LoadSync<T>(string key) where T : UnityEngine.Object
    {
        var typeCache = GetTypeCache(typeof(T));

        if (typeCache.TryGetValue(key, out var cached) && cached != null)
            return (T)cached;

        var result = Resources.Load<T>(key);
        if (result == null)
        {
            GameLogger.LogError(ELogCategory.Resource, $"Resources 동기 로드 실패: {key}");
            return null;
        }

        typeCache[key] = result;
        return result;
    }

    // ─────────────────────────────────────────────
    // Release
    // ─────────────────────────────────────────────

    public void Release<T>(string key) where T : UnityEngine.Object
    {
        var typeCache = GetTypeCache(typeof(T));
        if (!typeCache.TryGetValue(key, out var asset))
            return;

        typeCache.Remove(key);

        // GameObject/Component는 Resources.UnloadAsset 불가 (예외 발생) → 캐시 제거만
        if (asset != null && !(asset is GameObject) && !(asset is Component))
            Resources.UnloadAsset(asset);
    }

    public void ReleaseAll()
    {
        _cache.Clear();
        // 실제 메모리 회수는 호출부 판단. 전역 GC라 자동 호출하지 않음.
        // 필요 시 ResourceManager.UnloadUnusedAssets() 명시 호출.
    }
}
