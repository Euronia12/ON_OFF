﻿// [임시 진단용] 아무 GameObject에나 붙이고 Play → 버튼 위 클릭
// 확인 후 삭제. EventSystem이 클릭 지점에서 무엇을 감지하는지 직접 출력.
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class ClickDebugProbe : MonoBehaviour
{
    private void Update()
    {
        // 마우스 왼쪽 버튼 눌린 프레임에만 (New Input System)
        var mouse = UnityEngine.InputSystem.Mouse.current;
        if (mouse == null || !mouse.leftButton.wasPressedThisFrame) return;

        if (EventSystem.current == null)
        {
            Debug.LogWarning("[Probe] EventSystem.current 가 null 입니다");
            return;
        }

        var ped = new PointerEventData(EventSystem.current)
        {
            position = mouse.position.ReadValue()
        };

        var results = new List<RaycastResult>();
        EventSystem.current.RaycastAll(ped, results);

        Debug.LogWarning($"[Probe] 클릭 위치={ped.position} / 감지된 오브젝트 수={results.Count}");
        foreach (var r in results)
            Debug.LogWarning($"[Probe]  → {r.gameObject.name} (레이어캐스터: {r.module})");
    }
}