﻿// =================================================================
// [스크립트 목적]  자주 쓰는 트윈 패턴 확장 메서드. UI 등장/퇴장 프리셋 + UniTask 변환
// [의존 관계]      - DG.Tweening, UniTask
// [사용 예시]      await panel.PopInAsync();
//                  button.PunchScale();
// =================================================================
using System.Threading;
using Cysharp.Threading.Tasks;
using DG.Tweening;
using UnityEngine;
using UnityEngine.UI;

public static class TweenExtensions
{
    // ─────────────────────────────────────────────
    // UI 등장 / 퇴장 프리셋
    // ─────────────────────────────────────────────

    /// <summary>스케일 0→1 팝업 등장 (백이즈). CanvasGroup 있으면 페이드 동반</summary>
    public static Tween PopIn(this Transform t, float duration = 0.25f)
    {
        t.localScale = Vector3.zero;
        var seq = DOTween.Sequence();
        seq.Append(t.DOScale(1f, duration).SetEase(Ease.OutBack));

        if (t.TryGetComponent<CanvasGroup>(out var cg))
        {
            cg.alpha = 0f;
            seq.Join(cg.DOFade(1f, duration));
        }
        return seq.SetUpdate(isIndependentUpdate: true); // 일시정지 중에도 동작
    }

    /// <summary>스케일 1→0 팝업 퇴장</summary>
    public static Tween PopOut(this Transform t, float duration = 0.2f)
    {
        var seq = DOTween.Sequence();
        seq.Append(t.DOScale(0f, duration).SetEase(Ease.InBack));

        if (t.TryGetComponent<CanvasGroup>(out var cg))
            seq.Join(cg.DOFade(0f, duration));

        return seq.SetUpdate(true);
    }

    /// <summary>버튼 클릭 펀치 (눌림 피드백)</summary>
    public static Tween PunchScale(this Transform t, float strength = 0.2f, float duration = 0.2f)
        => t.DOPunchScale(Vector3.one * strength, duration, vibrato: 6, elasticity: 0.5f)
            .SetUpdate(true);

    /// <summary>CanvasGroup 페이드 인</summary>
    public static Tween FadeIn(this CanvasGroup cg, float duration = 0.3f)
    {
        cg.alpha = 0f;
        cg.blocksRaycasts = true;
        return cg.DOFade(1f, duration).SetUpdate(true);
    }

    /// <summary>CanvasGroup 페이드 아웃 (완료 시 raycast 차단 해제)</summary>
    public static Tween FadeOut(this CanvasGroup cg, float duration = 0.3f)
        => cg.DOFade(0f, duration)
             .SetUpdate(true)
             .OnComplete(() => cg.blocksRaycasts = false);

    /// <summary>Image fillAmount 트윈 (게이지/로딩바)</summary>
    public static Tween FillTo(this Image img, float target, float duration = 0.3f)
        => img.DOFillAmount(Mathf.Clamp01(target), duration).SetUpdate(true);

    // ─────────────────────────────────────────────
    // UniTask 변환 (await 가능)
    // ─────────────────────────────────────────────

    /// <summary>트윈을 await. 타겟 파괴 시 자동 취소되도록 token 연동 권장.</summary>
    /// <summary>
    /// 트윈을 await. tween.ToUniTask 확장(DOTween-UniTask 브릿지)이 없는 환경 대응으로
    /// UniTaskCompletionSource 직접 구현. 취소 시 Canceled 전파, 등록 해제 보장.
    /// </summary>
    public static UniTask AsUniTask(this Tween tween, CancellationToken token = default)
    {
        if (tween == null || !tween.IsActive())
            return UniTask.CompletedTask;

        var tcs = new UniTaskCompletionSource();

        // 취소 등록 핸들. 완료/취소 어느 경로로 끝나든 반드시 해제(토큰 수명 동안 람다 잔류 방지).
        // 람다는 reg 변수를 캡처(값이 아닌 참조) → 실행 시점엔 token.Register 반환값이 할당된 후라 안전.
        CancellationTokenRegistration reg = default;

        void DisposeRegistration()
        {
            reg.Dispose();
        }

        tween.OnComplete(() => { tcs.TrySetResult(); DisposeRegistration(); })
             .OnKill(() => { tcs.TrySetResult(); DisposeRegistration(); });

        reg = token.Register(() =>
        {
            tcs.TrySetCanceled(token); // 취소는 Canceled로 — await 측에서 취소 구분 가능
            DisposeRegistration();
        });

        return tcs.Task;
    }
}
