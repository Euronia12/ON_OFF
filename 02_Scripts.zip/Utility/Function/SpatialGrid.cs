// =================================================================
// [스크립트 목적]  균일 그리드 공간 분할. 거리 기반 쿼리 O(1) 셀 + 인근만 검사
// [주요 변수]      - _cells      : 셀 좌표 → 엔티티 리스트
//                  - _cellSize   : 셀 크기. 평균 쿼리 반경의 1~2배 권장
//                  - _entityCell : 엔티티 → 현재 셀 좌표 (이동 시 셀 갱신용)
// [의존 관계]      - IRegisterableEntity
// [성능 특성]      등록 O(1) / 위치 갱신 O(1) (셀 이동 시 List Remove O(n))
//                  거리 쿼리 O(반경 내 셀 수 × 셀당 평균 엔티티 수)
// =================================================================
using System;
using System.Collections.Generic;
using UnityEngine;

public class SpatialGrid<T> where T : class, IRegisterableEntity
{
    // 셀 좌표는 long으로 패킹 (x:32 | z:32). Dictionary 키 GC 회피
    private readonly Dictionary<long, List<T>> _cells = new(64);
    private readonly Dictionary<T, long> _entityCell = new(256);

    private readonly float _cellSize;
    private readonly float _cellSizeInv;
    private readonly bool _use2D;

    public int EntityCount => _entityCell.Count;
    public float CellSize => _cellSize;

    /// <param name="cellSize">셀 크기. 작을수록 정밀 / 클수록 메모리 절약. 평균 쿼리 반경의 1~2배</param>
    /// <param name="use2D">true면 XY 평면(2D), false면 XZ 평면(3D 탑다운)</param>
    public SpatialGrid(float cellSize = 10f, bool use2D = false)
    {
        _cellSize = Mathf.Max(0.1f, cellSize);
        _cellSizeInv = 1f / _cellSize;
        _use2D = use2D;
    }

    // ─────────────────────────────────────────────
    // 셀 좌표 패킹/언패킹
    // ─────────────────────────────────────────────

    private long GetCellKey(Vector3 position)
    {
        int x = Mathf.FloorToInt(position.x * _cellSizeInv);
        int y = _use2D
            ? Mathf.FloorToInt(position.y * _cellSizeInv)
            : Mathf.FloorToInt(position.z * _cellSizeInv);
        return PackKey(x, y);
    }

    private static long PackKey(int x, int y)
    {
        // int 두 개를 long 하나로 (음수 안전)
        return ((long)(uint)x) | (((long)(uint)y) << 32);
    }

    // ─────────────────────────────────────────────
    // 등록 / 갱신 / 제거
    // ─────────────────────────────────────────────

    public void Add(T entity)
    {
        if (entity == null || entity.Transform == null) return;
        if (_entityCell.ContainsKey(entity)) return;

        long key = GetCellKey(entity.Transform.position);
        GetOrCreateCell(key).Add(entity);
        _entityCell[entity] = key;
    }

    public void Remove(T entity)
    {
        if (entity == null) return;
        if (!_entityCell.TryGetValue(entity, out long key)) return;

        if (_cells.TryGetValue(key, out var list))
        {
            list.Remove(entity);
            if (list.Count == 0) _cells.Remove(key);
        }
        _entityCell.Remove(entity);
    }

    /// <summary>엔티티 이동 시 호출. 셀 경계 넘었으면 자동 재배치</summary>
    public void Update(T entity)
    {
        if (entity == null || entity.Transform == null) return;
        if (!_entityCell.TryGetValue(entity, out long oldKey)) return;

        long newKey = GetCellKey(entity.Transform.position);
        if (oldKey == newKey) return; // 같은 셀이면 노옵

        if (_cells.TryGetValue(oldKey, out var oldList))
        {
            oldList.Remove(entity);
            if (oldList.Count == 0) _cells.Remove(oldKey);
        }

        GetOrCreateCell(newKey).Add(entity);
        _entityCell[entity] = newKey;
    }

    public void Clear()
    {
        _cells.Clear();
        _entityCell.Clear();
    }

    private List<T> GetOrCreateCell(long key)
    {
        if (!_cells.TryGetValue(key, out var list))
        {
            list = new List<T>(8);
            _cells[key] = list;
        }
        return list;
    }

    // ─────────────────────────────────────────────
    // 쿼리 (할당 없음)
    // ─────────────────────────────────────────────

    /// <summary>
    /// 중심으로부터 radius 내의 엔티티를 results에 채움.
    /// 호출부가 List 재사용 → GC Zero.
    /// </summary>
    public void QueryRadius(Vector3 center, float radius, List<T> results,
        Predicate<T> filter = null)
    {
        results.Clear();
        if (radius <= 0f) return;

        int minX = Mathf.FloorToInt((center.x - radius) * _cellSizeInv);
        int maxX = Mathf.FloorToInt((center.x + radius) * _cellSizeInv);
        int minY, maxY;
        if (_use2D)
        {
            minY = Mathf.FloorToInt((center.y - radius) * _cellSizeInv);
            maxY = Mathf.FloorToInt((center.y + radius) * _cellSizeInv);
        }
        else
        {
            minY = Mathf.FloorToInt((center.z - radius) * _cellSizeInv);
            maxY = Mathf.FloorToInt((center.z + radius) * _cellSizeInv);
        }

        float radiusSqr = radius * radius;

        for (int x = minX; x <= maxX; x++)
        {
            for (int y = minY; y <= maxY; y++)
            {
                long key = PackKey(x, y);
                if (!_cells.TryGetValue(key, out var list)) continue;

                for (int i = 0; i < list.Count; i++)
                {
                    var e = list[i];
                    if (e == null || !e.IsAlive) continue;
                    if (filter != null && !filter(e)) continue;

                    Vector3 pos = e.Transform.position;
                    float dx = pos.x - center.x;
                    float dy = _use2D ? pos.y - center.y : pos.z - center.z;

                    if (dx * dx + dy * dy <= radiusSqr)
                        results.Add(e);
                }
            }
        }
    }

    /// <summary>가장 가까운 엔티티 1개 반환. 없으면 null.</summary>
    public T FindNearest(Vector3 center, float maxRadius, Predicate<T> filter = null)
    {
        T best = null;
        float bestDistSqr = maxRadius * maxRadius;

        int minX = Mathf.FloorToInt((center.x - maxRadius) * _cellSizeInv);
        int maxX = Mathf.FloorToInt((center.x + maxRadius) * _cellSizeInv);
        int minY, maxY;
        if (_use2D)
        {
            minY = Mathf.FloorToInt((center.y - maxRadius) * _cellSizeInv);
            maxY = Mathf.FloorToInt((center.y + maxRadius) * _cellSizeInv);
        }
        else
        {
            minY = Mathf.FloorToInt((center.z - maxRadius) * _cellSizeInv);
            maxY = Mathf.FloorToInt((center.z + maxRadius) * _cellSizeInv);
        }

        for (int x = minX; x <= maxX; x++)
        {
            for (int y = minY; y <= maxY; y++)
            {
                long key = PackKey(x, y);
                if (!_cells.TryGetValue(key, out var list)) continue;

                for (int i = 0; i < list.Count; i++)
                {
                    var e = list[i];
                    if (e == null || !e.IsAlive) continue;
                    if (filter != null && !filter(e)) continue;

                    Vector3 pos = e.Transform.position;
                    float dx = pos.x - center.x;
                    float dy = _use2D ? pos.y - center.y : pos.z - center.z;
                    float distSqr = dx * dx + dy * dy;

                    if (distSqr < bestDistSqr)
                    {
                        bestDistSqr = distSqr;
                        best = e;
                    }
                }
            }
        }
        return best;
    }
}
