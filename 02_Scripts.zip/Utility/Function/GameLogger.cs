// =================================================================
// [스크립트 목적]  카테고리별 빌드 조건부 로깅. 빌드 크기·런타임 비용 최소화
//                 Release 빌드에서 Log/LogWarning은 컴파일러가 통째로 제거 (Conditional)
//                 Error는 항상 출력 (이슈 추적용)
// [주요 변수]      - _enabledCategories : 활성 카테고리 비트마스크
//                  - _categoryColors    : 카테고리별 색상 (에디터 한정)
// [의존 관계]      - 어디서나 사용 가능. 매니저 의존성 없음
// =================================================================
using System.Diagnostics;
using UnityEngine;
using Debug = UnityEngine.Debug;

public static class GameLogger
{
    // 기본값: Editor·Development Build에서는 전체 활성, Release는 어차피 컴파일 제거
    private static ELogCategory _enabledCategories = ELogCategory.All;

#if UNITY_EDITOR
    // 에디터 한정 색상 태깅. 빌드에는 영향 없음
    private static readonly string[] _categoryColors =
    {
        "#FFFFFF", // System
        "#7FFF7F", // Resource
        "#7FBFFF", // UI
        "#FFD27F", // Audio
        "#FF7FBF", // Input
        "#BF7FFF", // Save
        "#7FFFFF", // Data
        "#FFB27F", // Pool
        "#B27FFF", // Scene
        "#FF7F7F", // Network
        "#7FFFB2", // Analytics
        "#FFFF7F"  // Gameplay
    };
#endif

    /// <summary>활성 카테고리 일괄 설정. 비트 연산으로 조합.</summary>
    public static void SetEnabledCategories(ELogCategory categories)
        => _enabledCategories = categories;

    /// <summary>개별 카테고리 ON/OFF.</summary>
    public static void SetCategoryEnabled(ELogCategory category, bool enabled)
    {
        if (enabled) _enabledCategories |= category;
        else _enabledCategories &= ~category;
    }

    public static bool IsCategoryEnabled(ELogCategory category)
        => (_enabledCategories & category) != 0;

    // ─────────────────────────────────────────────
    // 로그 메서드
    // Conditional 어트리뷰트로 Release 빌드에서 호출부 자체가 제거됨
    // → Release 빌드 성능·크기 영향 Zero
    // ─────────────────────────────────────────────

    [Conditional("UNITY_EDITOR"), Conditional("DEVELOPMENT_BUILD")]
    public static void Log(ELogCategory category, string message)
    {
        if (!IsCategoryEnabled(category)) return;
        Debug.Log(FormatMessage(category, message));
    }

    [Conditional("UNITY_EDITOR"), Conditional("DEVELOPMENT_BUILD")]
    public static void Log(ELogCategory category, string message, Object context)
    {
        if (!IsCategoryEnabled(category)) return;
        Debug.Log(FormatMessage(category, message), context);
    }

    [Conditional("UNITY_EDITOR"), Conditional("DEVELOPMENT_BUILD")]
    public static void LogWarning(ELogCategory category, string message)
    {
        if (!IsCategoryEnabled(category)) return;
        Debug.LogWarning(FormatMessage(category, message));
    }

    [Conditional("UNITY_EDITOR"), Conditional("DEVELOPMENT_BUILD")]
    public static void LogWarning(ELogCategory category, string message, Object context)
    {
        if (!IsCategoryEnabled(category)) return;
        Debug.LogWarning(FormatMessage(category, message), context);
    }

    /// <summary>에러는 Release 빌드에서도 출력. 카테고리 필터링도 적용 안 함 (이슈 추적 우선).</summary>
    public static void LogError(ELogCategory category, string message)
        => Debug.LogError(FormatMessage(category, message));

    public static void LogError(ELogCategory category, string message, Object context)
        => Debug.LogError(FormatMessage(category, message), context);

    // ─────────────────────────────────────────────
    // 포맷팅
    // ─────────────────────────────────────────────

    private static string FormatMessage(ELogCategory category, string message)
    {
#if UNITY_EDITOR
        var color = GetCategoryColor(category);
        return $"<color={color}>[{category}]</color> {message}";
#else
        return $"[{category}] {message}";
#endif
    }

#if UNITY_EDITOR
    private static string GetCategoryColor(ELogCategory category)
    {
        // 비트 위치 → 색상 인덱스
        int value = (int)category;
        if (value <= 0) return "#FFFFFF";

        int index = 0;
        while ((value & 1) == 0 && index < _categoryColors.Length - 1)
        {
            value >>= 1;
            index++;
        }

        return index < _categoryColors.Length ? _categoryColors[index] : "#FFFFFF";
    }
#endif
}
