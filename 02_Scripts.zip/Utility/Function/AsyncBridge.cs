﻿// =================================================================
// [스크립트 목적]  UniTask ↔ Coroutine 양방향 변환 헬퍼
//                 두 비동기 모델 어느 쪽이든 즉시 사용 가능하도록 다리 역할
// [의존 관계]      - UniTask, CoroutineRunner
// [개선]           1) 예외 catch 후 yield break 분리 (yield 내부 try-catch 불가 대응)
//                  2) 결과 없는 UniTask + 완료 콜백 오버로드 추가
//                     (SceneFlowManager.LoadSceneCoroutine 등 위임 경로에서 사용)
// =================================================================
using System;
using System.Collections;
using System.Threading;
using Cysharp.Threading.Tasks;

public static class AsyncBridge
{
    // ─────────────────────────────────────────────
    // UniTask → Coroutine
    // ─────────────────────────────────────────────

    /// <summary>UniTask를 Coroutine 환경에서 대기. UniTask 내장 ToCoroutine 래핑.</summary>
    public static IEnumerator ToCoroutine(UniTask task) => task.ToCoroutine();

    /// <summary>
    /// 결과 없는 UniTask를 Coroutine 환경에서 대기. 완료(성공) 시 콜백 호출.
    /// 예외는 로그로 격리하고 콜백을 호출하지 않음 (호출부 코루틴이 죽지 않음).
    /// </summary>
    public static IEnumerator ToCoroutine(UniTask task, Action onComplete)
        => ToCoroutineInternal(task, onComplete);

    /// <summary>결과 있는 UniTask를 Coroutine 환경에서 대기. 완료 시 콜백 호출.</summary>
    public static IEnumerator ToCoroutine<T>(UniTask<T> task, Action<T> onComplete)
        => ToCoroutineInternal(task, onComplete);

    private static IEnumerator ToCoroutineInternal(UniTask task, Action onComplete)
    {
        var awaiter = task.GetAwaiter();
        while (!awaiter.IsCompleted)
            yield return null;

        // GetResult 호출은 yield 밖에서 try-catch 가능
        bool succeeded = false;
        try
        {
            awaiter.GetResult();
            succeeded = true;
        }
        catch (Exception e)
        {
            UnityEngine.Debug.LogError($"[AsyncBridge] UniTask 변환 예외: {e}");
        }

        if (succeeded)
            onComplete?.Invoke();
    }

    private static IEnumerator ToCoroutineInternal<T>(UniTask<T> task, Action<T> onComplete)
    {
        var awaiter = task.GetAwaiter();
        while (!awaiter.IsCompleted)
            yield return null;

        // GetResult 호출은 yield 밖에서 try-catch 가능
        T result = default;
        bool succeeded = false;
        try
        {
            result = awaiter.GetResult();
            succeeded = true;
        }
        catch (Exception e)
        {
            UnityEngine.Debug.LogError($"[AsyncBridge] UniTask 변환 예외: {e}");
        }

        if (succeeded)
            onComplete?.Invoke(result);
    }

    // ─────────────────────────────────────────────
    // Coroutine → UniTask
    // ─────────────────────────────────────────────

    /// <summary>Coroutine을 UniTask로 변환. CoroutineRunner를 통해 실행됨.</summary>
    public static async UniTask ToUniTask(IEnumerator routine, CancellationToken token = default)
    {
        if (routine == null) return;

        var tcs = new UniTaskCompletionSource();
        CoroutineRunner.StartRoutine(RunCoroutineWrapper(routine, tcs, token));
        await tcs.Task.AttachExternalCancellation(token);
    }

    /// <summary>
    /// 결과 있는 Coroutine 패턴을 UniTask&lt;T&gt;로 변환.
    /// routineFactory는 결과 setter를 받아 코루틴 내부에서 채워줘야 함.
    /// </summary>
    public static async UniTask<T> ToUniTask<T>(
        Func<Action<T>, IEnumerator> routineFactory,
        CancellationToken token = default)
    {
        if (routineFactory == null) return default;

        var tcs = new UniTaskCompletionSource<T>();
        T resultHolder = default;

        Action<T> setter = value => resultHolder = value;
        var routine = routineFactory(setter);

        CoroutineRunner.StartRoutine(RunCoroutineWrapperT(routine, tcs, () => resultHolder, token));
        return await tcs.Task.AttachExternalCancellation(token);
    }

    // ─────────────────────────────────────────────
    // 내부 래퍼
    // ─────────────────────────────────────────────

    private static IEnumerator RunCoroutineWrapper(
        IEnumerator routine, UniTaskCompletionSource tcs, CancellationToken token)
    {
        while (true)
        {
            if (token.IsCancellationRequested)
            {
                tcs.TrySetCanceled(token);
                yield break;
            }

            bool moved;
            try
            {
                moved = routine.MoveNext();
            }
            catch (Exception e)
            {
                tcs.TrySetException(e);
                yield break;
            }

            if (!moved) break;
            yield return routine.Current;
        }
        tcs.TrySetResult();
    }

    private static IEnumerator RunCoroutineWrapperT<T>(
        IEnumerator routine, UniTaskCompletionSource<T> tcs,
        Func<T> resultGetter, CancellationToken token)
    {
        while (true)
        {
            if (token.IsCancellationRequested)
            {
                tcs.TrySetCanceled(token);
                yield break;
            }

            bool moved;
            try
            {
                moved = routine.MoveNext();
            }
            catch (Exception e)
            {
                tcs.TrySetException(e);
                yield break;
            }

            if (!moved) break;
            yield return routine.Current;
        }
        tcs.TrySetResult(resultGetter != null ? resultGetter() : default);
    }
}