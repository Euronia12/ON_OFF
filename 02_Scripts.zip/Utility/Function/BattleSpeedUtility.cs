using UnityEngine;

/// <summary>전투 고속모드 연출 배율 헬퍼. 게임 규칙이 아니라 duration/speed 계산에만 사용한다.</summary>
public static class BattleSpeedUtility
{
    private const float FastModeMultiplier = 2f;

    public static float Multiplier
    {
        get
        {
            if (!SettingsManager.HasInstance || SettingsManager.Instance.Current == null)
            {
                return 1f;
            }

            return SettingsManager.Instance.Current.FastModeEnabled ? FastModeMultiplier : 1f;
        }
    }

    public static float ScaleDuration(float duration)
    {
        if (duration <= 0f)
        {
            return 0f;
        }

        return duration / Mathf.Max(0.0001f, Multiplier);
    }

    public static float ScaleDuration(float duration, float visualSpeedMultiplier, float minimumDuration)
    {
        if (duration <= 0f)
        {
            return 0f;
        }

        return Mathf.Max(
            Mathf.Max(0f, minimumDuration),
            ScaleDuration(duration) / Mathf.Max(0.0001f, visualSpeedMultiplier));
    }

    public static float ScaleSpeed(float speed)
    {
        if (speed <= 0f)
        {
            return speed;
        }

        return speed * Multiplier;
    }
}
