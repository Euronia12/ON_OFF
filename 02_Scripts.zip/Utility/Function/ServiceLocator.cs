// =================================================================
// [스크립트 목적]  매니저 통합 접근 (옵션). 테스트 시 Mock 주입 용이
//                 기본 접근은 Singleton<T>.Instance 권장. 교체·테스트 필요 시만 사용
// =================================================================
using System;
using System.Collections.Generic;

public static class ServiceLocator
{
    private static readonly Dictionary<Type, object> _services = new();

    public static void Register<T>(T service) where T : class
        => _services[typeof(T)] = service;

    public static T Get<T>() where T : class
    {
        if (_services.TryGetValue(typeof(T), out var service))
            return (T)service;

        GameLogger.LogWarning(ELogCategory.System, $"서비스 미등록: {typeof(T).Name}");
        return null;
    }

    public static bool TryGet<T>(out T service) where T : class
    {
        if (_services.TryGetValue(typeof(T), out var raw))
        {
            service = (T)raw;
            return true;
        }
        service = null;
        return false;
    }

    public static void Unregister<T>() where T : class => _services.Remove(typeof(T));
    public static void Clear() => _services.Clear();
}
