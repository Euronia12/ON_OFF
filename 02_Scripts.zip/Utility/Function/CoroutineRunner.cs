﻿// =================================================================
// [스크립트 목적]  MonoBehaviour 없는 곳에서 Coroutine 실행. 그룹 단위 중단 지원
// [주요 변수]      - _instance       : Lazy 생성되는 단일 인스턴스
//                  - _groups         : 그룹별 추적 정보 (활성 수 + 코루틴 목록)
// [의존 관계]      - BootstrapInitializer보다 먼저 사용 가능 (Lazy 생성)
// [개선]           그룹 자동 정리를 카운터 방식으로 재설계.
//                  기존: 완료 코루틴이 목록에서 안 빠져 누적(메모리 누수) → 그룹도 영영 안 비워짐.
//                  변경: 활성 카운터로 완료 추적 → 0이면 그룹 제거. 즉시완료/장기실행 모두 정확.
// =================================================================
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CoroutineRunner : MonoBehaviour
{
    private static CoroutineRunner _instance;
    private static bool _isQuitting;

    /// <summary>그룹 추적 정보. 활성 코루틴 수 + 중단용 핸들 목록.</summary>
    private class GroupInfo
    {
        public int ActiveCount;                       // 아직 완료되지 않은 코루틴 수
        public readonly List<Coroutine> Routines = new(4); // StopGroup용 핸들 목록
    }

    // 그룹 ID → 추적 정보
    private readonly Dictionary<string, GroupInfo> _groups = new(8);

    /// <summary>
    /// 정적 진입점. 최초 호출 시 GameObject 자동 생성.
    /// 게임 종료 중에는 null 반환 (정적 인스턴스 재생성 방지).
    /// </summary>
    private static CoroutineRunner Instance
    {
        get
        {
            if (_isQuitting) return null;

            if (_instance == null)
            {
                var go = new GameObject("[CoroutineRunner]");
                _instance = go.AddComponent<CoroutineRunner>();
                DontDestroyOnLoad(go);
            }
            return _instance;
        }
    }

    private void OnApplicationQuit() => _isQuitting = true;

    private void OnDestroy()
    {
        if (_instance == this) _instance = null;
    }

    /// <summary>코루틴 실행. 종료 중에는 무시되어 null 반환.</summary>
    public static Coroutine StartRoutine(IEnumerator routine)
    {
        var runner = Instance;
        if (runner == null || routine == null) return null;
        return runner.StartCoroutine(routine);
    }

    /// <summary>그룹에 속한 코루틴 실행. StopGroup으로 일괄 중단 가능. 완료 시 자동 추적 해제.</summary>
    public static Coroutine StartRoutine(IEnumerator routine, string group)
    {
        var runner = Instance;
        if (runner == null || routine == null) return null;

        if (string.IsNullOrEmpty(group))
            return runner.StartCoroutine(routine);

        if (!runner._groups.TryGetValue(group, out var info))
        {
            info = new GroupInfo();
            runner._groups[group] = info;
        }

        // 카운터를 먼저 증가시킨 뒤 시작.
        // (StartCoroutine은 첫 yield까지 동기 실행 → 즉시완료 코루틴이면 wrapper가
        //  반환 전에 카운터를 감소시킬 수 있으므로, 증가가 반드시 선행돼야 함)
        info.ActiveCount++;

        var co = runner.StartCoroutine(runner.GroupedRoutineWrapper(routine, group));

        // 즉시완료(yield 없이 끝)된 경우 wrapper가 이미 카운터를 감소시키고 그룹을 제거했을 수 있음.
        // 그 경우 info는 더 이상 _groups에 없으므로 핸들 목록에 추가하지 않음(StopGroup 대상도 아님).
        if (co != null && runner._groups.TryGetValue(group, out var current) && current == info)
            info.Routines.Add(co);

        return co;
    }

    /// <summary>개별 코루틴 중단.</summary>
    public static void StopRoutine(Coroutine routine)
    {
        if (_instance == null || routine == null) return;
        _instance.StopCoroutine(routine);
    }

    /// <summary>그룹 내 모든 코루틴 일괄 중단. 씬 전환·로딩 취소 시 유용.</summary>
    public static void StopGroup(string group)
    {
        if (_instance == null || string.IsNullOrEmpty(group)) return;
        if (!_instance._groups.TryGetValue(group, out var info)) return;

        for (int i = 0; i < info.Routines.Count; i++)
        {
            if (info.Routines[i] != null)
                _instance.StopCoroutine(info.Routines[i]);
        }
        // 강제 중단 → wrapper의 완료 로직이 실행되지 않으므로 여기서 그룹 통째 제거
        info.Routines.Clear();
        _instance._groups.Remove(group);
    }

    /// <summary>모든 코루틴 일괄 중단. 비상 정리용.</summary>
    public static void StopAll()
    {
        if (_instance == null) return;
        _instance.StopAllCoroutines();
        _instance._groups.Clear();
    }

    /// <summary>현재 그룹의 활성 코루틴 수 (디버그·테스트용). 없으면 0.</summary>
    public static int GetGroupActiveCount(string group)
    {
        if (_instance == null || string.IsNullOrEmpty(group)) return 0;
        return _instance._groups.TryGetValue(group, out var info) ? info.ActiveCount : 0;
    }

    /// <summary>그룹 추적용 래퍼. 코루틴 완료 시 카운터 감소, 0이면 그룹 제거.</summary>
    private IEnumerator GroupedRoutineWrapper(IEnumerator inner, string group)
    {
        yield return inner;

        // 완료 → 카운터 감소. 0이면 그룹 제거(목록·Dictionary 누적 방지)
        if (_groups.TryGetValue(group, out var info))
        {
            info.ActiveCount--;
            if (info.ActiveCount <= 0)
            {
                info.Routines.Clear();
                _groups.Remove(group);
            }
        }
    }
}