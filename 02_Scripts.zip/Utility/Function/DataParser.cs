﻿// =================================================================
// [스크립트 목적]  데이터 텍스트(CSV/JSON)를 런타임 객체 목록으로 변환하는 파싱 전담 클래스
//                 DataManager는 로드·테이블 관리만, 변환 책임은 여기로 분리 (SRP)
// [주요 메서드]    - ParseCsv  : CSV 텍스트 → (id, object) 목록 (CsvParser로 행 분해 후 리플렉션 매핑)
//                  - ParseJson : JSON 루트 배열 → (id, object) 목록 (Newtonsoft)
// [의존 관계]      - CsvParser(행/열 분해), Newtonsoft.Json(JSON 역직렬화), GameLogger
// [반환 규칙]      변환된 (id, instance) 쌍 리스트. 실패 항목은 경고 후 스킵
// =================================================================
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Reflection;
using Newtonsoft.Json.Linq;

public static class DataParser
{
    private const BindingFlags FieldFlags = BindingFlags.Public | BindingFlags.Instance;

    /// <summary>변환 결과 1건. id와 생성된 인스턴스를 함께 보유.</summary>
    public readonly struct ParsedEntry
    {
        public readonly string Id;
        public readonly object Instance;
        public ParsedEntry(string id, object instance) { Id = id; Instance = instance; }
    }

    // ─────────────────────────────────────────────
    // CSV
    // ─────────────────────────────────────────────

    /// <summary>
    /// CSV 텍스트를 type 인스턴스 목록으로 변환.
    /// 헤더 컬럼명 = public 필드명 자동 매핑. idColumn 컬럼값을 id로 사용.
    /// 실패(헤더 없음·ID 컬럼 없음) 시 빈 목록 반환.
    /// </summary>
    public static List<ParsedEntry> ParseCsv(string csv, Type type, string idColumn, string sourceName)
    {
        var result = new List<ParsedEntry>();

        var rows = CsvParser.Parse(csv);
        if (rows.Count < 2)
        {
            GameLogger.LogWarning(ELogCategory.Data,
                $"[CSV] 데이터 없음 (헤더+1행 이상 필요): {sourceName}");
            return result;
        }

        var header = rows[0];
        int idIdx = header.IndexOf(idColumn);
        if (idIdx < 0)
        {
            GameLogger.LogError(ELogCategory.Data,
                $"[CSV] ID 컬럼 없음 '{idColumn}': {sourceName}");
            return result;
        }

        for (int r = 1; r < rows.Count; r++)
        {
            var row = rows[r];
            if (row.Count <= idIdx) continue;

            string id = row[idIdx];
            if (string.IsNullOrWhiteSpace(id)) continue;

            object instance = Activator.CreateInstance(type);
            MapRow(instance, type, header, row);
            result.Add(new ParsedEntry(id, instance));
        }

        return result;
    }

    /// <summary>헤더 컬럼명과 같은 이름의 public 필드를 찾아 자동 변환·할당.</summary>
    private static void MapRow(object instance, Type type, List<string> header, List<string> row)
    {
        for (int c = 0; c < header.Count && c < row.Count; c++)
        {
            var field = type.GetField(header[c], FieldFlags);
            if (field == null) continue;

            try
            {
                object value = ConvertScalar(row[c], field.FieldType);
                if (value != null || !field.FieldType.IsValueType)
                    field.SetValue(instance, value);
            }
            catch (Exception e)
            {
                GameLogger.LogWarning(ELogCategory.Data,
                    $"[CSV] 변환 실패 {type.Name}.{header[c]}='{row[c]}': {e.Message}");
            }
        }
    }

    private static object ConvertScalar(string raw, Type targetType)
    {
        if (targetType == typeof(string)) return raw;

        // Nullable<T>: 빈 값이면 null, 아니면 내부 타입으로 변환
        var underlying = Nullable.GetUnderlyingType(targetType);
        if (underlying != null)
            return string.IsNullOrWhiteSpace(raw) ? null : ConvertScalar(raw, underlying);

        if (string.IsNullOrWhiteSpace(raw)) return GetDefault(targetType);

        var culture = CultureInfo.InvariantCulture;

        // 정수 계열
        if (targetType == typeof(int)) return int.Parse(raw, culture);
        if (targetType == typeof(long)) return long.Parse(raw, culture);
        if (targetType == typeof(short)) return short.Parse(raw, culture);
        if (targetType == typeof(byte)) return byte.Parse(raw, culture);
        if (targetType == typeof(sbyte)) return sbyte.Parse(raw, culture);
        if (targetType == typeof(uint)) return uint.Parse(raw, culture);
        if (targetType == typeof(ulong)) return ulong.Parse(raw, culture);
        if (targetType == typeof(ushort)) return ushort.Parse(raw, culture);

        // 실수 계열
        if (targetType == typeof(float)) return float.Parse(raw, culture);
        if (targetType == typeof(double)) return double.Parse(raw, culture);
        if (targetType == typeof(decimal)) return decimal.Parse(raw, culture);

        if (targetType == typeof(bool)) return ParseBool(raw);
        if (targetType.IsEnum) return Enum.Parse(targetType, raw, ignoreCase: true);

        // Unity 벡터: "x;y" / "x;y;z" (콤마는 CSV 구분자와 충돌하므로 세미콜론 권장)
        if (targetType == typeof(UnityEngine.Vector2)) return ParseVector2(raw, culture);
        if (targetType == typeof(UnityEngine.Vector3)) return ParseVector3(raw, culture);

        GameLogger.LogWarning(ELogCategory.Data,
            $"[CSV] 미지원 타입: {targetType.Name} — 기본값 사용");
        return GetDefault(targetType);
    }

    /// <summary>"x;y" 형식 파싱. 구분자는 세미콜론(CSV 콤마 충돌 회피).</summary>
    private static UnityEngine.Vector2 ParseVector2(string raw, CultureInfo culture)
    {
        var parts = raw.Split(';');
        float x = parts.Length > 0 ? float.Parse(parts[0], culture) : 0f;
        float y = parts.Length > 1 ? float.Parse(parts[1], culture) : 0f;
        return new UnityEngine.Vector2(x, y);
    }

    /// <summary>"x;y;z" 형식 파싱. 구분자는 세미콜론(CSV 콤마 충돌 회피).</summary>
    private static UnityEngine.Vector3 ParseVector3(string raw, CultureInfo culture)
    {
        var parts = raw.Split(';');
        float x = parts.Length > 0 ? float.Parse(parts[0], culture) : 0f;
        float y = parts.Length > 1 ? float.Parse(parts[1], culture) : 0f;
        float z = parts.Length > 2 ? float.Parse(parts[2], culture) : 0f;
        return new UnityEngine.Vector3(x, y, z);
    }

    private static bool ParseBool(string raw)
    {
        raw = raw.Trim().ToLowerInvariant();
        return raw is "1" or "true" or "y" or "yes" or "o";
    }

    private static object GetDefault(Type type)
        => type.IsValueType ? Activator.CreateInstance(type) : null;

    // ─────────────────────────────────────────────
    // JSON (Newtonsoft, 루트 배열)
    // ─────────────────────────────────────────────

    /// <summary>
    /// JSON 루트 배열 [ {...}, ... ] 을 type 인스턴스 목록으로 변환.
    /// idField 필드값을 id로 사용. 파싱 실패 시 빈 목록 반환.
    /// </summary>
    public static List<ParsedEntry> ParseJson(string json, Type type, string idField, string sourceName)
    {
        var result = new List<ParsedEntry>();

        JArray array;
        try
        {
            array = JArray.Parse(json);
        }
        catch (Exception e)
        {
            GameLogger.LogError(ELogCategory.Data,
                $"[JSON] 파싱 실패 ({sourceName}): {e.Message} (루트가 배열 '[...]' 인지 확인)");
            return result;
        }

        if (array.Count == 0)
        {
            GameLogger.LogWarning(ELogCategory.Data, $"[JSON] 데이터 없음: {sourceName}");
            return result;
        }

        foreach (var jToken in array)
        {
            object instance;
            try
            {
                instance = jToken.ToObject(type);
            }
            catch (Exception e)
            {
                GameLogger.LogWarning(ELogCategory.Data,
                    $"[JSON] 항목 변환 실패 ({sourceName}): {e.Message}");
                continue;
            }

            if (instance == null) continue;

            var idToken = jToken[idField];
            if (idToken == null)
            {
                GameLogger.LogWarning(ELogCategory.Data,
                    $"[JSON] ID 필드 없음 '{idField}' — 항목 스킵 ({sourceName})");
                continue;
            }

            string id = idToken.ToString();
            if (string.IsNullOrWhiteSpace(id)) continue;

            result.Add(new ParsedEntry(id, instance));
        }

        return result;
    }
}