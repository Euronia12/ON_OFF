// =================================================================
// [스크립트 목적]  RFC 4180 준수 CSV 파서. 따옴표 내 콤마·개행·이스케이프 처리
//                 런타임/에디터 양쪽 사용 가능
// [개선]           마지막 빈 행 처리 명확화 (hasContentInRow 플래그)
// =================================================================
using System.Collections.Generic;
using System.Text;

public static class CsvParser
{
    /// <summary>
    /// CSV 텍스트를 행×열 리스트로 파싱.
    /// 따옴표 내부의 콤마/개행/이중따옴표("") 정상 처리.
    /// </summary>
    public static List<List<string>> Parse(string text)
    {
        var rows = new List<List<string>>();
        if (string.IsNullOrEmpty(text)) return rows;

        var currentRow = new List<string>();
        var sb = new StringBuilder();
        bool inQuotes = false;
        bool hasContentInRow = false;
        int i = 0;
        int len = text.Length;

        while (i < len)
        {
            char c = text[i];

            if (inQuotes)
            {
                if (c == '"')
                {
                    // 이중 따옴표("") → 리터럴 따옴표
                    if (i + 1 < len && text[i + 1] == '"')
                    {
                        sb.Append('"');
                        hasContentInRow = true;
                        i += 2;
                        continue;
                    }
                    inQuotes = false;
                    i++;
                    continue;
                }
                sb.Append(c);
                hasContentInRow = true;
                i++;
                continue;
            }

            switch (c)
            {
                case '"':
                    inQuotes = true;
                    i++;
                    break;

                case ',':
                    currentRow.Add(sb.ToString());
                    sb.Clear();
                    hasContentInRow = true;
                    i++;
                    break;

                case '\r':
                    if (i + 1 < len && text[i + 1] == '\n') i++;
                    if (hasContentInRow || sb.Length > 0)
                    {
                        currentRow.Add(sb.ToString());
                        rows.Add(currentRow);
                    }
                    sb.Clear();
                    currentRow = new List<string>();
                    hasContentInRow = false;
                    i++;
                    break;

                case '\n':
                    if (hasContentInRow || sb.Length > 0)
                    {
                        currentRow.Add(sb.ToString());
                        rows.Add(currentRow);
                    }
                    sb.Clear();
                    currentRow = new List<string>();
                    hasContentInRow = false;
                    i++;
                    break;

                default:
                    sb.Append(c);
                    hasContentInRow = true;
                    i++;
                    break;
            }
        }

        // 마지막 행 (개행 없이 끝나는 경우)
        if (hasContentInRow || sb.Length > 0)
        {
            currentRow.Add(sb.ToString());
            rows.Add(currentRow);
        }

        return rows;
    }
}
