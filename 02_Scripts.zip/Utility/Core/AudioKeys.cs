// =================================================================
// [스크립트 목적]  BGM / SFX Addressable 키 중앙 레지스트리
// [원칙]           - 용도 단위로 그룹핑 (Bgm / Card / Game / Ui)
//                  - 매직 스트링 제거: 사운드 키는 반드시 여기 등록
//                  - 키↔매핑 분리는 두지 않되, 전투 등급 매핑만 예외적으로 여기 보관
//                    (분기 대상이 이 파일의 const 뿐이라 외부 확장메서드보다 응집도가 높음)
// [주의]           키 문자열은 Addressables 주소와 일치해야 한다.
//                  에셋이 아직 없으면 AddressableLoader 가 location 사전 체크에서 null 을
//                  반환하고 AudioManager 가 조용히 무시한다 → 무음으로 안전하게 동작.
// =================================================================

/// <summary>
/// 사운드 Addressable 키 모음. 새 BGM·효과음 추가 시 해당 그룹에 const 를 등록한다.
/// 재생은 AudioManager.PlayBgmAsync / PlaySfxAsync 로 수행.
/// </summary>
public static class AudioKeys
{
    /// <summary>배경음 키.</summary>
    public static class Bgm
    {
        public const string TITLE = "BGM_Title";

        public const string SHOP          = "BGM_Shop";
        public const string REST          = "BGM_Rest";

        /// <summary>Event 노드 BGM. 이벤트 진입 시 맵 BGM 위로 크로스페이드.</summary>
        public const string EVENT = "BGM_Event";

        /// <summary>
        /// 런 시작 전 선택 화면(덱 선택·시작 카드팩) 전용 BGM.
        /// 맵 진입 시 InGameController.PresentMapAsync 가 현재 StageDataSO의 맵 BGM으로 크로스페이드한다.
        /// </summary>
        // [추정 구현] 실제 Addressable 주소가 다르면 교체 필요
        public const string CARD_PACK = "BGM_CardPack";

        /// <summary>
        /// 전투 승리 후 전리품(보상) 창 BGM. 전투 BGM 위로 크로스페이드하고,
        /// 보상 수령 후 맵 진입 시 PresentMapAsync 가 현재 StageDataSO의 맵 BGM으로 크로스페이드한다.
        /// </summary>
        // [추정 구현] 실제 Addressable 주소가 다르면 교체 필요
        public const string REWARD = "BGM_Reward";

        /// <summary>엔딩 크레딧 BGM (게임 클리어).</summary>
        public const string ENDING = "BGM_Ending";

        /// <summary>
        /// 타이틀 메뉴의 크레딧 스크롤 화면 BGM. 게임 클리어 연출용인 ENDING 과는 별개다.
        /// 크레딧 창을 닫으면 타이틀 BGM 으로 되돌아온다.
        /// </summary>
        public const string CREDIT = "BGM_Credit";
    }

    /// <summary>
    /// 상황별 BGM 볼륨(AudioSource 볼륨 0~1). 맵·전투·전리품이 스테이지별로 같은 곡을
    /// 공유하고 볼륨으로만 상황을 구분하므로, 세 값의 상대 관계가 곧 연출이다 → 함께 조율한다.
    /// 유저 설정(AudioMixer 의 BgmVolume)과 곱해지므로 여기 값은 상대적 크기만 담당한다.
    /// </summary>
    public static class BgmVolume
    {
        /// <summary>전투 중. 가장 크게 — 나머지 값의 기준.</summary>
        public const float BATTLE = 1f;

        /// <summary>맵(노드 선택) 화면. 같은 곡이 배경으로 깔리도록 낮춘다.</summary>
        public const float MAP = 0.4f;

        /// <summary>전리품(보상) 창. 맵보다 한 단계 더 낮춰 정적인 분위기를 만든다.</summary>
        public const float REWARD = 0.4f;
    }

    /// <summary>카드 관련 효과음 키.</summary>
    public static class Card
    {
        public const string CANNOT_LOCATE = "SFX_CannotLocate";
        public const string HOVER   = "SFX_CardHover";
        public const string DRAW    = "SFX_CardDraw";    // 핸드로 드로우
        public const string DISCARD = "SFX_CardDiscard"; // 핸드 → 묘지
        public const string RESHUFFLE = "SFX_CardReshuffle"; // 묘지 → 덱 셔플
        public const string SELECT  = "SFX_CardSelect";  // 카드 선택/상세 보기
        public const string PLACE   = SELECT;             // 그리드 배치(선택음 재사용)
        public const string BUY     = Ui.BUTTON;          // 상점 구매
        public const string REWARD  = "SFX_RewardSelect";// 보상 카드 선택
        public const string REMOVE  = Ui.FAILURE;         // 덱에서 제거
    }

    /// <summary>게임 진행 효과음 키.</summary>
    public static class Game
    {
        public const string GOLD_GAIN = "SFX_GoldGain";
        public const string GOLD_SPEND = "SFX_GoldSpend";
        public const string REST_HEAL = Ui.SUCCESS; // 휴식 회복
        public const string DEFEAT    = Ui.FAILURE; // 게임 패배
        public const string CLEAR     = Ui.SUCCESS; // 게임 클리어
    }

    /// <summary>전투 조작·피드백 효과음 키.</summary>
    public static class Battle
    {
        public const string CHAIN_LASER = "SFX_ChainLaser";
        public const string TURN_END = "SFX_TurnEnd";
        public const string PRESERVE_SELECT = "SFX_PreserveSelect";
        public const string PRESERVE_CONFIRM = "SFX_PreserveConfirm";
        public const string PLAYER_BLOCK = "SFX_PlayerBlock";
        public const string PLAYER_HIT = "SFX_PlayerHit";

        /// <summary>적 사망(처치) 효과음. 적 사망 소멸 연출 시작 시 재생.</summary>
        // [추정 구현] 실제 Addressable 주소가 다르면 교체 필요
        public const string ENEMY_DEATH = "SFX_EnemyDeath";
    }

    /// <summary>플레이어 스킬 효과음 키.</summary>
    public static class Skill
    {
        public const string USE = "SFX_SkillUse";
    }

    /// <summary>이벤트 선택·결과 효과음 키.</summary>
    public static class Event
    {
        public const string CHOICE = "SFX_EventChoice";
        public const string RESULT = "SFX_EventResult";
    }

    /// <summary>UI 효과음 키.</summary>
    public static class Ui
    {
        /// <summary>볼륨 슬라이더 조절 미리듣기.</summary>
        public const string SLIDER = BUTTON;
        public const string BUTTON = "SFX_UiButton";
        public const string CARD_PACK_OPEN = "SFX_CardPackOpen";
        public const string SUCCESS = "SFX_Success";
        public const string FAILURE = "SFX_Failure";
    }

    public static class Title
    {
        public const string CARD_HOVER = "SFX_TitleCardHover";
        public const string CARD_ACTIVATE = "SFX_TitleCardActivate";
        public const string CLICK = "SFX_TitleClick";
    }
}
