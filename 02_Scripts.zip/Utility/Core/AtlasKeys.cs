// =================================================================
// [스크립트 목적]  SpriteAtlas 내부 스프라이트 키 중앙 레지스트리
// [원칙]           - 아틀라스 단위로 그룹핑 (Common / Card ...)
//                  - 매직 스트링 제거: 아틀라스 스프라이트명은 반드시 여기 등록
//                  - 키↔매핑 분리: enum→키 매핑 로직은 여기 두지 않음(확장메서드 담당)
// [주의]           키 문자열은 실제 아틀라스에 등록된 스프라이트명과 일치해야 함
// =================================================================

/// <summary>
/// 아틀라스별 스프라이트 키 모음. 아틀라스 이름(에셋 키)은 ResourceManager 상수 참고.
/// 새 아이콘 추가 시 해당 아틀라스 그룹에 const 를 등록한다.
/// </summary>
public static class AtlasKeys
{
    // ── 아틀라스 에셋 키 (SpriteAtlas 로드용 Addressables/Resources 키) ──
    public const string CARD   = "CardAtlas";
    public const string COMMON = "CommonAtlas";

    /// <summary>CommonAtlas(공통 UI) 스프라이트 키</summary>
    public static class Common
    {
        // 스탯/행동효과 아이콘
        // [추정 구현] 실제 CommonAtlas 스프라이트명으로 교체 필요
        public const string ICON_ATTACK = "icon_attack";
        public const string ICON_BLOCK  = "icon_block";
        public const string ICON_HEAL   = "icon_heal";
        public const string ICON_DRAW   = "icon_draw";
        public const string ICON_ENERGY = "icon_energy";

        // [추후 추가] 캐스팅 아이콘. 스프라이트 준비 후 GridSlot 의 _useCastingIcon 체크로 활성화
        public const string ICON_CASTING = "icon_casting";
    }
}
