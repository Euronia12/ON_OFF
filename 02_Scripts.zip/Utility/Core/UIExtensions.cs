﻿// =================================================================
// [스크립트 목적]  UGUI 위젯 세팅용 확장 메서드. null 가드 + WithoutNotify 일원화
// [원칙]           - 위젯 값 변경(부수효과)이라 범용 Extensions와 분리 (성격 구분)
//                  - onValueChanged 발동 없이 값만 세팅 (UI 초기화 시 역호출 방지)
// [사용]           _slider.SetValueSafe(0.8f) / _toggle.SetIsOnSafe(true) 등
// =================================================================
using TMPro;
using UnityEngine.UI;

public static class UIExtensions
{
    /// <summary>슬라이더 값을 알림 없이 세팅. null이면 무시.</summary>
    public static void SetValueSafe(this Slider slider, float value)
    {
        if (slider != null) slider.SetValueWithoutNotify(value);
    }

    /// <summary>토글 값을 알림 없이 세팅. null이면 무시.</summary>
    public static void SetIsOnSafe(this Toggle toggle, bool on)
    {
        if (toggle != null) toggle.SetIsOnWithoutNotify(on);
    }

    /// <summary>드롭다운 인덱스를 알림 없이 세팅. 범위 밖이면 0으로 보정, null이면 무시.</summary>
    public static void SetValueSafe(this TMP_Dropdown dropdown, int index)
    {
        if (dropdown == null) return;
        if (index < 0 || index >= dropdown.options.Count) index = 0;
        dropdown.SetValueWithoutNotify(index);
    }

    /// <summary>스테퍼 인덱스를 알림 없이 세팅. null이면 무시.</summary>
    public static void SetIndexSafe(this UIStepper stepper, int index)
    {
        if (stepper != null) stepper.SetIndexWithoutNotify(index);
    }
}
