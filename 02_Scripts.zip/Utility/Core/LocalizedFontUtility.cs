using System.Collections.Generic;
using TMPro;
using UnityEngine;

public static class LocalizedFontUtility
{
    private static readonly List<TMP_Text> TextBuffer = new();

    public static TMP_FontAsset CurrentFont =>
        LocalizationManager.HasInstance ? LocalizationManager.Instance.GetCurrentFont() : null;

    public static void ApplyCurrentFont(TMP_Text text)
    {
        ApplyFont(text, CurrentFont);
    }

    public static void ApplyFont(TMP_Text text, TMP_FontAsset font)
    {
        if (text == null || font == null || text.font == font) return;
        text.font = font;
    }

    public static void ApplyCurrentFont(TMP_Dropdown dropdown)
    {
        if (dropdown == null) return;

        TMP_FontAsset font = CurrentFont;
        ApplyFont(dropdown.captionText, font);
        ApplyFont(dropdown.itemText, font);
        ApplyCurrentFont(dropdown.transform);
    }

    public static void ApplyCurrentFont(Transform root)
    {
        TMP_FontAsset font = CurrentFont;
        if (root == null || font == null) return;

        TextBuffer.Clear();
        root.GetComponentsInChildren(includeInactive: true, TextBuffer);
        for (int i = 0; i < TextBuffer.Count; i++)
            ApplyFont(TextBuffer[i], font);
        TextBuffer.Clear();
    }

    public static void ApplyCurrentFont(Component root)
    {
        if (root == null) return;
        ApplyCurrentFont(root.transform);
    }
}
