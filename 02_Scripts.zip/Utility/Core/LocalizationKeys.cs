public static class LocalizationKeys
{
    public static class Common
    {
        public const string Confirm = "UI_COMMON_CONFIRM";
        public const string Next = "UI_COMMON_NEXT";
        public const string Prev = "UI_COMMON_PREV";
        public const string Cancel = "UI_COMMON_CANCEL";
        public const string Yes = "UI_COMMON_YES";
        public const string No = "UI_COMMON_NO";
        public const string Back = "UI_COMMON_BACK";
        public const string PrivacyPolicy = "UI_PRIVACY_POLICY";
        public const string PrivacyConsentToggle = "UI_PRIVACY_CONSENT_TOGGLE";
        public const string PrivacyPolicyDetails = "UI_PRIVACY_POLICY_DETAILS";
        public const string PrivacyPolicyInvalidUrl = "UI_PRIVACY_POLICY_INVALID_URL";
        public const string FloorFormat = "UI_COMMON_FLOOR_FORMAT";
    }

    public static class Battle
    {
        public const string PreserveLimitExceeded = "UI_PRESERVE_LIMIT_EXCEEDED";
        public const string PreserveSelectFormat = "UI_BATTLE_PRESERVE_SELECT_FORMAT";
        public const string NoDrawableCard = "UI_BATTLE_NO_DRAWABLE_CARD";
        public const string DrawPile = "UI_BATTLE_DRAW_PILE";
        public const string DiscardPile = "UI_BATTLE_DISCARD_PILE";
        public const string EndTurn = "UI_BATTLE_END_TURN";
        public const string PreserveConfirm = "UI_BATTLE_PRESERVE_CONFIRM";
        public const string EnemyIntent = "UI_BATTLE_ENEMY_INTENT";
        public const string PlayerEraseInfoDebuffDesc = "PLAYER_DEBUFF_ERASE_INFO_DESC";
        public const string CorruptedSoulBuffName = "BOSS_BUFF_CORRUPTED_SOUL_NAME";
        public const string CorruptedSoulBuffDesc = "BOSS_BUFF_CORRUPTED_SOUL_DESC";
    }

    public static class Skill
    {
        public const string MultiGuide = "UI_SKILL_MULTI_GUIDE";
        public const string Cooldown = "UI_SKILL_COOLDOWN";
        public const string TooltipCooldownFormat = "UI_SKILL_TOOLTIP_COOLDOWN_FORMAT";
    }

    public static class Reward
    {
        public const string CardAdd = "UI_REWARD_CARD_ADD";
        public const string GridExpansion = "UI_REWARD_GRID_EXPANSION";
        public const string GridExpansionNotice = "UI_REWARD_GRID_EXPANSION_NOTICE";
        public const string PopupTitle = "UI_REWARD_POPUP_TITLE";
        public const string ClaimAll = "UI_REWARD_CLAIM_ALL";
    }

    public static class CardSelect
    {
        public const string Title = "UI_CARD_SELECT_TITLE";
        public const string Skip = "UI_CARD_SELECT_SKIP";
    }

    public static class DeckPicker
    {
        public const string DefaultConfirm = "UI_DECK_PICKER_DEFAULT_CONFIRM";
        public const string ViewTitle = "UI_DECK_VIEW_TITLE";
    }

    public static class Rest
    {
        public const string HealFormat = "UI_REST_HEAL_FORMAT";
        public const string Title = "UI_REST_TITLE";
        public const string SelectPrompt = "UI_REST_SELECT_PROMPT";
        public const string HpLabel = "UI_REST_HP_LABEL";
        public const string HealLabel = "UI_REST_HEAL_LABEL";
        public const string RestButton = "UI_REST_REST_BUTTON";
        public const string ReinforceButton = "UI_REST_REINFORCE_BUTTON";
        public const string LeaveButton = "UI_REST_LEAVE_BUTTON";
    }

    public static class Shop
    {
        public const string Title = "UI_MAP_NODE_SHOP";
        public const string RemoveCostFormat = "UI_SHOP_REMOVE_COST_FORMAT";
        public const string LeaveButton = "UI_SHOP_LEAVE_BUTTON";
        public const string RemovePickerTitle = "UI_SHOP_REMOVE_PICKER_TITLE";
        public const string RemovePickerConfirm = "UI_SHOP_REMOVE_PICKER_CONFIRM";
        public const string RemoveFailed = "UI_SHOP_REMOVE_FAILED";
        public const string NotEnoughGold = "UI_SHOP_NOT_ENOUGH_GOLD";
    }

    public static class Option
    {
        public const string SaveConfirmTitle = "OPTION_SAVE_CONFIRM_TITLE";
        public const string SaveConfirmDesc = "OPTION_SAVE_CONFIRM_DESC";
        public const string Save = "OPTION_SAVE";
        public const string ResetConfirmTitle = "OPTION_RESET_CONFIRM_TITLE";
        public const string ResetConfirmDesc = "OPTION_RESET_CONFIRM_DESC";
        public const string Reset = "OPTION_RESET";
        public const string Cancel = "UI_COMMON_CANCEL";
        public const string Confirm = "UI_COMMON_CONFIRM";
        public const string CloseDiscardTitle = "OPTION_CLOSE_DISCARD_TITLE";
        public const string CloseDiscardDesc = "OPTION_CLOSE_DISCARD_DESC";
        public const string GraphicsTab = "Graphics";
        public const string GameplayTab = "GamePlay";
        public const string SoundTab = "Audio";
        public const string ResetToDefault = "ResetToDeafultValue";
        public const string MasterVolume = "OPTION_MASTER_VOLUME";
        public const string BgmVolume = "OPTION_BGM_VOLUME";
        public const string SfxVolume = "OPTION_SFX_VOLUME";
        public const string UiVolume = "OPTION_UI_VOLUME";
        public const string BackgroundSound = "OPTION_BACKGROUND_SOUND";
        public const string FrameRate = "OPTION_FRAME_RATE";
        public const string Brightness = "OPTION_BRIGHTNESS";
        public const string Vsync = "OPTION_VSYNC";
        public const string Resolution = "OPTION_RESOLUTION";
        public const string ScreenMode = "OPTION_SCREEN_MODE";
        public const string Apply = "UI_SCREEN_CONFIRM_APPLY";
        public const string FastMode = "OPTION_FAST_MODE";
        public const string TextEffect = "OPTION_TEXT_EFFECT";
        public const string ScreenShake = "OPTION_SCREEN_SHAKE";
        public const string Language = "OPTION_LANGUAGE";
        public const string Frame30 = "OPTION_FRAME_30";
        public const string Frame60 = "OPTION_FRAME_60";
        public const string Frame120 = "OPTION_FRAME_120";
        public const string ScreenModeFullscreenWindow = "OPTION_SCREEN_MODE_FULLSCREEN_WINDOW";
        public const string ScreenModeFullscreen = "OPTION_SCREEN_MODE_FULLSCREEN";
        public const string ScreenModeWindowed = "OPTION_SCREEN_MODE_WINDOWED";
        public const string LanguageKorean = "OPTION_LANGUAGE_KOREAN";
        public const string LanguageEnglish = "OPTION_LANGUAGE_ENGLISH";
        public const string LanguageChineseSimplified = "OPTION_LANGUAGE_CHS";
        public const string LanguageChineseTraditional = "OPTION_LANGUAGE_CHT";
        public const string LanguageJapanese = "OPTION_LANGUAGE_JAPANESE";
        public const string LanguageGerman = "OPTION_LANGUAGE_GERMAN";
        public const string ScreenConfirmTitle = "UI_SCREEN_CONFIRM_TITLE";
        public const string ScreenConfirmDesc = "UI_SCREEN_CONFIRM_DESC";
        public const string ScreenConfirmApply = "UI_SCREEN_CONFIRM_APPLY";
        public const string ScreenConfirmDescWithSeconds = "UI_SCREEN_CONFIRM_DESC_WITH_SECONDS";
    }

    public static class Title
    {
        public const string CardPlaceGuide = "TITLE_CARD_PLACE_GUIDE";
        public const string FirstStarStartButton = "UI_FIRST_STAR_START_BUTTON";
        public const string Option = "TITLE_MENU_OPTION";
        public const string Credit = "TITLE_MENU_CREDIT";
        public const string Quit = "TITLE_MENU_QUIT";
        public const string Tutorial = "TITLE_MENU_TUTORIAL";
        public const string Collection = "TITLE_MENU_COLLECTION";
        public const string Continue = "TITLE_MENU_CONTINUE";
    }

    public static class Collection
    {
        public const string Title = "UI_COLLECTION_TITLE";
        public const string ReverseSort = "UI_COLLECTION_REVERSE_SORT";
    }

    public static class StartCardPack
    {
        public const string PickupDescription = "UI_START_CARD_PACK_PICKUP_DESC";
        public const string SkipOpeningAnimation = "UI_START_CARD_PACK_SKIP_OPENING_ANIMATION";
        public const string ContentsTitle = "UI_START_CARD_PACK_CONTENTS_TITLE";
    }

    public static class Map
    {
        public const string LegendTitle = "UI_MAP_LEGEND_TITLE";
    }

    public static class StageNotice
    {
        public const string CurrentStageFormat = "UI_STAGE_NOTICE_CURRENT_STAGE";
        public const string ClearedStageFormat = "UI_STAGE_NOTICE_CLEARED_STAGE";
        public const string TutorialTitle = "UI_STAGE_NOTICE_TUTORIAL";
    }

    public static class GameClear
    {
        public const string Title = "UI_GAME_CLEAR_TITLE";
        public const string SkipLoop = "UI_GAME_CLEAR_SKIP_LOOP";
        public const string StatsPlayTime = "UI_RUN_STATS_PLAY_TIME";
        public const string StatsPlayTimeFormat = "UI_RUN_STATS_PLAY_TIME_FORMAT";
        public const string StatsBattleRecord = "UI_RUN_STATS_BATTLE_RECORD";
        public const string StatsBattleRecordFormat = "UI_RUN_STATS_BATTLE_RECORD_FORMAT";
        public const string StatsBattleEfficiency = "UI_RUN_STATS_BATTLE_EFFICIENCY";
        public const string StatsBattleEfficiencyFormat = "UI_RUN_STATS_BATTLE_EFFICIENCY_FORMAT";
        public const string StatsDamageTaken = "UI_RUN_STATS_DAMAGE_TAKEN";
        public const string StatsCardUsage = "UI_RUN_STATS_CARD_USAGE";
        public const string StatsCardUsageFormat = "UI_RUN_STATS_CARD_USAGE_FORMAT";
        public const string StatsMaxChainLoops = "UI_RUN_STATS_MAX_CHAIN_LOOPS";
        public const string StatsMaxChainLoopsFormat = "UI_RUN_STATS_MAX_CHAIN_LOOPS_FORMAT";
        public const string StatsFinalDeck = "UI_RUN_STATS_FINAL_DECK";
        public const string StatsFinalDeckFormat = "UI_RUN_STATS_FINAL_DECK_FORMAT";
        public const string StatsTopCard = "UI_RUN_STATS_TOP_CARD";
        public const string DeckViewButton = "UI_RUN_STATS_DECK_VIEW";
        public const string DeckViewerTitle = "UI_RUN_STATS_DECK_TITLE";
    }

    public static class GameOver
    {
        public const string Title = "UI_GAME_OVER_TITLE";
    }

    public static class EscMenu
    {
        public const string Title = "UI_ESC_MENU_TITLE";
        public const string Continue = "UI_ESC_MENU_CONTINUE";
        public const string TitleScreen = "UI_ESC_MENU_TITLE_SCREEN";
        public const string Options = "UI_ESC_MENU_OPTIONS";
        public const string Collection = "UI_ESC_MENU_COLLECTION";
    }

    public static class Run
    {
        public const string NewGameConfirmTitle = "RUN_NEW_GAME_CONFIRM_TITLE";
        public const string NewGameConfirmDesc = "RUN_NEW_GAME_CONFIRM_DESC";
        public const string ResetTitle = "RUN_RESET_TITLE";
        public const string ResetMapDesc = "RUN_RESET_MAP_DESC";
        public const string ResetCorruptDesc = "RUN_RESET_CORRUPT_DESC";
        public const string DifficultySelectTitle = "RUN_DIFFICULTY_SELECT_TITLE";
        public const string DifficultyNormal = "RUN_DIFFICULTY_NORMAL";
        public const string DifficultyHard = "RUN_DIFFICULTY_HARD";
        public const string DifficultyHell = "RUN_DIFFICULTY_HELL";
        public const string DifficultyNormalDescription = "RUN_DIFFICULTY_NORMAL_DESC";
        public const string DifficultyHardDescription = "RUN_DIFFICULTY_HARD_DESC";
        public const string DifficultyHellDescription = "RUN_DIFFICULTY_HELL_DESC";
    }
}
