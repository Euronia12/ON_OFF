﻿// =================================================================
// [스크립트 목적]  프레임워크 공용 상수 모음
// [원칙]           - 프레임워크 전반에서 공유하는 고정값만
//                  - 게임별 데이터(밸런스 수치 등)는 여기 두지 말 것 → ScriptableObject 사용
//                  - 매직 스트링/넘버 제거 목적
// =================================================================

public static class Constants
{
    /// <summary>경로 관련 상수</summary>
    public static class Paths
    {
        /// <summary>Bootstrap 프리팹 경로 (Resources 기준, 확장자 제외)</summary>
        public const string BOOTSTRAP_RESOURCE = "Bootstrap";
    }

    /// <summary>Addressable 관련 상수</summary>
    public static class Addressable
    {
        /// <summary>키 매핑 json들에 부여하는 라벨</summary>
        public const string MAP_LABEL = "addressableMap";

        /// <summary>매핑 json 파일 이름</summary>
        public const string MAP_FILE_NAME = "addressableMap.json";

        /// <summary>미리 로드 대상 판별용 폴더 이름</summary>
        public const string PRELOAD_FOLDER = "Preload";
    }

    /// <summary>UI 관련 상수</summary>
    public static class UI
    {
        /// <summary>UIRoot 인스턴스 이름</summary>
        public const string UI_ROOT_NAME = "[UIRoot]";

        /// <summary>페이드 패널 이름 (프리팹에서 찾을 때 사용)</summary>
        public const string FADE_PANEL_NAME = "FadePanel";

        /// <summary>Screen 레이어 GameObject 이름 접두사 (Layer_HUD 등)</summary>
        public const string LAYER_PREFIX = "Layer_";

        /// <summary>World 레이어 GameObject 이름 접두사 (WorldLayer_HUD 등)</summary>
        public const string WORLD_LAYER_PREFIX = "WorldLayer_";

        /// <summary>기본 페이드 시간 (초)</summary>
        public const float DEFAULT_FADE_DURATION = 0.3f;
    }

    /// <summary>저장 관련 상수</summary>
    public static class Save
    {
        /// <summary>기본 저장 파일 확장자</summary>
        public const string DEFAULT_EXTENSION = "sav";

        /// <summary>기본 저장 슬롯 이름</summary>
        public const string DEFAULT_SLOT = "default";
    }

    /// <summary>외부 웹페이지 링크</summary>
    public static class ExternalLinks
    {
        /// <summary>Steam에 게시한 개인정보 처리방침</summary>
        public const string PRIVACY_POLICY =
            "https://store.steampowered.com/news/app/4914570?emclan=103582791475720961&emgid=677379620165649975";
    }

    /// <summary>트윈 관련 상수 (DOTween SetId용 보호 id)</summary>
    public static class Tween
    {
        /// <summary>씬 전환 페이드 트윈 id. 이 id로 SetId한 트윈은 씬 정리 시 보호됨</summary>
        public const string ID_FADE = "tween_fade";

        /// <summary>BGM/오디오 페이드 트윈 id. 씬 정리 시 보호됨</summary>
        public const string ID_AUDIO = "tween_audio";

        /// <summary>씬을 넘나드는 영속 UI 연출 트윈 id (상시 스피너 등). 씬 정리 시 보호됨</summary>
        public const string ID_PERSISTENT = "tween_persistent";
    }

    /// <summary>오디오 관련 상수 (AudioMixer Exposed Parameter 기본 이름)</summary>
    public static class Audio
    {
        public const string MASTER_PARAM = "MasterVolume";
        public const string BGM_PARAM = "BgmVolume";
        public const string SFX_PARAM = "SfxVolume";
        public const string UI_PARAM = "UiVolume";

        /// <summary>볼륨 0일 때 적용할 dB (mute 처리용)</summary>
        public const float MUTE_DB = -80f;
    }
}
