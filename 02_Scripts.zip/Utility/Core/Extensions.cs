// =================================================================
// [스크립트 목적]  부수효과 없는 공용 확장 메서드 모음
// [원칙]           - 부수효과 없음 (값 반환 위주, 상태 변경은 명시적인 것만)
//                  - 매니저 호출 금지 (숨은 의존성 방지)
//                  - 게임 로직 금지 (범용 유틸만)
// [주의]           GC 민감 구간(Update 등)에서는 GetRandom/Shuffle 등
//                  내부 할당 여부를 확인하고 사용할 것
// =================================================================
using System.Collections.Generic;
using UnityEngine;

public static class Extensions
{
    // ─────────────────────────────────────────────
    // 컬렉션
    // ─────────────────────────────────────────────

    /// <summary>null이거나 비어있는지. (== null 체크 + Count 체크)</summary>
    public static bool IsNullOrEmpty<T>(this ICollection<T> collection)
        => collection == null || collection.Count == 0;

    /// <summary>리스트에서 무작위 요소 1개. 비어있으면 default 반환.</summary>
    public static T GetRandom<T>(this IList<T> list)
    {
        if (list == null || list.Count == 0) return default;
        return list[Random.Range(0, list.Count)];
    }

    /// <summary>리스트를 제자리에서 섞음 (Fisher-Yates). 원본을 변경함.</summary>
    public static void Shuffle<T>(this IList<T> list)
    {
        if (list == null) return;
        for (int i = list.Count - 1; i > 0; i--)
        {
            int j = Random.Range(0, i + 1);
            (list[i], list[j]) = (list[j], list[i]);
        }
    }

    /// <summary>딕셔너리에서 값 조회, 없으면 기본값 반환 (예외 없음).</summary>
    public static TValue GetValueOrDefault<TKey, TValue>(
        this IDictionary<TKey, TValue> dict, TKey key, TValue defaultValue = default)
        => dict != null && dict.TryGetValue(key, out var value) ? value : defaultValue;

    // ─────────────────────────────────────────────
    // Transform (명시적 상태 변경 — 이름에서 의도가 드러남)
    // ─────────────────────────────────────────────

    /// <summary>로컬 위치/회전/스케일 초기화.</summary>
    public static void ResetLocal(this Transform t)
    {
        t.localPosition = Vector3.zero;
        t.localRotation = Quaternion.identity;
        t.localScale = Vector3.one;
    }

    /// <summary>position의 X만 변경.</summary>
    public static void SetX(this Transform t, float x)
    {
        var p = t.position; p.x = x; t.position = p;
    }

    /// <summary>position의 Y만 변경.</summary>
    public static void SetY(this Transform t, float y)
    {
        var p = t.position; p.y = y; t.position = p;
    }

    /// <summary>position의 Z만 변경.</summary>
    public static void SetZ(this Transform t, float z)
    {
        var p = t.position; p.z = z; t.position = p;
    }

    /// <summary>모든 자식 GameObject 파괴 (즉시 아님, Destroy 예약).</summary>
    public static void DestroyChildren(this Transform t)
    {
        for (int i = t.childCount - 1; i >= 0; i--)
            Object.Destroy(t.GetChild(i).gameObject);
    }

    // ─────────────────────────────────────────────
    // 숫자 (값 반환, 부수효과 없음)
    // ─────────────────────────────────────────────

    /// <summary>값을 [inMin,inMax] 범위에서 [outMin,outMax] 범위로 선형 매핑.</summary>
    public static float Remap(this float value, float inMin, float inMax, float outMin, float outMax)
    {
        if (Mathf.Approximately(inMax, inMin)) return outMin;
        return outMin + (value - inMin) * (outMax - outMin) / (inMax - inMin);
    }

    /// <summary>거의 0인지 (부동소수 오차 허용).</summary>
    public static bool IsZero(this float value) => Mathf.Abs(value) < Mathf.Epsilon;

    // ─────────────────────────────────────────────
    // Vector (값 반환 — 원본 불변)
    // ─────────────────────────────────────────────

    public static Vector3 WithX(this Vector3 v, float x) => new(x, v.y, v.z);
    public static Vector3 WithY(this Vector3 v, float y) => new(v.x, y, v.z);
    public static Vector3 WithZ(this Vector3 v, float z) => new(v.x, v.y, z);

    public static Vector2 WithX(this Vector2 v, float x) => new(x, v.y);
    public static Vector2 WithY(this Vector2 v, float y) => new(v.x, y);

    /// <summary>Vector3 → Vector2 (XZ 평면, 탑다운 게임용).</summary>
    public static Vector2 ToXZ(this Vector3 v) => new(v.x, v.z);

    // ─────────────────────────────────────────────
    // Color (값 반환 — 원본 불변)
    // ─────────────────────────────────────────────

    /// <summary>알파만 바꾼 새 색 반환.</summary>
    public static Color WithAlpha(this Color c, float alpha) => new(c.r, c.g, c.b, alpha);
}
