// =================================================================
// [스크립트 목적]  쿨다운 게이지 Image 의 채움 비율 갱신을 한곳에서 처리한다.
//                  Fill 방식(Radial360·Clockwise·Origin)은 프리팹 인스펙터 설정을 그대로 따른다.
// [주요 변수]      - 없음 (static 유틸)
// [의존 관계]      - UIBattleSkillButton / UIBattleSkillSelectButton 이 Apply 호출
// =================================================================

using UnityEngine;
using UnityEngine.UI;

/// <summary>쿨다운 게이지 Image 공용 유틸. 비율 갱신만 담당하고 Image 설정은 건드리지 않는다.</summary>
public static class UICooldownFillUtility
{
    /// <summary>남은/최대 비율로 게이지 갱신. remaining 이 0 이거나 max 가 0 이면 숨긴다.</summary>
    public static void Apply(Image fill, int remaining, int max)
    {
        if (fill == null) return;

        bool visible = remaining > 0 && max > 0;
        fill.fillAmount = visible ? Mathf.Clamp01((float)remaining / max) : 0f;
        if (fill.enabled != visible)
            fill.enabled = visible;
    }
}
