// =================================================================
// [스크립트 목적]  키 리바인딩 오버라이드 JSON을 SaveManager로 저장하기 위한 래퍼
//                 Input System의 SaveBindingOverridesAsJson() 결과를 담는 그릇
// [주요 변수]      - _bindingOverridesJson : Input System이 뱉은 오버라이드 JSON 문자열
//                  - _version              : 저장 포맷 버전 (ISaveData)
// [의존 관계]      - ISaveData (SaveManager 저장 대상 표식)
// [주의]           [Serializable] 필수 (JsonUtility 직렬화). 필드는 직렬화 위해 노출
// =================================================================
using System;
using UnityEngine;

/// <summary>
/// 리바인딩 오버라이드 저장 데이터.
/// InputActionAsset.SaveBindingOverridesAsJson() 문자열을 보관.
/// SaveManager.SaveAsync/LoadAsync의 제네릭 제약(ISaveData)을 충족시키기 위한 래퍼.
/// </summary>
[Serializable]
public class InputRebindData : ISaveData
{
    // JsonUtility는 private 직렬화에 [SerializeField]가 필요.
    // 외부 접근은 프로퍼티로만 허용 (public field 금지 규칙 준수).
    [SerializeField] private int _version = 1;
    [SerializeField] private string _bindingOverridesJson;

    public int Version
    {
        get => _version;
        set => _version = value;
    }

    /// <summary>Input System 오버라이드 JSON. 비어있으면 오버라이드 없음(기본 바인딩).</summary>
    public string BindingOverridesJson
    {
        get => _bindingOverridesJson;
        set => _bindingOverridesJson = value;
    }
}
