// =================================================================
// [스크립트 목적]  InputAction 이름 상수 테이블. Magic String 제거용
//                 InputActionAsset의 Action 이름과 1:1 매핑 (코드 한 곳에서 관리)
// [주요 변수]      - Move/Look/Attack/... : 프레임워크 기본 액션명 상수
//                  - Cancel               : ESC/백버튼 통합 액션명 (UI 맵)
// [의존 관계]      - 없음 (순수 상수 클래스)
// [주의]           여기 값은 Input Actions 에셋의 Action 이름과 정확히 일치해야 함
//                  프로젝트에 액션 추가 시 이 클래스에 상수 한 줄만 추가하면 됨
// =================================================================

/// <summary>
/// InputAction 이름 상수 모음. 외부에서 GetAction(InputActionNames.Move) 형태로 사용.
/// 문자열을 코드에 직접 박지 않기 위한 단일 관리 지점.
/// 에셋의 Action 이름이 바뀌면 이 클래스만 수정하면 됨.
/// </summary>
public static class InputActionNames
{
    // ─────────────────────────────────────────────
    // Gameplay 맵 (프레임워크 기본 제공 — 프로젝트에 맞게 수정/추가)
    // ─────────────────────────────────────────────

    /// <summary>이동 (Vector2)</summary>
    public const string Move = "Move";

    /// <summary>시점/조준 (Vector2)</summary>
    public const string Look = "Look";

    /// <summary>점프 (Button)</summary>
    public const string Jump = "Jump";

    /// <summary>공격/주요 액션 (Button)</summary>
    public const string Attack = "Attack";

    /// <summary>상호작용 (Button)</summary>
    public const string Interact = "Interact";

    /// <summary>대시/달리기 (Button)</summary>
    public const string Dash = "Dash";

    // ─────────────────────────────────────────────
    // UI 맵 (메뉴 내비게이션)
    // ─────────────────────────────────────────────

    /// <summary>
    /// 취소/뒤로가기 (Button). ESC + 모바일 백버튼(Android) 통합.
    /// InputManager.OnEscapePressed 발행 트리거.
    /// </summary>
    public const string Cancel = "Cancel";

    /// <summary>확인/제출 (Button)</summary>
    public const string Submit = "Submit";

    /// <summary>
    /// 전체화면 ↔ 창모드 토글 (Button). Alt+Enter.
    /// InputManager.OnToggleFullScreenPressed 발행 트리거.
    /// 엔진 기본 토글(Allow Fullscreen Switch)을 끄고 게임이 직접 처리하기 위한 액션.
    /// </summary>
    public const string ToggleFullScreen = "ToggleFullScreen";

    /// <summary>메뉴 내비게이션 (Vector2)</summary>
    public const string Navigate = "Navigate";

    // ─────────────────────────────────────────────
    // TestCommand 맵 (Dev/Test 전용)
    // ─────────────────────────────────────────────

    /// <summary>전투 스킬 쿨다운 전체 초기화 (기본 F9).</summary>
    public const string ResetSkillCooldown = "ResetSkillCooldown";
    public const string AddGold = "AddGold";
    public const string OpenCardDebug = "OpenCardDebug";
    public const string RerollReward = "RerollReward";
    public const string KillEnemy = "KillEnemy";
    public const string RerollShop = "RerollShop";
    public const string OpenNodeDebug = "OpenNodeDebug";
    public const string OpenEventDebug = "OpenEventDebug";
    public const string OpenEnemyDebug = "OpenEnemyDebug";
    public const string GainMana = "GainMana";
    public const string DrawCard = "DrawCard";
    public const string MulliganHand = "MulliganHand";
    public const string FullHeal = "FullHeal";
    public const string DamagePlayer = "DamagePlayer";
    public const string OpenSeedDebug = "OpenSeedDebug";

    /// <summary>Steam 업적 전체 초기화 (Shift+8 또는 숫자패드 *).</summary>
    public const string ResetSteamAchievements = "ResetSteamAchievements";
}
