// =================================================================
// [스크립트 목적]  InputManager 구독 헬퍼의 IDisposable 구현 모음
//                 - InputActionSubscription : 구독 해제용 (Dispose 시 정확히 같은 핸들러 제거)
//                 - EmptyDisposable         : 구독 실패 시 반환할 no-op
// [의존 관계]      - Input System (InputAction.CallbackContext)
// [주의]           Dispose는 멱등 (여러 번 호출해도 안전)
// =================================================================
using System;
using UnityEngine.InputSystem;

/// <summary>
/// InputAction 콜백 구독을 추적하는 핸들. Dispose() 시 등록했던 정확한 핸들러를 해제.
/// InputManager.SubscribeXxx()가 반환. 외부는 OnDisable에서 Dispose() 호출 권장.
/// </summary>
public sealed class InputActionSubscription : IDisposable
{
    private InputAction _action;
    private readonly string _phase;
    private Action<InputAction.CallbackContext> _callback;
    private bool _disposed;

    public InputActionSubscription(InputAction action, string phase, Action<InputAction.CallbackContext> callback)
    {
        _action = action;
        _phase = phase;
        _callback = callback;
    }

    public void Dispose()
    {
        // 멱등성: 이미 해제됐거나 참조가 비면 무시
        if (_disposed || _action == null || _callback == null) return;
        _disposed = true;

        switch (_phase)
        {
            case nameof(InputAction.performed): _action.performed -= _callback; break;
            case nameof(InputAction.started):   _action.started   -= _callback; break;
            case nameof(InputAction.canceled):  _action.canceled  -= _callback; break;
        }

        _action = null;
        _callback = null;
    }
}

/// <summary>구독 실패 시 반환하는 no-op Disposable (null 반환 회피 → 호출부 NRE 방지).</summary>
public sealed class EmptyDisposable : IDisposable
{
    public static readonly EmptyDisposable Instance = new EmptyDisposable();
    private EmptyDisposable() { }
    public void Dispose() { }
}
