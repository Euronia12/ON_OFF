using DG.Tweening;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.Sprites;

[DisallowMultipleComponent]
[RequireComponent(typeof(SpriteRenderer))]
public sealed class SpriteMagicCircleReveal : MonoBehaviour
{
    private static readonly int ProgressId = Shader.PropertyToID("_Progress");
    private static readonly int StartAngleId = Shader.PropertyToID("_StartAngle");
    private static readonly int ClockwiseId = Shader.PropertyToID("_Clockwise");
    private static readonly int UvRectId = Shader.PropertyToID("_UvRect");

    [Header("재생 설정")]
    [SerializeField, Min(0.01f)] private float _duration = 1.2f;
    [SerializeField] private Ease _ease = Ease.Linear;
    [SerializeField] private bool _playOnEnable;
    [SerializeField] private bool _useUnscaledTime;
    [SerializeField, Range(0f, 1f)] private float _startProgress;
    [SerializeField, Range(0f, 1f)] private float _endProgress = 1f;

    [Header("완료 처리")]
    [SerializeField] private bool _disableRendererOnComplete;
    [SerializeField] private UnityEvent _onRevealCompleted = new UnityEvent();
    [SerializeField] private UnityEvent _onReverseCompleted = new UnityEvent();

    private SpriteRenderer _spriteRenderer;
    private MaterialPropertyBlock _propertyBlock;
    private Sprite _cachedSprite;
    private Vector4 _spriteUvRect = new Vector4(0f, 0f, 1f, 1f);
    private Tween _tween;
    private float _currentProgress;
    private bool _initialized;
    private bool _warningLogged;

    private void Awake()
    {
        _currentProgress = Mathf.Clamp01(_startProgress);
        SetProgress(_currentProgress);
    }

    private void OnEnable()
    {
        if (_playOnEnable)
            Play();
        else
            SetProgress(_currentProgress);
    }

    public void Play()
    {
        if (!TryInitialize()) return;

        Kill();
        _spriteRenderer.enabled = true;
        SetProgress(_startProgress);
        PlayTo(_endProgress, _duration, _onRevealCompleted);
    }

    public void PlayReverse()
    {
        PlayReverse(_duration);
    }

    public void PlayReverse(float duration)
    {
        if (!TryInitialize()) return;

        Kill();
        _spriteRenderer.enabled = true;
        if (_currentProgress <= 0f)
            SetProgress(1f);
        PlayTo(0f, duration, _onReverseCompleted);
    }

    public void ResetReveal()
    {
        Kill();
        SetProgress(0f);
    }

    public void CompleteImmediately()
    {
        Kill();
        SetProgress(1f);
    }

    public void SetProgress(float progress)
    {
        _currentProgress = Mathf.Clamp01(progress);
        if (!TryInitialize()) return;

        _spriteRenderer.GetPropertyBlock(_propertyBlock);
        _propertyBlock.SetFloat(ProgressId, _currentProgress);
        ApplySpriteUvRect();
        _spriteRenderer.SetPropertyBlock(_propertyBlock);
    }

    public Tween TweenProgress(float progress, float duration)
    {
        if (!TryInitialize()) return null;

        float targetProgress = Mathf.Clamp01(progress);
        Kill();
        if (Mathf.Approximately(_currentProgress, targetProgress))
        {
            SetProgress(targetProgress);
            return null;
        }

        _spriteRenderer.enabled = true;
        return StartTween(targetProgress, duration);
    }

    public void SetStartAngle(float angle)
    {
        SetProperty(StartAngleId, Mathf.Repeat(angle, 360f));
    }

    public void SetClockwise(bool clockwise)
    {
        SetProperty(ClockwiseId, clockwise ? 1f : 0f);
    }

    public void Pause()
    {
        _tween?.Pause();
    }

    public void Resume()
    {
        _tween?.Play();
    }

    public void Kill()
    {
        Tween tween = _tween;
        _tween = null;
        tween?.Kill();
    }

    private void PlayTo(float targetProgress, float duration, UnityEvent completed)
    {
        Tween tween = StartTween(targetProgress, duration);
        tween.OnComplete(() =>
        {
            if (_disableRendererOnComplete)
                _spriteRenderer.enabled = false;
            completed?.Invoke();
        });
    }

    private Tween StartTween(float targetProgress, float duration)
    {
        Tween tween = DOTween.To(
                () => _currentProgress,
                SetProgress,
                Mathf.Clamp01(targetProgress),
                Mathf.Max(0.01f, duration))
            .SetEase(_ease)
            .SetUpdate(_useUnscaledTime)
            .SetLink(gameObject, LinkBehaviour.KillOnDestroy)
            .SetRecyclable(false);

        _tween = tween;
        tween.OnKill(() =>
        {
            if (ReferenceEquals(_tween, tween))
            {
                _tween = null;
            }
        });
        return tween;
    }

    private void SetProperty(int propertyId, float value)
    {
        if (!TryInitialize()) return;

        _spriteRenderer.GetPropertyBlock(_propertyBlock);
        _propertyBlock.SetFloat(propertyId, value);
        _spriteRenderer.SetPropertyBlock(_propertyBlock);
    }

    private void ApplySpriteUvRect()
    {
        Sprite sprite = _spriteRenderer.sprite;
        if (sprite != _cachedSprite)
        {
            _cachedSprite = sprite;
            _spriteUvRect = sprite != null
                ? DataUtility.GetOuterUV(sprite)
                : new Vector4(0f, 0f, 1f, 1f);
        }

        _propertyBlock.SetVector(UvRectId, _spriteUvRect);
    }

    private bool TryInitialize()
    {
        if (_initialized) return true;

        _spriteRenderer = GetComponent<SpriteRenderer>();
        Material material = _spriteRenderer != null ? _spriteRenderer.sharedMaterial : null;
        if (_spriteRenderer == null || material == null || !material.HasProperty(ProgressId))
        {
            if (!_warningLogged)
            {
                Debug.LogWarning(
                    $"{nameof(SpriteMagicCircleReveal)}: _Progress 프로퍼티가 있는 머티리얼과 SpriteRenderer가 필요합니다.",
                    this);
                _warningLogged = true;
            }

            return false;
        }

        _propertyBlock = new MaterialPropertyBlock();
        _initialized = true;
        return true;
    }

    private void OnDisable()
    {
        Kill();
    }

    private void OnDestroy()
    {
        Kill();
    }

    private void Reset()
    {
        _spriteRenderer = GetComponent<SpriteRenderer>();
        _duration = 1.2f;
        _ease = Ease.Linear;
        _startProgress = 0f;
        _endProgress = 1f;
    }

    private void OnValidate()
    {
        _duration = Mathf.Max(0.01f, _duration);
        _startProgress = Mathf.Clamp01(_startProgress);
        _endProgress = Mathf.Clamp01(_endProgress);
    }
}
