﻿// =================================================================
// [스크립트 목적]  Orthographic 카메라의 종횡비 보정. 종횡비가 바뀌어도
//                 "가로로 보이는 월드 범위"를 항상 일정하게 고정한다.
//                 → 화면 가장자리의 캐릭터·UI(HP·적의도)가 종횡비 변화에 안 어긋난다.
//                 지원 범위(16:9~16:10)를 벗어난 화면은 카메라 viewport를 줄여 남는 영역을 검게 둔다.
// [주요 변수]      - _camera           : 보정 대상 Orthographic 카메라
//                  - _baseOrthoSize     : 기준 종횡비에서의 직교 사이즈 (1920x1080 기준 6)
//                  - _referenceResolution : 기준 종횡비 산출용 (1920x1080)
// [의존 관계]      - 없음 (메인 카메라에 직접 부착). CameraManager 셰이크와 충돌 없음
//                    (이 컴포넌트는 orthographicSize 만, 셰이크는 transform.localPosition 만 조작).
// [배치]           메인 카메라(Orthographic, MainCamera 태그) 오브젝트에 부착.
// [원리]
//   직교 카메라의 orthographicSize 는 "세로 절반 높이"만 정의하고 가로는 종횡비에 종속된다.
//   따라서 종횡비가 좁아지면(세로가 길어지면) 같은 size 에서 가로 범위가 줄어 가장자리가 밀린다.
//   기준 대비 (refAspect / curAspect) 만큼 size 를 키우면 가로 범위가 항상 일정해진다.
//     orthographicSize = baseOrthoSize × (refAspect / curAspect)
//   CanvasScaler matchWidthOrHeight=0(가로 기준)과 축이 일치 → UI·월드가 함께 정합된다.
// [주의]
//   가로 기준 고정이라 극단적으로 세로가 긴 종횡비에서는 세로 콘텐츠가 잘릴 수 있다.
//   (16:9 ~ 16:10 범위는 문제없음. 본 프로젝트 요구 범위)
// =================================================================

using UnityEngine;

/// <summary>
/// 직교 카메라의 가로 화각을 종횡비와 무관하게 고정한다(가로 기준 고정).
/// 해상도/종횡비가 런타임에 바뀌어도(창 리사이즈·해상도 설정) 매 변화 시 자동 재보정한다.
/// </summary>
[RequireComponent(typeof(Camera))]
[DisallowMultipleComponent]
public sealed class CameraAspectController : MonoBehaviour
{
    [Header("대상 카메라")]
    [Tooltip("보정할 Orthographic 카메라. 비우면 같은 오브젝트의 Camera 사용")]
    [SerializeField] private Camera _camera;

    [Header("기준 설정")]
    [Tooltip("기준 종횡비에서의 직교 사이즈(세로 절반 높이).\n" +
             "1920x1080 화면에서 의도한 구도가 나오는 값. 현재 프로젝트 기준 6")]
    [Min(0.01f)]
    [SerializeField] private float _baseOrthoSize = 6f;

    [Tooltip("기준 종횡비 산출용 해상도. 이 비율(1920:1080=16:9)을 기준으로 가로 범위를 고정")]
    [SerializeField] private Vector2 _referenceResolution = new Vector2(1920f, 1080f);

    [Header("지원 종횡비")]
    [Tooltip("가장 좁은 지원 비율. 16:10")]
    [SerializeField] private float _minSupportedAspect = 16f / 10f;
    [Tooltip("가장 넓은 지원 비율. 16:9")]
    [SerializeField] private float _maxSupportedAspect = 16f / 9f;

    // 마지막으로 보정한 화면 크기 (변화 감지용 — 변화 없으면 재계산 스킵).
    private int _lastWidth;
    private int _lastHeight;

    // 기준 종횡비 캐시 (가로/세로). Awake 에서 1회 산출.
    private float _referenceAspect;

    private void Awake()
    {
        if (_camera == null) _camera = GetComponent<Camera>();

        _referenceAspect = _referenceResolution.y > 0f
            ? _referenceResolution.x / _referenceResolution.y
            : 16f / 9f;
    }

    private void OnEnable()
    {
        // 활성화 즉시 1회 강제 적용 (변화 감지 전 초기 정합).
        ForceApply();
    }

    private void LateUpdate()
    {
        // 화면 크기 변화가 있을 때만 재보정 (매 프레임 int 비교 → 비용·GC Zero).
        if (Screen.width == _lastWidth && Screen.height == _lastHeight) return;
        ForceApply();
    }

    /// <summary>현재 화면 종횡비에 맞춰 즉시 보정 (외부에서 해상도 변경 직후 호출도 가능).</summary>
    public void ForceApply()
    {
        if (_camera == null) return;

        _lastWidth = Screen.width;
        _lastHeight = Screen.height;

        if (_lastHeight <= 0) return; // 0 나눗셈 방지 (최소화 등 비정상 상태).

        float currentAspect = (float)_lastWidth / _lastHeight;
        if (currentAspect <= 0f) return;

        float targetAspect = Mathf.Clamp(currentAspect, _minSupportedAspect, _maxSupportedAspect);
        ApplyLetterbox(currentAspect, targetAspect);

        // 가로 기준 고정: 기준보다 종횡비가 좁아지면(세로가 길면) size 를 키워 가로 범위 유지.
        _camera.orthographicSize = _baseOrthoSize * (_referenceAspect / targetAspect);
    }

    private void ApplyLetterbox(float currentAspect, float targetAspect)
    {
        _camera.backgroundColor = Color.black;

        if (Mathf.Approximately(currentAspect, targetAspect))
        {
            _camera.rect = new Rect(0f, 0f, 1f, 1f);
            return;
        }

        if (currentAspect > targetAspect)
        {
            float width = targetAspect / currentAspect;
            _camera.rect = new Rect((1f - width) * 0.5f, 0f, width, 1f);
            return;
        }

        float height = currentAspect / targetAspect;
        _camera.rect = new Rect(0f, (1f - height) * 0.5f, 1f, height);
    }

#if UNITY_EDITOR
    // 에디터에서 값 조정 시 즉시 반영 (게임뷰 종횡비 바꿔가며 확인 편의).
    private void OnValidate()
    {
        if (_camera == null) _camera = GetComponent<Camera>();
        if (_referenceResolution.y > 0f)
            _referenceAspect = _referenceResolution.x / _referenceResolution.y;
        if (Application.isPlaying) ForceApply();
    }
#endif
}
