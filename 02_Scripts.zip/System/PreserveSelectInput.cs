// =================================================================
// [스크립트 목적]  보존(Retain) 페이즈에서 그리드 카드를 좌클릭해 보존 선택/해제한다.
//                 그리드는 UI 가 아니라 월드 콜라이더라 OnPointerClick 이 오지 않으므로
//                 GridCardHoverProbe 와 동일한 Physics Raycast 폴링 방식으로 클릭을 잡는다.
// [주요 변수]      - _camera        : 스크린→월드 Raycast 카메라 (비우면 Camera.main)
//                  - _slotLayerMask : 그리드 슬롯 레이어 마스크 (GridSlot BoxCollider)
//                  - _rayDistance   : Raycast 최대 거리
// [의존 관계]      - BattleManager(보존 선택 토글·페이즈) / GridManager / GridSlot
//                  - 페이즈 구독(OnPhaseChanged)으로 보존 페이즈에서만 활성.
// [배치]           전투 씬(또는 UIBattle) 상주. GridCardHoverProbe 와 같은 오브젝트 가능.
// [설계 노트]      - 보존 페이즈에서만 입력을 받는다(다른 페이즈는 무시) → 배치/회수와 충돌 없음.
//                  - 선택 토글·한도 판정은 전부 BattleManager 가 소유. 이 컴포넌트는 입력만.
//                  - 클릭 후 슬롯 보존 표시를 갱신한다. 확정 버튼은 UIBattle 턴 종료 버튼을 공유한다.
// =================================================================

using Cysharp.Threading.Tasks;
using UnityEngine;
using UnityEngine.InputSystem;

/// <summary>
/// 보존 페이즈 동안 그리드 카드 좌클릭을 폴링해 보존 선택을 토글한다.
/// 보존 페이즈가 아닐 때는 아무 입력도 처리하지 않는다.
/// </summary>
public sealed class PreserveSelectInput : MonoBehaviour
{
    private readonly RaycastHit[] _slotHits = new RaycastHit[32];

    [Header("Raycast")]
    [Tooltip("스크린→월드 Raycast 카메라. 비우면 Camera.main")]
    [SerializeField] private Camera _camera;

    [Tooltip("그리드 슬롯 레이어 마스크. 슬롯 BoxCollider 가 속한 레이어")]
    [SerializeField] private LayerMask _slotLayerMask = ~0;

    [Tooltip("Raycast 최대 거리 (m). 카메라에서 그리드 평면까지 닿을 거리")]
    [Min(1f)]
    [SerializeField] private float _rayDistance = 100f;

    private Camera Cam => _camera != null ? _camera : Camera.main;

    private bool _active;   // 보존 페이즈 동안만 true.

    private void OnEnable()
    {
        if (BattleManager.HasInstance)
        {
            BattleManager.Instance.OnPhaseChanged -= HandlePhaseChanged;
            BattleManager.Instance.OnPhaseChanged += HandlePhaseChanged;
            // 현재 페이즈 즉시 반영 (보존 페이즈 중 활성화될 수도 있음).
            HandlePhaseChanged(BattleManager.Instance.CurrentPhase);
        }
    }

    private void OnDisable()
    {
        if (BattleManager.HasInstance)
        {
            BattleManager.Instance.OnPhaseChanged -= HandlePhaseChanged;
        }
        _active = false;
    }

    /// <summary>보존 페이즈에서만 입력 처리 활성. 전체 보존 모드면 즉시 통과하므로 잡히지 않는다.</summary>
    private void HandlePhaseChanged(EBattlePhase phase)
    {
        _active = phase == EBattlePhase.PreserveSelect
                  && BattleManager.HasInstance
                  && !BattleManager.Instance.IsPreserveAll;
    }

    private void Update()
    {
        if (!_active || Mouse.current == null || !BattleManager.HasInstance) return;

        // 좌클릭 시에만 판정 (그 외 프레임은 즉시 반환 → 폴링 비용 최소).
        if (!Mouse.current.leftButton.wasPressedThisFrame) return;

        // 포인터가 UI(확인 버튼·패널 등) 위면 그쪽 클릭이 우선 — 그리드 선택 무시.
        if (UnityEngine.EventSystems.EventSystem.current != null &&
            UnityEngine.EventSystems.EventSystem.current.IsPointerOverGameObject())
        {
            return;
        }

        Vector2 screenPos = Mouse.current.position.ReadValue();
        GridSlot slot = FindSlotAt(screenPos);
        if (slot == null || slot.IsEmpty || slot.OccupiedCard == null) return;

        // 보존 선택 토글 — 한도 초과/후보 아님 판정은 BattleManager 가 수행.
        // 토글 결과에 따라 슬롯 보존 하이라이트를 갱신한다.
        // 효과(ReserveEffect)로 이미 보존된 카드는 선택집합에 없어도 하이라이트를 유지해야 하므로
        // "수동 선택됨 OR 효과 보존됨" 기준으로 표시한다.
        Card card = slot.OccupiedCard;
        bool wasSelected = BattleManager.Instance.IsPreserveSelected(card);
        BattleManager.Instance.TogglePreserveSelection(card);
        bool isSelected = BattleManager.Instance.IsPreserveSelected(card);
        if (wasSelected != isSelected && AudioManager.HasInstance)
            AudioManager.Instance.PlaySfxAsync(AudioKeys.Battle.PRESERVE_SELECT).Forget();

        // 하이라이트는 GridManager 의 보존 프리뷰 레이어를 통해 갱신한다.
        // 슬롯을 직접 칠하면 다른 프리뷰 레이어(호버·적 의도)가 갱신될 때 테두리가 지워진다.
        if (!GridManager.HasInstance) return;

        // 이번 턴 선택 = 시안 / 효과로 이미 보존됨 = 연한 파랑 / 그 외 = 끔.
        if (isSelected)
            GridManager.Instance.SetCardPreserveHighlight(card, true);
        else if (IsEffectPreserved(card))
            GridManager.Instance.SetCardPreserveHighlight(card, true, isEffectPreserved: true);
        else
            GridManager.Instance.SetCardPreserveHighlight(card, false);
    }

    /// <summary>효과(ReserveEffect 등)로 이미 보존 스택이 있는 카드인지. 하이라이트 유지 판정용.</summary>
    private static bool IsEffectPreserved(Card card)
    {
        return card != null && card.GridState != null && card.GridState.IsPreserved;
    }

    /// <summary>스크린 좌표 아래의 그리드 슬롯을 Raycast 로 탐지. 없으면 null.</summary>
    private GridSlot FindSlotAt(Vector2 screenPos)
    {
        Camera cam = Cam;
        if (cam == null) return null;

        Ray ray = cam.ScreenPointToRay(screenPos);
        int hitCount = Physics.RaycastNonAlloc(
            ray,
            _slotHits,
            _rayDistance,
            _slotLayerMask,
            QueryTriggerInteraction.Collide);

        GridSlot nearestSlot = null;
        float nearestDistance = float.MaxValue;
        for (int i = 0; i < hitCount; i++)
        {
            RaycastHit hit = _slotHits[i];
            if (hit.collider == null) continue;

            GridSlot slot = hit.collider.GetComponentInParent<GridSlot>();
            if (slot == null || hit.distance >= nearestDistance) continue;

            nearestSlot = slot;
            nearestDistance = hit.distance;
        }

        return nearestSlot;
    }
}
