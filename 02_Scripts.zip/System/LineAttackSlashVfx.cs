using System.Collections.Generic;
using UnityEngine;

[DisallowMultipleComponent]
public sealed class LineAttackSlashVfx : MonoBehaviour
{
    [Tooltip("실제 베기 플립북을 재생하는 Slash ParticleSystem")]
    [SerializeField] private ParticleSystem _slash;
    [Tooltip("원본 Slash 플립북이 표현하는 세로 길이")]
    [Min(0.01f)]
    [SerializeField] private float _referenceLength = 2f;
    [Tooltip("길이 조절 후에도 유지할 Slash 플립북의 폭")]
    [Min(0.01f)]
    [SerializeField] private float _referenceWidth = 2f;
    [Tooltip("계산된 공격 구간 양끝에 추가할 전체 여백")]
    [Min(0f)]
    [SerializeField] private float _lengthPadding;
    [Tooltip("공격 진입 방향으로 첫 그리드 밖까지 추가로 연장할 길이")]
    [Min(0f)]
    [SerializeField] private float _entryExtension = 0.4f;
    [Tooltip("그리드 평면과 겹치지 않도록 적용할 월드 Z 위치 보정값")]
    [SerializeField] private float _zOffset = -0.05f;
    [Tooltip("파티클 재생 시간 중 첫 슬롯 충격이 시작되는 정규화 시각")]
    [Range(0f, 1f)]
    [SerializeField] private float _impactStartNormalized;
    [Tooltip("파티클 재생 시간 중 마지막 슬롯 충격이 끝나는 정규화 시각")]
    [Range(0f, 1f)]
    [SerializeField] private float _impactEndNormalized = 0.7f;

    private readonly Vector3[] _corners = new Vector3[4];

    public float Duration { get; private set; }
    public float ImpactStartNormalized => _impactStartNormalized;
    public float ImpactEndNormalized => Mathf.Max(_impactStartNormalized, _impactEndNormalized);

    public bool Play(IReadOnlyList<GridSlot> slots, GridLineAttackPlan plan)
    {
        if (_slash == null || slots == null || slots.Count == 0 || slots[0] == null) return false;

        float speedMultiplier = BattleSpeedUtility.Multiplier;
        ParticleSystem[] particles = GetComponentsInChildren<ParticleSystem>(true);
        for (int i = 0; i < particles.Length; i++)
        {
            ParticleSystem.MainModule particleMain = particles[i].main;
            particleMain.simulationSpeed *= speedMultiplier;
        }

        GridSlot first = slots[0];
        GridSlot last = slots[slots.Count - 1];
        if (last == null) return false;

        Vector3 direction = plan.Axis == EGridLineAxis.Row ? Vector3.right : Vector3.up;
        if (!plan.Forward) direction = -direction;

        float start = GetProjectedEdge(first, direction, minimum: true) - _entryExtension;
        float end = last.IsEmpty
            ? GetProjectedEdge(last, direction, minimum: false)
            : Vector3.Dot(last.transform.position, direction);
        float length = Mathf.Max(0.01f, end - start + _lengthPadding);
        Vector3 center = (first.transform.position + last.transform.position) * 0.5f;
        center += direction * (((start + end) * 0.5f) - Vector3.Dot(center, direction));
        center.z = first.transform.position.z + _zOffset;
        transform.position = center;

        ParticleSystem.MainModule main = _slash.main;
        main.startSize3D = true;
        main.startSizeX = _referenceWidth;
        main.startSizeY = _referenceLength * (length / _referenceLength);
        main.startRotation = GetRotation(direction) * Mathf.Deg2Rad;
        Duration = BattleSpeedUtility.ScaleDuration(main.duration);

        _slash.Stop(true, ParticleSystemStopBehavior.StopEmittingAndClear);
        _slash.Play(true);
        return true;
    }

    private float GetProjectedEdge(GridSlot slot, Vector3 direction, bool minimum)
    {
        if (!slot.TryGetWorldOutline(_corners)) return Vector3.Dot(slot.transform.position, direction);

        float value = Vector3.Dot(_corners[0], direction);
        for (int i = 1; i < _corners.Length; i++)
        {
            float projected = Vector3.Dot(_corners[i], direction);
            value = minimum ? Mathf.Min(value, projected) : Mathf.Max(value, projected);
        }
        return value;
    }

    private static float GetRotation(Vector3 direction)
    {
        if (Mathf.Abs(direction.x) > Mathf.Abs(direction.y))
        {
            return direction.x < 0f ? 90f : 270f;
        }
        return direction.y > 0f ? 180f : 0f;
    }
}
