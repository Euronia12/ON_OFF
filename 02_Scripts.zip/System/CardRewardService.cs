﻿// =================================================================
// [스크립트 목적]  카드 쿼리·추첨 서비스 (POCO). 전체 카드를 조건으로 필터링 후
//                 등급 선추첨 후 비복원 랜덤 추출. 별도 보상 테이블 SO 없이 카드 자체 분류로 동작.
// [주요 변수]      - _allCards      : DataManager 에서 1회 캐싱한 전체 카드 SO
//                  - _unlock        : 해방 조회 (폴백=항상 true)
//                  - _scratchPool   : 추첨용 재사용 버퍼 (GC 절감)
// [의존 관계]      - DataManager.GetAllData<CardDataSO> / CardDataSO(_pools 등)
//                  - CardQueryCriteria / ICardUnlockProvider / ECardRarity
//                  - InGameController(보상)·상점·스타팅 등이 호출
// [설계 노트]      - ★ 조건마다 SO 테이블을 만들지 않는다. 카드가 자기 분류(pools/rarity/
//                    unlock)를 소유 → 쿼리로 동적 추출. 테이블 폭증·이중관리 제거.
//                  - 가중치: 등급(rarity) 자체를 먼저 뽑는 기본값.
//                  - 비복원 추첨: 뽑은 카드 제외 후 재추첨 → 중복 없는 N장.
//                  - 시드 재현: System.Random(RunContext.Rng) 주입 → 같은 런 동일 결과.
// =================================================================

using System;
using System.Collections.Generic;
using UnityEngine;

[Serializable]
public struct CardRarityWeights
{
    [Tooltip("Common 등급 등장 가중치")]
    [Min(0f)]
    [SerializeField] private float _common;

    [Tooltip("Rare 등급 등장 가중치")]
    [Min(0f)]
    [SerializeField] private float _rare;

    [Tooltip("Unique 등급 등장 가중치")]
    [Min(0f)]
    [SerializeField] private float _unique;

    [Tooltip("Legendary 등급 등장 가중치")]
    [Min(0f)]
    [SerializeField] private float _legendary;

    public static CardRarityWeights Default => new CardRarityWeights(70f, 24f, 5f, 1f);
    public bool IsValid => _common > 0f || _rare > 0f || _unique > 0f || _legendary > 0f;

    public CardRarityWeights(float common, float rare, float unique, float legendary)
    {
        _common = Mathf.Max(0f, common);
        _rare = Mathf.Max(0f, rare);
        _unique = Mathf.Max(0f, unique);
        _legendary = Mathf.Max(0f, legendary);
    }

    public float GetWeight(ECardRarity rarity)
    {
        return rarity switch
        {
            ECardRarity.Rare => Mathf.Max(0f, _rare),
            ECardRarity.Unique => Mathf.Max(0f, _unique),
            ECardRarity.Legendary => Mathf.Max(0f, _legendary),
            _ => Mathf.Max(0f, _common),
        };
    }
}

/// <summary>
/// 카드 쿼리·추첨 서비스. 전체 카드 풀에서 조건(CardQueryCriteria)에 맞는 카드를
/// 등급 선추첨 후 비복원으로 뽑는다. 보상·상점·스타팅덱 등 "조건부 카드 추출"을 단일 경로로 처리.
/// 등급별 테이블 SO 없이, 카드 자신이 가진 분류(pools/rarity/unlock)로만 필터링한다.
/// </summary>
public sealed class CardRewardService
{
    private readonly List<CardDataSO> _allCards;
    private readonly ICardUnlockProvider _unlock;
    private readonly CardRarityWeights _rarityWeights;

    // 추첨용 재사용 버퍼 (호출마다 new 회피 → GC 절감).
    private readonly List<CardDataSO> _scratchPool = new List<CardDataSO>(64);

    /// <param name="allCards">이번 추첨에 사용할 카드 SO 풀. null 이면 빈 풀.</param>
    /// <param name="unlock">해방 조회. null 이면 항상-해방 폴백 사용.</param>
    public CardRewardService(IReadOnlyList<CardDataSO> allCards, ICardUnlockProvider unlock = null)
        : this(allCards, unlock, CardRarityWeights.Default)
    {
    }

    /// <param name="allCards">이번 추첨에 사용할 카드 SO 풀. null 이면 빈 풀.</param>
    /// <param name="unlock">해방 조회. null 이면 항상-해방 폴백 사용.</param>
    /// <param name="rarityWeights">등급별 등장 가중치. 전부 0이면 기본값을 사용.</param>
    public CardRewardService(
        IReadOnlyList<CardDataSO> allCards,
        ICardUnlockProvider unlock,
        CardRarityWeights rarityWeights)
    {
        _allCards = new List<CardDataSO>(allCards != null ? allCards.Count : 0);
        if (allCards != null)
        {
            for (int i = 0; i < allCards.Count; i++)
            {
                if (allCards[i] != null) _allCards.Add(allCards[i]);
            }
        }
        _unlock = unlock ?? AlwaysUnlockedProvider.Instance;
        _rarityWeights = rarityWeights.IsValid ? rarityWeights : CardRarityWeights.Default;
    }

    /// <summary>
    /// DataManager 에서 전체 카드를 받아 서비스 생성하는 편의 팩토리.
    /// DataManager 미준비 시 빈 풀 서비스를 반환(호출부가 빈 결과 처리).
    /// </summary>
    public static CardRewardService FromDataManager(ICardUnlockProvider unlock = null)
    {
        if (DataManager.HasInstance && DataManager.Instance.IsLoaded)
        {
            List<CardDataSO> all = DataManager.Instance.GetAllData<CardDataSO>();
            return new CardRewardService(all, unlock);
        }

        Debug.LogWarning("[CardRewardService] DataManager 미준비 — 빈 카드 풀로 생성.");
        return new CardRewardService(null, unlock);
    }

    /// <summary>
    /// 조건에 맞는 카드 전체를 결과 리스트에 채운다 (추첨 없이 매칭만).
    /// 풀 비트 AND + 스테이지 + 등급(지정 시) + 해방여부 + 제외목록을 모두 통과한 카드만.
    /// </summary>
    public void Query(in CardQueryCriteria criteria, List<CardDataSO> result)
    {
        if (result == null) return;
        result.Clear();

        for (int i = 0; i < _allCards.Count; i++)
        {
            CardDataSO card = _allCards[i];
            if (!Matches(card, in criteria)) continue;
            result.Add(card);
        }
    }

    /// <summary>
    /// 조건에 맞는 카드를 등급 선추첨 + 비복원으로 count 장 추첨해 반환 (새 리스트).
    /// 풀이 count 보다 적으면 가능한 만큼만. rng 는 RunContext.Rng 공유 권장(재현성).
    /// </summary>
    public List<CardDataSO> PickRandom(in CardQueryCriteria criteria, int count, System.Random rng)
    {
        List<CardDataSO> result = new List<CardDataSO>(count > 0 ? count : 0);
        if (count <= 0) return result;

        System.Random random = rng ?? new System.Random();

        // 조건 매칭 카드를 스크래치에 모은다 (비복원 추첨용 가변 풀).
        Query(in criteria, _scratchPool);
        if (_scratchPool.Count == 0) return result;

        int take = count < _scratchPool.Count ? count : _scratchPool.Count;
        for (int n = 0; n < take; n++)
        {
            int picked = PickRarityFirstIndex(_scratchPool, random);
            if (picked < 0) break;

            result.Add(_scratchPool[picked]);
            _scratchPool.RemoveAt(picked); // 비복원
        }

        return result;
    }

    /// <summary>조건에 맞는 카드가 존재하는지 (보상 버튼 노출 판단 등 빠른 체크).</summary>
    public bool HasAny(in CardQueryCriteria criteria)
    {
        for (int i = 0; i < _allCards.Count; i++)
        {
            if (Matches(_allCards[i], in criteria)) return true;
        }
        return false;
    }

    // ── 내부 ───────────────────────────────────────────────

    /// <summary>카드가 쿼리 조건을 전부 통과하는지.</summary>
    private bool Matches(CardDataSO card, in CardQueryCriteria criteria)
    {
        if (card == null) return false;

        // 1) 풀: 카드의 _pools 와 조건 Pool 이 비트로 겹쳐야 함.
        if ((card.Pools & criteria.Pool) == 0) return false;

        // 2) 스테이지: 카드의 _stagePools 와 조건 StagePool 이 비트로 겹쳐야 함.
        if ((card.StagePools & criteria.StagePool) == 0) return false;

        // 3) 등급: 지정된 경우만 일치 요구.
        if (criteria.Rarity.HasValue && card.Rarity != criteria.Rarity.Value) return false;

        // 4) 해방: UnlockedOnly 면 해방 카드만 (잠긴 카드 제외).
        if (criteria.UnlockedOnly)
        {
            if (!card.UnlockedByDefault && !_unlock.IsUnlocked(card.CardId)) return false;
        }

        // 5) 제외 목록.
        if (criteria.ExcludeIds != null && criteria.ExcludeIds.Contains(card.CardId)) return false;

        return true;
    }

    /// <summary>
    /// 등급을 먼저 가중치로 확정한 뒤, 해당 등급 안에서 카드 1장을 균등 추첨한다.
    /// 비어 있는 등급은 확률 표에서 제외해 남은 후보만으로 재정규화한다.
    /// </summary>
    private int PickRarityFirstIndex(List<CardDataSO> pool, System.Random rng)
    {
        if (pool.Count == 0) return -1;

        bool hasCommon = HasRarity(pool, ECardRarity.Common);
        bool hasRare = HasRarity(pool, ECardRarity.Rare);
        bool hasUnique = HasRarity(pool, ECardRarity.Unique);
        bool hasLegendary = HasRarity(pool, ECardRarity.Legendary);

        float total = 0f;
        if (hasCommon) total += WeightOf(ECardRarity.Common);
        if (hasRare) total += WeightOf(ECardRarity.Rare);
        if (hasUnique) total += WeightOf(ECardRarity.Unique);
        if (hasLegendary) total += WeightOf(ECardRarity.Legendary);
        if (total <= 0f) return 0;

        double roll = rng.NextDouble() * total;
        float acc = 0f;

        if (hasCommon)
        {
            acc += WeightOf(ECardRarity.Common);
            if (roll < acc) return PickUniformIndexByRarity(pool, ECardRarity.Common, rng);
        }

        if (hasRare)
        {
            acc += WeightOf(ECardRarity.Rare);
            if (roll < acc) return PickUniformIndexByRarity(pool, ECardRarity.Rare, rng);
        }

        if (hasUnique)
        {
            acc += WeightOf(ECardRarity.Unique);
            if (roll < acc) return PickUniformIndexByRarity(pool, ECardRarity.Unique, rng);
        }

        if (hasLegendary)
        {
            return PickUniformIndexByRarity(pool, ECardRarity.Legendary, rng);
        }

        return 0;
    }

    private static bool HasRarity(List<CardDataSO> pool, ECardRarity rarity)
    {
        for (int i = 0; i < pool.Count; i++)
        {
            if (pool[i] != null && pool[i].Rarity == rarity) return true;
        }

        return false;
    }

    private static int PickUniformIndexByRarity(List<CardDataSO> pool, ECardRarity rarity, System.Random rng)
    {
        int count = 0;
        for (int i = 0; i < pool.Count; i++)
        {
            if (pool[i] != null && pool[i].Rarity == rarity) count++;
        }
        if (count <= 0) return 0;

        int target = rng.Next(0, count);
        for (int i = 0; i < pool.Count; i++)
        {
            if (pool[i] == null || pool[i].Rarity != rarity) continue;
            if (target-- == 0) return i;
        }

        return pool.Count - 1;
    }

    /// <summary>등급 추첨 가중치.</summary>
    private float WeightOf(ECardRarity rarity) => _rarityWeights.GetWeight(rarity);
}
