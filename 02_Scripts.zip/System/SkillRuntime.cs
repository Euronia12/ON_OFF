using System;
using UnityEngine;

public sealed class SkillRuntime
{
    public SkillRuntimeData Data { get; }
    private readonly int _maxCooldown;
    public int RemainingCooldown { get; private set; }
    public bool IsReady => RemainingCooldown <= 0;

    /// <summary>이 스킬의 최대 쿨다운 턴 수 (UI 게이지 비율 계산용).</summary>
    public int MaxCooldown => _maxCooldown;

    public event Action OnChanged;

    public SkillRuntime(SkillRuntimeData data, int additionalCooldown = 0)
    {
        Data = data;
        _maxCooldown = data != null
            ? Mathf.Max(SkillDataSO.CooldownMin, data.Cooldown + additionalCooldown)
            : 0;
    }

    public void OnBattleStart()
    {
        RemainingCooldown = 0;
        OnChanged?.Invoke();
    }

    public void Use()
    {
        RemainingCooldown = MaxCooldown;
        OnChanged?.Invoke();
    }

    public void RestoreCooldown(int remainingTurns)
    {
        RemainingCooldown = Mathf.Clamp(remainingTurns, 0, MaxCooldown);
        OnChanged?.Invoke();
    }

    public void ResetCooldown()
    {
        if (RemainingCooldown <= 0) return;
        RemainingCooldown = 0;
        OnChanged?.Invoke();
    }

    public void TickTurnEnd()
    {
        if (RemainingCooldown <= 0) return;
        RemainingCooldown = Mathf.Max(0, RemainingCooldown - 1);
        OnChanged?.Invoke();
    }
}
