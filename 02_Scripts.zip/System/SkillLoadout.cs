using System.Collections.Generic;

public sealed class SkillLoadout
{
    public const int SlotCount = 3;

    private readonly SkillRuntime[] _slots = new SkillRuntime[SlotCount];
    public IReadOnlyList<SkillRuntime> Slots => _slots;

    public SkillLoadout(IReadOnlyList<SkillRuntimeData> skills)
    {
        for (int i = 0; i < SlotCount; i++)
        {
            SkillRuntimeData data = skills != null && i < skills.Count ? skills[i] : null;
            _slots[i] = data != null ? new SkillRuntime(data) : null;
        }
    }

    public SkillRuntime Get(int index)
    {
        return index >= 0 && index < _slots.Length ? _slots[index] : null;
    }

    public void OnBattleStart()
    {
        for (int i = 0; i < _slots.Length; i++)
            _slots[i]?.OnBattleStart();
    }

    public void TickTurnEnd()
    {
        for (int i = 0; i < _slots.Length; i++)
            _slots[i]?.TickTurnEnd();
    }

}
