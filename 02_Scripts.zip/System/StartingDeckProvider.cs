﻿// =================================================================
// [스크립트 목적]  시작 덱 ID 추출 (Run Flow 헬퍼). enum → StartingDeckSO → 카드 ID 목록.
//                 기존 BattleController 의 시작덱 책임을 Run 쪽으로 이관 (책임 분리).
// [주요 변수]      - _deckMap : enum → 원본 StartingDeckSO 인덱스 (DataManager 1회 구축)
// [의존 관계]      - DataManager.GetAllData<StartingDeckSO> / StartingDeckSO / EStartingDeck
//                  - InGameController 가 런 시작 시 호출해 RunContext.InitializeDeck 에 넘김
// [설계 노트]      - ★ 시작 덱 결정은 Run Flow 개념 → BattleController 에서 분리.
//                  - 원본 SO 는 읽기 전용(BuildCards 로 Card 변환 후 ID만 추출). 복제 불필요.
//                  - enum 중복 시 첫 항목 우선 (경고).
// =================================================================

using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// 시작 덱 종류(enum)로부터 카드 SO ID 목록을 추출하는 Run Flow 헬퍼.
/// DataManager 에서 StartingDeckSO 전체를 받아 enum→SO 인덱스를 1회 구축하고,
/// 요청 시 해당 덱의 카드 ID 들을 반환한다 (RunContext.InitializeDeck 입력).
/// </summary>
public sealed class StartingDeckProvider
{
    private Dictionary<EStartingDeck, StartingDeckSO> _deckMap;

    /// <summary>
    /// 시작 덱 SO 의 카드 ID 목록 반환. 매칭 실패 시 첫 항목 폴백, 그것도 없으면 빈 목록.
    /// </summary>
    public List<string> GetStartingDeckCardIds(EStartingDeck deckType)
    {
        List<string> ids = new List<string>();
        StartingDeckSO deck = ResolveStartingDeck(deckType);
        if (deck == null) return ids;

        // StartingDeckSO 가 BuildCards 로 Card 를 만들므로, 거기서 CardId 를 뽑는다.
        List<Card> cards = deck.BuildCards();
        if (cards != null)
        {
            for (int i = 0; i < cards.Count; i++)
            {
                if (cards[i] != null && cards[i].Data != null)
                {
                    ids.Add(cards[i].Data.CardId);
                }
            }
        }
        return ids;
    }

    private StartingDeckSO ResolveStartingDeck(EStartingDeck deckType)
    {
        EnsureDeckMap();

        if (_deckMap.TryGetValue(deckType, out var deck) && deck != null)
        {
            return deck;
        }

        Debug.LogWarning($"[StartingDeckProvider] '{deckType}' 시작 덱 SO를 찾지 못했습니다. 첫 항목으로 폴백.");
        foreach (var v in _deckMap.Values)
        {
            if (v != null) return v;
        }
        return null;
    }

    /// <summary>DataManager 에서 StartingDeckSO 전체를 받아 enum→SO 인덱스 1회 구축.</summary>
    private void EnsureDeckMap()
    {
        if (_deckMap != null) return;
        _deckMap = new Dictionary<EStartingDeck, StartingDeckSO>();

        if (!DataManager.HasInstance || !DataManager.Instance.IsLoaded)
        {
            Debug.LogError("[StartingDeckProvider] DataManager 가 준비되지 않았습니다. 시작 덱 인덱스 비어있음.");
            return;
        }

        List<StartingDeckSO> all = DataManager.Instance.GetAllData<StartingDeckSO>();
        foreach (var so in all)
        {
            if (so == null) continue;
            if (!_deckMap.TryAdd(so.DeckType, so))
            {
                Debug.LogWarning($"[StartingDeckProvider] 시작 덱 enum 중복: '{so.DeckType}' ({so.name}). 첫 항목 유지.");
            }
        }

#if UNITY_EDITOR || DEVELOPMENT_BUILD
        Debug.Log($"[StartingDeckProvider] 시작 덱 인덱스 구축 — {_deckMap.Count}종 (DataManager 경유)");
#endif
    }
}