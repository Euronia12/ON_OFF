﻿// =================================================================
// [스크립트 목적]  전투 시작 입력 DTO (POCO). Run Flow → Battle Logic 경계.
//                 "이 덱, 이 적으로 싸워라"만 담아 BattleController 에 넘긴다.
// [주요 변수]      - DeckCardIds    : 이번 전투에 쓸 카드 SO ID 목록 (Run 누적덱에서 추출)
//                  - EnemyData      : 이번 전투의 적 데이터 (Run 이 시드로 결정)
//                  - ShuffleSeed    : 덱 셔플 시드 (재현성, 선택)
//                  - PlayerMaxHp/Energy : 전투 파라미터 오버라이드 (0 이하면 컨트롤러 기본값)
// [의존 관계]      - InGameController(생성) → BattleController(소비)
//                  - EnemyDataSO (적 데이터 참조)
// [설계 노트]      - ★ BattleController 가 RunContext/StageProvider/시드맵을 모르게 하는 핵심.
//                    Run Flow 개념(시드·층·누적덱·적결정)을 이 DTO 경계에서 전부 해소.
//                  - 전투는 이 DTO 만 있으면 굴러간다 → Run 없는 전투(아레나·튜토리얼)도 동일 입구.
//                  - 불변 의도(readonly). 적 데이터는 SO 참조(읽기 전용 — 게임플레이는 EnemyActor 변환).
// =================================================================

using System;
using System.Collections.Generic;
using UnityEngine;

/// <summary>전투 시작 시 그리드에 미리 배치할 카드 데이터.</summary>
[Serializable]
public sealed class BattleStartGridSeedCard
{
    [Tooltip("배치할 카드 데이터")]
    [SerializeField] private CardDataSO _cardData;

    [Tooltip("배치할 그리드 좌표")]
    [SerializeField] private Vector2Int _position;

    [Tooltip("강화 상태로 생성할지 여부")]
    [SerializeField] private bool _upgraded;

    public CardDataSO CardData => _cardData;
    public Vector2Int Position => _position;
    public bool Upgraded => _upgraded;

    public BattleStartGridSeedCard(CardDataSO cardData, Vector2Int position, bool upgraded = false)
    {
        _cardData = cardData;
        _position = position;
        _upgraded = upgraded;
    }
}

/// <summary>
/// 전투 1회의 시작 입력. Run Flow(InGameController)가 "이번 전투에 무엇을 쓸지"를
/// 결정해 포장하고, Battle Logic(BattleController)은 이 DTO 만 받아 전투를 구동한다.
/// BattleController 가 RunContext 에 의존하지 않게 만드는 경계 객체.
/// </summary>
public sealed class BattleStartContext
{
    private const uint SHUFFLE_SEED_OFFSET_BASIS = 2166136261u;
    private const uint SHUFFLE_SEED_PRIME = 16777619u;
    private const int FALLBACK_SHUFFLE_SEED = 1;

    /// <summary>이번 전투 덱 (카드 SO ID 목록). Run 누적덱에서 추출해 전달.</summary>
    public IReadOnlyList<string> DeckCardIds { get; }
    public IReadOnlyList<RunDeckEntry> DeckEntries { get; }
    public Func<int, bool, RunCardPersistentState> GetPersistentState { get; }
    public Action<int> TrimPersistentState { get; }

    /// <summary>런 덱 엔트리의 영구 코스트 보정 조회. null이면 보정 없음.</summary>
    public Func<int, int> GetCardCostDelta { get; }

    /// <summary>이번 전투의 적 데이터. Run 이 시드·층으로 결정해 전달 (null 이면 폴백 더미).</summary>
    public EnemyDataSO EnemyData { get; }

    /// <summary>이번 전투에서 사용할 배경 프리팹 Addressable 키.</summary>
    public string BattleBackgroundKey { get; }

    /// <summary>현재 스테이지와 적 등급으로 결정된 전투 BGM Addressable 키.</summary>
    public string BattleBgmKey { get; }

    /// <summary>보스 2페이즈부터 사용할 BGM Addressable 키.</summary>
    public string BossPhase2BgmKey { get; }

    /// <summary>덱 셔플 시드 (같은 시드 = 같은 셔플). 재현성용.</summary>
    public int ShuffleSeed { get; }

    /// <summary>플레이어 시작 체력 오버라이드. 0 이하면 BattleController 기본값 사용.</summary>
    public int PlayerMaxHp { get; }

    /// <summary>
    /// 플레이어 시작 시 현재 체력 (런 HP 유지). 0 이하면 PlayerMaxHp(풀피)로 시작.
    /// 슬더스식 — 이전 전투에서 깎인 HP 가 이어진다.
    /// </summary>
    public int PlayerCurrentHp { get; }

    /// <summary>플레이어 최대 에너지 오버라이드. 0 미만이면 BattleController 기본값 사용.</summary>
    public int PlayerMaxEnergy { get; }

    /// <summary>턴 시작 드로우 수 오버라이드(런 스탯). 0 미만이면 BattleController 기본값 사용.</summary>
    public int DrawPerTurn { get; }

    /// <summary>일반 전투용 그리드 행 수. 0 이하면 기존 GridManager 설정 유지.</summary>
    public int GridRows { get; }

    /// <summary>일반 전투용 그리드 열 수. 0 이하면 기존 GridManager 설정 유지.</summary>
    public int GridColumns { get; }

    /// <summary>튜토리얼 전투 여부. true일 때만 튜토리얼 전용 옵션을 적용한다.</summary>
    public bool IsTutorialBattle { get; }

    /// <summary>튜토리얼 전투용 그리드 행 수. 0 이하면 기존 GridManager 설정 유지.</summary>
    public int TutorialGridRows { get; }

    /// <summary>튜토리얼 전투용 그리드 열 수. 0 이하면 기존 GridManager 설정 유지.</summary>
    public int TutorialGridColumns { get; }

    /// <summary>튜토리얼 전투용 직접 카드 SO 덱. 비어 있으면 DeckCardIds 경로를 사용한다.</summary>
    public IReadOnlyList<CardDataSO> TutorialDeckCards { get; }

    /// <summary>튜토리얼 덱 카드별 최초 화살표 방향. TutorialDeckCards와 같은 인덱스를 사용한다.</summary>
    public IReadOnlyList<ECardDirection> TutorialDeckForcedArrows { get; }

    /// <summary>튜토리얼 전투의 첫 턴에 우선 드로우할 실제 런 덱 카드 ID 순서.</summary>
    public IReadOnlyList<string> TutorialFirstDrawCardIds { get; }

    /// <summary>튜토리얼 전투 시작 시 그리드에 미리 깔 카드 목록.</summary>
    public IReadOnlyList<BattleStartGridSeedCard> TutorialSeedCards { get; }

    /// <summary>턴 종료 카드 보존 설정 (런 → 전투). null 이면 보존 없음(전부 묘지행 폴백).</summary>
    public PreserveConfig Preserve { get; }

    /// <summary>
    /// 이미 저장되는 런 위치 정보로 전투별 셔플 시드를 안정적으로 파생한다.
    /// 0은 "시드 없음" 예약값이므로 파생 결과에서는 사용하지 않는다.
    /// </summary>
    public static int CreateShuffleSeed(int runSeed, int stageIndex, int nodeId)
    {
        unchecked
        {
            uint hash = SHUFFLE_SEED_OFFSET_BASIS;
            hash = (hash ^ (uint)runSeed) * SHUFFLE_SEED_PRIME;
            hash = (hash ^ (uint)stageIndex) * SHUFFLE_SEED_PRIME;
            hash = (hash ^ (uint)nodeId) * SHUFFLE_SEED_PRIME;

            int seed = (int)hash;
            return seed != 0 ? seed : FALLBACK_SHUFFLE_SEED;
        }
    }

    public BattleStartContext(
        IReadOnlyList<string> deckCardIds,
        EnemyDataSO enemyData,
        int shuffleSeed = 0,
        int playerMaxHp = 0,
        int playerMaxEnergy = -1,
        int playerCurrentHp = 0,
        int gridRows = 0,
        int gridColumns = 0,
        bool isTutorialBattle = false,
        int tutorialGridRows = 0,
        int tutorialGridColumns = 0,
        IReadOnlyList<CardDataSO> tutorialDeckCards = null,
        IReadOnlyList<BattleStartGridSeedCard> tutorialSeedCards = null,
        int drawPerTurn = -1,
        PreserveConfig preserveConfig = null,
        string battleBackgroundKey = null,
        string battleBgmKey = null,
        string bossPhase2BgmKey = null,
        IReadOnlyList<ECardDirection> tutorialDeckForcedArrows = null,
        IReadOnlyList<string> tutorialFirstDrawCardIds = null)
        : this(
            null,
            deckCardIds,
            enemyData,
            shuffleSeed,
            playerMaxHp,
            playerMaxEnergy,
            playerCurrentHp,
            null,
            null,
            gridRows,
            gridColumns,
            isTutorialBattle,
            tutorialGridRows,
            tutorialGridColumns,
            tutorialDeckCards,
            tutorialSeedCards,
            drawPerTurn,
            preserveConfig,
            battleBackgroundKey,
            battleBgmKey,
            bossPhase2BgmKey,
            tutorialDeckForcedArrows,
            tutorialFirstDrawCardIds)
    {
    }

    public BattleStartContext(
        IReadOnlyList<RunDeckEntry> deckEntries,
        IReadOnlyList<string> deckCardIds,
        EnemyDataSO enemyData,
        int shuffleSeed = 0,
        int playerMaxHp = 0,
        int playerMaxEnergy = -1,
        int playerCurrentHp = 0,
        Func<int, bool, RunCardPersistentState> getPersistentState = null,
        Action<int> trimPersistentState = null,
        int gridRows = 0,
        int gridColumns = 0,
        bool isTutorialBattle = false,
        int tutorialGridRows = 0,
        int tutorialGridColumns = 0,
        IReadOnlyList<CardDataSO> tutorialDeckCards = null,
        IReadOnlyList<BattleStartGridSeedCard> tutorialSeedCards = null,
        int drawPerTurn = -1,
        PreserveConfig preserveConfig = null,
        string battleBackgroundKey = null,
        string battleBgmKey = null,
        string bossPhase2BgmKey = null,
        IReadOnlyList<ECardDirection> tutorialDeckForcedArrows = null,
        IReadOnlyList<string> tutorialFirstDrawCardIds = null,
        Func<int, int> getCardCostDelta = null)
    {
        DeckCardIds = deckCardIds ?? new List<string>();
        DeckEntries = deckEntries ?? new List<RunDeckEntry>();
        EnemyData = enemyData;
        BattleBackgroundKey = battleBackgroundKey;
        BattleBgmKey = battleBgmKey;
        BossPhase2BgmKey = bossPhase2BgmKey;
        ShuffleSeed = shuffleSeed;
        PlayerMaxHp = playerMaxHp;
        PlayerMaxEnergy = playerMaxEnergy;
        PlayerCurrentHp = playerCurrentHp;
        DrawPerTurn = drawPerTurn;
        GetPersistentState = getPersistentState;
        TrimPersistentState = trimPersistentState;
        GetCardCostDelta = getCardCostDelta;
        GridRows = gridRows;
        GridColumns = gridColumns;
        IsTutorialBattle = isTutorialBattle;
        TutorialGridRows = tutorialGridRows;
        TutorialGridColumns = tutorialGridColumns;
        TutorialDeckCards = tutorialDeckCards ?? Array.Empty<CardDataSO>();
        TutorialDeckForcedArrows = tutorialDeckForcedArrows ?? Array.Empty<ECardDirection>();
        TutorialFirstDrawCardIds = tutorialFirstDrawCardIds ?? Array.Empty<string>();
        TutorialSeedCards = tutorialSeedCards ?? Array.Empty<BattleStartGridSeedCard>();
        Preserve = preserveConfig ?? PreserveConfig.None;
    }
}
