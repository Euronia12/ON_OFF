// =================================================================
// [스크립트 목적]  턴 종료 카드 보존(Retain) 설정 DTO (POCO). 런 → 전투 경계.
//                 "전체 보존인가 / 몇 장까지 보존 가능한가 / 증가 시 어디에 반영하나"를 묶는다.
// [주요 변수]      - PreserveAll       : true 면 선택 없이 전부 유지(선택 페이즈 스킵)
//                  - MaxPreserveCount  : 보존 선택 가능 최대 장수 (런 단위 값)
//                  - OnMaxCountChanged : 전투 중 보존 한도 증가 시 런에 반영하는 콜백(선택)
// [의존 관계]      - InGameController(생성) → BattleStartContext → BattleManager(소비)
// [설계 노트]      - BattleStartContext 생성자 비대화 방지를 위해 보존 설정을 1개 객체로 응집.
//                  - 보존 한도 원장은 RunContext 소유. 전투 중 증가분은 OnMaxCountChanged 로
//                    즉시 런에 역반영해 다음 전투까지 이어지게 한다(같은 런 한정).
//                  - PreserveAll=true 면 MaxPreserveCount 는 무의미(전부 유지).
// =================================================================

using System;

/// <summary>
/// 턴 종료 카드 보존 규칙. 전투가 RunContext 를 모르게 유지하면서
/// 보존 한도(런 단위)와 그 증감 반영 경로만 경계 객체로 넘긴다.
/// </summary>
public sealed class PreserveConfig
{
    /// <summary>전체 보존 모드. true 면 선택 페이즈 없이 그리드 카드를 전부 유지한다.</summary>
    public bool PreserveAll { get; }

    /// <summary>보존 선택 가능한 최대 장수 (n장 모드에서만 의미). 0 이면 보존 불가.</summary>
    public int MaxPreserveCount { get; }

    /// <summary>
    /// 전투 중 보존 한도가 증가했을 때 런에 반영하는 콜백 (새 한도 값 전달). null 허용.
    /// 아레나·튜토리얼 등 런이 없는 전투에서는 null 로 둔다.
    /// </summary>
    public Action<int> OnMaxCountChanged { get; }

    public PreserveConfig(bool preserveAll, int maxPreserveCount, Action<int> onMaxCountChanged = null)
    {
        PreserveAll = preserveAll;
        MaxPreserveCount = maxPreserveCount < 0 ? 0 : maxPreserveCount;
        OnMaxCountChanged = onMaxCountChanged;
    }

    /// <summary>보존 기능이 꺼진 기본값 (전부 묘지행, 보존 0장). 폴백용.</summary>
    public static PreserveConfig None => new PreserveConfig(false, 0, null);

    /// <summary>전체 보존 프리셋 (기존 동작 — 그리드 카드 전부 유지).</summary>
    public static PreserveConfig All => new PreserveConfig(true, 0, null);
}
