// =================================================================
// [스크립트 목적]  전투 1회의 카드 흐름(덱/핸드/묘지) 관리 + ICardGameService 구현
// [주요 변수]      - _drawPile    : 뽑을 더미 (뒤에서 Draw)
//                  - _hand        : 현재 손패
//                  - _discardPile : 버린 더미 (덱 소진 시 셔플되어 덱으로 복귀)
//                  - _rng         : 셔플용 난수 (추후 seed 주입 지점)
// [의존 관계]      - Card / CardFactory / StartingDeckSO / ICardGameService
//                  - BattleManager·InGameController 가 보유, CardPhaseDispatcher 에 Service 로 주입
// [설계 노트]      - SceneSingleton 아님(POCO): 전투 한정 생명주기 → 결합 최소화
//                    InGameController 가 생성·소유하고 필요한 곳에 주입한다
//                  - DrawCardEffect 가 Service.DrawCards 로 이 시스템을 건드린다
//                  - 실제 UICard 스폰/연출은 3단계에서 OnCardsDrawn 콜백으로 위임
//                    (DeckSystem 은 "데이터" 만 책임, 비주얼은 모름 — 로직/비주얼 경계)
// =================================================================

using System;
using System.Collections.Generic;
using System.Threading;
using Cysharp.Threading.Tasks;
using UnityEngine;

/// <summary>
/// 전투 1회 동안의 카드 흐름을 관리하는 시스템 (덱 → 핸드 → 묘지 → 셔플 복귀).
/// 순수 데이터 컨테이너이며 비주얼/연출을 직접 다루지 않는다 (콜백으로 외부에 통지).
/// ICardGameService(효과용 드로우/에너지) + ICardZoneService(흐름용 영역 이동)를 함께 구현하여
/// 단일 저장소로 덱/핸드/묘지를 관리한다 (zip 의 CardZoneController/Deck/Hand/Graveyard 폐기·통합).
/// 전투 시작 시 시작 덱(StartingDeckSO)으로 초기화하고, 종료 시 폐기한다.
/// </summary>
public sealed class DeckSystem : ICardGameService, ICardZoneService
{
    private const int TURN_START_BLOCK_ROLL_RANGE = 100;
    private const int TURN_START_BLOCK_ONE_THRESHOLD = 50;
    private const int TURN_START_BLOCK_TWO_THRESHOLD = 80;
    private const int TURN_START_BLOCK_THREE_THRESHOLD = 99;

    // ── 카드 더미 (데이터) ──────────────────────────────────
    private readonly List<Card> _drawPile = new List<Card>(32);
    private readonly List<Card> _hand = new List<Card>(16);
    private readonly List<Card> _discardPile = new List<Card>(32);
    private readonly List<Card> _exhaustPile = new List<Card>(16);
    private readonly List<Card> _turnStartDrawBuffer = new List<Card>(16);
    private readonly List<string> _nextTurnStartDrawOrder = new List<string>(16);

    // 셔플용 난수. [추정 구현] 추후 seed 기반 RunManager 에서 주입받도록 교체 가능.
    private System.Random _rng;

    // 손패 상한. 기본 무제한 — BattleController 가 전투 시작 시 SetMaxHandSize 로 주입한다.
    // (주입 전에는 기존 동작인 무제한을 유지해 다른 조립 경로의 회귀를 막는다)
    private int _maxHandSize = int.MaxValue;

    // ── 조회 (읽기 전용 노출) ───────────────────────────────

    /// <summary>뽑을 더미 카드 수.</summary>
    public int DrawCount => _drawPile.Count;

    /// <summary>현재 손패 카드 수.</summary>
    public int HandCount => _hand.Count;

    /// <summary>손에 들 수 있는 최대 카드 수.</summary>
    public int MaxHandSize => _maxHandSize;

    /// <summary>손패가 상한에 도달했는가. true 면 드로우한 카드는 손에 들어오지 못하고 묘지로 간다.</summary>
    public bool IsHandFull => _hand.Count >= _maxHandSize;

    /// <summary>버린 더미 카드 수.</summary>
    public int DiscardCount => _discardPile.Count;

    /// <summary>현재 손패 (읽기 전용).</summary>
    public IReadOnlyList<Card> Hand => _hand;

    /// <summary>현재 드로우 더미 (읽기 전용).</summary>
    public IReadOnlyList<Card> DrawPile => _drawPile;

    /// <summary>현재 버린 더미 (읽기 전용).</summary>
    public IReadOnlyList<Card> DiscardPile => _discardPile;
    public IReadOnlyList<Card> ExhaustPile => _exhaustPile;

    // ── 이벤트 (비주얼/연출 위임 — 3단계에서 구독) ──────────

    /// <summary>카드가 손패에 들어왔을 때. (UICard 스폰·드로우 연출 트리거)</summary>
    public event Action<Card> OnCardDrawn;

    /// <summary>카드 효과로 인해 카드가 손패에 들어왔을 때. source 가 있는 DrawCards 경로만 발행한다.</summary>
    public event Action<Card, Card> OnCardDrawnByCardEffect;

    /// <summary>덱과 묘지가 모두 비어 드로우에 실패했을 때.</summary>
    public event Action<Card> OnDrawFailedNoCards;

    /// <summary>손패가 가득 차 드로우한 카드가 손에 들어오지 못하고 묘지로 갔을 때.</summary>
    public event Action<Card> OnDrawDiscardedHandFull;

    /// <summary>카드가 손패에서 묘지로 갔을 때. (디스카드 연출 트리거)</summary>
    public event Action<Card> OnCardDiscarded;

    /// <summary>카드가 이번 전투의 소멸 더미로 이동했을 때.</summary>
    public event Action<Card> OnCardExhausted;

    /// <summary>덱 구성(셔플 등)이 변해 UI 카운터 갱신이 필요할 때.</summary>
    public event Action OnPilesChanged;

    // 에너지 획득 위임 — PlayerActor.GainEnergy 로 라우팅 (조립 시 주입).
    // DeckSystem 은 액터를 모르므로 콜백으로 결합을 끊는다.
    private System.Action<int> _onGainEnergy;
    private BattleReactiveEventBus _reactiveEvents;

    /// <param name="rng">셔플 난수. null 이면 시간 기반 기본 생성 (비결정적).</param>
    public DeckSystem(System.Random rng = null)
    {
        _rng = rng ?? new System.Random();
    }

    /// <summary>
    /// 전투 전용 난수 스트림을 지정한 시드의 시작 상태로 되돌린다.
    /// 덱 초기화 전에 전투당 한 번만 호출해야 같은 전투의 카드 흐름을 재현할 수 있다.
    /// </summary>
    public void ResetRandom(int seed)
    {
        _rng = new System.Random(seed);
    }

    /// <summary>손패 상한 주입 (전투 시작 시 1회). 1 미만은 1 로 보정.</summary>
    public void SetMaxHandSize(int max)
    {
        _maxHandSize = Mathf.Max(1, max);
    }

    // ── 초기화 ──────────────────────────────────────────────

    /// <summary>
    /// 시작 덱으로 초기화. 기존 더미를 모두 비우고 새 카드로 채운 뒤 셔플한다.
    /// 전투 시작 시 1회 호출.
    /// </summary>
    public void InitializeFromStartingDeck(StartingDeckSO startingDeck)
    {
        ClearAll();

        if (startingDeck == null)
        {
            Debug.LogError("[DeckSystem] StartingDeckSO 가 null 입니다. 빈 덱으로 시작합니다.");
            return;
        }

        List<Card> cards = startingDeck.BuildCards();
        _drawPile.AddRange(cards);
        Shuffle(_drawPile);

        OnPilesChanged?.Invoke();

#if UNITY_EDITOR || DEVELOPMENT_BUILD
        Debug.Log($"[DeckSystem] 시작 덱 초기화 — {_drawPile.Count}장 (덱: {startingDeck.DeckType})");
#endif
    }

    /// <summary>이미 만들어진 카드 리스트로 초기화 (세션 카드 풀 주입용 대안 경로).</summary>
    public void InitializeFromCards(IReadOnlyList<Card> cards)
    {
        ClearAll();
        if (cards != null)
        {
            for (int i = 0; i < cards.Count; i++)
            {
                if (cards[i] != null) _drawPile.Add(cards[i]);
            }
        }
        Shuffle(_drawPile);
        OnPilesChanged?.Invoke();
    }

    // ── 드로우 / 디스카드 ───────────────────────────────────

    /// <summary>
    /// 턴 시작 드로우. 현재 드로우 더미에서 방어 효과 카드를 확률적으로 먼저 고른 뒤
    /// 나머지는 비방어 카드로 채운다. 실제 영역 이동과 이벤트 발행은 DrawCards 에 위임한다.
    /// </summary>
    public void DrawTurnStartCards(int count)
    {
        if (count <= 0)
        {
            DrawCards(count);
            return;
        }

        if (_drawPile.Count == 0)
        {
            ReshuffleDiscardIntoDraw();
        }

        int prepareCount = Mathf.Min(count, _drawPile.Count);
        if (prepareCount > 0)
        {
            _turnStartDrawBuffer.Clear();

            if (_nextTurnStartDrawOrder.Count > 0)
            {
                MoveOrderedTurnStartCards(prepareCount);
            }
            else
            {
                int blockCandidateCount = CountTurnStartCandidates(hasBlockEffect: true);
                if (blockCandidateCount > 0)
                {
                    int blockDrawCount = Mathf.Min(prepareCount, RollTurnStartBlockDrawCount());
                    MoveRandomTurnStartCards(hasBlockEffect: true, blockDrawCount);
                }

                MoveRandomTurnStartCards(
                    hasBlockEffect: false,
                    prepareCount - _turnStartDrawBuffer.Count);
                MoveRandomTurnStartCards(
                    hasBlockEffect: true,
                    prepareCount - _turnStartDrawBuffer.Count);
            }

            for (int i = _turnStartDrawBuffer.Count - 1; i >= 0; i--)
            {
                _drawPile.Add(_turnStartDrawBuffer[i]);
            }

            _turnStartDrawBuffer.Clear();
        }
        _nextTurnStartDrawOrder.Clear();

        DrawCards(count);
    }

    /// <summary>다음 턴 시작 드로우에서 우선할 카드 ID 순서를 1회 예약한다.</summary>
    public void SetNextTurnStartDrawOrder(IReadOnlyList<string> cardIds)
    {
        _nextTurnStartDrawOrder.Clear();
        if (cardIds == null) return;

        for (int i = 0; i < cardIds.Count; i++)
        {
            if (!string.IsNullOrEmpty(cardIds[i]))
                _nextTurnStartDrawOrder.Add(cardIds[i]);
        }
    }

    /// <summary>
    /// 카드 count 장 드로우. 덱이 비면 묘지를 셔플해 덱으로 되돌린 뒤 계속 뽑는다.
    /// 양쪽 다 비면 더 못 뽑고 중단한다. ICardGameService.DrawCards 구현.
    /// </summary>
    public void DrawCards(int count, Card source = null)
    {
        int actualDrawCount = 0;
        for (int i = 0; i < count; i++)
        {
            if (_drawPile.Count == 0)
            {
                ReshuffleDiscardIntoDraw();
                if (_drawPile.Count == 0)
                {
                    // 뽑을 카드가 완전히 소진됨.
#if UNITY_EDITOR || DEVELOPMENT_BUILD
                    Debug.Log("[DeckSystem] 더 뽑을 카드가 없습니다.");
#endif
                    OnDrawFailedNoCards?.Invoke(source);
                    break;
                }
            }

            // 더미 끝에서 뽑기 (List 끝 제거 = O(1), GC 없음).
            int last = _drawPile.Count - 1;
            Card card = _drawPile[last];
            _drawPile.RemoveAt(last);

            if (AddDrawnCardToHand(card, source))
                actualDrawCount++;
        }

        PublishDrawEffectResolved(source, actualDrawCount);
        if (actualDrawCount > 0 && AudioManager.HasInstance)
            AudioManager.Instance.PlaySfxAsync(AudioKeys.Card.DRAW).Forget();
        OnPilesChanged?.Invoke();
    }

    /// <summary>
    /// 카드 count 장 드로우. 덱이 비면 묘지→덱 연출을 먼저 기다린 뒤 셔플한다.
    /// 턴 시작 드로우처럼 전투 흐름이 연출 대기를 알아야 하는 경로에서 사용한다.
    /// </summary>
    public async UniTask DrawCardsAsync(
        int count,
        Func<int, UniTask> onReshuffleAsync,
        CancellationToken token = default,
        Card source = null)
    {
        int actualDrawCount = 0;
        for (int i = 0; i < count; i++)
        {
            if (_drawPile.Count == 0)
            {
                int discardCount = _discardPile.Count;
                if (discardCount > 0 && onReshuffleAsync != null)
                {
                    await onReshuffleAsync(discardCount);
                    if (token.IsCancellationRequested) return;
                }

                ReshuffleDiscardIntoDraw();
                if (_drawPile.Count == 0)
                {
#if UNITY_EDITOR || DEVELOPMENT_BUILD
                    Debug.Log("[DeckSystem] 더 뽑을 카드가 없습니다.");
#endif
                    OnDrawFailedNoCards?.Invoke(source);
                    break;
                }
            }

            int last = _drawPile.Count - 1;
            Card card = _drawPile[last];
            _drawPile.RemoveAt(last);

            if (AddDrawnCardToHand(card, source))
                actualDrawCount++;
        }

        PublishDrawEffectResolved(source, actualDrawCount);
        if (actualDrawCount > 0 && AudioManager.HasInstance)
            AudioManager.Instance.PlaySfxAsync(AudioKeys.Card.DRAW).Forget();
        OnPilesChanged?.Invoke();
    }

    /// <summary>
    /// 덱에서 뽑은 카드 1장을 손패에 넣는다. 손패가 상한에 도달해 있으면 드로우 실패로 처리하고
    /// 그 카드를 곧바로 묘지로 보낸다. 손패에 실제로 들어갔으면 true.
    /// DrawCards / DrawCardsAsync 공용 — 두 경로가 같은 상한 규칙을 타게 한다.
    /// </summary>
    private bool AddDrawnCardToHand(Card card, Card source)
    {
        if (card == null) return false;

        if (IsHandFull)
        {
            DiscardOverflowDraw(card);
            return false;
        }

        _hand.Add(card);
        OnCardDrawn?.Invoke(card);
        if (source != null)
        {
            OnCardDrawnByCardEffect?.Invoke(card, source);
        }

        PublishCardEvent(EReactiveEventType.CardDrawn, card);
        return true;
    }

    /// <summary>
    /// 손패 상한 초과로 손에 못 들어온 카드를 묘지로 보낸다.
    /// OnCardDrawn 을 쏘지 않으므로 손패 UICard 가 생성되지 않는다 → 디스카드 연출 대상도 없다.
    /// 반응형 이벤트(CardDiscarded)는 발행해 '버려짐' 시너지 효과와 일관성을 유지한다.
    /// 묘지 편입 규칙(VanishesOnDiscard)은 DiscardFromHand 와 동일하게 따른다.
    /// </summary>
    private void DiscardOverflowDraw(Card card)
    {
        if (card == null) return;

        card.ClearRecallCostOverride();
        if (!card.VanishesOnDiscard)
        {
            _discardPile.Add(card);
        }

        OnDrawDiscardedHandFull?.Invoke(card);
        PublishCardEvent(EReactiveEventType.CardDiscarded, card);

#if UNITY_EDITOR || DEVELOPMENT_BUILD
        Debug.Log($"[DeckSystem] 손패 상한({_maxHandSize})으로 드로우 실패 — '{card.CardId}' 묘지行");
#endif
    }

    /// <summary>
    /// 이미 생성된 카드 1장을 곧바로 손패에 추가한다 (ICardGameService).
    /// 새끼낳기처럼 효과가 즉석에서 만든 카드를 손패에 넣을 때 사용. 손패가 가득 차면 무시한다.
    /// </summary>
    public void AddCardToHand(Card card)
    {
        if (card == null) return;

        _hand.Add(card);
        OnCardDrawn?.Invoke(card);
        PublishCardEvent(EReactiveEventType.CardDrawn, card);
        OnPilesChanged?.Invoke();
    }

    /// <summary>특정 손패 카드 1장을 묘지로 보낸다 (카드 배치/사용 후 호출).</summary>
    public void DiscardFromHand(Card card)
    {
        if (card == null) return;
        if (!_hand.Remove(card)) return;

        card.ClearRecallCostOverride();
        if (card.VanishesOnDiscard)
        {
            OnCardDiscarded?.Invoke(card);
            PublishCardEvent(EReactiveEventType.CardDiscarded, card);
            OnPilesChanged?.Invoke();
            return;
        }

        _discardPile.Add(card);
        OnCardDiscarded?.Invoke(card);
        PublishCardEvent(EReactiveEventType.CardDiscarded, card);
        PlayDiscardSfx();
        OnPilesChanged?.Invoke();
    }

    /// <summary>손패 전체를 묘지로 (턴 종료). 손패 전용 방해 카드는 묘지 없이 제거한다.</summary>
    public void DiscardHand()
    {
        int discarded = 0;
        int vanished = 0;
        // 역순 순회 — 제거하며 인덱스 안전.
        for (int i = _hand.Count - 1; i >= 0; i--)
        {
            Card card = _hand[i];
            _hand.RemoveAt(i);

            if (card == null) continue;

            card.ClearRecallCostOverride();
            if (card.IsHandOnlyDisturbance || card.VanishesOnDiscard)
            {
                vanished++;
            }
            else
            {
                _discardPile.Add(card);
                discarded++;
            }

            OnCardDiscarded?.Invoke(card);
            PublishCardEvent(EReactiveEventType.CardDiscarded, card);
        }

        OnPilesChanged?.Invoke();

        if (discarded > 0)
            PlayDiscardSfx();

#if UNITY_EDITOR || DEVELOPMENT_BUILD
        Debug.Log($"[DeckSystem] DiscardHand — {discarded}장 묘지行, {vanished}장 제거 (남은 손패 {_hand.Count}, 묘지 {_discardPile.Count})");
#endif
    }

    // ── ICardZoneService (전투 흐름이 쓰는 영역 이동) ───────

    /// <summary>
    /// 핸드 → 필드(그리드) 배치 성공 시 호출. 핸드에서 카드를 제거한다.
    /// 그리드에 올라간 카드는 GridManager 가 소유하며, 묘지行은 턴 종료 회수 시
    /// DiscardFromField 로 처리된다. (배치 시점엔 묘지로 보내지 않음)
    /// </summary>
    public void OnCardPlayedToField(Card card)
    {
        if (card == null) return;
        _hand.Remove(card);
        card.ClearRecallCostOverride();
        OnPilesChanged?.Invoke();
    }

    /// <summary>
    /// 필드 → 묘지 (그리드에서 회수된 카드를 묘지로).
    /// 턴 종료 시 보존되지 않은 그리드 카드를 BattleManager 가 모아 이 메서드로 넘긴다.
    /// </summary>
    public void DiscardFromField(Card card)
    {
        if (card == null) return;
        card.ClearRecallCostOverride();
        if (card.VanishesOnDiscard)
        {
            // 전투 한정 생성 카드: 묘지 편입 대신 소멸 (그리드 미보존 시 사라짐).
            OnCardDiscarded?.Invoke(card);
            PublishCardEvent(EReactiveEventType.CardDiscarded, card);
            OnPilesChanged?.Invoke();
            return;
        }

        _discardPile.Add(card);
        OnCardDiscarded?.Invoke(card);
        PublishCardEvent(EReactiveEventType.CardDiscarded, card);
        OnPilesChanged?.Invoke();
    }

    /// <summary>필드 카드를 손패로 되돌리고, 기존 드로우 UI 생성 경로를 재사용한다.</summary>
    public void ReturnFieldCardToHand(Card card)
    {
        if (card == null) return;
        if (!_hand.Contains(card))
            _hand.Add(card);
        OnCardDrawn?.Invoke(card);
        PublishCardEvent(EReactiveEventType.CardDrawn, card);
        OnPilesChanged?.Invoke();
    }

    /// <summary>드로우 더미에 카드 1장을 추가하고 섞는다.</summary>
    public void AddCardToDrawPileAndShuffle(
        Card card,
        EBattleDeckOwner owner = EBattleDeckOwner.PlayerTemporary)
    {
        if (card == null) return;

        card.SetBattleDeckOwner(owner);
        _drawPile.Add(card);
        Shuffle(_drawPile);
        OnPilesChanged?.Invoke();
    }

    /// <summary>필드 카드를 이번 전투의 소멸 더미로 이동한다.</summary>
    public void ExhaustFromField(Card card)
    {
        ExhaustCard(card);
    }

    /// <summary>현재 전투에 존재하는 카드 중 지정 출처의 카드들을 수집한다.</summary>
    public void GetCardsByOwner(EBattleDeckOwner owner, List<Card> results)
    {
        if (results == null) return;
        results.Clear();
        AddOwnedCards(_drawPile, owner, results);
        AddOwnedCards(_hand, owner, results);
        AddOwnedCards(_discardPile, owner, results);
        AddOwnedCards(_exhaustPile, owner, results);
    }

    public void GetAllCards(List<Card> results)
    {
        if (results == null) return;
        results.Clear();
        AddCards(_drawPile, results);
        AddCards(_hand, results);
        AddCards(_discardPile, results);
        AddCards(_exhaustPile, results);
    }

    // ── ICardGameService ────────────────────────────────────

    /// <summary>
    /// 전투 시작 시 첫 손패 드로우. DrawCards 와 동일하게 동작하되
    /// "초기 드로우"임을 명시적으로 분리 (추후 머리가지 카드·저주 등 특수 처리 지점).
    /// </summary>
    public void DrawInitialHand(int count)
    {
        DrawCards(count);
    }

    /// <summary>에너지 획득 (ICardGameService). 주입된 핸들러(PlayerActor.GainEnergy)로 위임.</summary>
    public void GainEnergy(int amount)
    {
        if (_onGainEnergy != null)
        {
            _onGainEnergy.Invoke(amount);
        }
#if UNITY_EDITOR || DEVELOPMENT_BUILD
        else
        {
            Debug.Log($"[DeckSystem] GainEnergy {amount} (에너지 핸들러 미주입)");
        }
#endif
    }

    public void ExhaustCard(Card card)
    {
        if (card == null) return;
        if (_exhaustPile.Contains(card)) return;

        _drawPile.Remove(card);
        bool removedFromHand = _hand.Remove(card);
        _discardPile.Remove(card);

        card.ClearRecallCostOverride();
        _exhaustPile.Add(card);
        if (removedFromHand)
        {
            OnCardExhausted?.Invoke(card);
        }
        PublishCardEvent(EReactiveEventType.CardExhausted, card);
        OnPilesChanged?.Invoke();
    }

    private static void AddOwnedCards(
        List<Card> source,
        EBattleDeckOwner owner,
        List<Card> results)
    {
        for (int i = 0; i < source.Count; i++)
        {
            Card card = source[i];
            if (card != null && card.BattleDeckOwner == owner && !results.Contains(card))
            {
                results.Add(card);
            }
        }
    }

    private static void AddCards(List<Card> source, List<Card> results)
    {
        for (int i = 0; i < source.Count; i++)
        {
            Card card = source[i];
            if (card != null && !results.Contains(card))
            {
                results.Add(card);
            }
        }
    }

    // ── 내부 ───────────────────────────────────────────────

    private int RollTurnStartBlockDrawCount()
    {
        int roll = _rng.Next(TURN_START_BLOCK_ROLL_RANGE);
        if (roll < TURN_START_BLOCK_ONE_THRESHOLD) return 1;
        if (roll < TURN_START_BLOCK_TWO_THRESHOLD) return 2;
        if (roll < TURN_START_BLOCK_THREE_THRESHOLD) return 3;
        return 4;
    }

    private int CountTurnStartCandidates(bool hasBlockEffect)
    {
        int count = 0;
        for (int i = 0; i < _drawPile.Count; i++)
        {
            Card card = _drawPile[i];
            bool cardHasBlock = card != null && card.HasEffect(ECardEffectFlag.Block);
            if (cardHasBlock == hasBlockEffect)
            {
                count++;
            }
        }

        return count;
    }

    private void MoveOrderedTurnStartCards(int count)
    {
        int targetCount = Mathf.Min(count, _nextTurnStartDrawOrder.Count);
        for (int orderIndex = 0; orderIndex < targetCount; orderIndex++)
        {
            string cardId = _nextTurnStartDrawOrder[orderIndex];
            for (int pileIndex = 0; pileIndex < _drawPile.Count; pileIndex++)
            {
                Card card = _drawPile[pileIndex];
                if (card == null || card.CardId != cardId) continue;

                _drawPile.RemoveAt(pileIndex);
                _turnStartDrawBuffer.Add(card);
                break;
            }
        }
    }

    private void MoveRandomTurnStartCards(bool hasBlockEffect, int count)
    {
        for (int moved = 0; moved < count; moved++)
        {
            int candidateCount = CountTurnStartCandidates(hasBlockEffect);
            if (candidateCount == 0) return;

            int candidateIndex = _rng.Next(candidateCount);
            for (int i = 0; i < _drawPile.Count; i++)
            {
                Card card = _drawPile[i];
                bool cardHasBlock = card != null && card.HasEffect(ECardEffectFlag.Block);
                if (cardHasBlock != hasBlockEffect) continue;
                if (candidateIndex-- > 0) continue;

                _drawPile.RemoveAt(i);
                _turnStartDrawBuffer.Add(card);
                break;
            }
        }
    }

    /// <summary>묘지를 셔플해 덱(드로우 더미)으로 되돌린다.</summary>
    private void ReshuffleDiscardIntoDraw()
    {
        if (_discardPile.Count == 0) return;

        _drawPile.AddRange(_discardPile);
        _discardPile.Clear();
        Shuffle(_drawPile);
        if (AudioManager.HasInstance)
            AudioManager.Instance.PlaySfxAsync(AudioKeys.Card.RESHUFFLE).Forget();

#if UNITY_EDITOR || DEVELOPMENT_BUILD
        Debug.Log($"[DeckSystem] 묘지 → 덱 재셔플 ({_drawPile.Count}장)");
#endif
    }

    /// <summary>카드가 실제 묘지에 편입된 단일/일괄 처리의 완료음.</summary>
    private static void PlayDiscardSfx()
    {
        if (AudioManager.HasInstance)
            AudioManager.Instance.PlaySfxAsync(AudioKeys.Card.DISCARD).Forget();
    }

    /// <summary>Fisher-Yates 셔플 (제자리, GC 없음).</summary>
    private void Shuffle(List<Card> list)
    {
        for (int i = list.Count - 1; i > 0; i--)
        {
            int j = _rng.Next(i + 1);
            (list[i], list[j]) = (list[j], list[i]);
        }
    }

    /// <summary>모든 더미 비우기 (전투 종료·재시작).</summary>
    public void ClearAll()
    {
        ClearRecallCostOverrides(_drawPile);
        ClearRecallCostOverrides(_hand);
        ClearRecallCostOverrides(_discardPile);
        ClearRecallCostOverrides(_exhaustPile);
        _drawPile.Clear();
        _hand.Clear();
        _discardPile.Clear();
        _exhaustPile.Clear();
        _nextTurnStartDrawOrder.Clear();
        OnPilesChanged?.Invoke();
    }

    /// <summary>에너지 획득 핸들러 주입 (BattleController 조립 시 player.GainEnergy 연결).</summary>
    public void SetEnergyHandler(System.Action<int> onGainEnergy)
    {
        _onGainEnergy = onGainEnergy;
    }

    public void SetReactiveEventBus(BattleReactiveEventBus reactiveEvents)
    {
        _reactiveEvents = reactiveEvents;
    }

    private void PublishDrawEffectResolved(Card source, int actualDrawCount)
    {
        if (_reactiveEvents == null || source == null || actualDrawCount <= 0)
        {
            return;
        }

        _reactiveEvents.Publish(new BattleReactiveEvent(
            EReactiveEventType.DrawEffectResolved,
            sourceCard: source,
            amount: actualDrawCount,
            owner: source.BattleDeckOwner));
    }

    private void PublishCardEvent(EReactiveEventType type, Card card)
    {
        if (_reactiveEvents == null || card == null)
        {
            return;
        }

        _reactiveEvents.Publish(new BattleReactiveEvent(
            type,
            sourceCard: card,
            targetCard: card,
            owner: card.BattleDeckOwner));
    }

    private static void ClearRecallCostOverrides(List<Card> cards)
    {
        for (int i = 0; i < cards.Count; i++)
            cards[i]?.ClearRecallCostOverride();
    }
}
