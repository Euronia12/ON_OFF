// =================================================================
// [스크립트 목적]  적 선형 공격의 예정 행을 짧은 선분과 화살표 스프라이트로 표시
// [의존 관계]      - GridManager / GridSlot / SpriteRenderer
// [설계 노트]      - 스프라이트는 중심 Pivot, 오른쪽 방향을 기준으로 인스펙터에서 연결한다.
// =================================================================

using System.Collections.Generic;
using DG.Tweening;
using UnityEngine;

[DisallowMultipleComponent]
public sealed class EnemyLineIntentWarningPresenter : MonoBehaviour
{
    private sealed class LineState
    {
        public Transform[] Elements { get; }
        public SpriteRenderer[] Renderers { get; }
        public float LoopStart { get; }
        public float LoopLength { get; }
        public float HalfDistance { get; }

        public LineState(
            Transform[] elements,
            SpriteRenderer[] renderers,
            float loopStart,
            float loopLength,
            float halfDistance)
        {
            Elements = elements;
            Renderers = renderers;
            LoopStart = loopStart;
            LoopLength = loopLength;
            HalfDistance = halfDistance;
        }
    }

    [Header("스프라이트")]
    [Tooltip("공격 경로를 따라 일정 간격으로 반복 배치할 짧은 선분 스프라이트")]
    [SerializeField] private Sprite _segmentSprite;
    [Tooltip("한 칸씩 건너 선분 위에 겹쳐 표시할 오른쪽 방향 화살표 스프라이트")]
    [SerializeField] private Sprite _arrowSprite;

    [Header("배치")]
    [Tooltip("선분 스프라이트 중심 사이의 간격")]
    [Min(0.01f)]
    [SerializeField] private float _segmentSpacing = 0.45f;
    [Tooltip("그리드 양쪽 외곽에서 경고선을 추가로 연장할 거리")]
    [Min(0f)]
    [SerializeField] private float _outsidePadding = 0.2f;
    [Tooltip("각 선분 스프라이트에 적용할 로컬 크기")]
    [SerializeField] private Vector2 _segmentScale = Vector2.one;
    [Tooltip("선분 위에 겹쳐지는 화살표 스프라이트에 적용할 로컬 크기")]
    [SerializeField] private Vector2 _arrowScale = Vector2.one;
    [Tooltip("방향선이 실제 베기 방향으로 이동하는 속도(유닛/초)")]
    [Min(0f)]
    [SerializeField] private float _scrollSpeed = 0.6f;
    [Tooltip("경고선 시작점과 끝점에서 스프라이트가 나타나고 사라지는 거리(유닛)")]
    [Min(0f)]
    [SerializeField] private float _edgeFadeDistance = 0.6f;
    [Tooltip("그리드 평면과 겹치지 않도록 적용할 로컬 Z 위치 보정값")]
    [SerializeField] private float _zOffset = -0.05f;
    [Tooltip("FrontEffect 정렬 레이어 안에서 사용할 렌더링 순서")]
    [SerializeField] private int _sortingOrder = 1000;

    [Header("점등")]
    [Tooltip("경고선 점등 중 가장 낮아지는 알파값")]
    [Range(0f, 1f)]
    [SerializeField] private float _pulseMinAlpha = 0.35f;
    [Tooltip("경고선 알파가 최대값에서 최저값까지 변하는 시간(초)")]
    [Min(0.01f)]
    [SerializeField] private float _pulseDuration = 2f;

    private readonly List<LineState> _lineStates = new List<LineState>();
    private GameObject _warningRoot;
    private Tween _pulseTween;
    private float _warningAlpha = 1f;

    private void Update()
    {
        if (_warningRoot == null) return;

        float movement = _scrollSpeed * Time.deltaTime;
        for (int i = 0; i < _lineStates.Count; i++)
        {
            LineState state = _lineStates[i];
            Transform[] elements = state.Elements;
            SpriteRenderer[] renderers = state.Renderers;
            for (int j = 0; j < elements.Length; j++)
            {
                Transform element = elements[j];
                if (element == null) continue;

                Vector3 position = element.localPosition;
                if (movement > 0f)
                {
                    position.x = state.LoopStart + Mathf.Repeat(
                        position.x + movement - state.LoopStart,
                        state.LoopLength);
                }
                element.localPosition = position;

                SpriteRenderer renderer = renderers[j];
                if (renderer == null) continue;

                Color color = renderer.color;
                color.a = _warningAlpha * GetEdgeAlpha(position.x, state.HalfDistance);
                renderer.color = color;
            }
        }
    }

    /// <summary>
    /// 라인 하나의 경고 스프라이트를 표시한다. 여러 번 호출하면 라인이 누적된다(이전 것을 지우지 않음).
    /// 새 경고 세트를 시작하려면 먼저 Clear() 를 호출한다.
    /// </summary>
    public void Show(IReadOnlyList<GridSlot> slots)
    {
        if (slots == null || slots.Count == 0) return;

        GridSlot first = slots[0];
        GridSlot last = slots[slots.Count - 1];
        if (first == null || last == null) return;

        // 여러 라인을 한 root 에 누적. 없을 때만 새로 만든다.
        if (_warningRoot == null)
        {
            _warningRoot = new GameObject("EnemyLineIntentWarning");
            _warningRoot.transform.SetParent(transform, false);
            StartPulse();
        }

        Vector3 start = transform.InverseTransformPoint(first.transform.position);
        Vector3 end = transform.InverseTransformPoint(last.transform.position);
        float centerDistance = Vector3.Distance(start, end);
        Vector3 direction = centerDistance > 0f ? (end - start) / centerDistance : Vector3.right;
        float cellSize = slots.Count > 1 ? centerDistance / (slots.Count - 1) : 0f;
        float extension = cellSize * 0.5f + _outsidePadding;
        start -= direction * extension;
        end += direction * extension;
        float distance = Vector3.Distance(start, end);
        float angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg;

        GameObject lineObject = new GameObject("Line");
        lineObject.transform.SetParent(_warningRoot.transform, false);
        lineObject.transform.localPosition = (start + end) * 0.5f + Vector3.forward * _zOffset;
        lineObject.transform.localRotation = Quaternion.Euler(0f, 0f, angle);

        float loopStart = -distance * 0.5f - _segmentSpacing;
        int elementCount = Mathf.Max(2, Mathf.CeilToInt(
            (distance + _segmentSpacing * 2f) / _segmentSpacing));
        if ((elementCount & 1) != 0)
        {
            elementCount++;
        }

#if UNITY_EDITOR || DEVELOPMENT_BUILD
        Debug.Assert((elementCount & 1) == 0,
            $"{nameof(EnemyLineIntentWarningPresenter)}: 교차 패턴 요소 수는 짝수여야 합니다.", this);
#endif

        Transform[] elements = new Transform[elementCount];
        SpriteRenderer[] renderers = new SpriteRenderer[elementCount];
        float halfDistance = distance * 0.5f;
        for (int i = 0; i < elementCount; i++)
        {
            bool useArrow = (i & 1) != 0;
            Sprite sprite = useArrow ? _arrowSprite : _segmentSprite;
            Vector2 scale = useArrow ? _arrowScale : _segmentScale;
            SpriteRenderer renderer = CreateSprite(
                lineObject.transform,
                useArrow ? "Arrow" : "Segment",
                sprite,
                loopStart + i * _segmentSpacing,
                scale,
                halfDistance);
            renderers[i] = renderer;
            elements[i] = renderer != null ? renderer.transform : null;
        }

        _lineStates.Add(new LineState(
            elements,
            renderers,
            loopStart,
            elementCount * _segmentSpacing,
            halfDistance));
    }

    public void Clear()
    {
        StopPulse();
        _lineStates.Clear();
        if (_warningRoot == null) return;
        Destroy(_warningRoot);
        _warningRoot = null;
    }

    private void OnDisable()
    {
        Clear();
    }

    private SpriteRenderer CreateSprite(
        Transform parent,
        string objectName,
        Sprite sprite,
        float localX,
        Vector2 scale,
        float halfDistance)
    {
        if (sprite == null) return null;

        GameObject spriteObject = new GameObject(objectName);
        spriteObject.transform.SetParent(parent, false);
        spriteObject.transform.localPosition = new Vector3(localX, 0f, 0f);
        spriteObject.transform.localScale = new Vector3(scale.x, scale.y, 1f);

        SpriteRenderer renderer = spriteObject.AddComponent<SpriteRenderer>();
        renderer.sprite = sprite;
        Color color = renderer.color;
        color.a = _warningAlpha * GetEdgeAlpha(localX, halfDistance);
        renderer.color = color;
        renderer.sortingLayerName = "FrontEffect";
        renderer.sortingOrder = _sortingOrder;
        return renderer;
    }

    private float GetEdgeAlpha(float localX, float halfDistance)
    {
        float distanceInside = halfDistance - Mathf.Abs(localX);
        if (_edgeFadeDistance <= 0f)
        {
            return distanceInside >= 0f ? 1f : 0f;
        }

        return Mathf.Clamp01(distanceInside / _edgeFadeDistance);
    }

    private void StartPulse()
    {
        StopPulse();
        _pulseTween = DOTween.To(
                () => _warningAlpha,
                SetWarningAlpha,
                _pulseMinAlpha,
                _pulseDuration)
            .SetEase(Ease.InOutSine)
            .SetLoops(-1, LoopType.Yoyo);
    }

    private void StopPulse()
    {
        _pulseTween?.Kill();
        _pulseTween = null;
        _warningAlpha = 1f;
    }

    private void SetWarningAlpha(float alpha)
    {
        _warningAlpha = alpha;
    }
}
