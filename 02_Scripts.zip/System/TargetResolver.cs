﻿// =================================================================
// [스크립트 목적]  타겟 해결 구현 (ITargetResolver). ETargetType → 액터 목록.
//                 기존 SimpleTargetResolver 개명. 플레이어 1 + 적 1 (1:1 전투) 전제.
// [주요 변수]      - _player : 플레이어(아군) 액터
//                  - _enemy  : 적 액터 (단일 적 구조)
// [의존 관계]      - ITargetResolver / ICombatActor
//                  - CardPhaseDispatcher 가 효과 실행 전 호출
// [설계 노트]      - 1:1 전투. 다수 적/아군은 이 구현만 교체하면 확장 (디스패처 불변)
//                  - picked(플레이어 직접 선택 대상)는 단일 적 구조라 _enemy 로 폴백
//                  - result 는 호출부가 Clear 한 리스트로 전달 → Add 만 (재사용/GC 0)
// =================================================================

using System.Collections.Generic;

/// <summary>
/// 1:1 전투(플레이어 1 + 적 1)를 전제로 한 타겟 해결 구현.
/// ETargetType 분류를 받아 실제 대상 액터를 result 리스트에 채운다.
/// 다수 적/아군 구조가 필요해지면 이 구현만 교체하면 된다 (디스패처는 불변).
/// </summary>
public sealed class TargetResolver : ITargetResolver
{
    private ICombatActor _player;
    private ICombatActor _enemy;

    /// <summary>전투 시작 시 액터 주입. 적 교체(웨이브) 시 SetEnemy 로 갱신.</summary>
    public TargetResolver(ICombatActor player, ICombatActor enemy)
    {
        _player = player;
        _enemy = enemy;
    }

    /// <summary>플레이어 액터 갱신.</summary>
    public void SetPlayer(ICombatActor player) => _player = player;

    /// <summary>적 액터 갱신 (다음 적 등장 시).</summary>
    public void SetEnemy(ICombatActor enemy) => _enemy = enemy;

    /// <summary>대상 분류에 맞는 액터를 result 에 채운다 (호출부가 Clear 한 상태로 전달).</summary>
    public void Resolve(
        ETargetType targetType, ICombatActor caster, ICombatActor picked, List<ICombatActor> result)
    {
        switch (targetType)
        {
            case ETargetType.Self:
                AddIfValid(result, caster ?? _player);
                break;

            case ETargetType.SingleEnemy:
                // 단일 적 구조: picked 가 있으면 우선, 없으면 기본 적.
                AddIfValid(result, picked ?? _enemy);
                break;

            case ETargetType.AllEnemies:
            case ETargetType.RandomEnemy:
                // 적이 1명뿐이라 모두 동일 대상.
                AddIfValid(result, _enemy);
                break;
            case ETargetType.Card:

                break;
            case ETargetType.None:
                // 대상 없음 (드로우·자원 등). result 비움.
                break;
        }
    }

    /// <summary>null·중복이 아닌 경우에만 추가.</summary>
    private static void AddIfValid(List<ICombatActor> result, ICombatActor actor)
    {
        if (actor == null) return;
        if (result.Contains(actor)) return;
        result.Add(actor);
    }
}