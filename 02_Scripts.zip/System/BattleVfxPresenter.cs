// =================================================================
// [스크립트 목적]  전투 연출 프리젠터 (IChainPresenter). 체인 웨이브의 카드별 투사체·적중
//                 이펙트를 풀링으로 재생. 그리드 카드 위치(출발) → 타겟 View(도착).
// [주요 변수]      - _resolveCardWorldPos : 카드 → 월드 위치 조회 (조립 시 주입)
//                  - _enemyTarget/_playerTarget : 도착점 (ICombatTarget)
//                  - _projectileSpeed : 투사체 이동 속도(units/sec)
// [의존 관계]      - IChainPresenter / Card / CardRuntimeData / PoolManager
//                  - ProjectileObject / VfxObject / ICombatTarget
//                  - BattleController 가 생성·주입 (ChainExecutor presenter 자리)
// [설계 노트]      - 위치 조회를 Func 로 주입: GridManager API 의존을 BattleController 로 위임
//                    (presenter 는 그리드 내부 구조를 모름 → 결합 최소)
//                  - 웨이브 단위 호출, 웨이브 내 카드별 투사체는 병렬(WhenAll) → 동시 발사
//                  - 연출 데이터(EVfxType/EVfxTarget/풀키)는 CardRuntimeData 에서 읽음
//                  - 투사체/적중은 prefab 이 아닌 풀 키(string)로 SpawnAsync 비동기 스폰
// =================================================================

using System;
using System.Collections.Generic;
using System.Threading;
using Cysharp.Threading.Tasks;
using DamageNumbersPro;
using UnityEngine;
using UnityEngine.Rendering;

public readonly struct BattleVfxRequest
{
    public readonly CardRuntimeData Data;
    public readonly Vector3 Start;
    public readonly Vector3 End;
    public readonly float VisualSpeedMultiplier;

    public BattleVfxRequest(CardRuntimeData data, Vector3 start, Vector3 end, float visualSpeedMultiplier = 1f)
    {
        Data = data;
        Start = start;
        End = end;
        VisualSpeedMultiplier = Mathf.Max(0.0001f, visualSpeedMultiplier);
    }

    public bool IsValid => Data != null;
}

/// <summary>
/// 카드 발동 연출을 풀링으로 재생하는 프리젠터. 한 웨이브의 ON 카드들에 대해
/// 각 카드의 CardRuntimeData 연출 설정(투사체/적중 이펙트/대상)을 읽어 동시에 발사하고,
/// 모든 투사체가 도착할 때까지 대기한다. 위치 조회는 외부 주입으로 그리드 결합을 끊는다.
/// </summary>
public sealed class BattleVfxPresenter : IChainPresenter
{
    private const string ChainCardActivationAudioKey = "ChainCard_Activate";
    private const string ChainMilestoneLaunchAudioKey = "ChainMilestone_Projectile_Launch";
    private const string ChainMilestoneHitAudioKey = "ChainMilestone_Projectile_Hit";
    private const string ChainFinisherLaunchAudioKey = "ChainFinisher_Laser_Launch";
    private const string ChainFinisherHitAudioKey = "ChainFinisher_Laser_Hit";
    // Laser.controller의 LaserEnd 클립 길이(초). 클립을 수정하면 함께 갱신해야 한다.
    private const float LaserEndClipDuration = 0.3f;
    private static readonly int LaserEndTriggerHash = Animator.StringToHash("End");

    private readonly Func<Card, Vector3?> _resolveCardWorldPos;
    private ICombatTarget _enemyTarget;
    private readonly ICombatTarget _playerTarget;
    private readonly CastingOrbView _castingOrbPrefab;
    private readonly CastingOrbVisualSet _castingOrbVisualSet;
    private readonly float _castingOrbRadius;
    private readonly float _castingOrbHeightOffset;
    private readonly Dictionary<int, CastingOrbView> _castingOrbs = new Dictionary<int, CastingOrbView>(8);
    private readonly List<int> _castingOrbOrder = new List<int>(8);
    private MagicCircleVfxView _magicCircleVfx;
    private int _magicCircleVfxId;
    private readonly float _projectileSpeed;
    private readonly float _multiHitProjectileCurveHeight;
    private readonly float _multiHitProjectileSpeedMultiplier;
    private readonly float _multiHitProjectileCurveAngle;
    private readonly BattleVfxAudioCatalog _vfxAudioCatalog;
    private readonly DamageNumber _chainTextPopupPrefab;
    private readonly Vector3 _chainTextPopupOffset;
    private readonly float _chainTextPopupScale;
    private readonly float _chainActivationBasePitch;
    private readonly float _chainActivationPitchPerCard;
    private readonly float _chainActivationMaxPitch;
    private int _chainTextPopupCount;
    // 피해 숫자(데미지 팝업) 설정 — 방어 흡수분/체력 피해분 분리 표시 + 겹침 방지 스태거.
    private readonly DamageNumber _damageNumberPrefab;
    private readonly Vector3 _damageNumberOffset;
    private readonly Color _hpDamageNumberColor;
    private readonly Color _blockedDamageNumberColor;
    private readonly Vector3 _damageNumberStagger;
    private readonly float _damageNumberStaggerWindow;
    private int _damageNumberSpawnIndex;
    private float _damageNumberStaggerWindowStartTime = -999f;
    // 카드 1장이 ON 될 때 보장하는 최소 연출 시간(초). VFX 가 없어도 순차 간격 확보.
    private readonly float _activationDelay;
    private readonly Sprite _chainSignalSprite;
    private readonly float _chainSignalScale;
    private readonly float _chainSignalDuration;
    private readonly float _chainVisualMinimumDuration;
    private readonly Dictionary<Card, float> _cardVisualSpeeds = new Dictionary<Card, float>(8);
    private readonly Material _signalLineMaterialOverride;
    private readonly Color _signalLineColor;
    private readonly float _signalLineWidth = 0.05f;
    private readonly float _signalLineDuration = 0.3f;
    private readonly float _signalLineYOffset = 0f;
    private Material _signalLineMaterial;

    /// <param name="resolveCardWorldPos">카드 → 월드 위치 조회 (그리드 비주얼 위치). null 반환 시 연출 생략.</param>
    /// <param name="enemyTarget">적 도착점.</param>
    /// <param name="playerTarget">플레이어 도착점.</param>
    /// <param name="projectileSpeed">투사체 이동 속도(units/sec).</param>
    /// <param name="chainTextPopupPrefab">체인 ON 텍스트 DamageNumbersPro 프리팹.</param>
    /// <param name="chainTextPopupOffset">카드 월드 위치 기준 텍스트 오프셋.</param>
    /// <param name="chainTextPopupScale">체인 텍스트 크기.</param>
    /// <param name="activationDelay">카드 1장 ON 최소 연출 시간(초). VFX 없는 카드도 순차로 보이게 함.</param>
    /// <param name="signalLineMaterial">체인 신호선 머티리얼. null 이면 런타임 기본 머티리얼을 만든다.</param>
    /// <param name="signalLineColor">체인 신호선 색상.</param>
    /// <param name="chainSignalSprite">체인 방향을 표시할 오른쪽 기준 1bit 화살표.</param>
    /// <param name="chainSignalScale">체인 화살표 월드 크기 배율.</param>
    /// <param name="chainSignalDuration">체인 화살표 이동 시간(초).</param>
    public BattleVfxPresenter(
        Func<Card, Vector3?> resolveCardWorldPos,
        ICombatTarget enemyTarget,
        ICombatTarget playerTarget,
        float projectileSpeed = 20f,
        float multiHitProjectileCurveHeight = 0.75f,
        float multiHitProjectileSpeedMultiplier = 7f,
        float multiHitProjectileCurveAngle = 25f,
        DamageNumber chainTextPopupPrefab = null,
        Vector3? chainTextPopupOffset = null,
        float chainTextPopupScale = 1f,
        float activationDelay = 0.18f,
        Material signalLineMaterial = null,
        Color? signalLineColor = null,
        Sprite chainSignalSprite = null,
        float chainSignalScale = 1f,
        float chainSignalDuration = 0.18f,
        float chainVisualMinimumDuration = 0.05f,
        CastingOrbView castingOrbPrefab = null,
        CastingOrbVisualSet castingOrbVisualSet = null,
        float castingOrbRadius = 1.35f,
        float castingOrbHeightOffset = 0.65f,
        DamageNumber damageNumberPrefab = null,
        Vector3? damageNumberOffset = null,
        Color? hpDamageNumberColor = null,
        Color? blockedDamageNumberColor = null,
        Vector3? damageNumberStagger = null,
        float damageNumberStaggerWindow = 0.4f,
        float chainActivationBasePitch = 0.9f,
        float chainActivationPitchPerCard = 0.01f,
        float chainActivationMaxPitch = 1.6f,
        BattleVfxAudioCatalog vfxAudioCatalog = null)
    {
        _resolveCardWorldPos = resolveCardWorldPos;
        _enemyTarget = enemyTarget;
        _playerTarget = playerTarget;
        _castingOrbPrefab = castingOrbPrefab;
        _castingOrbVisualSet = castingOrbVisualSet;
        _castingOrbRadius = Mathf.Max(0.1f, castingOrbRadius);
        _castingOrbHeightOffset = castingOrbHeightOffset;
        _projectileSpeed = Mathf.Max(1f, projectileSpeed);
        _multiHitProjectileCurveHeight = Mathf.Max(0f, multiHitProjectileCurveHeight);
        _multiHitProjectileSpeedMultiplier = Mathf.Max(0.1f, multiHitProjectileSpeedMultiplier);
        _multiHitProjectileCurveAngle = Mathf.Clamp(multiHitProjectileCurveAngle, 0f, 75f);
        _vfxAudioCatalog = vfxAudioCatalog;
        _chainTextPopupPrefab = chainTextPopupPrefab;
        _chainTextPopupOffset = chainTextPopupOffset ?? new Vector3(0f, 0.9f, 0f);
        _chainTextPopupScale = Mathf.Max(0.01f, chainTextPopupScale);
        _chainActivationBasePitch = Mathf.Clamp(chainActivationBasePitch, 0.1f, 3f);
        _chainActivationPitchPerCard = Mathf.Max(0f, chainActivationPitchPerCard);
        _chainActivationMaxPitch = Mathf.Clamp(
            Mathf.Max(_chainActivationBasePitch, chainActivationMaxPitch),
            0.1f,
            3f);
        _activationDelay = Mathf.Max(0f, activationDelay);
        _chainSignalSprite = chainSignalSprite;
        _chainSignalScale = Mathf.Max(0.01f, chainSignalScale);
        _chainSignalDuration = Mathf.Max(0.01f, chainSignalDuration);
        _chainVisualMinimumDuration = Mathf.Max(0f, chainVisualMinimumDuration);
        _signalLineMaterialOverride = signalLineMaterial;
        _signalLineColor = signalLineColor ?? new Color(0.1f, 0.95f, 1f, 1f);
        _damageNumberPrefab = damageNumberPrefab;
        _damageNumberOffset = damageNumberOffset ?? new Vector3(0f, 1.1f, 0f);
        _hpDamageNumberColor = hpDamageNumberColor ?? new Color(1f, 0.25f, 0.18f, 1f);
        _blockedDamageNumberColor = blockedDamageNumberColor ?? new Color(0f, 1f, 1f, 1f);
        _damageNumberStagger = damageNumberStagger ?? new Vector3(0.35f, 0.2f, 0f);
        _damageNumberStaggerWindow = Mathf.Max(0.01f, damageNumberStaggerWindow);
    }

    /// <summary>적 도착점 갱신 (층마다 적 View 가 교체되므로). 적 연출의 종착지를 바꾼다.</summary>
    public void SetEnemyTarget(ICombatTarget enemyTarget)
    {
        _enemyTarget = enemyTarget;
    }

    public void ResetChainTextPopupCount()
    {
        _chainTextPopupCount = 0;
    }

    public async UniTask<bool> PlayPlayerToEnemyProjectileAsync(string projectileKey, CancellationToken token)
    {
        Transform playerAnchor = _playerTarget != null ? _playerTarget.AnchorTransform : null;
        Transform enemyAnchor = _enemyTarget != null ? _enemyTarget.AnchorTransform : null;
        if (string.IsNullOrEmpty(projectileKey) || playerAnchor == null || enemyAnchor == null)
        {
            return false;
        }

        PlayVfxSfx(ChainMilestoneLaunchAudioKey, token);
        bool played = await MoveProjectileAsync(
            projectileKey,
            playerAnchor.position,
            enemyAnchor.position,
            1f,
            token,
            playSpawnSfx: false);
        if (played && !token.IsCancellationRequested)
        {
            PlayVfxSfx(ChainMilestoneHitAudioKey, token);
        }
        return played;
    }

    public async UniTask<bool> PlayPlayerLaserAsync(
        string vfxKey,
        Vector3 spawnOffset,
        float duration,
        float animationSpeedMultiplier,
        bool useFinisherAudio,
        float launchPitchMultiplier,
        float hitPitchMultiplier,
        int hitCount,
        Func<int, CancellationToken, UniTask<bool>> onHit,
        CancellationToken token)
    {
        float animationSpeed = Mathf.Max(0.01f, animationSpeedMultiplier);
        float scaledDuration = BattleSpeedUtility.ScaleDuration(
            Mathf.Max(0.01f, duration) / animationSpeed);
        int resolvedHitCount = Mathf.Max(1, hitCount);
        Transform playerAnchor = _playerTarget != null ? _playerTarget.AnchorTransform : null;
        GameObject instance = null;
        Animator animator = null;
        bool played = false;

        try
        {
            if (playerAnchor == null || string.IsNullOrEmpty(vfxKey) || !ResourceManager.HasInstance)
            {
                Debug.LogWarning("[BattleVfxPresenter] 플레이어 레이저 생성 조건이 부족합니다.");
            }
            else
            {
                try
                {
                    instance = await ResourceManager.Instance.InstantiateAsync<GameObject>(vfxKey, null, token);
                    if (instance == null)
                    {
                        Debug.LogWarning($"[BattleVfxPresenter] 레이저 생성 실패: {vfxKey}");
                    }
                    else
                    {
                        instance.transform.SetPositionAndRotation(
                            playerAnchor.position + spawnOffset,
                            Quaternion.identity);

                        animator = instance.GetComponentInChildren<Animator>(true);
                        if (animator != null)
                        {
                            animator.speed = BattleSpeedUtility.Multiplier * animationSpeed;
                            animator.Play(0, -1, 0f);
                        }

                        Renderer[] renderers = instance.GetComponentsInChildren<Renderer>(true);
                        for (int i = 0; i < renderers.Length; i++)
                        {
                            renderers[i].sortingLayerName = "FrontEffect";
                        }

                        PlayVfxSfx(
                            useFinisherAudio
                                ? ChainFinisherLaunchAudioKey
                                : ChainMilestoneLaunchAudioKey,
                            token,
                            launchPitchMultiplier,
                            allowRandomPitch: false);
                        played = true;
                    }
                }
                catch (OperationCanceledException)
                {
                    throw;
                }
                catch (Exception ex)
                {
                    Debug.LogWarning($"[BattleVfxPresenter] 레이저 생성 실패: {ex.Message}");
                }
            }

            if (onHit != null)
            {
                float hitInterval = Mathf.Max(0.01f, scaledDuration / resolvedHitCount);
                bool completedAllHits = true;
                for (int hitIndex = 0; hitIndex < resolvedHitCount; hitIndex++)
                {
                    if (hitIndex > 0)
                    {
                        await UniTask.Delay(TimeSpan.FromSeconds(hitInterval), cancellationToken: token);
                    }

                    if (token.IsCancellationRequested)
                    {
                        completedAllHits = false;
                        break;
                    }

                    if (played)
                    {
                        PlayVfxSfx(
                            useFinisherAudio
                                ? ChainFinisherHitAudioKey
                                : ChainMilestoneHitAudioKey,
                            token,
                            hitPitchMultiplier,
                            allowRandomPitch: false);
                    }

                    bool shouldContinue = await onHit(hitIndex, token);
                    if (!shouldContinue)
                    {
                        completedAllHits = hitIndex == resolvedHitCount - 1;
                        break;
                    }
                }

                if (completedAllHits && !token.IsCancellationRequested)
                {
                    await UniTask.Delay(TimeSpan.FromSeconds(hitInterval), cancellationToken: token);
                }
            }
            else
            {
                await UniTask.Delay(TimeSpan.FromSeconds(scaledDuration), cancellationToken: token);
            }

            if (animator != null && !token.IsCancellationRequested)
            {
                animator.SetTrigger(LaserEndTriggerHash);
                float endSeconds = LaserEndClipDuration / Mathf.Max(0.01f, animator.speed);
                await UniTask.Delay(TimeSpan.FromSeconds(endSeconds), cancellationToken: token);
            }

            return played;
        }
        finally
        {
            if (instance != null && ResourceManager.HasInstance)
            {
                ResourceManager.Instance.ReleaseInstance(instance);
            }
        }
    }

    public void CreateCastingOrb(int id, int remainingCount, Card sourceCard)
    {
        CastingOrbView prefab = ResolveCastingOrbPrefab(sourceCard);
        if (prefab == null || id <= 0)
        {
            return;
        }

        if (_castingOrbs.TryGetValue(id, out CastingOrbView existing) && existing != null)
        {
            existing.SetRemainingCount(remainingCount);
            RelayoutCastingOrbs();
            return;
        }

        Transform anchor = _playerTarget != null ? _playerTarget.AnchorTransform : null;
        if (anchor == null)
        {
            return;
        }

        CastingOrbView orb = PoolManager.HasInstance
            ? PoolManager.Instance.Spawn(prefab, anchor.position, Quaternion.identity)
            : UnityEngine.Object.Instantiate(prefab, anchor.position, Quaternion.identity);
        if (orb == null)
        {
            return;
        }

        orb.name = $"CastingOrb_{id:00}";
        orb.Initialize(id, remainingCount, sourceCard);
        PlayVfxSfx(prefab.name, CancellationToken.None);
        _castingOrbs[id] = orb;
        if (!_castingOrbOrder.Contains(id))
        {
            _castingOrbOrder.Add(id);
        }
        RelayoutCastingOrbs();
    }

    private CastingOrbView ResolveCastingOrbPrefab(Card sourceCard)
    {
        string cardId = sourceCard?.Data != null
            ? sourceCard.Data.CardId
            : sourceCard?.CardId;
        CastingOrbView mapped = _castingOrbVisualSet != null
            ? _castingOrbVisualSet.FindPrefab(cardId)
            : null;
        return mapped != null ? mapped : _castingOrbPrefab;
    }

    public void UpdateCastingOrb(int id, int remainingCount)
    {
        if (_castingOrbs.TryGetValue(id, out CastingOrbView orb) && orb != null)
        {
            orb.SetRemainingCount(remainingCount);
        }
    }

    public bool TryGetCastingOrbPosition(int id, out Vector3 position)
    {
        if (_castingOrbs.TryGetValue(id, out CastingOrbView orb) && orb != null)
        {
            position = orb.WorldPosition;
            return true;
        }

        position = default;
        return false;
    }

    public void RemoveCastingOrb(int id)
    {
        if (_castingOrbs.TryGetValue(id, out CastingOrbView orb) && orb != null)
        {
            ReleaseCastingOrb(orb);
        }

        _castingOrbs.Remove(id);
        _castingOrbOrder.Remove(id);
        RelayoutCastingOrbs();
    }

    public void ClearCastingOrbs()
    {
        for (int i = 0; i < _castingOrbOrder.Count; i++)
        {
            int id = _castingOrbOrder[i];
            if (_castingOrbs.TryGetValue(id, out CastingOrbView orb) && orb != null)
            {
                ReleaseCastingOrb(orb);
            }
        }

        _castingOrbs.Clear();
        _castingOrbOrder.Clear();
    }

    private static void ReleaseCastingOrb(CastingOrbView orb)
    {
        if (orb == null)
        {
            return;
        }

        if (PoolManager.HasInstance && PoolManager.Instance.IsPooledInstance(orb.gameObject))
        {
            PoolManager.Instance.Despawn(orb);
        }
        else
        {
            UnityEngine.Object.Destroy(orb.gameObject);
        }
    }

    public void CreateMagicCircleVfx(int id, string addressableKey)
    {
        ClearMagicCircleVfx();
        if (id <= 0 || string.IsNullOrEmpty(addressableKey))
        {
            return;
        }

        _magicCircleVfxId = id;
        SpawnMagicCircleVfxAsync(id, addressableKey).Forget();
    }

    public void RemoveMagicCircleVfx(int id)
    {
        if (id > 0 && _magicCircleVfxId != id)
        {
            return;
        }

        ClearMagicCircleVfx();
    }

    public void PlayMagicCircleConsumeVfx(string addressableKey, Card card)
    {
        if (string.IsNullOrEmpty(addressableKey) || card == null)
        {
            return;
        }

        Vector3? position = _resolveCardWorldPos?.Invoke(card);
        if (position.HasValue)
        {
            SpawnHitVfx(addressableKey, position.Value);
        }
    }

    private async UniTaskVoid SpawnMagicCircleVfxAsync(int id, string addressableKey)
    {
        Transform anchor = _playerTarget != null ? _playerTarget.AnchorTransform : null;
        if (anchor == null || !PoolManager.HasInstance)
        {
            return;
        }

        MagicCircleVfxView view = await PoolManager.Instance.SpawnAsync<MagicCircleVfxView>(
            addressableKey, anchor.position, Quaternion.identity, anchor, CancellationToken.None);
        if (view == null)
        {
            return;
        }

        if (_magicCircleVfxId != id)
        {
            ReleaseMagicCircleVfx(view);
            return;
        }

        if (_magicCircleVfx != null)
        {
            ReleaseMagicCircleVfx(_magicCircleVfx);
        }

        _magicCircleVfx = view;
        view.transform.SetParent(anchor, false);
        view.transform.localPosition = Vector3.zero;
        view.transform.localRotation = Quaternion.identity;
        PlayVfxSfx(addressableKey, CancellationToken.None);
    }

    private void ClearMagicCircleVfx()
    {
        _magicCircleVfxId = 0;
        if (_magicCircleVfx != null)
        {
            ReleaseMagicCircleVfx(_magicCircleVfx);
            _magicCircleVfx = null;
        }
    }

    private static void ReleaseMagicCircleVfx(MagicCircleVfxView view)
    {
        if (view == null)
        {
            return;
        }

        if (PoolManager.HasInstance && PoolManager.Instance.IsPooledInstance(view.gameObject))
        {
            PoolManager.Instance.Despawn(view);
        }
        else
        {
            UnityEngine.Object.Destroy(view.gameObject);
        }
    }

    private void RelayoutCastingOrbs()
    {
        Transform anchor = _playerTarget != null ? _playerTarget.AnchorTransform : null;
        if (anchor == null || _castingOrbOrder.Count == 0)
        {
            return;
        }

        Vector3 center = anchor.position + Vector3.up * _castingOrbHeightOffset;
        int count = _castingOrbOrder.Count;
        for (int i = 0; i < count; i++)
        {
            int id = _castingOrbOrder[i];
            if (!_castingOrbs.TryGetValue(id, out CastingOrbView orb) || orb == null)
            {
                continue;
            }

            float angle = (Mathf.PI * 2f * i / count) + Mathf.PI * 0.5f;
            Vector3 offset = new Vector3(
                Mathf.Cos(angle) * _castingOrbRadius,
                Mathf.Sin(angle) * _castingOrbRadius,
                0f);
            orb.MoveTo(center + offset);
        }
    }

    // ── IChainPresenter ─────────────────────────────────────

    /// <summary>웨이브의 모든 카드 연출을 병렬 재생하고 완료까지 대기.</summary>
    public async UniTask PlayActivationFeedbackAsync(IReadOnlyList<Card> wave, CancellationToken token)
    {
        if (wave == null || wave.Count == 0) return;

        // 카드별 연출을 병렬 실행 (동시 발사).
        List<UniTask> tasks = new List<UniTask>(wave.Count);
        for (int i = 0; i < wave.Count; i++)
        {
            Card card = wave[i];
            if (card == null) continue;

            UniTask t = PlayCardVfxAsync(card, token, allowCasting: false);
            tasks.Add(t);
        }

        if (tasks.Count > 0)
        {
            await UniTask.WhenAll(tasks);
        }
    }

    public void ScheduleActivationVfx(IReadOnlyList<Card> wave, CancellationToken token)
    {
        if (wave == null || wave.Count == 0) return;

        // 체인 웨이브의 시각 연출 시작음은 카드 수와 무관하게 1회만 재생한다.
        // if (AudioManager.HasInstance)
        //     AudioManager.Instance.PlaySfxAsync(AudioKeys.Battle.CHAIN_LASER).Forget();

        for (int i = 0; i < wave.Count; i++)
        {
            Card card = wave[i];
            if (card == null) continue;

            if (TryCreateActivationVfxRequest(card, allowCasting: false, out BattleVfxRequest request))
            {
                PlayVfxRequestFireAndForgetAsync(request, token).Forget();
            }
        }
    }

    public void SetCardVisualSpeed(Card card, float visualSpeedMultiplier)
    {
        if (card != null)
        {
            _cardVisualSpeeds[card] = Mathf.Max(0.0001f, visualSpeedMultiplier);
        }
    }

    public void ClearCardVisualSpeeds()
    {
        _cardVisualSpeeds.Clear();
    }

    /// <summary>Casting 카드가 실제 payload 페이즈를 실행했을 때 재생하는 발동 연출.</summary>
    public UniTask PlayCastingPayloadVfxAsync(Card card, CancellationToken token)
    {
        return PlayCastingPayloadVfxAsync(card, null, token);
    }

    public UniTask PlayCastingPayloadVfxAsync(Card card, Vector3? startOverride, CancellationToken token)
    {
        return PlayCardVfxAsync(card, token, allowCasting: true, startOverride);
    }

    public bool CanPlayImpactVfx(Card card)
    {
        return TryCreateImpactVfxRequest(card, out _);
    }

    public async UniTask<bool> PlayImpactVfxAsync(Card card, CancellationToken token)
    {
        if (!TryCreateImpactVfxRequest(card, out BattleVfxRequest request))
        {
            return false;
        }

        return await PlayImpactVfxAsync(request, token);
    }

    public async UniTask<bool> PlayImpactVfxAsync(BattleVfxRequest request, CancellationToken token)
    {
        return await PlayImpactVfxAsync(request, token, null);
    }

    public async UniTask<bool> PlayImpactVfxAsync(
        BattleVfxRequest request,
        CancellationToken token,
        Func<UniTask> onImpact)
    {
        return await PlayImpactVfxAsync(request, token, onImpact, 0, 1);
    }

    public async UniTask<bool> PlayImpactVfxAsync(
        BattleVfxRequest request,
        CancellationToken token,
        Func<UniTask> onImpact,
        int hitIndex,
        int hitCount)
    {
        return await PlayVfxRequestAsync(request, token, onImpact, hitIndex, hitCount);
    }

    public bool TryCreateImpactVfxRequest(Card card, out BattleVfxRequest request)
    {
        return TryCreateImpactVfxRequest(card, null, out request);
    }

    public bool TryCreateImpactVfxRequest(Card card, Vector3? startOverride, out BattleVfxRequest request)
    {
        return TryCreateVfxRequest(card, allowCasting: true, startOverride, out request);
    }

    /// <summary>
    /// 피해 판정 직전에 실제 impact 연출을 먼저 재생한다.
    /// 실제로 재생된 VFX 가 없으면 false 를 반환해 기존 즉시 피해 흐름을 유지한다.
    /// </summary>
    public async UniTask<bool> TryPlayImpactVfxBeforeDamageAsync(Card card, CancellationToken token)
    {
        return await PlayImpactVfxAsync(card, token);
    }

    private bool TryCreateActivationVfxRequest(Card card, bool allowCasting, out BattleVfxRequest request)
    {
        return TryCreateVfxRequest(card, allowCasting, null, out request);
    }

    private bool TryCreateVfxRequest(
        Card card,
        bool allowCasting,
        Vector3? startOverride,
        out BattleVfxRequest request)
    {
        request = default;

        if (card == null || card.Data == null)
        {
            return false;
        }

        CardRuntimeData data = card.Data;
        if (!allowCasting && data.CardType == ECardType.Casting)
        {
            return false;
        }

        EVfxType vfxType = data.VfxType;
        if (vfxType == EVfxType.None)
        {
            return false;
        }

        Vector3? startNullable = startOverride ?? _resolveCardWorldPos?.Invoke(card);
        if (startNullable == null)
        {
            return false;
        }

        ICombatTarget target = data.VfxTarget == EVfxTarget.Self ? _playerTarget : _enemyTarget;
        if (target == null || target.AnchorTransform == null)
        {
            return false;
        }

        if ((vfxType == EVfxType.Projectile || vfxType == EVfxType.Both) &&
            string.IsNullOrEmpty(data.ProjectileKey))
        {
            return false;
        }

        if ((vfxType == EVfxType.Hit || vfxType == EVfxType.Both) &&
            string.IsNullOrEmpty(data.HitVfxKey))
        {
            return false;
        }

        request = new BattleVfxRequest(
            data,
            startNullable.Value,
            target.AnchorTransform.position,
            GetCardVisualSpeed(card));
        return true;
    }

    private async UniTaskVoid PlayVfxRequestFireAndForgetAsync(BattleVfxRequest request, CancellationToken token)
    {
        try
        {
            await PlayVfxRequestAsync(request, token);
        }
        catch (OperationCanceledException)
        {
        }
        catch (Exception ex)
        {
            Debug.LogWarning($"[BattleVfxPresenter] VFX 예약 재생 실패: {ex.Message}");
        }
    }

    /// <summary>카드가 ON 될 때 현재 체인 순번을 카드 위에 표시한다.</summary>
    public void OnCardToggled(Card card, bool activated)
    {
        if (!activated || card == null)
        {
            return;
        }

        _chainTextPopupCount++;
        float pitchMultiplier = Mathf.Min(
            _chainActivationMaxPitch,
            _chainActivationBasePitch + ((_chainTextPopupCount - 1) * _chainActivationPitchPerCard));
        PlayVfxSfx(
            ChainCardActivationAudioKey,
            CancellationToken.None,
            pitchMultiplier,
            allowRandomPitch: false);

        if (_chainTextPopupPrefab == null)
        {
            return;
        }

        Vector3? position = _resolveCardWorldPos?.Invoke(card);
        if (position == null)
        {
            return;
        }

        DamageNumber popup = _chainTextPopupPrefab.Spawn(
            position.Value + _chainTextPopupOffset,
            $"{_chainTextPopupCount} Chain");

        if (popup == null)
        {
            return;
        }

        popup.SetScale(_chainTextPopupScale);
        ApplyDamageNumberSorting(popup);
    }

    /// <summary>
    /// 대상이 피해를 받았을 때 피해 숫자를 스폰한다.
    /// 방어 흡수분(시안)과 체력 피해분(현재색)을 각각의 숫자로 분리 표시한다.
    /// </summary>
    public void SpawnDamageNumber(Transform target, int requestedDamage, int hpDamage, int blockedDamage, float scale)
    {
        if (_damageNumberPrefab == null || target == null) return;

        if (blockedDamage > 0)
        {
            SpawnSingleDamageNumber(target, blockedDamage, _blockedDamageNumberColor, scale);
        }

        if (hpDamage > 0)
        {
            SpawnSingleDamageNumber(target, hpDamage, _hpDamageNumberColor, scale);
        }

        // 방어·체력 어느 쪽에도 잡히지 않는 경우(0/0)의 폴백.
        if (blockedDamage <= 0 && hpDamage <= 0 && requestedDamage > 0)
        {
            SpawnSingleDamageNumber(target, requestedDamage, _hpDamageNumberColor, scale);
        }
    }

    private void SpawnSingleDamageNumber(Transform target, int value, Color color, float scale)
    {
        if (_damageNumberPrefab == null || target == null || value <= 0) return;

        // 첫 스폰부터 고정된 시간창 안에서만 인덱스를 증가시킨다.
        // 마지막 스폰 시각을 기준으로 삼으면 짧은 간격의 피해가 계속될 때 창이 끝나지 않아
        // 스태거 Y 오프셋이 무한히 누적된다.
        if (Time.time - _damageNumberStaggerWindowStartTime > _damageNumberStaggerWindow)
        {
            _damageNumberSpawnIndex = 0;
            _damageNumberStaggerWindowStartTime = Time.time;
        }
        else
        {
            _damageNumberSpawnIndex++;
        }

        // 좌우 교차 배치: 0=원점, 1=우, 2=좌, 3=우2 ... 로 어긋나게.
        int step = (_damageNumberSpawnIndex + 1) / 2;
        float sign = (_damageNumberSpawnIndex % 2 == 1) ? 1f : -1f;
        Vector3 extraOffset = new Vector3(
            _damageNumberStagger.x * step * sign,
            _damageNumberStagger.y * step,
            _damageNumberStagger.z * step);

        DamageNumber number = _damageNumberPrefab.Spawn(
            target.position + _damageNumberOffset + extraOffset,
            value,
            target);

        if (number != null)
        {
            number.SetScale(Mathf.Max(0.01f, scale));
            // 프리팹 TMP에 버텍스 그라디언트가 켜져 있으면 SetColor(tmp.color)가 무시되므로
            // 그라디언트 4모서리도 동일 색으로 지정해 확실히 덮어쓴다.
            number.SetColor(color);
            number.SetGradientColor(color, color, color, color);
            ApplyDamageNumberSorting(number);
        }
    }

    private static void ApplyDamageNumberSorting(DamageNumber damageNumber)
    {
        if (damageNumber == null) return;

        Renderer[] renderers = damageNumber.GetComponentsInChildren<Renderer>(includeInactive: true);
        for (int i = 0; i < renderers.Length; i++)
        {
            Renderer renderer = renderers[i];
            if (renderer == null) continue;

            renderer.sortingLayerName = "FrontEffect";
            renderer.sortingOrder = 1000;
        }

        SortingGroup sortingGroup = damageNumber.GetComponent<SortingGroup>();
        if (sortingGroup != null)
        {
            sortingGroup.sortingLayerName = "FrontEffect";
            sortingGroup.sortingOrder = 1000;
        }
    }

    /// <summary>
    /// 방향 신호 전파 훅. 1bit 화살표를 계단식으로 이동하고, 스프라이트가 없으면 기존 선을 사용한다.
    /// </summary>
    public void OnSignalPropagated(
        Card emitter,
        Vector3 from,
        Vector3 to,
        Card reachedCard,
        float visualSpeedMultiplier)
    {
        Vector3 direction = to - from;
        if (direction.sqrMagnitude <= 0.0001f) return;

        Vector3 offset = Vector3.up * _signalLineYOffset;
        Vector3 start = from + offset;
        Vector3 end = Vector3.Lerp(from, to, 0.85f) + offset;

        if (_chainSignalSprite != null)
        {
            GameObject arrowObject = CreateChainSignalArrow(direction, start);
            PlayChainSignalArrowAsync(arrowObject, start, end, visualSpeedMultiplier).Forget();
            return;
        }

        GameObject lineObject = CreateSignalLineRenderer(out LineRenderer line);
        line.SetPosition(0, start);
        line.SetPosition(1, start);

        PlaySignalLineAsync(line, lineObject, start, end, visualSpeedMultiplier).Forget();
    }

    private GameObject CreateChainSignalArrow(Vector3 direction, Vector3 start)
    {
        GameObject arrowObject = new GameObject("ChainSignalPixelArrow");
        arrowObject.transform.SetPositionAndRotation(
            start,
            Quaternion.Euler(0f, 0f, Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg));
        arrowObject.transform.localScale = Vector3.one * _chainSignalScale;

        SpriteRenderer renderer = arrowObject.AddComponent<SpriteRenderer>();
        renderer.sprite = _chainSignalSprite;
        renderer.color = Color.white;
        renderer.sortingLayerName = "FrontEffect";
        return arrowObject;
    }

    private async UniTaskVoid PlayChainSignalArrowAsync(
        GameObject arrowObject,
        Vector3 from,
        Vector3 to,
        float visualSpeedMultiplier)
    {
        const int stepCount = 7;
        float duration = BattleSpeedUtility.ScaleDuration(
            _chainSignalDuration,
            visualSpeedMultiplier,
            _chainVisualMinimumDuration);
        float stepDuration = duration / (stepCount - 1);

        try
        {
            for (int step = 0; step < stepCount; step++)
            {
                if (arrowObject == null) return;

                arrowObject.transform.position = Vector3.Lerp(from, to, step / (stepCount - 1f));
                if (step < stepCount - 1)
                {
                    await UniTask.Delay(TimeSpan.FromSeconds(stepDuration));
                }
            }
        }
        finally
        {
            if (arrowObject != null)
            {
                UnityEngine.Object.Destroy(arrowObject);
            }
        }
    }

    private GameObject CreateSignalLineRenderer(out LineRenderer line)
    {
        GameObject lineObject = new GameObject("ChainSignalLine");
        line = lineObject.AddComponent<LineRenderer>();
        Material material = GetSignalLineMaterial();
        if (material != null)
        {
            line.material = material;
        }

        line.useWorldSpace = true;
        line.positionCount = 2;
        line.startWidth = _signalLineWidth;
        line.endWidth = _signalLineWidth;
        line.sortingLayerName = "FrontEffect";
        line.startColor = _signalLineColor;
        line.endColor = _signalLineColor;
        return lineObject;
    }

    private async UniTaskVoid PlaySignalLineAsync(
        LineRenderer line,
        GameObject owner,
        Vector3 from,
        Vector3 to,
        float visualSpeedMultiplier)
    {
        const float extendRatio = 0.55f;
        float duration = BattleSpeedUtility.ScaleDuration(
            _signalLineDuration,
            visualSpeedMultiplier,
            _chainVisualMinimumDuration);
        float extendDuration = duration * extendRatio;
        float shrinkDuration = duration - extendDuration;

        try
        {
            float elapsed = 0f;
            while (elapsed < extendDuration)
            {
                if (line == null) return;
                elapsed += Time.deltaTime;
                float t = Mathf.Clamp01(elapsed / extendDuration);
                line.SetPosition(0, from);
                line.SetPosition(1, Vector3.Lerp(from, to, t));
                await UniTask.Yield(PlayerLoopTiming.Update);
            }

            elapsed = 0f;
            while (elapsed < shrinkDuration)
            {
                if (line == null) return;
                elapsed += Time.deltaTime;
                float t = Mathf.Clamp01(elapsed / shrinkDuration);
                line.SetPosition(0, Vector3.Lerp(from, to, t));
                line.SetPosition(1, to);
                await UniTask.Yield(PlayerLoopTiming.Update);
            }
        }
        finally
        {
            if (owner != null)
            {
                UnityEngine.Object.Destroy(owner);
            }
        }
    }

    // ── 카드별 연출 ─────────────────────────────────────────

    private async UniTask PlayCardVfxAsync(
        Card card,
        CancellationToken token,
        bool allowCasting,
        Vector3? startOverride = null)
    {
        if (!TryCreateVfxRequest(card, allowCasting, startOverride, out BattleVfxRequest request))
        {
            await DelayActivationAsync(token, GetCardVisualSpeed(card));
            return;
        }

        bool played = await PlayVfxRequestAsync(request, token);
        if (!played)
        {
            await DelayActivationAsync(token);
        }
    }

    private async UniTask<bool> PlayVfxRequestAsync(
        BattleVfxRequest request,
        CancellationToken token,
        Func<UniTask> onImpact = null,
        int hitIndex = 0,
        int hitCount = 1)
    {
        if (!request.IsValid)
        {
            return false;
        }

        CardRuntimeData data = request.Data;
        EVfxType vfxType = data.VfxType;
        bool played = false;

        // 1) 투사체 (Projectile/Both).
        if (vfxType == EVfxType.Projectile || vfxType == EVfxType.Both)
        {
            played = await MoveProjectileAsync(
                data.ProjectileKey,
                request.Start,
                request.End,
                request.VisualSpeedMultiplier,
                token,
                hitIndex,
                hitCount);
            if (!played || token.IsCancellationRequested) return played;
            if (onImpact != null)
            {
                await onImpact();
            }
        }
        else
        {
            // 투사체가 없는 Hit 전용도 순차 간격 확보.
            await DelayActivationAsync(token, request.VisualSpeedMultiplier);
        }

        // 2) 적중 이펙트 (Hit/Both) — 도착점에 재생 (fire-and-forget).
        if (vfxType == EVfxType.Hit || vfxType == EVfxType.Both)
        {
            bool hitPlayed = await SpawnHitVfxAsync(
                data.HitVfxKey,
                request.End,
                request.VisualSpeedMultiplier,
                token);
            played |= hitPlayed;
        }

        return played;
    }

    /// <summary>카드 1장 활성화 최소 연출 대기. _activationDelay 가 0 이면 즉시 반환.</summary>
    private async UniTask DelayActivationAsync(CancellationToken token, float visualSpeedMultiplier = 1f)
    {
        if (_activationDelay <= 0f) return;
        await UniTask.Delay(System.TimeSpan.FromSeconds(BattleSpeedUtility.ScaleDuration(
                _activationDelay,
                visualSpeedMultiplier,
                _chainVisualMinimumDuration)),
            cancellationToken: token);
    }

    /// <summary>투사체를 풀 키로 비동기 스폰해 출발→도착으로 이동시키고 풀 반환. 속도 기반 시간 계산.</summary>
    private async UniTask<bool> MoveProjectileAsync(
        string projectileKey,
        Vector3 start,
        Vector3 end,
        float visualSpeedMultiplier,
        CancellationToken token,
        int hitIndex = 0,
        int hitCount = 1,
        bool playSpawnSfx = true)
    {
        if (string.IsNullOrEmpty(projectileKey) || !PoolManager.HasInstance) return false;

        // 풀 키로 비동기 스폰 (미등록 키면 PoolManager 가 로드 후 자동 등록 → 첫 호출만 hitch).
        ProjectileObject proj = await PoolManager.Instance.SpawnAsync<ProjectileObject>(
            projectileKey, start, Quaternion.identity, null, token);
        if (proj == null) return false;

        if (playSpawnSfx)
        {
            PlayVfxSfx(projectileKey, token);
        }
        ProjectileTrajectory trajectory = BuildProjectileTrajectory(start, end, hitIndex, hitCount);
        proj.SetStart(start, end);
        proj.SetDirection(EvaluateProjectileArcTangent(start, end, 0f, trajectory));

        float pathDistance = EstimateProjectilePathLength(start, end, trajectory);
        float straightDistance = Vector3.Distance(start, end);
        float singleProjectileDuration = BattleSpeedUtility.ScaleDuration(
            straightDistance / _projectileSpeed,
            visualSpeedMultiplier,
            _chainVisualMinimumDuration);
        float duration = hitCount > 1
            ? Mathf.Max(0.01f, singleProjectileDuration / _multiHitProjectileSpeedMultiplier)
            : BattleSpeedUtility.ScaleDuration(
                pathDistance / _projectileSpeed,
                visualSpeedMultiplier,
                _chainVisualMinimumDuration);
        float elapsed = 0f;

        try
        {
            while (elapsed < duration)
            {
                if (token.IsCancellationRequested) break;
                elapsed += Time.deltaTime;
                float t = Mathf.Clamp01(elapsed / duration);
                proj.transform.position = EvaluateProjectileArc(start, end, t, trajectory);
                proj.SetDirection(EvaluateProjectileArcTangent(start, end, t, trajectory));
                await UniTask.Yield(PlayerLoopTiming.Update, token);
            }
        }
        finally
        {
            // 도착·취소 무관 반환 (풀 누수 방지).
            if (PoolManager.HasInstance && PoolManager.Instance.IsPooledInstance(proj.gameObject))
            {
                PoolManager.Instance.Despawn(proj);
            }
        }

        return true;
    }

    private ProjectileTrajectory BuildProjectileTrajectory(Vector3 start, Vector3 end, int hitIndex, int hitCount)
    {
        if (hitCount <= 1)
        {
            return ProjectileTrajectory.Straight;
        }

        Vector3 direction = end - start;
        float distance = direction.magnitude;
        if (distance <= 0.0001f)
        {
            return ProjectileTrajectory.Straight;
        }

        Vector3 curveAxis = new Vector3(-direction.y, direction.x, 0f);
        if (curveAxis.sqrMagnitude <= 0.0001f)
        {
            curveAxis = Vector3.up;
        }
        else
        {
            curveAxis.Normalize();
        }

        float angle = Mathf.Max(0f, _multiHitProjectileCurveAngle);
        float sign = hitIndex % 2 == 0 ? 1f : -1f;
        float angleOffset = Mathf.Tan(angle * Mathf.Deg2Rad) * distance * 0.25f;
        float offset = (_multiHitProjectileCurveHeight + angleOffset) * sign;
        return new ProjectileTrajectory(curveAxis, offset);
    }

    private static Vector3 EvaluateProjectileArc(Vector3 start, Vector3 end, float t, ProjectileTrajectory trajectory)
    {
        Vector3 position = Vector3.Lerp(start, end, t);
        float curve = 4f * t * (1f - t);
        return position +
               trajectory.CurveAxis * (trajectory.CurveOffset * curve);
    }

    private static Vector3 EvaluateProjectileArcTangent(Vector3 start, Vector3 end, float t, ProjectileTrajectory trajectory)
    {
        Vector3 tangent = end - start;
        float curveDerivative = 4f * (1f - 2f * t);
        tangent += trajectory.CurveAxis * (trajectory.CurveOffset * curveDerivative);
        return tangent;
    }

    private static float EstimateProjectilePathLength(Vector3 start, Vector3 end, ProjectileTrajectory trajectory)
    {
        if (trajectory.IsStraight) return Vector3.Distance(start, end);

        const int sampleCount = 12;
        float length = 0f;
        Vector3 previous = start;
        for (int i = 1; i <= sampleCount; i++)
        {
            float t = i / (float)sampleCount;
            Vector3 current = EvaluateProjectileArc(start, end, t, trajectory);
            length += Vector3.Distance(previous, current);
            previous = current;
        }
        return length;
    }

    private readonly struct ProjectileTrajectory
    {
        public static readonly ProjectileTrajectory Straight = new ProjectileTrajectory(Vector3.zero, 0f);

        public readonly Vector3 CurveAxis;
        public readonly float CurveOffset;

        public bool IsStraight => Mathf.Approximately(CurveOffset, 0f);

        public ProjectileTrajectory(Vector3 curveAxis, float curveOffset)
        {
            CurveAxis = curveAxis;
            CurveOffset = curveOffset;
        }
    }

    /// <summary>적중 이펙트를 풀 키로 도착점에 스폰 (fire-and-forget, 자동 반환은 VfxObject 가 처리).</summary>
    private void SpawnHitVfx(string hitVfxKey, Vector3 pos)
    {
        if (string.IsNullOrEmpty(hitVfxKey) || !PoolManager.HasInstance) return;

        // 비동기 스폰을 대기 없이 발사 (적중 연출은 다음 웨이브 진행을 막지 않음).
        SpawnHitVfxFireAndForgetAsync(hitVfxKey, pos).Forget();
    }

    private async UniTaskVoid SpawnHitVfxFireAndForgetAsync(string hitVfxKey, Vector3 pos)
    {
        await SpawnHitVfxAsync(hitVfxKey, pos, 1f, CancellationToken.None);
    }

    /// <summary>적중 이펙트를 스폰하고 위치 지정이 끝난 시점까지 대기한다.</summary>
    private async UniTask<bool> SpawnHitVfxAsync(
        string hitVfxKey,
        Vector3 pos,
        float visualSpeedMultiplier,
        CancellationToken token)
    {
        if (string.IsNullOrEmpty(hitVfxKey) || !PoolManager.HasInstance)
        {
            return false;
        }

        VfxObject vfx = await PoolManager.Instance.SpawnAsync<VfxObject>(
            hitVfxKey, pos, Quaternion.identity, null, token);
        if (vfx == null) return false;

        PlayVfxSfx(hitVfxKey, token);
        vfx.SetPosition(pos);
        vfx.SetPlaybackSpeed(visualSpeedMultiplier, _chainVisualMinimumDuration);
        return true;
    }

    private void PlayVfxSfx(
        string vfxKey,
        CancellationToken token,
        float pitchMultiplier = 1f,
        bool allowRandomPitch = true)
    {
        if (_vfxAudioCatalog == null ||
            !AudioManager.HasInstance ||
            !_vfxAudioCatalog.TryFind(vfxKey, out BattleVfxAudioCue cue))
        {
            return;
        }

        AudioManager.Instance.PlaySfxAsync(
            cue.SfxKey,
            cue.Volume,
            Mathf.Clamp(cue.Pitch * pitchMultiplier, 0.1f, 3f),
            allowRandomPitch && cue.RandomPitch,
            token).Forget();
    }

    private float GetCardVisualSpeed(Card card)
    {
        return card != null && _cardVisualSpeeds.TryGetValue(card, out float multiplier)
            ? multiplier
            : 1f;
    }

    private Material GetSignalLineMaterial()
    {
        if (_signalLineMaterialOverride != null) return _signalLineMaterialOverride;
        if (_signalLineMaterial != null) return _signalLineMaterial;

        Shader shader = Shader.Find("Sprites/Default");
        if (shader == null)
        {
            shader = Shader.Find("Universal Render Pipeline/Unlit");
        }
        if (shader == null) return null;

        _signalLineMaterial = new Material(shader)
        {
            color = _signalLineColor
        };
        return _signalLineMaterial;
    }

    /// <summary>
    /// 무한루프 감지 시 호출. 연출은 아직 정해지지 않아 무동작이다.
    /// ChainExecutor 는 이 시점에 현재 체인만 중단하고 전투를 계속하므로,
    /// 여기서 예외를 던지면 그 복구 흐름 자체가 깨진다(체인이 예외로 터진다).
    /// 발동 사실은 ChainExecutor.OnInfiniteLoopDetected 이벤트로 분석에 기록된다.
    /// </summary>
    public void OnInfiniteLoopDetected(Card rootCard)
    {
#if UNITY_EDITOR || DEVELOPMENT_BUILD
        Debug.LogWarning($"[BattleVfxPresenter] 무한루프 감지 — 체인 중단. 원인 카드={rootCard?.CardId}");
#endif
    }
}
