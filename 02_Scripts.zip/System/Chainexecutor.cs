// =================================================================
// [스크립트 목적]  카드 활성화 체인 전파 (BFS 웨이브). ON된 카드의 방향 이웃을 순차 토글
// [주요 변수]      - _grid       : 그리드 조회·상태 접근 (IGridStatProvider 겸 GridManager)
//                  - _dispatcher : 효과 실행 위임 (CardPhaseDispatcher)
//                  - _presenter  : 연출 위임 (피드백/모션 — 팀원 구현)
//                  - _maxSteps   : 안전 한도 (무한 전파 방지)
// [의존 관계]      - GridManager / CardPhaseDispatcher / IChainPresenter
//                  - Card / GridCardState / ECardDirection / UniTask
// [설계 노트]      - zip ChainExecutor 의 거대 ApplyEffects switch 는 폐기 →
//                    효과 실행은 CardPhaseDispatcher 에 위임 (책임 분리)
//                  - 체인은 실제 토글 200회까지 진행하고, 한도 도달 시 현재 체인만 중단
//                  - Coroutine → UniTask 이식 (프로젝트 비동기 컨벤션)
// =================================================================

using System.Collections.Generic;
using System;
using System.Threading;
using Cysharp.Threading.Tasks;
using UnityEngine;

/// <summary>
/// 카드 활성화 체인을 전파하는 실행기.
/// 루트 카드를 토글하고, ON 된 카드의 방향(range 만큼) 이웃을 다음 웨이브로 모아 반복한다 (BFS).
/// 효과 실행은 디스패처, 연출은 프리젠터에 위임하여 전파 로직만 책임진다.
/// 안전 한도(_maxSteps)로 무한 전파를 차단한다 (정교한 루프 감지는 다음 단계).
/// </summary>
public sealed class ChainExecutor
{
    private readonly GridManager _grid;
    private readonly CardPhaseDispatcher _dispatcher;
    private readonly IChainPresenter _presenter;
    private readonly ICombatActor _caster;
    private readonly int _maxSteps;
    private readonly int _chainLoopActivationLimit;
    private readonly int _chainVisualSpeedStartCount;
    private readonly float _chainVisualSpeedPerChain;
    private readonly float _chainVisualMinimumDuration;
    private readonly Dictionary<Card, float> _cardVisualSpeeds = new Dictionary<Card, float>();
    private int _executionDepth;
    private int _stepSafetyLimit;
    private int _executedSteps;
    private int _chainActivatedCount;
    private Card _loopCauseCard;          // 체인 한도(무한루프)에 도달시킨 카드 (통지 좌표용)
    private bool _loopNotified;           // 이번 체인에서 무한루프를 이미 통지했는지 (중복 집계 방지)
    private bool _processingAutoTriggers;
    private bool _stepLimitReached;

    /// <summary>체인 실행 중 여부 (입력 차단 판단용).</summary>
    public bool IsExecuting { get; private set; }

    /// <summary>이번 체인에서 ON 된 카드 집합 (외부 조회용).</summary>
    private readonly HashSet<Card> _activatedCards = new HashSet<Card>();
    public IReadOnlyCollection<Card> ActivatedCards => _activatedCards;

    /// <summary>카드 토글 직후 통지. 튜토리얼 등 선택 시스템이 상태 변화를 관찰한다.</summary>
    public event Action<Card, bool> OnCardToggled;

    /// <summary>카드 토글 직후 비동기 대기 훅. 튜토리얼 설명처럼 체인을 잠시 멈출 때 사용한다.</summary>
    public event Func<Card, bool, CancellationToken, UniTask> OnCardToggledAsync;

    /// <summary>현재 체인에서 누적된 ON(활성화) 수. 체인 내 단조 증가 → 리셋 직전 값이 그 체인의 피크.</summary>
    public int ChainActivatedCount => _chainActivatedCount;
    /// <summary>현재 표시 체인이 ON 한도에 도달해 후속 반응 요청을 중단해야 하는지.</summary>
    public bool HasReachedActivationLimit => _chainActivatedCount >= _chainLoopActivationLimit;

    /// <summary>이번 루트 체인에서 카드가 ON 된 누적 순번을 통지한다.</summary>
    public event Func<Card, int, CancellationToken, UniTask> OnCardActivatedInChainAsync;

    /// <summary>
    /// 토글 안전 한도 도달(무한루프 감지) 통지. 인자: 원인 카드, 그리드 좌표.
    /// 연출용 _presenter 호출과 별개로, 분석 등 외부 시스템이 구독하는 지점이다.
    /// </summary>
    public event Action<Card, Vector2Int> OnInfiniteLoopDetected;

    public ChainExecutor(
        GridManager grid,
        CardPhaseDispatcher dispatcher,
        IChainPresenter presenter,
        ICombatActor caster,
        int maxSteps = 200,
        int chainLoopActivationLimit = 100,
        int chainVisualSpeedStartCount = 10,
        float chainVisualSpeedPerChain = 0.01f,
        float chainVisualMinimumDuration = 0.05f)
    {
        _grid = grid;
        _dispatcher = dispatcher;
        _presenter = presenter ?? new NullChainPresenter();
        _caster = caster;
        _maxSteps = Mathf.Max(1, maxSteps);
        _chainLoopActivationLimit = Mathf.Max(1, chainLoopActivationLimit);
        _chainVisualSpeedStartCount = Mathf.Max(1, chainVisualSpeedStartCount);
        _chainVisualSpeedPerChain = Mathf.Max(0f, chainVisualSpeedPerChain);
        _chainVisualMinimumDuration = Mathf.Max(0f, chainVisualMinimumDuration);
    }

    /// <summary>화면에 표시되는 한 체인의 시작·종료 경계에서 ON 누적 수를 초기화한다.</summary>
    public void ResetChainActivatedCount()
    {
        _chainActivatedCount = 0;
        _loopCauseCard = null;
        _loopNotified = false;
    }

    /// <summary>
    /// 루트 카드부터 체인 전파 시작.
    /// 각 웨이브의 카드를 토글하고, ON 전환된 카드는 효과 실행 + 이웃 수집.
    /// </summary>
    public async UniTask ExecuteFromAsync(Card rootCard, CancellationToken token)
    {
        if (rootCard == null || _grid == null) return;

        bool isRootExecution = _executionDepth == 0;
        if (isRootExecution)
        {
            _stepSafetyLimit = ResolveStepSafetyLimit();
            _executedSteps = 0;
            _stepLimitReached = false;
            _cardVisualSpeeds.Clear();
        }

        _executionDepth++;
        IsExecuting = true;
        if (isRootExecution)
        {
            _activatedCards.Clear();
        }

        bool completed = false;
        try
        {
            await ActivateChainAsync(new ChainSignal(rootCard, 1), token);
            completed = !token.IsCancellationRequested && !_stepLimitReached;
        }
        finally
        {
            _executionDepth--;
            IsExecuting = _executionDepth > 0;
        }

        if (isRootExecution && completed)
        {
            try
            {
                await ProcessAutoTriggersAsync(token);
            }
            finally
            {
                _cardVisualSpeeds.Clear();
                _presenter.ClearCardVisualSpeeds();
            }
        }
        else if (isRootExecution)
        {
            _cardVisualSpeeds.Clear();
            _presenter.ClearCardVisualSpeeds();
        }
    }

    /// <summary>
    /// emitter 자체는 다시 토글하지 않고, emitter의 체인 설정으로 찾은 첫 대상부터 추가 전파한다.
    /// ToggleEffect가 기존 자동 체인과 별도로 신호를 발생시킬 때 사용한다.
    /// </summary>
    public async UniTask ExecuteFromEmitterAsync(Card emitter, CancellationToken token)
    {
        if (emitter == null || _grid == null || token.IsCancellationRequested)
        {
            return;
        }

        bool isRootExecution = _executionDepth == 0;
        if (isRootExecution)
        {
            _stepSafetyLimit = ResolveStepSafetyLimit();
            _executedSteps = 0;
            _activatedCards.Clear();
            _stepLimitReached = false;
            _cardVisualSpeeds.Clear();
        }

        _executionDepth++;
        IsExecuting = true;
        bool completed = false;
        try
        {
            List<Card> emitters = new List<Card>(1) { emitter };
            List<ChainSignal> firstWave = CollectNextWave(emitters);
            if (firstWave.Count > 0)
            {
                await ActivateChainAsync(firstWave, token);
            }
            completed = !token.IsCancellationRequested && !_stepLimitReached;
        }
        finally
        {
            _executionDepth--;
            IsExecuting = _executionDepth > 0;
        }

        if (isRootExecution && completed)
        {
            try
            {
                await ProcessAutoTriggersAsync(token);
            }
            finally
            {
                _cardVisualSpeeds.Clear();
                _presenter.ClearCardVisualSpeeds();
            }
        }
        else if (isRootExecution)
        {
            _cardVisualSpeeds.Clear();
            _presenter.ClearCardVisualSpeeds();
        }
    }

    /// <summary>반응형 효과가 자기 자신을 토글할 때 사용하는 공식 경로.</summary>
    public async UniTask ExecuteReactiveSelfToggleAsync(Card owner, CancellationToken token)
    {
        await ExecuteFromAsync(owner, token);
    }

    /// <summary>
    /// 최상위 체인이 완전히 끝난 뒤 자동 토글 조건을 좌표 순서로 검사한다.
    /// 자동 토글에서 발생한 후속 체인도 같은 실행 단계 한도 안에서 모두 처리한다.
    /// </summary>
    private async UniTask ProcessAutoTriggersAsync(CancellationToken token)
    {
        if (_processingAutoTriggers || token.IsCancellationRequested || _grid == null)
        {
            return;
        }

        _processingAutoTriggers = true;
        _executionDepth++;
        IsExecuting = true;
        try
        {
            while (!token.IsCancellationRequested && !_stepLimitReached)
            {
                int activatedCount = CountActivatedCards();
                List<Card> orderedCards = GetPlacedCardsInGridOrder();
                Card triggerCard = null;

                for (int i = 0; i < orderedCards.Count; i++)
                {
                    Card card = orderedCards[i];
                    if (card == null || !_grid.TryGetPosition(card, out _)) continue;

                    IReadOnlyList<CardEffectBase> effects = card.Effects;
                    for (int j = 0; j < effects.Count; j++)
                    {
                        if (effects[j] is AutoToggleEffect autoToggle &&
                            autoToggle.Evaluate(activatedCount))
                        {
                            triggerCard = card;
                            break;
                        }
                    }

                    if (triggerCard != null) break;
                }

                if (triggerCard == null)
                {
                    return;
                }

                await ActivateChainAsync(new ChainSignal(triggerCard, 1), token);
            }
        }
        finally
        {
            _executionDepth--;
            IsExecuting = _executionDepth > 0;
            _processingAutoTriggers = false;
        }
    }

    private int CountActivatedCards()
    {
        int count = 0;
        foreach (Card card in _grid.PlacedCards)
        {
            if (card != null && card.GridState.IsActivated)
            {
                count++;
            }
        }
        return count;
    }

    private List<Card> GetPlacedCardsInGridOrder()
    {
        List<Card> cards = new List<Card>(_grid.PlacedCards);
        cards.Sort((left, right) =>
        {
            bool hasLeft = _grid.TryGetPosition(left, out Vector2Int leftPos);
            bool hasRight = _grid.TryGetPosition(right, out Vector2Int rightPos);
            if (!hasLeft || !hasRight) return hasLeft ? -1 : hasRight ? 1 : 0;

            int row = leftPos.y.CompareTo(rightPos.y);
            return row != 0 ? row : leftPos.x.CompareTo(rightPos.x);
        });
        return cards;
    }

    /// <summary>
    /// 체인 BFS 본체. currentWave 를 토글하며 nextWave 를 수집해 반복.
    /// 구버전처럼 카드를 "하나씩" 순차로 켠다 — 토글→ON비주얼→효과→연출대기를 카드 단위로
    /// 처리해, 동시에 결과만 뜨지 않고 한 장씩 활성화되며 전파되는 흐름을 보여준다.
    /// </summary>
    private async UniTask ActivateChainAsync(ChainSignal root, CancellationToken token)
    {
        await ActivateChainAsync(new List<ChainSignal> { root }, token);
    }

    private async UniTask ActivateChainAsync(List<ChainSignal> initialWave, CancellationToken token)
    {
        List<ChainSignal> currentWave = initialWave;
        List<Card> emitters = new List<Card>(8);   // 이번 웨이브에서 ON 된 카드 (전파 발신원)
        List<WaveActivation> activations = new List<WaveActivation>(8);
        List<Card> activationVfxCards = new List<Card>(8);
        List<UniTask> feedbackTasks = new List<UniTask>(8);
        List<UniTask> toggleHookTasks = new List<UniTask>(8);
        List<(Card Card, int Count)> milestoneHooks = new List<(Card, int)>(2);
        while (currentWave.Count > 0)
        {
            if (_stepLimitReached) return;
            emitters.Clear();
            activations.Clear();
            activationVfxCards.Clear();
            feedbackTasks.Clear();
            toggleHookTasks.Clear();
            milestoneHooks.Clear();

            // 현재 웨이브의 토글 비주얼을 먼저 모두 반영한다.
            foreach (ChainSignal incoming in currentWave)
            {
                Card current = incoming.Target;
                if (current == null) continue;

                GridCardState state = _grid.GetCardState(current);
                if (state == null) continue; // 그리드에서 빠진 카드 스킵

                // 토글 총량 하드 세이프티 (진짜 폭주 방지). 체인 100 판정과 별개의 최종 안전장치.
                // 단, 이미 체인 한도(100)에 도달한 웨이브라면 양보한다 — 이 웨이브 끝에서 어차피
                // 중단되므로, 여기서 선점해 return 하면 아직 안 돈 100 피니셔 마일스톤이 막힌다.
                if (_executedSteps >= _stepSafetyLimit && _chainActivatedCount < _chainLoopActivationLimit)
                {
                    _stepLimitReached = true;
                    Debug.LogWarning(
                        $"[ChainExecutor] 토글 {_stepSafetyLimit}회 안전 한도 도달. " +
                        "현재 체인만 중단하고 전투를 계속합니다.");
                    NotifyInfiniteLoop(current);
                    return;
                }
                _executedSteps++;

                bool activated = state.Toggle();
                bool countedActivation = false;
                int chainActivatedCount = _chainActivatedCount;
                if (activated)
                {
                    if (_chainActivatedCount < _chainLoopActivationLimit)
                    {
                        _chainActivatedCount++;
                        chainActivatedCount = _chainActivatedCount;
                        countedActivation = true;
                        // 체인 한도에 도달시킨 카드를 기억 (무한루프 통지 좌표용).
                        if (_chainActivatedCount == _chainLoopActivationLimit)
                        {
                            _loopCauseCard = current;
                            // 도달 즉시 통지한다. 이 웨이브의 피니셔가 적을 처치하면 전투 종료로 토큰이
                            // 취소되어 아래 웨이브 종료 지점까지 오지 못하고, 통계·업적·분석이 통째로 누락된다.
                            // (프리젠터 통지는 무동작이라 연출 순서에는 영향이 없다)
                            NotifyInfiniteLoop(current);
                        }
                    }
                    float visualSpeedMultiplier = GetVisualSpeedMultiplier(chainActivatedCount);
                    _cardVisualSpeeds[current] = visualSpeedMultiplier;
                    _presenter.SetCardVisualSpeed(current, visualSpeedMultiplier);
                }

                // OFF 전환도 현재 누적 ON 체인 배속으로 플립한다.
                float visualSpeedMultiplierForFeedback = GetVisualSpeedMultiplier(_chainActivatedCount);

                // 마지막 동시 웨이브는 모두 토글하되 100을 넘는 체인 팝업과 마일스톤은 만들지 않는다.
                if (!activated || countedActivation)
                {
                    _presenter.OnCardToggled(current, activated);
                }
                _grid.SetCardActivatedImmediate(current, activated);
                OnCardToggled?.Invoke(current, activated);
                feedbackTasks.Add(_grid.PlayCardToggleFeedbackAsync(
                    current,
                    incoming.FromDirection,
                    visualSpeedMultiplierForFeedback,
                    _chainVisualMinimumDuration,
                    token));
                if (OnCardToggledAsync != null)
                {
                    toggleHookTasks.Add(InvokeCardToggledAsync(current, activated, token));
                }
                if (countedActivation && OnCardActivatedInChainAsync != null)
                {
                    milestoneHooks.Add((current, chainActivatedCount));
                }
                activations.Add(new WaveActivation(current, activated));

                if (activated)
                {
                    emitters.Add(current);
                    _activatedCards.Add(current);

                    // ON 카운트 누적 (Self/Grid 집계 원천).
                    state.IncrementTurnOnCount();
                    _grid.IncrementTurnToggleCount();

                }
                else
                {
                    _activatedCards.Remove(current);
                }
            }

            if (feedbackTasks.Count > 0)
            {
                await UniTask.WhenAll(feedbackTasks);
                if (token.IsCancellationRequested) return;
            }

            if (toggleHookTasks.Count > 0)
            {
                await UniTask.WhenAll(toggleHookTasks);
                if (token.IsCancellationRequested) return;
            }

            // 마일스톤 공격은 Chain 순번대로 완료해 장시간 연출끼리 겹치지 않게 한다.
            for (int i = 0; i < milestoneHooks.Count; i++)
            {
                (Card milestoneCard, int milestoneCount) = milestoneHooks[i];
                await InvokeCardActivatedInChainAsync(milestoneCard, milestoneCount, token);
                if (token.IsCancellationRequested) return;
            }

            // 효과 실행 순서는 기존처럼 웨이브 내 카드 순서를 유지한다.
            for (int i = 0; i < activations.Count; i++)
            {
                WaveActivation activation = activations[i];
                Card current = activation.Card;
                if (current == null) continue;

                if (activation.Activated)
                {
                    CardDispatchResult dispatchResult = CardDispatchResult.None;
                    if (_dispatcher != null)
                    {
                        await _dispatcher.NotifyActivationChangedAsync(current, _caster, true, token);
                        dispatchResult = await _dispatcher.DispatchActivationAsync(current, _caster, null, token);

                        await NotifyOtherCardsActivatedAsync(current, token);
                        await _dispatcher.AdvanceCastingQueueAsync(current, token);
                    }

                    if (token.IsCancellationRequested) return;

                    if (!dispatchResult.PlayedImpactVfx)
                    {
                        activationVfxCards.Add(current);
                    }

                }
                else if (_dispatcher != null)
                {
                    await _dispatcher.NotifyActivationChangedAsync(current, _caster, false, token);
                }
            }

            if (activationVfxCards.Count > 0)
            {
                _presenter.ScheduleActivationVfx(activationVfxCards, token);
            }

            // 체인(활성화) 한도 도달 = 무한루프로 판정.
            // 이번 웨이브의 피니셔(마일스톤)·효과는 위에서 모두 실행된 뒤이므로,
            // 다음 웨이브 수집만 막아 "피니셔 발동 후 전파 중단" 이 된다.
            // 통지 자체는 위 토글 시점에서 이미 끝났고, 여기서는 중복 통지가 차단된다.
            if (_chainActivatedCount >= _chainLoopActivationLimit)
            {
                _stepLimitReached = true;
                Debug.LogWarning(
                    $"[ChainExecutor] 체인 {_chainLoopActivationLimit}회 도달(무한루프 판정). " +
                    "현재 체인만 중단하고 전투를 계속합니다.");
                NotifyInfiniteLoop(_loopCauseCard);
                return;
            }

            // ON 된 카드들의 방향 이웃을 다음 웨이브로 수집.
            currentWave = CollectNextWave(emitters);
        }
    }

    private int ResolveStepSafetyLimit()
    {
        int gridCapacity = Mathf.Max(_grid.PlacedCards.Count, _grid.Rows * _grid.Columns);
        return Mathf.Max(_maxSteps, (_chainLoopActivationLimit * 2) + gridCapacity);
    }

    /// <summary>
    /// 무한루프(토글 안전 한도 / 체인 한도) 감지를 외부 구독자와 연출에 통지한다.
    /// 분석 등 외부 구독자에 먼저 통지(연출과 분리) — 연출에서 예외가 나도 기록은 남는다.
    /// 좌표를 못 찾으면 (-1,-1).
    /// </summary>
    private void NotifyInfiniteLoop(Card cause)
    {
        // 한 체인당 1회만 통지 (한도 도달 시점 + 웨이브 종료 시점 중복 호출 차단).
        if (_loopNotified) return;
        _loopNotified = true;

        if (OnInfiniteLoopDetected != null)
        {
            Vector2Int loopPos = _grid != null && cause != null && _grid.TryGetPosition(cause, out Vector2Int found)
                ? found
                : new Vector2Int(-1, -1);
            OnInfiniteLoopDetected.Invoke(cause, loopPos);
        }

        _presenter.OnInfiniteLoopDetected(cause);
    }

    private static bool HasTriggerPhase(Card card, ETriggerPhase phase)
    {
        if (card == null)
        {
            return false;
        }

        IReadOnlyList<CardEffectBase> effects = card.Effects;
        for (int i = 0; i < effects.Count; i++)
        {
            if (effects[i] != null && effects[i].TriggerPhase == phase)
            {
                return true;
            }
        }
        return false;
    }

    private readonly struct ChainSignal
    {
        public Card Target { get; }

        /// <summary>이 신호가 흘러온 진행 방향(도미노 연출용). 루트/패턴 전파는 None.</summary>
        public ECardDirection FromDirection { get; }

        public ChainSignal(Card target, int strength)
            : this(target, strength, ECardDirection.None)
        {
        }

        public ChainSignal(Card target, int strength, ECardDirection fromDirection)
        {
            Target = target;
            FromDirection = fromDirection;
        }
    }

    private readonly struct WaveActivation
    {
        public Card Card { get; }
        public bool Activated { get; }

        public WaveActivation(Card card, bool activated)
        {
            Card = card;
            Activated = activated;
        }
    }

    /// <summary>
    /// emitters(ON 카드)의 각 방향으로 range 만큼 진행하며, 카드의 전파 타입에 따라
    /// 점유 카드를 다음 웨이브로 모은다. 4방위 ECardDirection 을 비트 분해해 개별 탐색한다.
    /// 전파 도중 '신호가 흐른' 구간은 프리젠터(OnSignalPropagated)로 통지해 방향선 연출을 맡긴다.
    /// </summary>
    private List<ChainSignal> CollectNextWave(List<Card> emitters)
    {
        List<ChainSignal> orderedNext = new List<ChainSignal>(8);
        HashSet<Card> seen = new HashSet<Card>();

        for (int e = 0; e < emitters.Count; e++)
        {
            Card emitter = emitters[e];
            if (!_grid.TryGetPosition(emitter, out Vector2Int origin)) continue;
            if (emitter.PatternType != EChainPatternType.Line)
            {
                CollectByPattern(emitter, origin, orderedNext, seen);
                continue;
            }

            ECardDirection dirs = emitter.Arrow != null ? emitter.Arrow.Current : ECardDirection.None;
            if (dirs == ECardDirection.None) continue;

            int range = Mathf.Max(1, GetRange(emitter));
            EChainPropagation rule = emitter.Propagation;

            // 4방위 비트 분해 — 각 방향으로 range 칸 전파 (전파 타입 규칙 적용).
            CollectInDirection(emitter, origin, dirs, ECardDirection.Up, range, rule, orderedNext, seen);
            CollectInDirection(emitter, origin, dirs, ECardDirection.UpRight, range, rule, orderedNext, seen);
            CollectInDirection(emitter, origin, dirs, ECardDirection.Right, range, rule, orderedNext, seen);
            CollectInDirection(emitter, origin, dirs, ECardDirection.DownRight, range, rule, orderedNext, seen);
            CollectInDirection(emitter, origin, dirs, ECardDirection.Down, range, rule, orderedNext, seen);
            CollectInDirection(emitter, origin, dirs, ECardDirection.DownLeft, range, rule, orderedNext, seen);
            CollectInDirection(emitter, origin, dirs, ECardDirection.Left, range, rule, orderedNext, seen);
            CollectInDirection(emitter, origin, dirs, ECardDirection.UpLeft, range, rule, orderedNext, seen);
        }

        // 최초 발견 순서를 유지하면서 같은 웨이브의 중복 대상만 제거한다.
        return orderedNext;
    }

    /// <summary>
    /// dirs 에 single 방향 비트가 있으면 그 방향으로 range 칸 진행하며 전파 규칙대로 카드 수집.
    /// - Pierce          : 경로상 모든 점유 카드 수집, range 끝까지 진행
    /// - BlockOnFirstCard: 첫 점유 카드 수집 후 즉시 중단 (빈칸은 통과)
    /// - StopOnGap       : 칸이 비어 있으면 그 방향 전파 즉시 중단 (연속 배치만 흐름)
    /// 진행한 각 칸은 프리젠터로 통지해 방향선 연출을 맡긴다 (좌표는 그리드가 계산).
    /// </summary>
    private void CollectInDirection(
        Card emitter,
        Vector2Int origin,
        ECardDirection dirs,
        ECardDirection single,
        int range,
        EChainPropagation rule,
        List<ChainSignal> ordered,
        HashSet<Card> seen)
    {
        if ((dirs & single) == 0) return;

        Vector2Int delta = DirectionToDelta(single);
        Vector2Int cursor = origin;

        // 발신 카드의 월드 좌표 (방향선 출발점). 조회 실패 시 연출만 생략.
        bool hasFrom = _grid.TryGetCardWorldPosition(emitter, out Vector3 fromWorld);

        for (int i = 0; i < range; i++)
        {
            cursor += delta;
            GridSlot slot = _grid.GetSlot(cursor);
            if (slot == null) break; // 그리드 밖 — 더 진행 불가

            bool occupied = _grid.TryGetOccupiedCard(cursor, out Card reachedCard);

            // 방향선 연출 통지 (도달 카드 기준). 빈칸에는 연쇄 이펙트를 표시하지 않는다.
            if (occupied && hasFrom)
            {
                _presenter.OnSignalPropagated(
                    emitter,
                    fromWorld,
                    slot.transform.position,
                    reachedCard,
                    GetVisualSpeedMultiplierForCard(emitter));
            }

            if (occupied)
            {
                AddOrdered(reachedCard, single, ordered, seen);

                // 차단형: 첫 카드를 만나면 그 방향 전파 종료.
                if (rule == EChainPropagation.BlockOnFirstCard)
                {
                    break;
                }
                // 관통형(Pierce): 계속 진행. StopOnGap 도 카드면 계속(빈칸에서만 멈춤).
            }
            else
            {
                // 빈칸 막힘형: 빈칸을 만나면 그 방향 전파 종료.
                if (rule == EChainPropagation.StopOnGap)
                {
                    break;
                }
                // Pierce / BlockOnFirstCard 는 빈칸 통과.
            }
        }
    }

    /// <summary>카드 전파 사거리. Card 가 SO(GetRange)에서 캐싱한 값을 사용 (강화 반영).</summary>
    private static int GetRange(Card card)
    {
        return card != null ? card.Range : 1;
    }

    /// <summary>4방위 → 좌표 델타. 확장 시 대각선 추가.</summary>
    private static Vector2Int DirectionToDelta(ECardDirection direction) => direction switch
    {
        ECardDirection.Up => new Vector2Int(0, 1),
        ECardDirection.Down => new Vector2Int(0, -1),
        ECardDirection.Left => new Vector2Int(-1, 0),
        ECardDirection.Right => new Vector2Int(1, 0),
        ECardDirection.UpLeft => new Vector2Int(-1, 1),
        ECardDirection.UpRight => new Vector2Int(1, 1),
        ECardDirection.DownLeft => new Vector2Int(-1, -1),
        ECardDirection.DownRight => new Vector2Int(1, -1),
        _ => Vector2Int.zero
    };

    /// <summary>좌표 델타 → 8방위 (부호만 사용). 패턴 전파의 도미노 토글 방향 계산용.</summary>
    private static ECardDirection DeltaToDirection(Vector2Int delta)
    {
        ECardDirection dir = ECardDirection.None;
        if (delta.y > 0) dir |= ECardDirection.Up;
        else if (delta.y < 0) dir |= ECardDirection.Down;
        if (delta.x > 0) dir |= ECardDirection.Right;
        else if (delta.x < 0) dir |= ECardDirection.Left;
        return dir;
    }

    private async UniTask NotifyOtherCardsActivatedAsync(Card activatedCard, CancellationToken token)
    {
        if (_dispatcher == null || _grid == null || activatedCard == null)
        {
            return;
        }

        List<Card> snapshot = new List<Card>(_grid.PlacedCards);
        for (int i = 0; i < snapshot.Count; i++)
        {
            Card card = snapshot[i];
            if (card == null || card == activatedCard) continue;

            await _dispatcher.NotifyOtherCardActivatedAsync(card, activatedCard, _caster, token);
            if (token.IsCancellationRequested)
            {
                return;
            }
        }
    }

    private void CollectByPattern(
        Card emitter,
        Vector2Int origin,
        List<ChainSignal> ordered,
        HashSet<Card> seen)
    {
        switch (emitter.PatternType)
        {
            case EChainPatternType.FrontCone2:
                CollectFrontCone2(emitter, origin, ordered, seen);
                break;

            case EChainPatternType.ForwardSkip1:
                CollectForwardSkip1(emitter, origin, ordered, seen);
                break;

            case EChainPatternType.ImpactCrossForward2:
                CollectImpactCross(emitter, origin, 2, ordered, seen);
                break;

            case EChainPatternType.ShotgunForward2:
                CollectShotgunForward2(emitter, origin, ordered, seen);
                break;
        }
    }

    private void CollectForwardSkip1(
        Card emitter,
        Vector2Int origin,
        List<ChainSignal> ordered,
        HashSet<Card> seen)
    {
        ECardDirection dirs = emitter.Arrow != null ? emitter.Arrow.Current : ECardDirection.None;
        foreach (ECardDirection dir in EnumerateDirections(dirs))
        {
            Vector2Int target = origin + (DirectionToDelta(dir) * 2);
            AddCardAt(target, ordered, seen, emitter, dir, emitter);
        }
    }

    private void CollectFrontCone2(
        Card emitter,
        Vector2Int origin,
        List<ChainSignal> ordered,
        HashSet<Card> seen)
    {
        ECardDirection dirs = emitter.Arrow != null ? emitter.Arrow.Current : ECardDirection.None;
        foreach (ECardDirection dir in EnumerateDirections(dirs))
        {
            Vector2Int delta = DirectionToDelta(dir);
            Vector2Int impact = origin + (delta * 2);
            Vector2Int sideA = impact + new Vector2Int(-delta.y, delta.x);
            Vector2Int sideB = impact + new Vector2Int(delta.y, -delta.x);

            AddCardAt(impact, ordered, seen, null, dir, emitter);
            AddCardAt(sideA, ordered, seen, null, DeltaToDirection(sideA - origin), emitter);
            AddCardAt(sideB, ordered, seen, null, DeltaToDirection(sideB - origin), emitter);
        }
    }

    private void CollectImpactCross(
        Card emitter,
        Vector2Int origin,
        int forwardDistance,
        List<ChainSignal> ordered,
        HashSet<Card> seen)
    {
        ECardDirection dirs = emitter.Arrow != null ? emitter.Arrow.Current : ECardDirection.None;
        foreach (ECardDirection dir in EnumerateDirections(dirs))
        {
            Vector2Int center = origin + (DirectionToDelta(dir) * Mathf.Max(1, forwardDistance));
            CollectCrossAround(emitter, origin, center, ordered, seen);
        }
    }

    /// <summary>
    /// 샷건 패턴 수집: 1칸 앞 + 2칸 앞 + 2칸 앞의 진행방향 양옆 4칸의 카드를 모은다.
    /// 우측 방향이면 (1,0)(2,0)(2,1)(2,-1). 진행축에 수직인 양옆은 (-delta.y, delta.x).
    /// </summary>
    private void CollectShotgunForward2(
        Card emitter,
        Vector2Int origin,
        List<ChainSignal> ordered,
        HashSet<Card> seen)
    {
        ECardDirection dirs = emitter.Arrow != null ? emitter.Arrow.Current : ECardDirection.None;
        foreach (ECardDirection dir in EnumerateDirections(dirs))
        {
            Vector2Int delta = DirectionToDelta(dir);
            Vector2Int forward1 = origin + delta;            // 1칸 앞
            Vector2Int forward2 = origin + (delta * 2);      // 2칸 앞
            Vector2Int perp = new Vector2Int(-delta.y, delta.x); // 진행축 수직

            // 진행 칸은 발사 방향 그대로, 양옆 칸은 발신 기준 대각선 방향으로 넘어간다.
            AddCardAt(forward1, ordered, seen, emitter, dir, emitter);
            AddCardAt(forward2, ordered, seen, emitter, dir, emitter);
            AddCardAt(forward2 + perp, ordered, seen, emitter, DeltaToDirection(forward2 + perp - origin), emitter);
            AddCardAt(forward2 - perp, ordered, seen, emitter, DeltaToDirection(forward2 - perp - origin), emitter);
        }
    }

    private void CollectCrossAround(
        Card emitter,
        Vector2Int origin,
        Vector2Int center,
        List<ChainSignal> ordered,
        HashSet<Card> seen)
    {
        // 도미노 방향은 발신 카드(origin) 기준 — 충격이 발신점에서 퍼져나가는 인상.
        AddCrossCell(center, emitter, origin, ordered, seen);
        AddCrossCell(center + Vector2Int.up, emitter, origin, ordered, seen);
        AddCrossCell(center + Vector2Int.right, emitter, origin, ordered, seen);
        AddCrossCell(center + Vector2Int.down, emitter, origin, ordered, seen);
        AddCrossCell(center + Vector2Int.left, emitter, origin, ordered, seen);
    }

    private void AddCrossCell(
        Vector2Int pos,
        Card emitter,
        Vector2Int origin,
        List<ChainSignal> ordered,
        HashSet<Card> seen)
    {
        AddCardAt(pos, ordered, seen, null, DeltaToDirection(pos - origin), emitter);
    }

    /// <summary>
    /// 좌표의 점유 카드를 신호 목록에 추가한다 (패턴 수집 공용).
    /// fromDirection 은 도미노 토글 방향으로 쓰이고, emitter 를 주면
    /// Line 패턴(CollectInDirection)과 동일하게 발신→도달 방향선 연출도 통지한다.
    /// </summary>
    private void AddCardAt(
        Vector2Int pos,
        List<ChainSignal> ordered,
        HashSet<Card> seen,
        Card excluded = null,
        ECardDirection fromDirection = ECardDirection.None,
        Card emitter = null)
    {
        if (_grid == null || !_grid.TryGetOccupiedCard(pos, out Card card) || card == null) return;
        if (card == excluded) return;
        if (!seen.Add(card)) return;

        ordered.Add(new ChainSignal(card, 1, fromDirection));

        if (emitter != null && _grid.TryGetCardWorldPosition(emitter, out Vector3 fromWorld))
        {
            GridSlot slot = _grid.GetSlot(pos);
            if (slot != null)
            {
                _presenter.OnSignalPropagated(
                    emitter,
                    fromWorld,
                    slot.transform.position,
                    card,
                    GetVisualSpeedMultiplierForCard(emitter));
            }
        }
    }

    private static void AddOrdered(
        Card card, ECardDirection fromDirection, List<ChainSignal> ordered, HashSet<Card> seen)
    {
        if (card != null && seen.Add(card))
        {
            ordered.Add(new ChainSignal(card, 1, fromDirection));
        }
    }

    private float GetVisualSpeedMultiplier(int chainCount)
    {
        int additionalCount = Mathf.Max(0, chainCount - _chainVisualSpeedStartCount);
        return Mathf.Pow(1f + _chainVisualSpeedPerChain, additionalCount);
    }

    private float GetVisualSpeedMultiplierForCard(Card card)
    {
        return card != null && _cardVisualSpeeds.TryGetValue(card, out float multiplier)
            ? multiplier
            : 1f;
    }

    private async UniTask InvokeCardToggledAsync(Card card, bool activated, CancellationToken token)
    {
        if (OnCardToggledAsync == null)
        {
            return;
        }

        Delegate[] handlers = OnCardToggledAsync.GetInvocationList();
        for (int i = 0; i < handlers.Length; i++)
        {
            if (handlers[i] is Func<Card, bool, CancellationToken, UniTask> handler)
            {
                await handler.Invoke(card, activated, token);
                if (token.IsCancellationRequested)
                {
                    return;
                }
            }
        }
    }

    private async UniTask InvokeCardActivatedInChainAsync(Card card, int chainCount, CancellationToken token)
    {
        if (OnCardActivatedInChainAsync == null)
        {
            return;
        }

        Delegate[] handlers = OnCardActivatedInChainAsync.GetInvocationList();
        for (int i = 0; i < handlers.Length; i++)
        {
            if (handlers[i] is Func<Card, int, CancellationToken, UniTask> handler)
            {
                await handler.Invoke(card, chainCount, token);
                if (token.IsCancellationRequested)
                {
                    return;
                }
            }
        }
    }

    private static IEnumerable<ECardDirection> EnumerateDirections(ECardDirection dirs)
    {
        if ((dirs & ECardDirection.Up) != 0) yield return ECardDirection.Up;
        if ((dirs & ECardDirection.UpRight) != 0) yield return ECardDirection.UpRight;
        if ((dirs & ECardDirection.Right) != 0) yield return ECardDirection.Right;
        if ((dirs & ECardDirection.DownRight) != 0) yield return ECardDirection.DownRight;
        if ((dirs & ECardDirection.Down) != 0) yield return ECardDirection.Down;
        if ((dirs & ECardDirection.DownLeft) != 0) yield return ECardDirection.DownLeft;
        if ((dirs & ECardDirection.Left) != 0) yield return ECardDirection.Left;
        if ((dirs & ECardDirection.UpLeft) != 0) yield return ECardDirection.UpLeft;
    }

}
