// =================================================================
// [스크립트 목적]  드래그 중 카드 배치 예정 칸과 영향 칸 외곽 프리뷰 표시
// [주요 변수]      - _placementColor : 배치 예정 칸 초록 외곽선 색상
//                  - _projectileColor/_occupiedProjectileColor : 영향 칸 회전 투사체 색상
//                  - _outlinePadding/_zOffset : 슬롯 외곽 표시 보정값
// [의존 관계]      - GridManager 가 계산한 프리뷰 슬롯 목록 / GridSlot
// [설계 노트]      - 규칙 계산은 GridManager 가 담당하고, 이 클래스는 월드 공간 표시만 담당한다.
// =================================================================

using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// UI 캔버스가 아니라 실제 월드 그리드 위에 배치/영향 프리뷰를 표시한다.
/// </summary>
public sealed class GridPlacementPreviewTrailPresenter : MonoBehaviour
{
    [Header("배치 예정 칸")]
    [Tooltip("카드가 놓일 예정 칸 외곽선 색상")]
    [SerializeField] private Color _placementColor = new Color(0.2f, 1f, 0.25f, 0.95f);

    [Tooltip("배치 예정 칸 외곽선 두께")]
    [Min(0.001f)]
    [SerializeField] private float _placementLineWidth = 0.055f;

    [Header("영향 칸 투사체")]
    [Tooltip("빈 영향 칸 외곽을 도는 투사체 색상")]
    [SerializeField] private Color _projectileColor = new Color(1f, 0.05f, 0.02f, 0.62f);

    [Tooltip("점유 영향 칸 외곽을 도는 투사체 색상")]
    [SerializeField] private Color _occupiedProjectileColor = new Color(1f, 0.05f, 0.02f, 0.95f);

    [Tooltip("투사체 길이")]
    [Min(0.01f)]
    [SerializeField] private float _projectileLength = 0.35f;

    [Tooltip("투사체 두께")]
    [Min(0.001f)]
    [SerializeField] private float _projectileWidth = 0.07f;

    [Tooltip("투사체 이동 속도 (world units/sec)")]
    [Min(0.01f)]
    [SerializeField] private float _projectileSpeed = 2.8f;

    [Header("공통 보정")]
    [Tooltip("슬롯 외곽보다 바깥으로 표시할 거리")]
    [Min(0f)]
    [SerializeField] private float _outlinePadding = 0.08f;

    [Tooltip("그리드 바닥보다 앞에 보이도록 더하는 Z 오프셋")]
    [SerializeField] private float _zOffset = -0.05f;

    private readonly Vector3[] _cornerScratch = new Vector3[4];
    private readonly HashSet<GridSlot> _shownSlots = new HashSet<GridSlot>();
    private readonly List<OrbitingProjectile> _projectiles = new List<OrbitingProjectile>(16);
    private LineRenderer _placementOutline;
    private Material _material;

    public void Show(GridSlot origin, IReadOnlyList<GridSlot> previewSlots)
    {
        Clear();
        if (origin == null || previewSlots == null) return;

        ShowPlacementOutline(origin);

        _shownSlots.Clear();
        for (int i = 0; i < previewSlots.Count; i++)
        {
            GridSlot slot = previewSlots[i];
            if (slot == null || slot == origin) continue;
            if (!_shownSlots.Add(slot)) continue;

            if (!slot.TryGetWorldOutline(_cornerScratch, _outlinePadding, _zOffset)) continue;

            Color color = slot.IsEmpty ? _projectileColor : _occupiedProjectileColor;
            _projectiles.Add(CreateProjectile(slot, _cornerScratch, color));
        }
    }

    public void Clear()
    {
        if (_placementOutline != null)
        {
            Destroy(_placementOutline.gameObject);
            _placementOutline = null;
        }

        for (int i = _projectiles.Count - 1; i >= 0; i--)
        {
            _projectiles[i]?.Destroy();
        }
        _projectiles.Clear();
        _shownSlots.Clear();
    }

    private void Update()
    {
        if (_projectiles.Count == 0) return;

        float delta = _projectileSpeed * Time.deltaTime;
        for (int i = 0; i < _projectiles.Count; i++)
        {
            _projectiles[i]?.Update(delta, _projectileLength);
        }
    }

    private void OnDisable()
    {
        Clear();
    }

    private void ShowPlacementOutline(GridSlot origin)
    {
        if (!origin.TryGetWorldOutline(_cornerScratch, _outlinePadding, _zOffset)) return;

        GameObject go = new GameObject("PlacementPreviewOriginOutline");
        go.transform.SetParent(transform, false);
        _placementOutline = go.AddComponent<LineRenderer>();
        ConfigureLine(_placementOutline, _placementColor, _placementLineWidth);
        _placementOutline.positionCount = 5;
        for (int i = 0; i < 4; i++)
        {
            _placementOutline.SetPosition(i, _cornerScratch[i]);
        }
        _placementOutline.SetPosition(4, _cornerScratch[0]);
    }

    private OrbitingProjectile CreateProjectile(GridSlot slot, Vector3[] sourceCorners, Color color)
    {
        GameObject go = new GameObject($"PlacementPreviewProjectile_{slot.Position.x}_{slot.Position.y}");
        go.transform.SetParent(transform, false);

        LineRenderer line = go.AddComponent<LineRenderer>();
        ConfigureLine(line, color, _projectileWidth);
        line.positionCount = 2;

        Vector3[] corners = new Vector3[4];
        for (int i = 0; i < 4; i++)
        {
            corners[i] = sourceCorners[i];
        }

        OrbitingProjectile projectile = new OrbitingProjectile(go, line, corners);
        projectile.Update(0f, _projectileLength);
        return projectile;
    }

    private void ConfigureLine(LineRenderer line, Color color, float width)
    {
        line.useWorldSpace = true;
        line.startWidth = width;
        line.endWidth = width;
        line.startColor = color;
        line.endColor = color;
        line.numCapVertices = 4;
        line.sortingLayerName = "FrontEffect";

        Material material = GetMaterial();
        if (material != null)
        {
            line.material = material;
        }
    }

    private Material GetMaterial()
    {
        if (_material != null) return _material;

        Shader shader = Shader.Find("Sprites/Default");
        if (shader == null)
        {
            shader = Shader.Find("Universal Render Pipeline/Unlit");
        }
        if (shader == null) return null;

        _material = new Material(shader)
        {
            name = "GridPlacementPreviewTrailMaterial",
            hideFlags = HideFlags.HideAndDontSave
        };
        return _material;
    }

    private sealed class OrbitingProjectile
    {
        private readonly GameObject _owner;
        private readonly LineRenderer _line;
        private readonly Vector3[] _corners;
        private readonly float[] _segmentLengths = new float[4];
        private readonly float _totalLength;
        private float _distance;

        public OrbitingProjectile(GameObject owner, LineRenderer line, Vector3[] corners)
        {
            _owner = owner;
            _line = line;
            _corners = corners;

            for (int i = 0; i < 4; i++)
            {
                _segmentLengths[i] = Vector3.Distance(_corners[i], _corners[(i + 1) % 4]);
                _totalLength += _segmentLengths[i];
            }
        }

        public void Update(float distanceDelta, float projectileLength)
        {
            if (_line == null || _totalLength <= 0f) return;

            _distance = Mathf.Repeat(_distance + distanceDelta, _totalLength);
            _line.SetPosition(0, Evaluate(_distance));
            _line.SetPosition(1, EvaluateSameEdge(_distance, Mathf.Max(0.01f, projectileLength)));
        }

        public void Destroy()
        {
            if (_owner != null)
            {
                Object.Destroy(_owner);
            }
        }

        private Vector3 Evaluate(float targetDistance)
        {
            float remaining = Mathf.Repeat(targetDistance, _totalLength);
            for (int i = 0; i < 4; i++)
            {
                float segmentLength = _segmentLengths[i];
                if (remaining <= segmentLength || i == 3)
                {
                    Vector3 a = _corners[i];
                    Vector3 b = _corners[(i + 1) % 4];
                    float t = segmentLength > 0f ? remaining / segmentLength : 0f;
                    return Vector3.LerpUnclamped(a, b, t);
                }

                remaining -= segmentLength;
            }

            return _corners[0];
        }

        private Vector3 EvaluateSameEdge(float targetDistance, float forwardLength)
        {
            float remaining = Mathf.Repeat(targetDistance, _totalLength);
            for (int i = 0; i < 4; i++)
            {
                float segmentLength = _segmentLengths[i];
                if (remaining <= segmentLength || i == 3)
                {
                    Vector3 a = _corners[i];
                    Vector3 b = _corners[(i + 1) % 4];
                    float clamped = Mathf.Min(remaining + forwardLength, segmentLength);
                    float t = segmentLength > 0f ? clamped / segmentLength : 0f;
                    return Vector3.LerpUnclamped(a, b, t);
                }

                remaining -= segmentLength;
            }

            return _corners[0];
        }
    }
}
